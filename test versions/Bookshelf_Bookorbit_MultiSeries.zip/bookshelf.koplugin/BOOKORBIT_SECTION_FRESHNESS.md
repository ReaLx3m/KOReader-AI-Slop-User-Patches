# Refresh sections only when the server has something new (BookOrbit)

BookOrbit chips used to change only when you swiped down. The ones listed under "Which chip, and when" now check
BookOrbit quietly and redraw **only if the server's list is different** from what is on screen.
Menu: Bookshelf settings > BookOrbit > **Refresh sections automatically** (default **on**, key `bookorbit_section_refresh`).

**Not run on a device.** The decision logic (`lib/bookshelf_bookorbit_fresh.lua`, `lib/bookshelf_bookorbit_fresh_glue.lua`)
is covered by off-device tests with a fake clock, fake sync coordinator and fake Wi-Fi gate. `main.lua`, the widget, the
settings menu row and the real glue were only parse-checked. See "On-device checklist" at the end.

## What it does

1. **Shows the saved list first.** Chips keep their cached books (no time limit), so a tapped chip paints at once.
2. **Then asks the server one small question.** The check fetches the first page of the chip's list and builds a
   *signature* of the first 24 books: id, read status, `updatedAt` and progress (rounded to 0.5 %), in order.
3. **Compares with the last signature.** Same = nothing happens (no redraw, no flash). Different = the chip's cache is
   replaced/invalidated and the shelf redraws, but only if that chip is still the one on screen.

No ETag or "changed since" exists in the BookOrbit API (the official plugin has none either: it just re-fetches), so
the saved round trip is the work, not the response. The library version token (`manifestVersion`) is **not** used: it
does not move for reading progress, read status or Want to read flags.

## Which chip, and when

Only the chip **on screen**, and only these chips:

- **Continue reading** and **Want to read** (the first version of this feature).
- **Recently added** and **All books**.
- **Libraries, Collections and Smart scopes** shown as a flat book list (a chip pinned to one library / collection /
  smart scope, or to the "All <title>" entry, which is a flat list of every book).
- A **single Author** or **single Series** chip (a chip pinned directly to `authors:<name>` / `series:<name>`).

Never checked: **Discover** (random on purpose), **Similar books** (depends on one book), **Search** (a one-off query),
the **folder-tile views** (Authors / Series / Libraries / Collections / Smart scopes shown as tiles, including the
bare "All Authors" / "All Series" chips), and **anything you have drilled into**, for example an author opened by
tapping a folder tile. Those never trigger a request.
No background timer, no checking of chips you are not looking at.

| Trigger | What happens | Waits for Wi-Fi? | Minimum gap |
|---|---|---|---|
| Tap a chip (or swipe-cycle, or add/edit a chip) | Check starts 0.5 s after the chip paints | No: offline = skipped silently | 60 s per chip |
| Wake on the home screen | Check after the Auto Wi-Fi `wake_home` trigger | Yes, with Auto Wi-Fi on (up to 30 s) | 60 s per chip |
| Book closed, shelf returns | Check after the progress push | Yes, with Auto Wi-Fi on (up to 30 s) | none (`force`) |
| Manual swipe down | The swipe reloads the chip itself; the check then only records the new baseline (`adopt`), no second redraw | No | none (`force`) |

Notes:
- Tapping the chip that is **already active** does nothing (the chip bar treats it as a no-op), so it does not check.
- The 60 s is a **gap, not a timer**: nothing runs by itself. It only skips a check made less than 60 s after the last
  successful one for the same chip.
- `force` (book closed, swipe) skips both the 60 s gap **and** the failure back-off, because the data certainly
  changed and someone is waiting.
- Wake with a book open is not a trigger (pull-on-wake handles that book when "Pull progress on wake" is on). Startup, reconnect and "Sync now"
  are deliberately not triggers.
- **The wait for Wi-Fi only exists with Auto Wi-Fi on.** With Auto Wi-Fi off the check runs at once and is skipped if
  the radio is not back yet (some devices restore Wi-Fi a few seconds after wake). That is intentional.
- When the Wi-Fi is ready, the chip is decided **then**, not when the trigger fired. If the shelf is not showing, a
  book is open, the shelf is drilled into something, or the chip is not one of the covered chips above, the check is
  skipped and the Wi-Fi lease released.

## What it never does

- Turn Wi-Fi on by itself, or prompt for a connection. It uses Wi-Fi that is already up, or that the Auto Wi-Fi
  controller brings up for its own triggers (wake, book close). A manual Wi-Fi off is respected (no `trigger` is
  passed, so it never clears it).
- Show an error or notice. Offline, timeout, manual-off, setting off, BookOrbit not configured: all silent. An
  offline skip is **not** a failure and causes no back-off.
- Run in the render path. The request runs inside a sync-coordinator job (family `bo_fresh:<id>`), so it cannot race
  a progress push; a lease is held while waiting for Wi-Fi and released exactly once on every path.
- Redraw when nothing changed.

After a real failure (request error, throwing probe) the chip backs off 120 s, 240 s, 360 s ... capped at 900 s
(tap and wake obey it; `force` does not).

## How each chip is probed

- **Want to read:** `GET /koreader/plugin/catalog/dashboard/sections/want-to-read` (one request), used when the server
  advertises `catalogDashboardSections`. The list is in the **server's own order** (not re-sorted by
  `want_to_read_flagged_at`). On change the probed list is stored straight into the chip's cache. If the endpoint
  is unsupported (404/405, remembered for 30 min), fails, or looks truncated, the old catalog walk (up to 2000 books,
  100 per page) is used instead. The first load of a large library is therefore one request instead of up to 20.
- **Continue reading:** `catalogBooks{ sort="recently_read", readStatus="reading", page=1, size=24 }`, the same query
  the chip uses. On change only the chip's page cache is invalidated (page keys depend on the grid size); the redraw
  reloads the visible page once.
- **Recently added, All books, flat Library / Collection / Smart-scope, single Author / Series** (kind `catalog`):
  the same probe with the chip's own query (`recently_added`; `title`; `libraryId` / `collectionId` / `smartScopeId`;
  author or series with `sort=series`, a numeric series id goes out as `seriesId`), `page=1, size=24`. On change the
  chip's page cache (every cached page of that chip, including the one on screen) is dropped and the redraw reloads
  the visible page once. Nothing is stored from the probe itself.

The signature covers only the **first 24 books** of the chip's order. For Recently added that is exactly where new
books appear, and libraries, collections, authors and series are usually short enough to be covered whole. For **All
books** (title order) a change that only affects a book further down the list (for example a read-status change on a
book starting with "T") is **not detected**; the chip then stays as it is until you swipe down. This is a known
limit, not a bug. Because every newly covered chip starts with no saved signature, its first check after updating
counts as "changed" once and may redraw once even if nothing changed; after that it settles.

Signature baselines are kept in the shared cache under `fresh:<id>`, so a restart does not cause a refetch. With no
baseline (first run, evicted, or after `invalidateAll()`) a check counts as "changed" once, then settles.

## Risk R1: is the Want to read section capped? (UNVERIFIED)

The official plugin treats `want-to-read` as a short shelf with no list view, so the server may return only the first
N books. Nothing here could be tested against a real server. Protection built in:

- If the section carries a total larger than the books returned, or a "has more" flag, it is treated as truncated and
  merged with the walk (section order first, remaining walked books after).
- The constant `WTR_SECTION_COMPLETE_ASSUMED = true` in `lib/bookshelf_bookorbit_source.lua` (search for it, ~L1276)
  says "trust an untruncated-looking section as the full list". **If your Want to read chip shows fewer books than
  the server has, set it to `false`**: the section is then used only for ordering and the full list always comes from
  the walk (hybrid).
- Each Want to read load logs one info line: `want-to-read via <section|hybrid|walk> section_books <n> list <n>
  section_keys <keys>`. That line tells you what the server returned.

## Settings and files

- Setting: `bookorbit_section_refresh`, default on, read with `nilOrTrue` (an unset key means on). Turning it off stops
  every automatic check; the manual swipe still works. The 60 s gap and 30 s Wi-Fi wait are not configurable.
- Files: `lib/bookshelf_bookorbit_fresh.lua` (signature, section helpers, controller), `lib/bookshelf_bookorbit_fresh_glue.lua`
  (what is on screen, redraw rules, Wi-Fi gate, settings), `lib/bookshelf_bookorbit_source.lua` (`fresh*` hooks, section
  fetch), `lib/bookshelf_widget.lua` (tap, swipe), `main.lua` (wake, book close).
- Tests: `tools/bo_tests/test_bo_fresh.lua` (the id classification and the probe queries run against the real
  functions cut out of the source file).

## Known limits

- A gesture-unlock screen on wake stops `_repaintAfterWake` early, so no wake check then (same limit as the existing
  `wake_home` Auto Wi-Fi trigger).
- Book-close ordering (check reads data after the push) relies on FIFO `nextTick`, lease order and coordinator
  submission order. Unverified on a device (R5). If Continue reading shows the old order after closing a book but the
  new one after a tap, the probe ran too early and should be chained from the push job's completion.
- A baseline is a string with control-character separators stored through the settings layer. If after a restart every
  chip reports "changed" once more than expected, that round trip is the suspect.

## On-device checklist

1. **Capped section (R1):** count your Want to read books on the server and open the Want to read chip. The counts
   must match. If the chip shows fewer, set `WTR_SECTION_COMPLETE_ASSUMED` to `false`.
2. Flag a book Want to read in the web UI. On the device tap another chip, then Want to read (more than a minute after
   the last check). The old list shows at once, then updates by itself if something changed, with no visible flash
   when nothing changed.
3. Change progress on another device (or in the web UI). Tap Continue reading: same behaviour.
4. Leave Continue reading on screen, change progress elsewhere, let the device sleep, wake it on the home screen: the
   chip updates by itself within about 30 s (it waits for Wi-Fi if Auto Wi-Fi is on).
5. Auto Wi-Fi on + "Disconnect Wi-Fi when book is opened": open a book, close it. Wi-Fi comes back, the progress
   pushes, and the on-screen Continue reading chip then shows the new order. If it shows the old order until you tap
   it again, report it (risk R5).
6. Chips outside the covered set (Discover, Similar, Search, folder-tile views, anything drilled into) never trigger a
   request. Startup, reconnect and "Sync now" do not trigger a check by themselves.
7. Turn Wi-Fi off by hand, then wake the device or close a book: no check, Wi-Fi is not turned on by the check, no
   prompt, no error; cached lists still show. (The Auto Wi-Fi triggers on wake and book close may still reconnect, as
   before; that is not the check.)
8. Tap the chip that is already active: nothing should happen.
9. Turn "Refresh sections automatically" off: nothing refreshes by itself; the manual swipe still works.
10. Large library: the first load of Want to read is one request (read the log line above).
11. Old server without `catalogDashboardSections` (if you have one): Want to read still works through the walk.
12. **Recently added:** add a book on the server. Tap another chip, then Recently added (more than a minute after the
    last check): the new book appears by itself, with no visible flash when nothing changed.
13. **All books:** change a read status in the web UI for a book that sorts in the first 24 by title, tap All books:
    it updates. A change to a book far down the list is NOT expected to update (known limit).
14. **Flat Library / Collection / Smart-scope chip:** add or remove a book on the server, tap the chip: it updates.
15. **Not covered:** Discover, Similar, Search, folder-tile views and anything drilled into (including an author or
    series opened from a folder tile) never trigger a request.
16. **Book closed on All books / Recently added:** close a book while one of these chips is on screen; badges and
    order update after the push (same R5 caveat as Continue reading).
17. The first tap on each newly covered chip after updating may redraw once even if nothing changed (no saved
    signature yet); it must settle from then on.
18. **Single Author / Series chip** (pinned directly to one author or series): add a book to that author or series on
    the server, or change a read status, then tap the chip (more than a minute after the last check): it updates.
