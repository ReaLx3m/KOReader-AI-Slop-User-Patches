# BookOrbit integration

Adds a native BookOrbit client to Bookshelf: `lib/bookshelf_bookorbit.lua`
(auth, progress sync, catalog browsing + download) and
`lib/bookshelf_bookorbit_catalog.lua` (the on-device catalog browser),
wired into `main.lua` (push-on-close, pull-notice-on-open) and
`lib/bookshelf_settings.lua` (`Bookshelf menu -> BookOrbit`: Connect,
Browse catalog, Sync now, Disconnect).

## Update: BookOrbit does not speak OPDS

The first pass of this integration assumed BookOrbit's catalog was exposed
over OPDS (Atom/XML), based on its public marketing copy. It isn't. Checked
against BookOrbit's own official KOReader plugin source
(`bookorbit.koplugin`), the real catalog and auth surface is a JSON REST API
under `<server_url>/api/v1`, using the same X-Auth-User/X-Auth-Key headers
KOReader's own kosync plugin uses:

- `GET  /koreader/users/auth` -- verify credentials
- `PUT  /koreader/syncs/progress` -- push `{document, percentage, progress,
  device, device_id, timestamp}`
- `GET  /koreader/syncs/progress/<partial_md5>` -- pull latest position
- `GET  /koreader/plugin/catalog/root` -- top-level section list
- `GET  /koreader/plugin/catalog/sections/<section>` -- e.g. `libraries`,
  `collections`, `smart-scopes`, `authors`, `series`
- `GET  /koreader/plugin/catalog/books` -- paged book list (`page`, `size`,
  `sort`, `q`, `libraryId`, `collectionId`, `author`, `series`, etc.)
- `GET  /koreader/plugin/catalog/books/<id>` -- book detail, including a
  `files` array (`{id, format, sizeBytes, role}`)
- `GET  /koreader/plugin/catalog/files/<file_id>/download` -- the actual
  book bytes

`lib/bookshelf_bookorbit.lua` and `lib/bookshelf_bookorbit_catalog.lua` were
rewritten against this shape. This is what fixes the "Server sent xml but
no `<entry>` elements were found" error: the server was never returning
Atom in the first place, so no XML parser fix would have helped -- the
client needed to hit different endpoints entirely.

## What's confirmed vs. what to verify

**Confirmed** (read directly from BookOrbit's own official plugin source,
not guessed): auth headers, the progress-sync endpoints/payload shape, and
every catalog endpoint path + response field name listed above.

**Not confirmed -- test on your server:**
- Field names can still drift between BookOrbit versions; if a response
  shape doesn't match (e.g. `body.items` is empty when you expect books),
  add a quick `logger.info` dump in `jsonRequest`/`catalogBooks` etc. to see
  the raw decoded table.
- `BookOrbit.pushStats` is a stub (returns `false, "not_implemented"`) and
  isn't called anywhere yet. The server's real equivalent
  (`/koreader/plugin/page-stats`) expects a batch of already-aggregated
  per-book page-stat records wrapped with device metadata, not a single
  session snapshot -- implementing it properly is a separate task.
- `main.lua`'s pull-on-open check (`remote.device ~= BookOrbit.getConfig().device_id`)
  compares a device *name* (what the server echoes back in `progress.device`,
  e.g. "Kobo Libra") against a locally generated device *id* string. Those
  will essentially never match, so the guard likely never does what it's
  named for. Not touched here since it's unrelated to the catalog bug, but
  worth revisiting -- BookOrbit's own plugin doesn't use a device check at
  all for this decision, it compares `timestamp`/`percentage` instead (see
  `bookorbit_progress_sync.lua`).

## Update: two real client bugs found from live testing

- **Password hashing was broken.** `md5hex()` tried `require("md5")` (not
  a module KOReader ships) and silently fell back to
  `util.partialMD5()` -- a *sampled* per-file digest meant for identifying
  book files, not a real MD5 of an arbitrary string. The `X-Auth-Key` sent
  was therefore never a valid `md5(password)`, so every request 401'd
  regardless of how correct the credentials were. Now uses
  `require("ffi/sha2").md5`, the same hash BookOrbit's own official plugin
  uses for this.
- **Transport/TLS failures were misreported as "unexpected response."**
  When a request fails below the HTTP layer (bad cert, TLS handshake
  failure, DNS failure, connection refused), LuaSocket doesn't raise a Lua
  error -- `http.request` just returns `nil, "some string reason"`, which
  showed up as a non-numeric `code`. That fell through to the "got a
  response but it wasn't 2xx/401/403" branch and got shown as "Unexpected
  response from server," when the request never actually reached the
  server. Added the same `type(code) ~= "number"` guard the official
  plugin's `bookorbit_api.lua` uses, so this case now correctly says
  "Could not reach ... (<actual transport error>)." If you still see this
  on https after updating, the message will now contain the real reason
  (e.g. a certificate error) instead of a generic one.

## New: BookOrbit sections as chips (cover-grid browsing)

Previously the only way to browse the server was the plain-text
`Browse catalog` menu (`lib/bookshelf_bookorbit_catalog.lua`, untouched by
this change). You can now add a **chip** (the tabs across the top of the
shelf) that points at a BookOrbit section, so it shows in Bookshelf's normal
cover grid, pages, and opens exactly like a local shelf.

New/changed files:
- `lib/bookshelf_bookorbit_source.lua` (new) -- the bridge module. Maps a
  chip's `source.id` (e.g. `"libraries:42"`, `"recent:"`) onto one
  `catalogBooks()` page per grid page-turn, converts each server book into
  Bookshelf's record shape, downloads+disk-caches cover thumbnails, and
  resolves a real on-disk path (downloading on first open) when a book is
  tapped.
- `lib/bookshelf_bookorbit.lua` -- added `downloadCatalogThumbnail()` (the
  official plugin has this endpoint; the earlier port of this client didn't)
  and small shared download-destination helpers (`defaultDownloadDir`,
  `sanitizeFilename`, `uniqueDownloadPath`).
- `lib/bookshelf_book_repository.lua` -- `Repo.getBySource` gained a
  `kind == "bookorbit"` branch, right next to the existing Kobo
  virtual-library branch it's modeled on.
- `lib/bookshelf_chip_editor.lua` -- "New chip -> BookOrbit section..."
  opens a two-level picker (root shortcuts -- All books / Recently added /
  Continue reading -- plus whatever sections your server advertises:
  libraries, collections, smart scopes, authors, series -- then drills into
  entries within one). Picking a leaf sets the chip's source and names it
  after the picked entry.
- `lib/bookshelf_widget.lua` -- tapping a BookOrbit book downloads it (or
  reopens a previously-downloaded copy) then opens it, mirroring the Kobo
  virtual-book open flow but over the network with its own progress
  notice/error messages. Long-pressing one opens a small dedicated dialog
  (cover, title/author, Open, Close) instead of the full file-editing modal,
  since that modal's Delete/Move/Send-to-Kindle/etc. all assume a real file
  on disk, which a not-yet-downloaded BookOrbit record doesn't have.

**Known trade-offs, by design, given this is a first pass:**
- Section pickers (libraries/collections/authors/series lists) only fetch
  page 1 of entries; if you have enough of one type to paginate, later ones
  won't show up in the chip-creation picker yet.
- The grid's `total` isn't real (the API only reports `hasNext`, not a
  count) -- it's synthesised just far enough past the current page to keep
  forward paging working. Harmless for browsing; don't rely on any
  "X books" count shown for a BookOrbit chip.
- Cover thumbnails are version-keyed by each book's `updatedAt` (server-
  side cover change or a library rescan invalidates just that book's
  cached image automatically) -- see the disk-caching section below for
  the full design. This used to require manually clearing
  `<KOReader settings dir>/bookshelf_bookorbit_covers/`; that's no longer
  necessary for a normal cover replacement, only for a genuinely corrupt
  cache file.
- Downloaded-book bookkeeping lives in
  `bookshelf_bookorbit_downloads.lua` (maps remote book id -> local path);
  if you delete a downloaded file outside Bookshelf, the next tap
  re-downloads it automatically (the stale mapping is simply ignored,
  not cleaned up).
- Sort options in the chip editor's Sort tab have no effect on a BookOrbit
  chip -- ordering is decided server-side by the query each section/shortcut
  uses (title, recently_added, recently_read, or series).

**Not yet done / didn't touch:** bulk-select actions (multi-select toolbar)
aren't guarded against BookOrbit records the way the single-book long-press
menu now is -- avoid multi-selecting BookOrbit books until that's audited.

## New: choose the download folder

`Bookshelf menu -> BookOrbit` now has a **Download folder** item (shown
once connected, right below Connect). Tap it to pick any folder via
KOReader's normal folder browser; long-press it to reset back to the
auto-detected default (your KOReader home folder, falling back to the
full data dir if that isn't set). The chosen folder applies to downloads
from *both* the plain-text `Browse catalog` menu and books opened from a
BookOrbit chip -- both now go through the same `BookOrbit.downloadDir()`,
which prefers this setting and falls back to the old auto-detection when
it's unset or the folder has disappeared (e.g. an SD card was removed).

Stored alongside your BookOrbit credentials in the same settings file
(`download_dir` key); `Disconnect` does not clear it, so reconnecting
later keeps your chosen folder.



## New: two bugs found from live testing of the chip grid

- **Tapping a book replaced its title/author with a raw number (its
  BookOrbit id).** The tap-time selection-highlight repaint
  (`_repaintSelectionHighlight` in `bookshelf_widget.lua`) calls
  `Repo.buildBookMeta(fp)` to get "fresh" metadata for the tapped book,
  falling back to the existing record only if that returns nil.
  `buildBookMeta` is a generic real-file metadata builder -- it doesn't know
  about BookOrbit's synthetic `"bookorbit://<id>"` filepaths, so it queried
  BIM for a file that doesn't exist, got nothing back, and fell through to
  its "no metadata -- use the filename" fallback, which for that fake path
  is just the numeric id. Fixed with one guard at the top of
  `Repo.buildBookMeta`: return `nil` immediately for a `bookorbit://` path,
  so callers' existing `... or old_spine.book` fallback keeps the correct
  record instead.
- **Covers never showed -- text fallback every time.** The new
  `downloadCatalogThumbnail` was missing the `Accept-Encoding: identity`
  header that both the official plugin's `BookOrbitApi:download` and our
  own (working) `downloadCatalogFile` always send. Without it, a gzipping
  reverse proxy can hand back compressed bytes into a raw file sink --
  LuaSocket doesn't inflate for you -- so the "download" reports success
  (200, bytes landed on disk) but the file isn't a valid JPEG, and
  `RenderImage` silently fails to decode it, which looks identical to "no
  cover" from the outside. Added the missing header (matching
  `downloadCatalogFile` exactly), plus: a per-session failure cache so a
  book whose cover genuinely 404s/errors doesn't retry on every repaint,
  and cleanup of a downloaded-but-undecodable file so a one-off bad
  response doesn't permanently poison the disk cache for that book.
  `logger.dbg` now records the real failure reason
  (`[bookshelf][bookorbit] coverBB: ...`) if a cover still doesn't show --
  turn on debug logging and check the log if this recurs.

## New: disk-cached catalog pages, version-gated invalidation, offline fallback

Previously the chip grid's catalog pages lived only in an in-RAM cache
(gone on every app restart, no change-awareness -- a page fetched once
stayed "fresh" until manually refreshed, evicted for space, or the app
closed), and cover thumbnails were cached to disk forever with no
invalidation at all. Both now behave much closer to the plugin's local/
Kobo chips: cached to disk, surviving restarts, and only re-fetched from
the server when something has actually changed, rather than on a fixed
schedule or "never until the user notices staleness."

**Cover thumbnails** (`lib/bookshelf_bookorbit_source.lua`'s
`coverToken`/`memoKey`, mirroring the official BookOrbit plugin's own
`bookorbit_catalog_thumbnails.lua`): cache filenames are keyed by
`<book_id>_<updatedAt-digits>`, where `updatedAt` is a per-book timestamp
the server already includes on every catalog list/detail response. A
cover only re-downloads when *that specific book's* `updatedAt` changes
-- a server-side cover replacement or a library rescan invalidates
exactly the affected book's cached image, nothing else. This was already
in place before the batches below started (Batch 1 found it already
correct and made no change) -- it's documented here because it's the
model the catalog-page caching below deliberately copies for books,
scaled up to library level.

**Catalog pages** (`lib/bookshelf_bookorbit_cache.lua`): the RAM cache
(default 64MB, LRU-evicted) is now also persisted to disk, and gated by
a **library version token** instead of never expiring:
- `BookOrbit.getLibraryVersion()` (`lib/bookshelf_bookorbit.lua`) reads a
  single cheap "has anything in this user's accessible libraries changed"
  token off the catalog manifest endpoint (`size=1`, the smallest legal
  request) -- one lightweight aggregate query server-side, not a full
  catalog scan.
- `Cache.checkVersionAndInvalidate(version)` compares that token against
  the one the cache was last validated against: unchanged -> every cached
  page is kept as-is (zero network requests for pages already on disk);
  changed -> every cached page is wiped, since the token carries no
  detail about *what* changed or *where* (see the limitation below); a
  failed/offline version check fails open -- it never invalidates a good
  cache just because the check itself couldn't be verified.
- This is wired into the chip grid at `lib/bookshelf_bookorbit_source.lua`'s
  `listBooks`/`listGroups` entry points, debounced to at most once per 30
  seconds (there's no distinct "chip opened" event these functions get
  called on -- page turns, same-page cover-fill rebuilds, and internal
  helper lookups all re-enter the same two functions, so an exact
  once-per-chip-open trigger isn't available; see the header comment on
  `_checkLibraryVersionIfDue` in that file for the full reasoning).

**Important limitation -- library-wide, not per-chip:** the version token
covers a user's *entire* accessible library set. There is no per-chip or
per-section change signal from the server. A mismatch invalidates *all*
cached catalog pages at once, not just the chip/section that actually
changed -- e.g. adding one book to one library, then opening an unrelated
chip, re-fetches that unrelated chip's pages too, even though nothing in
it changed. This is a deliberate trade-off (correctness over
granularity), not a bug: the alternative would be silently serving a
stale page in some other chip because the invalidation missed it.

**Important limitation -- not a documented/public API:** the version
token isn't a dedicated, stable endpoint -- it rides along on a catalog
manifest response that wasn't designed for polling. This is the same
category of risk already accepted elsewhere in this integration for the
reverse-engineered catalog endpoints (see "BookOrbit does not speak
OPDS" above): it could change shape or disappear in a future BookOrbit
release without notice. If catalog pages stop being invalidated after a
BookOrbit server update (pages look stuck stale, or `currentVersion()`
stops changing), this token drifting or disappearing server-side is the
first thing to check.

**Offline fallback:** switching to a chip while offline used to always
show an empty grid. It now serves the last-known disk-cached page (or
bucket, for Authors/Series/Libraries/Collections/Smart-scopes) if one
exists from a previous fetch, in this session or an earlier one -- and
still shows an empty grid, instantly and without error, for a chip/page/
section that's never actually been fetched before. See item 6 in the
chip-browsing testing checklist below.

## Testing checklist (connect + basic catalog browsing)

1. Copy `bookshelf.koplugin/` onto a device, restart KOReader.
2. `Bookshelf menu -> BookOrbit -> Connect` with your server URL + KOReader
   account (the one set up in BookOrbit's web app under Settings >
   KOReader, not your main login).
3. `Browse catalog` should list your library sections (or books directly,
   depending on what your server's `/koreader/plugin/catalog/root` returns);
   drilling in and tapping a book should offer a download.
4. Open a book, read a page or two, go back to the shelf -- check your
   BookOrbit dashboard shows updated progress.
5. If `Connect` reports success but the catalog is empty or errors, check
   the HTTP code shown in the notification -- 401/403 means credentials,
   anything else likely means a field-name mismatch (see above).
6. `Download folder` -> pick a folder -> download a book from `Browse
   catalog`: it should land there. Long-press `Download folder` to reset,
   then confirm a download goes back to your KOReader home folder.

## Testing checklist (chip browsing)

1. `Bookshelf menu -> Edit chips -> New chip -> BookOrbit section...`.
2. Confirm the root list shows your shortcuts (All books / Recently added /
   Continue reading) plus your server's sections; drill into one (e.g.
   Libraries) and pick an entry.
3. Save -- the new chip should appear in the chip bar; tapping it should
   show a cover grid (covers may take a moment to download the first time
   you see each one; scrolling back to a page you've already seen should be
   instant).
3a. Covers should render as actual images, not blank/text-only cells. If a
    particular book still shows text instead of its cover, turn on debug
    logging and look for `[bookshelf][bookorbit] coverBB: ...` in the log
    to see the real reason (download failure vs. undecodable file).
4. Tap a book: expect a brief "Downloading from BookOrbit..." notice, then
   the reader opens. Go back, tap the same book again: should open
   immediately (no re-download).
4a. Tapping a book (before it opens) should NOT change its title/author
    text to a number -- the title/author shown should stay exactly what it
    was before the tap.
5. Long-press a book: expect the small Open/Close dialog, not the full
   Edit/Tags/Reviews modal.
6. Turn off WiFi and switch to a chip you've browsed before (in this
   session or a previous one): should show the last-known cached page
   instead of an empty grid. Switching to a chip/section/page you've
   never opened before while offline should still show an empty grid --
   there's nothing on disk to fall back to -- but should do so instantly,
   without erroring or hanging.

As with the rest of this integration, all touched files pass a Lua syntax
check but this has not been run inside an actual KOReader process --
please test on-device before relying on it.

