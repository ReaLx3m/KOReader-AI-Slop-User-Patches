# Hero community rating (Hardcover / Goodreads / Amazon / Apple Books)

Settings > BookOrbit > "Community rating in hero" lets the hero's star row
show a BookOrbit-sourced book's **community rating** from an ordered chain
of providers you choose (any combination of Hardcover, Goodreads, Amazon,
Apple Books/iTunes) instead of your own personal rating -- display-only,
same rendering as the existing separate "Show Hardcover ratings in hero"
option, but reading BookOrbit's own per-book rating data.

Tap providers in the submenu in the order you want them tried: the first
one that actually has a rating for a given book wins. E.g. enabling
Goodreads, then Apple Books, then Hardcover (in that tap order) tries
Goodreads first, falls back to Apple Books if that book has no Goodreads
rating, then Hardcover, and finally falls back to your own rating if none
of them have one for that book.

## Why this needs a server change first

BookOrbit's server (checked against `bookorbit/bookorbit` on GitHub, `main`
branch) already collects these ratings -- they're stored per book in its
`bookCommunityRatings` table and used for filtering in the web UI (Magic
Shelves / smart scopes). But the KOReader-facing endpoint this plugin
talks to, `GET /koreader/plugin/catalog/books/<id>`, never included that
field in its response: `KoreaderCatalogBookDetail`
(`packages/types/src/koreader.ts`) and the mapping in
`koreader-catalog.service.ts` only ever sent the *user's own* `rating`,
not `communityRatings`.

So this plugin's `bookshelf_bookorbit_source.lua` has code to read and
cache a `communityRatings` array off the book detail response
(`M.communityRating` / `M.communityRatingFallback`, wired into
`M.rebuildRecord`), but against an unpatched BookOrbit server that field
is simply absent from the JSON -- there's nothing to read, the setting
silently has nothing to show, and the hero falls back to your own rating
exactly as if the setting were off.

## Applying the server patch

If you self-host BookOrbit, apply
`bookorbit-server-expose-community-ratings.patch` (shipped alongside this
plugin) to your BookOrbit server checkout:

```sh
cd /path/to/your/bookorbit
git apply bookorbit-server-expose-community-ratings.patch
```

It touches exactly two files, both purely additive (no existing field
removed or renamed, so nothing else that reads this endpoint -- the web
client, other integrations -- is affected):

- `packages/types/src/koreader.ts` -- adds
  `communityRatings: BookCommunityRating[]` to `KoreaderCatalogBookDetail`.
- `server/src/modules/koreader/koreader-catalog.service.ts` -- forwards
  `detail.communityRatings` (already fetched for every book detail lookup)
  into that response instead of dropping it.

Rebuild/redeploy your server the same way you normally would after
pulling an update (`docker compose up -d --build`, or your usual
build step), then re-open a book's hero (or pull-to-refresh the shelf) --
`rebuildRecord`'s per-book detail fetch will pick up `communityRatings`
from then on.

## Stale cache after patching

The hero's per-book detail (synopsis + community ratings) is cached to
disk, keyed off the book's own `updatedAt`. If you'd already opened a
book's hero even once *before* patching the server, that cache entry has
no `communityRatings` in it -- and since nothing about the book itself
changed server-side, the cache still looks valid and never re-fetches on
its own. Symptom: some books show a community rating fine (the ones
opened for the first time after patching), others don't (the ones you'd
already looked at before).

Fix: **Settings > BookOrbit > "Clear cached descriptions & ratings"**
(or the swipe-down-to-refresh gesture from the collapsed shelf, which
does the same thing among other cache resets). Either drops the whole
cache so the next hero view of any BookOrbit book re-fetches its detail
fresh.

## Notes

- This is **not an official BookOrbit patch** -- it's a small, targeted
  addition for this plugin's own use, built by reading BookOrbit's public
  source. Field names, whether a book has a rating from a given provider
  at all, and the shape of `communityRatings` can still drift in a future
  BookOrbit server release; if the hero setting stops showing anything
  after a server update, that's the first thing to check.
- Consider also filing this as a feature request on
  `github.com/bookorbit/bookorbit/issues` -- if BookOrbit ships it
  upstream, this local patch becomes unnecessary.
- A book with no rating at all from your chosen provider (present in
  `communityRatings` for other providers, just not that one) falls back
  to your own rating, the same as when the plugin's own Hardcover-linking
  toggle has no cached rating for a book.
