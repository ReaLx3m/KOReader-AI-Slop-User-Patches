# Fix: distorted BookOrbit covers when paging back to an already-visited page

## Symptom

Browsing a BookOrbit chip several pages deep (10+ pages, 12 covers/page),
then paging back to a page visited earlier: some covers render as garbage
(not blank, not missing -- corrupted pixel noise). Tapping a corrupted
cover opens the hero fine, and afterwards **both** the hero and that
book's grid thumbnail display correctly.

## Root cause: a guard/ownership conflict between two files

1. `bookshelf_bookorbit_cache.lua` caches each page's book-list in RAM
   (default 64MB, no TTL) and hands back the **same mutated-in-place
   record tables** on every revisit -- confirmed by the existing comment
   on `wantsCover()` in `bookshelf_bookorbit_source.lua`.

2. `scheduleCoverFills` -> `wantsCover(record)` used `record.cover_bb`
   itself as its "already filled, don't requeue" guard. This was written
   to stop an infinite re-fill loop (a disk-cache-hit record would
   otherwise "succeed" again instantly every rebuild), but it silently
   assumed `cover_bb` stays a valid reference forever.

3. It doesn't. `record.cover_bb` is a ONE-SHOT bb: `SpineWidget`
   (`bookshelf_spine_widget.lua`) frees it as soon as a grid tile
   consumes it -- either directly, or after copying its pixels into
   `ScaledCoverCache`. Nothing ever set the field back to `nil` after
   freeing it.

4. So: page 1 loads, its covers get filled and painted, and every
   `record.cover_bb` on that page is now a **dangling pointer to freed
   memory** that `wantsCover()` still treats as "good."

5. Page forward 10-11 pages (this evicts page 1's actual pixel data out
   of `ScaledCoverCache`'s much smaller 24MB budget -- `bookshelf_
   bookorbit_cache.lua`'s 64MB metadata budget doesn't account for
   `cover_bb` bytes at all, so it happily keeps the stale pointers
   resident long after the real pixel cache has dropped them).

6. Page back to page 1. `getBySource` returns the same records, with
   `wantsCover()` still refusing to requeue them. `SpineWidget` picks up
   the stale `record.cover_bb` as its source bb and, depending on whether
   `ScaledCoverCache` still had a valid entry for that book's synthetic
   `bookorbit://<id>` filepath:
   - **hit**: frees the already-freed bb a second time (double free --
     can corrupt the allocator broadly, not just that one cover), or
   - **miss**: scales the freed memory directly into a "fresh" cover,
     caching and painting garbage.

7. Tapping the book routes through `rebuildRecord`/`buildPreviewBook`
   (see `BOOKORBIT_HERO_FIX.md`), which unconditionally fetches a real
   fresh cover and, via the same `ScaledCoverCache:put(fp, ...)` path
   SpineWidget uses, **overwrites the shared cache entry** for that
   filepath -- which is why the grid thumbnail also comes right the
   moment you back out of the hero, without anyone touching the grid's
   own record.

## Fix

- `lib/bookshelf_spine_widget.lua`: both places that free a `bb` sourced
  from `self.book.cover_bb` (the cache-hit "didn't need it after all"
  free, and the cache-miss "scaled it, done with the source" free) now
  also null `self.book.cover_bb` afterwards. A shared/cached record can
  no longer retain a reference to memory that's already been freed.
- `lib/bookshelf_bookorbit_source.lua`: `wantsCover()` now checks a new,
  persistent `record._cover_filled` boolean instead of `record.cover_bb`
  directly. `fillOneCover()` sets it once, alongside `cover_bb`, and it's
  never cleared -- so the original anti-loop guarantee (a record that's
  already been filled doesn't get requeued every rebuild) still holds
  even though `cover_bb` itself can now legitimately go back to `nil`
  after a grid tile consumes it.

## What this does NOT fully solve

If `ScaledCoverCache` has evicted a book's pixels by the time you page
back to it, and `SpineWidget` has since nulled that book's
`cover_bb`, the grid tile now shows the ordinary blank/placeholder cover
for a beat (same class of "cover not ready yet" as any first-ever
render) rather than corrupted pixels -- `Repo.getCoverBB` short-circuits
to `nil` for synthetic `bookorbit://` paths, and `wantsCover()`'s
`_cover_filled` guard means it won't get auto-requeued for a fresh
download/decode by `scheduleCoverFills` on that revisit. This is a
strict improvement (no corruption, no double-free) but not a full fix
for that narrower case; re-priming `ScaledCoverCache` from the
already-downloaded thumbnail file on disk (bypassing `wantsCover`
entirely, since no network round-trip is needed) would close that gap
too, if it turns out to matter in practice.

## Testing checklist

1. `luajit -e "assert(loadfile(...))"` on both touched files -- parses
   clean. Not yet run inside an actual KOReader process -- please test
   on-device.
2. Open a BookOrbit chip with 100+ books, page ~10 pages deep, page back
   to page 1. Covers should render correctly or blank -- never garbled.
3. Repeat with `Settings > BookOrbit > Cache size` (bookorbit RAM cache)
   and the cover-cache MB budget both turned down, to make eviction
   happen sooner and exercise the miss path more easily.
4. Tap a book whose cover was blank/placeholder on a revisited page --
   hero should show a correct cover, and the grid thumbnail should also
   resolve correctly once you back out.
