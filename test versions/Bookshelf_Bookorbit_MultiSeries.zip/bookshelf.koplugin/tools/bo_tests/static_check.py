#!/usr/bin/env python3
"""Static QA for the BookOrbit micro-modules. Needs only Python 3 (no Lua, no lupa),
so it runs where the Lua test suites cannot. It is NOT a replacement for them:
it checks structure, not behaviour.

Usage (from the plugin root):
    python3 -I tools/bo_tests/static_check.py            # run every check
    python3 -I tools/bo_tests/static_check.py pot --write # also append missing strings to the .pot

Checks
  syntax    a Lua tokenizer (strings, long strings, comments) + block/bracket balance
            for every .lua file: function/if/for/while/do/repeat vs end/until, () {} []
  requires  every require("x") in the BookOrbit files resolves to a file in the plugin
            or to a known KOReader module (anything else is listed, not guessed)
  specs     keys unique and prefixed, category set, `server` flag agrees with the
            summary text ("Needs a BookOrbit server." / "Works offline."), no key
            clashes with the other micromodules
  pot       every literal _("...") / ngettext("..","..",n) of the BookOrbit files is a
            msgid in locale/bookshelf.pot
"""
import os, re, sys

ROOT = os.getcwd()
SCOPE_GLOBS = ("lib/bookorbit_board/", "lib/bookshelf_bo_", "micromodules/bookorbit_",
               "lib/bookshelf_bookorbit_catalog.lua")
fails = 0


def report(ok, msg):
    global fails
    if not ok:
        fails += 1
    print(("ok   " if ok else "FAIL ") + msg)


def lua_files():
    out = []
    for d, _dirs, fs in os.walk(ROOT):
        for f in fs:
            if f.endswith(".lua"):
                out.append(os.path.relpath(os.path.join(d, f), ROOT))
    return sorted(out)


def in_scope(rel):
    return any(rel.startswith(g) for g in SCOPE_GLOBS)


# ------------------------------------------------------------------ tokenizer
ESC = {"n": "\n", "t": "\t", "r": "\r", "a": "\a", "b": "\b", "f": "\f", "v": "\v",
       "\\": "\\", '"': '"', "'": "'", "\n": "\n"}


def tokenize(src):
    """Yield (kind, value, line). kind: name | str | op | num. Raises ValueError."""
    i, n, line = 0, len(src), 1
    toks = []
    while i < n:
        c = src[i]
        if c == "\n":
            line += 1; i += 1; continue
        if c in " \t\r":
            i += 1; continue
        if src.startswith("--", i):
            m = re.match(r"--\[(=*)\[", src[i:])
            if m:
                close = "]" + m.group(1) + "]"
                j = src.find(close, i)
                if j < 0:
                    raise ValueError("unterminated long comment at line %d" % line)
                line += src.count("\n", i, j); i = j + len(close)
            else:
                j = src.find("\n", i)
                i = n if j < 0 else j
            continue
        m = re.match(r"\[(=*)\[", src[i:])
        if m:
            close = "]" + m.group(1) + "]"
            j = src.find(close, i)
            if j < 0:
                raise ValueError("unterminated long string at line %d" % line)
            val = src[i + len(m.group(0)):j]
            toks.append(("str", val, line)); line += src.count("\n", i, j); i = j + len(close)
            continue
        if c in "\"'":
            q, j, buf, start = c, i + 1, [], line
            while True:
                if j >= n or src[j] == "\n":
                    raise ValueError("unterminated string at line %d" % start)
                ch = src[j]
                if ch == q:
                    break
                if ch == "\\":
                    j += 1
                    e = src[j]
                    if e in ESC:
                        buf.append(ESC[e])
                        if e == "\n":
                            line += 1
                    elif e.isdigit():
                        k = j
                        while k < n and k < j + 3 and src[k].isdigit():
                            k += 1
                        buf.append(chr(int(src[j:k]))); j = k - 1
                    elif e == "x":
                        buf.append(chr(int(src[j + 1:j + 3], 16))); j += 2
                    elif e == "z":
                        while j + 1 < n and src[j + 1] in " \t\r\n":
                            if src[j + 1] == "\n":
                                line += 1
                            j += 1
                    elif e == "u":
                        k = src.index("}", j)
                        buf.append(chr(int(src[j + 2:k], 16))); j = k
                    else:
                        raise ValueError("bad escape \\%s at line %d" % (e, line))
                else:
                    buf.append(ch)
                j += 1
            toks.append(("str", "".join(buf), start)); i = j + 1
            continue
        m = re.match(r"[A-Za-z_][A-Za-z_0-9]*", src[i:])
        if m:
            toks.append(("name", m.group(0), line)); i += len(m.group(0)); continue
        m = re.match(r"0[xX][0-9a-fA-F.]+(?:[pP][+-]?\d+)?|\d+\.?\d*(?:[eE][+-]?\d+)?|\.\d+(?:[eE][+-]?\d+)?", src[i:])
        if m:
            toks.append(("num", m.group(0), line)); i += len(m.group(0)); continue
        for op in ("...", "..", "==", "~=", "<=", ">=", "//", "::", "<<", ">>"):
            if src.startswith(op, i):
                toks.append(("op", op, line)); i += len(op); break
        else:
            toks.append(("op", c, line)); i += 1
    return toks


def balance(toks):
    """Returns an error string or None. Stack entries are [opener, line, do_pending]."""
    stack = []
    pairs = {")": "(", "]": "[", "}": "{"}
    for kind, v, ln in toks:
        if kind == "op":
            if v in "([{":
                stack.append([v, ln, False])
            elif v in pairs:
                if not stack or stack[-1][0] != pairs[v]:
                    return "unbalanced '%s' at line %d" % (v, ln)
                stack.pop()
        elif kind == "name":
            if v in ("for", "while"):
                stack.append([v, ln, True])          # its own `do` is still to come
            elif v == "do":
                if stack and stack[-1][0] in ("for", "while") and stack[-1][2]:
                    stack[-1][2] = False             # the loop's `do`: no new block
                else:
                    stack.append(["do", ln, False])
            elif v in ("function", "if", "repeat"):
                stack.append([v, ln, False])
            elif v == "until":
                if not stack or stack[-1][0] != "repeat":
                    return "'until' without 'repeat' at line %d" % ln
                stack.pop()
            elif v == "end":
                if not stack or stack[-1][0] in ("(", "[", "{", "repeat"):
                    return "'end' without opener at line %d (top=%s)" % (ln, stack[-1][:2] if stack else None)
                stack.pop()
    if stack:
        return "unclosed '%s' opened at line %d" % tuple(stack[-1][:2])
    return None


def check_syntax(files):
    bad = 0
    for rel in files:
        try:
            src = open(os.path.join(ROOT, rel), encoding="utf-8").read()
            err = balance(tokenize(src))
        except Exception as e:  # noqa
            err = "%s: %s" % (type(e).__name__, e)
        if err:
            bad += 1
            report(False, "syntax %s -> %s" % (rel, err))
    report(bad == 0, "syntax: %d Lua files tokenised and block-balanced, %d problems" % (len(files), bad))


# ------------------------------------------------------------------- requires
KOREADER_PREFIXES = (
    "ui/", "ffi/", "device", "logger", "gettext", "datetime", "util", "docsettings",
    "libs/", "optionsutil", "frontend/", "apps/", "dispatcher", "readhistory", "luasettings",
    "ltn12", "socket", "socketutil", "mime", "json", "rapidjson", "lua-ljsqlite3/", "lfs",
    "ffi", "bit", "cache", "document/", "pic", "persist", "version", "dbg", "plugins/",
    "datastorage", "ui", "random", "sort", "dump", "lua_settings", "docsettings", "gesturerange",
    "configurable", "koptoptions", "readerui", "bookinfomanager", "fontlist", "isolated",
)


def check_requires(files, known_ok):
    allfiles = set(lua_files())
    unknown = {}
    total = 0
    for rel in files:
        if not in_scope(rel):
            continue
        src = open(os.path.join(ROOT, rel), encoding="utf-8").read()
        toks = tokenize(src)
        for i, (k, v, ln) in enumerate(toks):
            if k == "name" and v == "require":
                j = i + 1
                if j < len(toks) and toks[j][:2] == ("op", "("):
                    j += 1
                if j < len(toks) and toks[j][0] == "str":
                    total += 1
                    name = toks[j][1]
                    cand = [name + ".lua", name + "/init.lua"]
                    if any(c in allfiles for c in cand):
                        continue
                    if name.startswith(KOREADER_PREFIXES) or name in known_ok:
                        continue
                    unknown.setdefault(name, []).append("%s:%d" % (rel, ln))
    for name, where in sorted(unknown.items()):
        report(False, "require(%r) not in the plugin and not a known KOReader module: %s" % (name, ", ".join(where[:3])))
    report(not unknown, "requires: %d require() calls in the BookOrbit files, %d unresolved" % (total, len(unknown)))


# ---------------------------------------------------------------------- specs
def check_specs():
    mdir = os.path.join(ROOT, "micromodules")
    bo_files = sorted(f for f in os.listdir(mdir) if f.startswith("bookorbit_") and f.endswith(".lua"))
    others = [f for f in os.listdir(mdir) if f.endswith(".lua") and f not in bo_files]
    other_keys = set()
    for f in others:
        for m in re.finditer(r'\bkey\s*=\s*"([^"]+)"', open(os.path.join(mdir, f), encoding="utf-8").read()):
            other_keys.add(m.group(1))
    keys, per_cat, problems = {}, {}, 0
    for f in bo_files:
        src = open(os.path.join(mdir, f), encoding="utf-8").read()
        spans = [m for m in re.finditer(r'\bkey\s*=\s*"(bookorbit_[a-z0-9_]+)"', src)]
        loop_server = bool(re.search(r"for\s+_\w+,\s*b\s+in\s+ipairs\(BUDDIES\)[\s\S]*?server\s*=\s*true", src))
        for idx, m in enumerate(spans):
            key = m.group(1)
            end = spans[idx + 1].start() if idx + 1 < len(spans) else len(src)
            win = src[m.start():end]
            if key in keys:
                report(False, "duplicate key %s (%s and %s)" % (key, keys[key], f)); problems += 1
            keys[key] = f
            cat = re.search(r'category\s*=\s*"(bookorbit:[a-z]+)"', win)
            summ = re.search(r'summary\s*=\s*_\("((?:[^"\\]|\\.)*)"\)', win)
            if not cat:
                # buddy rows get their category in the loop that builds the specs
                if key.startswith("bookorbit_buddy_") and 'category = "bookorbit:decor"' in src:
                    cat_name = "bookorbit:decor"
                else:
                    report(False, "%s: no category" % key); problems += 1; continue
            else:
                cat_name = cat.group(1)
            per_cat[cat_name] = per_cat.get(cat_name, 0) + 1
            server = bool(re.search(r"\bserver\s*=\s*true", win)) or (key.startswith("bookorbit_buddy_") and loop_server)
            if not summ:
                report(False, "%s: no summary" % key); problems += 1; continue
            text = summ.group(1)
            needs, offline = "Needs a BookOrbit server." in text, "Works offline." in text
            if needs == offline or needs != server:
                report(False, "%s: server=%s but summary says %r" % (key, server, text[-40:])); problems += 1
            if key in other_keys:
                report(False, "%s clashes with an existing Bookshelf module" % key); problems += 1
    total = len(keys)
    report(problems == 0, "specs: %d BookOrbit modules, keys unique, categories set, server flag matches summary" % total)
    print("     per category: " + ", ".join("%s=%d" % (k.split(":")[1], v) for k, v in sorted(per_cat.items())))
    return keys


# ------------------------------------------------------------------------ pot
def po_decode(s):
    out, i = [], 0
    while i < len(s):
        if s[i] == "\\" and i + 1 < len(s):
            out.append({"n": "\n", "t": "\t", '"': '"', "\\": "\\"}.get(s[i + 1], s[i + 1])); i += 2
        else:
            out.append(s[i]); i += 1
    return "".join(out)


def po_encode(s):
    return s.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n").replace("\t", "\\t")


def pot_msgids(path):
    ids, cur, in_id = set(), None, False
    for raw in open(path, encoding="utf-8"):
        line = raw.rstrip("\n")
        if line.startswith("msgid "):
            if cur is not None:
                ids.add(cur)
            cur, in_id = po_decode(line[7:-1]), True
        elif line.startswith("msgstr") or line.startswith("msgid_plural"):
            in_id = False
        elif in_id and line.startswith('"'):
            cur += po_decode(line[1:-1])
    if cur is not None:
        ids.add(cur)
    return ids


# Vendored code that is kept for fidelity but never reachable (the Chapter line widget was
# dropped): its strings are not worth a translator's time.
DEAD_RANGES = {"lib/bookorbit_board/decor.lua": [(891, 959)]}


def extract_strings(rel):
    """[(msgid, line)] for literal _("..") and ngettext("..","..",n) calls. Strings with no
    letter in them ("%1 %2", "<1%") carry nothing to translate and are skipped."""
    dead = DEAD_RANGES.get(rel, [])
    toks = tokenize(open(os.path.join(ROOT, rel), encoding="utf-8").read())
    out = []
    for i, (k, v, ln) in enumerate(toks):
        if k != "name" or i + 2 >= len(toks) or toks[i + 1][:2] != ("op", "("):
            continue
        if v == "_" and toks[i + 2][0] == "str" and toks[i + 3][:2] in (("op", ")"), ("op", ",")):
            out.append((toks[i + 2][1], ln))
        elif v == "ngettext" and toks[i + 2][0] == "str" and toks[i + 3][:2] == ("op", ",") and toks[i + 4][0] == "str":
            out.append((toks[i + 2][1], ln)); out.append((toks[i + 4][1], ln))
    return [(m, ln) for m, ln in out
            if re.search(r"[^\W\d_]", m) and not any(a <= ln <= b for a, b in dead)]


def check_pot(files, write):
    pot = os.path.join(ROOT, "locale", "bookshelf.pot")
    have = pot_msgids(pot)
    missing = {}
    for rel in files:
        if not in_scope(rel):
            continue
        for msg, ln in extract_strings(rel):
            if msg and msg not in have:
                missing.setdefault(msg, []).append("%s:%d" % (rel, ln))
    if missing and write:
        with open(pot, "a", encoding="utf-8") as fh:
            for msg, refs in sorted(missing.items(), key=lambda kv: kv[1][0]):
                seen, uniq = set(), []
                for r in refs:
                    if r not in seen:
                        seen.add(r); uniq.append(r)
                fh.write('\n#: %s\nmsgid "%s"\nmsgstr ""\n' % (" ".join(uniq), po_encode(msg)))
        print("     appended %d msgids to locale/bookshelf.pot" % len(missing))
        return check_pot(files, False)
    for msg, refs in sorted(missing.items(), key=lambda kv: kv[1][0])[:15]:
        print("     missing: %r  (%s)" % (msg, refs[0]))
    report(not missing, "pot: %d literal strings in the BookOrbit files, %d not in locale/bookshelf.pot" % (
        sum(len(extract_strings(r)) for r in files if in_scope(r)), len(missing)))


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    write = "--write" in sys.argv
    what = args or ["syntax", "requires", "specs", "pot"]
    files = lua_files()
    if "syntax" in what:
        check_syntax(files)
    if "requires" in what:
        check_requires(files, set())
    if "specs" in what:
        check_specs()
    if "pot" in what:
        check_pot(files, write)
    print("RESULT:", "all static checks passed" if not fails else "%d problem(s)" % fails)
    sys.exit(1 if fails else 0)


if __name__ == "__main__":
    main()
