-- Prescale, Batch S1: the pure orchestration (lib/bookshelf_bookorbit_prescale.lua).
-- Off-device; no KOReader. Proves the LOGIC only (not run on a device). The module is
-- NOT wired into the source or the widget yet (S2 / S3).
package.path = PLUGIN .. "/?.lua;" .. package.path
local fails, passes = 0, 0
local function check(n, c, x)
    if c then passes = passes + 1
    else fails = fails + 1; print("FAIL: " .. n .. (x ~= nil and (" -> " .. tostring(x)) or "")) end
end

local Prescale = require("lib/bookshelf_bookorbit_prescale")

-- Fakes ----------------------------------------------------------------------------
local frees = 0   -- every bb:free(); the module must never cause one
local function fake_bb(w, h)
    local bb = { w = w, h = h }
    function bb:free() frees = frees + 1 end
    return bb
end
local function book(id) return { filepath = "bookorbit://" .. id, remote_id = id, has_cover = true } end

-- A rig: a fake clock that advances by the "cost" of each dep, call logs, and knobs.
local function rig(over)
    local r = { t = 100, calls = {}, cache = {}, logs = {}, dims_w = 118, dims_h = 158 }
    r.log = function(name, ...) r.calls[#r.calls + 1] = name end
    local d = {
        dims = function(rec)
            r.log("dims")
            if r.dims_throw then error("dims boom") end
            if r.dims_nil then return nil end
            return r.dims_w, r.dims_h
        end,
        has = function(fp, w, h)
            r.log("has"); r.has_args = { fp, w, h }
            if r.has_throw then error("has boom") end
            return r.has_result and true or false
        end,
        scale = function(bb, w, h)
            r.log("scale"); r.scale_args = { bb, w, h }
            r.t = r.t + (r.scale_cost or 0.040)
            if r.scale_throw then error("scale boom") end
            if r.scale_nil then return nil end
            return fake_bb(w, h)
        end,
        put = function(fp, bb)
            r.log("put"); r.put_args = { fp, bb }
            r.t = r.t + (r.put_cost or 0.120)
            if r.put_throw then error("put boom") end
            if r.put_nil then return nil end
            r.cache[fp] = bb
            return r.put_returns or bb
        end,
        now = function() return r.t end,
        logger = { dbg = function(self, ...) r.logs[#r.logs + 1] = table.concat({ ... }, " ") end },
    }
    for k, v in pairs(over or {}) do d[k] = v end
    r.p = Prescale.new(d)
    return r
end
local function count(r, name) local n = 0; for _, c in ipairs(r.calls) do if c == name then n = n + 1 end end; return n end

-- isBookRecord -------------------------------------------------------------------------
check("isBookRecord: numeric book", Prescale.isBookRecord(book(42)) == true)
check("isBookRecord: big id", Prescale.isBookRecord({ filepath = "bookorbit://1234567" }) == true)
check("isBookRecord: nil", Prescale.isBookRecord(nil) == false)
check("isBookRecord: string", Prescale.isBookRecord("bookorbit://1") == false)
check("isBookRecord: no filepath", Prescale.isBookRecord({}) == false)
check("isBookRecord: non-numeric id (folder/author tile)", Prescale.isBookRecord({ filepath = "bookorbit://author-7" }) == false)
check("isBookRecord: empty id", Prescale.isBookRecord({ filepath = "bookorbit://" }) == false)
check("isBookRecord: trailing junk", Prescale.isBookRecord({ filepath = "bookorbit://12/x" }) == false)
check("isBookRecord: other scheme", Prescale.isBookRecord({ filepath = "/mnt/onboard/book.epub" }) == false)
check("isBookRecord: filepath not a string", Prescale.isBookRecord({ filepath = 12 }) == false)

-- the happy path -----------------------------------------------------------------------
do
    local r = rig()
    local bb = fake_bb(600, 900)
    local rec = book(7)
    local st, stats = r.p:run(rec, bb)
    check("scaled: status", st == "scaled", st)
    check("scaled: stats table", type(stats) == "table")
    check("scaled: stats w/h", stats and stats.w == 118 and stats.h == 158)
    check("scaled: scale_ms", stats and math.abs(stats.scale_ms - 40) < 0.01, stats and stats.scale_ms)
    check("scaled: put_ms", stats and math.abs(stats.put_ms - 120) < 0.01, stats and stats.put_ms)
    check("scaled: order dims, has, scale, put", table.concat(r.calls, ",") == "dims,has,scale,put", table.concat(r.calls, ","))
    check("scaled: has got the filepath and size", r.has_args[1] == "bookorbit://7" and r.has_args[2] == 118 and r.has_args[3] == 158)
    check("scaled: scale got the raw bb at the tile size", r.scale_args[1] == bb and r.scale_args[2] == 118 and r.scale_args[3] == 158)
    check("scaled: put got the SCALED bb under the filepath", r.put_args[1] == "bookorbit://7"
        and r.put_args[2] ~= bb and r.put_args[2].w == 118 and r.put_args[2].h == 158)
    check("scaled: the cache holds it", r.cache["bookorbit://7"] == r.put_args[2])
    check("scaled: the raw bb is never freed", frees == 0)
    check("scaled: the record is not touched", rec.cover_bb == nil and rec._cover_filled == nil and rec.has_cover == true)
end

-- already cached ------------------------------------------------------------------------
do
    local r = rig(); r.has_result = true
    local bb = fake_bb(600, 900)
    local st, stats = r.p:run(book(8), bb)
    check("already: status", st == "already", st)
    check("already: stats carry the size and zero costs", stats and stats.w == 118 and stats.h == 158 and stats.scale_ms == 0 and stats.put_ms == 0)
    check("already: no scale", count(r, "scale") == 0)
    check("already: no put (no disk write)", count(r, "put") == 0)
    check("already: raw bb not freed", frees == 0)
    local r2 = rig(); r2.has_result = true
    local st2 = r2.p:run(book(8), nil)
    check("already: works without a bitmap", st2 == "already")
end

-- not a book / no dims -------------------------------------------------------------------
do
    local r = rig()
    local st, why = r.p:run({ filepath = "bookorbit://author-1" }, fake_bb(10, 10))
    check("not_book: nil + reason", st == nil and why == "not_book", why)
    check("not_book: no dep is even asked", #r.calls == 0, table.concat(r.calls, ","))
    local st2, why2 = r.p:run(nil, fake_bb(10, 10))
    check("nil record: not_book", st2 == nil and why2 == "not_book")
    local st3, why3 = r.p:run({ filepath = "/x/y.epub" }, fake_bb(10, 10))
    check("plain file record: not_book", st3 == nil and why3 == "not_book")
end
do
    local r = rig(); r.dims_nil = true
    local st, why = r.p:run(book(1), fake_bb(10, 10))
    check("no_dims: nil + reason", st == nil and why == "no_dims", why)
    check("no_dims: nothing scaled, nothing put, has not asked", count(r, "scale") == 0 and count(r, "put") == 0 and count(r, "has") == 0)
end
for _, bad in ipairs({ { 0, 100 }, { 100, 0 }, { -5, 100 }, { 0 / 0, 100 }, { "118", 158 }, { 118, "158" }, { 0.5, 100 } }) do
    local r = rig(); r.dims_w, r.dims_h = bad[1], bad[2]
    local st, why = r.p:run(book(1), fake_bb(10, 10))
    check("no_dims: unusable size " .. tostring(bad[1]) .. "x" .. tostring(bad[2]), st == nil and why == "no_dims" and count(r, "put") == 0, why)
end
do
    local r = rig(); r.dims_w, r.dims_h = 1, 1
    check("tiny but valid size is accepted", r.p:run(book(1), fake_bb(10, 10)) == "scaled")
end

-- no bitmap -----------------------------------------------------------------------------
do
    local r = rig()
    local st, why = r.p:run(book(1), nil)
    check("no_bitmap: nil + reason", st == nil and why == "no_bitmap", why)
    check("no_bitmap: scale and put not called", count(r, "scale") == 0 and count(r, "put") == 0)
end

-- scale failures ------------------------------------------------------------------------
do
    local r = rig(); r.scale_nil = true
    local bb = fake_bb(10, 10)
    local st, why = r.p:run(book(1), bb)
    check("scale returns nil: scale_failed", st == nil and why == "scale_failed", why)
    check("scale returns nil: put NOT called", count(r, "put") == 0)
    check("scale returns nil: raw bb not freed", frees == 0)
end
do
    local r = rig(); r.scale_throw = true
    local ok, st, why = pcall(function() return r.p:run(book(1), fake_bb(10, 10)) end)
    check("scale throws: no error escapes", ok == true)
    check("scale throws: scale_failed", st == nil and why == "scale_failed", why)
    check("scale throws: put NOT called", count(r, "put") == 0)
    check("scale throws: logged", #r.logs >= 1 and r.logs[1]:find("scale", 1, true) ~= nil, r.logs[1])
end
do
    local r = rig({ scale = function() return false end })
    local st, why = r.p:run(book(1), fake_bb(10, 10))
    check("scale returns false: scale_failed", st == nil and why == "scale_failed", why)
end

-- put failures --------------------------------------------------------------------------
do
    local r = rig(); r.put_nil = true
    local st, why = r.p:run(book(1), fake_bb(10, 10))
    check("put returns nil: put_failed", st == nil and why == "put_failed", why)
    check("put returns nil: scaled bitmap not freed", frees == 0)
end
do
    local r = rig(); r.put_throw = true
    local ok, st, why = pcall(function() return r.p:run(book(1), fake_bb(10, 10)) end)
    check("put throws: no error escapes", ok == true)
    check("put throws: put_failed", st == nil and why == "put_failed", why)
    check("put throws: nothing freed (put may have stored it)", frees == 0)
end

-- put keeps a larger cached entry (returns that bb): still success ------------------------
do
    local r = rig(); local bigger = fake_bb(240, 316); r.put_returns = bigger
    local st = r.p:run(book(1), fake_bb(10, 10))
    check("put returning a larger cached bb is still 'scaled'", st == "scaled")
end

-- throwing dims / has -------------------------------------------------------------------
do
    local r = rig(); r.dims_throw = true
    local ok, st, why = pcall(function() return r.p:run(book(1), fake_bb(10, 10)) end)
    check("dims throws: no error escapes", ok == true)
    check("dims throws: error reason", st == nil and why == "error", why)
    check("dims throws: nothing scaled or put", count(r, "scale") == 0 and count(r, "put") == 0)
end
do
    local r = rig(); r.has_throw = true
    local ok, st, why = pcall(function() return r.p:run(book(1), fake_bb(10, 10)) end)
    check("has throws: no error escapes", ok == true)
    check("has throws: error reason (not 'already', not scaled)", st == nil and why == "error", why)
    check("has throws: nothing scaled or put", count(r, "scale") == 0 and count(r, "put") == 0)
end

-- missing deps / defaults ------------------------------------------------------------------
do
    local p = Prescale.new{}
    local ok, st, why = pcall(function() return p:run(book(1), fake_bb(10, 10)) end)
    check("no deps at all: no error", ok == true)
    check("no deps at all: nil + error", st == nil and why == "error", why)
    local p2 = Prescale.new()
    check("Prescale.new() without a table works", select("#", p2:run(book(1), fake_bb(1, 1))) == 2)
    local p3 = Prescale.new{ dims = function() return 10, 10 end, has = function() return false end }
    local st3, why3 = p3:run(book(1), fake_bb(10, 10))
    check("missing scale dep: scale_failed", st3 == nil and why3 == "scale_failed", why3)
end

-- clock handling ---------------------------------------------------------------------------
do
    local r = rig({ now = function() error("no clock") end })
    local st, stats = r.p:run(book(1), fake_bb(10, 10))
    check("clock throws: still scaled", st == "scaled")
    check("clock throws: ms are 0, not an error", stats and stats.scale_ms == 0 and stats.put_ms == 0)
    local r2 = rig({ now = function() return "x" end })
    local st2, stats2 = r2.p:run(book(1), fake_bb(10, 10))
    check("clock returns junk: still scaled, ms 0", st2 == "scaled" and stats2.scale_ms == 0 and stats2.put_ms == 0)
    local r3 = rig(); local calls = 0
    local d_now = function() calls = calls + 1; return 100 - calls end   -- goes backwards
    local r4 = rig({ now = d_now })
    local st4, stats4 = r4.p:run(book(1), fake_bb(10, 10))
    check("clock goes backwards: ms clamp to 0", st4 == "scaled" and stats4.scale_ms == 0 and stats4.put_ms == 0)
end

-- default clock does not need a dep ------------------------------------------------------------
do
    local p = Prescale.new{
        dims = function() return 4, 4 end, has = function() return false end,
        scale = function(bb, w, h) return fake_bb(w, h) end, put = function(fp, bb) return bb end,
    }
    local st, stats = p:run(book(3), fake_bb(10, 10))
    check("no clock dep: scaled with default clock", st == "scaled" and type(stats.scale_ms) == "number" and stats.scale_ms >= 0)
end

-- repeatability: the object keeps no state between runs ----------------------------------------------
do
    local r = rig()
    local a = r.p:run(book(1), fake_bb(10, 10))
    r.has_result = true
    local b = r.p:run(book(1), fake_bb(10, 10))
    r.has_result = false; r.scale_nil = true
    local c, why = r.p:run(book(2), fake_bb(10, 10))
    r.scale_nil = false
    local d = r.p:run(book(3), fake_bb(10, 10))
    check("stateless: scaled, already, failed, scaled again", a == "scaled" and b == "already" and c == nil and why == "scale_failed" and d == "scaled")
end

-- a different size per record (true cover aspect is per book) ----------------------------------------
do
    local sizes = { ["bookorbit://1"] = { 118, 158 }, ["bookorbit://2"] = { 118, 170 } }
    local seen = {}
    local p = Prescale.new{
        dims = function(rec) local s = sizes[rec.filepath]; return s[1], s[2] end,
        has = function() return false end,
        scale = function(bb, w, h) seen[#seen + 1] = w .. "x" .. h; return fake_bb(w, h) end,
        put = function(fp, bb) return bb end,
    }
    p:run(book(1), fake_bb(1, 1)); p:run(book(2), fake_bb(1, 1))
    check("dims is asked per record", seen[1] == "118x158" and seen[2] == "118x170", table.concat(seen, ","))
end

-- the module has no KOReader dependency ------------------------------------------------------------
do
    local f = io.open(PLUGIN .. "/lib/bookshelf_bookorbit_prescale.lua")
    local src = f:read("*a"); f:close()
    check("source: no require() at all (pure)", not src:find("require%s*%(") and not src:find("require%s*\""))
    check("source: never frees (no :free() call)", not src:find(":free%s*%("))
    check("source: no direct SpineWidget/ScaledCoverCache use", not src:find("SpineWidget%.") and not src:find("ScaledCoverCache[:%.]"))
end

print(string.format("test_bo_prescale: %d passed, %d failed", passes, fails))
return fails > 0
