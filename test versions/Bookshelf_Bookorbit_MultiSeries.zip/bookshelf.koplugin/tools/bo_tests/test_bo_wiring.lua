-- Cover speed, Batch 3: wiring of the cover pool inside the REAL
-- lib/bookshelf_bookorbit_source.lua, run against fakes (fake clock/timers,
-- fake fork, fake lfs, fake decode). Off-device; proves the glue, not device
-- behaviour (fork, HTTP, RenderImage are all faked). NOT run on a device.
package.path = PLUGIN .. "/?.lua;" .. package.path
local fails, passes = 0, 0
local function check(n, c, x)
    if c then passes = passes + 1
    else fails = fails + 1; print("FAIL: " .. n .. (x ~= nil and (" -> " .. tostring(x)) or "")) end
end

-- A stub that answers every field and call, for the many requires the source
-- makes that this test does not care about.
local function universal()
    return setmetatable({}, {
        __index = function() return universal() end,
        __call = function() return universal() end,
    })
end

local DIR = "/s/bookshelf_bookorbit_covers"
local W   -- the current world (rebuilt for every scenario)

local function newWorld(opts)
    opts = opts or {}
    local w = { now = 100, timers = {}, forks = {}, files = {}, removed = {}, logs = {},
                events = {}, pid = 1000, online = true, dir_listing = opts.dir_listing or {} }
    local UI = {}
    function UI:scheduleIn(d, fn) w.timers[#w.timers + 1] = { t = w.now + d, fn = fn } end
    function UI:unschedule(fn)
        for i = #w.timers, 1, -1 do if w.timers[i].fn == fn then table.remove(w.timers, i) end end
    end
    local function fork(pid) for _, f in ipairs(w.forks) do if f.pid == pid then return f end end end
    local ffi = {
        runInSubProcess = function(payload)
            if w.fork_fails then return nil end
            w.pid = w.pid + 1
            w.forks[#w.forks + 1] = { pid = w.pid, payload = payload }
            return w.pid, w.pid
        end,
        isSubProcessDone = function(pid) local f = fork(pid); return f == nil or f.done == true end,
        getNonBlockingReadSize = function(fd) local f = fork(fd); return f and f.out and #f.out or 0 end,
        readAllFromFD = function(fd) local f = fork(fd); return f and f.out or "" end,
        terminateSubProcess = function(pid) local f = fork(pid); if f then f.killed = true; f.done = true end end,
        writeToFD = function(fd, s) local f = fork(fd); if f then f.out = s end end,
    }
    if opts.no_fork then ffi.runInSubProcess = nil end
    w.BO = universal()
    w.BO.downloadCatalogThumbnailAtomic = function(id, final) return w.download(id, final) end
    w.BO.downloadCatalogAuthorPhotoAtomic = function(id, final) return w.download_photo(id, final) end
    w.BO.downloadCatalogThumbnail = function() return true end   -- inline fallback path
    w.download = function() return true end
    w.download_photo = function() return true end
    local lfs = {
        attributes = function(p, m)
            if w.files[p] then return m == "mode" and "file" or 1 end
            if p == DIR then return m == "mode" and "directory" or nil end
        end,
        dir = function()
            local i = 0
            return function() i = i + 1; return w.dir_listing[i] end
        end,
    }
    w.decoded = 0
    local stubs = {
        ["ui/uimanager"] = UI, ["ffi/util"] = ffi,
        ["ui/network/manager"] = { isOnline = function() return w.online end },
        ["libs/libkoreader-lfs"] = lfs,
        ["util"] = { makePath = function() return true end },
        ["datastorage"] = { getSettingsDir = function() return "/s" end },
        ["lib/bookshelf_gettime"] = function() return w.now end,
        ["logger"] = { dbg = function(...)
            local t = {}; for i = 1, select("#", ...) do t[#t + 1] = tostring((select(i, ...))) end
            w.logs[#w.logs + 1] = table.concat(t, " ")
        end, info = function() end, warn = function() end },
        ["lib/bookshelf_bookorbit"] = w.BO,
        ["ui/renderimage"] = { renderImageFile = function()
            w.decoded = w.decoded + 1
            if w.bad_decode then return nil end
            return { getWidth = function() return 10 end, getHeight = function() return 20 end }
        end },
    }
    w.os_remove = os.remove
    w.stubs = stubs
    return w
end

local real_require = require
local function loadSource(w)
    function require(name)   -- luacheck: ignore
        if w.stubs[name] then return w.stubs[name] end
        if name:match("^lib/") then
            local ok, m = pcall(real_require, name)
            if ok then return m end
        end
        return universal()
    end
    local f, err = loadfile(PLUGIN .. "/lib/bookshelf_bookorbit_source.lua")
    assert(f, err)
    local M = f()
    require = real_require   -- luacheck: ignore
    -- The module resolves its lazy requires at call time, so keep the fakes
    -- installed for the whole scenario.
    function require(name)   -- luacheck: ignore
        if w.stubs[name] then return w.stubs[name] end
        if name:match("^lib/") then
            local ok, m = pcall(real_require, name)
            if ok then return m end
        end
        return universal()
    end
    return M
end

local function run(w, secs)
    local stop = w.now + secs
    while true do
        table.sort(w.timers, function(a, b) return a.t < b.t end)
        local t = w.timers[1]
        if not t or t.t > stop then break end
        table.remove(w.timers, 1)
        w.now = math.max(w.now, t.t)
        t.fn()
    end
    w.now = stop
end

local function path(id, day) return DIR .. "/" .. id .. "_2026010" .. day .. ".jpg" end
local function mkrecs(n)
    local r = {}
    for i = 1, n do r[i] = { remote_id = i, updated_at = "2026-01-0" .. i } end
    return r
end
local function filled(recs) local n = 0; for _, r in ipairs(recs) do if r._cover_filled then n = n + 1 end end; return n end
local function perfLine(w) for _, l in ipairs(w.logs) do if l:find("[bookshelf perf] bo covers: n=", 1, true) then return l end end end

-- finish a worker: run its payload in-process (the "child"), and, like the
-- real child, a "1" result means the file now exists on disk.
local function finishFork(w, f, id_for_file)
    f.payload(f.pid, f.pid)
    f.done = true
    if f.out == "1" and id_for_file then w.files[path(id_for_file, id_for_file)] = true end
end

-- 1. load + happy path ------------------------------------------------------------------------------
do
    W = newWorld(); local w = W
    local M = loadSource(w)
    check("source loads with stubs", type(M) == "table" and type(M.scheduleCoverFills) == "function")
    check("shutdownCoverPool exported", type(M.shutdownCoverPool) == "function")
    M.onCoversReady(function(sid, final) w.events[#w.events + 1] = tostring(sid) .. ":" .. tostring(final) end)
    local recs = mkrecs(5)
    M.scheduleCoverFills(recs, "chipA")
    check("nothing forked before the first timer", #w.forks == 0)
    run(w, 0.1)
    check("width 3: three workers launched", #w.forks == 3, #w.forks)
    check("no inline download happened (UI thread untouched)", w.decoded == 0)
    for i = 1, 3 do finishFork(w, w.forks[i], i) end
    run(w, 0.4)
    check("two more workers launched as slots freed", #w.forks == 5, #w.forks)
    for i = 4, 5 do finishFork(w, w.forks[i], i) end
    run(w, 2)
    check("all five covers filled", filled(recs) == 5, filled(recs))
    check("cover fields set", recs[1].cover_bb ~= nil and recs[1].cover_w == 10 and recs[1].cover_h == 20 and recs[1].has_cover == true)
    check("exactly one final event", (function() local n = 0; for _, e in ipairs(w.events) do if e == "chipA:true" then n = n + 1 end end; return n end)() == 1, table.concat(w.events, ","))
    check("final is the last event", w.events[#w.events] == "chipA:true")
    check("four non-final events before it", #w.events == 5, #w.events)
    local line = perfLine(w)
    check("perf line logged", line ~= nil)
    check("perf line counts", line and line:find("n=5", 1, true) and line:find("forked=5", 1, true)
        and line:find("failed=0", 1, true) and line:find("landed=5", 1, true) and line:find("width_end=3", 1, true), line)
    -- re-scheduling a filled page is a no-op
    local before = #w.forks
    M.scheduleCoverFills(recs, "chipA"); run(w, 1)
    check("filled page: nothing queued again", #w.forks == before and #w.timers == 0 or #w.forks == before, #w.forks)
end

-- 2. the child's result contract ------------------------------------------------------------------
do
    W = newWorld(); local w = W
    local M = loadSource(w)
    M.onCoversReady(function() end)
    local recs = mkrecs(4)
    recs[4].author_photo = true
    local seen = {}
    w.download = function(id, final) seen[#seen + 1] = "book:" .. id .. ":" .. final; return true end
    w.download_photo = function(id, final) seen[#seen + 1] = "photo:" .. id .. ":" .. final; return true end
    M.scheduleCoverFills(recs, "x")
    run(w, 0.1)
    for i = 1, 3 do finishFork(w, w.forks[i], nil) end
    check("child writes exactly \"1\" on success", w.forks[1].out == "1", w.forks[1].out)
    check("child downloads to the FINAL path (atomic .part is inside the BO call)", seen[1] == "book:1:" .. path(1, 1), seen[1])
    -- failure strings
    w.download = function() return nil, "http_404" end
    local f = { pid = 9, payload = nil }
    -- run a fresh child through the real payload by launching one more cover
    local recs2 = { { remote_id = 77, updated_at = "2026-01-09" } }
    M.scheduleCoverFills(recs2, "x"); run(w, 0.2)
    local last = w.forks[#w.forks]
    last.payload(last.pid, last.pid)
    check("child writes nf:<why> on a failed download", last.out == "nf:http_404", last.out)
    w.download = function() error("boom\nsecond line") end
    local recs3 = { { remote_id = 78, updated_at = "2026-01-09" } }
    M.scheduleCoverFills(recs3, "x"); run(w, 0.2)
    last = w.forks[#w.forks]
    last.payload(last.pid, last.pid)
    check("a crashing download still yields a clean nf: line", last.out and last.out:match("^nf:") and not last.out:find("\n"), last.out)
    w.download = function() return nil, nil end
    local recs4 = { { remote_id = 79, updated_at = "2026-01-09" } }
    M.scheduleCoverFills(recs4, "x"); run(w, 0.2)
    last = w.forks[#w.forks]
    last.payload(last.pid, last.pid)
    check("nil,nil still yields nf:", last.out and last.out:match("^nf:") ~= nil, last.out)
end

-- 3. a definitive failure gives the key up; manual refresh brings it back ------------------------------
do
    W = newWorld(); local w = W
    local M = loadSource(w)
    M.onCoversReady(function(sid, final) w.events[#w.events + 1] = tostring(final) end)
    local recs = mkrecs(1)
    w.download = function() return nil, "http_404" end
    M.scheduleCoverFills(recs, "x"); run(w, 0.1)
    check("one worker", #w.forks == 1)
    finishFork(w, w.forks[1], nil)
    run(w, 1)
    check("failed cover is not filled", filled(recs) == 0)
    M.scheduleCoverFills(recs, "x"); run(w, 1)
    check("given up: no second fork", #w.forks == 1, #w.forks)
    check("no landed event for a failure", #w.events == 0)
    M.clearThumbFailures()
    w.download = function() return true end
    M.scheduleCoverFills(recs, "x"); run(w, 0.1)
    check("manual refresh clears the give-up (pool + blacklist): forks again", #w.forks == 2, #w.forks)
end

-- 4. supersede keeps the in-flight worker (C7) ----------------------------------------------------------
do
    W = newWorld(); local w = W
    local M = loadSource(w)
    M.onCoversReady(function() end)
    local recs = mkrecs(6)
    M.scheduleCoverFills(recs, "A"); run(w, 0.1)
    check("3 in flight", #w.forks == 3)
    M.scheduleCoverFills(recs, "A"); run(w, 0.2)      -- a rebuild calls it again
    M.cancelThumbnailJobs(); run(w, 0.2)
    check("supersede/cancel launched no duplicate workers", #w.forks == 3, #w.forks)
    local any_killed = false
    for _, f in ipairs(w.forks) do if f.killed then any_killed = true end end
    check("cancel/supersede kills nothing in flight", not any_killed)
end

-- 5. P4: a background chip supersedes the pending list but never the in-flight ones ----------------------
do
    W = newWorld(); local w = W
    local M = loadSource(w)
    M.onCoversReady(function(sid, final) w.events[#w.events + 1] = tostring(sid) .. ":" .. tostring(final) end)
    local visible = mkrecs(6)
    local background = {}
    for i = 1, 3 do background[i] = { remote_id = 100 + i, updated_at = "2026-01-0" .. i } end
    M.scheduleCoverFills(visible, "visible"); run(w, 0.1)
    check("visible: 3 in flight", #w.forks == 3)
    M.scheduleCoverFills(background, "background"); run(w, 0.2)
    local killed = false
    for _, f in ipairs(w.forks) do if f.killed then killed = true end end
    check("P4: a background call does not kill in-flight visible downloads", not killed)
    check("P4: slots stay full (no extra worker while 3 are busy)", #w.forks == 3, #w.forks)
    for i = 1, 3 do finishFork(w, w.forks[i], i) end
    run(w, 0.5)
    -- The visible chip's PENDING covers (4-6) were replaced by the background
    -- chip's list; the next rebuild of the visible page re-queues them.
    local done_ids = {}
    for _, f in ipairs(w.forks) do done_ids[#done_ids + 1] = f.pid end
    check("P4: the three finished visible covers still land", filled(visible) == 3, filled(visible))
    M.scheduleCoverFills(visible, "visible"); run(w, 0.5)
    local seen_visible_again = #w.forks > 3
    check("P4: re-scheduling the visible page re-queues its dropped covers", seen_visible_again, #w.forks)
end

-- 6. shutdown (widget closed) ----------------------------------------------------------------------------
do
    W = newWorld(); local w = W
    local M = loadSource(w)
    M.onCoversReady(function(sid, final) w.events[#w.events + 1] = tostring(final) end)
    local recs = mkrecs(6)
    M.scheduleCoverFills(recs, "x"); run(w, 0.1)
    check("3 workers before shutdown", #w.forks == 3)
    M.shutdownCoverPool()
    local killed = 0
    for _, f in ipairs(w.forks) do if f.killed then killed = killed + 1 end end
    check("shutdown kills every in-flight worker", killed == 3, killed)
    run(w, 3)
    check("no event and no new worker after shutdown", #w.events == 0 and #w.forks == 3, #w.events .. "/" .. #w.forks)
    check("shutdown with no pool is harmless", (function()
        local w2 = newWorld(); local M2 = loadSource(w2); return pcall(M2.shutdownCoverPool)
    end)())
end

-- 7. offline: nothing launched, no failure, no Wi-Fi prompt ----------------------------------------------
do
    W = newWorld(); local w = W
    w.online = false
    local M = loadSource(w)
    M.onCoversReady(function() end)
    local recs = mkrecs(3)
    M.scheduleCoverFills(recs, "x"); run(w, 2)
    check("offline: no worker launched", #w.forks == 0)
    check("offline: nothing marked failed", not perfLine(w))
    w.online = true
    M.scheduleCoverFills(recs, "x"); run(w, 0.1)
    check("back online: the same covers are tried", #w.forks == 3, #w.forks)
end

-- 8. disk hits never fork ---------------------------------------------------------------------------------
do
    W = newWorld(); local w = W
    local M = loadSource(w)
    M.onCoversReady(function(sid, final) w.events[#w.events + 1] = tostring(final) end)
    local recs = mkrecs(3)
    for i = 1, 3 do w.files[path(i, i)] = true end
    M.scheduleCoverFills(recs, "x"); run(w, 1)
    check("disk hits: no fork", #w.forks == 0, #w.forks)
    check("disk hits: all decoded in the parent", filled(recs) == 3 and w.decoded == 3, w.decoded)
    local line = perfLine(w)
    check("perf line shows disk=3 forked=0", line and line:find("disk=3", 1, true) and line:find("forked=0", 1, true), line)
end

-- 9. fallback to the inline loop (C10) --------------------------------------------------------------------
do
    W = newWorld({ no_fork = true }); local w = W
    local M = loadSource(w)
    M.onCoversReady(function(sid, final) w.events[#w.events + 1] = tostring(final) end)
    local recs = mkrecs(3)
    M.scheduleCoverFills(recs, "x")
    for i = 1, 3 do w.files[path(i, i)] = true end   -- the inline download "wrote" them
    run(w, 1)
    check("no runInSubProcess: inline loop fills the covers", filled(recs) == 3, filled(recs))
    check("no runInSubProcess: a final event still fires", w.events[#w.events] == "true", table.concat(w.events, ","))
end
do
    W = newWorld(); local w = W
    w.fork_fails = true
    local M = loadSource(w)
    M.onCoversReady(function(sid, final) w.events[#w.events + 1] = tostring(final) end)
    local recs = mkrecs(3)
    M.scheduleCoverFills(recs, "x")
    for i = 1, 3 do w.files[path(i, i)] = true end
    run(w, 1)
    check("fork fails: pool hands the work back, inline loop fills the covers", filled(recs) == 3, filled(recs))
    check("fork fails: exactly one final", (function() local n = 0; for _, e in ipairs(w.events) do if e == "true" then n = n + 1 end end; return n end)() == 1, table.concat(w.events, ","))
    -- later calls go straight to the inline loop
    local more = { { remote_id = 50, updated_at = "2026-01-05" } }
    w.files[path(50, 5)] = true
    M.scheduleCoverFills(more, "x"); run(w, 1)
    check("after fork_broken later pages still fill inline", filled(more) == 1)
end

-- 9b. the inline fallback uses the short timeout tier; a timeout is not blacklisted ----------------------
do
    W = newWorld({ no_fork = true }); local w = W
    local tiers = {}
    local M = loadSource(w)
    M.onCoversReady(function() end)
    w.BO.downloadCatalogThumbnail = function(id, final, tier) tiers[#tiers + 1] = tostring(tier); return nil, "timeout" end
    local recs = mkrecs(1)
    M.scheduleCoverFills(recs, "x"); run(w, 0.5)
    check("inline fallback asks for the short (block) tier", tiers[1] == "block", tiers[1])
    M.scheduleCoverFills(recs, "x"); run(w, 0.5)
    check("a timeout is retried later, not blacklisted", #tiers == 2, #tiers)
    w.BO.downloadCatalogThumbnail = function(id, final, tier) tiers[#tiers + 1] = "x"; return nil, "http_404" end
    M.scheduleCoverFills(recs, "x"); run(w, 0.5)
    M.scheduleCoverFills(recs, "x"); run(w, 0.5)
    check("a definitive failure is blacklisted at once", #tiers == 3, #tiers)
end

-- 10. decoding: one BlitBuffer per record, bad file is retried then given up --------------------------
do
    W = newWorld(); local w = W
    local M = loadSource(w)
    M.onCoversReady(function() end)
    local a = { remote_id = 1, updated_at = "2026-01-01" }
    local b = { remote_id = 1, updated_at = "2026-01-01" }   -- same cover key, a second record object
    w.files[path(1, 1)] = true
    M.scheduleCoverFills({ a, b }, "x"); run(w, 1)
    check("two records of one cover both filled", a._cover_filled and b._cover_filled)
    check("each record owns its own bb (cover_bb is one-shot)", a.cover_bb ~= b.cover_bb and w.decoded == 2, w.decoded)
end
do
    W = newWorld(); local w = W
    local M = loadSource(w)
    M.onCoversReady(function(sid, final) w.events[#w.events + 1] = tostring(final) end)
    w.bad_decode = true
    local recs = mkrecs(1)
    w.files[path(1, 1)] = true
    M.scheduleCoverFills(recs, "x"); run(w, 0.1)
    run(w, 5)
    check("undecodable file: not filled, no landed event", filled(recs) == 0 and #w.events == 0)
end

-- 11. stale .part sweep, once per session -------------------------------------------------------------
do
    W = newWorld({ dir_listing = { "12_2026.jpg", "13_2026.jpg.part", "a5_1.jpg.part", "readme.txt" } }); local w = W
    local removed = {}
    local real_remove = os.remove
    os.remove = function(p) removed[#removed + 1] = p; return true end
    local M = loadSource(w)
    M.onCoversReady(function() end)
    M.scheduleCoverFills(mkrecs(1), "x"); run(w, 0.1)
    local n_part, n_jpg = 0, 0
    for _, p in ipairs(removed) do
        if p:match("%.jpg%.part$") then n_part = n_part + 1 end
        if p == DIR .. "/12_2026.jpg" then n_jpg = n_jpg + 1 end
    end
    check("stale .part files swept (2)", n_part >= 2, n_part)
    check("a finished .jpg is never swept", n_jpg == 0)
    local before = #removed
    M.scheduleCoverFills(mkrecs(2), "x"); run(w, 0.2)
    local again = 0
    for i = before + 1, #removed do
        if removed[i] == DIR .. "/13_2026.jpg.part" then again = again + 1 end
    end
    check("sweep runs once per session", again == 0, again)
    os.remove = real_remove
end

-- 12. the widget closes the pool (static) ------------------------------------------------------------------
do
    local fh = io.open(PLUGIN .. "/lib/bookshelf_widget.lua", "rb")
    local src = fh and fh:read("*a") or ""
    if fh then fh:close() end
    local a = src:find("function BookshelfWidget:onCloseWidget%(%)")
    local b = a and src:find("shutdownCoverPool", a, true)
    check("onCloseWidget calls shutdownCoverPool", a and b and (b - a) < 2500, a and b and (b - a))
end


-- 13. per-worker timing log (C22) ---------------------------------------------------------------------------
do
    W = newWorld(); local w = W
    local M = loadSource(w)
    M.onCoversReady(function() end)
    local recs = mkrecs(3)
    M.scheduleCoverFills(recs, "t")
    run(w, 0.1)
    check("3 workers for the timing check", #w.forks == 3, #w.forks)
    run(w, 0.5)
    w.download = function(id, final) if id == 2 then return nil, "http_404" end return true end
    finishFork(w, w.forks[1], 1)
    finishFork(w, w.forks[2], nil)
    run(w, 0.4)   -- the poll collects both
    -- fork 3 is never finished: the 25 s deadline kills it
    run(w, 30)
    local function workerLines()
        local out = {}
        for _, l in ipairs(w.logs) do
            if l:find("[bookshelf perf] bo cover worker:", 1, true) then out[#out + 1] = l end
        end
        return out
    end
    local lines = workerLines()
    local ok_l, nf_l, to_l
    for _, l in ipairs(lines) do
        if l:find("result=ok", 1, true) then ok_l = l end
        if l:find("result=nf:http_404", 1, true) then nf_l = l end
        if l:find("result=timeout", 1, true) then to_l = l end
    end
    check("worker line for an ok result", ok_l ~= nil, #lines)
    check("worker line for an nf: result", nf_l ~= nil)
    check("worker line for a timeout", to_l ~= nil)
    check("worker line carries key and ms", ok_l and ok_l:match("key=%S+ ms=%d+ result=") ~= nil, ok_l)
    local ms = to_l and tonumber(to_l:match("ms=(%d+)"))
    check("timeout ms is about the 25 s deadline", ms and ms >= 25000 and ms < 27000, ms)
    check("one worker line per finished worker (3)", #lines == 3, #lines)
end


-- ===========================================================================
-- Batch 6 (phase 2): async page-list fetch through the REAL source file.
-- Fork / HTTP / rapidjson / Cache are fakes; the page files are REAL files in
-- a temp dir so the child's write + rename and the parent's read + cleanup are
-- exercised for real. NOT run on a device.
-- ===========================================================================
local PROOT = "/tmp/bo_pagefetch_test"
local ID = "libraries:1"
local KEY0 = "page:" .. ID .. ":0:12"
local function sh(c) os.execute(c) end

local function newPageWorld(opts)
    opts = opts or {}
    sh("rm -rf " .. PROOT .. " && mkdir -p " .. PROOT)
    local w = newWorld(opts)
    local PAGES = PROOT .. "/bookshelf_bookorbit_pages"
    w.pages_dir = PAGES
    if opts.leftovers then
        sh("mkdir -p " .. PAGES)
        for _, n in ipairs(opts.leftovers) do
            local f = io.open(PAGES .. "/" .. n, "wb"); f:write("stale"); f:close()
        end
    end
    w.stubs["datastorage"] = { getSettingsDir = function() return PROOT end }
    w.stubs["util"] = { makePath = function(p) sh('mkdir -p "' .. p .. '"'); return true end }
    w.stubs["libs/libkoreader-lfs"] = {
        attributes = function(p, m)
            if p == PAGES then
                local f = io.open(PAGES .. "/.", "rb")
                if f then f:close(); return m == "mode" and "directory" or 1 end
                return nil
            end
            if p:sub(1, #PROOT) == PROOT then
                local f = io.open(p, "rb")
                if f then f:close(); return m == "mode" and "file" or 1 end
            end
        end,
        dir = function(d)
            local names = {}
            local ph = io.popen('ls -A "' .. d .. '" 2>/dev/null')
            if ph then for l in ph:lines() do names[#names + 1] = l end ph:close() end
            local i = 0
            return function() i = i + 1; return names[i] end
        end,
    }
    -- fake Cache: RAM only, records the version checks
    w.cache = { store = {}, version_calls = {} }
    w.stubs["lib/bookshelf_bookorbit_cache"] = {
        get = function(k) return w.cache.store[k] end,
        set = function(k, v) w.cache.store[k] = v end,
        invalidate = function(k) w.cache.store[k] = nil end,
        invalidatePrefix = function(pre)
            for k in pairs(w.cache.store) do if k:sub(1, #pre) == pre then w.cache.store[k] = nil end end
        end,
        invalidateAll = function() w.cache.store = {} end,
        checkVersionAndInvalidate = function(v) w.cache.version_calls[#w.cache.version_calls + 1] = v end,
        flush = function() end,
    }
    -- fake rapidjson: encode returns a handle string, decode resolves it
    local reg = {}
    w.stubs["rapidjson"] = {
        encode = function(t) reg[#reg + 1] = t; return "JSON#" .. #reg end,
        decode = function(str)
            local i = tonumber(tostring(str):match("^JSON#(%d+)$"))
            if not i then error("bad json") end
            return reg[i]
        end,
        null = {},
    }
    -- not inside a Trapper coroutine: the blocking path runs inline
    w.stubs["ui/trapper"] = { isWrapped = function() return false end }
    w.catalog_calls = 0
    w.catalog_result = function(q)
        return { items = { { id = 1, title = "A" }, { id = 2, title = "B" } }, total = 30, hasNext = true }
    end
    w.BO.catalogBooks = function(q)
        w.catalog_calls = w.catalog_calls + 1
        w.last_query = q
        return w.catalog_result(q)
    end
    w.BO.getLibraryVersion = function() return "v7" end
    w.BO.isConfigured = function() return true end
    return w
end

-- the "child": run every launched worker's payload in-process, then mark exited
local function finishAll(w)
    for _, f in ipairs(w.forks) do
        if not f.done and not f.killed then f.payload(f.pid, f.pid); f.done = true end
    end
end
local function pageLines(w, needle)
    local out = {}
    for _, l in ipairs(w.logs) do
        if l:find("[bookshelf perf] bo page:", 1, true) and (not needle or l:find(needle, 1, true)) then
            out[#out + 1] = l
        end
    end
    return out
end
local function newReady(M)
    local ready = {}
    M.onPageReady(function(key, req, ok, why, urgent)
        ready[#ready + 1] = { key = key, req = req, ok = ok, why = why, urgent = urgent }
    end)
    return ready
end

-- 6.1 miss -> pending page + forks, then ready -> cache hit ----------------------------------------
do
    local w = newPageWorld(); local M = loadSource(w)
    check("6: onPageReady / shutdownPageFetch exported",
        type(M.onPageReady) == "function" and type(M.shutdownPageFetch) == "function")
    local ready = newReady(M)
    local page, total = M.listBooks(ID, 0, 12, { async_page = true })
    check("6.1 async miss returns a pending page", type(page) == "table" and page.bo_pending ~= nil)
    check("6.1 pending page has no books", #page == 0)
    check("6.1 pending key is the page cache key", page.bo_pending and page.bo_pending.key == KEY0, page.bo_pending and page.bo_pending.key)
    check("6.1 pending carries id/offset/limit",
        page.bo_pending and page.bo_pending.id == ID and page.bo_pending.offset == 0 and page.bo_pending.limit == 12)
    check("6.1 pending total with no known total = offset + limit", total == 12, total)
    check("6.1 no HTTP on the calling thread", w.catalog_calls == 0)
    check("6.1 no fork is started inside listBooks (timer launches it)", #w.forks == 0)
    run(w, 0.05)
    check("6.1 page worker + version worker launched (width 2)", #w.forks == 2, #w.forks)
    finishAll(w)
    check("6.1 the child made the catalog request once", w.catalog_calls == 1, w.catalog_calls)
    check("6.1 child asked for page 1, size 12",
        w.last_query and w.last_query.page == 1 and w.last_query.size == 12 and w.last_query.libraryId == "1")
    run(w, 1)
    check("6.1 on_ready fired once (the version job is not reported)", #ready == 1, #ready)
    check("6.1 on_ready: ok, urgent, right key", ready[1] and ready[1].ok == true and ready[1].urgent == true and ready[1].key == KEY0)
    check("6.1 page landed in the cache", w.cache.store[KEY0] ~= nil and #w.cache.store[KEY0].records == 2)
    check("6.1 cached total is the server's", w.cache.store[KEY0] and w.cache.store[KEY0].total == 30)
    check("6.1 version job fed Cache.checkVersionAndInvalidate", w.cache.version_calls[1] == "v7", w.cache.version_calls[1])
    local nforks = #w.forks
    local recs, tot = M.listBooks(ID, 0, 12, { async_page = true })
    check("6.1 next call is an instant cache hit (records, real total)", #recs == 2 and tot == 30 and recs.bo_pending == nil)
    check("6.1 cache hit starts no fork", #w.forks == nforks)
    local ls = io.popen('ls "' .. w.pages_dir .. '" 2>/dev/null'):read("*a")
    check("6.1 body and part files are cleaned up", ls == "", ls)
    local l = pageLines(w, "result=ok")
    check("6.1 perf line for the page worker", #l >= 1 and l[1]:match("key=%S+ ms=%d+ result=ok") ~= nil, l[1])
    -- a second page: total rule uses the last real total
    local p2, t2 = M.listBooks(ID, 12, 12, { async_page = true })
    check("6.1 pending total = max(last real total, offset+limit)", p2.bo_pending and t2 == 30, t2)
    local p3, t3 = M.listBooks(ID, 36, 12, { async_page = true })
    check("6.1 ... and offset+limit when that is larger", p3.bo_pending and t3 == 48, t3)
    run(w, 0.05); finishAll(w); run(w, 1)
    check("6.1 page 2 asked the server for page 2", w.last_query and w.last_query.page == 2 or w.last_query.page == 4, w.last_query and w.last_query.page)
end

-- 6.1b the loader alone records the real total (no cache-hit call in between) --------------------
do
    local w = newPageWorld(); local M = loadSource(w)
    newReady(M)
    M.listBooks(ID, 0, 12, { async_page = true })
    run(w, 0.05); finishAll(w); run(w, 1)
    local p2, t2 = M.listBooks(ID, 12, 12, { async_page = true })
    check("6.1b a landed page sets the real total used by the next pending page", p2.bo_pending ~= nil and t2 == 30, t2)
end

-- 6.2 join + preload ----------------------------------------------------------------------------
do
    local w = newPageWorld(); local M = loadSource(w)
    local ready = newReady(M)
    local pg = M.listBooks(ID, 0, 12, { async_page = true, preload = true })
    check("6.2 a preload miss also answers pending", pg.bo_pending ~= nil)
    local pg2 = M.listBooks(ID, 0, 12, { async_page = true })
    check("6.2 a render request for the same key joins (still pending)", pg2.bo_pending ~= nil)
    run(w, 0.05)
    check("6.2 one page worker for both requests (+ the version worker)", #w.forks == 2, #w.forks)
    finishAll(w); run(w, 1)
    check("6.2 one ready event, upgraded to urgent by the render request",
        #ready == 1 and ready[1].urgent == true, #ready)
    -- a pure preload reports urgent = false
    local pg3 = M.listBooks(ID, 12, 12, { async_page = true, preload = true })
    check("6.2 pure preload pending", pg3.bo_pending ~= nil)
    run(w, 0.05); finishAll(w); run(w, 1)
    check("6.2 pure preload ready is not urgent", #ready == 2 and ready[2].urgent == false and ready[2].key == "page:" .. ID .. ":12:12", ready[2] and tostring(ready[2].urgent))
end

-- 6.3 failures ------------------------------------------------------------------------------------
do
    local w = newPageWorld(); local M = loadSource(w)
    local ready = newReady(M)
    w.catalog_result = function() return nil, 404 end
    M.listBooks(ID, 0, 12, { async_page = true })
    run(w, 0.05); finishAll(w); run(w, 1)
    check("6.3 a server 'no' reports ok=false", #ready == 1 and ready[1].ok == false, #ready)
    check("6.3 nothing cached for a failed page", w.cache.store[KEY0] == nil)
    local pf, tf = M.listBooks(ID, 0, 12, { async_page = true })
    check("6.3 the next request answers failed (no retry loop)", pf.bo_failed ~= nil and pf.bo_pending == nil, pf.bo_failed)
    check("6.3 failed page carries the same total rule", tf == 12, tf)
    local nforks = #w.forks
    run(w, 1)
    check("6.3 no new fork while failed", #w.forks == nforks)
    M.clearThumbFailures()
    local pr = M.listBooks(ID, 0, 12, { async_page = true })
    check("6.3 clearThumbFailures (manual refresh) lets the page retry", pr.bo_pending ~= nil)
    -- invalidateNextPageCache also resets the failure
    w.catalog_result = function() return nil, 500 end
    run(w, 0.05); finishAll(w); run(w, 1)
    local pf2 = M.listBooks(ID, 0, 12, { async_page = true })
    check("6.3 failed again", pf2.bo_failed ~= nil)
    M.invalidateNextPageCache(ID)
    local pr2 = M.listBooks(ID, 0, 12, { async_page = true })
    check("6.3 invalidateNextPageCache resets the failure", pr2.bo_pending ~= nil)
end

-- 6.4 fallbacks to today's blocking path -------------------------------------------------------
do
    local w = newPageWorld({ no_fork = true }); local M = loadSource(w)
    local recs, tot = M.listBooks(ID, 0, 12, { async_page = true })
    check("6.4 no runInSubProcess -> blocking fetch, real records", #recs == 2 and tot == 30 and recs.bo_pending == nil)
    check("6.4 ... which made the request inline", w.catalog_calls == 1)
end
do
    local w = newPageWorld(); local M = loadSource(w)
    local recs = M.listBooks(ID, 0, 12)
    check("6.4 no async flag -> blocking, no pending, no fork", #recs == 2 and recs.bo_pending == nil and #w.forks == 0 and w.catalog_calls == 1)
end
do
    local w = newPageWorld(); local M = loadSource(w)
    w.online = false
    local recs, tot = M.listBooks(ID, 0, 12, { async_page = true })
    check("6.4 offline miss: today's empty page, not pending", #recs == 0 and recs.bo_pending == nil and tot == 0, tot)
    run(w, 0.5)
    check("6.4 offline: nothing launched", #w.forks == 0)
end
do
    local w = newPageWorld(); local M = loadSource(w)
    local ready = newReady(M)
    w.fork_fails = true
    local pg = M.listBooks(ID, 0, 12, { async_page = true })
    check("6.4 a broken fork is only noticed at launch: first answer pending", pg.bo_pending ~= nil)
    run(w, 0.5)
    check("6.4 fork_broken is reported to the widget", #ready >= 1 and ready[1].ok == false and ready[1].why == "fork_broken", ready[1] and tostring(ready[1].why))
    local recs = M.listBooks(ID, 0, 12, { async_page = true })
    check("6.4 after fork_broken the blocking path serves the page", #recs == 2 and recs.bo_pending == nil and w.catalog_calls == 1)
end

-- 6.5 shutdown + sweep -------------------------------------------------------------------------------
do
    local w = newPageWorld(); local M = loadSource(w)
    local ready = newReady(M)
    M.listBooks(ID, 0, 12, { async_page = true })
    run(w, 0.05)
    check("6.5 workers are running", #w.forks == 2)
    M.shutdownPageFetch()
    local killed = 0
    for _, f in ipairs(w.forks) do if f.killed then killed = killed + 1 end end
    check("6.5 shutdownPageFetch kills every worker", killed == 2, killed)
    run(w, 3)
    check("6.5 no callback after shutdown", #ready == 0, #ready)
end
do
    local w = newPageWorld({ leftovers = { "page_deadbeef_5.json", "page_deadbeef_5.json.part", "keep_me.txt" } })
    local M = loadSource(w)
    M.listBooks(ID, 0, 12, { async_page = true })
    local ls = io.popen('ls "' .. w.pages_dir .. '"'):read("*a")
    check("6.5 stale page/part files swept when the fetcher is built", not ls:find("deadbeef", 1, true), ls)
    check("6.5 unrelated files are left alone", ls:find("keep_me.txt", 1, true) ~= nil, ls)
end

-- 6.6 static wiring of the repo and widget (parse-checked only) ----------------------------------------
do
    local function slurp(p) local f = assert(io.open(PLUGIN .. "/" .. p, "rb")); local t = f:read("*a"); f:close(); return t end
    local repo, widget = slurp("lib/bookshelf_book_repository.lua"), slurp("lib/bookshelf_widget.lua")
    check("6.6 repo passes opts to listBooks", repo:find("BOSource.listBooks(source.id, off, lim, opts)", 1, true) ~= nil)
    check("6.6 repo returns a pending/failed page before scheduleCoverFills",
        (repo:find("page.bo_pending or page.bo_failed", 1, true) or 1e9) < (repo:find("BOSource.scheduleCoverFills(page, source.id)", 1, true) or 0))
    check("6.6 widget: render path asks for async", select(2, widget:gsub('_fetchChipItems%(MAX_FETCH, nil, "render"%)', "")) == 2)
    check("6.6 widget: preload asks for async + preload", widget:find('_fetchChipItems, self, 400, false, preload_mode', 1, true) ~= nil)
    check("6.6 widget: the other callers stay blocking",
        widget:find("self:_fetchChipItems(400)", 1, true) ~= nil
        and widget:find("self:_fetchChipItems(SPINE_ALL_LIMIT, true)", 1, true) ~= nil
        and widget:find("self:_fetchChipItems(SELECT_ALL_LIMIT, true)", 1, true) ~= nil)
    check("6.6 widget: page-ready callback registered", widget:find("BOSource_init.onPageReady(", 1, true) ~= nil)
    check("6.6 widget: teardown shuts the page fetcher down", widget:find("BOSource.shutdownPageFetch", 1, true) ~= nil)
    check("6.6 widget: preload skips pending pages", widget:find("items.bo_pending or items.bo_failed", 1, true) ~= nil)
    check("6.6 widget: pending page is not the empty state", widget:find("not (type(all_items) == \"table\" and all_items.bo_pending)", 1, true) ~= nil)
end

-- 7. next-page prefetch wiring (P2): the REAL source, fake forks/clock/cache --------------------------------
-- (behavioural smoke; the full scenario list is Batch P3)
do
    local COVERS = PROOT .. "/bookshelf_bookorbit_covers"
    local function prefetchWorld(opts)
        local w = newPageWorld(opts)
        -- A cover worker leaves a real file at its final path (like the real child).
        w.download = function(id, final)
            local f = io.open(final, "wb"); if f then f:write("jpeg"); f:close() end
            return true
        end
        w.page_forks = 0
        return w
    end
    local function pageKey(off, lim) return "page:" .. ID .. ":" .. off .. ":" .. lim end
    local function settle(w, M, rounds)
        for _ = 1, rounds or 6 do run(w, 1.2); finishAll(w) end
        run(w, 1.2)
    end
    local function logged(w, needle)
        for _, l in ipairs(w.logs) do if l:find(needle, 1, true) then return true end end
        return false
    end

    -- 7.1 settled visible page -> list through the fetcher (non-blocking), covers download-only ------------------
    do
        local w = prefetchWorld(); local M = loadSource(w)
        newReady(M)
        M.listBooks(ID, 0, 12, { async_page = true })
        run(w, 0.05); finishAll(w); run(w, 1)
        check("7.1 visible page cached", w.cache.store[pageKey(0, 12)] ~= nil)
        local calls0, forks0 = w.catalog_calls, #w.forks
        M.prefetchNextPage(ID, 12, 12)
        check("7.1 prefetchNextPage starts nothing inside the call", #w.forks == forks0 and w.catalog_calls == calls0)
        run(w, 0.9)
        check("7.1 nothing before the settle delay", #w.forks == forks0)
        run(w, 0.3)
        check("7.1 list requested through the fetcher (one fork)", #w.forks == forks0 + 1, #w.forks - forks0)
        check("7.1 no blocking catalogBooks call on the UI thread", w.catalog_calls == calls0, w.catalog_calls - calls0)
        finishAll(w)
        check("7.1 the child made exactly one catalog request", w.catalog_calls == calls0 + 1)
        run(w, 0.6)
        check("7.1 next page landed in the cache", w.cache.store[pageKey(12, 12)] ~= nil)
        settle(w, M, 4)
        local rec = w.cache.store[pageKey(12, 12)].records
        local ls = io.popen('ls "' .. COVERS .. '" 2>/dev/null'):read("*a")
        local njpg = select(2, ls:gsub("%.jpg\n", ""))
        check("7.1 prefetch downloaded both covers to disk (and left no .part)", #rec == 2 and njpg == 2 and not ls:find("%.part"), ls)
        local all_bb, all_filled = #rec > 0, #rec > 0
        for _, r in ipairs(rec) do
            if r.cover_bb == nil then all_bb = false end
            if not r._cover_filled then all_filled = false end
        end
        check("7.1 decoded ahead: every cached record carries cover_bb AND _cover_filled", all_bb and all_filled)
        check("7.1 exactly one decode per record (2)", w.decoded == 2, w.decoded)
        check("7.1 decode-ahead summary logged", logged(w, "bo prefetch: decode-ahead n=2"))
        check("7.1 covers queued log", logged(w, "bo prefetch: covers queued n=2"))
        local nforks = #w.forks
        M.prefetchNextPage(ID, 12, 12)
        for _ = 1, 3 do run(w, 1.5); finishAll(w) end
        check("7.1 re-arming the same page (cascading rebuilds) is a no-op", #w.forks == nforks, #w.forks - nforks)
    end

    -- 7.2 nothing starts while the visible page's main cover chain runs ---------------------------------------
    do
        local w = prefetchWorld(); local M = loadSource(w)
        newReady(M)
        M.onCoversReady(function() end)
        M.listBooks(ID, 0, 12, { async_page = true })
        run(w, 0.05); finishAll(w); run(w, 1)
        local vis = w.cache.store[pageKey(0, 12)].records
        M.scheduleCoverFills(vis, ID); run(w, 0.1)
        local forks_after_covers = #w.forks
        M.prefetchNextPage(ID, 12, 12)
        run(w, 6)
        check("7.2 visible covers in flight: prefetch does not start", #w.forks == forks_after_covers, #w.forks - forks_after_covers)
        finishAll(w); run(w, 0.5)
        run(w, 0.3)
        check("7.2 chain drained: still inside the quiet delay, nothing yet", #w.forks == forks_after_covers, #w.forks - forks_after_covers)
        run(w, 2)
        check("7.2 after the chain drained and the quiet delay: the list is requested", #w.forks == forks_after_covers + 1, #w.forks - forks_after_covers)
    end

    -- 7.3 a visible chain starting yields: timer dropped, in-flight download killed, re-armed when idle --------
    do
        local w = prefetchWorld(); local M = loadSource(w)
        newReady(M)
        M.onCoversReady(function() end)
        M.listBooks(ID, 0, 12, { async_page = true })
        run(w, 0.05); finishAll(w); run(w, 1)
        -- next page already cached: straight to covers
        w.cache.store[pageKey(12, 12)] = { records = { { remote_id = 41, updated_at = "2026-01-01" }, { remote_id = 42, updated_at = "2026-01-02" } }, total = 30 }
        M.prefetchNextPage(ID, 12, 12)
        run(w, 1.2)
        local pf_forks = #w.forks
        check("7.3 one prefetch cover worker (width 1)", pf_forks >= 1)
        local inflight = w.forks[#w.forks]
        local vis = { { remote_id = 7, updated_at = "2026-01-07" } }
        M.scheduleCoverFills(vis, ID)
        check("7.3 a visible chain kills the in-flight prefetch download", inflight.killed == true)
        run(w, 0.5); finishAll(w); run(w, 3)
    end

    -- 7.4 offline: nothing starts ------------------------------------------------------------------------------
    do
        local w = prefetchWorld(); local M = loadSource(w)
        newReady(M)
        M.listBooks(ID, 0, 12, { async_page = true })
        run(w, 0.05); finishAll(w); run(w, 1)
        w.online = false
        local forks0 = #w.forks
        M.prefetchNextPage(ID, 12, 12)
        run(w, 5); finishAll(w); run(w, 2)
        check("7.4 offline: no fork, no request", #w.forks == forks0)
        w.online = true
        M.prefetchNextPage(ID, 12, 12)
        run(w, 1.3)
        check("7.4 back online: it can arm again", #w.forks == forks0 + 1, #w.forks - forks0)
    end

    -- 7.5 a page the user turns to takes over (urgent join): the prefetch drops it ------------------------------
    do
        local w = prefetchWorld(); local M = loadSource(w)
        local ready = newReady(M)
        M.listBooks(ID, 0, 12, { async_page = true })
        run(w, 0.05); finishAll(w); run(w, 1)
        M.prefetchNextPage(ID, 12, 12)
        run(w, 1.2)                                     -- list job queued (non-urgent)
        local before = #w.forks
        local p = M.listBooks(ID, 12, 12, { async_page = true })   -- the user turns to it
        check("7.5 turning to it joins the running job", p.bo_pending ~= nil and #w.forks == before)
        finishAll(w); run(w, 1)
        check("7.5 the page landed urgent", ready[#ready] and ready[#ready].urgent == true and ready[#ready].ok == true)
        local nf = #w.forks
        run(w, 5); finishAll(w); run(w, 2)
        check("7.5 no prefetch covers for the page that is now visible", #w.forks == nf, #w.forks - nf)
        check("7.5 dropped as visible", logged(w, "dropped reason=visible"))
    end

    -- 7.6 inline fallback: a running inline fill blocks it; a superseded one does not (R-P2) ----------------------
    do
        local w = prefetchWorld({ no_fork = true }); local M = loadSource(w)
        w.cache.store[pageKey(0, 12)] = { records = {}, total = 30 }
        w.cache.store[pageKey(12, 12)] = { records = { { remote_id = 51, updated_at = "2026-01-01" } }, total = 30 }
        local big = {}
        for i = 1, 300 do big[i] = { remote_id = 1000 + i, updated_at = "2026-01-01" } end
        M.scheduleCoverFills(big, ID)          -- inline loop, ~3 s of ticks
        M.prefetchNextPage(ID, 12, 12)
        run(w, 1.6)
        check("7.6 inline fill running: prefetch waits", logged(w, "bo prefetch: not settled, waiting"))
        check("7.6 ... and has not queued anything", not logged(w, "bo prefetch: covers queued"))
        run(w, 6)
        check("7.6 inline fill ended: the prefetch ran (notify at the end)", logged(w, "bo prefetch: covers queued n=1"))
        local w2 = prefetchWorld({ no_fork = true }); local M2 = loadSource(w2)
        w2.cache.store[pageKey(12, 12)] = { records = { { remote_id = 51, updated_at = "2026-01-01" } }, total = 30 }
        local big2 = {}
        for i = 1, 300 do big2[i] = { remote_id = 2000 + i, updated_at = "2026-01-01" } end
        M2.scheduleCoverFills(big2, ID)
        M2.cancelThumbnailJobs()               -- the fill is superseded: its loop just stops
        M2.prefetchNextPage(ID, 12, 12)
        run(w2, 1.5)
        check("7.6 a superseded inline fill never blocks the prefetch", logged(w2, "bo prefetch: covers queued n=1"))
    end

    -- 7.7 shutdown: no timers, no leftover workers ------------------------------------------------------------
    do
        local w = prefetchWorld(); local M = loadSource(w)
        newReady(M)
        M.listBooks(ID, 0, 12, { async_page = true })
        run(w, 0.05); finishAll(w); run(w, 1)
        w.cache.store[pageKey(12, 12)] = { records = { { remote_id = 61, updated_at = "2026-01-01" }, { remote_id = 62, updated_at = "2026-01-02" } }, total = 30 }
        M.prefetchNextPage(ID, 12, 12)
        run(w, 1.2)
        local n = #w.forks
        M.shutdownCoverPool(); M.shutdownPageFetch()
        local live = 0
        for _, f in ipairs(w.forks) do if not f.killed and not f.done then live = live + 1 end end
        check("7.7 shutdown kills the prefetch worker", live == 0, live)
        run(w, 10)
        check("7.7 nothing starts after shutdown", #w.forks == n)
    end

    -- 7.8 a failed next list: one attempt, no retry storm, nothing cached -----------------------------------
    do
        local w = prefetchWorld(); local M = loadSource(w)
        newReady(M)
        M.listBooks(ID, 0, 12, { async_page = true })
        run(w, 0.05); finishAll(w); run(w, 1)
        w.catalog_result = function() return nil, 404 end
        local forks0 = #w.forks
        M.prefetchNextPage(ID, 12, 12); run(w, 1.3)
        check("7.8 one list request", #w.forks == forks0 + 1, #w.forks - forks0)
        finishAll(w); run(w, 1)
        check("7.8 nothing cached for the failed page", w.cache.store[pageKey(12, 12)] == nil)
        check("7.8 dropped (logged)", logged(w, "bo prefetch: dropped reason="))
        for _ = 1, 5 do M.prefetchNextPage(ID, 12, 12); run(w, 12); finishAll(w) end
        check("7.8 no retry storm from cascading re-arms", #w.forks == forks0 + 1, #w.forks - forks0)
        -- 7.8b a manual refresh forgets it: the page can be prefetched again
        w.catalog_result = function() return { items = { { id = 1, title = "A" } }, total = 30, hasNext = true } end
        M.invalidateNextPageCache(ID)
        M.prefetchNextPage(ID, 12, 12); run(w, 1.3)
        check("7.8b manual refresh: prefetch can arm again", #w.forks == forks0 + 2, #w.forks - forks0)
    end

    -- 7.9 manual refresh forgets already-prefetched keys -----------------------------------------------------
    do
        local w = prefetchWorld(); local M = loadSource(w)
        newReady(M)
        M.listBooks(ID, 0, 12, { async_page = true })
        run(w, 0.05); finishAll(w); run(w, 1)
        M.prefetchNextPage(ID, 12, 12)
        settle(w, M, 5)
        local nf = #w.forks
        M.prefetchNextPage(ID, 12, 12); settle(w, M, 3)
        check("7.9 done key: no second prefetch", #w.forks == nf, #w.forks - nf)
        M.invalidateNextPageCache(ID)
        check("7.9 refresh dropped the cached next page", w.cache.store[pageKey(12, 12)] == nil)
        M.prefetchNextPage(ID, 12, 12); run(w, 1.3)
        check("7.9 after the refresh the key prefetches again", #w.forks == nf + 1, #w.forks - nf)
    end

    -- 7.10 an urgent page job (someone waiting) holds the prefetch back ------------------------------------------
    do
        local w = prefetchWorld(); local M = loadSource(w)
        newReady(M)
        M.listBooks(ID, 0, 12, { async_page = true })
        run(w, 0.05); finishAll(w); run(w, 1)
        local p = M.listBooks(ID, 24, 12, { async_page = true })      -- the user turns two pages: urgent, in flight
        check("7.10 setup: urgent job pending", p.bo_pending ~= nil)
        run(w, 0.1)                                                    -- its worker is launched
        local forks0 = #w.forks
        M.prefetchNextPage(ID, 12, 12)
        run(w, 6)
        check("7.10 urgent job in flight: no prefetch fork", #w.forks == forks0, #w.forks - forks0)
        finishAll(w); run(w, 0.3)
        run(w, 1.5)
        check("7.10 urgent job done + quiet delay: prefetch list requested", #w.forks == forks0 + 1, #w.forks - forks0)
    end

    -- 7.11 cover failures: definitive blacklists for the visible page, transient does not --------------------------
    do
        local w = prefetchWorld(); local M = loadSource(w)
        newReady(M)
        M.listBooks(ID, 0, 12, { async_page = true })
        run(w, 0.05); finishAll(w); run(w, 1)
        local r71 = { remote_id = 71, updated_at = "2026-01-01" }
        local r72 = { remote_id = 72, updated_at = "2026-01-01" }
        w.cache.store[pageKey(12, 12)] = { records = { r71, r72 }, total = 30 }
        w.download = function(id)
            if tostring(id) == "71" then return nil, "http_404" end
            return nil, "timeout"
        end
        M.prefetchNextPage(ID, 12, 12)
        run(w, 1.3)
        for _ = 1, 6 do finishAll(w); run(w, 1.5) end
        local nf = #w.forks
        M.scheduleCoverFills({ { remote_id = 71, updated_at = "2026-01-01" } }, ID); run(w, 0.2)
        check("7.11 definitive failure (404) is blacklisted for the visible page", #w.forks == nf, #w.forks - nf)
        M.scheduleCoverFills({ { remote_id = 72, updated_at = "2026-01-01" } }, ID); run(w, 0.2)
        check("7.11 transient failure (timeout) is NOT blacklisted: the page turn retries", #w.forks == nf + 1, #w.forks - nf)
        finishAll(w); run(w, 3)
    end

    -- 7.12 clearThumbFailures also resets the prefetch pool's give-up list -------------------------------------
    do
        local w = prefetchWorld(); local M = loadSource(w)
        newReady(M)
        M.listBooks(ID, 0, 12, { async_page = true })
        run(w, 0.05); finishAll(w); run(w, 1)
        local function seed()
            w.cache.store[pageKey(12, 12)] = { records = { { remote_id = 73, updated_at = "2026-01-01" } }, total = 30 }
        end
        seed()
        w.download = function() return nil, "http_404" end
        M.prefetchNextPage(ID, 12, 12); run(w, 1.3)
        for _ = 1, 4 do finishAll(w); run(w, 1.5) end
        local nf = #w.forks
        -- the prefetch pool gave up on cover 73; a refresh must bring it back
        w.download = function(id, final)
            local f = io.open(final, "wb"); if f then f:write("jpeg"); f:close() end
            return true
        end
        M.clearThumbFailures()
        M.invalidateNextPageCache(ID)      -- also forgets the prefetch intent / done key
        seed()
        M.prefetchNextPage(ID, 12, 12); run(w, 1.3)
        check("7.12 after clearThumbFailures the prefetch pool downloads the cover again", #w.forks == nf + 1, #w.forks - nf)
    end

    -- =====================================================================================================
    -- D3: decode-ahead behaviour (the REAL source; fake fork / clock / cache / RenderImage). Not run on a device.
    -- Records: ids base+i, updated_at 2026-01-01 -> file COVERS/<id>_20260101.jpg
    -- =====================================================================================================
    local function cfile(id) return COVERS .. "/" .. id .. "_20260101.jpg" end
    local function touch(p)
        sh('mkdir -p "' .. COVERS .. '"')
        local f = io.open(p, "wb"); f:write("jpeg"); f:close()
    end
    local function exists(p) local f = io.open(p, "rb"); if f then f:close(); return true end return false end
    -- n records; `disk` = "all" | {[i]=true} | nil
    local function nrecs(base, n, disk)
        local r = {}
        for i = 1, n do
            r[i] = { remote_id = base + i, updated_at = "2026-01-01" }
            if disk == "all" or (type(disk) == "table" and disk[i]) then touch(cfile(base + i)) end
        end
        return r
    end
    local function visibleWorld()
        local w = prefetchWorld(); local M = loadSource(w)
        newReady(M)
        M.onCoversReady(function() end)
        M.listBooks(ID, 0, 12, { async_page = true })
        run(w, 0.05); finishAll(w); run(w, 1)
        return w, M
    end
    local function seed(w, off, recs) w.cache.store[pageKey(off, 12)] = { records = recs, total = 30 } end
    local function count(w, needle)
        local n = 0
        for _, l in ipairs(w.logs) do if l:find(needle, 1, true) then n = n + 1 end end
        return n
    end
    -- (records carrying a bitmap, records flagged _cover_filled)
    local function tally(recs)
        local bb, fl = 0, 0
        for _, r in ipairs(recs) do
            if r.cover_bb ~= nil then bb = bb + 1 end
            if r._cover_filled then fl = fl + 1 end
        end
        return bb, fl
    end
    -- what SpineWidget does when it consumes a record's one-shot bitmap
    local function consume(r) r.cover_bb = nil end
    local function armAndRun(w, M, off, secs)
        M.prefetchNextPage(ID, off, 12)
        run(w, 1.2); run(w, secs or 2)
    end

    -- 7.15 next page fully on disk: decoded ahead, no download, one distinct bitmap per record -----------------
    do
        local w, M = visibleWorld()
        local recs = nrecs(100, 3, "all")
        seed(w, 12, recs)
        local forks0, dec0 = #w.forks, w.decoded
        armAndRun(w, M, 12)
        local bb, fl = tally(recs)
        check("7.15 disk hits: no download forked", #w.forks == forks0, #w.forks - forks0)
        check("7.15 every record carries a bitmap AND _cover_filled", bb == 3 and fl == 3, bb .. "/" .. fl)
        check("7.15 exactly one decode per record", w.decoded - dec0 == 3, w.decoded - dec0)
        check("7.15 has_cover, width and height attached", recs[1].has_cover == true and recs[1].cover_w == 10 and recs[1].cover_h == 20)
        check("7.15 bitmaps are never shared between records (one-shot)",
            recs[1].cover_bb ~= recs[2].cover_bb and recs[2].cover_bb ~= recs[3].cover_bb and recs[1].cover_bb ~= recs[3].cover_bb)
        check("7.15 disk hits are queued too (n=3)", logged(w, "bo prefetch: covers queued n=3"))
        check("7.15 summary logged once with n=3", count(w, "bo prefetch: decode-ahead n=3") == 1, count(w, "bo prefetch: decode-ahead n=3"))
        check("7.15 the cache holds the SAME record tables", w.cache.store[pageKey(12, 12)].records == recs)
        check("7.15 jpg files stay on disk", exists(cfile(101)) and exists(cfile(103)))
    end

    -- 7.16 mixed disk / miss: misses are downloaded, then decoded ---------------------------------------------
    do
        local w, M = visibleWorld()
        local recs = nrecs(110, 3, { true, true })
        seed(w, 12, recs)
        local forks0 = #w.forks
        M.prefetchNextPage(ID, 12, 12)
        run(w, 1.2); run(w, 0.5)
        check("7.16 exactly one download (the miss)", #w.forks == forks0 + 1, #w.forks - forks0)
        local bb0 = tally(recs)
        check("7.16 the two disk hits are decoded while the download runs", bb0 == 2, bb0)
        check("7.16 the missing one waits for its download", recs[3].cover_bb == nil and not recs[3]._cover_filled)
        finishAll(w); run(w, 1)
        local bb, fl = tally(recs)
        check("7.16 after the download all three are decoded", bb == 3 and fl == 3, bb .. "/" .. fl)
        check("7.16 three decodes in total (no double decode)", w.decoded == 3, w.decoded)
        check("7.16 summary logged with n=3", logged(w, "bo prefetch: decode-ahead n=3"))
        check("7.16 no .part left behind", not io.popen('ls -A "' .. COVERS .. '"'):read("*a"):find("%.part"))
    end

    -- 7.17 turning to a decoded-ahead page: the visible side has nothing to queue, the prefetch does NOT yield --
    do
        local w, M = visibleWorld()
        local recs = nrecs(120, 2, "all")
        seed(w, 12, recs); armAndRun(w, M, 12)
        check("7.17 setup: decoded ahead", select(1, tally(recs)) == 2)
        -- the page turn: arms the page after it, then the grid asks for cover fills of the turned-to page
        local nextnext = nrecs(130, 2, "all")
        seed(w, 24, nextnext)
        local forks0, dec0 = #w.forks, w.decoded
        M.prefetchNextPage(ID, 24, 12)
        M.scheduleCoverFills(recs, ID)
        for _, r in ipairs(recs) do consume(r) end   -- the turn paints synchronously: the widget takes the bitmaps
        run(w, 0.3)
        check("7.17 no fork for the turned-to page", #w.forks == forks0, #w.forks - forks0)
        check("7.17 no decode for the turned-to page", w.decoded == dec0, w.decoded - dec0)
        check("7.17 no visible cover chain (no perf line for a chain)", count(w, "[bookshelf perf] bo covers: n=") == 0)
        run(w, 1.2); run(w, 2)
        check("7.17 the prefetch of the page after it was NOT superseded (no yield)", logged(w, "bo prefetch: covers queued n=2"))
        check("7.17 ... and it decoded ahead", select(1, tally(nextnext)) == 2)
        local bbT, flT = tally(recs)
        check("7.17 the turned-to page is released only by the NEW step B, and consumed records keep their flag", bbT == 0 and flT == 2, bbT .. "/" .. flT)
    end

    -- 7.18 turn while the prefetch is still decoding: the visible pool finishes the rest, nothing decoded twice --
    do
        local w, M = visibleWorld()
        local recs = nrecs(140, 4, "all")
        seed(w, 12, recs)
        M.prefetchNextPage(ID, 12, 12)
        run(w, 1.0)
        local guard = 0
        while w.decoded < 2 and guard < 400 do run(w, 0.01); guard = guard + 1 end
        local dec_mid = w.decoded
        local bb_mid = tally(recs)
        check("7.18 setup: stopped part-way (2 of 4)", bb_mid >= 1 and bb_mid < 4, bb_mid)
        local kept = {}
        for i, r in ipairs(recs) do kept[i] = r.cover_bb end
        M.scheduleCoverFills(recs, ID)        -- the turn: a real chain for the visible page
        run(w, 2); finishAll(w); run(w, 1)
        local bb, fl = tally(recs)
        check("7.18 every record ends up filled", bb == 4 and fl == 4, bb .. "/" .. fl)
        check("7.18 each cover decoded exactly once (no double decode)", w.decoded == 4, w.decoded)
        local same = true
        for i = 1, bb_mid do if recs[i].cover_bb ~= kept[i] then same = false end end
        check("7.18 bitmaps decoded ahead are kept (not replaced)", same)
        check("7.18 the prefetch yielded (nothing queued after the turn)", count(w, "bo prefetch: decode-ahead n=4") == 0)
    end

    -- 7.19 a different page is armed: stale decode stops, release only at the NEW step B, consumed record untouched
    do
        local w, M = visibleWorld()
        local A = nrecs(150, 3, "all")
        seed(w, 12, A); armAndRun(w, M, 12)
        check("7.19 setup: page A decoded", select(1, tally(A)) == 3)
        consume(A[2])                          -- the widget consumed one of them
        local B = nrecs(160, 2, "all")
        seed(w, 24, B)
        M.prefetchNextPage(ID, 24, 12)         -- request time: runs inside the page turn
        local bbA, flA = tally(A)
        check("7.19 NOT released at request time (page-turn race)", bbA == 2 and flA == 3, bbA .. "/" .. flA)
        run(w, 0.5)
        check("7.19 still held inside the quiet delay", select(1, tally(A)) == 2)
        run(w, 0.8)                            -- step B of page B
        run(w, 2)
        local bbA2, flA2 = tally(A)
        check("7.19 page A released at the new step B (bitmap AND flag cleared together)",
            A[1].cover_bb == nil and not A[1]._cover_filled and A[3].cover_bb == nil and not A[3]._cover_filled, bbA2 .. "/" .. flA2)
        check("7.19 a record the widget already consumed is left alone (flag kept)", A[2].cover_bb == nil and A[2]._cover_filled == true)
        check("7.19 released n=2 reason=newpage logged", logged(w, "decode-ahead released n=2 reason=newpage"))
        check("7.19 page B decoded ahead", select(1, tally(B)) == 2)
    end

    -- 7.20 stale page: queued decodes stop when another page is armed (cancelDecode) --------------------------
    do
        local w, M = visibleWorld()
        local A = nrecs(170, 4, "all")
        seed(w, 12, A)
        M.prefetchNextPage(ID, 12, 12)
        run(w, 1.0)
        local guard = 0
        while w.decoded < 1 and guard < 400 do run(w, 0.01); guard = guard + 1 end
        local B = nrecs(180, 2, "all")
        seed(w, 24, B)
        M.prefetchNextPage(ID, 24, 12)         -- different key: cancel_covers
        local dec0 = w.decoded
        local bbA0 = tally(A)
        run(w, 0.5)                            -- before B's step B
        check("7.20 a started decode run stops at once for the stale page", w.decoded == dec0, w.decoded - dec0)
        check("7.20 the rest of page A stays undecoded", select(1, tally(A)) == bbA0 and bbA0 < 4, bbA0)
        run(w, 1); run(w, 2)
        check("7.20 page B is decoded afterwards", select(1, tally(B)) == 2)
    end

    -- 7.21 a stale in-flight download landing late is NOT decoded (file stays on disk) ----------------------------
    do
        local w, M = visibleWorld()
        local A = nrecs(190, 2, nil)           -- both missing: downloads
        seed(w, 12, A)
        M.prefetchNextPage(ID, 12, 12)
        run(w, 1.2); run(w, 0.1)
        local inflight = w.forks[#w.forks]
        check("7.21 setup: one download in flight (width 1)", inflight ~= nil and not inflight.done and not inflight.killed)
        local B = nrecs(200, 2, "all")
        seed(w, 24, B)
        M.prefetchNextPage(ID, 24, 12)
        run(w, 1.2)                            -- step B of page B: A is no longer the current page
        finishAll(w)                           -- the stale download lands now
        run(w, 2); finishAll(w); run(w, 1)
        check("7.21 stale download: no bitmap, no flag on its record", A[1].cover_bb == nil and not A[1]._cover_filled)
        check("7.21 stale download: the file stays on disk for a later visit", exists(cfile(191)))
        check("7.21 stale download is not a failure (no give-up logged)", not logged(w, "prefetch: giving up on book cover"))
        check("7.21 page B decoded ahead meanwhile", select(1, tally(B)) == 2)
    end

    -- 7.22 releases: invalidate and stop; the book is NOT left permanently blank --------------------------------
    do
        local w, M = visibleWorld()
        local recs = nrecs(210, 3, "all")
        seed(w, 12, recs); armAndRun(w, M, 12)
        consume(recs[3])
        M.invalidateNextPageCache(ID)
        check("7.22 invalidate releases the held bitmaps (flag cleared with them)",
            recs[1].cover_bb == nil and not recs[1]._cover_filled and recs[2].cover_bb == nil and not recs[2]._cover_filled)
        check("7.22 invalidate leaves the consumed record alone", recs[3]._cover_filled == true)
        check("7.22 released n=2 reason=invalidate logged", logged(w, "decode-ahead released n=2 reason=invalidate"))
        -- sharp edge: after a release the book is eligible again and a normal fill brings the cover back
        local dec0 = w.decoded
        M.scheduleCoverFills({ recs[1], recs[2] }, ID); run(w, 1.5); finishAll(w); run(w, 1)
        check("7.22 after a release the normal fill decodes the cover again", recs[1].cover_bb ~= nil and recs[2].cover_bb ~= nil and w.decoded - dec0 == 2, w.decoded - dec0)
    end
    do
        local w, M = visibleWorld()
        local recs = nrecs(220, 2, "all")
        seed(w, 12, recs); armAndRun(w, M, 12)
        M.shutdownCoverPool()
        check("7.22 shutdownCoverPool (prefetchStop) releases", select(1, tally(recs)) == 0 and select(2, tally(recs)) == 0)
        check("7.22 released n=2 reason=stop logged", logged(w, "decode-ahead released n=2 reason=stop"))
    end
    do
        local w, M = visibleWorld()
        local recs = nrecs(225, 2, "all")
        seed(w, 12, recs); armAndRun(w, M, 12)
        M.shutdownPageFetch()
        check("7.22 shutdownPageFetch releases", select(1, tally(recs)) == 0 and select(2, tally(recs)) == 0)
    end

    -- 7.23 a record somebody else already filled is never overwritten or dropped ---------------------------------
    do
        local w, M = visibleWorld()
        local recs = nrecs(230, 3, "all")
        local sentinel = { getWidth = function() return 1 end, getHeight = function() return 1 end }
        recs[2].cover_bb, recs[2]._cover_filled = sentinel, true
        seed(w, 12, recs)
        local dec0 = w.decoded
        armAndRun(w, M, 12)
        check("7.23 already filled: not decoded again", w.decoded - dec0 == 2, w.decoded - dec0)
        check("7.23 already filled: bitmap not overwritten", recs[2].cover_bb == sentinel)
        M.invalidateNextPageCache(ID)
        check("7.23 already filled: not registered, so a release leaves it alone", recs[2].cover_bb == sentinel and recs[2]._cover_filled == true)
        check("7.23 the two others were released", recs[1].cover_bb == nil and recs[3].cover_bb == nil)
    end

    -- 7.23b filled by someone else AFTER it was queued, BEFORE its decode tick: the decode-time guard ------------
    do
        local w, M = visibleWorld()
        local recs = nrecs(235, 3, "all")
        local sentinel = { getWidth = function() return 1 end, getHeight = function() return 1 end }
        seed(w, 12, recs)
        M.prefetchNextPage(ID, 12, 12)
        run(w, 0.9)
        local guard = 0
        while not logged(w, "bo prefetch: covers queued n=3") and guard < 2000 do run(w, 0.001); guard = guard + 1 end
        check("7.23b setup: queued, nothing decoded yet", logged(w, "bo prefetch: covers queued n=3") and w.decoded == 0, w.decoded)
        -- e.g. the visible pool / the widget filled the last record in the meantime
        recs[3].cover_bb, recs[3]._cover_filled = sentinel, true
        run(w, 2)
        check("7.23b a record filled meanwhile keeps ITS bitmap (never overwritten)", recs[3].cover_bb == sentinel)
        check("7.23b only the other two were decoded", w.decoded == 2 and recs[1].cover_bb ~= nil and recs[2].cover_bb ~= nil, w.decoded)
        M.invalidateNextPageCache(ID)
        check("7.23b a release leaves the foreign bitmap alone", recs[3].cover_bb == sentinel and recs[3]._cover_filled == true)
    end

    -- 7.24 bad JPEG: the decode failure path, no bitmap, no endless loop --------------------------------------------
    do
        local w, M = visibleWorld()
        local recs = nrecs(240, 1, "all")
        seed(w, 12, recs)
        w.bad_decode = true
        local forks0 = #w.forks
        M.prefetchNextPage(ID, 12, 12)
        run(w, 1.2); run(w, 1)
        for _ = 1, 4 do finishAll(w); run(w, 1.5) end
        check("7.24 bad file: no bitmap and no flag", recs[1].cover_bb == nil and not recs[1]._cover_filled)
        local d1, f1 = w.decoded, #w.forks
        for _ = 1, 3 do finishAll(w); run(w, 2) end
        check("7.24 bounded: no endless re-download / re-decode loop", w.decoded == d1 and #w.forks == f1, (w.decoded - d1) .. "/" .. (#w.forks - f1))
        check("7.24 exactly one re-download, two decodes in total, bad file removed",
            #w.forks - forks0 == 1 and w.decoded == 2 and not exists(cfile(241)), (#w.forks - forks0) .. "/" .. w.decoded)
        check("7.24 nothing logged as decoded ahead", not logged(w, "bo prefetch: decode-ahead n="))
    end

    -- 7.25 size cap: > 36 records is download-only (as before D), exactly 36 is decoded ahead --------------------
    do
        local w, M = visibleWorld()
        local recs = nrecs(300, 37, "all")
        os.remove(cfile(337))                  -- one miss: still downloaded
        seed(w, 12, recs)
        local forks0, dec0 = #w.forks, w.decoded
        M.prefetchNextPage(ID, 12, 12)
        run(w, 1.2); run(w, 0.5)
        check("7.25 over the cap: the missing cover is still downloaded", #w.forks == forks0 + 1, #w.forks - forks0)
        finishAll(w); run(w, 3)
        check("7.25 over the cap: nothing decoded ahead", w.decoded == dec0 and select(1, tally(recs)) == 0 and select(2, tally(recs)) == 0, w.decoded - dec0)
        check("7.25 over the cap: the state machine hands over all 37, the source narrows to the miss",
            logged(w, "bo prefetch: covers queued n=37") and not logged(w, "bo prefetch: decode-ahead n="))
    end
    do
        local w, M = visibleWorld()
        local recs = nrecs(400, 36, "all")
        seed(w, 12, recs)
        local dec0 = w.decoded
        M.prefetchNextPage(ID, 12, 12)
        run(w, 1.2); run(w, 4)
        local bb, fl = tally(recs)
        check("7.25 exactly 36 records: all decoded ahead", bb == 36 and fl == 36 and w.decoded - dec0 == 36, bb .. "/" .. fl .. "/" .. (w.decoded - dec0))
    end

    -- 7.26 setting OFF (the repo never arms the prefetch): the source does nothing on its own ----------------------
    do
        local w, M = visibleWorld()
        local recs = nrecs(500, 3, "all")
        seed(w, 12, recs)
        local forks0, dec0 = #w.forks, w.decoded
        run(w, 6); finishAll(w); run(w, 3)
        check("7.26 never armed: no fork, no decode, no bitmap", #w.forks == forks0 and w.decoded == dec0 and select(1, tally(recs)) == 0)
    end

    -- =====================================================================================================
    -- D5: the decode-ahead SUB-SETTING (key bookorbit_prefetch_decode_ahead; ON unless explicitly false).
    -- The settings store is a stub backed by w.settings so each scenario sets the key. Not run on a device.
    -- =====================================================================================================
    local SUB = "bookorbit_prefetch_decode_ahead"
    local function settingsWorld(settings)
        local w = prefetchWorld()
        w.settings = settings or {}
        w.stubs["lib/bookshelf_settings_store"] = { read = function(k) return w.settings[k] end, save = function(k, v) w.settings[k] = v end, flush = function() end }
        local M = loadSource(w)
        newReady(M)
        M.onCoversReady(function() end)
        M.listBooks(ID, 0, 12, { async_page = true })
        run(w, 0.05); finishAll(w); run(w, 1)
        return w, M
    end

    -- 7.27 sub-setting OFF (parent armed): download only, exactly as before decode-ahead ------------------------
    do
        local w, M = settingsWorld({ [SUB] = false })
        local recs = nrecs(600, 4, { true, true, true })     -- the 4th is missing from disk
        seed(w, 12, recs)
        local forks0, dec0 = #w.forks, w.decoded
        M.prefetchNextPage(ID, 12, 12)
        run(w, 1.2); run(w, 0.5)
        check("7.27 OFF: disk hits are not wanted, only the missing cover (covers queued n=1)", logged(w, "bo prefetch: covers queued n=1"))
        check("7.27 OFF: exactly one download (the miss)", #w.forks == forks0 + 1, #w.forks - forks0)
        finishAll(w); run(w, 3)
        local bb, fl = tally(recs)
        check("7.27 OFF: the missing cover is on disk", exists(cfile(604)))
        check("7.27 OFF: nothing decoded, no bitmap, no flag on any record", w.decoded == dec0 and bb == 0 and fl == 0, w.decoded - dec0)
        check("7.27 OFF: no decode-ahead log line", not logged(w, "bo prefetch: decode-ahead n="))
    end
    do   -- OFF and everything already on disk: nothing at all to do
        local w, M = settingsWorld({ [SUB] = false })
        local recs = nrecs(610, 3, "all")
        seed(w, 12, recs)
        local forks0, dec0 = #w.forks, w.decoded
        armAndRun(w, M, 12)
        check("7.27 OFF + all on disk: no fork, no decode, no bitmap",
            #w.forks == forks0 and w.decoded == dec0 and select(1, tally(recs)) == 0 and select(2, tally(recs)) == 0)
    end

    -- 7.28 sub-setting ON or unset: decoded ahead (default ON) ---------------------------------------------------
    for _, case in ipairs({ { "explicit true", { [SUB] = true } }, { "unset (default)", {} } }) do
        local w, M = settingsWorld(case[2])
        local recs = nrecs(620, 3, "all")
        seed(w, 12, recs)
        local dec0 = w.decoded
        armAndRun(w, M, 12)
        local bb, fl = tally(recs)
        check("7.28 " .. case[1] .. ": decoded ahead", bb == 3 and fl == 3 and w.decoded - dec0 == 3, bb .. "/" .. fl)
    end

    -- 7.29 switching it OFF with held bitmaps: released (flags cleared with them), consumed records untouched ------
    do
        local w, M = settingsWorld({})
        local recs = nrecs(630, 3, "all")
        seed(w, 12, recs); armAndRun(w, M, 12)
        consume(recs[3])
        w.settings[SUB] = false
        M.releaseDecodeAhead("setting")      -- what the menu callback does
        check("7.29 held records released: bitmap AND flag cleared together",
            recs[1].cover_bb == nil and not recs[1]._cover_filled and recs[2].cover_bb == nil and not recs[2]._cover_filled)
        check("7.29 the consumed record keeps its flag", recs[3]._cover_filled == true)
        check("7.29 released n=2 reason=setting logged", logged(w, "decode-ahead released n=2 reason=setting"))
        local dec0 = w.decoded
        M.scheduleCoverFills({ recs[1], recs[2] }, ID); run(w, 1.5); finishAll(w); run(w, 1)
        check("7.29 after the release the normal fill brings the covers back", recs[1].cover_bb ~= nil and recs[2].cover_bb ~= nil and w.decoded - dec0 == 2, w.decoded - dec0)
        M.releaseDecodeAhead("setting")      -- again, nothing held by the holder any more: harmless
        check("7.29 a second release is harmless", recs[1].cover_bb ~= nil)
    end

    -- 7.30 switching it OFF in the middle of a decode run: queued decodes of that page are vetoed ---------------
    do
        local w, M = settingsWorld({})
        local recs = nrecs(640, 4, "all")
        seed(w, 12, recs)
        M.prefetchNextPage(ID, 12, 12)
        run(w, 1.0)
        local guard = 0
        while w.decoded < 1 and guard < 400 do run(w, 0.01); guard = guard + 1 end
        w.settings[SUB] = false
        M.releaseDecodeAhead("setting")
        local dec_at = w.decoded
        run(w, 3)
        local bb, fl = tally(recs)
        check("7.30 no further decode after the release", w.decoded == dec_at and dec_at < 4, w.decoded)
        check("7.30 nothing is left attached (bitmap AND flag)", bb == 0 and fl == 0, bb .. "/" .. fl)
    end

    -- 7.31 OFF (menu release), then the next page: download-only, the previous page stays released -----------------
    do
        local w, M = settingsWorld({})
        local A = nrecs(650, 2, "all")
        seed(w, 12, A); armAndRun(w, M, 12)
        check("7.31 setup: A decoded ahead", select(1, tally(A)) == 2)
        w.settings[SUB] = false
        M.releaseDecodeAhead("setting")      -- the menu callback
        check("7.31 the menu release freed page A at once", select(1, tally(A)) == 0 and select(2, tally(A)) == 0)
        local B = nrecs(660, 3, { true, true })       -- the 3rd is missing
        seed(w, 24, B)
        local forks0, dec0 = #w.forks, w.decoded
        M.prefetchNextPage(ID, 24, 12)
        run(w, 1.2); run(w, 0.5)
        check("7.31 page B: only the missing cover is downloaded", #w.forks == forks0 + 1, #w.forks - forks0)
        finishAll(w); run(w, 3)
        check("7.31 page B is not decoded (OFF), the download is on disk", w.decoded == dec0 and select(1, tally(B)) == 0 and exists(cfile(663)))
    end

    -- 7.32 releasing before anything was built is harmless -------------------------------------------------------
    do
        local w = prefetchWorld(); local M = loadSource(w)
        local ok = pcall(M.releaseDecodeAhead, "setting")
        check("7.32 releaseDecodeAhead on a fresh module does nothing and does not error", ok and type(M.releaseDecodeAhead) == "function")
    end

    -- 7.14 static: O1 fix, option A (P5) ------------------------------------------------------------------------
    do
        local function slurp(p) local f = assert(io.open(PLUGIN .. "/" .. p, "rb")); local t = f:read("*a"); f:close(); return t end
        local repo, widget = slurp("lib/bookshelf_book_repository.lua"), slurp("lib/bookshelf_widget.lua")
        local early = repo:find("page.bo_pending or page.bo_failed", 1, true)
        local g = 'if BOSource.scheduleCoverFills and not (opts and opts.preload_visible) then'
        local gpos = repo:find(g, 1, true)
        check("7.14 repo: scheduleCoverFills guarded by preload_visible, once", gpos and select(2, repo:gsub("BOSource%.scheduleCoverFills%(page, source%.id%)", "")) == 1)
        check("7.14 repo: guard after the pending/failed early return", early and gpos and early < gpos)
        check("7.14 repo: the call sits inside that guard", gpos and repo:find("BOSource.scheduleCoverFills(page, source.id)", gpos, true) == (repo:find("BOSource.scheduleCoverFills(page, source.id)", 1, true)))
        check("7.14 repo: plain preload (chip pre-warm) is NOT excluded from cover fills",
            not repo:find("scheduleCoverFills and not (opts and opts.preload)", 1, true))
        check("7.14 repo: prefetch arming still excludes every preload call", repo:find('and not (opts and opts.preload)\n', 1, true) ~= nil)
        check("7.14 widget: preload_visible sets preload AND the flag",
            widget:find('async_mode == "preload" or async_mode == "preload_visible"', 1, true) ~= nil
            and widget:find('if async_mode == "preload_visible" then fetch_opts.preload_visible = true end', 1, true) ~= nil)
        check("7.14 widget: mode chosen by on-screen chip and no description pre-warm",
            widget:find('(chip_key == save_chip and not prefetch_desc) and "preload_visible" or "preload"', 1, true) ~= nil)
        check("7.14 widget: chip pre-warm call still passes prefetch_desc = true",
            widget:find("self._chip_preload_seen, key, 1, w, h, true)", 1, true) ~= nil)
        check("7.14 widget: next-page warm-up call still passes self.chip",
            widget:find("self:_collectPageCovers(jobs, seen, self.chip, target, w, h)", 1, true) ~= nil)
        check("7.14 widget: preload_visible is set nowhere else", select(2, widget:gsub("preload_visible = true", "")) == 1)
    end

    -- 7.13 static: the repo gate (D-P6) and the source cleanup ---------------------------------------------------
    do
        local function slurp(p) local f = assert(io.open(PLUGIN .. "/" .. p, "rb")); local t = f:read("*a"); f:close(); return t end
        local repo, src = slurp("lib/bookshelf_book_repository.lua"), slurp("lib/bookshelf_bookorbit_source.lua")
        local early = repo:find("page.bo_pending or page.bo_failed", 1, true)
        local call  = repo:find("BOSource.prefetchNextPage(source.id, off + lim, lim)", 1, true)
        local gate  = call and repo:sub(math.max(1, call - 400), call)
        check("7.13 repo: the prefetch call exists exactly once", select(2, repo:gsub("BOSource%.prefetchNextPage%(", "")) == 1)
        check("7.13 repo: the prefetch sits after the pending/failed early return", early and call and early < call)
        check("7.13 repo: still gated by the setting == true", gate and gate:find('BookshelfSettings.read("bookorbit_prefetch_next_page") == true', 1, true) ~= nil)
        check("7.13 repo: preload calls never arm it (D-P6)", gate and gate:find("not (opts and opts.preload)", 1, true) ~= nil)
        check("7.13 repo: the gate is part of the SAME condition as the setting",
            gate and (gate:find('== true\n%s*and not %(opts and opts%.preload%)') ~= nil))
        check("7.13 source: clearThumbFailures resets the prefetch pool", src:find("_prefetch_pool:resetFailures()", 1, true) ~= nil)
    end

    -- =====================================================================================================
    -- 9. S2: the prescale hook in the prefetch pool's decode (the REAL source; the prescaler is a FAKE
    -- registered through M.setCoverPrescaler; fake fork / clock / cache / RenderImage). Not run on a device.
    -- Records: ids base+i -> COVERS/<id>_20260101.jpg. A bitmap here counts its own :free() calls.
    -- =====================================================================================================
    local function presWorld(settings)
        local w, M = settingsWorld(settings or {})
        w.frees, w.double_free, w.bbs, w.pcalls = 0, 0, {}, {}
        w.stubs["ui/renderimage"] = { renderImageFile = function()
            w.decoded = w.decoded + 1
            if w.bad_decode then return nil end
            local bb = { freed = false, getWidth = function() return 10 end, getHeight = function() return 20 end }
            function bb:free()
                w.frees = w.frees + 1
                if self.freed then w.double_free = w.double_free + 1 end
                self.freed = true
            end
            w.bbs[#w.bbs + 1] = bb
            return bb
        end }
        return w, M
    end
    -- register a fake prescaler; decide(record, bb, n) -> status, stats (or errors)
    local function installPresc(w, M, decide)
        M.setCoverPrescaler(function(record, bb)
            -- what the prescaler sees of the record at call time (it is offered the bitmap BEFORE
            -- the record is touched: nothing attached, not flagged yet)
            w.pcalls[#w.pcalls + 1] = { record = record, bb = bb, pre_bb = record.cover_bb, pre_flag = record._cover_filled }
            return decide(record, bb, #w.pcalls)
        end)
    end
    local function scaledStatus() return "scaled", { w = 118, h = 158, scale_ms = 5, put_ms = 7 } end
    local function noBitmapAnywhere(recs)
        for _, r in ipairs(recs) do
            if r.cover_bb ~= nil or r.cover_w ~= nil or r.cover_h ~= nil then return false end
        end
        return true
    end

    -- 9.1 prescaled page: no bitmap on any record, flagged, raw freed once each, holder holds nothing ----------
    do
        local w, M = presWorld()
        local recs = nrecs(700, 3, "all"); seed(w, 12, recs)
        installPresc(w, M, scaledStatus)
        local forks0, dec0 = #w.forks, w.decoded
        armAndRun(w, M, 12)
        local bb, fl = tally(recs)
        check("9.1 the prescaler was asked once per record", #w.pcalls == 3, #w.pcalls)
        check("9.1 it was handed the record and the freshly decoded bitmap",
            w.pcalls[1].record == recs[1] and w.pcalls[1].bb == w.bbs[1] and w.pcalls[3].bb == w.bbs[3])
        check("9.1 at call time the record is untouched (no bitmap attached, not flagged): offered BEFORE attaching",
            w.pcalls[1].pre_bb == nil and not w.pcalls[1].pre_flag and w.pcalls[3].pre_bb == nil and not w.pcalls[3].pre_flag)
        check("9.1 each record got its OWN bitmap (one decode per record)", w.decoded - dec0 == 3 and w.pcalls[1].bb ~= w.pcalls[2].bb)
        check("9.1 no record holds a bitmap, size fields are clear", bb == 0 and noBitmapAnywhere(recs))
        check("9.1 every record is flagged _cover_filled and has_cover (identical to a revisited record)",
            fl == 3 and recs[1].has_cover == true and recs[2].has_cover == true and recs[3].has_cover == true)
        check("9.1 each raw bitmap freed exactly once, no double free", w.frees == 3 and w.double_free == 0, w.frees .. "/" .. w.double_free)
        check("9.1 no download forked (disk hits)", #w.forks == forks0)
        check("9.1 summary: prescaled=3 raw=0 bytes=0", logged(w, "bo prefetch: decode-ahead n=3 prescaled=3 raw=0 bytes=0 ms="))
        check("9.1 summary carries prescale_ms", logged(w, "prescale_ms="))
        check("9.1 summary logged once", count(w, "bo prefetch: decode-ahead n=") == 1, count(w, "bo prefetch: decode-ahead n="))
        check("9.1 per-cover line with the stats the prescaler returned",
            count(w, "bo prescale: id=701 118x158 scale=5ms put=7ms") == 1 and count(w, "bo prescale: id=703 118x158 scale=5ms put=7ms") == 1)
        check("9.1 the cache holds the SAME record tables", w.cache.store[pageKey(12, 12)].records == recs)
        check("9.1 jpg files stay on disk", exists(cfile(701)) and exists(cfile(703)))
        -- the holder holds nothing: a release / invalidate / stop drops nothing and keeps the flags
        M.releaseDecodeAhead("setting")
        check("9.1 release: nothing dropped, flags kept, no 'released' line", select(2, tally(recs)) == 3 and not logged(w, "decode-ahead released"))
        M.invalidateNextPageCache(ID)
        check("9.1 invalidate: nothing dropped, flags kept, no 'released' line", select(2, tally(recs)) == 3 and not logged(w, "decode-ahead released"))
        M.shutdownCoverPool()
        check("9.1 stop: nothing dropped, flags kept, no 'released' line, nothing freed again",
            select(2, tally(recs)) == 3 and not logged(w, "decode-ahead released") and w.frees == 3)
    end

    -- 9.2 "already": same outcome, no per-cover line --------------------------------------------------------------
    do
        local w, M = presWorld()
        local recs = nrecs(710, 3, "all"); seed(w, 12, recs)
        installPresc(w, M, function() return "already", { w = 118, h = 158, scale_ms = 0, put_ms = 0 } end)
        armAndRun(w, M, 12)
        local bb, fl = tally(recs)
        check("9.2 already: no bitmap, flagged, raw freed once each", bb == 0 and fl == 3 and w.frees == 3 and w.double_free == 0)
        check("9.2 already: counted as prescaled", logged(w, "n=3 prescaled=3 raw=0 bytes=0"))
        check("9.2 already: no per-cover 'bo prescale' line (nothing was scaled)", count(w, "bo prescale: id=") == 0)
    end

    -- 9.3 no prescaler (never set, set then cleared, or a non-function): exactly the D5 raw path ----------------------
    for _, case in ipairs({ { "never set", false }, { "cleared with nil", true }, { "cleared with a non-function", "junk" } }) do
        local w, M = presWorld()
        local recs = nrecs(720, 3, "all"); seed(w, 12, recs)
        if case[2] then
            installPresc(w, M, scaledStatus)
            if case[2] == "junk" then M.setCoverPrescaler("junk") else M.setCoverPrescaler(nil) end
        end
        armAndRun(w, M, 12)
        local bb, fl = tally(recs)
        check("9.3 " .. case[1] .. ": raw bitmaps attached to every record", bb == 3 and fl == 3)
        check("9.3 " .. case[1] .. ": nothing freed, prescaler never called", w.frees == 0 and #w.pcalls == 0)
        check("9.3 " .. case[1] .. ": summary says prescaled=0 raw=3", logged(w, "n=3 prescaled=0 raw=3 bytes="))
        check("9.3 " .. case[1] .. ": no per-cover line", count(w, "bo prescale: id=") == 0)
        M.releaseDecodeAhead("setting")
        check("9.3 " .. case[1] .. ": release still drops them (bitmap AND flag)", select(1, tally(recs)) == 0 and select(2, tally(recs)) == 0)
    end

    -- 9.4 mixed: the prescaler declines for some records -------------------------------------------------------------
    do
        local w, M = presWorld()
        local recs = nrecs(730, 3, "all"); seed(w, 12, recs)
        installPresc(w, M, function(record) if record.remote_id == 732 then return nil end return scaledStatus() end)
        armAndRun(w, M, 12)
        local bb, fl = tally(recs)
        check("9.4 mixed: only the declined record keeps a bitmap, all three flagged", bb == 1 and fl == 3, bb .. "/" .. fl)
        check("9.4 mixed: the declined record holds ITS OWN decoded bitmap, still alive", recs[2].cover_bb == w.bbs[2] and w.bbs[2].freed == false)
        check("9.4 mixed: the two prescaled raws freed, the kept one not", w.frees == 2 and w.bbs[1].freed and w.bbs[3].freed and w.double_free == 0)
        check("9.4 mixed: summary n=3 prescaled=2 raw=1", logged(w, "n=3 prescaled=2 raw=1 bytes="))
        check("9.4 mixed: the declined record's size attached", recs[2].cover_w == 10 and recs[2].cover_h == 20)
        M.releaseDecodeAhead("setting")
        check("9.4 mixed: a release drops ONLY the held raw record (bitmap AND flag), prescaled keep their flag",
            recs[2].cover_bb == nil and not recs[2]._cover_filled and recs[1]._cover_filled and recs[3]._cover_filled)
        check("9.4 mixed: released n=1 logged (the holder only ever saw the raw one)", logged(w, "decode-ahead released n=1 reason=setting"))
        check("9.4 mixed: a release never frees", w.frees == 2)
    end

    -- 9.5 the prescaler throws: fallback to the raw path, called once per record, no retry loop -------------------------
    do
        local w, M = presWorld()
        local recs = nrecs(740, 3, "all"); seed(w, 12, recs)
        installPresc(w, M, function() error("prescale boom") end)
        local dec0 = w.decoded
        armAndRun(w, M, 12)
        local bb, fl = tally(recs)
        check("9.5 throw: raw bitmap attached for every record, flagged", bb == 3 and fl == 3)
        check("9.5 throw: asked exactly once per record (no loop), one decode each", #w.pcalls == 3 and w.decoded - dec0 == 3, #w.pcalls .. "/" .. (w.decoded - dec0))
        check("9.5 throw: nothing freed", w.frees == 0)
        check("9.5 throw: summary prescaled=0 raw=3", logged(w, "n=3 prescaled=0 raw=3 bytes="))
        check("9.5 throw: not a decode failure (no give-up logged)", not logged(w, "prefetch: giving up on book cover"))
    end

    -- 9.6 anything but "scaled" / "already" is not handled ---------------------------------------------------------------
    do
        local w, M = presWorld()
        local recs = nrecs(750, 4, "all"); seed(w, 12, recs)
        local answers = { false, "weird", true, "SCALED" }
        installPresc(w, M, function(_, _, n) return answers[n] end)
        armAndRun(w, M, 12)
        local bb, fl = tally(recs)
        check("9.6 unknown statuses (false, 'weird', true, wrong case): all four fall back to raw", bb == 4 and fl == 4 and w.frees == 0, bb .. "/" .. fl .. "/" .. w.frees)
        check("9.6 summary prescaled=0 raw=4", logged(w, "n=4 prescaled=0 raw=4 bytes="))
    end

    -- 9.7 the stale page is vetoed BEFORE the prescaler (a different page armed mid-run) -------------------------------
    do
        local w, M = presWorld()
        local A = nrecs(760, 4, "all")
        seed(w, 12, A)
        installPresc(w, M, scaledStatus)
        M.prefetchNextPage(ID, 12, 12)
        run(w, 1.0)
        local guard = 0
        while w.decoded < 1 and guard < 400 do run(w, 0.01); guard = guard + 1 end
        local B = nrecs(770, 2, "all")
        seed(w, 24, B)
        M.prefetchNextPage(ID, 24, 12)         -- different key: cancel_covers
        local calls0, dec0 = #w.pcalls, w.decoded
        run(w, 0.5)
        check("9.7 stale: no further decode and the prescaler is NOT called for the rest of page A", w.decoded == dec0 and #w.pcalls == calls0, #w.pcalls - calls0)
        local _, flA = tally(A)
        check("9.7 stale: the rest of page A has no flag and no bitmap", flA == calls0 and flA < 4 and select(1, tally(A)) == 0, flA)
        run(w, 1); run(w, 2)
        local bbB, flB = tally(B)
        check("9.7 page B is prescaled afterwards (flagged, no bitmap)", bbB == 0 and flB == 2)
        local onlyB = true
        for i = calls0 + 1, #w.pcalls do if w.pcalls[i].record.remote_id < 770 then onlyB = false end end
        check("9.7 every later prescaler call was for page B", onlyB and #w.pcalls == calls0 + 2, #w.pcalls - calls0)
    end

    -- 9.8 a stale download landing late is not decoded, so the prescaler is not asked ---------------------------------
    do
        local w, M = presWorld()
        local A = nrecs(780, 2, nil)
        seed(w, 12, A)
        installPresc(w, M, scaledStatus)
        M.prefetchNextPage(ID, 12, 12)
        run(w, 1.2); run(w, 0.1)
        local B = nrecs(790, 2, "all")
        seed(w, 24, B)
        M.prefetchNextPage(ID, 24, 12)
        run(w, 1.2)
        finishAll(w)
        run(w, 2); finishAll(w); run(w, 1)
        local askedA = false
        for _, c in ipairs(w.pcalls) do if c.record.remote_id < 790 then askedA = true end end
        check("9.8 stale download: the prescaler was never asked about page A", not askedA)
        check("9.8 stale download: no flag, no bitmap on its records, file stays on disk",
            select(2, tally(A)) == 0 and select(1, tally(A)) == 0 and exists(cfile(781)))
        check("9.8 page B prescaled meanwhile", select(2, tally(B)) == 2 and select(1, tally(B)) == 0)
    end

    -- 9.9 release / sub-setting OFF in the middle of a prescale run: queued decodes vetoed ---------------------------------
    do
        local w, M = presWorld()
        local recs = nrecs(800, 4, "all"); seed(w, 12, recs)
        installPresc(w, M, scaledStatus)
        M.prefetchNextPage(ID, 12, 12)
        run(w, 1.0)
        local guard = 0
        while w.decoded < 1 and guard < 400 do run(w, 0.01); guard = guard + 1 end
        w.settings["bookorbit_prefetch_decode_ahead"] = false
        M.releaseDecodeAhead("setting")
        local calls0, dec_at = #w.pcalls, w.decoded
        run(w, 3)
        check("9.9 release mid-run: no further decode, the prescaler is not asked again", w.decoded == dec_at and #w.pcalls == calls0 and calls0 < 4, #w.pcalls)
        check("9.9 release mid-run: the records prescaled before keep their flag (no bitmap), the rest are untouched",
            select(2, tally(recs)) == calls0 and select(1, tally(recs)) == 0)
    end

    -- 9.10 sub-setting OFF and an oversize page: download only, the prescaler is never asked --------------------------------
    do
        local w, M = presWorld({ bookorbit_prefetch_decode_ahead = false })
        local recs = nrecs(810, 3, { true, true }); seed(w, 12, recs)   -- the 3rd is missing from disk
        installPresc(w, M, scaledStatus)
        armAndRun(w, M, 12)
        finishAll(w); run(w, 3)
        check("9.10 OFF: the prescaler is never asked, nothing flagged, only the download happened",
            #w.pcalls == 0 and select(2, tally(recs)) == 0 and exists(cfile(813)) and w.decoded == 0)
        local w2, M2 = presWorld()
        local big = nrecs(820, 37, "all"); seed(w2, 12, big)             -- > PREFETCH_AHEAD_MAX_RECORDS (36)
        installPresc(w2, M2, scaledStatus)
        armAndRun(w2, M2, 12)
        finishAll(w2); run(w2, 3)
        check("9.10 oversize page (37): download only, the prescaler is never asked, nothing decoded or flagged",
            #w2.pcalls == 0 and select(2, tally(big)) == 0 and w2.decoded == 0)
    end

    -- 9.11 a bad JPEG: decode fails exactly as before, the prescaler is not asked ----------------------------------------------
    do
        local w, M = presWorld()
        w.bad_decode = true
        local recs = nrecs(830, 2, "all"); seed(w, 12, recs)
        installPresc(w, M, scaledStatus)
        armAndRun(w, M, 12)
        check("9.11 bad jpeg: the prescaler is not asked, no flag, no bitmap, nothing freed",
            #w.pcalls == 0 and select(2, tally(recs)) == 0 and select(1, tally(recs)) == 0 and w.frees == 0)
    end

    -- 9.12 the prescaler is cleared mid-run: the rest of the page takes the raw path -----------------------------------------------
    do
        local w, M = presWorld()
        local recs = nrecs(840, 4, "all"); seed(w, 12, recs)
        installPresc(w, M, function(record, bb, n)
            if n == 1 then M.setCoverPrescaler(nil) end   -- cleared during the first call (widget teardown)
            return scaledStatus()
        end)
        armAndRun(w, M, 12)
        local bb, fl = tally(recs)
        check("9.12 cleared mid-run: record 1 prescaled (no bitmap), the other three raw", bb == 3 and fl == 4 and recs[1].cover_bb == nil, bb .. "/" .. fl)
        check("9.12 cleared mid-run: the prescaler was asked once, one raw freed", #w.pcalls == 1 and w.frees == 1)
        check("9.12 cleared mid-run: summary n=4 prescaled=1 raw=3", logged(w, "n=4 prescaled=1 raw=3 bytes="))
        M.releaseDecodeAhead("setting")
        check("9.12 cleared mid-run: release drops the three raw ones, keeps the prescaled flag",
            select(1, tally(recs)) == 0 and recs[1]._cover_filled == true and not recs[2]._cover_filled)
    end

    -- 9.13 the VISIBLE page's pool never calls the prescaler ---------------------------------------------------------------------
    do
        local w, M = presWorld()
        local vis = nrecs(850, 3, "all")
        installPresc(w, M, scaledStatus)
        M.scheduleCoverFills(vis, ID); run(w, 1.5); finishAll(w); run(w, 1)
        local bb, fl = tally(vis)
        check("9.13 visible chain: normal raw bitmaps attached, prescaler never asked, nothing freed",
            bb == 3 and fl == 3 and #w.pcalls == 0 and w.frees == 0, bb .. "/" .. fl .. "/" .. #w.pcalls)
    end

    -- 9.14 a bitmap without :free (the older harness fake) does not break the prescaled branch -----------------------------------
    do
        local w, M = settingsWorld({})        -- default RenderImage fake: plain table, no free
        local recs = nrecs(860, 2, "all"); seed(w, 12, recs)
        M.setCoverPrescaler(scaledStatus)
        local ok = pcall(armAndRun, w, M, 12)
        check("9.14 no :free on the bitmap: no error, records still flagged without a bitmap",
            ok and select(2, tally(recs)) == 2 and select(1, tally(recs)) == 0)
    end

    -- 9.15 an already-filled record is never offered to the prescaler (nor overwritten) -----------------------------------------
    do
        local w, M = presWorld()
        local recs = nrecs(870, 3, "all")
        local sentinel = { getWidth = function() return 1 end, getHeight = function() return 1 end }
        recs[2].cover_bb, recs[2]._cover_filled = sentinel, true
        seed(w, 12, recs)
        installPresc(w, M, scaledStatus)
        armAndRun(w, M, 12)
        check("9.15 already filled: not decoded, not offered, bitmap untouched", #w.pcalls == 2 and recs[2].cover_bb == sentinel and w.decoded == 2)
        check("9.15 the other two prescaled", recs[1].cover_bb == nil and recs[1]._cover_filled and recs[3].cover_bb == nil and recs[3]._cover_filled)
    end

    -- 9.16 a prescaled record is not wanted again: a later visible fill skips it (nothing to decode) -------------------------------
    do
        local w, M = presWorld()
        local recs = nrecs(880, 2, "all"); seed(w, 12, recs)
        installPresc(w, M, scaledStatus)
        armAndRun(w, M, 12)
        local dec0 = w.decoded
        M.scheduleCoverFills(recs, ID); run(w, 1.5); finishAll(w); run(w, 1)
        check("9.16 turning to a prescaled page: the visible chain decodes nothing (the widget blits the cache)", w.decoded == dec0, w.decoded - dec0)
        check("9.16 ... and attaches nothing", select(1, tally(recs)) == 0 and select(2, tally(recs)) == 2)
    end

    -- 9.17 prescale_ms is the summed wall time of the prescaler calls; counters do not leak into the next page ------------------
    do
        local w, M = presWorld()
        local A = nrecs(890, 3, "all"); seed(w, 12, A)
        installPresc(w, M, function() w.now = w.now + 0.25; return scaledStatus() end)
        armAndRun(w, M, 12)
        check("9.17 page A: prescale_ms is the sum of the three timed calls (750)", logged(w, "n=3 prescaled=3 raw=0 bytes=0 ms=") and logged(w, "prescale_ms=750"))
        local B = nrecs(895, 2, "all"); seed(w, 24, B)
        armAndRun(w, M, 24)
        check("9.17 page B: its own summary starts from zero (n=2 prescaled=2, prescale_ms=500)",
            logged(w, "n=2 prescaled=2 raw=0 bytes=0 ms=") and logged(w, "prescale_ms=500"))
        check("9.17 exactly two summaries in total", count(w, "bo prefetch: decode-ahead n=") == 2, count(w, "bo prefetch: decode-ahead n="))
        -- a page of raw records after a prescaled one: prescaled must be 0, not 3 or 5
        M.setCoverPrescaler(nil)
        local C = nrecs(900, 2, "all"); seed(w, 36, C)
        armAndRun(w, M, 36)
        check("9.17 page C (no prescaler): n=2 prescaled=0 raw=2, prescale_ms=0", logged(w, "n=2 prescaled=0 raw=2 bytes=") and logged(w, "prescale_ms=0"))
    end

    -- =====================================================================================================
    -- S4: M.coverTileChanged(): the tile size moved after covers were prescaled for pages NOT yet turned to.
    -- The flag of exactly those records is cleared (so the normal chain decodes them at the new size);
    -- pages already handed to the widget (a non-preload listBooks hit) are never touched. Not run on a device.
    -- =====================================================================================================

    -- 9.18 a prescaled, not-yet-turned page: flags cleared, nothing else; the normal chain brings the covers back ---------------
    do
        local w, M = presWorld()
        local recs = nrecs(910, 3, "all"); seed(w, 12, recs)
        installPresc(w, M, scaledStatus)
        armAndRun(w, M, 12)
        check("9.18 before: three records prescaled and flagged, no bitmap", select(2, tally(recs)) == 3 and select(1, tally(recs)) == 0)
        local n = M.coverTileChanged()
        check("9.18 coverTileChanged reports 3 cleared flags", n == 3, n)
        check("9.18 the flags are gone, no bitmap appeared", select(2, tally(recs)) == 0 and select(1, tally(recs)) == 0)
        check("9.18 has_cover stays true (the book still has a cover), size fields stay clear",
            recs[1].has_cover == true and recs[3].has_cover == true and noBitmapAnywhere(recs))
        check("9.18 the cleared flag is nil (same state as Ahead.dropRecord leaves)", recs[1]._cover_filled == nil and recs[2]._cover_filled == nil)
        check("9.18 one dbg line says how many will be decoded again", count(w, "bo prescale: tile changed, 3 prefetched cover(s) will be decoded again") == 1)
        check("9.18 nothing was freed or decoded by the call itself", w.frees == 3 and w.double_free == 0)
        local dec0, pc0 = w.decoded, #w.pcalls
        M.scheduleCoverFills(recs, ID); run(w, 1.5); finishAll(w); run(w, 1)
        check("9.18 a normal fill decodes the three covers again", w.decoded - dec0 == 3, w.decoded - dec0)
        check("9.18 ... and they come back as raw bitmaps with the flag (the widget scales them at the new size)",
            select(1, tally(recs)) == 3 and select(2, tally(recs)) == 3)
        check("9.18 the visible chain still never asks the prescaler", #w.pcalls == pc0)
        -- idempotent / the re-filled records are not tracked any more
        local keep = { recs[1].cover_bb, recs[2].cover_bb, recs[3].cover_bb }
        check("9.18 a second call clears nothing", M.coverTileChanged() == 0)
        check("9.18 ... and leaves the re-filled bitmaps and flags alone",
            recs[1].cover_bb == keep[1] and recs[2].cover_bb == keep[2] and recs[3].cover_bb == keep[3] and select(2, tally(recs)) == 3)
    end

    -- 9.19 a page the widget has been handed (non-preload listBooks hit) is never touched ----------------------------------------
    do
        local w, M = presWorld()
        local recs = nrecs(920, 3, "all"); seed(w, 12, recs)
        installPresc(w, M, scaledStatus)
        armAndRun(w, M, 12)
        local got = M.listBooks(ID, 12, 12, { async_page = true })
        check("9.19 the turn gets the SAME cached record tables", got == recs)
        check("9.19 tile change after the turn: nothing cleared", M.coverTileChanged() == 0)
        check("9.19 ... the three records keep their flag and has_cover, still no bitmap",
            select(2, tally(recs)) == 3 and select(1, tally(recs)) == 0 and recs[1].has_cover == true)
        check("9.19 no 'tile changed' line when nothing was cleared", count(w, "bo prescale: tile changed") == 0)
    end

    -- 9.20 the widget's own next-page WARM-UP (listBooks with opts.preload) is not a turn: it must not forget -------------------
    do
        local w, M = presWorld()
        local recs = nrecs(930, 3, "all"); seed(w, 12, recs)
        installPresc(w, M, scaledStatus)
        armAndRun(w, M, 12)
        local a = M.listBooks(ID, 12, 12, { async_page = true, preload = true })
        local b = M.listBooks(ID, 12, 12, { async_page = true, preload = true, preload_visible = true })
        check("9.20 the warm-up gets the cached page (nothing is refetched)", a == recs and b == recs)
        check("9.20 after the warm-up the records are still waiting: tile change clears all three", M.coverTileChanged() == 3)
        check("9.20 flags gone", select(2, tally(recs)) == 0)
    end

    -- 9.21 only the PRESCALED records are touched: a record that was declined keeps its raw bitmap and flag --------------------
    do
        local w, M = presWorld()
        local recs = nrecs(940, 3, "all"); seed(w, 12, recs)
        installPresc(w, M, function(r, bb, n) if n == 2 then return nil, "no_dims" end return scaledStatus() end)
        armAndRun(w, M, 12)
        local bm = recs[2].cover_bb
        check("9.21 before: record 2 holds a raw bitmap, 1 and 3 are prescaled", bm ~= nil and recs[1].cover_bb == nil and recs[3].cover_bb == nil)
        check("9.21 tile change clears exactly the two prescaled flags", M.coverTileChanged() == 2)
        check("9.21 the declined record keeps its bitmap, its size fields and its flag",
            recs[2].cover_bb == bm and recs[2]._cover_filled == true and recs[2].cover_w == 10 and recs[2].cover_h == 20)
        check("9.21 the two prescaled records are wanted again", recs[1]._cover_filled == nil and recs[3]._cover_filled == nil)
    end

    -- 9.22 an \"already\" (cover found in the scaled cache) record is tracked and cleared like a scaled one ------------------------
    do
        local w, M = presWorld()
        local recs = nrecs(950, 3, "all"); seed(w, 12, recs)
        installPresc(w, M, function() return "already", { w = 1, h = 1, scale_ms = 0, put_ms = 0 } end)
        armAndRun(w, M, 12)
        check("9.22 'already' records are flagged without a bitmap", select(2, tally(recs)) == 3 and select(1, tally(recs)) == 0)
        check("9.22 ... and cleared by a tile change", M.coverTileChanged() == 3 and select(2, tally(recs)) == 0)
    end

    -- 9.23 a record that got a bitmap (or lost its flag) since is not ours to touch ---------------------------------------------
    do
        local w, M = presWorld()
        local recs = nrecs(960, 3, "all"); seed(w, 12, recs)
        installPresc(w, M, scaledStatus)
        armAndRun(w, M, 12)
        local sentinel = { getWidth = function() return 1 end, getHeight = function() return 1 end }
        recs[1].cover_bb = sentinel            -- someone attached a bitmap meanwhile
        recs[2]._cover_filled = nil            -- someone already dropped the flag
        check("9.23 only the one still in the exact prescale state is cleared", M.coverTileChanged() == 1)
        check("9.23 the record holding a bitmap keeps bitmap and flag", recs[1].cover_bb == sentinel and recs[1]._cover_filled == true)
        check("9.23 the record without a flag stays without", recs[2]._cover_filled == nil and recs[3]._cover_filled == nil)
        check("9.23 all three are forgotten after the call (a second call finds nothing)", M.coverTileChanged() == 0 and recs[1]._cover_filled == true)
    end

    -- 9.24 nothing prescaled: harmless, silent -------------------------------------------------------------------------------
    do
        local w, M = presWorld()
        check("9.24 fresh module: returns 0 and does not error", select(2, pcall(M.coverTileChanged)) == 0)
        local recs = nrecs(970, 2, "all"); seed(w, 12, recs)       -- no prescaler: the raw path (D5)
        armAndRun(w, M, 12)
        local bb0 = recs[1].cover_bb
        check("9.24 a raw (D5) page is not tracked: returns 0, bitmaps and flags untouched",
            M.coverTileChanged() == 0 and recs[1].cover_bb == bb0 and select(1, tally(recs)) == 2 and select(2, tally(recs)) == 2)
        check("9.24 nothing logged", count(w, "bo prescale: tile changed") == 0)
    end

    -- 9.25 several waiting pages: every one of them is cleared, a consumed one is not ----------------------------------------
    do
        local w, M = presWorld()
        local A = nrecs(980, 3, "all"); seed(w, 12, A)
        local B = nrecs(985, 2, "all"); seed(w, 24, B)
        installPresc(w, M, scaledStatus)
        armAndRun(w, M, 12)
        armAndRun(w, M, 24)
        check("9.25 both pages prescaled", select(2, tally(A)) == 3 and select(2, tally(B)) == 2)
        M.listBooks(ID, 12, 12, { async_page = true })      -- the user turns to page A
        check("9.25 tile change: only the waiting page B is cleared (2)", M.coverTileChanged() == 2)
        check("9.25 page A (consumed) keeps its flags, page B lost them", select(2, tally(A)) == 3 and select(2, tally(B)) == 0)
    end
    do
        local w, M = presWorld()
        local A = nrecs(990, 3, "all"); seed(w, 12, A)
        local B = nrecs(995, 2, "all"); seed(w, 24, B)
        installPresc(w, M, scaledStatus)
        armAndRun(w, M, 12)
        armAndRun(w, M, 24)
        check("9.25b nobody turned: both pages waiting, one call clears all five (not only the page held last)",
            M.coverTileChanged() == 5 and select(2, tally(A)) == 0 and select(2, tally(B)) == 0)
    end

    -- 9.26 the prescale keeps working after a tile change; the call touches no pool, hook or holder ---------------------------
    do
        local w, M = presWorld()
        local A = nrecs(1000, 2, "all"); seed(w, 12, A)
        installPresc(w, M, scaledStatus)
        armAndRun(w, M, 12)
        local pc0 = #w.pcalls
        M.coverTileChanged()
        local B = nrecs(1005, 2, "all"); seed(w, 24, B)
        armAndRun(w, M, 24)
        check("9.26 the next prefetch still asks the prescaler (hook not cleared)", #w.pcalls == pc0 + 2, #w.pcalls - pc0)
        check("9.26 ... and prescales page B as before", select(2, tally(B)) == 2 and select(1, tally(B)) == 0)
        check("9.26 its summary is a normal one (n=2 prescaled=2 raw=0)", logged(w, "n=2 prescaled=2 raw=0 bytes=0 ms="))
        check("9.26 release / stop paths still run fine after a tile change",
            pcall(M.releaseDecodeAhead, "setting") and select(2, tally(B)) == 2)
    end

    -- 9.27 the table holds its records WEAKLY: a page that left the page cache is not kept alive by it -------------------------
    do
        local w, M = presWorld()
        local recs = nrecs(1010, 2, "all"); seed(w, 12, recs)
        M.setCoverPrescaler(scaledStatus)                  -- a hook that keeps no reference to the records
        armAndRun(w, M, 12)
        local probe = setmetatable({ recs[1] }, { __mode = "v" })
        check("9.27 tracked before", select(2, tally(recs)) == 2 and probe[1] == recs[1])
        w.cache.store[pageKey(12, 12)] = nil
        recs = nil
        collectgarbage(); collectgarbage()
        check("9.27 the record was collected: the source does not pin it", probe[1] == nil)
        check("9.27 coverTileChanged afterwards: nothing left, no error", select(2, pcall(M.coverTileChanged)) == 0)
    end

    -- =====================================================================================================
    -- S4b: after a tile change the prefetch machine forgets its done keys, so the waiting page is prefetched
    -- AGAIN (decoded + prescaled at the new size) by the widget's next request (M.prefetchNextPage, which the
    -- widget calls on every rebuild). Only the done keys are forgotten: nothing is cancelled or enqueued by
    -- the tile change itself. Not run on a device.
    -- =====================================================================================================

    -- 9.28 the whole flow: prescaled waiting page -> tile change -> rebuild -> prescaled again at the new size ------------------
    do
        local w, M = presWorld()
        local recs = nrecs(1100, 3, "all"); seed(w, 12, recs)
        installPresc(w, M, scaledStatus)
        armAndRun(w, M, 12)
        check("9.28 before: prefetched and prescaled once", select(2, tally(recs)) == 3 and #w.pcalls == 3 and count(w, "bo prefetch: armed key=") == 1)
        check("9.28 before: a rebuild's request changes nothing (the page is done)", (function()
            M.prefetchNextPage(ID, 12, 12); run(w, 1.2); run(w, 2); return #w.pcalls == 3 and count(w, "bo prefetch: armed key=") == 1 end)())
        local frees0, dec0 = w.frees, w.decoded
        check("9.28 tile change clears the three flags", M.coverTileChanged() == 3)
        check("9.28 one dbg line says the prefetch will look at 1 page again", count(w, "bo prescale: prefetch will look at 1 page(s) again") == 1)
        check("9.28 the tile change itself decodes, frees and asks nothing", w.decoded == dec0 and w.frees == frees0 and #w.pcalls == 3)
        armAndRun(w, M, 12)                      -- the widget's rebuild requests the next page again
        check("9.28 the page is armed again by that request", count(w, "bo prefetch: armed key=") == 2, count(w, "bo prefetch: armed key="))
        check("9.28 its three covers are queued again (disk hits)", count(w, "bo prefetch: covers queued n=3") == 2)
        check("9.28 the prescaler is asked for each cover again", #w.pcalls == 6, #w.pcalls)
        check("9.28 flagged again, still no bitmap anywhere", select(2, tally(recs)) == 3 and select(1, tally(recs)) == 0 and noBitmapAnywhere(recs))
        check("9.28 the new raw bitmaps are freed exactly once each, no double free", w.decoded - dec0 == 3 and w.frees - frees0 == 3 and w.double_free == 0)
        check("9.28 a normal prefetch summary follows (n=3 prescaled=3 raw=0)", count(w, "n=3 prescaled=3 raw=0 bytes=0 ms=") == 2)
        check("9.28 the holder holds nothing and nothing was released", count(w, "decode-ahead released") == 0)
        -- and it is done again afterwards
        M.prefetchNextPage(ID, 12, 12); run(w, 1.2); run(w, 2)
        check("9.28 afterwards the page is done again: no third round", #w.pcalls == 6 and count(w, "bo prefetch: armed key=") == 2)
    end

    -- 9.29 the tile change alone starts nothing: the re-arm needs the widget's request ---------------------------------------------
    do
        local w, M = presWorld()
        local recs = nrecs(1110, 3, "all"); seed(w, 12, recs)
        installPresc(w, M, scaledStatus)
        armAndRun(w, M, 12)
        local pc0, dec0, forks0, armed0 = #w.pcalls, w.decoded, #w.forks, count(w, "bo prefetch: armed key=")
        M.coverTileChanged()
        run(w, 1.2); run(w, 5); finishAll(w); run(w, 3)
        check("9.29 no request: no timer fires, nothing decoded, nothing forked, nothing armed",
            #w.pcalls == pc0 and w.decoded == dec0 and #w.forks == forks0 and count(w, "bo prefetch: armed key=") == armed0)
        check("9.29 the records stay unflagged until the request comes", select(2, tally(recs)) == 0)
    end

    -- 9.30 a prefetch that is downloading right now is untouched, and its page is not enqueued a second time --------------------
    do
        local w, M = presWorld()
        local A = nrecs(1120, 3, "all"); seed(w, 12, A)
        installPresc(w, M, scaledStatus)
        armAndRun(w, M, 12)                                  -- A prefetched and prescaled, waiting
        local B = nrecs(1130, 2, nil); seed(w, 24, B)        -- B must be downloaded first
        M.prefetchNextPage(ID, 24, 12)
        run(w, 1.2); run(w, 0.1)
        check("9.30 B's download is in flight", count(w, "bo prefetch: covers queued n=2") == 1 and #w.forks >= 1)
        local forks0, queued0 = #w.forks, count(w, "bo prefetch: covers queued")
        local n = M.coverTileChanged()
        check("9.30 the tile change clears A's three flags", n == 3, n)
        M.prefetchNextPage(ID, 24, 12)                       -- the rebuild's request for the running page
        run(w, 1.2); run(w, 0.2)
        check("9.30 the running page was NOT enqueued a second time and no extra fork started",
            count(w, "bo prefetch: covers queued") == queued0 and #w.forks == forks0, count(w, "bo prefetch: covers queued"))
        check("9.30 the running download was not killed", (function()
            for _, f in ipairs(w.forks) do if f.killed then return false end end return true end)())
        finishAll(w); run(w, 2); finishAll(w); run(w, 1)
        check("9.30 B finishes and is prescaled exactly once per record", select(2, tally(B)) == 2 and select(1, tally(B)) == 0 and #w.pcalls == 3 + 2, #w.pcalls)
        check("9.30 one summary for B (n=2 prescaled=2)", count(w, "n=2 prescaled=2 raw=0 bytes=0 ms=") == 1)
        check("9.30 no release, no double free", count(w, "decode-ahead released") == 0 and w.double_free == 0)
        -- A's key WAS forgotten (only B's was kept): now that B is idle, A arms again
        M.prefetchNextPage(ID, 12, 12); run(w, 1.2); run(w, 2)
        check("9.30 page A (forgotten) is prefetched again afterwards and prescaled at the new size",
            select(2, tally(A)) == 3 and select(1, tally(A)) == 0 and #w.pcalls == 3 + 2 + 3, #w.pcalls)
    end

    -- 9.31 a page the user already turned to is not re-armed: nothing was cleared, so nothing is forgotten --------------------------
    do
        local w, M = presWorld()
        local recs = nrecs(1140, 3, "all"); seed(w, 12, recs)
        installPresc(w, M, scaledStatus)
        armAndRun(w, M, 12)
        M.listBooks(ID, 12, 12, { async_page = true })       -- the turn
        local pc0, armed0 = #w.pcalls, count(w, "bo prefetch: armed key=")
        check("9.31 tile change after the turn clears nothing", M.coverTileChanged() == 0)
        check("9.31 ... and logs no 'look at again' line", count(w, "prefetch will look at") == 0)
        M.prefetchNextPage(ID, 12, 12); run(w, 1.2); run(w, 3)
        check("9.31 the turned-to page is not prefetched again", #w.pcalls == pc0 and count(w, "bo prefetch: armed key=") == armed0)
        check("9.31 its records keep their flags", select(2, tally(recs)) == 3)
    end

    -- 9.32 a raw (D5) page is not tracked: no clear, no forget, no re-prefetch ---------------------------------------------------------
    do
        local w, M = presWorld()
        local recs = nrecs(1150, 3, "all"); seed(w, 12, recs)
        armAndRun(w, M, 12)                                  -- no prescaler: raw bitmaps are held
        local bb0, fl0 = tally(recs)
        local armed0, dec0 = count(w, "bo prefetch: armed key="), w.decoded
        check("9.32 raw page: tile change clears nothing", M.coverTileChanged() == 0)
        M.prefetchNextPage(ID, 12, 12); run(w, 1.2); run(w, 3)
        check("9.32 ... the page is not armed again and nothing is decoded again",
            count(w, "bo prefetch: armed key=") == armed0 and w.decoded == dec0)
        check("9.32 ... the raw bitmaps and flags are untouched", select(1, tally(recs)) == bb0 and select(2, tally(recs)) == fl0 and bb0 == 3)
    end

    -- 9.33 mixed page: the two prescaled records are prescaled again; the declined (raw) one is released by the holder -------------
    -- (re-arming the SAME page starts a new holder generation, like any new prefetched page: its raw bitmap and flag are
    -- dropped TOGETHER, references only, nothing freed; the normal chain decodes that one record at the turn)
    do
        local w, M = presWorld()
        local recs = nrecs(1160, 3, "all"); seed(w, 12, recs)
        local round = 1
        installPresc(w, M, function(r, bb, n) if round == 1 and n == 2 then return nil, "no_dims" end return scaledStatus() end)
        armAndRun(w, M, 12)
        check("9.33 before: record 2 holds a raw bitmap (declined), 1 and 3 are prescaled",
            recs[2].cover_bb ~= nil and recs[1].cover_bb == nil and recs[3].cover_bb == nil and select(2, tally(recs)) == 3)
        round = 2
        local pc0, frees0 = #w.pcalls, w.frees
        check("9.33 tile change clears exactly the two prescaled records", M.coverTileChanged() == 2)
        check("9.33 ... the declined record is untouched by the tile change itself", recs[2].cover_bb ~= nil and recs[2]._cover_filled == true)
        armAndRun(w, M, 12)
        check("9.33 only the two cleared covers are offered to the prescaler again", #w.pcalls == pc0 + 2, #w.pcalls - pc0)
        check("9.33 the two are flagged again, without a bitmap",
            recs[1]._cover_filled == true and recs[3]._cover_filled == true and recs[1].cover_bb == nil and recs[3].cover_bb == nil)
        check("9.33 the new holder generation released the old raw record (logged once, reason=newpage)",
            count(w, "decode-ahead released n=1 reason=newpage") == 1)
        check("9.33 ... bitmap and flag together (clean, wanted by the normal chain), size fields gone too",
            recs[2].cover_bb == nil and recs[2]._cover_filled == nil and recs[2].cover_w == nil and recs[2].cover_h == nil and recs[2].has_cover == true)
        check("9.33 ... only references dropped: frees are just the two new raw bitmaps, no double free", w.frees - frees0 == 2 and w.double_free == 0, w.frees - frees0)
    end

    -- 9.34 repeated tile changes (draft regrid steps): one re-prefetch, not one per step --------------------------------------------
    do
        local w, M = presWorld()
        local recs = nrecs(1170, 3, "all"); seed(w, 12, recs)
        installPresc(w, M, scaledStatus)
        armAndRun(w, M, 12)
        local pc0 = #w.pcalls
        local a, b, c = M.coverTileChanged(), M.coverTileChanged(), M.coverTileChanged()
        check("9.34 three steps: the first clears 3, the others 0", a == 3 and b == 0 and c == 0)
        check("9.34 only one 'look at again' line", count(w, "prefetch will look at") == 1)
        M.prefetchNextPage(ID, 12, 12); M.prefetchNextPage(ID, 12, 12); M.prefetchNextPage(ID, 12, 12)
        run(w, 1.2); run(w, 3)
        check("9.34 the page is prefetched once (three prescaler calls, one more 'armed')",
            #w.pcalls == pc0 + 3 and count(w, "bo prefetch: armed key=") == 2, #w.pcalls - pc0)
        -- the re-prescaled records are tracked again: a second change repeats the cycle
        check("9.34 a LATER tile change repeats the whole cycle", M.coverTileChanged() == 3)
        armAndRun(w, M, 12)
        check("9.34 ... third prescale round", #w.pcalls == pc0 + 6 and select(2, tally(recs)) == 3 and select(1, tally(recs)) == 0, #w.pcalls - pc0)
    end

    -- 9.35 sub-setting OFF after the tile change: the re-armed page has nothing to download and nothing is decoded ------------------
    do
        local w, M = presWorld()
        local recs = nrecs(1180, 3, "all"); seed(w, 12, recs)
        installPresc(w, M, scaledStatus)
        armAndRun(w, M, 12)
        M.coverTileChanged()
        w.settings["bookorbit_prefetch_decode_ahead"] = false
        local pc0, dec0 = #w.pcalls, w.decoded
        local ok = pcall(function() armAndRun(w, M, 12) end)
        check("9.35 no error; the files are on disk, so a download-only prefetch has nothing to do",
            ok and w.decoded == dec0 and #w.pcalls == pc0)
        check("9.35 the records stay unflagged (the page turn uses the normal chain)", select(2, tally(recs)) == 0 and select(1, tally(recs)) == 0)
    end

    -- 9.36 manual refresh / stop after a tile change: nothing left over, no error ----------------------------------------------------
    do
        local w, M = presWorld()
        local recs = nrecs(1190, 2, "all"); seed(w, 12, recs)
        installPresc(w, M, scaledStatus)
        armAndRun(w, M, 12)
        M.coverTileChanged()
        check("9.36 refresh of the chip after a tile change does not error", pcall(M.invalidateNextPageCache, ID))
        check("9.36 release after a tile change does not error", pcall(M.releaseDecodeAhead, "setting"))
    end
end

sh("rm -rf " .. PROOT)


-- 8. E2 UNWIRED: the main pool's landings carry NO hold flag any more (real source, fake forks/clock) ------
do
    local function events()
        local ev = {}
        return ev, function(...) ev[#ev + 1] = { n = select("#", ...), sid = (select(1, ...)), final = (select(2, ...)), hold = (select(3, ...)) } end
    end
    local function seq(ev) local s = {}; for _, e in ipairs(ev) do s[#s + 1] = e.final and "F" or "n" end; return table.concat(s, ",") end
    local function twoArgs(ev) for _, e in ipairs(ev) do if e.n ~= 2 or e.hold ~= nil or type(e.final) ~= "boolean" then return false end end return #ev > 0 end

    -- 8.1 three covers already on disk: every landing repaints, none carries a hold
    do
        W = newWorld(); local w = W
        local M = loadSource(w)
        local ev, cb = events(); M.onCoversReady(cb)
        local recs = mkrecs(3)
        for i = 1, 3 do w.files[path(i, i)] = true end
        M.scheduleCoverFills(recs, "chipA"); run(w, 2)
        check("unwired 8.1: all three decoded without a download", filled(recs) == 3 and #w.forks == 0, #w.forks)
        check("unwired 8.1: two non-final landings then the final one", seq(ev) == "n,n,F", seq(ev))
        check("unwired 8.1: every event has exactly (source_id, final), no hold", twoArgs(ev))
    end
    -- 8.2 two on disk + one download in flight: no hold either, the download lands and ends the chain
    do
        W = newWorld(); local w = W
        local M = loadSource(w)
        local ev, cb = events(); M.onCoversReady(cb)
        local recs = mkrecs(3)
        w.files[path(1, 1)] = true; w.files[path(2, 2)] = true       -- record 3 must be downloaded
        M.scheduleCoverFills(recs, "chipA"); run(w, 0.5)
        check("unwired 8.2: one download in flight, still not finished", #w.forks == 1 and not w.forks[1].done, #w.forks)
        check("unwired 8.2: both disk hits decoded and reported without a hold", filled(recs) == 2 and seq(ev) == "n,n", seq(ev))
        finishFork(w, w.forks[1], 3); run(w, 1)
        check("unwired 8.2: the download lands and the chain ends with a final event", filled(recs) == 3 and ev[#ev].final == true, seq(ev))
        check("unwired 8.2: no event ever carried a hold", twoArgs(ev))
    end
    -- 8.3 one disk hit + downloads
    do
        W = newWorld(); local w = W
        local M = loadSource(w)
        local ev, cb = events(); M.onCoversReady(cb)
        local recs = mkrecs(2)
        w.files[path(1, 1)] = true
        M.scheduleCoverFills(recs, "chipA"); run(w, 0.5)
        check("unwired 8.3: a lone disk hit repaints at once, no hold", seq(ev) == "n" and twoArgs(ev), seq(ev))
    end
    -- 8.4 old callbacks keep working
    do
        W = newWorld(); local w = W
        local M = loadSource(w)
        local n = 0
        M.onCoversReady(function() n = n + 1 end)
        local recs = mkrecs(3)
        for i = 1, 3 do w.files[path(i, i)] = true end
        M.scheduleCoverFills(recs, "chipA"); run(w, 2)
        check("unwired 8.4: a callback without parameters still fires for every landing (2 + final)", n == 3, n)
    end
end

print(string.format("test_bo_wiring: %d passed, %d failed", passes, fails))
return fails > 0
