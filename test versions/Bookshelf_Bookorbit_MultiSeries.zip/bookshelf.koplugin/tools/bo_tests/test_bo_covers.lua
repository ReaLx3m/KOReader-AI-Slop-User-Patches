-- Cover speed, Batch 1: repaint coalescer. Off-device; no KOReader, no network.
-- Proves the LOGIC only (not run on a device). The real source/widget wiring
-- (fireCoversReady's `final` argument, the widget callback) is parse-checked only.
package.path = PLUGIN .. "/?.lua;" .. package.path
local fails, passes = 0, 0
local function check(n, c, x)
    if c then passes = passes + 1
    else fails = fails + 1; print("FAIL: " .. n .. (x ~= nil and (" -> " .. tostring(x)) or "")) end
end

local Coalesce = require("lib/bookshelf_bookorbit_coalesce")

-- Fake clock + timer queue ---------------------------------------------------
local function rig(gap, flush_fn, hold_max)
    local r = { t = 100, timers = {}, flushed = {}, unscheduled = 0 }
    r.c = Coalesce.new{
        now = function() return r.t end,
        schedule = function(delay, fn)
            local h = { at = r.t + delay, fn = fn, live = true }
            r.timers[#r.timers + 1] = h
            return h
        end,
        unschedule = function(h) if h then h.live = false end; r.unscheduled = r.unscheduled + 1 end,
        min_gap = gap,
        hold_max = hold_max,
        flush = flush_fn or function(set) r.flushed[#r.flushed + 1] = set end,
    }
    -- advance the clock, firing due timers in order
    function r.advance(dt)
        local target = r.t + dt
        while true do
            local nxt
            for _, h in ipairs(r.timers) do
                if h.live and h.at <= target and (not nxt or h.at < nxt.at) then nxt = h end
            end
            if not nxt then break end
            r.t = math.max(r.t, nxt.at)
            nxt.live = false
            nxt.fn()
        end
        r.t = target
    end
    function r.live_timers()
        local n = 0
        for _, h in ipairs(r.timers) do if h.live then n = n + 1 end end
        return n
    end
    return r
end

-- defaults -------------------------------------------------------------------
check("default gap is 0.5", Coalesce.DEFAULT_MIN_GAP == 0.5)
do
    local c = Coalesce.new{ now = function() return 0 end,
        schedule = function() return {} end, unschedule = function() end,
        flush = function() end }
    check("min_gap defaults when omitted", c.min_gap == 0.5)
end

-- leading edge ---------------------------------------------------------------
do
    local r = rig(0.5)
    check("first request flushes at once", r.c:request("a") == "flushed")
    check("  one flush", #r.flushed == 1 and r.flushed[1].a == true)
    check("  no timer", r.live_timers() == 0)
end

-- merge inside the gap -> one trailing flush ----------------------------------
do
    local r = rig(0.5)
    r.c:request("a")                     -- flush #1 at t=100
    r.advance(0.1)
    check("2nd inside gap is scheduled", r.c:request("a") == "scheduled")
    r.advance(0.1)
    check("3rd inside gap is merged", r.c:request("b") == "merged")
    r.advance(0.1)
    check("4th inside gap is merged", r.c:request("a") == "merged")
    check("  still one flush so far", #r.flushed == 1)
    check("  exactly one timer", r.live_timers() == 1)
    r.advance(0.19)
    check("  not yet at gap", #r.flushed == 1)
    r.advance(0.02)
    check("  trailing flush at last+gap", #r.flushed == 2)
    check("  merged set has both ids", r.flushed[2].a == true and r.flushed[2].b == true)
    check("  timer consumed", r.live_timers() == 0)
end

-- after the gap, leading edge again -------------------------------------------
do
    local r = rig(0.5)
    r.c:request("a")
    r.advance(0.6)
    check("request after the gap flushes at once", r.c:request("a") == "flushed")
    check("  two flushes", #r.flushed == 2)
end

-- trailing delay is measured from the last flush -------------------------------
do
    local r = rig(0.5)
    r.c:request("a")                     -- t=100
    r.advance(0.3)
    r.c:request("a")                     -- t=100.3, scheduled for 100.5
    local h = r.timers[#r.timers]
    check("trailing scheduled at last_flush+gap", math.abs(h.at - 100.5) < 1e-9, h.at)
end

-- final flushes at once and cancels the timer ----------------------------------
do
    local r = rig(0.5)
    r.c:request("a")
    r.advance(0.1)
    r.c:request("a")                     -- scheduled
    check("timer pending before final", r.live_timers() == 1)
    check("final flushes at once", r.c:request("a", true) == "flushed")
    check("  flush count 2", #r.flushed == 2)
    check("  timer cancelled", r.live_timers() == 0)
    r.advance(5)
    check("  nothing fires afterwards", #r.flushed == 2)
end

-- final as the very first request -----------------------------------------------
do
    local r = rig(0.5)
    r.c:request("a", true)
    check("final first: flushed", #r.flushed == 1)
end

-- final after gap, nothing pending is not invented -------------------------------
do
    local r = rig(0.5)
    r.c:request("a")
    r.advance(1)
    -- timer already ran / nothing pending; a final with a source still flushes it
    r.c:request("a", true)
    check("final with new source flushes", #r.flushed == 2)
end

-- nil source id -> ANY marker ------------------------------------------------------
do
    local r = rig(0.5)
    r.c:request(nil)
    check("nil id flushed as ANY", r.flushed[1][Coalesce.ANY] == true)
    check("ANY marker is \"*\"", Coalesce.ANY == "*")
end

-- cancel ------------------------------------------------------------------------
do
    local r = rig(0.5)
    r.c:request("a")
    r.advance(0.1)
    r.c:request("a")
    r.c:cancel()
    check("cancel drops the timer", r.live_timers() == 0)
    r.advance(5)
    check("cancel: nothing flushes later", #r.flushed == 1)
    -- usable again after cancel
    r.advance(1)
    check("usable after cancel", r.c:request("z") == "flushed" and #r.flushed == 2)
    check("  pending was cleared", r.flushed[2].a == nil and r.flushed[2].z == true)
end

-- flush callback that throws is swallowed; the object keeps working ----------------
do
    local n = 0
    local r = rig(0.5, function() n = n + 1; error("boom") end)
    local ok = pcall(function() r.c:request("a") end)
    check("throwing flush does not propagate", ok)
    r.advance(1)
    local ok2 = pcall(function() r.c:request("a") end)
    check("still usable after a throw", ok2 and n == 2, n)
end

-- schedule that throws or returns nil -> flush at once, never stuck -----------------
do
    local flushed = 0
    local t = 100
    local c = Coalesce.new{ now = function() return t end,
        schedule = function() error("no timer") end, unschedule = function() end,
        min_gap = 0.5, flush = function() flushed = flushed + 1 end }
    c:request("a")
    t = 100.1
    local res = c:request("a")
    check("schedule failure flushes at once", res == "flushed" and flushed == 2, res)
    local c2 = Coalesce.new{ now = function() return t end,
        schedule = function() return nil end, unschedule = function() end,
        min_gap = 0.5, flush = function() flushed = flushed + 1 end }
    c2:request("a"); t = t + 0.1
    check("schedule returning nil flushes at once", c2:request("a") == "flushed")
end

-- clock that throws or returns garbage does not break requests -----------------------
do
    local flushed = 0
    local c = Coalesce.new{ now = function() error("no clock") end,
        schedule = function() return {} end, unschedule = function() end,
        flush = function() flushed = flushed + 1 end }
    local ok = pcall(function() c:request("a") end)
    check("bad clock does not throw", ok and flushed == 1)
end

-- the real scenario: 12 requests over ~2.4 s collapse to a handful of flushes --------
do
    local r = rig(0.5)
    for i = 1, 11 do
        r.c:request("chip")              -- one batch of 2 covers every ~0.2 s
        r.advance(0.2)
    end
    r.c:request("chip", true)            -- queue ended
    local s = r.c:stats()
    check("12 requests counted", s.requests == 12, s.requests)
    check("12 requests -> at most 6 flushes (was 12)", s.flushes <= 6 and s.flushes >= 3, s.flushes)
    check("  last flush is the final one", r.live_timers() == 0)
end

-- a burst in one instant is a single flush ------------------------------------------
do
    local r = rig(0.5)
    for _ = 1, 10 do r.c:request("chip") end
    r.advance(1)
    check("instant burst: first at once + one trailing", #r.flushed == 2, #r.flushed)
end

-- zero gap flushes every request --------------------------------------------------------
do
    local r = rig(0)
    r.c:request("a"); r.c:request("a"); r.c:request("a")
    check("gap 0 flushes each request", #r.flushed == 3)
end

-- C21(a): the gap runs from the END of a flush ---------------------------------------
do
    -- A slow flush (a 0.45 s rebuild). A request right after it must NOT flush
    -- at once: 0.45 s have passed since the flush STARTED, but the gap counts
    -- from its end.
    local r
    local flush_starts = {}
    r = rig(0.5, function(set)
        flush_starts[#flush_starts + 1] = r.t
        r.t = r.t + 0.45                    -- the flush itself takes time
    end)
    check("slow flush: first request flushes at once", r.c:request("a") == "flushed")
    check("slow flush: clock advanced by the flush", math.abs(r.t - 100.45) < 1e-9, r.t)
    local ans = r.c:request("a")
    check("request right after a slow flush is not flushed at once", ans == "scheduled", ans)
    check("... and only one flush has run", #flush_starts == 1, #flush_starts)
    r.advance(0.49)
    check("trailing flush waits for the gap after the END of the flush", #flush_starts == 1, #flush_starts)
    r.advance(0.02)
    check("trailing flush fires once the gap has passed", #flush_starts == 2, #flush_starts)
    check("trailing flush started at end-of-flush + gap",
        math.abs(flush_starts[2] - 100.95) < 0.02, flush_starts[2])
end
do
    -- Same slow flush, but a request ARRIVES while the flush is running (a
    -- re-entrant request): the timer it arms must not fire at start + gap.
    local r
    local starts = {}
    local reentered = false
    r = rig(0.5, function(set)
        starts[#starts + 1] = r.t
        if not reentered then
            reentered = true
            r.c:request("b")                -- arrives mid-flush
            r.t = r.t + 0.45
        end
    end)
    r.c:request("a")
    check("re-entrant request during a slow flush is merged, not nested", #starts == 1, #starts)
    r.advance(0.2)                          -- t = start + 0.65: past start + gap, inside end + gap
    check("timer armed mid-flush waits for the gap after the flush end", #starts == 1, #starts)
    r.advance(0.4)
    check("... then flushes the merged request once", #starts == 2, #starts)
end
do
    -- A fast flush behaves exactly as before (gap from the flush, no extra wait).
    local r = rig(0.5)
    r.c:request("a")
    r.advance(0.1)
    r.c:request("a")
    r.advance(0.39)
    check("fast flush: still waiting at 0.49 s", #r.flushed == 1, #r.flushed)
    r.advance(0.02)
    check("fast flush: trailing at last_flush + gap", #r.flushed == 2, #r.flushed)
end


-- E1: hold (first repaint delayed while more decodes are queued) ---------------
check("default hold cap is 1.0", Coalesce.DEFAULT_HOLD_MAX == 1.0)
do -- leading edge held; released by hold=false
    local r = rig(0.5)
    check("hold: leading request is held, not flushed", r.c:request("a", false, true) == "held" and #r.flushed == 0)
    check("hold: one hold timer armed", r.live_timers() == 1, r.live_timers())
    check("hold: further hold requests merge", r.c:request("a", false, true) == "merged" and #r.flushed == 0)
    r.advance(0.2)
    check("hold: still held at 0.2 s", #r.flushed == 0)
    check("hold: request with hold=false flushes at once", r.c:request("a", false, false) == "flushed" and #r.flushed == 1)
    check("hold: flush cancelled the hold timer", r.live_timers() == 0, r.live_timers())
    r.advance(5)
    check("hold: no second flush from the cap timer", #r.flushed == 1, #r.flushed)
end
do -- hold=nil behaves like false
    local r = rig(0.5)
    r.c:request("a", false, true)
    check("hold: nil hold flushes the held request", r.c:request("a") == "flushed" and #r.flushed == 1)
end
do -- final flushes a held request
    local r = rig(0.5)
    r.c:request("a", false, true)
    check("hold: final flushes at once", r.c:request("a", true, true) == "flushed" and #r.flushed == 1)
    check("hold: final leaves no timer", r.live_timers() == 0)
end
do -- cap
    local r = rig(0.5, nil, 1.0)
    r.c:request("a", false, true)
    r.advance(0.99)
    check("hold: not flushed just before the cap", #r.flushed == 0)
    r.advance(0.02)
    check("hold: flushed by the cap", #r.flushed == 1, #r.flushed)
    check("hold: cap flush carries the held source", r.flushed[1] and r.flushed[1].a == true)
    check("hold: nothing left after the cap flush", r.live_timers() == 0)
end
do -- custom cap
    local r = rig(0.5, nil, 0.3)
    r.c:request("a", false, true)
    r.advance(0.31)
    check("hold: custom hold_max honoured", #r.flushed == 1, #r.flushed)
end
do -- after the hold flush the normal throttle applies
    local r = rig(0.5)
    r.c:request("a", false, true)
    r.advance(0.1)
    r.c:request("a", false, false)             -- flush at t0+0.1
    check("after hold: flushed once", #r.flushed == 1)
    r.advance(0.1)
    check("after hold: next request inside the gap is scheduled as before", r.c:request("a", false, true) == "scheduled")
    r.advance(0.5)
    check("after hold: trailing flush as before", #r.flushed == 2, #r.flushed)
end
do -- hold inside the min_gap window: unchanged (no hold timer, trailing as before)
    local r = rig(0.5)
    r.c:request("a")                           -- flush
    r.advance(0.1)
    check("hold inside the gap: scheduled, not held", r.c:request("a", false, true) == "scheduled")
    r.advance(0.39)
    check("hold inside the gap: not flushed early", #r.flushed == 1)
    r.advance(0.02)
    check("hold inside the gap: trailing flush at gap end", #r.flushed == 2, #r.flushed)
end
do -- hold after a full gap held again (new burst)
    local r = rig(0.5)
    r.c:request("a")
    r.advance(0.6)
    check("hold after a full gap: held again", r.c:request("b", false, true) == "held")
    r.c:request("b", true)
    check("hold: second burst flushed by final", #r.flushed == 2)
end
do -- cancel drops the hold timer and the pending request
    local r = rig(0.5)
    r.c:request("a", false, true)
    r.c:cancel()
    check("hold: cancel clears the hold timer", r.live_timers() == 0)
    r.advance(5)
    check("hold: nothing flushed after cancel", #r.flushed == 0)
    check("hold: usable after cancel", r.c:request("a", false, true) == "held")
end
do -- no timer available: do not hold at all
    local flushed = 0
    local c = Coalesce.new{ now = function() return 1 end, schedule = function() return nil end,
        unschedule = function() end, flush = function() flushed = flushed + 1 end }
    check("hold: no timer -> flushed at once", c:request("a", false, true) == "flushed" and flushed == 1)
end
do -- default path unchanged: no hold argument = leading flush
    local r = rig(0.5)
    check("no hold argument: leading edge flushes as always", r.c:request("a") == "flushed" and #r.flushed == 1 and r.live_timers() == 0)
end
do -- cap timer fires after a merge: still one flush with all sources
    local r = rig(0.5)
    r.c:request("a", false, true)
    r.c:request("b", false, true)
    r.advance(1.01)
    check("hold: cap flush merges all held sources", #r.flushed == 1 and r.flushed[1].a and r.flushed[1].b)
end


-- E2 UNWIRED (user request: keep the plain 2-3 repaints per page turn). The pure hold pieces stay in
-- coverpool/coalesce (tested above); these static checks pin that NOTHING passes or forwards `hold` any more.
do
    local function slurp(rel) local f = io.open(PLUGIN .. "/" .. rel, "rb"); if not f then return "" end local s = f:read("*a"); f:close(); return s end
    local src = slurp("lib/bookshelf_bookorbit_source.lua")
    local wid = slurp("lib/bookshelf_widget.lua")
    check("unwired static: fireCoversReady takes (source_id, final) only", src:find("function fireCoversReady(source_id, final)", 1, true) ~= nil and src:find("function fireCoversReady(source_id, final, hold)", 1, true) == nil)
    check("unwired static: the callback gets two arguments, no hold", src:find("pcall(_covers_ready_cb, source_id, final and true or false)", 1, true) ~= nil and src:find("hold and true or false", 1, true) == nil)
    check("unwired static: main pool on_landed ignores decode_left", src:find("on_landed = function(source_id, final)", 1, true) ~= nil and src:find("on_landed = function(source_id, final, decode_left)", 1, true) == nil)
    check("unwired static: main pool fires every landing without a hold flag", src:find("            fireCoversReady(source_id, final)\n", 1, true) ~= nil and src:find("decode_left", 1, true) == nil)
    check("unwired static: inline fill calls stay as they were",
        src:find("fireCoversReady(source_id, true) end", 1, true) ~= nil and src:find("fireCoversReady(source_id, false)", 1, true) ~= nil)
    check("unwired static: the prefetch pool still never repaints", src:find("on_landed = function() end", 1, true) ~= nil)
    check("unwired static: widget has no COVER_HOLD_MAX_S and no hold_max", wid:find("COVER_HOLD_MAX_S", 1, true) == nil and wid:find("hold_max", 1, true) == nil)
    check("unwired static: widget callback takes (source_id, final) and requests without hold",
        wid:find("onCoversReady(function(source_id, final)", 1, true) ~= nil
        and wid:find("coalescer:request(source_id, final)", 1, true) ~= nil
        and wid:find("coalescer:request(source_id, final, hold)", 1, true) == nil)
    check("unwired static: the inactive-batch filter still runs before the coalescer",
        (function() local a = wid:find("if not self:_isActiveBookorbitBatch(source_id) then return end", 1, true)
            local b = wid:find("coalescer:request(source_id, final)", 1, true)
            return a ~= nil and b ~= nil and a < b end)())
    check("unwired static: coalescer still cancelled on widget teardown", wid:find("self._bo_cover_coalescer:cancel()", 1, true) ~= nil)
    check("unwired static: the pure hold pieces are still there (unused)",
        slurp("lib/bookshelf_bookorbit_coalesce.lua"):find("hold_max", 1, true) ~= nil
        and slurp("lib/bookshelf_bookorbit_coverpool.lua"):find("decode_left", 1, true) ~= nil)
end

-- S3: scale covers ahead, widget + SpineWidget side.
-- Part 1 RUNS the real source text of the SpineWidget pieces (extracted from the file,
-- loaded against stubs: SpineWidget itself is not loadable off-device).
-- Part 2 is static: the widget is read as text. NOT run on a device.
do
    local function slurp(rel) local f = io.open(PLUGIN .. "/" .. rel, "rb"); if not f then return "" end local s = f:read("*a"); f:close(); return s end
    local spine = slurp("lib/bookshelf_spine_widget.lua")
    local wid   = slurp("lib/bookshelf_widget.lua")
    local row   = slurp("lib/bookshelf_shelf_row.lua")
    -- Text of one top-level function: from `start_pat` up to the first "\nend\n" at column 0.
    local function extract(start_pat)
        local a = spine:find(start_pat, 1, true)
        if not a then return nil end
        local b = spine:find("\nend\n", a, true)
        if not b then return nil end
        return spine:sub(a, b + 4)
    end
    local parts = {
        extract("local function _coverFillBB(bb, img_w, img_h)"),
        extract("function SpineWidget:_noShadow()"),
        extract("function SpineWidget:_cardDimensions()"),
        extract("function SpineWidget.imageDims(width, height)"),
        extract("function SpineWidget.fillScale(bb, img_w, img_h)"),
    }
    local all_found = true
    for i = 1, 5 do if not parts[i] then all_found = false end end
    check("S3 spine: the five pieces were found in the source", all_found)

    if all_found then
        local settings = { cover_no_shadow = false }
        local BookshelfSettings = { read = function(k, d) local v = settings[k]; if v == nil then return d end return v end }
        local made = {}   -- every fake bitmap, in creation order
        local function newbb(w, h, t)
            local bb = { w = w, h = h, t = t or "rgb", freed = 0, scaled_to = nil, blits = {} }
            function bb:getWidth() return self.w end
            function bb:getHeight() return self.h end
            function bb:getType() return self.t end
            function bb:free() self.freed = self.freed + 1 end
            function bb:scale(nw, nh) local r = newbb(nw, nh, self.t); r.scaled_from = self; made[#made + 1] = r; return r end
            function bb:blitFrom(src, dx, dy, sx, sy, w2, h2) self.blits[#self.blits + 1] = { src = src, dx = dx, dy = dy, sx = sx, sy = sy, w = w2, h = h2 } end
            return bb
        end
        local Blitbuffer = { new = function(w, h, t) local b = newbb(w, h, t); made[#made + 1] = b; return b end }
        local SpineWidget = {}
        local prefix = "local SpineWidget, BookshelfSettings, Blitbuffer, SHADOW_OFFSET, CARD_BORDER = ...\n"
        local code = prefix .. parts[1] .. "\n" .. parts[2] .. "\n" .. parts[3] .. "\n" .. parts[4] .. "\n" .. parts[5] .. "\nreturn SpineWidget\n"
        local chunk, err = load(code, "=spine_pieces", "t")
        check("S3 spine: the extracted pieces compile (" .. tostring(err) .. ")", chunk ~= nil)
        if chunk then
            -- SHADOW_OFFSET 5 / CARD_BORDER 2 on purpose: not the production numbers, so a copy of
            -- a literal inside imageDims would be caught.
            local ok, SW = pcall(chunk, SpineWidget, BookshelfSettings, Blitbuffer, 5, 2)
            check("S3 spine: the pieces load", ok and SW == SpineWidget)

            -- imageDims = _cardDimensions minus the border on both sides
            local iw, ih = SW.imageDims(100, 150)
            check("S3 imageDims: shadow reserved (100x150 -> 100-5-4 x 150-5-4)", iw == 91 and ih == 141)
            local real = setmetatable({ width = 100, height = 150 }, { __index = SW })
            local cw, chh = real:_cardDimensions()
            check("S3 imageDims: equals _cardDimensions of a real box minus 2*CARD_BORDER", iw == cw - 4 and ih == chh - 4)
            settings.cover_no_shadow = true
            local nw, nh = SW.imageDims(100, 150)
            check("S3 imageDims: 'no shadow' setting gives the whole slot minus borders", nw == 96 and nh == 146)
            local real2 = setmetatable({ width = 100, height = 150 }, { __index = SW })
            local cw2, ch2 = real2:_cardDimensions()
            check("S3 imageDims: still equals _cardDimensions with no shadow", nw == cw2 - 4 and nh == ch2 - 4)
            settings.cover_no_shadow = false
            local a1, b1 = SW.imageDims(118 + 5 + 4, 158 + 5 + 4)
            check("S3 imageDims: a box built from a wanted image size gives that size back", a1 == 118 and b1 == 158)
            local pw, ph = 100, 150
            SW.imageDims(pw, ph)
            check("S3 imageDims: pure (inputs untouched, no instance state kept)", pw == 100 and ph == 150 and rawget(SW, "width") == nil and rawget(SW, "height") == nil)

            -- fillScale = _coverFillBB (same crop logic), never frees the source
            local portrait = newbb(200, 300)
            local r1 = SW.fillScale(portrait, 118, 158)
            check("S3 fillScale: portrait is stretched to exactly the image size", r1.w == 118 and r1.h == 158 and r1.scaled_from == portrait)
            check("S3 fillScale: portrait source is not freed", portrait.freed == 0)

            local land = newbb(400, 200)
            local before = #made
            local r2 = SW.fillScale(land, 100, 150)
            check("S3 fillScale: landscape comes out exactly the image size (centre-cropped)", r2.w == 100 and r2.h == 150)
            local blit = r2.blits[1]
            -- scaled width = floor(400*150/200) = 300; centre crop x_off = (300-100)/2 = 100
            check("S3 fillScale: landscape crop is centred (x_off 100 of 300)", blit ~= nil and blit.sx == 100 and blit.w == 100 and blit.h == 150 and blit.src.w == 300)
            check("S3 fillScale: the intermediate is freed once, the source never", blit ~= nil and blit.src.freed == 1 and land.freed == 0)
            check("S3 fillScale: landscape keeps the bitmap type", r2.t == land.t)

            local square = newbb(300, 300)
            local r3 = SW.fillScale(square, 100, 150)
            check("S3 fillScale: square source is cropped, not squashed", r3.w == 100 and r3.h == 150 and r3.blits[1] ~= nil and r3.blits[1].src.w == 150)

            local wide = newbb(120, 80)
            local r4 = SW.fillScale(wide, 100, 150)
            check("S3 fillScale: always exactly img_w x img_h", r4.w == 100 and r4.h == 150)
        end
    end

    -- ---- static: SpineWidget exports and untouched neighbours
    check("S3 static: SpineWidget.imageDims asks _cardDimensions and subtracts CARD_BORDER on both sides",
        spine:find("local card_w, card_h = proto:_cardDimensions()", 1, true) ~= nil
        and spine:find("return card_w - 2 * CARD_BORDER, card_h - 2 * CARD_BORDER", 1, true) ~= nil)
    check("S3 static: SpineWidget.fillScale delegates to _coverFillBB", spine:find("return _coverFillBB(bb, img_w, img_h)", 1, true) ~= nil)
    check("S3 static: _coverFillBB is still defined exactly once (not copied)", select(2, spine:gsub("local function _coverFillBB%(", "")) == 1)
    check("S3 static: _cardDimensions shadow reservation unchanged",
        spine:find("return self.width - SHADOW_OFFSET, self.height - SHADOW_OFFSET", 1, true) ~= nil
        and spine:find("(self:_noShadow() and not self.flat_card and not self.force_shadow) then", 1, true) ~= nil)
    check("S3 static: _renderCover still derives img size from _cardDimensions and CARD_BORDER",
        spine:find("local img_w = card_w - 2 * border", 1, true) ~= nil and spine:find("local img_h = card_h - 2 * border", 1, true) ~= nil)

    -- ---- static: the widget block
    local a = wid:find("-- Scale covers ahead (prescale S3).", 1, true)
    local b = wid:find("-- Async page fetch (HANDOFF_cover_speed Phase 2, Batch 6).", 1, true)
    local blk = (a and b and b > a) and wid:sub(a, b - 1) or ""
    check("S3 static: the prescale block exists in the widget init", blk ~= "")
    local cov_a = wid:find("BOSource_init.onCoversReady(function(source_id, final)", 1, true)
    check("S3 static: it sits after the onCoversReady registration and before onPageReady",
        cov_a ~= nil and a ~= nil and b ~= nil and cov_a < a and a < b)
    check("S3 static: registered only when the source offers the hook",
        blk:find("if ok_bo_init and BOSource_init.setCoverPrescaler then", 1, true) ~= nil)
    check("S3 static: uses the S1 pure module", blk:find('require("lib/bookshelf_bookorbit_prescale")', 1, true) ~= nil and blk:find("Prescale.new{", 1, true) ~= nil)
    check("S3 static: hook is registered with (record, bb) and returns what run returns",
        blk:find("BOSource_init.setCoverPrescaler(function(record, bb)", 1, true) ~= nil and blk:find("return prescale:run(record, bb)", 1, true) ~= nil)
    check("S3 static: hook stands down when the widget is closed or no longer live, before running",
        (function()
            local g = blk:find("if self._closed or BookshelfWidget.live ~= self then return nil end\n            return prescale:run", 1, true)
            return g ~= nil
        end)())
    check("S3 static: dims callback is guarded the same way", blk:find("dims = function(record)\n                if self._closed or BookshelfWidget.live ~= self then return nil end", 1, true) ~= nil)
    check("S3 static: grid (Covers) mode only, checked on the view AND on the dims' own mode stamp",
        blk:find("if self:_viewMode() ~= ViewMode.COVERS then return nil end", 1, true) ~= nil
        and blk:find("if not d or d.view_mode ~= ViewMode.COVERS then return nil end", 1, true) ~= nil)
    check("S3 static: tile size is the one the shelf reported (_shelf_dims.cover_w/cover_h)",
        blk:find("local d = self._shelf_dims", 1, true) ~= nil and blk:find("local slot_w, cover_h = d.cover_w, d.cover_h", 1, true) ~= nil)
    check("S3 static: never the derived fallback _currentSlotDims", blk:find("_currentSlotDims()", 1, true) == nil)
    check("S3 static: declines on missing or non-positive dims",
        blk:find('type(slot_w) ~= "number" or type(cover_h) ~= "number"', 1, true) ~= nil and blk:find("slot_w < 1 or cover_h < 1", 1, true) ~= nil)
    -- same per-book helper calls as ShelfRow (R-S3)
    check("S3 static: ShelfRow still sizes a tile with isTrue(true_cover_aspect) + trueAspectBoxHeight(slot_w, item, cover_h)",
        row:find('BookshelfSettings.isTrue("true_cover_aspect")', 1, true) ~= nil
        and row:find("spine_h = SpineWidget.trueAspectBoxHeight(slot_w, item, cover_h)", 1, true) ~= nil)
    check("S3 static: the prescaler uses the same setting and helper per record",
        blk:find('if BookshelfSettings.isTrue("true_cover_aspect") then', 1, true) ~= nil
        and blk:find("spine_h = SpineWidget.trueAspectBoxHeight(slot_w, record, cover_h)", 1, true) ~= nil)
    check("S3 static: image size comes from SpineWidget.imageDims on the per-book box height",
        blk:find("return SpineWidget.imageDims(slot_w, spine_h)", 1, true) ~= nil)
    check("S3 static: scale is SpineWidget.fillScale (never a plain bb:scale)",
        blk:find("scale = function(bb, w, h) return SpineWidget.fillScale(bb, w, h) end", 1, true) ~= nil
        and blk:find(":scale(", 1, true) == nil)
    check("S3 static: has() reads the cache and compares BOTH axes against the wanted size",
        blk:find("ScaledCoverCache:get(fp)", 1, true) ~= nil
        and blk:find("cached:getWidth() >= w and cached:getHeight() >= h", 1, true) ~= nil)
    check("S3 static: put() goes through ScaledCoverCache:put (the disk write-through)", blk:find("return ScaledCoverCache:put(fp, scaled)", 1, true) ~= nil)
    check("S3 static: a wall clock is injected (not the os.clock default)", blk:find("now = _gettime,", 1, true) ~= nil)
    check("S3 static: the logger is adapted to KOReader's plain logger.dbg",
        blk:find("logger = { dbg = function(_self, ...) logger.dbg(...) end },", 1, true) ~= nil)
    check("S3 static: the block frees nothing itself", blk:find(":free()", 1, true) == nil)

    -- ---- static: teardown
    local t0 = wid:find("function BookshelfWidget:onCloseWidget()", 1, true)
    local t1 = t0 and wid:find("if BookshelfWidget.live == self then BookshelfWidget.live = nil end", t0, true)
    local tb = (t0 and t1) and wid:sub(t0, t1) or ""
    check("S3 static: teardown clears the prescaler", tb:find("pcall(BOSource.setCoverPrescaler, nil)", 1, true) ~= nil)
    check("S3 static: ...only while this widget is still live, and before live is cleared",
        tb:find("and BookshelfWidget.live == self then\n            pcall(BOSource.setCoverPrescaler, nil)", 1, true) ~= nil)
    check("S3 static: the hook is registered once in the widget (no second registration path)",
        select(2, wid:gsub("BOSource_init%.setCoverPrescaler%(function", "")) == 1)
    check("S3 static: the source exports the hook the widget registers (S2) with the (record, bb) call shape",
        slurp("lib/bookshelf_bookorbit_source.lua"):find("function M.setCoverPrescaler(fn)", 1, true) ~= nil
        and slurp("lib/bookshelf_bookorbit_source.lua"):find("pcall(fn, record, bb)", 1, true) ~= nil)
end

-- S4: tile size changes. The REAL text of BookshelfWidget:_syncCoverTile is extracted from the widget
-- and RUN against stubs (the widget is not loadable off-device); the two call sites are checked as text.
-- NOT run on a device.
do
    local function slurp(rel) local f = io.open(PLUGIN .. "/" .. rel, "rb"); if not f then return "" end local s = f:read("*a"); f:close(); return s end
    local wid = slurp("lib/bookshelf_widget.lua")
    local a = wid:find("function BookshelfWidget:_syncCoverTile()", 1, true)
    local b = a and wid:find("\nend\n", a, true)
    local body = (a and b) and wid:sub(a, b + 4) or ""
    check("S4 widget: _syncCoverTile found in the widget", body ~= "")

    if body ~= "" then
        local settings = { true_cover_aspect = false, cover_no_shadow = false }
        local BookshelfSettings = {
            isTrue = function(k) return settings[k] == true end,
            read = function(k, d) local v = settings[k]; if v == nil then return d end return v end,
        }
        local ViewMode = { COVERS = "covers", LIST = "list", SPINES = "spines" }
        local calls, mode = 0, "ok"        -- mode: ok | throws | missing | norequire
        local Source = { coverTileChanged = function() calls = calls + 1; if mode == "throws" then error("boom") end end }
        local function fakeRequire(name)
            assert(name == "lib/bookshelf_bookorbit_source", "unexpected require " .. tostring(name))
            if mode == "norequire" then error("module not found") end
            if mode == "missing" then return {} end
            return Source
        end
        local prefix = "local BookshelfWidget, ViewMode, BookshelfSettings, require = ...\n"
        local chunk, err = load(prefix .. body .. "\nreturn BookshelfWidget\n", "=sync_tile", "t")
        check("S4 widget: the extracted function compiles (" .. tostring(err) .. ")", chunk ~= nil)
        if chunk then
            local function fresh()
                local BW = {}
                chunk(BW, ViewMode, BookshelfSettings, fakeRequire)
                return BW
            end
            local function inst(BW, d) return setmetatable({ _shelf_dims = d }, { __index = BW }) end
            local function covers(w, h) return { view_mode = ViewMode.COVERS, cover_w = w, cover_h = h } end

            local BW = fresh()
            local s1 = inst(BW, covers(118, 158))
            s1:_syncCoverTile()
            check("S4 sync: the first call only records the geometry (nothing to invalidate yet)", calls == 0)
            s1:_syncCoverTile()
            check("S4 sync: the same geometry again does nothing", calls == 0)
            s1._shelf_dims = covers(100, 158); s1:_syncCoverTile()
            check("S4 sync: a different cover width notifies the source once", calls == 1, calls)
            s1:_syncCoverTile()
            check("S4 sync: ... and only once (the new geometry is remembered)", calls == 1, calls)
            s1._shelf_dims = covers(100, 140); s1:_syncCoverTile()
            check("S4 sync: a different cover height notifies", calls == 2, calls)
            settings.true_cover_aspect = true; s1:_syncCoverTile()
            check("S4 sync: toggling 'true cover aspect' notifies (per-book box heights change)", calls == 3, calls)
            settings.true_cover_aspect = false; s1:_syncCoverTile()
            check("S4 sync: ... and toggling it back notifies again", calls == 4, calls)
            settings.cover_no_shadow = true; s1:_syncCoverTile()
            check("S4 sync: toggling the shadow ('cover_no_shadow') notifies (the painted image size changes)", calls == 5, calls)
            settings.cover_no_shadow = false; s1:_syncCoverTile()
            check("S4 sync: ... and back", calls == 6, calls)

            -- view mode
            s1._shelf_dims = { view_mode = ViewMode.LIST, cover_w = 40, cover_h = 60 }; s1:_syncCoverTile()
            check("S4 sync: switching to list view notifies (nothing there paints a grid tile)", calls == 7, calls)
            s1._shelf_dims = { view_mode = ViewMode.LIST, cover_w = 41, cover_h = 61 }; s1:_syncCoverTile()
            check("S4 sync: list dims moving around inside list view do not notify", calls == 7, calls)
            s1._shelf_dims = covers(100, 140); s1:_syncCoverTile()
            check("S4 sync: back to the grid notifies (covers prescaled for the old grid are stale)", calls == 8, calls)

            -- not ready / odd dims count as 'other', never as a covers geometry
            s1._shelf_dims = nil; s1:_syncCoverTile()
            check("S4 sync: no stash at all is the 'other' state (and notifies once from the grid)", calls == 9, calls)
            s1._shelf_dims = { view_mode = ViewMode.COVERS, cover_w = nil, cover_h = nil }; s1:_syncCoverTile()
            check("S4 sync: a grid stash without reported dims is still 'other' (no notify, no error)", calls == 9, calls)
            s1._shelf_dims = { view_mode = ViewMode.COVERS, cover_w = "118", cover_h = 158 }; s1:_syncCoverTile()
            check("S4 sync: non-number dims are 'other' too", calls == 9, calls)

            -- the signature lives on the CLASS: a reopened shelf at the same geometry invalidates nothing
            local BW2 = fresh()
            local a1 = inst(BW2, covers(118, 158)); a1:_syncCoverTile()
            local c0 = calls
            local a2 = inst(BW2, covers(118, 158)); a2:_syncCoverTile()
            check("S4 sync: a second widget instance at the same geometry does not notify (class-level signature)", calls == c0, calls - c0)
            local a3 = inst(BW2, covers(120, 158)); a3:_syncCoverTile()
            check("S4 sync: ... but one with a different geometry does", calls == c0 + 1, calls - c0)
            check("S4 sync: two separate classes do not share state (the signature is not a global)", rawget(_G, "_cover_tile_sig") == nil)

            -- robustness: the notification can never break a build
            local BW3 = fresh()
            local b1 = inst(BW3, covers(118, 158)); b1:_syncCoverTile()
            mode = "throws"
            local c1 = calls
            b1._shelf_dims = covers(90, 158)
            check("S4 sync: a throwing source does not propagate", pcall(b1._syncCoverTile, b1))
            check("S4 sync: ... it was called once", calls == c1 + 1, calls - c1)
            check("S4 sync: ... and the geometry was still recorded (no repeated notification on the next build)",
                (function() local c = calls; b1:_syncCoverTile(); return calls == c end)())
            mode = "missing"
            b1._shelf_dims = covers(80, 158)
            check("S4 sync: an older source without coverTileChanged is harmless", pcall(b1._syncCoverTile, b1))
            mode = "norequire"
            b1._shelf_dims = covers(70, 158)
            check("S4 sync: a source that cannot be required is harmless", pcall(b1._syncCoverTile, b1))
            mode = "ok"
        end

        -- ---- static: what the function reads, and what it must not do
        check("S4 static: the signature reads the view mode, both reported cover dims and both size settings",
            body:find("d.view_mode == ViewMode.COVERS", 1, true) and body:find("d.cover_w", 1, true) and body:find("d.cover_h", 1, true)
            and body:find('BookshelfSettings.isTrue("true_cover_aspect")', 1, true)
            and body:find('BookshelfSettings.read("cover_no_shadow", false) == true', 1, true))
        check("S4 static: the signature is kept on the class, not on the instance",
            body:find("BookshelfWidget._cover_tile_sig", 1, true) and not body:find("self._cover_tile_sig", 1, true))
        check("S4 static: the source is reached through pcall and pcall(BOSource.coverTileChanged)",
            body:find('pcall(require, "lib/bookshelf_bookorbit_source")', 1, true) and body:find("pcall(BOSource.coverTileChanged)", 1, true))
        check("S4 static: the helper builds, frees and schedules nothing",
            not body:find(":free(", 1, true) and not body:find("UIManager", 1, true) and not body:find("_rebuild", 1, true)
            and not body:find("ScaledCoverCache", 1, true))
    end

    -- ---- static: the two call sites (a shelf build and an in-place swap), nothing else
    check("S4 static: _syncCoverTile is called exactly twice", select(2, wid:gsub("self:_syncCoverTile%(%)", "")) == 2)
    local stash = wid:find("wipe_rows_top        = pre_rows_h - label_h,", 1, true)
    local c1 = stash and wid:find("self:_syncCoverTile()", stash, true)
    check("S4 static: call 1 is right after the _shelf_dims stash of a build, before the overlap group is stored",
        c1 ~= nil and c1 - stash < 200 and wid:find("self._overlap_group = overlap_group", c1, true) - c1 < 200)
    local sw = wid:find("d.cover_h = rows[1].cover_h", 1, true)
    local c2 = sw and wid:find("self:_syncCoverTile()", sw, true)
    check("S4 static: call 2 is right after the swap refreshes d.cover_w / d.cover_h", c2 ~= nil and c2 - sw < 200)
    check("S4 static: the widget reaches coverTileChanged only through that helper",
        select(2, wid:gsub("BOSource%.coverTileChanged", "")) == 2 and select(2, wid:gsub("pcall%(BOSource%.coverTileChanged%)", "")) == 1)
    check("S4 static: the prescaler's dims still come from the stash the build reported (S3 unchanged)",
        wid:find("local slot_w, cover_h = d.cover_w, d.cover_h", 1, true) ~= nil)
    check("S4 static: the source exports the function the widget calls",
        slurp("lib/bookshelf_bookorbit_source.lua"):find("function M.coverTileChanged()", 1, true) ~= nil)
end

print(string.format("test_bo_covers: %d passed, %d failed", passes, fails))
return fails > 0
