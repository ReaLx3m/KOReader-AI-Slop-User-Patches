-- Pull on wake (Batch 6B). Off-device: radio, scheduler, BookOrbit and the
-- prompt are fakes; time is virtual. Proves the LOGIC only; wake timing and
-- Wi-Fi bring-up on real devices are NOT verified (not run on a device).
package.path = PLUGIN .. "/?.lua;" .. package.path
local fails, passes = 0, 0
local function check(n, c, x)
    if c then passes = passes + 1
    else fails = fails + 1; print("FAIL: " .. n .. (x ~= nil and (" -> " .. tostring(x)) or "")) end
end
package.preload["logger"] = function() return { warn = function() end, info = function() end, dbg = function() end, err = function() end } end

local function newUI()
    local ui = { t = 0, q = {} }
    function ui:scheduleIn(secs, fn) table.insert(self.q, { at = self.t + secs, fn = fn }) end
    function ui:nextTick(fn) self:scheduleIn(0, fn) end
    function ui:unschedule(fn)
        for i = #self.q, 1, -1 do if self.q[i].fn == fn then table.remove(self.q, i) end end
    end
    function ui:advance(secs)
        local target = self.t + secs
        while true do
            local best, bi
            for i, e in ipairs(self.q) do
                if e.at <= target and (not best or e.at < best.at) then best, bi = e, i end
            end
            if not best then break end
            table.remove(self.q, bi)
            self.t = math.max(self.t, best.at)
            best.fn()
        end
        self.t = target
    end
    return ui
end

local function newNet(ui, o)
    o = o or {}
    local n = { wifi_on = o.wifi_on or false, online = o.online or false, connect_after = o.connect_after,
                restore_calls = 0, disable_calls = 0 }
    function n:isWifiOn() return self.wifi_on end
    function n:isOnline() return self.online end
    function n:restoreWifiAsync()
        self.restore_calls = self.restore_calls + 1
        self.wifi_on = true
        if self.connect_after then ui:scheduleIn(self.connect_after, function() self.online = true end) end
    end
    function n:scheduleConnectivityCheck() end
    function n:enableWifi() end
    function n:disableWifi() self.disable_calls = self.disable_calls + 1; self.wifi_on = false; self.online = false end
    return n
end

local Wifi = require("lib/bookshelf_bookorbit_wifi")
local Wake = require("lib/bookshelf_bookorbit_wake")

-- o: off_in_book, auto_wifi, pull_on_wake (default on), configured, auto_sync, verdict ("clear"|"ahead"|"unknown"),
--    book (true), compared (true), net={connect_after=}, defer_jobs, submit_throws, locked
local function env(o)
    o = o or {}
    local ui = newUI()
    local net = newNet(ui, o.net == nil and { connect_after = 2 } or o.net)
    local cfg = { enabled = o.auto_wifi ~= false, off_in_book = o.off_in_book ~= false }
    local w = Wifi.new{
        network = net, ui = ui,
        settings = { enabled = function() return cfg.enabled end,
                     off_in_book = function() return cfg.enabled and cfg.off_in_book end,
                     can_restore = function() return true end },
    }
    w:noteBookOpened()
    local bo = { checks = {}, jobs = 0, verdict = o.verdict or "clear", queued = {},
                 conf = o.configured ~= false, sync = o.auto_sync ~= false, wifi_on = o.auto_wifi ~= false,
                 remote = { percentage = 0.8, progress = "xp9", device_id = "other" } }
    function bo.isConfigured() return bo.conf end
    function bo.autoSyncEnabled() return bo.sync end
    function bo.autoWifiEnabled() return cfg.enabled end
    -- Effective value, like the real module: parent AND the wake switch.
    function bo.autoWifiPullOnWake() return cfg.enabled and o.pull_on_wake ~= false end
    function bo.getBookHash(fp) return "hash:" .. fp end
    function bo.checkServerBeforePush(fp, pct, pos)
        table.insert(bo.checks, { fp = fp, pct = pct, pos = pos, radio = net.wifi_on })
        if bo.verdict == "ahead" then return "ahead", bo.remote end
        if bo.verdict == "unknown" then return "unknown", nil, "timeout" end
        return "clear", nil, nil
    end
    function bo.submitSyncJob(job)
        if o.submit_throws then error("boom") end
        bo.jobs = bo.jobs + 1
        if o.defer_jobs then table.insert(bo.queued, job); return "queued" end
        pcall(job.run)
        if job.cleanup then job.cleanup() end
        return "started"
    end
    local state = { book = o.book ~= false and "/b/a.epub" or nil, compared = o.compared ~= false,
                    offers = {}, device = { screen_saver_lock = o.locked and true or nil } }
    local wk = Wake.new{
        bookorbit = bo, wifi = w, ui = ui, device = state.device,
        now = function() return ui.t end,
        target = function()
            if not (state.book and state.compared) then return nil end
            return state.book, 0.42, "xp1"
        end,
        same_book = function(fp) return state.book == fp end,
        offer = function(fp, remote, done) table.insert(state.offers, { fp = fp, remote = remote }); done() end,
    }
    return wk, w, ui, net, bo, state, cfg
end

-- W1 remote ahead: one pull, one offer, radio off again (sub-setting 1 on)
do
    local wk, w, ui, net, bo, st = env{ verdict = "ahead", off_in_book = true }
    check("W1a onWake starts", wk:onWake() == "started")
    ui:advance(10)
    check("W1b pulled once, with the live place and the radio up", #bo.checks == 1 and bo.checks[1].radio
        and bo.checks[1].pct == 0.42 and bo.checks[1].pos == "xp1")
    check("W1c newer place offered once", #st.offers == 1 and st.offers[1].remote.progress == "xp9")
    check("W1d no lease left, radio off again (sub 1 on)", w.count == 0 and not net.wifi_on)
    check("W1e wake no longer pending", wk.pending == false)
end

-- W2 not ahead: no prompt
do
    local wk, w, ui, net, bo, st = env{ verdict = "clear" }
    wk:onWake(); ui:advance(10)
    check("W2 not ahead: pulled, no prompt, no lease", #bo.checks == 1 and #st.offers == 0 and w.count == 0)
end

-- W3 failed pull is quiet (D21)
do
    local wk, w, ui, net, bo, st = env{ verdict = "unknown" }
    wk:onWake(); ui:advance(10)
    check("W3 failed pull: quiet, no prompt, no lease, stats", #st.offers == 0 and w.count == 0 and wk.stats.failed == 1)
end

-- W4 one wake = one pull; a later wake pulls again (D18: no minimum sleep)
do
    local wk, w, ui, net, bo, st = env{ verdict = "clear" }
    local a = wk:onWake()
    local b = wk:onWake()            -- LeaveStandby for the same wake, while pending
    local n = 0
    while wk.pending and n < 30 do ui:advance(1); n = n + 1 end
    local c = wk:onWake()            -- right after it resolved: same wake, cooldown
    ui:advance(1)
    check("W4a Resume + LeaveStandby pull once", a == "started" and b == "duplicate" and c == "duplicate" and #bo.checks == 1,
        tostring(a) .. "/" .. tostring(b) .. "/" .. tostring(c) .. "/" .. #bo.checks)
    ui:advance(10)                   -- a later, separate wake
    local d = wk:onWake()
    ui:advance(10)
    check("W4b a later wake pulls again, however short the sleep", d == "started" and #bo.checks == 2)
end

-- W5 settings gate (D19)
do
    local wk, w, ui, net, bo = env{ auto_wifi = false }
    check("W5a Auto Wi-Fi off: nothing", wk:onWake() == "disabled" and net.restore_calls == 0 and #bo.checks == 0)
    wk, w, ui, net, bo = env{ pull_on_wake = false }
    check("W5a2 Pull progress on wake off (Auto Wi-Fi on): nothing", wk:onWake() == "disabled" and net.restore_calls == 0 and #bo.checks == 0)
    wk, w, ui, net, bo = env{ configured = false }
    check("W5b not configured: nothing", wk:onWake() == "disabled" and net.restore_calls == 0)
    wk, w, ui, net, bo = env{ auto_sync = false }
    check("W5c auto-sync off: nothing", wk:onWake() == "disabled" and net.restore_calls == 0)
end

-- W6 no book / not weighed yet (reader still opening)
do
    local wk, w, ui, net, bo = env{ book = false }
    check("W6a no book open: nothing", wk:onWake() == "no_book" and net.restore_calls == 0)
    wk, w, ui, net, bo = env{ compared = false }
    check("W6b place not weighed yet: nothing (pull-on-open owns it)", wk:onWake() == "no_book" and net.restore_calls == 0)
end

-- W7 manual off is cleared (D20)
do
    local wk, w, ui, net, bo, st = env{ verdict = "ahead" }
    w.manual_off = true
    wk:onWake(); ui:advance(10)
    check("W7 manual off cleared, pull done", w.manual_off == false and #bo.checks == 1 and #st.offers == 1)
end

-- W8 radio afterwards: off with sub 1, stays on without
do
    local wk, w, ui, net = env{ off_in_book = false }
    wk:onWake(); ui:advance(10)
    check("W8a sub 1 off: Wi-Fi stays on, no lease", net.wifi_on and net.online and w.count == 0 and net.disable_calls == 0)
    local wk2, w2, ui2, net2 = env{ off_in_book = true }
    wk2:onWake(); ui2:advance(10)
    check("W8b sub 1 on: Wi-Fi switched off after the pull", not net2.wifi_on and w2.count == 0)
end

-- W9 leaks: never connects, submit throws, dropped job
do
    local wk, w, ui, net, bo, st = env{ net = { connect_after = nil } }   -- out of range
    wk:onWake(); ui:advance(60)
    check("W9a out of range: quiet, no pull, no lease, wake resolved, radio off",
        #bo.checks == 0 and #st.offers == 0 and w.count == 0 and wk.pending == false and not net.wifi_on)
    local wk2, w2, ui2, net2, bo2 = env{ submit_throws = true }
    wk2:onWake(); ui2:advance(10)
    check("W9b submit throws: lease released, wake resolved", w2.count == 0 and wk2.pending == false)
    local wk3, w3, ui3, net3, bo3 = env{ defer_jobs = true }
    wk3:onWake(); ui3:advance(10)
    check("W9c job queued: lease held until it runs", w3.count == 1)
    local job = bo3.queued[1]
    job.cleanup()                    -- the coordinator drops it
    check("W9d dropped job: cleanup releases the lease and resolves", w3.count == 0 and wk3.pending == false)
end

-- W10 lock screen: waits, then runs; gives up quietly
do
    local wk, w, ui, net, bo, st = env{ locked = true, verdict = "ahead" }
    wk:onWake(); ui:advance(10)
    check("W10a locked: nothing pulled, nothing shown, radio untouched",
        #bo.checks == 0 and #st.offers == 0 and net.restore_calls == 0 and wk.pending)
    local dev = nil
    -- unlock
    local wk2, w2, ui2, net2, bo2, st2 = env{ locked = true, verdict = "ahead" }
    wk2:onWake(); ui2:advance(6)
    st2.device.screen_saver_lock = nil
    ui2:advance(20)
    check("W10b after unlock the pull runs and prompts once", #bo2.checks == 1 and #st2.offers == 1 and w2.count == 0)
    ui:advance(60)
    check("W10c never unlocked: gives up after MAX_TRIES, quiet", #bo.checks == 0 and wk.pending == false and wk.stats.skipped == 1)
end

-- W11 sleep sync still holding its lease: wait, do not race it
do
    local wk, w, ui, net, bo, st = env{ verdict = "ahead", net = { connect_after = 1 } }
    local lease = w:acquire("sleep_sync", function() end, function() end,
        { timeout = 12, trigger = true, off_when_done = true })
    wk:onWake(); ui:advance(5)
    check("W11a sleep lease held: wake pull waits", #bo.checks == 0 and wk.pending)
    w:release(lease)
    ui:advance(15)
    check("W11b after the sleep sync ended the pull runs, no lease left", #bo.checks == 1 and #st.offers == 1 and w.count == 0)
end

-- W12 suspend cancels a waiting pull
do
    local wk, w, ui, net, bo = env{ locked = true }
    wk:onWake(); ui:advance(3)
    wk:cancel()
    ui:advance(60)
    check("W12 cancel: no pull, nothing pending", #bo.checks == 0 and wk.pending == false and net.restore_calls == 0)
end

-- W13 book closed / changed before the prompt: no offer
do
    local wk, w, ui, net, bo, st = env{ verdict = "ahead", defer_jobs = true }
    wk:onWake(); ui:advance(10)
    local job = bo.queued[1]
    job.run()                        -- the pull answers "ahead"
    st.book = "/b/other.epub"        -- the user switched books meanwhile
    ui:advance(5)
    job.cleanup()
    check("W13 book changed: nothing offered, lease released", #st.offers == 0 and w.count == 0 and wk.pending == false)
end

-- W14 explicit trigger resets the sleeping state: wake after a sleep sync (sub 1 off) reconnects steady state
do
    local wk, w, ui, net, bo, st = env{ off_in_book = false, verdict = "clear" }
    w.sleeping = true
    wk:onWake(); ui:advance(10)
    check("W14 wake clears `sleeping`", w.sleeping == false and #bo.checks == 1)
end

print(string.format("test_bo_wake: %d passed, %d failed", passes, fails))
return fails > 0 and 1 or 0
