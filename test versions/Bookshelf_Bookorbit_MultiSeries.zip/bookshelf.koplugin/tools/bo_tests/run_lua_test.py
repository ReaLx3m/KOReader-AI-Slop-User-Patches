import sys
from lupa import LuaRuntime
lua = LuaRuntime(unpack_returned_tuples=True)
lua.globals().PLUGIN = sys.argv[1]
import os
# lupa has no io.popen; tests that need a directory listing use this.
lua.globals().listdir = lambda d: lua.table_from(sorted(os.listdir(d)))
src = open(sys.argv[2]).read()
try:
    r = lua.execute(src)
except Exception as e:
    print("LUA ERROR:", e); sys.exit(2)
sys.exit(1 if r else 0)
