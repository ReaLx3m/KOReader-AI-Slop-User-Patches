-- "Selection ring first" (BookOrbit hero): the no-fetch mode of BOSource.rebuildRecord (H1), run against
-- the REAL lib/bookshelf_bookorbit_source.lua under KOReader stubs (fake lfs, fake disk caches, fake
-- BookOrbit client that counts calls, fake RenderImage, fake Trapper). Off-device; proves the logic, not
-- device behaviour. NOT run on a device. H2 appends the repo/_hydrateBook checks (real function text run under stubs); H3 the deferral (_deferBookOrbitDetail, real text under stubs); H4 the wiring of _previewBookWork (static text checks + a run of the hydrate-to-defer slice).
package.path = PLUGIN .. "/?.lua;" .. package.path
local fails, passes = 0, 0
local function check(n, c, x)
    if c then passes = passes + 1
    else fails = fails + 1; print("FAIL: " .. n .. (x ~= nil and (" -> " .. tostring(x)) or "")) end
end

local function universal()
    return setmetatable({}, {
        __index = function() return universal() end,
        __call = function() return universal() end,
    })
end

local DIR = "/s/bookshelf_bookorbit_covers"
local DESC_FILE   = "/s/bookshelf_bookorbit_descriptions.lua"
local RATING_FILE = "/s/bookshelf_bookorbit_rating_overrides.lua"

local function thumbPath(id, updated_at)
    local token = tostring(updated_at):gsub("%D", "")
    return DIR .. "/" .. tostring(id) .. "_" .. token .. ".jpg"
end

local function newWorld()
    local w = { files = {}, stores = {}, logs = {}, detail_calls = 0, downloads = 0, decoded = 0,
                popups = 0, configured = true, detail = nil, detail_err = "boom",
                download_ok = true, trapper_wrapped = false, trapper_cancel = false }
    local function open(path)
        local data = w.stores[path]
        if not data then data = {}; w.stores[path] = data end
        local s = {}
        function s:readSetting(k) return data[k] end
        function s:saveSetting(k, v) data[k] = v; return s end
        function s:delSetting(k) data[k] = nil; return s end
        function s:flush() return s end
        function s:purge() for k in pairs(data) do data[k] = nil end return s end
        return s
    end
    w.BO = universal()
    w.BO.isConfigured = function() return w.configured end
    w.BO.catalogBook = function(id)
        w.detail_calls = w.detail_calls + 1
        if w.detail then return w.detail end
        return nil, w.detail_err
    end
    w.BO.downloadCatalogThumbnail = function(id, path)
        w.downloads = w.downloads + 1
        if w.download_ok then w.files[path] = true; return true end
        return nil, "http_500"
    end
    local lfs = {
        attributes = function(p, m)
            if w.files[p] then return m == "mode" and "file" or 1 end
            if p == DIR then return m == "mode" and "directory" or nil end
        end,
        dir = function() return function() return nil end end,
    }
    local trapper = {
        isWrapped = function() return w.trapper_wrapped end,
        dismissableRunInSubprocess = function(_self, fn, msg)
            w.popups = w.popups + 1
            if w.trapper_cancel then return false end
            return true, fn()
        end,
    }
    w.stubs = {
        ["luasettings"] = { open = function(_, path) return open(path) end },
        ["datastorage"] = { getSettingsDir = function() return "/s" end },
        ["libs/libkoreader-lfs"] = lfs,
        ["util"] = { makePath = function() return true end },
        ["ui/trapper"] = trapper,
        ["lib/bookshelf_bookorbit"] = w.BO,
        ["lib/bookshelf_settings_store"] = { read = function() return nil end, save = function() end, flush = function() end },
        ["lib/bookshelf_gettime"] = function() return 100 end,
        ["logger"] = { dbg = function() end, info = function() end, warn = function() end },
        ["ui/renderimage"] = { renderImageFile = function(_, path)
            w.decoded = w.decoded + 1
            return { w = 10, h = 20, id = w.decoded, getWidth = function() return 10 end, getHeight = function() return 20 end }
        end },
    }
    return w
end

local real_require = require
local function loadSource(w)
    local function req(name)
        if w.stubs[name] then return w.stubs[name] end
        if name:match("^lib/") then
            local ok, m = pcall(real_require, name)
            if ok then return m end
        end
        return universal()
    end
    function require(name) return req(name) end   -- luacheck: ignore
    local f, err = loadfile(PLUGIN .. "/lib/bookshelf_bookorbit_source.lua")
    assert(f, err)
    return f()
end

local SENTINEL = { sentinel = true }
local function fallbackRecord(extra)
    local r = { remote_id = 7, updated_at = "2026-01-07", filepath = "bookorbit://7", title = "Title",
                cover_bb = SENTINEL, _cover_filled = true, has_cover = true }
    for k, v in pairs(extra or {}) do r[k] = v end
    return r
end
local function goodDetail()
    return { description = "A synopsis", updatedAt = "2026-01-07", rating = 3,
             communityRatings = { { provider = "goodreads", rating = 4.1 } },
             genres = { "Fantasy" }, tags = { "Epic" } }
end
local function cacheEntry(w) return w.stores[DESC_FILE] and w.stores[DESC_FILE]["7"] end
local function seedCache(w)
    w.stores[DESC_FILE] = { ["7"] = { description = "Cached synopsis", updated_at = "2026-01-07",
        community_ratings = { { provider = "apple", rating = 4.5 } }, genres = { "Cached genre" } } }
end
local function seedCover(w) w.files[thumbPath(7, "2026-01-07")] = true end
local function fresh()
    local w = newWorld(); local M = loadSource(w)
    return w, M
end
local NF = { no_fetch = true }

-- 1. no_fetch + synopsis cached + cover on disk: everything present, nothing fetched ------------------------
do
    local w, M = fresh(); seedCache(w); seedCover(w)
    local fb = fallbackRecord()
    local rec, pending = M.rebuildRecord(fb, NF)
    check("1: a record comes back", type(rec) == "table" and rec ~= fb)
    check("1: description from the cache", rec.description == "Cached synopsis", rec and rec.description)
    check("1: community ratings and genres from the cache", rec.community_ratings and rec.community_ratings[1].provider == "apple"
        and rec.genres and rec.genres[1] == "Cached genre")
    check("1: cover decoded from the file on disk", rec.cover_bb ~= nil and rec.cover_bb ~= SENTINEL and rec.cover_w == 10 and rec.cover_h == 20 and rec.has_cover == true, tostring(rec.cover_bb))
    check("1: nothing pending", pending == false, tostring(pending))
    check("1: no detail request, no download, no popup", w.detail_calls == 0 and w.downloads == 0 and w.popups == 0)
    check("1: the fallback's cover_bb is never carried and the fallback is untouched", fb.cover_bb == SENTINEL and fb.description == nil and fb._cover_filled == true)
end

-- 2. no_fetch + synopsis NOT cached (the user's case): nothing fetched, pending ------------------------------
do
    local w, M = fresh(); seedCover(w)
    local fb = fallbackRecord({ author = "Someone", series = "S" })
    local rec, pending = M.rebuildRecord(fb, NF)
    check("2: a record comes back", type(rec) == "table" and rec ~= fb)
    check("2: zero detail requests (the network is not touched)", w.detail_calls == 0, w.detail_calls)
    check("2: no description yet", rec.description == nil)
    check("2: pending", pending == true, tostring(pending))
    check("2: other fields carried over", rec.title == "Title" and rec.author == "Someone" and rec.series == "S" and rec.remote_id == 7 and rec.filepath == "bookorbit://7")
    check("2: cover from disk, fresh bitmap, fallback's not carried", rec.cover_bb ~= nil and rec.cover_bb ~= SENTINEL and w.downloads == 0)
    check("2: no popup, nothing written to the description cache", w.popups == 0 and cacheEntry(w) == nil)
end

-- 3. no_fetch + synopsis cached + cover NOT on disk: no download, pending because of the cover -----------------
do
    local w, M = fresh(); seedCache(w)
    local rec, pending = M.rebuildRecord(fallbackRecord(), NF)
    check("3: description present", rec.description == "Cached synopsis")
    check("3: no download attempted and nothing decoded", w.downloads == 0 and w.decoded == 0)
    check("3: no cover on the record", rec.cover_bb == nil)
    check("3: pending (the cover still has to come)", pending == true, tostring(pending))
end

-- 4. a cover that cannot exist is not pending ---------------------------------------------------------------
do
    local w, M = fresh(); seedCache(w)
    local rec, pending = M.rebuildRecord(fallbackRecord({ has_cover = false }), NF)
    check("4a: has_cover == false and the description cached: not pending", pending == false, tostring(pending))
    check("4a: no cover, nothing decoded or downloaded", rec.cover_bb == nil and w.decoded == 0 and w.downloads == 0)
    -- a download that failed in this session blacklists the book (same as the grid): not pending afterwards
    local w2, M2 = fresh(); seedCache(w2); w2.download_ok = false
    local r1 = M2.rebuildRecord(fallbackRecord())
    check("4b: the full call gave up on the cover", r1 and r1.cover_bb == nil and w2.downloads == 1, w2.downloads)
    local rec2, pending2 = M2.rebuildRecord(fallbackRecord(), NF)
    check("4b: no_fetch afterwards: description cached + cover given up on: not pending", pending2 == false and rec2.cover_bb == nil, tostring(pending2))
    check("4b: still no new download", w2.downloads == 1)
    -- the description missing still makes it pending
    local w3, M3 = fresh(); w3.download_ok = false
    M3.rebuildRecord(fallbackRecord())
    local _, pending3 = M3.rebuildRecord(fallbackRecord(), NF)
    check("4c: cover given up on but no cached description: pending", pending3 == true)
end

-- 5. the local rating override is applied in no_fetch mode ---------------------------------------------------
do
    local w, M = fresh(); seedCover(w)
    M.setLocalRatingOverride(7, 4)
    local rec = M.rebuildRecord(fallbackRecord({ rating = 1 }), NF)
    check("5: override wins over the fallback's stale rating", rec.rating == 4, rec.rating)
    local rec2 = M.rebuildRecord(fallbackRecord({ remote_id = 8, filepath = "bookorbit://8", rating = 2 }), NF)
    check("5: no override: the fallback's rating stays", rec2.rating == 2, rec2.rating)
end

-- 6. no opts + miss (the OLD behaviour, regression) -----------------------------------------------------------
do
    local w, M = fresh(); seedCover(w); w.detail = goodDetail()
    local rec, pending = M.rebuildRecord(fallbackRecord())
    check("6: exactly one detail request", w.detail_calls == 1, w.detail_calls)
    check("6: description, ratings and genres from the server", rec.description == "A synopsis" and rec.community_ratings[1].provider == "goodreads"
        and rec.genres[1] == "Fantasy" and rec.genres[2] == "Epic")
    check("6: the description cache was written", cacheEntry(w) and cacheEntry(w).description == "A synopsis" and cacheEntry(w).genres[1] == "Fantasy")
    check("6: the server rating overwrote the local override", rec.rating == 3 and w.stores[RATING_FILE] and w.stores[RATING_FILE]["7"] == 3)
    check("6: cover decoded", rec.cover_bb ~= nil and rec.cover_bb ~= SENTINEL and w.decoded == 1)
    check("6: pending is false", pending == false, tostring(pending))
    -- a failed fetch still returns nil, with or without a cover on disk
    local w2, M2 = fresh(); seedCover(w2)
    local r2 = M2.rebuildRecord(fallbackRecord())
    check("6: failed detail request -> nil (caller reuses the old record)", r2 == nil and w2.detail_calls == 1)
    -- a missing thumbnail IS downloaded on the full path (unchanged)
    local w3, M3 = fresh(); w3.detail = goodDetail()
    local r3 = M3.rebuildRecord(fallbackRecord())
    check("6: full path downloads a missing thumbnail", w3.downloads == 1 and r3 and r3.cover_bb ~= nil, w3.downloads)
end

-- 7. no opts + cache hit: no request ----------------------------------------------------------------------------
do
    local w, M = fresh(); seedCache(w); seedCover(w)
    local rec, pending = M.rebuildRecord(fallbackRecord())
    check("7: description from the cache, no request", rec.description == "Cached synopsis" and w.detail_calls == 0)
    check("7: pending false", pending == false)
end

-- 8. opts that are not no_fetch = true behave like no opts ---------------------------------------------------------
do
    for _, opts in ipairs({ {}, { no_fetch = false }, { no_fetch = "yes" }, "no_fetch", 42 }) do
        local w, M = fresh(); seedCover(w); w.detail = goodDetail()
        local rec, pending = M.rebuildRecord(fallbackRecord(), opts)
        check("8: opts " .. tostring(type(opts) == "table" and (opts.no_fetch == nil and "{}" or ("no_fetch=" .. tostring(opts.no_fetch))) or opts)
            .. " does the full fetch", w.detail_calls == 1 and rec and rec.description == "A synopsis" and pending == false, w.detail_calls)
    end
end

-- 9. guards ------------------------------------------------------------------------------------------------------------
do
    local w, M = fresh()
    check("9: nil fallback -> nil", M.rebuildRecord(nil, NF) == nil and M.rebuildRecord(nil) == nil)
    check("9: no remote_id -> nil", M.rebuildRecord({ title = "x" }, NF) == nil)
    w.configured = false
    check("9: server not configured -> nil (both modes)", M.rebuildRecord(fallbackRecord(), NF) == nil and M.rebuildRecord(fallbackRecord()) == nil)
    check("9: nothing fetched while unavailable", w.detail_calls == 0 and w.downloads == 0)
end

-- 10. the phase-2 flow: no_fetch, then a full call fills the caches, then no_fetch is a hit -------------------------------
do
    local w, M = fresh(); seedCover(w); w.detail = goodDetail()
    local r1, p1 = M.rebuildRecord(fallbackRecord(), NF)
    check("10: step 1 pending, no request", p1 == true and w.detail_calls == 0 and r1.description == nil)
    local r2, p2 = M.rebuildRecord(fallbackRecord())
    check("10: step 2 (full) fetched once and has the synopsis", w.detail_calls == 1 and r2.description == "A synopsis" and p2 == false)
    local r3, p3 = M.rebuildRecord(fallbackRecord(), NF)
    check("10: step 3 (no_fetch again) is a cache hit, nothing pending", r3.description == "A synopsis" and p3 == false and w.detail_calls == 1)
    check("10: the records are distinct tables with their own bitmaps", r1 ~= r2 and r2 ~= r3 and r1.cover_bb ~= r2.cover_bb and r2.cover_bb ~= r3.cover_bb)
end

-- 11. Trapper: the popup is only ever shown by the full call --------------------------------------------------------------
do
    local w, M = fresh(); seedCover(w); w.detail = goodDetail(); w.trapper_wrapped = true
    local _, p = M.rebuildRecord(fallbackRecord(), NF)
    check("11: no_fetch inside a Trapper coroutine shows no popup and fetches nothing", p == true and w.popups == 0 and w.detail_calls == 0)
    local rec = M.rebuildRecord(fallbackRecord())
    check("11: the full call shows the dismissable popup once (the user keeps it) and fetches", w.popups == 1 and w.detail_calls == 1 and rec and rec.description == "A synopsis", w.popups)
    -- cancelled popup -> nil, nothing cached (existing contract)
    local w2, M2 = fresh(); seedCover(w2); w2.detail = goodDetail(); w2.trapper_wrapped = true; w2.trapper_cancel = true
    local r2 = M2.rebuildRecord(fallbackRecord())
    check("11: cancelled popup -> nil and nothing cached", r2 == nil and cacheEntry(w2) == nil and w2.detail_calls == 0)
    -- a cache hit never shows a popup
    local w3, M3 = fresh(); seedCache(w3); seedCover(w3); w3.trapper_wrapped = true
    M3.rebuildRecord(fallbackRecord())
    check("11: cache hit: no popup", w3.popups == 0)
end

-- ===== H2: repo pass-through + BookshelfWidget:_hydrateBook(book, opts) ======================================
-- The widget and the repo are NOT loadable off-device. The REAL text of Repo.buildPreviewBook and of
-- BookshelfWidget:_hydrateBook is extracted from the source files and RUN under small stubs; the call-site
-- audit is a static text check only.
local function readFile(rel)
    local f = assert(io.open(PLUGIN .. "/" .. rel, "r")); local s = f:read("*a"); f:close(); return s
end
local function splitLines(s) local t = {}; for l in (s .. "\n"):gmatch("(.-)\n") do t[#t + 1] = l end return t end
-- text of `function <head>` up to the matching top-level `end` (column 0)
local function extractFn(src, head)
    local lines, out, on = splitLines(src), {}, false
    for _, l in ipairs(lines) do
        if not on and l:sub(1, #head + 9) == "function " .. head then on = true end
        if on then out[#out + 1] = l; if l == "end" then break end end
    end
    assert(on and out[#out] == "end", "function not found: " .. head)
    return table.concat(out, "\n")
end
local function countPlain(s, needle)
    local n, i = 0, 1
    while true do local a, b = s:find(needle, i, true); if not a then return n end; n = n + 1; i = b + 1 end
end

local REPO_SRC   = readFile("lib/bookshelf_book_repository.lua")
local WIDGET_SRC = readFile("lib/bookshelf_widget.lua")
local PREVIEW_TXT = extractFn(REPO_SRC, "Repo.buildPreviewBook(")
local HYDRATE_TXT = extractFn(WIDGET_SRC, "BookshelfWidget:_hydrateBook(")

-- Repo.buildPreviewBook under stubs: `bo` is the fake BookOrbit source (nil -> require fails)
local function loadPreview(bo, builds)
    local env = { type = type, pcall = pcall, error = error }
    env.Repo = { buildBook = function(fp) builds[#builds + 1] = fp; return { built = fp } end }
    env.require = function(name)
        if name == "lib/bookshelf_bookorbit_source" and bo then return bo end
        error("module '" .. tostring(name) .. "' not found")
    end
    local f = assert(load(PREVIEW_TXT, "=buildPreviewBook", "t", env))
    f()
    return env.Repo
end
-- BookshelfWidget:_hydrateBook under stubs: `Repo` has a recording fake buildPreviewBook
local function loadHydrate(repo)
    local env = { BookshelfWidget = {}, Repo = repo }
    local f = assert(load(HYDRATE_TXT, "=_hydrateBook", "t", env))
    f()
    return env.BookshelfWidget
end

-- 12. Repo.buildPreviewBook (REAL text, fake BOSource): opts forwarded, two values for BookOrbit ------------
do
    local seen, builds = {}, {}
    local bo = { rebuildRecord = function(fb, opts)
        seen[#seen + 1] = { fb = fb, opts = opts, n = select("#", fb, opts) }
        return { rec_of = fb.filepath }, "PENDING"
    end }
    local R = loadPreview(bo, builds)
    local fb, o = { filepath = "bookorbit://7" }, { no_fetch = true }
    local function pack(...) return select("#", ...), ... end
    local n, rec, pend = pack(R.buildPreviewBook("bookorbit://7", fb, o))
    check("12: BookOrbit path returns BOTH values of rebuildRecord", n == 2 and rec.rec_of == "bookorbit://7" and pend == "PENDING", n)
    check("12: rebuildRecord got the fallback and the SAME opts table", #seen == 1 and seen[1].fb == fb and rawequal(seen[1].opts, o))
    R.buildPreviewBook("bookorbit://7", fb)
    check("12: no opts -> rebuildRecord called with opts nil (old behaviour)", #seen == 2 and seen[2].opts == nil)
    local r2 = R.buildPreviewBook("bookorbit://7", { filepath = "bookorbit://8" }, o)
    check("12: mismatched fallback -> nil, rebuildRecord not called", r2 == nil and #seen == 2)
    local r3 = R.buildPreviewBook("bookorbit://7", nil, o)
    check("12: nil fallback -> nil, rebuildRecord not called", r3 == nil and #seen == 2)
    local nn, r4 = pack(R.buildPreviewBook("/books/a.epub", { filepath = "/books/a.epub" }, o))
    check("12: non-BookOrbit path -> Repo.buildBook only, ONE value, opts ignored, rebuildRecord not called",
        nn == 1 and r4.built == "/books/a.epub" and builds[1] == "/books/a.epub" and #builds == 1 and #seen == 2, nn)
    local R2 = loadPreview(nil, {})
    check("12: BOSource not loadable -> nil", R2.buildPreviewBook("bookorbit://7", fb, o) == nil)
    local R3 = loadPreview({}, {})
    check("12: BOSource without rebuildRecord -> nil", R3.buildPreviewBook("bookorbit://7", fb, o) == nil)
end

-- 13. BookshelfWidget:_hydrateBook (REAL text, recording fake repo) -------------------------------------------
do
    local calls, ret = {}, {}
    local repo = { buildPreviewBook = function(fp, fb, opts)
        calls[#calls + 1] = { fp = fp, fb = fb, opts = opts }
        return table.unpack(ret, 1, ret.n or #ret)
    end }
    local W = loadHydrate(repo)
    local function self_(remote) return { _isRemoteRecord = function(_, b) return remote and remote(b) or false end } end
    local function pack(...) return select("#", ...), ... end
    local book = { filepath = "bookorbit://7", title = "T" }
    local o = { no_fetch = true }

    ret = { n = 2, { rebuilt = true }, true }
    local n, rec, pending = pack(W._hydrateBook(self_(), book, o))
    check("13: opts forwarded UNCHANGED (same table) with the book's filepath and the book as fallback",
        #calls == 1 and calls[1].fp == "bookorbit://7" and calls[1].fb == book and rawequal(calls[1].opts, o))
    check("13: returns rec, pending == true", n == 2 and rec.rebuilt == true and pending == true, n)

    ret = { n = 2, { rebuilt = true }, false }
    local _, r2, p2 = pack(W._hydrateBook(self_(), book, o))
    check("13: pending false passes through", r2.rebuilt == true and p2 == false)

    ret = { n = 1, { rebuilt = true } }   -- non-BookOrbit: the repo returns ONE value
    local _, r3, p3 = pack(W._hydrateBook(self_(), book))
    check("13: single-value repo result -> pending is false (not nil)", r3.rebuilt == true and p3 == false, tostring(p3))
    check("13: no opts -> repo called with opts nil (old behaviour)", calls[#calls].opts == nil)

    ret = { n = 2, { rebuilt = true }, "yes" }
    local _, _, p4 = pack(W._hydrateBook(self_(), book, o))
    ret = { n = 2, { rebuilt = true }, nil }
    local _, _, p5 = pack(W._hydrateBook(self_(), book, o))
    check("13: pending is coerced to a boolean", p4 == true and p5 == false, tostring(p4) .. "/" .. tostring(p5))

    ret = { n = 0 }   -- failed rebuild (offline, cancelled popup)
    local n6, r6, p6 = pack(W._hydrateBook(self_(), book, o))
    check("13: nil rebuild -> the book itself comes back, pending false", n6 == 2 and r6 == book and p6 == false)

    local before = #calls
    local remote = { filepath = "opds://x/1", _remote = true }
    local n7, r7, p7 = pack(W._hydrateBook(self_(function(b) return b == remote end), remote, o))
    check("13: remote / OPDS record untouched, repo NOT called, pending false", n7 == 2 and r7 == remote and p7 == false and #calls == before)
    local nofp = { title = "no path" }
    local _, r8, p8 = pack(W._hydrateBook(self_(), nofp, o))
    check("13: record without filepath untouched, repo NOT called", r8 == nofp and p8 == false and #calls == before)
    local _, r9, p9 = pack(W._hydrateBook(self_(), nil, o))
    check("13: nil book -> nil, false, repo NOT called", r9 == nil and p9 == false and #calls == before)

    -- single-value contexts used by the callers: the second value must not leak
    ret = { n = 2, { rebuilt = true }, true }
    local s = self_()
    local function paren() return (book and book.filepath and W._hydrateBook(s, book)) or book end
    check("13: the parenthesised `and ... or` caller form yields ONE value", select("#", paren()) == 1 and paren().rebuilt == true)
    local t = {}; t.x = W._hydrateBook(s, book)
    check("13: the plain assignment caller form takes the record only", t.x.rebuilt == true)
end

-- 14. end to end: REAL Repo.buildPreviewBook text + REAL _hydrateBook text + REAL BOSource.rebuildRecord ------
do
    local w, M = fresh(); seedCover(w); w.detail = goodDetail()
    local builds = {}
    local Repo = loadPreview(M, builds)
    local W = loadHydrate(Repo)
    local sf = { _isRemoteRecord = function() return false end }
    local fb = fallbackRecord()
    local rec1, p1 = W._hydrateBook(sf, fb, { no_fetch = true })
    check("14: phase 1 on a synopsis miss: record without synopsis, pending, ZERO requests",
        rec1 ~= fb and rec1.description == nil and p1 == true and w.detail_calls == 0 and w.downloads == 0, w.detail_calls)
    check("14: phase 1 record carries the cover from disk (not the fallback's bb)", rec1.cover_bb ~= nil and rec1.cover_bb ~= SENTINEL)
    local rec2, p2 = W._hydrateBook(sf, fb)
    check("14: phase 2 (no opts): one detail request, synopsis present, pending false",
        w.detail_calls == 1 and rec2.description == "A synopsis" and p2 == false, w.detail_calls)
    local rec3, p3 = W._hydrateBook(sf, fb, { no_fetch = true })
    check("14: phase 1 again is now a cache hit: synopsis, not pending, still one request",
        rec3.description == "A synopsis" and p3 == false and w.detail_calls == 1)
    -- failure / offline: the book comes back, pending false
    local w2, M2 = fresh(); seedCover(w2)   -- no detail -> catalogBook fails
    local W2 = loadHydrate(loadPreview(M2, {}))
    local r4, p4 = W2._hydrateBook(sf, fb)
    check("14: failed detail fetch -> the fallback book itself, pending false", r4 == fb and p4 == false and w2.detail_calls == 1)
end

-- 15. static checks (text only) ------------------------------------------------------------------------------
do
    check("15: repo signature takes opts", REPO_SRC:find("function Repo.buildPreviewBook(filepath, fallback_book, opts)", 1, true) ~= nil)
    check("15: repo BookOrbit branch passes opts to rebuildRecord", countPlain(PREVIEW_TXT, "return BOSource.rebuildRecord(fallback_book, opts)") == 1)
    check("15: repo non-BookOrbit branch unchanged", countPlain(PREVIEW_TXT, "    return Repo.buildBook(filepath)\n") == 1)
    check("15: widget signature takes opts", WIDGET_SRC:find("function BookshelfWidget:_hydrateBook(book, opts)", 1, true) ~= nil)
    check("15: widget forwards opts to the repo", countPlain(HYDRATE_TXT, "Repo.buildPreviewBook(book.filepath, book, opts)") == 1)

    -- call-site audit: every non-comment use of _hydrateBook( / buildPreviewBook( is one of the known single-value forms
    local hyd, prev, other = 0, 0, {}
    for i, l in ipairs(splitLines(WIDGET_SRC)) do
        local code = l:match("^%s*(.-)%s*$")
        if code:sub(1, 2) ~= "--" and not code:find("^function BookshelfWidget:_hydrateBook") then
            if code:find("_hydrateBook(", 1, true) then
                hyd = hyd + 1
                if code:find("^return") or code:find(",%s*[%w_.:]*_hydrateBook%(") then other[#other + 1] = i .. ": " .. code end
            end
            if code:find("buildPreviewBook(", 1, true) then prev = prev + 1 end
        end
    end
    check("15: audit: exactly 9 widget call sites of _hydrateBook (8 from H2 + the H3 deferral; a new one must be audited)", hyd == 9, hyd)
    check("15: audit: the H3 site is a plain single-value assignment", countPlain(WIDGET_SRC, "        local rec = self_:_hydrateBook(book)\n") == 1)
    check("15: audit: none is a `return` tail or a later argument", #other == 0, other[1])
    check("15: audit: widget calls Repo.buildPreviewBook only at _hydrateBook and the one `or`-truncated site", prev == 2, prev)
    check("15: audit: _buildHero site is a plain assignment", countPlain(WIDGET_SRC, "            current = self:_hydrateBook(self._preview_book)\n") == 1)
    check("15: audit: 4 parenthesised `and ... or` sites", select(2, WIDGET_SRC:gsub("self%._preview_book%.filepath%s*\n%s*and self:_hydrateBook%(self%._preview_book%)%)%s*\n%s*or self%._preview_book", "")) == 4)
    check("15: audit: expanded-shelf tap is a plain assignment", countPlain(WIDGET_SRC, "bw._preview_book = bw:_hydrateBook(b)\n") == 1)
    check("15: audit: micro branch is the unchanged plain assignment; main path (H4) is a plain multi-assignment with no_fetch", countPlain(WIDGET_SRC, "\n        self._preview_book = self:_hydrateBook(book)\n") == 1
        and countPlain(WIDGET_SRC, "\n    local rec, pending = self:_hydrateBook(book, { no_fetch = true })\n    self._preview_book = rec\n") == 1
        and countPlain(WIDGET_SRC, "\n    self._preview_book = self:_hydrateBook(book)\n") == 0)
    check("15: audit: the direct repo caller is `or`-truncated", countPlain(WIDGET_SRC, "Repo.buildPreviewBook(sel_fp, self._preview_book) or self._preview_book") == 1)
    -- nothing outside the widget calls the repo function or the widget method
    local others = {}
    for _, rel in ipairs({ "main.lua", "lib/bookshelf_book_repository.lua", "lib/bookshelf_hero_card.lua", "lib/bookshelf_bookorbit_source.lua" }) do
        for _, l in ipairs(splitLines(readFile(rel))) do
            local code = l:match("^%s*(.-)%s*$")
            if code:sub(1, 2) ~= "--" and (code:find("_hydrateBook(", 1, true) or code:find("buildPreviewBook(", 1, true)) and not code:find("^function Repo.buildPreviewBook") then
                others[#others + 1] = rel .. ": " .. code
            end
        end
    end
    check("15: audit: no caller of either function in main.lua / repo / hero card / source", #others == 0, others[1])
end

-- ===== H3: BookshelfWidget:_deferBookOrbitDetail (REAL text, run under stubs; wired in H4, section 27) ==================
-- Fake tick queue (pumped by hand), fake Trapper, scripted _hydrateBook, fake _swapHeroInPlace. The widget file is
-- not loadable off-device: only the extracted function text runs; the "not called yet" check is static.
local DEFER_TXT = extractFn(WIDGET_SRC, "BookshelfWidget:_deferBookOrbitDetail(")
local FP = "bookorbit://7"

local function newDefer(o)
    o = o or {}
    local d = { ticks = {}, nextticks = {}, logs = {}, wraps = 0, swaps = 0, hydrates = {}, wrapped = false, clock = 0 }
    local BW = {}
    d.trapper = {
        isWrapped = function() return d.wrapped end,
        wrap = function(_, fn) d.wraps = d.wraps + 1; d.wrapped = true; fn(); d.wrapped = false end,
    }
    local env = { BookshelfWidget = BW, string = string, tostring = tostring, pcall = pcall, error = error,
        logger = { dbg = function(s) d.logs[#d.logs + 1] = s end },
        _gettime = function() d.clock = d.clock + 0.25; return d.clock end,
        UIManager = { nextTick = function(_, f) d.nextticks[#d.nextticks + 1] = f end } }
    if not o.no_tick_after_next then
        env.UIManager.tickAfterNext = function(_, f) d.ticks[#d.ticks + 1] = f end
    end
    env.require = function(n)
        if n == "ui/trapper" and not o.no_trapper then return o.trapper or d.trapper end
        error("module '" .. tostring(n) .. "' not found")
    end
    local f = assert(load(DEFER_TXT, "=_deferBookOrbitDetail", "t", env)); f()
    local s = { _preview_book = o.preview or { filepath = FP, phase = 1 }, _hero_parent = {}, _hero_dims = {} }
    if o.no_hero then s._hero_parent = nil end
    s._hydrateBook = function(self, b, ...)
        d.hydrates[#d.hydrates + 1] = { b = b, nargs = select("#", ...), wrapped = d.wrapped }
        if d.on_hydrate then d.on_hydrate(self) end
        if d.result then return d.result(b) end
        return { filepath = b.filepath, phase = 2, description = "full" }, false
    end
    s._swapHeroInPlace = function(self)
        d.swaps = d.swaps + 1; d.cache_at_swap = self._hero_book_cache
    end
    BW.live = s
    d.s, d.BW, d.defer = s, BW, BW._deferBookOrbitDetail
    function d.pump() local q = d.ticks; d.ticks = {}; for _, f in ipairs(q) do f() end end
    function d.log(pat) for _, l in ipairs(d.logs) do if l:find(pat, 1, true) then return true end end return false end
    return d
end
local BOOK = { filepath = FP, title = "T" }

-- 16. happy path --------------------------------------------------------------------------------------------------
do
    local d = newDefer()
    d.defer(d.s, BOOK)
    check("16: nothing runs synchronously (queued only)", #d.ticks == 1 and #d.hydrates == 0 and d.wraps == 0 and d.swaps == 0 and #d.nextticks == 0)
    check("16: token set and 'deferred' logged", d.s._bo_detail_token == 1 and d.log("bo hero detail: deferred"))
    check("16: _preview_book untouched until the tick", d.s._preview_book.phase == 1)
    d.pump()
    check("16: after the tick: one full hydrate of the SAME book table, no opts, inside a Trapper wrap",
        #d.hydrates == 1 and d.hydrates[1].b == BOOK and d.hydrates[1].nargs == 0 and d.wraps == 1 and d.hydrates[1].wrapped == true)
    check("16: _preview_book is the new record", d.s._preview_book.phase == 2 and d.s._preview_book.description == "full")
    check("16: _hero_book_cache = the new record, already set when the swap ran", d.s._hero_book_cache == d.s._preview_book and d.cache_at_swap == d.s._preview_book)
    check("16: exactly one hero swap", d.swaps == 1)
    check("16: 'landed' logged with ms and swapped=true", d.log("bo hero detail: landed ms=250 swapped=true"), table.concat(d.logs, "|"))
end

-- 17. stale BEFORE the tick: no fetch at all -----------------------------------------------------------------------
do
    local d = newDefer(); d.defer(d.s, BOOK)
    d.s._preview_book = { filepath = "bookorbit://8" }
    local other = d.s._preview_book
    d.pump()
    check("17: another selection before the tick -> no fetch, no swap, nothing changed",
        #d.hydrates == 0 and d.swaps == 0 and d.s._preview_book == other and d.s._hero_book_cache == nil)
    check("17: dropped reason=stale logged", d.log("bo hero detail: dropped reason=stale"))
end

-- 18. stale AFTER the fetch ---------------------------------------------------------------------------------------
do
    local d = newDefer(); local sentinel = { filepath = "bookorbit://8", keep = true }
    d.s._hero_book_cache = sentinel
    d.defer(d.s, BOOK)
    local other = { filepath = "bookorbit://8" }
    d.on_hydrate = function(s) s._preview_book = other end
    d.pump()
    check("18: the fetch ran but the result is dropped: no swap, preview stays on the other book", #d.hydrates == 1 and d.swaps == 0 and d.s._preview_book == other)
    check("18: _hero_book_cache untouched (no stash)", d.s._hero_book_cache == sentinel)
    check("18: dropped reason=stale logged", d.log("dropped reason=stale") and not d.log("landed"))
end

-- 19. superseded by a newer deferral ------------------------------------------------------------------------------
do
    local d = newDefer()
    d.defer(d.s, BOOK); d.defer(d.s, BOOK)
    check("19: two ticks queued, token advanced", #d.ticks == 2 and d.s._bo_detail_token == 2)
    d.pump()
    check("19: the first is inert (no fetch), the second works once", #d.hydrates == 1 and d.swaps == 1 and d.log("dropped reason=superseded") and d.log("landed"))
    -- superseded WHILE the first fetch is running
    local d2 = newDefer(); local sentinel = { filepath = "x" }; d2.s._hero_book_cache = sentinel
    d2.defer(d2.s, BOOK)
    d2.on_hydrate = function(s) d2.on_hydrate = nil; s:_deferBookOrbitDetailAgain() end
    d2.s._deferBookOrbitDetailAgain = function(s) d2.defer(s, BOOK) end
    d2.pump()
    check("19: superseded during the fetch -> first result dropped, cache untouched, no swap", d2.swaps == 0 and d2.s._hero_book_cache == sentinel and d2.log("dropped reason=superseded"))
    d2.pump()
    check("19: the newer deferral then lands normally", d2.swaps == 1 and d2.s._preview_book.phase == 2 and #d2.hydrates == 2)
end

-- 20. widget closed / not live, before and after --------------------------------------------------------------------
do
    local d = newDefer(); d.defer(d.s, BOOK); d.s._closed = true; d.pump()
    check("20: closed before the tick -> no fetch, no swap", #d.hydrates == 0 and d.swaps == 0 and d.log("dropped reason=closed"))
    local d2 = newDefer(); d2.defer(d2.s, BOOK); d2.BW.live = {}; d2.pump()
    check("20: another widget is live before the tick -> no fetch, no swap", #d2.hydrates == 0 and d2.swaps == 0 and d2.log("dropped reason=closed"))
    local d3 = newDefer(); d3.defer(d3.s, BOOK); d3.on_hydrate = function(s) s._closed = true end; d3.pump()
    check("20: closed during the fetch -> no swap, preview unchanged", #d3.hydrates == 1 and d3.swaps == 0 and d3.s._preview_book.phase == 1 and d3.s._hero_book_cache == nil)
    local d4 = newDefer(); d4.defer(d4.s, BOOK); d4.on_hydrate = function(s) d4.BW.live = nil end; d4.pump()
    check("20: no longer live during the fetch -> no swap", d4.swaps == 0 and d4.s._preview_book.phase == 1)
end

-- 21. failed / cancelled fetch, bad records ------------------------------------------------------------------------
do
    local d = newDefer(); d.result = function(b) return b, false end   -- _hydrateBook returns the book itself
    local p1 = d.s._preview_book; d.defer(d.s, BOOK); d.pump()
    check("21: fetch failed or cancelled (rec == book): phase-1 hero kept, no swap, no cache", d.swaps == 0 and d.s._preview_book == p1 and d.s._hero_book_cache == nil and d.log("dropped reason=failed"))
    local d2 = newDefer(); d2.result = function() return nil end
    local q1 = d2.s._preview_book; d2.defer(d2.s, BOOK); d2.pump()
    check("21: nil result treated as failed", d2.swaps == 0 and d2.s._preview_book == q1 and d2.log("reason=failed"))
    local d3 = newDefer(); d3.result = function() return { filepath = "bookorbit://99" }, false end
    local r1 = d3.s._preview_book; d3.defer(d3.s, BOOK); d3.pump()
    check("21: a record for a different filepath is not accepted", d3.swaps == 0 and d3.s._preview_book == r1 and d3.s._hero_book_cache == nil)
end

-- 22. no hero slot ------------------------------------------------------------------------------------------------
do
    local d = newDefer({ no_hero = true }); d.s._hero_book_cache = { filepath = "stale" }
    d.defer(d.s, BOOK); d.pump()
    check("22: no _hero_parent: record kept, cache cleared, NO swap", d.swaps == 0 and d.s._preview_book.phase == 2 and d.s._hero_book_cache == nil and d.log("swapped=false"))
    local d2 = newDefer(); d2.s._hero_dims = nil; d2.s._hero_book_cache = { filepath = "stale" }
    d2.defer(d2.s, BOOK); d2.pump()
    check("22: no _hero_dims: same", d2.swaps == 0 and d2.s._preview_book.phase == 2 and d2.s._hero_book_cache == nil)
end

-- 23. Trapper shapes ----------------------------------------------------------------------------------------------
do
    local d = newDefer(); d.defer(d.s, BOOK); d.wrapped = true; d.pump()
    check("23: already wrapped -> direct call, no nested wrap", d.wraps == 0 and #d.hydrates == 1 and d.swaps == 1)
    local d2 = newDefer(); d2.defer(d2.s, BOOK); d2.pump()
    check("23: not wrapped -> wrapped exactly once, hydrate ran inside the wrap", d2.wraps == 1 and d2.hydrates[1].wrapped == true)
    local d3 = newDefer({ no_trapper = true }); d3.defer(d3.s, BOOK); d3.pump()
    check("23: no Trapper module -> direct call", #d3.hydrates == 1 and d3.swaps == 1 and d3.hydrates[1].wrapped == false)
    local d4 = newDefer({ trapper = { } }); d4.defer(d4.s, BOOK); d4.pump()
    check("23: Trapper without wrap/isWrapped -> direct call", #d4.hydrates == 1 and d4.swaps == 1)
end

-- 24. bitmaps are never freed -------------------------------------------------------------------------------------
do
    local freed = 0
    local function bb() return { free = function() freed = freed + 1 end } end
    local d = newDefer({ preview = { filepath = FP, phase = 1, cover_bb = bb() } })
    d.result = function(b) return { filepath = b.filepath, phase = 2, cover_bb = bb() }, false end
    d.defer(d.s, BOOK); d.pump()
    check("24: landed record: neither the phase-1 bb nor the new bb is freed by the function", freed == 0 and d.s._preview_book.phase == 2)
    local d2 = newDefer(); d2.result = function(b) return { filepath = b.filepath, cover_bb = bb() }, false end
    d2.defer(d2.s, BOOK); d2.on_hydrate = function(s) s._closed = true end; d2.pump()
    check("24: a DISCARDED record's bb is not freed either (dropped, not freed)", freed == 0)
end

-- 25. API edges ---------------------------------------------------------------------------------------------------
do
    local d = newDefer({ no_tick_after_next = true }); d.defer(d.s, BOOK)
    check("25: no tickAfterNext -> falls back to nextTick, still not synchronous", #d.nextticks == 1 and #d.hydrates == 0)
    d.nextticks[1](); check("25: the nextTick fallback runs the work", #d.hydrates == 1 and d.swaps == 1)
    local d2 = newDefer(); d2.defer(d2.s, nil); d2.defer(d2.s, { title = "no path" })
    check("25: nil book / no filepath -> nothing queued, token not touched", #d2.ticks == 0 and d2.s._bo_detail_token == nil and #d2.logs == 0)
    -- a second book's deferral never lets the first one swap
    local d3 = newDefer(); d3.defer(d3.s, BOOK)
    d3.s._preview_book = { filepath = "bookorbit://8" }
    d3.defer(d3.s, { filepath = "bookorbit://8" })
    d3.pump()
    check("25: book A then book B (both pending): A inert, B works, hero ends on B",
        d3.swaps == 1 and d3.s._preview_book.filepath == "bookorbit://8" and d3.s._preview_book.phase == 2 and #d3.hydrates == 1)
end

-- 26. static --------------------------------------------------------------------------------------------------------
do
    check("26: queued with tickAfterNext(run) and wrapped like _previewBook", countPlain(DEFER_TXT, "UIManager:tickAfterNext(run)") == 1
        and countPlain(DEFER_TXT, "Trapper:wrap(work)") == 1 and countPlain(DEFER_TXT, "if Trapper:isWrapped() then") == 1)
    check("26: the fetch is the FULL _hydrateBook(book) (no opts, no no_fetch)", countPlain(DEFER_TXT, "self_:_hydrateBook(book)") == 1 and not DEFER_TXT:find("no_fetch", 1, true))
    check("26: the function never frees a bitmap", not DEFER_TXT:find(":free(", 1, true))
    check("26: dbg lines present (deferred / landed / dropped)", DEFER_TXT:find("bo hero detail: deferred", 1, true) and DEFER_TXT:find("bo hero detail: landed ms=", 1, true)
        and DEFER_TXT:find("bo hero detail: dropped reason=", 1, true))
    local callers = 0
    for _, l in ipairs(splitLines(WIDGET_SRC)) do
        local code = l:match("^%s*(.-)%s*$")
        if code:sub(1, 2) ~= "--" and code:find("_deferBookOrbitDetail(", 1, true) and not code:find("^function BookshelfWidget:_deferBookOrbitDetail") then callers = callers + 1 end
    end
    check("26: since H4 exactly one caller of _deferBookOrbitDetail (in _previewBookWork, see section 27)", callers == 1, callers)
    check("26: defined once, right after _hydrateBook", countPlain(WIDGET_SRC, "function BookshelfWidget:_deferBookOrbitDetail(book)") == 1
        and WIDGET_SRC:find("function BookshelfWidget:_hydrateBook(", 1, true) < WIDGET_SRC:find("function BookshelfWidget:_deferBookOrbitDetail(", 1, true))
end

-- ===== H4: wiring in BookshelfWidget:_previewBookWork (MAIN path only) ==========================================
-- _previewBookWork is far too large to run off-device, so the wiring is checked STATICALLY (text order / shape);
-- additionally the slice "hydrate .. stash .. defer" of the main path is extracted and RUN under stubs.
local PBW = extractFn(WIDGET_SRC, "BookshelfWidget:_previewBookWork(")
local function pos(s, needle, init) return (s:find(needle, init or 1, true)) end
local HYD   = "    local rec, pending = self:_hydrateBook(book, { no_fetch = true })\n    self._preview_book = rec\n"
local STASH = "    if self._preview_book and self._preview_book.filepath == book.filepath\n            and self._preview_book ~= book then\n        self._hero_book_cache = self._preview_book\n    end\n"
local DEFER = "\n    if pending then self:_deferBookOrbitDetail(book) end\n"
do
    local p_micro  = pos(PBW, 'if self._hero_mode == "micro" then')
    local p_t0     = pos(PBW, "    local _perf_t0 = _gettime()\n")
    local p_same   = pos(PBW, "if self._preview_book and self._preview_book.filepath == book.filepath then\n        logger.dbg(")
    local p_hyd    = pos(PBW, HYD)
    local p_quotes = pos(PBW, "rerollBook() end)\n    -- Stash", p_hyd)
    local p_stash  = pos(PBW, STASH)
    local p_defer  = pos(PBW, DEFER)
    local p_bound  = pos(PBW, "    if was_diff ~= is_diff then")
    local p_swap1  = pos(PBW, "self:_swapHeroInPlace()", p_t0)
    local p_ring1  = pos(PBW, "self:_repaintSelectionHighlight(", p_t0)
    local p_rebuild = pos(PBW, "self:_rebuild()", p_t0)
    check("27: all anchors found", p_micro and p_t0 and p_same and p_hyd and p_stash and p_defer and p_bound and p_swap1 and p_ring1 and p_rebuild)

    check("27: main path hydrates with { no_fetch = true } exactly once, as a plain multi-assignment followed by _preview_book = rec", countPlain(PBW, HYD) == 1
        and countPlain(PBW, "_hydrateBook(book, { no_fetch = true })") == 1)
    check("27: no blocking _hydrateBook(book) is left in the main path (everything after the micro branch)", not PBW:sub(p_t0):find("_hydrateBook(book)", 1, true))
    check("27: the micro branch still calls _hydrateBook(book) WITHOUT opts, once", countPlain(PBW:sub(p_micro, p_t0), "self._preview_book = self:_hydrateBook(book)\n") == 1
        and not PBW:sub(p_micro, p_t0):find("no_fetch", 1, true))
    check("27: the micro branch has no deferral", not PBW:sub(p_micro, p_t0):find("_deferBookOrbitDetail", 1, true))
    check("27: exactly one _deferBookOrbitDetail call in the function", countPlain(PBW, "_deferBookOrbitDetail(") == 1)
    check("27: the call is `if pending then ... end` at function top level (4-space indent), not inside a branch", countPlain(PBW, DEFER) == 1)
    check("27: order: hydrate < quotes reroll < stash < defer < boundary branch",
        p_hyd < p_quotes and p_quotes < p_stash and p_stash < p_defer and p_defer < p_bound, table.concat({ p_hyd, p_quotes, p_stash, p_defer, p_bound }, ","))
    check("27: the hydrate comes before the first hero swap, selection-ring repaint and rebuild of the main path", p_hyd < p_swap1 and p_hyd < p_ring1 and p_hyd < p_rebuild)
    check("27: the defer comes before every swap / ring repaint / rebuild after it (all branches return, one call site covers them)",
        p_defer < p_swap1 and p_defer < p_ring1 and p_defer < p_rebuild)
    check("27: the stash block is byte-for-byte the pre-H4 block", countPlain(PBW, STASH) == 1)
    check("27: `_tap_selected_fp = nil` still the first statement-level reset and the open-same branch is intact and BEFORE the hydrate",
        countPlain(PBW, "    self._tap_selected_fp = nil\n") == 1 and p_same < p_hyd and countPlain(PBW, "branch=open-same") == 1
        and countPlain(PBW, "        self:_openBook(book)\n        return\n") == 1)
    check("27: the boundary / plain / cold branches are untouched (still present, in order)",
        pos(PBW, "branch=swap+chipinplace") and pos(PBW, "branch=rebuild") and pos(PBW, "branch=swap tap_gap") and pos(PBW, "branch=cold-rebuild")
        and pos(PBW, "branch=swap+chipinplace") < pos(PBW, "branch=swap tap_gap") and pos(PBW, "branch=swap tap_gap") < pos(PBW, "branch=cold-rebuild"))
    -- nothing else in the widget passes no_fetch, and the other call sites keep their form
    local nf = 0
    for _, l in ipairs(splitLines(WIDGET_SRC)) do
        local code = l:match("^%s*(.-)%s*$")
        if code:sub(1, 2) ~= "--" and code:find("no_fetch = true", 1, true) then nf = nf + 1 end
    end
    check("27: `no_fetch = true` appears in exactly one non-comment place in the whole widget (the OPDS `no_fetch` parameter of _expandOpdsNav is unrelated)", nf == 1, nf)
    check("27: expanded-shelf tap work() unchanged", countPlain(WIDGET_SRC, "                        bw._preview_book = bw:_hydrateBook(b)\n                        bw:_opdsEnsurePreviewCover(bw._preview_book)\n") == 1)
    check("27: _buildHero still hydrates in full (assignment, no opts)", countPlain(WIDGET_SRC, "            current = self:_hydrateBook(self._preview_book)\n") == 1)
    check("27: the direct repo caller (cursor restore) unchanged", countPlain(WIDGET_SRC, "Repo.buildPreviewBook(sel_fp, self._preview_book) or self._preview_book") == 1)
    check("27: _previewBook (the Trapper wrapper) unchanged: wraps _previewBookWork", countPlain(WIDGET_SRC, "    self_:_previewBookWork(book, tap_t)\n") == 1)
end

-- 28. RUN the slice hydrate .. stash .. defer of the real main path under stubs -------------------------------
do
    local a = PBW:find(HYD, 1, true)
    local b = PBW:find("    local _perf_t2 = _gettime()\n", a, true)
    local SLICE = PBW:sub(a, b - 1)
    local function run(hyd_ret_rec, hyd_ret_pending, book, preview_before)
        local env
        env = { pcall = pcall, require = function() return { rerollBook = function() env.rerolls = env.rerolls + 1 end } end, rerolls = 0 }
        local self_ = { _preview_book = preview_before, calls = {} }
        function self_:_hydrateBook(bk, opts) self_.calls[#self_.calls + 1] = "hydrate"; self_.hopts = opts; return hyd_ret_rec, hyd_ret_pending end
        function self_:_deferBookOrbitDetail(bk) self_.calls[#self_.calls + 1] = "defer"; self_.defer_arg = bk end
        env.self, env.book = self_, book
        -- the slice reads self/book: hand them in as locals
        local g = assert(load("local self, book = ...\n" .. SLICE, "=slice", "t", env))
        g(self_, book)
        return self_, env
    end
    local book = { filepath = FP, title = "T" }
    local rec = { filepath = FP, title = "T", phase = 1 }
    local s1, e1 = run(rec, true, book, nil)
    check("28: pending: hydrate called once with { no_fetch = true }, then the deferral with the SAME book, after the stash",
        table.concat(s1.calls, ",") == "hydrate,defer" and s1.hopts and s1.hopts.no_fetch == true and s1.defer_arg == book)
    check("28: pending: _preview_book = the record and it is stashed in _hero_book_cache; quotes rerolled once",
        s1._preview_book == rec and s1._hero_book_cache == rec and e1.rerolls == 1)
    local s2 = run({ filepath = FP, phase = 2, description = "cached" }, false, book, nil)
    check("28: not pending (cache hit / non-BookOrbit): NO deferral, record stashed", table.concat(s2.calls, ",") == "hydrate" and s2._hero_book_cache == s2._preview_book and s2._preview_book.phase == 2)
    local s3 = run(book, false, book, nil)
    check("28: hydrate returned the shelf record itself (nothing built): not stashed, no deferral", s3._preview_book == book and s3._hero_book_cache == nil and table.concat(s3.calls, ",") == "hydrate")
    local s4 = run({ filepath = "bookorbit://99" }, true, book, nil)
    check("28: a record for another filepath is never stashed (but pending still defers: phase 2 re-validates)", s4._hero_book_cache == nil and table.concat(s4.calls, ",") == "hydrate,defer")
end

print(string.format("test_bo_ringfirst: %d passed, %d failed", passes, fails))
return fails > 0
