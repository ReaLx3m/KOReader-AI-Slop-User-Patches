# BookOrbit micro-module tests (run off-device)

No KOReader needed: KOReader modules are stubbed. The Lua suites need `pip install lupa`.

Needs only Python (no Lua): structural checks of every Lua file, `require` targets,
the module keys/flags/summaries and `.pot` coverage. Add `--write` to the `pot`
check to append missing msgids to `locale/bookshelf.pot`.

    python3 -I tools/bo_tests/static_check.py
    python3 -I tools/bo_tests/static_check.py pot --write

    python3 -I tools/bo_tests/parse_check.py lib/bookshelf_bo_data.lua ...        # parse check
    python3 -I tools/bo_tests/run_lua_test.py "$PWD" tools/bo_tests/test_bo_data.lua    # data layer
    python3 -I tools/bo_tests/run_lua_test.py "$PWD" tools/bo_tests/test_bo_module.lua  # adapter + tap regions
    python3 -I tools/bo_tests/run_lua_test.py "$PWD" tools/bo_tests/test_bo_actions.lua # tap actions
    python3 -I tools/bo_tests/run_lua_test.py "$PWD" tools/bo_tests/test_bo_batch5.lua  # Library/Device actions, per-card state, the 16 specs
    python3 -I tools/bo_tests/run_lua_test.py "$PWD" tools/bo_tests/test_bo_picker.lua  # "Shelf from your library" add flow
    python3 -I tools/bo_tests/run_lua_test.py "$PWD" tools/bo_tests/test_bo_batch6a.lua # decor specs, sprite data, vendored decor module
    python3 -I tools/bo_tests/run_lua_test.py "$PWD" tools/bo_tests/test_bo_batch6b.lua # data-driven decor specs, dust actions

These prove the logic (caching, TTL, shared fetch, queues, hints). They do NOT
prove drawing, fonts, SVG icons or touch handling: that needs a real device.
