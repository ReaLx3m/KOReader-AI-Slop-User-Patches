# BookOrbit micro-module tests (run off-device)

No KOReader needed: KOReader modules are stubbed. The Lua suites need `pip install lupa`.

Needs only Python (no Lua): structural checks of every Lua file, `require` targets,
the module keys/flags/summaries and `.pot` coverage. Add `--write` to the `pot`
check to append missing msgids to `locale/bookshelf.pot`.

    python3 -I tools/bo_tests/static_check.py
    python3 -I tools/bo_tests/static_check.py pot --write

    python3 -I tools/bo_tests/parse_check.py lib/bookshelf_bo_data.lua ...        # parse check
    python3 -I tools/bo_tests/run_lua_test.py "$PWD" tools/bo_tests/test_bo_data.lua    # data layer
    python3 -I tools/bo_tests/run_lua_test.py "$PWD" tools/bo_tests/test_bo_module.lua  # adapter + tap regions
    python3 -I tools/bo_tests/run_lua_test.py "$PWD" tools/bo_tests/test_bo_actions.lua # tap actions
    python3 -I tools/bo_tests/run_lua_test.py "$PWD" tools/bo_tests/test_bo_batch5.lua  # Library/Device actions, per-card state, the 16 specs
    python3 -I tools/bo_tests/run_lua_test.py "$PWD" tools/bo_tests/test_bo_picker.lua  # "Shelf from your library" add flow
    python3 -I tools/bo_tests/run_lua_test.py "$PWD" tools/bo_tests/test_bo_batch6a.lua # decor specs, sprite data, vendored decor module
    python3 -I tools/bo_tests/run_lua_test.py "$PWD" tools/bo_tests/test_bo_batch6b.lua # data-driven decor specs, dust actions
    python3 -I tools/bo_tests/run_lua_test.py "$PWD" tools/bo_tests/test_bo_wifi.lua    # Auto Wi-Fi controller, settings API, migration
    python3 -I tools/bo_tests/run_lua_test.py "$PWD" tools/bo_tests/test_bo_sleep.lua   # Auto Wi-Fi sync on sleep
    python3 -I tools/bo_tests/run_lua_test.py "$PWD" tools/bo_tests/test_bo_guard.lua   # pull-before-push guard, pending outbox
    python3 -I tools/bo_tests/run_lua_test.py "$PWD" tools/bo_tests/test_bo_wake.lua    # pull on wake
    python3 -I tools/bo_tests/run_lua_test.py "$PWD" tools/bo_tests/test_bo_fresh.lua   # section freshness: helpers, controller, glue, catalog chips (302 checks)
    python3 -I tools/bo_tests/run_lua_test.py "$PWD" tools/bo_tests/test_bo_covers.lua  # cover speed: repaint coalescer incl. gap-from-flush-end and E1 hold + E2 static wiring checks and S3 and S4 checks (174 checks; S3: the real source text of SpineWidget.imageDims/fillScale and the pieces they call is extracted and RUN against stubs, plus static checks of the widget's prescaler registration, its per-book size maths vs ShelfRow, and its teardown; S4: the real text of BookshelfWidget:_syncCoverTile is extracted and RUN against stubs (geometry signature, class-level, notifies the source), plus the two call sites)
    python3 -I tools/bo_tests/run_lua_test.py "$PWD" tools/bo_tests/test_bo_coverpool.lua # cover speed: pure download pool, fake forks (174 checks; incl. on_idle, cancelDecode and the decode_left argument)
    python3 -I tools/bo_tests/run_lua_test.py "$PWD" tools/bo_tests/test_bo_wiring.lua   # cover speed: cover pool AND async page fetch wired into the REAL bookorbit source, fake fork/clock/lfs/Cache, real temp page files (446 checks; incl. section 9 (S2: the prescale hook of the prefetch pool with a fake prescaler, scenarios 9.1-9.17; S4: M.coverTileChanged, scenarios 9.18-9.27; S4b: the tile change makes the prefetch machine forget its done keys, so the waiting page is prefetched and prescaled again, scenarios 9.28-9.36), section 8 (E2 unwired: the main pool's landings carry no hold flag), section 7: next-page prefetch wiring, behavioural scenarios 7.1-7.12, static repo-gate checks 7.13 and O1 option-A checks 7.14, decode-ahead behavioural scenarios 7.15-7.26 (D3) and the sub-setting scenarios 7.27-7.32 (D5))
    python3 -I tools/bo_tests/run_lua_test.py "$PWD" tools/bo_tests/test_bo_pagefetch.lua # page fetch: pure page-list fetcher, fake forks (138 checks; wired in Batch 6, see test_bo_wiring; incl. counts().urgent)
    python3 -I tools/bo_tests/run_lua_test.py "$PWD" tools/bo_tests/test_bo_prefetch.lua # next-page prefetch: pure state machine, fake clock, plus static checks of the wiring in the real source (incl. the S2 prescale hook, the S4 tile-change tracking and the S4b done-key forgetting; S4b also has behaviour tests of Prefetch:forgetDone on the pure machine) and of the settings items (266 checks)
    python3 -I tools/bo_tests/run_lua_test.py "$PWD" tools/bo_tests/test_bo_ahead.lua    # decode-ahead holder: pure, fake bitmaps (75 checks; incl. recordBytes with LuaJIT cdata-like stride/height; wired into the source in D2, see HANDOFF_prefetch_decode_ahead)
    python3 -I tools/bo_tests/run_lua_test.py "$PWD" tools/bo_tests/test_bo_prescale.lua  # prescale in the idle prefetch tick: pure orchestration (dims/has/scale/put injected), never frees the raw bb (78 checks; wired into the source as an injected hook in S2 (M.setCoverPrescaler), the widget side (S3) registers it with the real deps in BookshelfWidget:init, checked statically in test_bo_covers.lua; see HANDOFF_prefetch_prescale)
    python3 -I tools/bo_tests/run_lua_test.py "$PWD" tools/bo_tests/test_bo_ringfirst.lua # selection ring first (BookOrbit hero): BOSource.rebuildRecord no-fetch mode run against the real source with a fake BookOrbit client, disk caches, lfs, RenderImage and Trapper (158 checks: H1 no network/popup/download in no_fetch, pending flag, cache hit/miss, cover from disk only, rating override, old path unchanged; H2 the REAL text of Repo.buildPreviewBook and BookshelfWidget:_hydrateBook run under stubs and chained to the real source, opts forwarding, two return values, plus a static audit of every _hydrateBook call site; H3 the REAL text of BookshelfWidget:_deferBookOrbitDetail run against a fake tick queue / Trapper / scripted _hydrateBook: nothing synchronous, stale / superseded / closed / failed / no-hero handling, Trapper shapes, no bitmap freed); H4 the wiring of _previewBookWork's main path: static order/shape checks of the real text, micro branch / expanded tap / _buildHero unchanged, plus a run of the hydrate-stash-defer slice under stubs
    python3 -I tools/bo_tests/run_lua_test.py "$PWD" tools/bo_tests/test_bo_hold.lua     # hold-the-previous-screen gate: layout stamp + hold/paint decision, pure (329 checks: pure gate, the widget wiring read as source, and the hold helpers, render-path pre-flight and page-ready callback run against fakes; see HANDOFF_hold_page)
    python3 -I tools/bo_tests/run_lua_test.py "$PWD" tools/bo_tests/test_bo_cachedirty.lua # BookOrbit catalog cache dirty flag: the REAL lib/bookshelf_bookorbit_cache.lua against a fake file store (read/save counters, can throw) and a fake clock (64 checks: untouched flush does no read/save, get() never dirties, flush twice = one write, debounce keeps dirty, failed save retried, invalidate/invalidatePrefix/evict/checkVersionAndInvalidate/invalidateAll cases, disk sanitising, restore round trip)

These prove the logic (caching, TTL, shared fetch, queues, hints). They do NOT
prove drawing, fonts, SVG icons or touch handling: that needs a real device.
