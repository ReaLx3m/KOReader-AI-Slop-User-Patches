-- BookOrbit catalog cache: dirty flag (Batch 2). Runs the REAL
-- lib/bookshelf_bookorbit_cache.lua against a fake file store (counts
-- read/save calls, can be told to throw) and a fake clock (os.time).
-- Proves the LOGIC only; nothing here was run on a device.
local fails, passes = 0, 0
local function check(n, c, x)
    if c then passes = passes + 1
    else fails = fails + 1; print("FAIL: " .. n .. (x ~= nil and (" -> " .. tostring(x)) or "")) end
end

local real_time = os.time
local clock = 1000
os.time = function() return clock end

-- Fresh module + fresh fakes per scenario (the module keeps upvalue state).
local function env(opts)
    opts = opts or {}
    local e = { reads = 0, saves = 0, fail = false, disk = opts.disk, last = nil, mb = opts.mb or 64 }
    package.loaded["lib/bookshelf_settings_store"] = {
        read = function(k) if k == "bookorbit_cache_mb" then return e.mb end return nil end,
    }
    package.loaded["lib/bookshelf_file_store"] = { new = function()
        return {
            read = function(_, def) e.reads = e.reads + 1; if e.disk ~= nil then return e.disk end return def end,
            save = function(_, v)
                e.saves = e.saves + 1
                if e.fail then error("disk full") end
                e.last = v; e.disk = v
            end,
        }
    end }
    package.loaded["lib/bookshelf_bookorbit_cache"] = nil
    e.C = dofile(PLUGIN .. "/lib/bookshelf_bookorbit_cache.lua")
    return e
end

-- 1. never touched
do
    local e = env()
    e.C.flush()
    check("1.1 flush before any use: no read", e.reads == 0)
    check("1.2 flush before any use: no save", e.saves == 0)
    check("1.3 not dirty", e.C.isDirty() == false)
    e.C.flush(); e.C.flush()
    check("1.4 repeated flush still nothing", e.reads == 0 and e.saves == 0)
end

-- 2. get() alone / loaded from existing file
do
    local e = env{ disk = { entries = { a = { value = { 1 }, bytes = 50 } }, order = { "a" }, used_bytes = 50, version = "v7" } }
    local v = e.C.get("a")
    check("2.1 existing file restored", v and v[1] == 1)
    check("2.2 file read exactly once", e.reads == 1)
    check("2.3 loaded state is clean", e.C.isDirty() == false)
    check("2.4 version carried forward", e.C.currentVersion() == "v7")
    check("2.5 used bytes restored", e.C.usedBytes() == 50)
    e.C.get("a"); e.C.get("missing")
    check("2.6 get (hit/miss) never dirties", e.C.isDirty() == false)
    e.C.flush()
    check("2.7 flush after only gets: no write", e.saves == 0)
    check("2.8 no second read", e.reads == 1)
end

-- 3. set -> flush -> flush
do
    local e = env()
    e.C.set("a", { 1 })
    check("3.1 first set writes immediately (no prior flush time)", e.saves == 1)
    check("3.2 clean after successful write", e.C.isDirty() == false)
    e.C.flush()
    check("3.3 flush when clean: no write", e.saves == 1)
    -- change inside debounce window: skipped, dirty stays
    e.C.set("b", { 2 })
    check("3.4 set inside debounce window: skipped", e.saves == 1)
    check("3.5 skipped write leaves dirty", e.C.isDirty() == true)
    e.C.flush()
    check("3.6 flush writes the debounced change once", e.saves == 2 and e.C.isDirty() == false)
    e.C.flush()
    check("3.7 second flush: 0 writes", e.saves == 2)
    check("3.8 payload has both entries", e.last.entries.a and e.last.entries.b)
    check("3.9 payload order", e.last.order[1] == "a" and e.last.order[2] == "b")
    check("3.10 payload used_bytes matches", e.last.used_bytes == e.C.usedBytes())
end

-- 4. debounce window expiry
do
    clock = 1000
    local e = env()
    e.C.set("a", 1)                       -- t=1000 write
    clock = 1010; e.C.set("b", 2)         -- skipped
    check("4.1 skipped inside window", e.saves == 1 and e.C.isDirty())
    clock = 1031; e.C.set("c", 3)         -- window passed
    check("4.2 write once window passed", e.saves == 2 and not e.C.isDirty())
    check("4.3 includes skipped change", e.last.entries.b ~= nil and e.last.entries.c ~= nil)
end

-- 5. failing save
do
    clock = 1000
    local e = env()
    e.fail = true
    local ok = pcall(e.C.set, "a", 1)
    check("5.1 set does not throw on save failure", ok)
    check("5.2 failed save keeps dirty", e.C.isDirty() == true and e.saves == 1)
    e.C.set("b", 2)                       -- same second: debounced, not retried per set
    check("5.3 failing disk not retried on every set", e.saves == 1)
    e.C.flush()
    check("5.4 flush retries (still failing)", e.saves == 2 and e.C.isDirty())
    e.fail = false
    e.C.flush()
    check("5.5 flush retries and succeeds", e.saves == 3 and not e.C.isDirty())
    e.C.flush()
    check("5.6 no write after recovery", e.saves == 3)
end

-- 6. invalidate
do
    clock = 1000
    local e = env()
    e.C.set("a", 1); clock = 2000; e.C.flush()
    local s = e.saves
    e.C.invalidate("missing")
    check("6.1 invalidate(missing) does not dirty", not e.C.isDirty())
    e.C.flush()
    check("6.2 ... and flush writes nothing", e.saves == s)
    e.C.invalidate("a")
    check("6.3 invalidate(existing) writes (window passed)", e.saves == s + 1 and not e.C.isDirty())
    check("6.4 entry gone from payload", e.last.entries.a == nil and #e.last.order == 0)
    e.C.set("p:1", 1); e.C.set("p:2", 2); e.C.set("q:1", 3)
    clock = 3000; e.C.flush(); s = e.saves
    e.C.invalidatePrefix("zzz:")
    check("6.5 invalidatePrefix with no match: clean", not e.C.isDirty() and e.saves == s)
    e.C.invalidatePrefix("p:")   -- same second as the last write: debounced
    check("6.6 invalidatePrefix with match: dirty, debounced", e.C.isDirty() and e.saves == s)
    e.C.flush()
    check("6.6b flush writes the prefix removal once", e.saves == s + 1)
    check("6.7 only matching removed", e.last.entries["p:1"] == nil and e.last.entries["q:1"] ~= nil)
end

-- 7. evict
do
    clock = 1000
    local e = env{ mb = 1 }
    local big = string.rep("x", 600 * 1024)
    e.C.set("a", big)
    clock = 2000; e.C.flush()
    local s = e.saves
    check("7.1 under budget: nothing dropped", e.last.entries.a ~= nil)
    e.C.set("b", big)                     -- over 1 MB: drops "a"
    check("7.2 over-budget set writes", e.saves == s + 1)
    check("7.3 LRU victim dropped from payload", e.last.entries.a == nil and e.last.entries.b ~= nil)
    check("7.4 used_bytes consistent", e.last.used_bytes == e.C.usedBytes())
    check("7.5 clean afterwards", not e.C.isDirty())
    e.C.get("b")
    check("7.6 get after evict does not dirty", not e.C.isDirty())
end

-- 8. checkVersionAndInvalidate
do
    clock = 1000
    local e = env()
    check("8.1 nil -> skipped", e.C.checkVersionAndInvalidate(nil) == "skipped")
    check("8.2 nil: no write, not dirty", e.saves == 0 and not e.C.isDirty())
    check("8.3 first version -> kept", e.C.checkVersionAndInvalidate("v1") == "kept")
    check("8.4 new version: exactly one write", e.saves == 1 and e.last.version == "v1")
    check("8.5 same version -> kept", e.C.checkVersionAndInvalidate("v1") == "kept")
    check("8.6 same version: no write", e.saves == 1)
    check("8.7 changed version", e.C.checkVersionAndInvalidate("v2") == "changed")
    check("8.8 changed version writes immediately inside window", e.saves == 2 and e.last.version == "v2")
end

-- 9. invalidateAll
do
    clock = 1000
    local e = env()
    e.C.set("a", 1)                       -- write at 1000
    clock = 1001
    e.C.invalidateAll()
    check("9.1 invalidateAll writes inside debounce window", e.saves == 2)
    check("9.2 payload empty", next(e.last.entries) == nil and #e.last.order == 0 and e.last.used_bytes == 0)
    check("9.3 clean after", not e.C.isDirty())
    e.C.flush()
    check("9.4 flush after invalidateAll: nothing", e.saves == 2)
    -- fresh module, never touched: invalidateAll still wipes the disk file
    local e2 = env{ disk = { entries = { a = { value = 1, bytes = 9 } }, order = { "a" }, used_bytes = 9 } }
    e2.C.invalidateAll()
    check("9.5 invalidateAll on a loaded-clean cache writes", e2.saves == 1 and next(e2.last.entries) == nil)
end

-- 10. payload sanitising still works
do
    clock = 1000
    local e = env()
    e.C.set("rec", { title = "t", cover_bb = {}, cover_w = 1, cover_h = 2, _cover_filled = true, fn = function() end })
    local rec = e.last and e.last.entries.rec.value
    check("10.1 cover fields stripped on disk", rec and rec.cover_bb == nil and rec.cover_w == nil
        and rec.cover_h == nil and rec._cover_filled == nil)
    check("10.2 functions stripped, plain data kept", rec and rec.fn == nil and rec.title == "t")
    local live = e.C.get("rec")
    check("10.3 live RAM copy keeps cover_bb", live.cover_bb ~= nil and live._cover_filled == true)
end

-- 11. round trip: written state loads back clean in a new session
do
    clock = 1000
    local e = env()
    e.C.set("a", { 1, 2 }); e.C.checkVersionAndInvalidate("v9")
    local saved = e.disk
    local e2 = env{ disk = saved }
    check("11.1 restored value", e2.C.get("a")[2] == 2)
    check("11.2 restored version", e2.C.currentVersion() == "v9")
    e2.C.flush()
    check("11.3 restored session flush: no write", e2.saves == 0)
end

os.time = real_time
print(string.format("test_bo_cachedirty: %d passed, %d failed", passes, fails))
return fails > 0 and 1 or 0
