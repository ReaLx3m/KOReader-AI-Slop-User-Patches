import sys, pathlib
from lupa import LuaRuntime
lua = LuaRuntime()
chk = lua.eval("function(f) local fn,e=loadfile(f) return fn and 'ok' or e end")
bad = 0
for p in sys.argv[1:]:
    r = chk(p)
    if r != 'ok':
        bad += 1; print("FAIL", p, r)
print("checked", len(sys.argv)-1, "files,", bad, "failures")
sys.exit(1 if bad else 0)
