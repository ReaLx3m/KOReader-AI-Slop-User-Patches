-- Auto Wi-Fi controller + settings API + migration. Off-device: NetworkMgr,
-- UIManager and the settings store are fakes; time is a fake scheduler.
package.path = PLUGIN .. "/?.lua;" .. package.path
local fails, passes = 0, 0
local function check(n, c, x)
    if c then passes = passes + 1
    else fails = fails + 1; print("FAIL: " .. n .. (x ~= nil and (" -> " .. tostring(x)) or "")) end
end

package.preload["logger"] = function() return { warn = function() end, info = function() end, dbg = function() end, err = function() end } end

-- ---------------------------------------------------------------------
-- fake scheduler (UIManager:scheduleIn / unschedule) with virtual time
-- ---------------------------------------------------------------------
local function newUI()
    local ui = { t = 0, q = {} }
    function ui:scheduleIn(secs, fn) table.insert(self.q, { at = self.t + secs, fn = fn }) end
    function ui:unschedule(fn)
        for i = #self.q, 1, -1 do if self.q[i].fn == fn then table.remove(self.q, i) end end
    end
    function ui:advance(secs)
        local target = self.t + secs
        while true do
            local best, bi
            for i, e in ipairs(self.q) do
                if e.at <= target and (not best or e.at < best.at) then best, bi = e, i end
            end
            if not best then break end
            table.remove(self.q, bi)
            self.t = math.max(self.t, best.at)
            best.fn()
        end
        self.t = target
    end
    return ui
end

-- fake NetworkMgr. connect_after = seconds until a turned-on radio is online
-- (nil = never comes online).
local function newNet(ui, o)
    o = o or {}
    local n = { wifi_on = o.wifi_on or false, online = o.online or false,
                connect_after = o.connect_after, on_calls = {}, off_calls = 0 }
    function n:isWifiOn() return self.wifi_on end
    function n:isOnline() return self.online end
    function n:turnOnWifi(cb, interactive)
        table.insert(self.on_calls, { interactive = interactive })
        self.wifi_on = true
        if self.connect_after then
            ui:scheduleIn(self.connect_after, function() self.online = true; if cb then cb() end end)
        end
    end
    function n:turnOffWifi() self.wifi_on = false; self.online = false; self.off_calls = self.off_calls + 1 end
    return n
end

local Wifi = require("lib/bookshelf_bookorbit_wifi")

local function make(o)
    o = o or {}
    local ui = newUI()
    local net = newNet(ui, o.net)
    local cfg = { enabled = o.enabled ~= false, off_in_book = o.off_in_book or false }
    local hooks_log = { off = 0, online = 0 }
    local w = Wifi.new{
        network = net, ui = ui,
        settings = { enabled = function() return cfg.enabled end, off_in_book = function() return cfg.enabled and cfg.off_in_book end },
        hooks = { notify_wifi_off = function() hooks_log.off = hooks_log.off + 1 end,
                  on_online = function() hooks_log.online = hooks_log.online + 1 end },
    }
    return w, ui, net, cfg, hooks_log
end

-- ---------------------------------------------------------------------
-- disabled
-- ---------------------------------------------------------------------
do
    local w, ui, net, cfg = make{ enabled = false }
    local ready = 0
    local lease = w:acquire("sync", function() ready = ready + 1 end)
    check("A1 disabled: on_ready runs at once, no lease, radio untouched",
        ready == 1 and lease == nil and #net.on_calls == 0)
    w:trigger("startup"); w:noteBookOpened(); w:noteBookClosed(true); w:release(lease)
    ui:advance(500)
    check("A2 disabled: trigger/open/close never touch the radio",
        #net.on_calls == 0 and net.off_calls == 0)
    check("A3 disabled: skip-offline is not bypassed", w:shouldBypassSkipOffline() == false)
end

-- ---------------------------------------------------------------------
-- leases
-- ---------------------------------------------------------------------
do
    local w, ui, net = make{ net = { wifi_on = true, online = true } }
    local ready = 0
    local lease = w:acquire("sync", function() ready = ready + 1 end)
    check("B1 already online: ready immediately, no turn-on", ready == 1 and #net.on_calls == 0 and w.count == 1)
    w:release(lease)
    check("B2 release with no book open leaves Wi-Fi on", net.off_calls == 0 and w.count == 0)
    w:release(lease); w:release(nil)
    check("B3 release is idempotent and nil-safe", w.count == 0)
end

do
    local w, ui, net = make{ net = { connect_after = 4 } }
    local ready, failed = 0, 0
    w:acquire("sync", function() ready = ready + 1 end, function() failed = failed + 1 end)
    check("C1 offline: turned on once, non-interactive",
        #net.on_calls == 1 and net.on_calls[1].interactive == false and ready == 0)
    ui:advance(10)
    check("C2 ready fires once after connect, no failure", ready == 1 and failed == 0)
end

do
    -- two overlapping leases share one connect; radio stays up until the last is released
    local w, ui, net, cfg, hooks = make{ off_in_book = true, net = { connect_after = 3 } }
    local r1, r2 = 0, 0
    local l1 = w:acquire("close-push", function() r1 = r1 + 1 end)
    local l2 = w:acquire("open-pull", function() r2 = r2 + 1 end)
    check("D1 overlapping leases share one turn-on", #net.on_calls == 1)
    ui:advance(10)
    check("D2 both leases got ready", r1 == 1 and r2 == 1 and w.count == 2)
    w:noteBookOpened()
    check("D3 book open with leases held: Wi-Fi stays on", net.off_calls == 0)
    w:release(l1)
    check("D4 first release keeps Wi-Fi on (other job still running)", net.off_calls == 0 and net.online)
    w:release(l2)
    check("D5 last release with book open + off_in_book turns Wi-Fi off", net.off_calls == 1 and not net.online)
    check("D6 shelf icon hook fired once", hooks.off == 1)
end

do
    -- same, but off_in_book off: last release does not turn it off
    local w, ui, net = make{ off_in_book = false, net = { wifi_on = true, online = true } }
    local l = w:acquire("x", function() end)
    w:noteBookOpened()
    w:release(l)
    check("D7 off_in_book off: Wi-Fi stays on in a book", net.off_calls == 0)
end

do
    -- timeout
    local w, ui, net = make{ net = {} }   -- never connects
    local ready, err = 0, nil
    w:acquire("sync", function() ready = ready + 1 end, function(e) err = e end, { timeout = 10 })
    ui:advance(9)
    check("E1 not failed before the cap", err == nil)
    ui:advance(3)
    check("E2 on_fail('timeout') after the cap, lease count back to 0", err == "timeout" and ready == 0 and w.count == 0)
    check("E3 polling stopped after failure", w.connecting == false and not w.poll_pending)
    net.connect_after = 2
    net.wifi_on = false      -- radio fell back off, so the next lease turns it on again
    local ok2 = 0
    w:acquire("sync", function() ok2 = ok2 + 1 end)
    ui:advance(5)
    check("E4 later lease works after a failed one", ok2 == 1)
end

-- ---------------------------------------------------------------------
-- manual off
-- ---------------------------------------------------------------------
do
    local w, ui, net = make{ net = { wifi_on = true, online = true } }
    -- user switches Wi-Fi off from the menu: radio off, broadcast arrives
    net.wifi_on, net.online = false, false
    w:onNetworkDisconnected()
    check("F1 user turned it off -> manual_off", w.manual_off == true)
    w:reconcile(); ui:advance(300)
    check("F2 nothing reconnects while manual_off", #net.on_calls == 0)
    local err
    local l = w:acquire("sync", function() end, function(e) err = e end)
    check("F3 plain acquire fails with manual_off, no turn-on", err == "manual_off" and l == nil and #net.on_calls == 0)
    net.connect_after = 2
    local ready = 0
    w:acquire("sync-now", function() ready = ready + 1 end, nil, { trigger = true })
    ui:advance(5)
    check("F4 acquire with trigger clears manual_off and connects", ready == 1 and w.manual_off == false)
end

do
    local w, ui, net = make{ net = { wifi_on = true, online = true } }
    net.wifi_on, net.online = false, false
    w:onNetworkDisconnected()
    net.connect_after = 2
    w:trigger("wake_home")
    ui:advance(5)
    check("F5 trigger clears manual_off and reconnects", w.manual_off == false and net.online and #net.on_calls == 1)
end

do
    -- our own turn-off is not a manual off
    local w, ui, net = make{ off_in_book = true, net = { wifi_on = true, online = true } }
    w:noteBookOpened()   -- no leases -> we turn it off
    check("G1 setup: we turned it off", net.off_calls == 1)
    w:onNetworkDisconnected()
    check("G2 broadcast after our own turn-off is not a manual off", w.manual_off == false)
    -- a later genuine disconnect (flag consumed): radio is off -> manual
    w:onNetworkDisconnected()
    check("G3 expected flag was consumed once", w.manual_off == true)
end

do
    -- the expected-off window expires on its own
    local w, ui, net = make{ off_in_book = true, net = { wifi_on = true, online = true } }
    w:noteBookOpened()
    ui:advance(Wifi.EXPECTED_OFF_WINDOW + 1)
    check("G4 expected-off flag clears after the window", w.expected_off == false)
end

do
    -- radio still on but link lost: not manual
    local w, ui, net = make{ net = { wifi_on = true, online = true } }
    net.online = false
    w:onNetworkDisconnected()
    check("H1 radio on but offline (out of range) is not manual off", w.manual_off == false)
end

do
    -- mid-connect broadcasts are ignored
    local w, ui, net = make{ net = { connect_after = 5 } }
    w:trigger("startup")
    net.wifi_on = false      -- platform glitch during bring-up
    w:onNetworkDisconnected()
    check("H2 broadcast during our own connect is ignored", w.manual_off == false)
end

do
    -- onNetworkConnected clears manual off
    local w, ui, net = make{ net = { wifi_on = true, online = true } }
    net.wifi_on, net.online = false, false
    w:onNetworkDisconnected()
    net.wifi_on, net.online = true, true
    w:onNetworkConnected()
    check("H3 Wi-Fi back on by other means clears manual_off", w.manual_off == false)
end

-- ---------------------------------------------------------------------
-- triggers, steady state and backoff
-- ---------------------------------------------------------------------
do
    local w, ui, net, cfg, hooks = make{ net = { connect_after = 3 } }
    w:trigger("startup")
    check("I1 trigger brings Wi-Fi up (one attempt)", #net.on_calls == 1 and w.stats.attempts == 1)
    ui:advance(10)
    check("I2 online after trigger, on_online hook fired, retry state reset",
        net.online and hooks.online == 1 and w.retry_step == 0)
    w:trigger("wake_home")
    check("I3 trigger while already online does nothing", w.stats.attempts == 1 and #net.on_calls == 1)
end

do
    -- never connects: attempts at 0, +30, +60, +120 s then stop
    local w, ui, net = make{ net = {} }
    w:trigger("startup")
    check("J1 first attempt immediate", w.stats.attempts == 1)
    ui:advance(Wifi.ATTEMPT_WINDOW + 2)          -- attempt 1 fails
    check("J2 attempt 1 failed, still one attempt, retry queued", w.stats.attempts == 1 and w.retry_pending)
    ui:advance(Wifi.RETRY_DELAYS[1])             -- +30
    check("J3 attempt 2 after 30 s", w.stats.attempts == 2)
    ui:advance(Wifi.ATTEMPT_WINDOW + Wifi.RETRY_DELAYS[2] + 2)
    check("J4 attempt 3 after a further 60 s", w.stats.attempts == 3)
    ui:advance(Wifi.ATTEMPT_WINDOW + Wifi.RETRY_DELAYS[3] + 2)
    check("J5 attempt 4 after a further 120 s", w.stats.attempts == 4)
    ui:advance(5000)
    check("J6 gives up after 4 attempts", w.stats.attempts == 4 and not w.retry_pending and not w.connecting)
    check("J7 radio only asked on once (it stays on between attempts)", #net.on_calls == 1)
    net.connect_after = 2
    net.wifi_on = false
    w:trigger("book_closed")
    ui:advance(6)
    check("J8 next trigger starts fresh and can succeed", net.online and w.stats.attempts == 5)
end

do
    -- retry stops when the state no longer wants Wi-Fi (book opened with off_in_book)
    local w, ui, net = make{ off_in_book = true, net = {} }
    w:trigger("startup")
    ui:advance(Wifi.ATTEMPT_WINDOW + 2)
    check("K1 setup: retry queued", w.retry_pending)
    w:noteBookOpened()
    check("K2 book open cancels the queued retry", not w.retry_pending)
    ui:advance(500)
    check("K3 no further attempts in the book", w.stats.attempts == 1)
end

-- ---------------------------------------------------------------------
-- book open / close policy
-- ---------------------------------------------------------------------
do
    local w, ui, net, cfg, hooks = make{ off_in_book = true, net = { wifi_on = true, online = true } }
    local pull = w:acquire("open-pull", function() end)   -- lease first
    w:noteBookOpened()                                    -- then the note
    check("L1 lease taken before noteBookOpened keeps Wi-Fi up for the pull", net.off_calls == 0)
    w:release(pull)
    check("L2 pull done -> Wi-Fi off", net.off_calls == 1 and hooks.off == 1)
    w:noteBookClosed(false)
    check("L3 close that only hands over to another book changes nothing", w.book_open == true and #net.on_calls == 0)
    net.connect_after = 2
    w:noteBookClosed(true)
    ui:advance(5)
    check("L4 close returning home reconnects", w.book_open == false and net.online)
end

do
    local w, ui, net = make{ off_in_book = true, net = { wifi_on = true, online = true } }
    w:noteBookOpened()
    check("L5 no pull: noteBookOpened turns it off right away", net.off_calls == 1)
    -- rapid close then open another book while the close-time push runs
    net.connect_after = 2
    w:noteBookClosed(true)
    local push = w:acquire("close-push", function() end)
    ui:advance(5)
    w:noteBookOpened()                  -- next book opens; push still running
    check("L6 open during a running push does not drop Wi-Fi", net.online and w.count == 1)
    w:release(push)
    check("L7 push finished -> then off", not net.online)
end

do
    -- pull fails: release still turns it off
    local w, ui, net = make{ off_in_book = true, net = {} }
    local err
    local l = w:acquire("open-pull", function() end, function(e) err = e end, { timeout = 5 })
    w:noteBookOpened()
    ui:advance(10)
    check("M1 open-time lease timing out is reported", err == "timeout")
    check("M2 and the book-open policy then turns the radio off", net.off_calls == 1 and not net.wifi_on)
end


do
    -- a timed-out lease must not skip the steady-state backoff
    local w, ui, net = make{ net = {} }
    local err
    w:acquire("sync", function() end, function(e) err = e end, { timeout = 5 })
    ui:advance(8)
    check("M3 lease timeout while wanting Wi-Fi on starts no extra attempt", err == "timeout" and w.stats.attempts == 0)
end

-- ---------------------------------------------------------------------
-- robustness
-- ---------------------------------------------------------------------
do
    local w, ui, net = make{ net = { wifi_on = true, online = true } }
    local ok = pcall(function()
        local l = w:acquire("x", function() error("boom") end, function() error("boom2") end)
        w:release(l)
    end)
    check("N1 a throwing on_ready is contained and bookkeeping stays right", ok and w.count == 0)
end

do
    -- NetworkMgr without turnOnWifi falls back to runWhenOnline
    local ui = newUI()
    local used = 0
    local net = { wifi_on = false, online = false,
        isWifiOn = function(s) return s.wifi_on end, isOnline = function(s) return s.online end,
        turnOffWifi = function() end,
        runWhenOnline = function(s, cb) used = used + 1; s.wifi_on = true
            ui:scheduleIn(1, function() s.online = true; cb() end) end }
    local w = Wifi.new{ network = net, ui = ui, settings = { enabled = function() return true end } }
    local ready = 0
    w:acquire("x", function() ready = ready + 1 end)
    ui:advance(3)
    check("N2 falls back to runWhenOnline when turnOnWifi is missing", used == 1 and ready == 1)
end

-- ---------------------------------------------------------------------
-- settings API + migration, against the REAL lib/bookshelf_bookorbit.lua
-- ---------------------------------------------------------------------
local store = {}          -- filename -> table
package.preload["datastorage"] = function() return { getSettingsDir = function() return "/s" end } end
package.preload["luasettings"] = function()
    local LS = {}
    function LS:open(file)
        store[file] = store[file] or {}
        local o = { data = store[file] }
        function o:readSetting(k) return self.data[k] end
        function o:saveSetting(k, v) self.data[k] = v end
        function o:delSetting(k) self.data[k] = nil end
        function o:isTrue(k) return self.data[k] == true end
        function o:flush() end
        return o
    end
    return LS
end
package.preload["ui/network/manager"] = function() return { isOnline = function() return false end } end
package.preload["device"] = function() return { model = "Test" } end
package.preload["ui/uimanager"] = function() return { show = function() end, scheduleIn = function() end, unschedule = function() end } end
package.preload["ui/widget/notification"] = function() return { new = function(_, o) return o end } end
package.preload["lib/bookshelf_i18n"] = function() return { gettext = function(s) return s end } end
package.preload["lib/bookshelf_bookorbit_sync_coordinator"] = function() return { PRIORITY = { auto = 1, manual = 2 }, new = function() return {} end } end
package.preload["lib/bookshelf_bookorbit_sync_job_runner"] = function() return {} end

local ok_load, BO = pcall(require, "lib/bookshelf_bookorbit")
check("P0 real bookorbit module loads under stubs", ok_load, ok_load and nil or BO)
if ok_load then
    local file = "/s/bookorbit_settings.lua"
    -- Reset IN PLACE: the module caches its settings object, which holds
    -- this very table, so replacing the table would leave it stale.
    local function reset(t)
        store[file] = store[file] or {}
        for k in pairs(store[file]) do store[file][k] = nil end
        for k, v in pairs(t or {}) do store[file][k] = v end
    end

    reset()
    check("P1 defaults: everything off",
        not BO.autoWifiEnabled() and not BO.autoWifiOffInBook() and not BO.autoWifiSyncOnSleep()
        and not BO.autoWifiOffInBookStored() and not BO.autoWifiSyncOnSleepStored()
        and not BO.autoWifiPullOnWake() and not BO.autoWifiPullOnWakeStored())

    BO.setAutoWifiOffInBook(true); BO.setAutoWifiSyncOnSleep(true)
    check("P2 sub-settings stored but not effective while the parent is off",
        BO.autoWifiOffInBookStored() and BO.autoWifiSyncOnSleepStored()
        and not BO.autoWifiOffInBook() and not BO.autoWifiSyncOnSleep())

    BO.setAutoWifiEnabled(true)
    check("P3 parent on: sub 1 and sub 2 effective", BO.autoWifiOffInBook() and BO.autoWifiSyncOnSleep())

    BO.setAutoWifiOffInBook(false)
    check("P4 sub 2 is independent of sub 1 (batch 5 decision)", not BO.autoWifiOffInBook() and BO.autoWifiSyncOnSleep()
        and BO.autoWifiSyncOnSleepStored())
    BO.setAutoWifiSyncOnSleep(false)
    check("P5 sub 2 off -> not effective whatever sub 1 says", not BO.autoWifiSyncOnSleep())

    -- Sub 3: "Pull progress on wake" (own key, tied to the parent, independent of subs 1 and 2).
    reset()
    BO.setAutoWifiPullOnWake(true)
    check("P6 wake switch stored but not effective while the parent is off",
        BO.autoWifiPullOnWakeStored() and not BO.autoWifiPullOnWake())
    check("P6b wake switch uses its own key, the sleep switch is untouched",
        store[file].auto_wifi_pull_on_wake == true and not BO.autoWifiSyncOnSleepStored())
    BO.setAutoWifiEnabled(true)
    check("P7 parent on: wake effective, sleep and sub 1 still off",
        BO.autoWifiPullOnWake() and not BO.autoWifiSyncOnSleep() and not BO.autoWifiOffInBook())
    BO.setAutoWifiSyncOnSleep(true); BO.setAutoWifiPullOnWake(false)
    check("P8 sleep on, wake off: independent",
        BO.autoWifiSyncOnSleep() and not BO.autoWifiPullOnWake() and not BO.autoWifiPullOnWakeStored())
    BO.setAutoWifiEnabled(false)

    -- migration
    local function migrated(old, delete_old)
        reset(old)
        local ran = BO.migrateAutoWifi(delete_old)
        return ran, store[file]
    end
    local ran, s = migrated({})
    check("Q1 fresh install: migrates to off, flag set", ran and s.auto_wifi == false and s.auto_wifi_migrated == true)
    ran, s = migrated({ auto_wifi = true })
    check("Q2 old sync toggle on -> on", s.auto_wifi == true)
    ran, s = migrated({ auto_wifi_on_access = true })
    check("Q3 old access toggle on -> on", s.auto_wifi == true)
    ran, s = migrated({ auto_wifi = true, auto_wifi_on_access = true })
    check("Q4 both old toggles on -> on", s.auto_wifi == true)
    ran, s = migrated({ auto_wifi_on_open = true })
    check("Q5 old on_open alone (no parent) -> off", s.auto_wifi == false)
    ran, s = migrated({ auto_wifi = true, auto_wifi_on_open = true, auto_wifi_on_access = true, auto_wifi_on_access_timeout = 300 })
    check("Q6 without delete_old the old keys stay",
        s.auto_wifi_on_open == true and s.auto_wifi_on_access == true and s.auto_wifi_on_access_timeout == 300)
    ran, s = migrated({ auto_wifi = true, auto_wifi_on_open = true, auto_wifi_on_access = true, auto_wifi_on_access_timeout = 300 }, true)
    check("Q7 delete_old removes the old keys", s.auto_wifi == true and s.auto_wifi_on_open == nil
        and s.auto_wifi_on_access == nil and s.auto_wifi_on_access_timeout == nil)
    ran, s = migrated({ auto_wifi = true, auto_wifi_migrated = true })
    check("Q8 idempotent: second run does nothing", ran == false and s.auto_wifi == true)
    reset({ auto_wifi_on_access = true, auto_wifi_migrated = true })
    BO.migrateAutoWifi()
    check("Q9 already migrated: old access flag is not re-merged", store[file].auto_wifi == nil)
    -- profiles that a development build flagged as migrated still get cleaned
    reset({ auto_wifi = true, auto_wifi_migrated = true, auto_wifi_on_open = true,
            auto_wifi_on_access = true, auto_wifi_on_access_timeout = 300 })
    ran = BO.migrateAutoWifi(true)
    s = store[file]
    check("Q10 already-migrated profile: old keys deleted, auto_wifi untouched, merge not repeated",
        ran == false and s.auto_wifi == true and s.auto_wifi_on_open == nil
        and s.auto_wifi_on_access == nil and s.auto_wifi_on_access_timeout == nil)
    -- the old API is gone
    check("R1 legacy API removed", BO.autoWifiOnOpenEnabled == nil and BO.autoWifiOnAccessEnabled == nil
        and BO.setAutoWifiOnOpenEnabled == nil and BO.setAutoWifiOnAccessEnabled == nil
        and BO.autoWifiOnAccessTimeoutSeconds == nil and BO.setAutoWifiOnAccessTimeoutSeconds == nil
        and BO.AUTO_WIFI_ACCESS_TIMEOUT_DEFAULT == nil)
end


-- ---------------------------------------------------------------------
-- batch 2: withAutoWifi gate on top of the controller (real BO module,
-- fake radio + scheduler injected through package.loaded)
-- ---------------------------------------------------------------------
if ok_load then
    local file = "/s/bookorbit_settings.lua"
    local function setSettings(t)
        store[file] = store[file] or {}
        for k in pairs(store[file]) do store[file][k] = nil end
        for k, v in pairs(t or {}) do store[file][k] = v end
    end
    local function gateEnv(o)
        local ui = newUI()
        ui.nextTick = function(self, fn) fn() end
        local net = newNet(ui, o)
        package.loaded["ui/network/manager"] = net
        package.loaded["ui/uimanager"] = ui
        Wifi._resetDefault()
        local w = Wifi.get()
        return w, ui, net
    end

    -- G1 feature off: job runs at once, no radio call, on_fail never fires
    setSettings({ auto_wifi = false })
    do
        local w, ui, net = gateEnv{}
        local ran, failed, done = 0, 0, nil
        BO.withAutoWifi(function(d) ran = ran + 1; done = d end, { on_fail = function() failed = failed + 1 end })
        check("G1 off: schedule runs immediately with a no-op afterDone",
            ran == 1 and failed == 0 and #net.on_calls == 0 and w.count == 0)
        done()
    end

    -- G2 on + already online: runs synchronously, lease released by afterDone
    setSettings({ auto_wifi = true })
    do
        local w, ui, net = gateEnv{ wifi_on = true, online = true }
        local ran, done = 0, nil
        BO.withAutoWifi(function(d) ran = ran + 1; done = d end)
        check("G2a online: runs at once and holds one lease", ran == 1 and w.count == 1)
        done(); done()
        check("G2b afterDone releases (idempotent), Wi-Fi stays on", w.count == 0 and net.off_calls == 0 and net.online)
    end

    -- G3 synchronous afterDone inside schedule must not leak the lease
    do
        local w = gateEnv{ wifi_on = true, online = true }
        BO.withAutoWifi(function(d) d() end)
        check("G3 afterDone called inside schedule releases the lease", w.count == 0)
    end

    -- G4 offline, connect succeeds later
    do
        local w, ui, net = gateEnv{ connect_after = 5 }
        local ran, done = 0, nil
        BO.withAutoWifi(function(d) ran = ran + 1; done = d end)
        check("G4a waits for Wi-Fi (non-interactive turn-on)", ran == 0 and #net.on_calls == 1 and net.on_calls[1].interactive == false)
        ui:advance(10)
        check("G4b runs once online", ran == 1 and w.count == 1)
        done()
        check("G4c released, radio left on", w.count == 0 and net.wifi_on)
    end

    -- G5 Wi-Fi never comes up: job does NOT run, on_fail fires -> queue (D4)
    do
        local w, ui, net = gateEnv{ connect_after = nil }
        local ran, err = 0, nil
        BO.withAutoWifi(function() ran = ran + 1 end, { timeout = 10, on_fail = function(e) err = e end })
        ui:advance(60)
        check("G5 failed connect: no job, on_fail('timeout'), lease gone", ran == 0 and err == "timeout" and w.count == 0)
    end

    -- G6 manual off: refused for automatic jobs, honoured for explicit ones
    do
        local w, ui, net = gateEnv{ connect_after = 3 }
        w.manual_off = true
        local ran, err = 0, nil
        BO.withAutoWifi(function() ran = ran + 1 end, { on_fail = function(e) err = e end })
        check("G6a manual off: automatic job queued via on_fail, radio untouched",
            ran == 0 and err == "manual_off" and #net.on_calls == 0)
        local ran2 = 0
        BO.withAutoWifi(function(d) ran2 = ran2 + 1; d() end, { trigger = true })
        ui:advance(10)
        check("G6b explicit action (trigger=true) clears manual off and connects", ran2 == 1 and not w.manual_off)
    end

    -- G7 two overlapping jobs: refcount, the first release does not drop Wi-Fi
    setSettings({ auto_wifi = true, auto_wifi_off_in_book = true })
    do
        local w, ui, net = gateEnv{ connect_after = 2 }
        local d1, d2
        w.book_open = true       -- state wants the radio off in a book
        BO.withAutoWifi(function(d) d1 = d end)
        BO.withAutoWifi(function(d) d2 = d end)
        ui:advance(5)
        check("G7a both jobs ran on one connect", d1 and d2 and w.count == 2)
        d1()
        check("G7b first release keeps Wi-Fi up (one lease left)", net.off_calls == 0 and net.wifi_on)
        d2()
        check("G7c last release turns it off (book open + off_in_book)", net.off_calls == 1)
    end
    -- -----------------------------------------------------------------
    -- batch 3: book open / close sequences (sub-setting 1 = off_in_book)
    -- -----------------------------------------------------------------
    setSettings({ auto_wifi = true, auto_wifi_off_in_book = true })

    -- H1 open: pull holds a lease, THEN noteBookOpened; Wi-Fi goes off only
    -- when the pull resolves (D14)
    do
        local w, ui, net = gateEnv{ wifi_on = true, online = true }
        local d
        BO.withAutoWifi(function(done) d = done end, { reason = "pull_on_open" })
        w:noteBookOpened()
        check("H1a pull in flight: Wi-Fi stays on", net.wifi_on and net.off_calls == 0)
        d()
        check("H1b pull resolved: Wi-Fi off", net.off_calls == 1 and not net.wifi_on)
    end

    -- H2 open with nothing to pull: off straight away
    do
        local w, ui, net = gateEnv{ wifi_on = true, online = true }
        w:noteBookOpened()
        check("H2 no pull: Wi-Fi off at once", net.off_calls == 1)
    end

    -- H3 sub-setting 1 off: opening changes nothing (D13)
    setSettings({ auto_wifi = true, auto_wifi_off_in_book = false })
    do
        local w, ui, net = gateEnv{ wifi_on = true, online = true }
        w:noteBookOpened()
        check("H3 off_in_book off: Wi-Fi stays on in the book", net.off_calls == 0 and net.wifi_on)
    end

    -- H4 close returning home: reconnect, push runs, Wi-Fi stays up (D15)
    setSettings({ auto_wifi = true, auto_wifi_off_in_book = true })
    do
        local w, ui, net = gateEnv{ connect_after = 3 }
        w.book_open = true
        local ran, d = 0, nil
        w:noteBookClosed(true)
        BO.withAutoWifi(function(done) ran = ran + 1; d = done end, { reason = "book_close" })
        ui:advance(10)
        check("H4a close: reconnected and the push ran", ran == 1 and net.online and not w.book_open)
        d()
        check("H4b after the push Wi-Fi stays on at home", net.off_calls == 0 and net.wifi_on)
    end

    -- H5 manual off at home is cleared by the close trigger, so the push goes out
    do
        local w, ui, net = gateEnv{ connect_after = 3 }
        w.book_open = true; w.manual_off = true
        local ran = 0
        w:noteBookClosed(true)
        BO.withAutoWifi(function(done) ran = ran + 1; done() end, { reason = "book_close" })
        ui:advance(10)
        check("H5 close clears manual off and pushes", ran == 1 and not w.manual_off)
    end

    -- H6 reader->reader hand-off: no trigger; push lease held across the open
    -- of the next book never loses Wi-Fi under an active job
    do
        local w, ui, net = gateEnv{ wifi_on = true, online = true }
        w.book_open = true
        local dpush, dpull
        BO.withAutoWifi(function(done) dpush = done end, { reason = "book_close" })
        w:noteBookClosed(false)                      -- hand-off: ignored
        check("H6a hand-off ignored (still in a book)", w.book_open == true)
        BO.withAutoWifi(function(done) dpull = done end, { reason = "pull_on_open" })
        w:noteBookOpened()
        dpush()
        check("H6b push done, pull still active: Wi-Fi up", net.off_calls == 0 and net.wifi_on)
        dpull()
        check("H6c both done: off (book open + off_in_book)", net.off_calls == 1)
    end

    -- H7 pull failing (job throws / dropped) still releases via cleanup
    do
        local w, ui, net = gateEnv{ wifi_on = true, online = true }
        w:noteBookOpened()   -- off at once (no lease yet) ...
        net.wifi_on, net.online, net.off_calls = true, true, 0
        local d
        BO.withAutoWifi(function(done) d = done end)
        d(); d()
        check("H7 afterDone twice (run + cleanup) releases once", w.count == 0)
    end

    -- H8 skip-when-offline bypass (D7)
    setSettings({ auto_wifi = true, skip_sync_when_offline = true })
    check("H8a Auto Wi-Fi on: skip-when-offline is bypassed", BO.shouldSkipAutoSyncOffline() == false)
    setSettings({ auto_wifi = false, skip_sync_when_offline = true })
    check("H8b Auto Wi-Fi off: skip-when-offline still applies", BO.shouldSkipAutoSyncOffline() == true)

    -- J: coordinator + runner run `cleanup` for dropped / failed jobs
    do
        local C = dofile(PLUGIN .. "/lib/bookshelf_bookorbit_sync_coordinator.lua")
        local R = dofile(PLUGIN .. "/lib/bookshelf_bookorbit_sync_job_runner.lua")
        local c = C.new()
        local cleaned = { a = 0, b = 0, c = 0, thrown = 0 }
        local hold
        local function job(name, family, priority, run)
            return R.prepare{ family = family, priority = priority,
                run = run or function() end, cleanup = function() cleaned[name] = cleaned[name] + 1 end }
        end
        -- first job holds the coordinator busy (async-style: finishes later)
        c:submit{ family = "x", run = function(done) hold = done; return true end, async = true }
        c:submit(job("a", "progress:1", C.PRIORITY.auto))
        c:submit(job("b", "progress:1", C.PRIORITY.auto))     -- replaces a
        check("J1 replaced queued job is cleaned up, replacement is not", cleaned.a == 1 and cleaned.b == 0)
        c:submit(job("c", "progress:1", nil)); -- same priority, replaces b
        check("J2 second replacement", cleaned.b == 1)
        local man = job("a", "progress:2", C.PRIORITY.manual)
        c:submit(man)
        local lower = job("c", "progress:2", C.PRIORITY.auto)
        c:submit(lower)                                         -- kept: lower is dropped
        check("J3 lower-priority newcomer dropped -> its cleanup ran", cleaned.c == 1)
        hold()                                                  -- queue drains, jobs run
        check("J4 jobs that run also clean up (idempotent hook)", cleaned.c >= 2 and cleaned.a >= 2)
        -- a throwing job
        local c2 = C.new()
        c2:submit(job("thrown", "progress:9", C.PRIORITY.auto, function() error("boom") end))
        check("J5 throwing job still runs cleanup", cleaned.thrown == 1)
    end

    -- -----------------------------------------------------------------
    -- batch 4: "changed since the last successful push?" (D2)
    -- -----------------------------------------------------------------
    do
        local f = "/b/x.epub"
        check("K1 no baseline yet counts as changed", BO.progressChangedSincePush(f, 0.5, "xp1") == true)
        BO.markProgressSynced(f, 0.5, "xp1")
        check("K2 same position string: unchanged", BO.progressChangedSincePush(f, 0.5, "xp1") == false)
        check("K3 different position string: changed", BO.progressChangedSincePush(f, 0.5, "xp2") == true)
        BO.markProgressSynced(f, 0.5, "")
        check("K4 no position strings: compares percentages",
            BO.progressChangedSincePush(f, 0.50001, "") == false and BO.progressChangedSincePush(f, 0.52, "") == true)
        BO.forgetProgressMark(f)
        check("K5 forgotten baseline counts as changed again", BO.progressChangedSincePush(f, 0.5, "xp1") == true)
        check("K6 other books are independent", (function()
            BO.markProgressSynced("/b/a.epub", 0.1, "a")
            return BO.progressChangedSincePush("/b/b.epub", 0.1, "a") == true
        end)())
    end

    -- batch 4: controller uses the supported KOReader entry points
    do
        local function ctl(can_restore, net_extra)
            local ui = newUI()
            local net = newNet(ui, {})
            for k, v in pairs(net_extra or {}) do net[k] = v end
            local cfg = { enabled = true }
            local w = Wifi.new{ network = net, ui = ui,
                settings = { enabled = function() return true end, off_in_book = function() return true end,
                             can_restore = function() return can_restore end } }
            return w, ui, net
        end
        local calls = {}
        local w, ui, net = ctl(true, {
            restoreWifiAsync = function(self) calls[#calls + 1] = "restore"; self.wifi_on = true end,
            scheduleConnectivityCheck = function() calls[#calls + 1] = "check" end,
            enableWifi = function() calls[#calls + 1] = "enable" end,
        })
        w:acquire("x", function() end)
        check("N1 restore-capable device: quiet restoreWifiAsync + connectivity check, no raw turnOnWifi",
            calls[1] == "restore" and calls[2] == "check" and #calls == 2 and #net.on_calls == 0)

        calls = {}
        w, ui, net = ctl(false, { enableWifi = function(self, cb, interactive)
            calls[#calls + 1] = interactive; self.wifi_on = true end })
        w:acquire("x", function() end)
        check("N2 otherwise enableWifi(cb, false), still not the raw backend call",
            calls[1] == false and #net.on_calls == 0)

        local off = 0
        w, ui, net = ctl(false, { wifi_on = true, online = true,
            disableWifi = function(self) off = off + 1; self.wifi_on = false; self.online = false end })
        w:noteBookOpened(); -- book_open + off_in_book: radio goes off
        check("N3 turn-off goes through disableWifi when available", off == 1 and net.off_calls == 0)
    end

    package.loaded["ui/network/manager"] = nil
    package.loaded["ui/uimanager"] = nil
    Wifi._resetDefault()
end

print(string.format("RESULT: %d passed, %d failed", passes, fails))
return fails > 0 and 1 or nil
