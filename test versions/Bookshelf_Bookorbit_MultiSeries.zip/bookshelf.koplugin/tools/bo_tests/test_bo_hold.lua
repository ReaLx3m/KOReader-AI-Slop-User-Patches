-- Hold-the-previous-screen gate (HANDOFF_hold_page, Batch H1). Pure module,
-- no KOReader stubs. Proves the DECISION only: whether the widget wiring holds
-- the screen correctly is not covered here and was not run on a device.
--
-- Optional first argument: path of an alternative module file, used by the
-- hand mutation checks (the same suite must FAIL against a mutant).
package.path = PLUGIN .. "/?.lua;" .. package.path
local fails, passes = 0, 0
local function check(n, c, x)
    if c then passes = passes + 1
    else fails = fails + 1; print("FAIL: " .. n .. (x ~= nil and (" -> " .. tostring(x)) or "")) end
end

local Hold
do
    local alt = ARGS and ARGS[1]
    if alt and alt ~= "" then
        local f, e = loadfile(alt)
        assert(f, e)
        Hold = f()
    else
        Hold = require("lib/bookshelf_hold_gate")
    end
end

-- NIL in an override table means "set this key to nil" (pairs() skips real nils).
local NIL = {}
local function S(over)
    local t = { w = 1072, h = 1448, n_shelves = 2, n_cols = 4, view_mode = "covers",
                night = false, expanded = false, hero_mode = "card", aspect = 1.5 }
    for k, v in pairs(over or {}) do if v == NIL then t[k] = nil else t[k] = v end end
    return t
end

-- A ctx where every condition holds; each test breaks exactly one.
local function C(over)
    local c = { enabled = true, painted = true, grid_mode = true,
                draft_regrid = false, nested = false, want_all = false,
                stamp_now = S(), stamp_last = S(),
                pending = { id = "x", key = "k" }, failed = false }
    for k, v in pairs(over or {}) do if v == NIL then c[k] = nil else c[k] = v end end
    return c
end

-- ── stamp ────────────────────────────────────────────────────────────────
do
    local s = Hold.stamp(S())
    check("stamp: complete input gives a table", type(s) == "table")
    check("stamp: fields copied", s and s.w == 1072 and s.h == 1448 and s.n_shelves == 2
          and s.n_cols == 4 and s.view_mode == "covers" and s.aspect == 1.5
          and s.hero_mode == "card")
    check("stamp: night/expanded normalised to booleans",
          s and s.night == false and s.expanded == false)
    local s2 = Hold.stamp(S({ night = 1, expanded = "yes" }))
    check("stamp: truthy night/expanded become true", s2 and s2.night == true and s2.expanded == true)
    local s3 = Hold.stamp(S({ hero_mode = NIL, aspect = NIL, night = NIL, expanded = NIL }))
    check("stamp: optional fields default", s3 and s3.hero_mode == "" and s3.aspect == 0
          and s3.night == false and s3.expanded == false)
    check("stamp: extra keys are not carried", Hold.stamp(S({ junk = 5 })).junk == nil)
    check("stamp: does not return the input table", Hold.stamp(S()) ~= nil
          and (function() local t = S(); return Hold.stamp(t) ~= t end)())
    for _i, k in ipairs({ "w", "h", "n_shelves", "n_cols", "view_mode" }) do
        check("stamp: missing " .. k .. " -> nil", Hold.stamp(S({ [k] = false })) == nil
              and Hold.stamp((function() local t = S(); t[k] = nil; return t end)()) == nil)
    end
    check("stamp: NaN width -> nil", Hold.stamp(S({ w = 0 / 0 })) == nil)
    check("stamp: string width -> nil", Hold.stamp(S({ w = "1072" })) == nil)
    check("stamp: numeric view_mode -> nil", Hold.stamp(S({ view_mode = 1 })) == nil)
    check("stamp: nil -> nil", Hold.stamp(nil) == nil)
    check("stamp: string -> nil", Hold.stamp("x") == nil)
    check("stamp: number -> nil", Hold.stamp(7) == nil)
    check("stamp: function -> nil", Hold.stamp(function() end) == nil)
end

-- ── sameLayout ───────────────────────────────────────────────────────────
do
    check("same: equal stamps", Hold.sameLayout(S(), S()) == true)
    check("same: normalised and raw mix", Hold.sameLayout(Hold.stamp(S()), S()) == true)
    check("same: optional defaults compare equal",
          Hold.sameLayout(S({ hero_mode = NIL, aspect = NIL }), S({ hero_mode = "", aspect = 0 })))
    local diffs = {
        { "w", 1448 }, { "h", 1072 }, { "n_shelves", 3 }, { "n_cols", 3 },
        { "view_mode", "list" }, { "night", true }, { "expanded", true },
        { "hero_mode", "micro" }, { "aspect", 1.4 },
    }
    for _i, d in ipairs(diffs) do
        check("same: differing " .. d[1] .. " -> false",
              Hold.sameLayout(S(), S({ [d[1]] = d[2] })) == false)
        check("same: differing " .. d[1] .. " is symmetric",
              Hold.sameLayout(S({ [d[1]] = d[2] }), S()) == false)
    end
    check("same: nil, stamp -> false", Hold.sameLayout(nil, S()) == false)
    check("same: stamp, nil -> false", Hold.sameLayout(S(), nil) == false)
    check("same: nil, nil -> false", Hold.sameLayout(nil, nil) == false)
    check("same: incomplete, incomplete -> false",
          Hold.sameLayout({ w = 1 }, { w = 1 }) == false)
    check("same: garbage -> false (no throw)", Hold.sameLayout("a", 5) == false)
    check("same: returns a boolean", type(Hold.sameLayout(S(), S())) == "boolean")
end

-- ── decide: the one hold ──────────────────────────────────────────────────
do
    local v, r = Hold.decide(C())
    check("decide: all conditions -> hold", v == "hold" and r == "hold", v .. "/" .. tostring(r))
end

-- ── decide: each single breaker, and its reason ────────────────────────────
local breakers = {
    { "disabled",       { enabled = false } },
    { "no_frame",       { painted = false } },
    { "not_grid",       { grid_mode = false } },
    { "draft",          { draft_regrid = true } },
    { "nested",         { nested = true } },
    { "want_all",       { want_all = true } },
    { "layout_changed", { stamp_now = S({ w = 1448, h = 1072 }) } },
    { "layout_changed", { stamp_now = S({ night = true }) } },
    { "layout_changed", { stamp_last = S({ n_cols = 3 }) } },
    { "layout_changed", { stamp_now = NIL } },
    { "layout_changed", { stamp_last = NIL } },
    { "not_pending",    { pending = NIL } },
    { "not_pending",    { pending = false } },
    { "not_pending",    { pending = "pending" } },
    { "failed",         { failed = true } },
}
for _i, b in ipairs(breakers) do
    local v, r = Hold.decide(C(b[2]))
    local k = next(b[2])
    check("decide: " .. b[1] .. " (" .. k .. ") -> paint", v == "paint", v)
    check("decide: " .. b[1] .. " (" .. k .. ") reason", r == b[1], r)
end

-- ── decide: truthiness of the flags ──────────────────────────────────────────
do
    check("decide: enabled=nil is disabled", select(2, Hold.decide(C({ enabled = NIL }))) == "disabled")
    check("decide: painted=nil is no_frame", select(2, Hold.decide(C({ painted = NIL }))) == "no_frame")
    check("decide: grid_mode=nil is not_grid", select(2, Hold.decide(C({ grid_mode = NIL }))) == "not_grid")
    check("decide: draft_regrid=nil does not break",
          Hold.decide(C({ draft_regrid = NIL })) == "hold")
    check("decide: nested=nil does not break", Hold.decide(C({ nested = NIL })) == "hold")
    check("decide: want_all=nil does not break", Hold.decide(C({ want_all = NIL })) == "hold")
    check("decide: failed=nil does not break", Hold.decide(C({ failed = NIL })) == "hold")
    check("decide: enabled=1 counts as on", Hold.decide(C({ enabled = 1 })) == "hold")
end

-- ── decide: fixed priority ───────────────────────────────────────────────────
do
    -- Every condition broken at once, then peeled off in priority order.
    local all_bad = {
        enabled = false, painted = false, grid_mode = false, draft_regrid = true,
        nested = true, want_all = true, stamp_now = S({ w = 1 }), stamp_last = S(),
        pending = nil, failed = true,
    }
    local order = {
        { "disabled",       function(c) c.enabled = true end },
        { "no_frame",       function(c) c.painted = true end },
        { "not_grid",       function(c) c.grid_mode = true end },
        { "draft",          function(c) c.draft_regrid = false end },
        { "nested",         function(c) c.nested = false end },
        { "want_all",       function(c) c.want_all = false end },
        { "layout_changed", function(c) c.stamp_now = S() end },
        { "not_pending",    function(c) c.pending = { key = "k" } end },
        { "failed",         function(c) c.failed = false end },
    }
    local c = {}
    for k, v in pairs(all_bad) do c[k] = v end
    for _i, step in ipairs(order) do
        local v, r = Hold.decide(c)
        check("priority: with everything broken the next reason is " .. step[1],
              v == "paint" and r == step[1], tostring(r))
        step[2](c)
    end
    local v, r = Hold.decide(c)
    check("priority: after fixing everything -> hold", v == "hold" and r == "hold", tostring(r))
end

-- ── decide: garbage never throws ─────────────────────────────────────────────
do
    local garbage = { nil, false, true, 0, 1, "x", function() end, {}, { enabled = "x" },
                      { enabled = true, painted = true, grid_mode = true, stamp_now = "a", stamp_last = 7 },
                      { enabled = true, painted = true, grid_mode = true,
                        stamp_now = S(), stamp_last = S(), pending = 5 } }
    local n = 0
    for i = 1, 11 do
        local ok, v = pcall(Hold.decide, garbage[i])
        n = n + 1
        check("garbage #" .. i .. ": no throw", ok)
        check("garbage #" .. i .. ": never holds", ok and v == "paint", tostring(v))
    end
    check("garbage: all cases ran", n == 11)
    check("garbage: non-table ctx reason is disabled", select(2, Hold.decide("x")) == "disabled")
end

-- ── decide: does not mutate its input ────────────────────────────────────────
do
    local c = C()
    Hold.decide(c)
    check("decide: ctx untouched", c.enabled == true and c.pending.key == "k"
          and c.stamp_now.w == 1072 and c.failed == false)
end

-- ── eligible ─────────────────────────────────────────────────────────────────
do
    -- eligible ignores the page: no pending, even failed, is still "eligible".
    local ok, r = Hold.eligible(C({ pending = NIL, failed = true }))
    check("eligible: page state is ignored", ok == true and r == "eligible", tostring(r))
    ok, r = Hold.eligible(C())
    check("eligible: full ctx -> true", ok == true and r == "eligible")
    for _i, b in ipairs(breakers) do
        if b[1] ~= "not_pending" and b[1] ~= "failed" then
            ok, r = Hold.eligible(C(b[2]))
            check("eligible: " .. b[1] .. " (" .. next(b[2]) .. ") -> false",
                  ok == false and r == b[1], tostring(r))
        end
    end
    ok, r = Hold.eligible(nil)
    check("eligible: nil ctx -> false, no throw", ok == false and r == "disabled")
    local c = C({ pending = NIL })
    Hold.eligible(c)
    check("eligible: does not mutate the ctx", c.pending == nil and c.failed == false)
    -- eligible agrees with decide when the page IS pending and not failed.
    local agree = true
    for _i, b in ipairs(breakers) do
        if b[1] ~= "not_pending" and b[1] ~= "failed" then
            local ctx = C(b[2])
            local e = Hold.eligible(ctx)
            local d = Hold.decide(ctx) == "hold"
            if e ~= d then agree = false end
        end
    end
    check("eligible: agrees with decide on a pending page", agree)
end

-- ── the module is pure ───────────────────────────────────────────────────────
do
    local f = io.open(PLUGIN .. "/lib/bookshelf_hold_gate.lua", "r")
    local src = f and f:read("*a") or ""
    if f then f:close() end
    check("pure: no require() calls", not src:find("require%s*%("))
    check("pure: no UIManager / logger / G_reader_settings",
          not src:find("UIManager") and not src:find("logger") and not src:find("G_reader_settings"))
    check("pure: no os.time / os.clock", not src:find("os%.time") and not src:find("os%.clock"))
    check("pure: returns its table", src:find("\nreturn M%s*$") ~= nil)
end


-- ══ H2: widget wiring, read as source (the widget cannot be loaded here) ════
local function slurp(path)
    local f = io.open(path, "r"); if not f then return "" end
    local t = f:read("*a"); f:close(); return t
end
local W = slurp(PLUGIN .. "/lib/bookshelf_widget.lua")
local function fnBody(name)
    local a = W:find("\nfunction BookshelfWidget:" .. name .. "%(")
    if not a then return nil end
    local b = W:find("\nfunction ", a + 5, true) or #W
    return W:sub(a, b)
end
local function at(hay, needle, from) return hay and hay:find(needle, from or 1, true) end

do
    check("wire: gate required", at(W, 'require("lib/bookshelf_hold_gate")') ~= nil)
    check("wire: BO_HOLD_PREVIOUS constant is on", W:find("local BO_HOLD_PREVIOUS%s*=%s*true") ~= nil)
    check("wire: timeout constant is 35 s", W:find("local BO_HOLD_TIMEOUT_S%s*=%s*35") ~= nil)
    local n = 0
    for _ in W:gmatch("BO_HOLD_PREVIOUS") do n = n + 1 end
    -- declaration, doc comment mention(s) aside: exactly one USE in code
    check("wire: the constant feeds the gate (enabled = BO_HOLD_PREVIOUS)",
          at(W, "enabled      = BO_HOLD_PREVIOUS") ~= nil)
end

local swap = fnBody("_swapShelvesInPlace")
check("swap: body found", swap ~= nil and #swap > 1000)
if swap then
    local p_fetch  = at(swap, '_fetchChipItems(MAX_FETCH, nil, "render")')
    local p_wait   = at(swap, "self._bo_wait = all_items.bo_pending or nil")
    local p_failed = at(swap, "if all_items.bo_failed then")
    local p_hold   = at(swap, "Hold.decide{")
    local p_begin  = at(swap, '_beginHold(all_items.bo_pending, "swap")')
    local p_totals = at(swap, "self:_noteFetchTotals(")
    local p_take   = at(swap, "self:_takeFetchedPage(")
    local p_rows   = at(swap, "self:_buildShelfRows(")
    local p_end    = at(swap, "self:_notePainted()")
    check("swap: all anchors present", p_fetch and p_wait and p_failed and p_hold and p_begin
          and p_totals and p_take and p_rows and p_end)
    if p_fetch and p_wait and p_failed and p_hold and p_begin and p_totals and p_take and p_rows and p_end then
        check("swap: order fetch < _bo_wait < bo_failed < hold < totals < take < rows < notePainted",
              p_fetch < p_wait and p_wait < p_failed and p_failed < p_hold and p_hold < p_totals
              and p_totals < p_take and p_take < p_rows and p_rows < p_end)
        -- the hold branch itself: from the verdict test to its `return`
        local a = at(swap, 'if verdict == "hold" then')
        local b = a and at(swap, "return", a)
        local branch = (a and b) and swap:sub(a, b + 6) or ""
        check("swap: hold branch found", #branch > 20)
        check("swap: hold branch begins a hold and returns",
              branch:find("_beginHold") and branch:find("return") and true or false)
        for _i, bad in ipairs({ "_buildShelfRows", "_buildListRows", "_buildSpineRows", "_rebuild",
                                "setDirty", "_takeFetchedPage", "_inner_vgroup", "_noteFetchTotals",
                                "_persistNavState", "_swapFooterInPlace" }) do
            check("swap: hold branch does not touch " .. bad, not branch:find(bad, 1, true))
        end
        check("swap: hold branch honours after_fn", branch:find("if after_fn then after_fn() end", 1, true) ~= nil)
        -- the hold is only taken for a TABLE pending page, after bo_failed is routed away
        check("swap: hold only for a table pending page",
              at(swap, 'if type(all_items.bo_pending) == "table" then') ~= nil)
    end
    local fa = at(swap, "if all_items.bo_failed then")
    local fb = fa and at(swap, "return", fa)
    check("swap: bo_failed still routes to a full _rebuild",
          fa and fb and swap:sub(fa, fb):find("self:_rebuild()", 1, true) ~= nil or false)
    check("swap: gate gets grid_mode / failed=false / nested force flag / draft flag",
          at(swap, "grid_mode    = not self:_isListMode() and not self:_isSpineMode()")
          and at(swap, "failed       = false")
          and at(swap, "nested       = self._bo_force_paint")
          and at(swap, "draft_regrid = self._draft_regrid") and true or false)
    check("swap: stamp_last comes from the painted stamp, stamp_now is read live",
          at(swap, "stamp_last   = self._bo_painted_stamp") and at(swap, "stamp_now    = self:_holdStampNow()")
          and true or false)
    check("swap: a non-hold verdict falls through to the blank-row swap (logs why)",
          at(swap, "swap paints blank rows, reason=") ~= nil)
end

do
    local cnt = 0
    for _ in W:gmatch("self:_notePainted%(%)") do cnt = cnt + 1 end
    check("paint markers: _rebuild end, empty-state exit and swap end (3 sites)", cnt == 3, cnt)
    local rb = fnBody("_rebuild")
    check("paint marker: _rebuild ends with it", rb and rb:find("self._tree_fresh = true\n    self:_notePainted()\nend", 1, true) ~= nil or false)
    check("paint marker: empty-state exit has it before its return",
          rb and rb:find("self:_opdsAfterPage(self._page_items)\n        self:_notePainted()\n        return", 1, true) ~= nil or false)
    check("paint marker: not recorded at the nested-retry returns",
          rb and not rb:find("return self:_rebuild()\n        self:_notePainted", 1, true) or false)
    check("_rebuild itself carries no gate logic (it lives in _holdPreflight)", rb and not rb:find("Hold.decide", 1, true) and not rb:find("Hold.eligible", 1, true) or false)
end

do
    local oc = fnBody("onCloseWidget")
    check("onCloseWidget: body found", oc ~= nil)
    check("onCloseWidget: clears the hold (timer cancelled)", oc and oc:find("self:_clearHold()", 1, true) ~= nil or false)
    check("onCloseWidget: drops the painted stamp", oc and oc:find("self._bo_painted_stamp = nil", 1, true) ~= nil or false)
    local cl = fnBody("_clearHold")
    check("_clearHold: cancels the timer and drops the hold",
          cl and cl:find("_cancelHoldTimer", 1, true) and cl:find("self._bo_hold = nil", 1, true) and true or false)
    local bh = fnBody("_beginHold")
    check("_beginHold: cancels any older timer first, then arms one",
          bh and at(bh, "_cancelHoldTimer") and at(bh, "scheduleIn(BO_HOLD_TIMEOUT_S")
          and at(bh, "_cancelHoldTimer") < at(bh, "scheduleIn(BO_HOLD_TIMEOUT_S") and true or false)
end

-- ══ H2: the hold helpers, run for real against fakes ═══════════════════════
do
    local a = W:find("\nfunction BookshelfWidget:_holdStampNow", 1, true)
    local b = W:find("\nfunction BookshelfWidget:_rebuild()", 1, true)
    check("helpers: source block found", a ~= nil and b ~= nil and a < b)
    local src = W:sub(a, b)

    local function newEnv(opts)
        opts = opts or {}
        local env = { pcall = pcall, tostring = tostring, string = string, type = type, ipairs = ipairs }
        env.fakes = {
            ["lib/bookshelf_tab_model"] = {
                getById = function(id) return env.tabs[id] end,
                rootOf = function(id) return (env.tabs[id] and env.tabs[id].parent) or id end,
                getActive = function() return env.active end,
            },
        }
        env.tabs = { recent = { id = "recent", source = { kind = "bookorbit", id = "x" } },
                     local1 = { id = "local1", source = { kind = "all" } } }
        env.active = { env.tabs.recent, env.tabs.local1 }
        env.require = function(n) return env.fakes[n] end
        env.t = 0
        env.q = {}
        env.rebuilds, env.dirties, env.logs, env.warns = 0, 0, {}, {}
        env.force_during = {}
        env.UIManager = {
            scheduleIn = function(_, secs, fn) env.q[#env.q + 1] = { at = env.t + secs, fn = fn } end,
            unschedule = function(_, fn)
                for i = #env.q, 1, -1 do if env.q[i].fn == fn then table.remove(env.q, i) end end
            end,
            setDirty = function() env.dirties = env.dirties + 1 end,
        }
        env.logger = { dbg = function(m) env.logs[#env.logs + 1] = m end,
                       warn = function(...) env.warns[#env.warns + 1] = { ... } end }
        env._gettime = function() return env.t end
        env.BO_HOLD_TIMEOUT_S = 35
        env.BO_HOLD_PREVIOUS = (opts.enabled ~= false)
        env.Screen = { getWidth = function() return 1072 end, getHeight = function() return 1448 end, night_mode = false }
        env.Hold = Hold
        local BW = { live = nil }
        env.BookshelfWidget = BW
        local chunk = assert(load(src, "hold_helpers", "t", env))
        chunk()
        local w = setmetatable({ chip = "recent", _hero_mode = "card", _expanded = false }, { __index = BW })
        BW.live = w
        function w:_rebuild() env.rebuilds = env.rebuilds + 1; env.force_during[#env.force_during + 1] = self._bo_force_paint end
        function w:_nShelves() return 2 end
        function w:_nCols() return 4 end
        function w:_viewMode() return "covers" end
        function w:_coverAspect() return 1.5 end
        function env.advance(secs)
            local target = env.t + secs
            while true do
                local best, bi
                for i, e in ipairs(env.q) do if e.at <= target and (not best or e.at < best.at) then best, bi = e, i end end
                if not best then break end
                table.remove(env.q, bi); env.t = math.max(env.t, best.at); best.fn()
            end
            env.t = target
        end
        return w, env
    end

    -- stamp helper
    local w, env = newEnv()
    local st = w:_holdStampNow()
    check("helpers: _holdStampNow builds a complete stamp",
          st and st.w == 1072 and st.h == 1448 and st.n_shelves == 2 and st.n_cols == 4 and st.view_mode == "covers")
    w._nShelves = function() error("boom") end
    check("helpers: _holdStampNow answers nil when an input throws", w:_holdStampNow() == nil)

    -- _notePainted records the stamp and ends a hold
    w, env = newEnv()
    w:_beginHold({ key = "k1" }, "swap")
    check("begin: hold recorded", w._bo_hold and w._bo_hold.key == "k1")
    check("begin: one timer armed at 35 s", #env.q == 1 and env.q[1].at == 35)
    w:_notePainted()
    check("notePainted: stamp recorded", w._bo_painted_stamp ~= nil and w._bo_painted_stamp.n_cols == 4)
    check("notePainted: hold cleared, timer cancelled", w._bo_hold == nil and #env.q == 0 and w._bo_hold_fn == nil)

    -- a newer hold replaces an older one and re-arms the timer
    w, env = newEnv()
    w:_beginHold({ key = "a" }, "swap")
    env.advance(10)
    w:_beginHold({ key = "b" }, "swap")
    check("replace: only the newer hold is kept", w._bo_hold.key == "b")
    check("replace: exactly one timer, re-armed from now", #env.q == 1 and env.q[1].at == 10 + 35)
    env.advance(30)  -- t=40: the OLD deadline (35) has passed, the new one (45) has not
    check("replace: the old deadline does not fire", env.rebuilds == 0)

    -- timeout while still waiting on that page: ONE forced paint
    w, env = newEnv()
    w._bo_wait = { key = "k" }
    w:_beginHold({ key = "k" }, "swap")
    env.advance(34)
    check("timeout: nothing before 35 s", env.rebuilds == 0 and w._bo_hold ~= nil)
    env.advance(2)
    check("timeout: one forced rebuild + one repaint", env.rebuilds == 1 and env.dirties == 1)
    check("timeout: the force flag was set during the paint", env.force_during[1] == true)
    check("timeout: the force flag is cleared afterwards", w._bo_force_paint == nil)
    check("timeout: hold gone", w._bo_hold == nil and w._bo_hold_fn == nil)
    local logged = false
    for _i, m in ipairs(env.logs) do if m:find("held_ms=35000 reason=timeout", 1, true) then logged = true end end
    check("timeout: logs held_ms and reason", logged)
    env.advance(100)
    check("timeout: fires only once", env.rebuilds == 1)

    -- already landed (the page-ready callback cleared _bo_wait): no paint
    w, env = newEnv()
    w._bo_wait = { key = "k" }
    w:_beginHold({ key = "k" }, "swap")
    w._bo_wait = nil
    env.advance(40)
    check("stale: landed hold -> no forced paint", env.rebuilds == 0 and w._bo_hold == nil)

    -- waiting on a DIFFERENT page now: no paint for the old hold
    w, env = newEnv()
    w._bo_wait = { key = "other" }
    w:_beginHold({ key = "k" }, "swap")
    env.advance(40)
    check("stale: superseded wait -> no forced paint", env.rebuilds == 0)

    -- closed / not live: no paint
    w, env = newEnv()
    w._bo_wait = { key = "k" }
    w:_beginHold({ key = "k" }, "swap")
    w._closed = true
    env.advance(40)
    check("closed: no forced paint into a torn-down widget", env.rebuilds == 0)
    w, env = newEnv()
    w._bo_wait = { key = "k" }
    w:_beginHold({ key = "k" }, "swap")
    getmetatable(w).__index.live = nil
    env.advance(40)
    check("not live: no forced paint", env.rebuilds == 0)

    -- a throwing release rebuild is contained and the flag still cleared
    w, env = newEnv()
    w._bo_wait = { key = "k" }
    w._rebuild = function() error("rebuild blew up") end
    w:_beginHold({ key = "k" }, "swap")
    local ok = pcall(env.advance, 40)
    check("release: a throwing rebuild does not escape", ok)
    check("release: the force flag is cleared after a throw", w._bo_force_paint == nil)
    check("release: the throw is logged as a warning", #env.warns == 1)

    -- _clearHold (onCloseWidget) cancels the timer
    w, env = newEnv()
    w._bo_wait = { key = "k" }
    w:_beginHold({ key = "k" }, "swap")
    w:_clearHold()
    env.advance(100)
    check("clear: a cleared hold never fires", env.rebuilds == 0 and #env.q == 0)
    w:_clearHold()
    check("clear: clearing twice is harmless", w._bo_hold == nil)

    -- a hold with a nil page is tolerated
    w, env = newEnv()
    local ok2 = pcall(w._beginHold, w, nil, "swap")
    check("begin: nil page does not throw", ok2)
end


-- ══ H3: the render-path pre-flight ═════════════════════════════════════════
do
    local rb = fnBody("_rebuild")
    check("rebuild: body found", rb ~= nil)
    -- FIRST statement: nothing may run before it.
    local first = rb and rb:match("^\nfunction BookshelfWidget:_rebuild%(%)\n([^\n]*)\n([^\n]*)")
    check("rebuild: first statement is the pre-flight", first == "    if self:_holdPreflight() then return end", first)
    check("rebuild: pre-flight precedes _syncShelfTheme and the old-tree free",
          rb and at(rb, "_holdPreflight()") < at(rb, "self:_syncShelfTheme()")
          and at(rb, "_holdPreflight()") < at(rb, "old_tree:free()") or false)

    -- the real fetch site consumes the stash
    local site = rb and at(rb, "local pf = self._bo_preflight")
    check("fetch site: consumes the stash", site ~= nil)
    if site then
        local seg = rb:sub(site, site + 900)
        for _i, frag in ipairs({ "self._bo_preflight = nil", "pf.chip == self.chip", "pf.cursor == self._cursor",
                                 "pf.view_size == VIEW_SIZE", "pf.n_path == #path", "pf.tip == path[#path]",
                                 'self:_fetchChipItems(MAX_FETCH, nil, "render")' }) do
            check("fetch site: has " .. frag, at(seg, frag) ~= nil)
        end
        check("fetch site: the stash is cleared before the match test (never twice)",
              at(seg, "self._bo_preflight = nil") < at(seg, "pf.chip == self.chip"))
    end
    local cnt = 0
    for _ in (rb or ""):gmatch("self%._bo_preflight = nil") do cnt = cnt + 1 end
    check("fetch site: stash cleared on every branch after the chain (2 clears)", cnt == 2, cnt)

    local pf = fnBody("_holdPreflight")
    check("preflight: body found", pf ~= nil)
    if pf then
        local p_stale = at(pf, "self._bo_preflight = nil")
        local p_const = at(pf, "if not BO_HOLD_PREVIOUS then return false end")
        local p_frame = at(pf, "self._bo_painted_stamp)")
        local p_bo    = at(pf, "_holdIsBookorbitPage()")
        local p_elig  = at(pf, "Hold.eligible(ctx)")
        local p_valid = at(pf, "_holdChipStillValid()")
        local p_fetch = at(pf, '_fetchChipItems(400, nil, "render")')
        local p_dec   = at(pf, "Hold.decide(ctx)")
        local p_begin = at(pf, '_beginHold(all_items.bo_pending, "rebuild")')
        local p_stash = at(pf, "self._bo_preflight = {")
        check("preflight: all anchors present", p_stale and p_const and p_frame and p_bo and p_elig
              and p_valid and p_fetch and p_dec and p_begin and p_stash)
        if p_stale and p_const and p_frame and p_bo and p_elig and p_valid and p_fetch and p_dec and p_begin and p_stash then
            check("preflight: order stale < constant < frame < BO < eligible < chip valid < fetch < decide < begin < stash",
                  p_stale < p_const and p_const < p_frame and p_frame < p_bo and p_bo < p_elig
                  and p_elig < p_valid and p_valid < p_fetch and p_fetch < p_dec
                  and p_dec < p_begin and p_begin < p_stash)
        end
        local a = at(pf, 'if verdict == "hold" then')
        local b = a and at(pf, "return true", a)
        local branch = (a and b) and pf:sub(a, b + 10) or ""
        check("preflight: hold branch sets _bo_wait, begins a hold, returns true",
              at(branch, "self._bo_wait = all_items.bo_pending") and at(branch, "_beginHold") and true or false)
        for _i, bad in ipairs({ "_rebuild", "setDirty", "self[1]", "_chip_bar", "_hero_card", "_hero_dims",
                                "_shelf_crumbs", "_inner_vgroup =", "_page_items", "_cursor =" }) do
            check("preflight: hold branch does not touch " .. bad, not branch:find(bad, 1, true))
        end
        for _i, flag in ipairs({ "self._grid_labels_retry", "self._cursor_clamp_retry",
                                 "BookshelfWidget.go_home_pending", "self._pending_restore_drill",
                                 "self._bo_force_paint" }) do
            check("preflight: nested includes " .. flag, at(pf, flag) ~= nil)
        end
        check("preflight: draft regrid and want_all fed to the gate",
              at(pf, "draft_regrid = self._draft_regrid") and at(pf, "want_all     = false") and true or false)
        check("preflight: stamp_now is read live", at(pf, "stamp_now    = self:_holdStampNow()") ~= nil)
        check("preflight: the whole function never assigns the hero / chip strip",
              not pf:find("self._chip_bar =", 1, true) and not pf:find("self._hero_card =", 1, true))
    end
    local oc = fnBody("onCloseWidget")
    check("onCloseWidget: drops the pre-flight stash", oc and at(oc, "self._bo_preflight = nil") ~= nil or false)
end

do
    local a = W:find("\nfunction BookshelfWidget:_holdStampNow", 1, true)
    local b = W:find("\nfunction BookshelfWidget:_rebuild()", 1, true)
    local src = W:sub(a, b)

    -- a fake widget the pre-flight can run on
    local function newW(opts)
        opts = opts or {}
        local env = { pcall = pcall, tostring = tostring, string = string, type = type, ipairs = ipairs }
        env.fetches, env.logs = {}, {}
        env.t = 0
        env.q = {}
        env.UIManager = {
            scheduleIn = function(_, secs, fn) env.q[#env.q + 1] = { at = secs, fn = fn } end,
            unschedule = function(_, fn)
                for i = #env.q, 1, -1 do if env.q[i].fn == fn then table.remove(env.q, i) end end
            end,
        }
        env.logger = { dbg = function(m) env.logs[#env.logs + 1] = m end, warn = function() end }
        env._gettime = function() return env.t end
        env.BO_HOLD_TIMEOUT_S = 35
        env.BO_HOLD_PREVIOUS = (opts.enabled ~= false)
        env.Screen = { getWidth = function() return env.sw or 1072 end, getHeight = function() return 1448 end, night_mode = false }
        env.Hold = Hold
        env.tabs = { recent = { id = "recent", source = { kind = "bookorbit", id = "x" } },
                     local1 = { id = "local1", source = { kind = "all" } },
                     gone = { id = "gone", source = { kind = "bookorbit", id = "y" } } }
        env.active = { env.tabs.recent, env.tabs.local1 }
        env.require = function(n)
            if n == "lib/bookshelf_tab_model" then
                return { getById = function(id) return env.tabs[id] end,
                         rootOf = function(id) return id end,
                         getActive = function() return env.active end }
            end
        end
        local BW = {}
        env.BookshelfWidget = BW
        assert(load(src, "hold_helpers", "t", env))()
        local w = setmetatable({ chip = "recent", _cursor = 1, _drilldown_path = {}, _hero_mode = "card",
                                 _expanded = false }, { __index = BW })
        BW.live = w
        w[1] = {}; w._inner_vgroup = {}; w._shelf_dims = {}
        w._isListMode = function() return false end
        w._isSpineMode = function() return false end
        w._nShelves = function() return 2 end
        w._nCols = function() return 4 end
        w._viewMode = function() return "covers" end
        w._coverAspect = function() return 1.5 end
        w._viewSize = function() return 8 end
        env.page = { { title = "a" }, { title = "b" } }
        env.hint = 2
        w._fetchChipItems = function(_, n, want_all, mode)
            env.fetches[#env.fetches + 1] = { n = n, want_all = want_all, mode = mode }
            return env.page, env.hint
        end
        w._bo_painted_stamp = w:_holdStampNow()
        return w, env, BW
    end
    local function nfetch(env) return #env.fetches end

    -- 1. hold
    local w, env = newW()
    env.page = { bo_pending = { id = "x", key = "k1" } }
    check("pf: pending page, nothing changed -> holds", w:_holdPreflight() == true)
    check("pf: one fetch, asked as 'render', not want_all, n=400",
          nfetch(env) == 1 and env.fetches[1].mode == "render" and env.fetches[1].n == 400 and not env.fetches[1].want_all)
    check("pf: _bo_wait is the pending page", w._bo_wait and w._bo_wait.key == "k1")
    check("pf: a hold with that key is recorded and a timer armed", w._bo_hold and w._bo_hold.key == "k1" and #env.q == 1)
    check("pf: no stash on a hold", w._bo_preflight == nil)
    check("pf: the old frame's fields are untouched", w[1] ~= nil and w._chip_bar == nil and w._hero_card == nil)

    -- 2. cache hit
    w, env = newW()
    check("pf: cached page -> does not hold", w:_holdPreflight() == false)
    check("pf: cached page -> exactly one fetch (the stash saves the second)", nfetch(env) == 1)
    local sp = w._bo_preflight
    check("pf: stash keyed on chip/cursor/view size/drill",
          sp and sp.chip == "recent" and sp.cursor == 1 and sp.view_size == 8 and sp.n_path == 0
          and sp.all_items == env.page and sp.total_hint == 2)
    check("pf: no hold recorded", w._bo_hold == nil)

    -- 3. failed page paints (and keeps the page for the real site)
    w, env = newW()
    env.page = { bo_failed = "offline" }
    check("pf: failed page -> does not hold", w:_holdPreflight() == false)
    check("pf: failed page is stashed for the real site", w._bo_preflight and w._bo_preflight.all_items.bo_failed == "offline")

    -- 4. a stale stash never survives a new call
    w, env = newW()
    w._bo_preflight = { chip = "old" }
    w._bo_painted_stamp = nil
    check("pf: no frame -> false", w:_holdPreflight() == false)
    check("pf: stale stash cleared even when the pre-flight bails", w._bo_preflight == nil)

    -- 5. every 'cannot speak for it' case: false, and NO fetch
    local cases = {
        { "constant off",           function(w, env, BW) end, { enabled = false } },
        { "no previous frame",      function(w) w[1] = nil end },
        { "no inner vgroup",        function(w) w._inner_vgroup = nil end },
        { "no shelf dims",          function(w) w._shelf_dims = nil end },
        { "no painted stamp",       function(w) w._bo_painted_stamp = nil end },
        { "rotated",                function(w, env) env.sw = 1448 end },
        { "list mode",              function(w) w._isListMode = function() return true end end },
        { "spine mode",             function(w) w._isSpineMode = function() return true end end },
        { "expanded changed",       function(w) w._expanded = true end },
        { "label retry",            function(w) w._grid_labels_retry = true end },
        { "cursor clamp retry",     function(w) w._cursor_clamp_retry = true end },
        { "go home pending",        function(w, env, BW) BW.go_home_pending = true end },
        { "pending drill restore",  function(w) w._pending_restore_drill = {} end },
        { "forced paint",           function(w) w._bo_force_paint = true end },
        { "draft regrid",           function(w) w._draft_regrid = true end },
        { "local (non-BookOrbit) chip", function(w) w.chip = "local1" end },
        { "drilled into a folder",  function(w) w._drilldown_path = { { kind = "folder" } } end },
        { "chip disabled",          function(w, env) w.chip = "gone" end },
        { "unknown chip",           function(w) w.chip = "nope" end },
    }
    for _i, c in ipairs(cases) do
        local w2, env2, BW2 = newW(c[3])
        c[2](w2, env2, BW2)
        local held = w2:_holdPreflight()
        check("pf: " .. c[1] .. " -> no hold", held == false)
        check("pf: " .. c[1] .. " -> no fetch, no hold record", nfetch(env2) == 0 and w2._bo_hold == nil and #env2.q == 0,
              nfetch(env2))
    end

    -- 6. a drill into one author/series tile IS a BookOrbit page
    w, env = newW()
    w._drilldown_path = { { kind = "bookorbit_group", payload = { source_id = "authors:1" } } }
    env.page = { bo_pending = { id = "authors:1", key = "kg" } }
    check("pf: drill into a BookOrbit group tile holds too", w:_holdPreflight() == true and w._bo_hold.key == "kg")

    -- 7. the layout stamp: night mode flips
    w, env = newW()
    env.page = { bo_pending = { key = "kn" } }
    w._bo_painted_stamp = Hold.stamp{ w = 1072, h = 1448, n_shelves = 2, n_cols = 4, view_mode = "covers",
                                      night = true, hero_mode = "card", aspect = 1.5 }
    check("pf: night mode changed since the last frame -> paints", w:_holdPreflight() == false and nfetch(env) == 0)

    -- 8. last request wins: a second pending page replaces the first hold
    w, env = newW()
    env.page = { bo_pending = { key = "first" } }
    w:_holdPreflight()
    env.page = { bo_pending = { key = "second" } }
    w.chip = "recent"; w._cursor = 9
    check("pf: second request holds too", w:_holdPreflight() == true)
    check("pf: only the newer hold and wait remain", w._bo_hold.key == "second" and w._bo_wait.key == "second" and #env.q == 1)

    -- 9. then the first page lands in the cache: the next rebuild paints and stashes
    env.page = { { title = "now cached" } }
    check("pf: page landed -> next call paints", w:_holdPreflight() == false and w._bo_preflight ~= nil)
    check("pf: log names the reason", (function()
        for _i, m in ipairs(env.logs) do if m:find("rebuild paints, reason=not_pending", 1, true) then return true end end
    end)() == true)
end


-- ══ H4: the page-ready callback (landing / failure / supersede) ═════════════
do
    local a = W:find("BOSource_init.onPageReady(function(key, req, ok, why, urgent)", 1, true)
    local b = a and W:find("\n        end)\n    end\n", a, true)
    check("callback: source found", a ~= nil and b ~= nil)
    local fnsrc = (a and b) and W:sub(a + #"BOSource_init.onPageReady(", b + #"\n        end" - 1) or ""
    check("callback: extracted as a function", fnsrc:sub(1, 9) == "function(" and fnsrc:sub(-3) == "end", fnsrc:sub(-10))

    -- static: order of the guards
    local p_wait  = at(fnsrc, "if not (wait and wait.key == key) then return end")
    local p_nil   = at(fnsrc, "self._bo_wait = nil")
    local p_held  = at(fnsrc, "local held = self._bo_hold")
    local p_clear = at(fnsrc, "self:_clearHold()")
    local p_batch = at(fnsrc, "if not held and not self:_isActiveBookorbitBatch(req and req.id) then return end")
    local p_queue = at(fnsrc, "if self._bo_page_rebuild_queued then return end")
    check("callback: guards present", p_wait and p_nil and p_held and p_clear and p_batch and p_queue and true or false)
    if p_wait and p_nil and p_held and p_clear and p_batch and p_queue then
        check("callback: order wait-key < clear _bo_wait < read hold < clear hold < batch guard < queued guard",
              p_wait < p_nil and p_nil < p_held and p_held < p_clear and p_clear < p_batch and p_batch < p_queue)
    end
    check("callback: logs held_ms with reason=landed", at(fnsrc, "held_ms=%.0f reason=landed ok=%s") ~= nil)
    check("callback: the batch guard is skipped for a held page (no stuck-stale screen)",
          at(fnsrc, "if not held and not self:_isActiveBookorbitBatch") ~= nil)
    check("callback: a hold of another key is ignored", at(fnsrc, "if held and held.key ~= key then held = nil end") ~= nil)

    -- behavioural: real hold helpers + the real callback, fake UIManager
    local function build()
        local ha = W:find("\nfunction BookshelfWidget:_holdStampNow", 1, true)
        local hb = W:find("\nfunction BookshelfWidget:_rebuild()", 1, true)
        local helpers = W:sub(ha, hb)
        local env = { pcall = pcall, tostring = tostring, string = string, type = type, ipairs = ipairs }
        env.t, env.timers, env.ticks = 0, {}, {}
        env.rebuilds, env.dirties, env.logs = 0, 0, {}
        env.UIManager = {
            scheduleIn = function(_, secs, fn) env.timers[#env.timers + 1] = { at = env.t + secs, fn = fn } end,
            unschedule = function(_, fn)
                for i = #env.timers, 1, -1 do if env.timers[i].fn == fn then table.remove(env.timers, i) end end
            end,
            nextTick = function(_, fn) env.ticks[#env.ticks + 1] = fn end,
            setDirty = function() env.dirties = env.dirties + 1 end,
        }
        env.logger = { dbg = function(m) env.logs[#env.logs + 1] = m end, warn = function() end }
        env._gettime = function() return env.t end
        env.BO_HOLD_TIMEOUT_S = 35
        env.BO_HOLD_PREVIOUS = true
        env.Hold = Hold
        local BW = {}
        env.BookshelfWidget = BW
        assert(load(helpers, "helpers", "t", env))()
        local w = setmetatable({}, { __index = BW })
        BW.live = w
        function w:_rebuild() env.rebuilds = env.rebuilds + 1 end
        env.active = true
        function w:_isActiveBookorbitBatch() return env.active end
        env.w = w
        local cb = assert(load("local self = ...; return " .. fnsrc, "cb", "t", env))(w)
        function env.runTicks()
            local q = env.ticks; env.ticks = {}
            for _i, f in ipairs(q) do f() end
        end
        function env.logged(pat)
            for _i, m in ipairs(env.logs) do if m:find(pat, 1, true) then return true end end
            return false
        end
        return w, env, cb
    end

    -- landing: ends the hold, cancels the timer, one rebuild + repaint
    local w, env, cb = build()
    w._bo_wait = { key = "k" }
    w:_beginHold({ key = "k" }, "rebuild")
    env.t = 2.5
    cb("k", { id = "x" }, true, nil, true)
    check("landed: hold cleared", w._bo_hold == nil)
    check("landed: safety timer cancelled", #env.timers == 0 and w._bo_hold_fn == nil)
    check("landed: _bo_wait cleared", w._bo_wait == nil)
    check("landed: logs held_ms=2500 reason=landed ok=true", env.logged("held_ms=2500 reason=landed ok=true"))
    check("landed: nothing painted until the tick", env.rebuilds == 0)
    env.runTicks()
    check("landed: ONE rebuild + ONE repaint", env.rebuilds == 1 and env.dirties == 1)
    check("landed: the queued flag is released", w._bo_page_rebuild_queued == nil)
    env.t = 100
    check("landed: no timeout fires afterwards", #env.timers == 0 and env.rebuilds == 1)

    -- FAILED landing (ok=false): still repaints, so the failure placeholder can draw
    w, env, cb = build()
    w._bo_wait = { key = "k" }
    w:_beginHold({ key = "k" }, "swap")
    cb("k", { id = "x" }, false, "timeout", true)
    env.runTicks()
    check("failed: held screen is repainted", env.rebuilds == 1 and env.dirties == 1 and w._bo_hold == nil)
    check("failed: logged with ok=false", env.logged("reason=landed ok=false"))

    -- the batch guard must not leave a HELD screen stale...
    w, env, cb = build()
    env.active = false
    w._bo_wait = { key = "k" }
    w:_beginHold({ key = "k" }, "swap")
    cb("k", { id = "other" }, true, nil, true)
    env.runTicks()
    check("inactive batch + held: still repaints (no stuck stale screen)", env.rebuilds == 1 and w._bo_hold == nil)
    -- ...while an ordinary (not held) page keeps the old guard
    w, env, cb = build()
    env.active = false
    w._bo_wait = { key = "k" }
    cb("k", { id = "other" }, true, nil, true)
    env.runTicks()
    check("inactive batch + not held: no rebuild (old behaviour kept)", env.rebuilds == 0)
    w, env, cb = build()
    w._bo_wait = { key = "k" }
    cb("k", { id = "x" }, true, nil, true)
    env.runTicks()
    check("not held, active batch: one rebuild as before", env.rebuilds == 1)
    check("not held: no landed log", not env.logged("reason=landed"))

    -- a key that is not waited on (a preload) does nothing and leaves a hold alone
    w, env, cb = build()
    w._bo_wait = { key = "k" }
    w:_beginHold({ key = "k" }, "swap")
    cb("preload-key", { id = "x" }, true, nil, false)
    env.runTicks()
    check("other key: no rebuild", env.rebuilds == 0)
    check("other key: hold, wait and timer untouched", w._bo_hold and w._bo_wait.key == "k" and #env.timers == 1)

    -- supersede: last request wins, the older key landing is ignored
    w, env, cb = build()
    w._bo_wait = { key = "A" }
    w:_beginHold({ key = "A" }, "rebuild")
    w._bo_wait = { key = "B" }
    w:_beginHold({ key = "B" }, "swap")
    check("supersede: one timer, newer hold", #env.timers == 1 and w._bo_hold.key == "B")
    cb("A", { id = "x" }, true, nil, true)
    env.runTicks()
    check("supersede: the older page landing does nothing", env.rebuilds == 0 and w._bo_hold.key == "B" and #env.timers == 1)
    cb("B", { id = "x" }, true, nil, true)
    env.runTicks()
    check("supersede: the newer page landing repaints once", env.rebuilds == 1 and w._bo_hold == nil and #env.timers == 0)

    -- a hold whose key differs from the wait key (stale record) is not treated as landed
    w, env, cb = build()
    w._bo_wait = { key = "k" }
    w._bo_hold = { key = "zzz", since = 0 }
    env.active = false
    cb("k", { id = "x" }, true, nil, true)
    env.runTicks()
    check("stale hold record: falls back to the batch guard", env.rebuilds == 0 and not env.logged("reason=landed"))

    -- closed / not live
    w, env, cb = build()
    w._bo_wait = { key = "k" }
    w:_beginHold({ key = "k" }, "swap")
    w._closed = true
    cb("k", { id = "x" }, true, nil, true)
    env.runTicks()
    check("closed: callback stands down", env.rebuilds == 0)

    -- a landing while a rebuild is already queued: no second rebuild, but the hold ends
    w, env, cb = build()
    w._bo_wait = { key = "k" }
    w:_beginHold({ key = "k" }, "swap")
    w._bo_page_rebuild_queued = true
    cb("k", { id = "x" }, true, nil, true)
    check("already queued: hold ended, no extra rebuild queued", w._bo_hold == nil and #env.ticks == 0)

    -- the timeout path end to end: page never lands -> ONE forced paint that cannot hold again
    w, env, cb = build()
    w._bo_wait = { key = "k" }
    local flag_seen
    w._rebuild = function(self) env.rebuilds = env.rebuilds + 1; flag_seen = self._bo_force_paint end
    w:_beginHold({ key = "k" }, "rebuild")
    env.t = 35
    for i = #env.timers, 1, -1 do local f = env.timers[i].fn; table.remove(env.timers, i); f() end
    check("timeout: one forced paint, flagged", env.rebuilds == 1 and flag_seen == true and w._bo_force_paint == nil)
    check("timeout: logged reason=timeout", env.logged("reason=timeout"))
    cb("k", { id = "x" }, true, nil, true)
    env.runTicks()
    -- After the release the screen shows blank rows and still waits for the page
    -- (the real rebuild sets _bo_wait again), so a LATE landing must repaint them.
    check("timeout: a late landing after the release repaints the blank rows (once)", env.rebuilds == 2)
    check("timeout: and it is not logged as a held landing", not env.logged("reason=landed"))
end

print(string.format("test_bo_hold: %d passed, %d failed", passes, fails))
return fails > 0
