-- Functional test for lib/bookshelf_bo_data.lua with KOReader stubbed out.
-- Run via lupa: PLUGIN (plugin root) is set by the Python driver.
package.path = PLUGIN .. "/?.lua;" .. package.path

local fails, passes = 0, 0
local function check(name, cond, extra)
    if cond then passes = passes + 1
    else fails = fails + 1; print("FAIL: " .. name .. (extra and (" -> " .. tostring(extra)) or "")) end
end

-- ------------------------------------------------------------------ stubs
local now = os.time()
local env = { online = true, configured = true, tasks = {}, calls = {}, stats_calls = {} }
local function count(name) env.calls[name] = (env.calls[name] or 0) + 1 end

package.preload["logger"] = function() return { warn = function(...) env.last_warn = table.concat({ ... }, " ") end, info = function() end, dbg = function() end, err = function() end } end
package.preload["ffi/util"] = function() return { template = function(s, ...)
    local a = { ... }
    return (s:gsub("%%(%d)", function(i) return tostring(a[tonumber(i)]) end))
end } end
package.preload["lib/bookshelf_i18n"] = function() return { gettext = function(s) return s end } end
package.preload["datetime"] = function() return {
    shortDayOfWeekToLongTranslation = {}, shortDayOfWeekTranslation = {},
    longMonthTranslation = {}, shortMonthTranslation = {},
    secondsToHour = function(t) return os.date("%H:%M", t) end,
} end
package.preload["device"] = function() return { hasFrontlight = function() return false end } end
package.preload["util"] = function() return {
    diskUsage = function() count("diskUsage") return { total = 32e9, available = 12e9 } end,
    partialMD5 = function(path) count("partialMD5") return "abcdef0123456789" end,
    makePath = function() end,
} end
package.preload["datastorage"] = function() return { getSettingsDir = function() return "/tmp/x" end, getDataDir = function() return "/tmp/x" end } end
package.preload["libs/libkoreader-lfs"] = function() return {
    attributes = function(path, what)
        if env.files and env.files[path] then
            if what == "modification" and env.mtimes and env.mtimes[path] then return env.mtimes[path] end
            return what == "mode" and "file" or 1
        end
        return nil
    end,
    dir = function() return function() return nil end end,
} end
package.preload["ui/network/manager"] = function() return { isConnected = function() return env.online end, isOnline = function() return env.online end } end
package.preload["ui/uimanager"] = function() return {
    scheduleIn = function(_, delay, fn) table.insert(env.tasks, fn) end,
    nextTick = function(_, fn) table.insert(env.tasks, fn) end,
} end
package.preload["lib/bookorbit_board/art"] = function() return { hasFont = function() return true end } end
-- the statistics reader: counted, controllable
package.preload["lib/bookorbit_board/stats_reader"] = function()
    local R = {}
    local function stat(name, ret) return function(...) env.stats_calls[name] = (env.stats_calls[name] or 0) + 1; return ret end end
    R.getDailySeconds = function(since)
        env.stats_calls.daily = (env.stats_calls.daily or 0) + 1
        return { [os.date("%Y-%m-%d", now)] = 1800 }
    end
    R.getHourMinutes = stat("hours", (function() local h = {} for i = 1, 24 do h[i] = i end return h end)())
    R.getSessionRecords = stat("records", { sessions = 5, longest_seconds = 3000, average_seconds = 1200, pages_per_hour = 40 })
    R.getPageTurns = stat("pages", { total = 100, today = 7, first = now - 86400 * 400 })
    R.getBookPace = function(md5, days)
        env.stats_calls.pace = (env.stats_calls.pace or 0) + 1
        return { seconds_per_page = 60, total_pages = 300, recent_seconds = 14 * 1800 }
    end
    return R
end
_G.G_reader_settings = { isTrue = function() return false end }

-- BookOrbit client stub
local client = {}
package.preload["lib/bookshelf_bookorbit"] = function() return client end
env.dash_body = function()
    return {
        displayName = "Tester", generatedAt = os.date("!%Y-%m-%dT%H:%M:%SZ", now),
        continueReading = { { id = 1, title = "One", authors = { "A" }, progressPercentage = 40, updatedAt = "2026-01-01T00:00:00Z" },
                            { id = 2, title = "Two", authors = { "B" }, progressPercentage = 10 } },
        discover = { { id = 3, title = "Three", authors = { "C" } } },
        finishedThisYear = { { id = 4, title = "Four", authors = { "D" } } },
        readingGoal = { goalBooks = 20, completedBooks = 5, year = tonumber(os.date("%Y", now)) },
        readingStreak = { currentStreak = 3, longestStreak = 9, lastSevenDays = {} },
        browseCounts = { series = 5, authors = 7, collections = 2, smartScopes = 1 }, totalBooks = 321,
    }
end
local function resetClient()
    env.calls = {}
    env.dash_result = nil     -- nil -> success body
    env.dash_err = nil
    client.isConfigured = function() return env.configured end
    client.getConfig = function() return { server_url = "https://bo.example", username = "me" } end
    client.getDownloadDir = function() return "/books" end
    client.catalogDashboard = function()
        count("catalogDashboard")
        if env.dash_err then return nil, env.dash_err end
        return env.dash_body(), nil
    end
    client.catalogDiscover = function() count("catalogDiscover") return { discover = { { id = 30, title = "Disc" } } } end
    client.catalogBooks = function(q) count("catalogBooks:" .. tostring(q.sort or q.ids)) return { items = { { id = 40, title = "Book40" } } } end
    client.catalogSection = function(sec, q) count("catalogSection:" .. sec) return { items = { { title = "Coll A" }, { title = "Coll B" } } } end
    client.catalogDashboardSection = function(t) count("section:" .. t) return { section = { books = { { id = 50, title = "Sec " .. t } } } } end
    client.serverSupports = function(f) env.cap_calls = (env.cap_calls or 0) + 1; return env.supports end
    client.submitSyncJob = function(o) count("submitSyncJob"); o.run(); return "started" end
end
env.supports = true

-- shared disk cache stub
local cache_store = {}
package.preload["lib/bookshelf_bookorbit_cache"] = function() return {
    get = function(k) return cache_store[k] end,
    set = function(k, v) count("cacheSet"); cache_store[k] = v end,
} end
-- source stub: covers + downloads
env.downloaded = {}
env.covers_on_disk = {}
package.preload["lib/bookshelf_bookorbit_source"] = function() return {
    downloadedMap = function() return env.downloaded end,
    boardCover = function(book)
        if env.covers_on_disk[book.id] then return "/covers/" .. book.id .. ".jpg", "ready" end
        return nil, "loading"
    end,
    fetchBoardCover = function(book) count("fetchCover") env.covers_on_disk[book.id] = true return true end,
} end

local function runTasks(limit)
    local n = 0
    while #env.tasks > 0 and n < (limit or 200) do
        local fn = table.remove(env.tasks, 1)
        fn()
        n = n + 1
    end
    return n
end

local Data = require("lib/bookshelf_bo_data")
local function fresh()
    resetClient()
    Data.reset()
    env.tasks = {}
    env.stats_calls = {}
    cache_store = {}
    env.online, env.configured = true, true
    env.downloaded, env.covers_on_disk, env.files = {}, {}, {}
end

-- ===================== A. preview: sample data, zero I/O =====================
fresh()
local d = Data.get{ preview = true, refresh = function() end, needs = { shelves = { { source = "want-to-read" } } } }
check("A1 preview flag", d.preview == true)
check("A2 sample goal", d.goal.books == 24 and d.goal.done == 9, d.goal and d.goal.books)
check("A3 sample counts", d.counts.library == 640)
check("A4 heatmap built from sample", type(d.heatmap) == "table" and #d.heatmap > 300)
check("A5 sample hours", type(d.hours) == "table" and #d.hours == 24)
check("A6 sample word", d.word and d.word.word == "petrichor")
check("A7 no tasks scheduled", #env.tasks == 0, #env.tasks)
check("A8 no stats reads", next(env.stats_calls) == nil)
check("A9 no client calls", (env.calls.catalogDashboard or 0) == 0 and (env.calls.submitSyncJob or 0) == 0)
check("A10 not flagged unconfigured", d.not_configured == false)
check("A11 preview never touches cache", (env.calls.cacheSet or 0) == 0)

-- ===================== B. not configured ====================================
fresh(); env.configured = false
d = Data.get{ refresh = function() end }
check("B1 not_configured", d.not_configured == true)
check("B2 unavailable", d.unavailable == true and d.loading == false)
check("B3 no fetch scheduled", (env.calls.submitSyncJob or 0) == 0)
runTasks()
check("B4 still no fetch", (env.calls.catalogDashboard or 0) == 0)
check("B5 clock fields still present", d.clock ~= nil and d.day_month ~= nil)

-- ===================== C. first load, shared fetch ==========================
fresh()
local refreshed1, refreshed2 = 0, 0
local f1 = function() refreshed1 = refreshed1 + 1 end
local f2 = function() refreshed2 = refreshed2 + 1 end
local needs = { shelves = { { source = "want-to-read" }, { source = "recently-added" }, { source = "random" } }, names = { "collections" } }
d = Data.get{ refresh = f1, needs = needs }
check("C1 loading on first render", d.loading == true and d.unavailable == false, tostring(d.loading) .. "/" .. tostring(d.unavailable))
check("C2 render did not fetch", (env.calls.catalogDashboard or 0) == 0)
local d2 = Data.get{ refresh = f2, needs = needs }   -- second card, same pass
check("C3 one pending fetch for both cards", Data.status().fetch_pending == true and (env.calls.submitSyncJob or 0) == 0)
runTasks()
check("C4 one dashboard call for two cards", env.calls.catalogDashboard == 1, env.calls.catalogDashboard)
check("C5 want-to-read via section endpoint", env.calls["section:want-to-read"] == 1)
check("C6 recently-added via catalog/books", env.calls["catalogBooks:recently_added"] == 1)
check("C7 random served from dashboard body (no discover call)", (env.calls.catalogDiscover or 0) == 0)
check("C8 collections names fetched", env.calls["catalogSection:collections"] == 1)
check("C9 both cards refreshed once", refreshed1 == 1 and refreshed2 == 1, refreshed1 .. "," .. refreshed2)
d = Data.get{ refresh = f1, needs = needs }
check("C10 data present", d.loading == false and d.continue_reading[1] and d.continue_reading[1].title == "One")
check("C11 name", d.display_name == "Tester")
check("C12 goal", d.goal.books == 20 and d.goal.done == 5)
check("C13 streak", d.streak.current == 3 and d.streak.longest == 9)
check("C14 counts", d.counts.library == 321 and d.counts.series == 5)
check("C15 shelf want-to-read", d.shelves["want-to-read"] and d.shelves["want-to-read"][1].title == "Sec want-to-read")
check("C16 shelf random from body", d.shelves["random"] and d.shelves["random"][1].title == "Three")
check("C17 finished shelf", d.shelves["finished"][1].title == "Four")
check("C18 names", d.names.collections and d.names.collections[1] == "Coll A")
check("C19 cached to disk cache", cache_store["bo_board:https://bo.example|me:dash"] ~= nil)
check("C20 not stale", d.stale == false)
-- covers: queued by decorate(), downloaded off the render path
check("C21 covers queued, not downloaded in render", (env.calls.fetchCover or 0) == 0)
check("C22 cover state loading", d.continue_reading[1].cover_state == "loading")
local before = refreshed1
d = Data.get{ refresh = f1, needs = needs }   -- re-register listener
runTasks()
check("C23 covers fetched in ticks", (env.calls.fetchCover or 0) >= 2, env.calls.fetchCover)
check("C24 repaint after covers", refreshed1 > before)
d = Data.get{ refresh = f1, needs = needs }
check("C25 cover ready path", d.continue_reading[1].cover_path == "/covers/1.jpg" and d.continue_reading[1].cover_state == "ready")
runTasks()
local calls_after = env.calls.catalogDashboard
for i = 1, 5 do Data.get{ refresh = f1, needs = needs } end
runTasks()
check("C26 fresh data: no refetch on later renders", env.calls.catalogDashboard == calls_after)

-- ===================== D. offline with a cache ==============================
local saved_cache = cache_store
fresh(); cache_store = saved_cache; env.online = false
d = Data.get{ refresh = f1, needs = needs }
check("D1 served from disk cache", d.continue_reading[1] and d.continue_reading[1].title == "One")
check("D2 stale when offline", d.stale == true and d.online == false)
runTasks()
check("D3 no fetch offline", (env.calls.submitSyncJob or 0) == 0 and (env.calls.catalogDashboard or 0) == 0 and Data.status().fetch_pending == false)

-- ===================== E. offline, no cache =================================
fresh(); env.online = false
d = Data.get{ refresh = f1 }
check("E1 unavailable, not loading", d.unavailable == true and d.loading == false)
runTasks()
check("E2 no fetch", (env.calls.submitSyncJob or 0) == 0 and (env.calls.catalogDashboard or 0) == 0)

-- ===================== F. old server (404) ==================================
fresh(); env.dash_err = 404
d = Data.get{ refresh = f1 }
runTasks()
check("F1 one attempt", env.calls.catalogDashboard == 1)
d = Data.get{ refresh = f1 }
check("F2 server_too_old", d.server_too_old == true and d.unavailable == true)
runTasks()
Data.get{ refresh = f1 }; runTasks()
check("F3 no hammering (backoff)", env.calls.catalogDashboard == 1, env.calls.catalogDashboard)

-- ===================== G. transient failure =================================
fresh(); env.dash_err = "timeout"
d = Data.get{ refresh = f1 }
runTasks()
check("G1 one attempt", env.calls.catalogDashboard == 1)
d = Data.get{ refresh = f1 }
check("G2 unavailable while backing off", d.unavailable == true and d.loading == false)
Data.get{ refresh = f1 }; runTasks()
check("G3 backoff holds", env.calls.catalogDashboard == 1)
check("G4 status reports backoff", Data.status().backoff > 0)

-- ===================== H. local statistics: snapshot + queue ================
fresh()
local hrefresh = 0
local hf = function() hrefresh = hrefresh + 1 end
cache_store["bo_board:https://bo.example|me:dash"] = { at = os.time(), body = env.dash_body() }
Data.reset()
d = Data.get{ refresh = hf }
local hours = d.hours          -- lazy field, evaluated at "draw" time
check("H1 hours nil on first draw", hours == false or hours == nil)
check("H2 render did not read sqlite", next(env.stats_calls) == nil, next(env.stats_calls))
local _ = d.heatmap
runTasks()
check("H3 queue read hours once", env.stats_calls.hours == 1, env.stats_calls.hours)
check("H4 daily read once", env.stats_calls.daily == 1, env.stats_calls.daily)
check("H5 repainted", hrefresh >= 1)
d = Data.get{ refresh = hf }
local h2 = d.hours
check("H6 hours present on next build", type(h2) == "table" and #h2 == 24)
check("H7 today's minutes from local stats", d.today_min == 30, d.today_min)
check("H8 week minutes", d.week_min == 30, d.week_min)
local reads = env.stats_calls.hours
for i = 1, 4 do local dd = Data.get{ refresh = hf }; local _ = dd.hours; local _ = dd.records end
runTasks()
check("H9 records read once, hours not re-read", env.stats_calls.records == 1 and env.stats_calls.hours == reads)
d = Data.get{ refresh = hf }
check("H10 records value", d.records and d.records.longest_min == 50 and d.records.pages_per_hour == 40, d.records and d.records.longest_min)
check("H11 pages", (function() local p = d.pages; runTasks(); d = Data.get{ refresh = hf }; return d.pages and d.pages.today == 7 end)())

-- ===================== I. forecast needs md5 -> pace via queue ==============
fresh()
cache_store["bo_board:https://bo.example|me:dash"] = { at = os.time(), body = env.dash_body() }
Data.reset()
env.downloaded = { ["1"] = "/books/one.epub" }
env.files = { ["/books/one.epub"] = true }
d = Data.get{ refresh = hf }
check("I1 lead book on device", d.continue_reading[1].on_device == true)
check("I2 md5 computed", env.calls.partialMD5 == 1)
check("I3 no pace read in render", (env.stats_calls.pace or 0) == 0)
check("I4 no forecast yet", d.forecast == nil)
runTasks()
d = Data.get{ refresh = hf }
check("I5 pace read in tick", env.stats_calls.pace == 1, env.stats_calls.pace)
check("I6 forecast present", d.forecast and d.forecast.minutes_left > 0, d.forecast and d.forecast.minutes_left)
check("I7 device count", d.counts.device == 1)

-- ===================== J. account switch drops state =========================
local cfg_calls = 0
local old_get = client.getConfig
client.getConfig = function() return { server_url = "https://other.example", username = "you" } end
d = Data.get{ refresh = hf }
check("J1 other account has no cached dashboard", d.continue_reading and #d.continue_reading == 0, d.continue_reading and #d.continue_reading)
client.getConfig = old_get

-- ===================== K. needs derivation (adapter) ========================
package.preload["logger"] = package.preload["logger"]
local Bo = require("lib/bookshelf_bo_module")
local n = Bo.needsFor{ type = "shelf", props = { source = "want-to-read" } }
check("K1 shelf needs", #n.shelves == 1 and n.shelves[1].source == "want-to-read")
n = Bo.needsFor{ type = "link", props = { link = "authors" } }
check("K2 authors link needs two shelves", #n.shelves == 2)
n = Bo.needsFor{ type = "link", props = { link = "collections" } }
check("K3 collections link needs names", n.names[1] == "collections" and #n.shelves == 0)
n = Bo.needsFor{ type = "dust" }
check("K4 dust needs unopened", n.shelves[1].source == "unopened")
n = Bo.needsFor{ type = "clock" }
check("K5 clock needs nothing", #n.shelves == 0 and #n.names == 0)

-- ===================== L. Batch 5: selector shelves, last sync, searches ====
fresh()
local last_q
client.catalogBooks = function(q) last_q = q; count("catalogBooks:sel") return { items = { { id = 60, title = "FromLib" } } } end
local sel = { source = "libraries", params = { libraryId = 5, sort = "title" }, title = "Sci-fi" }
local sneeds = { shelves = { { source = sel.source, params = sel.params } } }
d = Data.get{ refresh = function() end, needs = sneeds }
runTasks()
d = Data.get{ refresh = function() end, needs = sneeds }
check("L1 selector shelf fetched with its filter", last_q and last_q.libraryId == 5 and last_q.size ~= nil, last_q and last_q.libraryId)
check("L2 stored under the shelf key BookOrbit's widget reads", d.shelves["libraries:libraryId=5:sort=title"] and d.shelves["libraries:libraryId=5:sort=title"][1].title == "FromLib")
-- two different selector shelves do not share a slot
local other = { source = "authors", params = { author = "Le Guin", sort = "title" } }
local n2 = { shelves = { { source = sel.source, params = sel.params }, { source = other.source, params = other.params } } }
d = Data.get{ refresh = function() end, needs = n2 }
runTasks()
d = Data.get{ refresh = function() end, needs = n2 }
check("L3 second selector shelf separate", d.shelves["authors:author=Le Guin:sort=title"] ~= nil and d.shelves["libraries:libraryId=5:sort=title"] ~= nil)
-- last sync + recent searches come from the client, not a stub
client.lastSync = function() return { at = now - 7200, event = "push" } end
client.recentSearches = function() return { "Dune", "Hyperion" } end
Data.invalidate()
d = Data.get{ refresh = function() end, needs = { shelves = {}, names = {} } }
check("L4 last_sync_at from the client", d.last_sync_at == now - 7200, tostring(d.last_sync_at))
check("L5 recent searches from the client", d.recent_searches[1] == "Dune" and d.recent_searches[2] == "Hyperion")
client.lastSync = function() return nil end
d = Data.get{ refresh = function() end, needs = { shelves = {}, names = {} } }
check("L6 never synced -> nil", d.last_sync_at == nil)
local pv = Data.get{ preview = true, refresh = function() end, needs = { shelves = {}, names = {} } }
check("L7 preview has a sample last sync + searches", pv.last_sync_at ~= nil and #pv.recent_searches > 0)

-- ===================== M. Batch 6b: badge/chapters/dust samples, dust state, file removal
fresh()
pv = Data.get{ preview = true, refresh = function() end, needs = { shelves = {}, names = {} } }
check("M1 preview badge has a next and a latest badge", pv.badges and pv.badges.next and pv.badges.next.name == "Fifty Hours"
    and pv.badges.latest and pv.badges.latest.name == "One Week", pv.badges and tostring(pv.badges.missing))
check("M1b the sample badge is not 'fresh' (earned 3 days ago)", pv.badges.fresh == false)
check("M2 preview chapter line: 8 stops, a next stop with minutes", pv.chapters and #pv.chapters.stops == 8
    and pv.chapters.next > pv.chapters.cur and type(pv.chapters.minutes(pv.chapters.next)) == "number")
check("M3 preview dust has a book", pv.dust and pv.dust.count == 7 and pv.dust.book ~= nil)
check("M4 these samples still do no I/O", #env.tasks == 0 and next(env.stats_calls) == nil and (env.calls.submitSyncJob or 0) == 0)

-- a real dusty pool: three downloaded, unopened books
fresh()
local today = os.date("%Y-%m-%d")
env.downloaded = { ["11"] = "/books/a.epub", ["12"] = "/books/b.epub", ["13"] = "/books/c.epub" }
env.files = { ["/books/a.epub"] = true, ["/books/b.epub"] = true, ["/books/c.epub"] = true }
env.mtimes = { ["/books/a.epub"] = 1000, ["/books/b.epub"] = 2000, ["/books/c.epub"] = 3000 }
client.catalogBooks = function(q)
    local items = {}
    for id in tostring(q.ids or ""):gmatch("%d+") do items[#items + 1] = { id = tonumber(id), title = "Book" .. id } end
    return { items = items }
end
client.dustState = function() return env.dust_state or {} end
local dneeds = { shelves = { { source = "unopened" } }, names = {} }
local function dustNow()
    -- The shelf fetch and the unopened-files snapshot each land on their own tick.
    for _i = 1, 4 do
        local _ = Data.get{ refresh = function() end, needs = dneeds }.dust   -- a render reads it, which queues the scan
        runTasks()
    end
    return Data.get{ refresh = function() end, needs = dneeds }.dust
end
local base = dustNow()
check("M5 dust: a pool of 3 gives a book and a count", base and base.count == 3 and base.book, base and tostring(base.count))
env.dust_state = { day = today, skip = 1 }
local skip1 = dustNow()
check("M6 dust: today's skip count (live setting) shows another book", skip1 and skip1.book and skip1.book.id ~= base.book.id)
env.dust_state = { day = today, skip = 3 }
local skip3 = dustNow()
check("M7 dust: skipping the whole pool wraps back", skip3 and skip3.book.id == base.book.id)
env.dust_state = { day = "2000-01-01", skip = 1 }
local old_day = dustNow()
check("M8 dust: yesterday's skip does not apply today", old_day and old_day.book.id == base.book.id)
env.dust_state = {}

-- the trash button: the file goes away, the data layer is told, the pool shrinks
local gone = base.book.id
env.files[env.downloaded[tostring(gone)]] = nil
local stale = dustNow()
check("M9 without fileRemoved the 3600s snapshot still holds the removed book", stale and stale.count == 3, stale and tostring(stale.count))
Data.fileRemoved(env.downloaded[tostring(gone)])
local after = dustNow()
check("M10 after fileRemoved the pool is 2 and the removed book is gone", after and after.count == 2 and after.book.id ~= gone,
    after and (tostring(after.count) .. "/" .. tostring(after.book and after.book.id)))
check("M11 fileRemoved did not refetch the dashboard", (env.calls.catalogDashboard or 0) <= 1, env.calls.catalogDashboard)
check("M12 fileRemoved tolerates junk", pcall(Data.fileRemoved, nil) and pcall(Data.fileRemoved, 5))

print(string.format("RESULT: %d passed, %d failed", passes, fails))
return fails
