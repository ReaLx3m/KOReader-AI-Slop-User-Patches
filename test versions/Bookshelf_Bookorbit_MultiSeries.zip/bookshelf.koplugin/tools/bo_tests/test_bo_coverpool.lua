-- Cover speed, Batch 2: pure cover pool core. Off-device; no KOReader, no
-- network, no real forks (a fake world stands in for every dep). Proves the
-- LOGIC only (not run on a device). The pool is NOT wired into the UI yet.
package.path = PLUGIN .. "/?.lua;" .. package.path
local fails, passes = 0, 0
local function check(n, c, x)
    if c then passes = passes + 1
    else fails = fails + 1; print("FAIL: " .. n .. (x ~= nil and (" -> " .. tostring(x)) or "")) end
end

local Pool = require("lib/bookshelf_bookorbit_coverpool")

-- Fake world ------------------------------------------------------------------
local function world(opts)
    opts = opts or {}
    local w = {
        t = 0, timers = {}, files = {}, forks = {}, next_pid = 0,
        spawned = {}, kills = {}, removed = {}, landed = {}, failed = {}, decoded = {},
        broken = {}, idle = {}, online = true, fork_ok = true, decode_ok = {}, callbacks_in_api = 0,
        in_api = false,
    }
    local function path_of(rec) return "/c/" .. tostring(rec.id) .. ".jpg" end
    local deps = {
        now = function() return w.t end,
        schedule = function(delay, fn)
            local h = { at = w.t + delay, fn = fn, live = true }
            w.timers[#w.timers + 1] = h
            return h
        end,
        unschedule = function(h) if h then h.live = false end end,
        online = function() return w.online end,
        exists = function(path) return w.files[path] == true end,
        describe = function(rec)
            if rec.bad_describe then error("describe boom") end
            if rec.skip then return nil end
            return { key = rec.id, path = path_of(rec), part = path_of(rec) .. ".part" }
        end,
        spawn = function(job)
            if opts.spawn_throws then error("spawn boom") end
            if not w.fork_ok then return nil, "no fork" end
            w.next_pid = w.next_pid + 1
            local pid = w.next_pid
            w.forks[pid] = { job = job, done = false, out = "", killed = false, done_after = nil }
            w.spawned[#w.spawned + 1] = job.key
            return pid, "fd" .. pid
        end,
        is_done = function(pid)
            local f = w.forks[pid]
            if not f then return true end
            if f.done_after and w.t >= f.done_after then f.done = true end
            return f.done
        end,
        readable = function(fd) local f = w.forks[tonumber(fd:sub(3))]; return f and f.out ~= "" end,
        read = function(fd)
            local f = w.forks[tonumber(fd:sub(3))]
            local o = f and f.out or ""
            if f then f.out = "" end
            return o
        end,
        kill = function(pid)
            w.kills[#w.kills + 1] = pid
            local f = w.forks[pid]
            if f then f.killed = true; f.done_after = w.t + (opts.reap_delay or 0) end
        end,
        remove = function(path) w.removed[#w.removed + 1] = path; w.files[path] = nil end,
        decode = function(job)
            if opts.decode_throws then error("decode boom") end
            if w.decode_ok[job.key] == false then
                w.files[job.path] = nil
                return false
            end
            for _, r in ipairs(job.records) do r.cover = true end
            w.decoded[#w.decoded + 1] = job.key
            return true
        end,
        mark_failed = function(key, why) w.failed[#w.failed + 1] = { key = key, why = why } end,
        on_landed = function(sid, final, left)
            w.landed[#w.landed + 1] = { sid = sid, final = final, left = left }
            if w.on_landed_hook then w.on_landed_hook(sid, final) end
            if opts.landed_throws then error("landed boom") end
        end,
        on_fork_broken = function(recs, sid) w.broken[#w.broken + 1] = { recs = recs, sid = sid } end,
        on_idle = (not opts.no_idle) and function(had)
            w.idle[#w.idle + 1] = had
            if w.on_idle_hook then w.on_idle_hook(had) end
            if opts.idle_throws then error("idle boom") end
        end or nil,
        width = opts.width, deadline = opts.deadline,
    }
    w.deps = deps
    w.pool = Pool.new(deps)
    function w.advance(dt)
        local target = w.t + dt
        while true do
            local nxt
            for _, h in ipairs(w.timers) do
                if h.live and h.at <= target and (not nxt or h.at < nxt.at) then nxt = h end
            end
            if not nxt then break end
            w.t = math.max(w.t, nxt.at)
            nxt.live = false
            nxt.fn()
        end
        w.t = target
    end
    function w.live_timers()
        local n = 0
        for _, h in ipairs(w.timers) do if h.live then n = n + 1 end end
        return n
    end
    -- Finish a worker: out = "1" creates the file, anything else does not.
    function w.finish(pid, out, done)
        local f = w.forks[pid]
        f.out = out
        f.done = done ~= false
        if out == "1" then w.files[f.job.path] = true end
    end
    function w.recs(...)
        local list = {}
        for _, id in ipairs({ ... }) do list[#list + 1] = { id = id } end
        return list
    end
    function w.finals()
        local n = 0
        for _, l in ipairs(w.landed) do if l.final then n = n + 1 end end
        return n
    end
    return w
end

local function spawn_count(w) return #w.spawned end

-- constants ----------------------------------------------------------------------
check("default width 3", Pool.DEFAULT_WIDTH == 3)
check("default deadline 25", Pool.DEFAULT_DEADLINE == 25)
check("max tries 2", Pool.MAX_TRIES == 2)

-- empty enqueue -----------------------------------------------------------------
do
    local w = world()
    check("empty list -> empty", w.pool:enqueue({}, "s") == "empty")
    check("  no timers", w.live_timers() == 0)
    check("nil list -> empty", w.pool:enqueue(nil, "s") == "empty")
    local r = { id = 1, skip = true }
    check("describe nil -> empty", w.pool:enqueue({ r }, "s") == "empty")
    check("describe throws -> skipped", w.pool:enqueue({ { id = 2, bad_describe = true } }, "s") == "empty")
end

-- basic flow --------------------------------------------------------------------------
do
    local w = world()
    local recs = w.recs("A", "B", "C")
    check("enqueue queued", w.pool:enqueue(recs, "chip") == "queued")
    check("  nothing spawned inside enqueue", spawn_count(w) == 0)
    w.advance(0.03)
    check("3 workers launched at first poll", spawn_count(w) == 3)
    check("  order A B C", w.spawned[1] == "A" and w.spawned[3] == "C")
    w.finish(1, "1"); w.finish(2, "1"); w.finish(3, "1")
    w.advance(0.15)
    check("  collected into decode queue", w.pool:status().in_flight == 0)
    w.advance(0.5)
    check("all decoded", #w.decoded == 3 and recs[1].cover and recs[2].cover and recs[3].cover)
    check("  landed events false,false,true", #w.landed == 3 and not w.landed[1].final
        and not w.landed[2].final and w.landed[3].final)
    check("  final once", w.finals() == 1)
    check("  chain over, no timers", not w.pool:status().chain_active and w.live_timers() == 0)
end

-- width limit + FIFO --------------------------------------------------------------------
do
    local w = world()
    w.pool:enqueue(w.recs(1, 2, 3, 4, 5, 6, 7), "s")
    w.advance(0.03)
    check("width 3 respected", spawn_count(w) == 3 and w.pool:status().pending == 4)
    w.finish(1, "1")
    w.advance(0.15)
    check("a freed slot launches the next, in order", spawn_count(w) == 4 and w.spawned[4] == 4)
end

-- configured width ----------------------------------------------------------------------------
do
    local w = world({ width = 5 })
    w.pool:enqueue(w.recs(1, 2, 3, 4, 5, 6, 7), "s")
    w.advance(0.03)
    check("width 5 honoured", spawn_count(w) == 5)
    local w2 = world({ width = 0 })
    w2.pool:enqueue(w2.recs(1, 2), "s"); w2.advance(0.03)
    check("width floor 1", spawn_count(w2) == 1)
end

-- dedup inside one enqueue; records attached -------------------------------------------------------
do
    local w = world()
    local a1, a2 = { id = "A" }, { id = "A" }
    w.pool:enqueue({ a1, a2 }, "s")
    w.advance(0.03)
    check("same key: one worker", spawn_count(w) == 1)
    w.finish(1, "1")
    w.advance(1)
    check("  both record objects filled", a1.cover and a2.cover)
end

-- disk hit skips the fork ------------------------------------------------------------------------------
do
    local w = world()
    w.files["/c/A.jpg"] = true
    local recs = w.recs("A", "B")
    w.pool:enqueue(recs, "s")
    w.advance(0.03)
    check("disk hit: no worker for A", spawn_count(w) == 1 and w.spawned[1] == "B")
    w.advance(0.1)
    check("  A decoded without a fork", recs[1].cover == true)
end

-- same cover key twice, file already on disk (Batch 3 regression) -----------------------------------------------
-- Two record objects with one key arriving in ONE enqueue used to make two
-- decode jobs; _toDecode kept the first and silently dropped the second, so the
-- second record was never filled.
do
    local w = world()
    w.files["/c/A.jpg"] = true
    local r1, r2 = w.recs("A", "A")[1], nil
    local recs = w.recs("A", "A")
    w.pool:enqueue(recs, "s")
    check("same-key disk hits make ONE decode job", w.pool:status().decode == 1, w.pool:status().decode)
    w.advance(0.2)
    check("  both records filled", recs[1].cover == true and recs[2].cover == true)
    check("  decoded once, one final", #w.decoded == 1 and w.finals() == 1, #w.decoded)
end

-- decode budget: one per tick ------------------------------------------------------------------------------
do
    local w = world()
    for _, id in ipairs({ "A", "B", "C", "D", "E" }) do w.files["/c/" .. id .. ".jpg"] = true end
    w.pool:enqueue(w.recs("A", "B", "C", "D", "E"), "s")
    check("5 disk hits queued for decode", w.pool:status().decode == 5)
    w.advance(0.021)
    check("one decode after the first tick", #w.decoded == 1, #w.decoded)
    w.advance(0.02)
    check("two after the second", #w.decoded == 2, #w.decoded)
    w.advance(0.1)
    check("all five eventually", #w.decoded == 5)
    check("  decode-only chain ends with one final", w.finals() == 1)
    check("  no non-final event for the last cover", w.landed[#w.landed].final and #w.landed == 5)
end

-- new disk hits decode ahead of older queued decodes ---------------------------------------------------------------
do
    local w = world()
    w.files["/c/A.jpg"] = true; w.files["/c/B.jpg"] = true
    w.pool:enqueue(w.recs("A", "B"), "old")
    w.files["/c/X.jpg"] = true
    w.pool:enqueue(w.recs("X"), "new")
    w.advance(0.021)
    check("newest page's disk hit decodes first", w.decoded[1] == "X", w.decoded[1])
end

-- definitive failure, server says no: no narrowing ---------------------------------------------------------------------
do
    local w = world()
    w.pool:enqueue(w.recs("A", "B", "C"), "s")
    w.advance(0.03)
    w.finish(1, "nf:http_404")
    w.advance(0.15)
    check("404: mark_failed once", #w.failed == 1 and w.failed[1].key == "A" and w.failed[1].why == "http_404")
    check("  width not narrowed", w.pool:status().cap == 3)
    check("  part removed", w.removed[1] == "/c/A.jpg.part")
    local before = spawn_count(w)
    w.pool:enqueue(w.recs("A"), "s"); w.advance(0.5)
    check("  given-up key never re-launched", spawn_count(w) == before)
    local w2 = world()
    w2.pool:enqueue(w2.recs("A", "B", "C"), "s"); w2.advance(0.03)
    w2.finish(1, "nf:not_an_image"); w2.advance(0.15)
    check("not_an_image does not narrow (chain still active)",
        w2.pool:status().chain_active and w2.pool:status().cap == 3, w2.pool:status().cap)
end

-- transport failure narrows -------------------------------------------------------------------------------------------------
do
    local w = world()
    w.pool:enqueue(w.recs("A", "B", "C", "D"), "s")
    w.advance(0.03)
    w.finish(1, "nf:http_500")
    w.advance(0.15)
    check("5xx narrows 3 -> 1", w.pool:status().cap == 1, w.pool:status().cap)
    check("  and the key is given up", w.failed[1] and w.failed[1].why == "http_500")
    -- never widens again within the chain
    w.finish(2, "1"); w.finish(3, "1")
    w.advance(0.15)
    check("  never widens within the chain", w.pool:status().cap == 1)
end

-- narrowing halves down to 1 ---------------------------------------------------------------------------------------------------
do
    local w = world({ width = 8 })
    w.pool:enqueue(w.recs(1, 2, 3, 4, 5, 6, 7, 8, 9, 10), "s")
    w.advance(0.03)
    w.finish(1, "nf:timeout"); w.advance(0.15)
    check("8 -> 4", w.pool:status().cap == 4, w.pool:status().cap)
    w.finish(2, "nf:timeout"); w.advance(0.15)
    check("4 -> 2", w.pool:status().cap == 2, w.pool:status().cap)
    w.finish(3, "nf:timeout"); w.advance(0.15)
    check("2 -> 1", w.pool:status().cap == 1, w.pool:status().cap)
    w.finish(4, "nf:timeout"); w.advance(0.15)
    check("floor 1", w.pool:status().cap == 1)
end

-- offline reply from a worker: dropped silently --------------------------------------------------------------------------------------
do
    local w = world()
    w.pool:enqueue(w.recs("A"), "s"); w.advance(0.03)
    w.finish(1, "nf:offline"); w.advance(0.2)
    check("nf:offline: no mark_failed", #w.failed == 0)
    check("  no try counted: can be enqueued again", w.pool:enqueue(w.recs("A"), "s") == "queued")
    check("  width unchanged", w.pool:status().cap == 3)
end

-- timeout: kill, remove part, retry once, then give up ----------------------------------------------------------------------------------
do
    local w = world({ deadline = 25 })
    w.pool:enqueue(w.recs("A"), "s"); w.advance(0.03)
    w.advance(24)
    check("not killed before the deadline", #w.kills == 0)
    w.advance(1.5)
    check("killed after the deadline", #w.kills == 1 and w.kills[1] == 1, #w.kills)
    check("  part removed", w.removed[1] == "/c/A.jpg.part")
    check("  timeout is not a permanent failure yet", #w.failed == 0)
    check("  retried (second worker)", spawn_count(w) == 2, spawn_count(w))
    check("  width narrowed on timeout", w.pool:status().cap == 1)
    w.advance(26.5)
    check("2nd timeout gives up", #w.failed == 1 and w.failed[1].why == "timeout", #w.failed)
    check("  and the key is blacklisted in the pool", (function()
        local n = spawn_count(w)
        w.pool:enqueue(w.recs("A"), "s"); w.advance(1)
        return spawn_count(w) == n
    end)())
end

-- crash: finished worker with no output ---------------------------------------------------------------------------------------------------
do
    local w = world()
    w.pool:enqueue(w.recs("A"), "s"); w.advance(0.03)
    w.finish(1, "")
    w.advance(0.2)
    check("crash counts as a try, retried", spawn_count(w) == 2 and #w.failed == 0, spawn_count(w))
    w.finish(2, "")
    w.advance(0.2)
    check("2nd crash gives up", #w.failed == 1 and w.failed[1].why == "crash")
end

-- "1" but the file is missing --------------------------------------------------------------------------------------------------------------------
do
    local w = world()
    w.pool:enqueue(w.recs("A"), "s"); w.advance(0.03)
    local f = w.forks[1]; f.out = "1"; f.done = true   -- no file created
    w.advance(0.2)
    check("ok without file is a transient failure", #w.failed == 0 and spawn_count(w) == 2)
end

-- result written but process not finished yet: result is taken, pid reaped later ---------------------------------------------------------------
do
    local w = world({ reap_delay = 3 })
    w.pool:enqueue(w.recs("A"), "s"); w.advance(0.03)
    w.finish(1, "1", false)          -- output ready, process still exiting
    w.forks[1].done_after = w.t + 3
    w.advance(0.2)
    check("result accepted before the process exits", w.pool:status().in_flight == 0 and #w.decoded == 1, #w.decoded)
    check("  pid queued for collection", w.pool:status().reaping == 1)
    w.advance(5)
    check("  reaper collects it", w.pool:status().reaping == 0)
    check("  reaper timer stops", w.live_timers() == 0)
end

-- supersede keeps in-flight, replaces pending ------------------------------------------------------------------------------------------------------
do
    local w = world({ width = 2 })
    local old = w.recs("A", "B", "C", "D")
    w.pool:enqueue(old, "chip1")
    w.advance(0.03)                       -- A, B in flight; C, D pending
    local newer = w.recs("B", "X", "Y")   -- B is already in flight
    w.pool:enqueue(newer, "chip1")
    local st = w.pool:status()
    check("pending replaced (X, Y), in-flight kept", st.pending == 2 and st.in_flight == 2, st.pending)
    check("  nothing killed by the supersede", #w.kills == 0)
    w.finish(2, "1")                      -- B finishes
    w.advance(0.5)
    check("  in-flight B fills BOTH record objects", old[2].cover and newer[1].cover)
    check("  old pending C/D were dropped (never launched)", (function()
        for _, k in ipairs(w.spawned) do if k == "C" or k == "D" then return false end end
        return true
    end)())
end

-- cancel: pending only, no callbacks -------------------------------------------------------------------------------------------------------------------
do
    local w = world({ width = 1 })
    w.pool:enqueue(w.recs("A", "B", "C"), "s"); w.advance(0.03)
    local before = #w.landed
    w.pool:cancel()
    check("cancel: no callback inside", #w.landed == before)
    check("  pending dropped, in-flight kept", w.pool:status().pending == 0 and w.pool:status().in_flight == 1)
    w.finish(1, "1"); w.advance(0.5)
    check("  in-flight still lands and the chain ends with a final", #w.decoded == 1 and w.finals() == 1)
end

-- cancel with nothing else active ends the chain from a timer, not inside cancel ----------------------------------------------------------------------------
do
    local w = world()
    w.pool:enqueue(w.recs("A"), "s"); w.advance(0.03)
    w.finish(1, "1"); w.advance(0.15)
    -- decoded A already? run until chain end first
    w.advance(0.5)
    local w2 = world()
    w2.pool:enqueue(w2.recs("A", "B"), "s"); w2.advance(0.03)
    w2.finish(1, "1"); w2.finish(2, "1")
    w2.advance(0.15)                       -- both in decode queue
    w2.pool:cancel()
    check("cancel never fires on_landed itself", #w2.landed == 0)
    w2.advance(0.5)
    check("decode work survives cancel", #w2.decoded == 2)
end

-- shutdown: kill, remove, no callbacks, reaper alive ---------------------------------------------------------------------------------------------------------------
do
    local w = world({ reap_delay = 2 })
    w.pool:enqueue(w.recs("A", "B", "C", "D"), "s"); w.advance(0.03)
    w.pool:shutdown()
    check("shutdown killed 3 workers", #w.kills == 3)
    check("  removed their .part files", #w.removed == 3)
    check("  no callbacks", #w.landed == 0 and #w.failed == 0)
    local st = w.pool:status()
    check("  state cleared", st.pending == 0 and st.in_flight == 0 and st.decode == 0 and not st.chain_active)
    check("  pids still being reaped", st.reaping == 3)
    w.advance(5)
    check("  reaper collects them all", w.pool:status().reaping == 0 and w.live_timers() == 0)
    check("  usable again after shutdown", w.pool:enqueue(w.recs("Z"), "s") == "queued")
end

-- offline: never launch, drop pending, no failure ------------------------------------------------------------------------------------------------------------------------
do
    local w = world()
    w.online = false
    w.pool:enqueue(w.recs("A", "B"), "s")
    w.advance(0.5)
    check("offline: nothing spawned", spawn_count(w) == 0)
    check("  chain ended quietly, no final", not w.pool:status().chain_active and #w.landed == 0)
    check("  no failure recorded", #w.failed == 0)
    w.online = true
    check("  back online it works again", w.pool:enqueue(w.recs("A"), "s") == "queued")
    w.advance(0.03)
    check("  and launches", spawn_count(w) == 1)
end

-- fork broken: hand the rest back ----------------------------------------------------------------------------------------------------------------------------------------------------
do
    local w = world()
    w.fork_ok = false
    local recs = w.recs("A", "B", "C")
    check("enqueue still queued (spawn happens in the poll)", w.pool:enqueue(recs, "chip") == "queued")
    check("  no callback inside enqueue", #w.broken == 0)
    w.advance(0.03)
    check("on_fork_broken fired once with every waiting record", #w.broken == 1 and #w.broken[1].recs == 3)
    check("  source id passed", w.broken[1].sid == "chip")
    check("  pool flags fork_broken", w.pool:status().fork_broken)
    check("  later enqueue answers fork_broken", w.pool:enqueue(recs, "chip") == "fork_broken")
    w.advance(1)
    check("  chain drained, no timers", w.live_timers() == 0)
end
do
    local w = world({ spawn_throws = true })
    w.pool:enqueue(w.recs("A"), "s"); w.advance(0.03)
    check("spawn that throws counts as fork_broken", w.pool:status().fork_broken and #w.broken == 1)
end

-- finals: one per distinct source that landed, nil source ok -----------------------------------------------------------------------------------------------------------------------------
do
    local w = world()
    w.files["/c/A.jpg"] = true; w.files["/c/B.jpg"] = true; w.files["/c/C.jpg"] = true
    local a, b, c = { id = "A" }, { id = "B" }, { id = "C" }
    w.pool:enqueue({ a }, "one")
    w.pool:enqueue({ b }, "two")
    w.pool:enqueue({ c }, nil)
    w.advance(1)
    check("three sources landed", #w.decoded == 3)
    check("  one final per distinct source", w.finals() == 3, w.finals())
    local seen_nil = false
    for _, l in ipairs(w.landed) do if l.final and l.sid == nil then seen_nil = true end end
    check("  nil source id gets its own final", seen_nil)
end

-- nothing landed -> no final ------------------------------------------------------------------------------------------------------------------------------------------------------------------------
do
    local w = world()
    w.pool:enqueue(w.recs("A"), "s"); w.advance(0.03)
    w.finish(1, "nf:http_404"); w.advance(0.5)
    check("all failed: no landed events at all", #w.landed == 0)
    check("  chain ended", not w.pool:status().chain_active)
end

-- width resets at the end of a chain -----------------------------------------------------------------------------------------------------------------------------------------------------------------
do
    local w = world()
    w.pool:enqueue(w.recs("A"), "s"); w.advance(0.03)
    w.finish(1, "nf:http_500"); w.advance(0.5)
    check("chain over after a narrow", not w.pool:status().chain_active)
    check("  next chain starts at the configured width", w.pool:status().cap == 3)
end

-- decode failure: one more download, then give up ----------------------------------------------------------------------------------------------------------------------------------------------------------------
do
    local w = world()
    w.files["/c/A.jpg"] = true
    w.decode_ok["A"] = false
    w.pool:enqueue(w.recs("A", "B", "C"), "s")
    w.advance(0.2)
    check("bad disk file is re-downloaded once", spawn_count(w) == 3 and w.spawned[3] == "A", spawn_count(w))
    check("  a decode problem does not narrow the width", w.pool:status().cap == 3, w.pool:status().cap)
    w.finish(1, "1"); w.finish(2, "1")      -- B and C downloaded fine
    w.finish(3, "1")                        -- A re-downloaded, still undecodable
    w.advance(0.5)
    check("2nd decode failure gives up", #w.failed == 1 and w.failed[1].why == "decode", #w.failed)
    check("  the two good covers still decoded", #w.decoded == 2, #w.decoded)
end

-- throwing deps never break the pool --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
do
    local w = world({ decode_throws = true })
    w.files["/c/A.jpg"] = true
    w.pool:enqueue(w.recs("A"), "s")
    local ok = pcall(function() w.advance(1) end)
    check("decode throwing does not propagate", ok)
    local w2 = world({ landed_throws = true })
    w2.files["/c/A.jpg"] = true; w2.files["/c/B.jpg"] = true
    w2.pool:enqueue(w2.recs("A", "B"), "s")
    local ok2 = pcall(function() w2.advance(1) end)
    check("on_landed throwing does not propagate", ok2 and #w2.decoded == 2)
end

-- callbacks may re-enter the pool ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
do
    local w = world()
    w.files["/c/A.jpg"] = true; w.files["/c/B.jpg"] = true
    local reentered = 0
    w.on_landed_hook = function(sid, final)
        if reentered < 3 then
            reentered = reentered + 1
            w.pool:cancel()
            w.pool:enqueue(w.recs("A", "B", "N" .. reentered), "s")   -- like a repaint -> rebuild -> enqueue
        end
    end
    local ok = pcall(function() w.advance(3) end)
    check("re-entrant enqueue/cancel from on_landed is safe", ok)
    -- let every worker finish; the pool must then drain completely
    local ok2 = pcall(function()
        for round = 1, 10 do
            for pid, f in pairs(w.forks) do
                if not f.done then w.finish(pid, "1") end
            end
            w.advance(1)
        end
    end)
    check("  pool drains after the re-entrant storm", ok2 and not w.pool:status().chain_active
        and w.live_timers() == 0 and w.pool:status().pending == 0 and w.pool:status().in_flight == 0)
end

-- a final fired for a drained chain may start a new chain ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
do
    local w = world()
    w.files["/c/A.jpg"] = true
    local started = false
    w.on_landed_hook = function(sid, final)
        if final and not started then
            started = true
            w.pool:enqueue(w.recs("Q"), "s2")
        end
    end
    w.pool:enqueue(w.recs("A"), "s1")
    w.advance(0.5)
    w.advance(0.1)
    check("  and launches its worker", spawn_count(w) == 1 and w.spawned[1] == "Q", spawn_count(w))
end

-- resetFailures --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
do
    local w = world()
    w.pool:enqueue(w.recs("A"), "s"); w.advance(0.03)
    w.finish(1, "nf:http_404"); w.advance(0.3)
    w.pool:enqueue(w.recs("A"), "s"); w.advance(0.1)
    local n = spawn_count(w)
    check("given up before the reset", n == 1, n)
    w.pool:resetFailures()
    w.pool:enqueue(w.recs("A"), "s"); w.advance(0.1)
    check("allowed again after resetFailures", spawn_count(w) == 2, spawn_count(w))
end

-- poll timer is single, no timer pile-up ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
do
    local w = world()
    for _ = 1, 10 do w.pool:enqueue(w.recs("A", "B"), "s") end
    check("repeated enqueue keeps a single poll timer", w.live_timers() == 1, w.live_timers())
end

-- status shape --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
do
    local w = world()
    local st = w.pool:status()
    check("status fields", st.pending == 0 and st.in_flight == 0 and st.decode == 0
        and st.reaping == 0 and st.cap == 3 and st.landed == 0 and st.fork_broken == false
        and st.chain_active == false)
end


-- on_worker timing hook (C22, log only) ------------------------------------------------------
do
    local w = world()
    local seen = {}
    w.deps.on_worker = function(info) seen[#seen + 1] = info end
    w.pool = Pool.new(w.deps)
    w.pool:enqueue(w.recs(1, 2, 3, 4), "s")
    w.advance(0.1)
    check("on_worker: 3 workers running", spawn_count(w) == 3, spawn_count(w))
    w.advance(2)
    w.finish(1, "1")
    w.finish(2, "nf:http_404")
    w.advance(0.2)
    w.finish(3, "")   -- finished with nothing written: a crash
    w.advance(0.5)
    local by = {}
    for _, i in ipairs(seen) do by[i.key] = i end
    check("on_worker ok", by[1] and by[1].result == "ok", by[1] and by[1].result)
    check("on_worker nf", by[2] and by[2].result == "nf:http_404", by[2] and by[2].result)
    check("on_worker crash", by[3] and by[3].result == "crash", by[3] and by[3].result)
    check("on_worker ms is spawn to result", by[1] and by[1].ms >= 2000 and by[1].ms < 2500, by[1] and by[1].ms)
    -- timeout
    w.advance(40)
    local to
    for _, i in ipairs(seen) do if i.result == "timeout" then to = i end end
    check("on_worker timeout reported", to ~= nil)
    -- a throwing hook changes nothing
    local w2 = world()
    w2.deps.on_worker = function() error("hook boom") end
    w2.pool = Pool.new(w2.deps)
    w2.pool:enqueue(w2.recs(1), "s")
    w2.advance(0.1)
    w2.finish(1, "1")
    w2.advance(1)
    check("throwing on_worker does not break the chain", #w2.decoded == 1 and w2.finals() == 1, #w2.decoded)
end


-- on_idle (prefetch P1): fires once when a chain drains, even if nothing landed ------------------------------------------------------------------------------------
do
    local w = world()
    w.pool:enqueue(w.recs("A", "B"), "s")
    check("on_idle: not fired inside enqueue", #w.idle == 0)
    w.advance(0.03)
    w.finish(1, "1")
    w.advance(0.2)
    check("on_idle: not fired while work remains", #w.idle == 0, #w.idle)
    w.finish(2, "1")
    w.advance(1)
    check("on_idle: fired once after the drain", #w.idle == 1, #w.idle)
    check("  had_landed true when covers landed", w.idle[1] == true)
    local last = w.landed[#w.landed]
    check("  after the final on_landed (final callback came first)", last and last.final == true)
    w.advance(5)
    check("  never fires twice for one chain", #w.idle == 1)
    check("  chain over, no timers left", not w.pool:status().chain_active and w.live_timers() == 0)
end

do -- everything given up: no on_landed final, but on_idle(false)
    local w = world()
    w.pool:enqueue(w.recs("A"), "s")
    w.advance(0.03)
    w.finish(1, "nf:http_404")
    w.advance(1)
    check("on_idle: all given up -> fired with false", #w.idle == 1 and w.idle[1] == false, #w.idle)
    check("  no final on_landed (nothing landed)", w.finals() == 0)
end

do -- offline drop
    local w = world()
    w.online = false
    w.pool:enqueue(w.recs("A", "B"), "s")
    w.advance(0.5)
    check("on_idle: offline drop -> fired with false", #w.idle == 1 and w.idle[1] == false, #w.idle)
    check("  nothing spawned while offline", spawn_count(w) == 0)
end

do -- worker says offline
    local w = world()
    w.pool:enqueue(w.recs("A"), "s")
    w.advance(0.03)
    w.finish(1, "nf:offline")
    w.advance(1)
    check("on_idle: nf:offline drain -> fired with false", #w.idle == 1 and w.idle[1] == false, #w.idle)
end

do -- cancel with nothing in flight ends the chain from a timer
    local w = world()
    w.pool:enqueue(w.recs("A", "B"), "s")
    w.pool:cancel()
    check("on_idle: not fired inside cancel", #w.idle == 0)
    w.advance(0.5)
    check("  fired later from the poll timer", #w.idle == 1 and w.idle[1] == false, #w.idle)
end

do -- shutdown is silent
    local w = world()
    w.pool:enqueue(w.recs("A", "B"), "s")
    w.advance(0.03)
    w.pool:shutdown()
    w.advance(5)
    check("on_idle: shutdown never fires it", #w.idle == 0, #w.idle)
end

do -- a plain empty enqueue (no chain) does not fire it
    local w = world()
    check("on_idle: empty enqueue", w.pool:enqueue({}, "s") == "empty")
    w.advance(2)
    check("  no chain -> no on_idle", #w.idle == 0)
end

do -- on_idle may enqueue again; throwing on_idle changes nothing; absent dep is fine
    local w = world()
    local again = 0
    w.on_idle_hook = function()
        if again < 1 then again = again + 1; w.pool:enqueue(w.recs("Z"), "s") end
    end
    w.pool:enqueue(w.recs("A"), "s")
    w.advance(0.03); w.finish(1, "1"); w.advance(0.5)
    check("on_idle: re-enqueue starts a new chain", #w.idle == 1 and w.pool:status().chain_active)
    w.advance(0.03); w.finish(2, "1"); w.advance(1)
    check("  second chain drains and fires again", #w.idle == 2 and not w.pool:status().chain_active, #w.idle)

    local w2 = world({ idle_throws = true })
    w2.pool:enqueue(w2.recs("A"), "s")
    w2.advance(0.03); w2.finish(1, "1"); w2.advance(1)
    check("on_idle throwing does not propagate or wedge the pool", #w2.idle == 1 and not w2.pool:status().chain_active)
    w2.pool:enqueue(w2.recs("B"), "s"); w2.advance(0.03); w2.finish(2, "1"); w2.advance(1)
    check("  and the pool still works afterwards", #w2.decoded == 2 and #w2.idle == 2)

    local w3 = world({ no_idle = true })
    w3.pool:enqueue(w3.recs("A"), "s")
    w3.advance(0.03); w3.finish(1, "1"); w3.advance(1)
    check("absent on_idle: unchanged behaviour", #w3.decoded == 1 and w3.finals() == 1 and not w3.pool:status().chain_active)
end

do -- on_idle after a decode failure that is given up on the 2nd try
    local w = world()
    w.decode_ok["A"] = false
    w.pool:enqueue(w.recs("A"), "s")
    for _ = 1, 4 do
        w.advance(0.03)
        for pid, f in pairs(w.forks) do if not f.done then w.finish(pid, "1") end end
        w.advance(0.5)
    end
    w.advance(2)
    check("on_idle: decode give-up drain -> fired once with false", #w.idle == 1 and w.idle[1] == false, #w.idle)
end

-- cancelDecode (decode-ahead, D1): queued decodes only, no callbacks --------------------------------------------------------------------------------------
do -- disk hits queued, nothing decoded yet: the queue empties, the chain still ends from a timer
    local w = world()
    w.files["/c/A.jpg"], w.files["/c/B.jpg"], w.files["/c/C.jpg"] = true, true, true
    w.pool:enqueue(w.recs("A", "B", "C"), "s")
    check("cancelDecode: three disk hits are queued for decode", w.pool:status().decode == 3)
    local l0, i0 = #w.landed, #w.idle
    w.pool:cancelDecode()
    check("cancelDecode: queue emptied", w.pool:status().decode == 0)
    check("cancelDecode: no callback inside the call", #w.landed == l0 and #w.idle == i0)
    check("cancelDecode: the decode timer is gone, the poll timer keeps the chain", w.live_timers() == 1, w.live_timers())
    w.advance(1)
    check("cancelDecode: nothing was decoded", #w.decoded == 0)
    check("cancelDecode: chain still ends -> one on_idle(false), no landed", #w.idle == 1 and w.idle[1] == false and #w.landed == 0)
    check("cancelDecode: chain inactive afterwards", not w.pool:status().chain_active)
end

do -- a decode already done stays done; the rest is dropped; the dropped keys can be enqueued again
    local w = world()
    for _, id in ipairs({ "A", "B", "C" }) do w.files["/c/" .. id .. ".jpg"] = true end
    w.pool:enqueue(w.recs("A", "B", "C"), "s")
    w.advance(0.025)
    check("cancelDecode: one decode landed before the cancel", #w.decoded == 1 and w.decoded[1] == "A")
    local l0 = #w.landed
    w.pool:cancelDecode()
    check("cancelDecode: no callback inside (mid-chain)", #w.landed == l0)
    check("cancelDecode: the rest of the queue is gone", w.pool:status().decode == 0)
    w.advance(1)
    check("cancelDecode: B and C never decode", #w.decoded == 1)
    check("cancelDecode: the chain ends with the final for what did land", w.finals() == 1 and #w.idle == 1 and w.idle[1] == true)
    w.pool:enqueue(w.recs("B", "C"), "s"); w.advance(1)
    check("cancelDecode: a dropped key can be enqueued and decoded again", #w.decoded == 3 and w.decoded[2] == "B" and w.decoded[3] == "C")
end

do -- pending downloads and in-flight workers are not touched
    local w = world({ width = 1 })
    w.files["/c/D1.jpg"], w.files["/c/D2.jpg"] = true, true
    w.pool:enqueue(w.recs("A", "B", "D1", "D2"), "s")
    w.advance(0.021)
    check("cancelDecode setup: A in flight, B pending, D1 decoded, D2 queued",
        spawn_count(w) == 1 and w.pool:status().in_flight == 1 and w.pool:status().pending == 1
        and #w.decoded == 1 and w.pool:status().decode == 1)
    w.pool:cancelDecode()
    local st = w.pool:status()
    check("cancelDecode: in-flight and pending untouched", st.in_flight == 1 and st.pending == 1 and st.decode == 0)
    check("cancelDecode: no kill, no remove", #w.kills == 0 and #w.removed == 0)
    w.finish(1, "1"); w.advance(0.5)
    w.finish(2, "1"); w.advance(1)
    local got = {}
    for _, k in ipairs(w.decoded) do got[k] = true end
    check("cancelDecode: the in-flight and the pending download still land and decode", got.A and got.B)
    check("cancelDecode: the cancelled disk hit D2 never decodes", not got.D2 and got.D1)
    check("cancelDecode: chain ends", not w.pool:status().chain_active and #w.idle == 1)
end

do -- idle pool: harmless, leaves no timer behind
    local w = world()
    w.pool:cancelDecode()
    check("cancelDecode on an idle pool: no timers, no callbacks", w.live_timers() == 0 and #w.landed == 0 and #w.idle == 0)
    w.pool:cancelDecode()
    check("cancelDecode twice: still nothing", w.live_timers() == 0)
end

do -- called from inside on_landed (re-entrancy), as the source's cancel_covers can be
    local w = world()
    for _, id in ipairs({ "A", "B", "C" }) do w.files["/c/" .. id .. ".jpg"] = true end
    w.on_landed_hook = function(_, final) if not final then w.pool:cancelDecode() end end
    w.pool:enqueue(w.recs("A", "B", "C"), "s")
    local ok = pcall(function() w.advance(1) end)
    check("cancelDecode from on_landed is safe: only the first decode landed", ok and #w.decoded == 1)
    check("cancelDecode from on_landed: chain ended", not w.pool:status().chain_active)
end


-- E1: third on_landed argument = decode jobs still queued -------------------------------------
do -- three disk hits: 2, 1 left, then the final callback gets 0
    local w = world()
    for _, id in ipairs({ "A", "B", "C" }) do w.files["/c/" .. id .. ".jpg"] = true end
    w.pool:enqueue(w.recs("A", "B", "C"), "s")
    w.advance(1)
    local nonfinal = {}
    for _, l in ipairs(w.landed) do if not l.final then nonfinal[#nonfinal + 1] = l.left end end
    check("decode_left: two non-final landings", #nonfinal == 2, #nonfinal)
    check("decode_left counts the decode queue after the decode (2 then 1)", nonfinal[1] == 2 and nonfinal[2] == 1, tostring(nonfinal[1]) .. "," .. tostring(nonfinal[2]))
    local last = w.landed[#w.landed]
    check("decode_left: final callback gets 0", last.final == true and last.left == 0, tostring(last.left))
end
do -- a download still in flight does NOT count as decode work left
    local w = world()
    w.files["/c/A.jpg"] = true
    w.pool:enqueue(w.recs("A", "B"), "s")      -- A on disk (decode), B needs a download
    w.advance(0.1)
    local first
    for _, l in ipairs(w.landed) do if not l.final then first = l; break end end
    check("decode_left: queue drained while a download is in flight -> 0", first ~= nil and first.left == 0, first and first.left)
    check("... and the download really is still in flight", w.pool:status().in_flight == 1)
end
do -- a pending (not yet launched) download does not count either
    local w = world{ width = 1 }
    w.files["/c/A.jpg"] = true
    w.pool:enqueue(w.recs("A", "B", "C"), "s")
    w.advance(0.1)
    local first
    for _, l in ipairs(w.landed) do if not l.final then first = l; break end end
    check("decode_left: pending downloads are not counted", first ~= nil and first.left == 0, first and first.left)
end
do -- two-argument callbacks still work (the argument is just ignored)
    local w = world()
    w.files["/c/A.jpg"] = true; w.files["/c/B.jpg"] = true
    w.deps.on_landed = function(sid, final) w.landed[#w.landed + 1] = { sid = sid, final = final } end
    w.pool = Pool.new(w.deps)
    w.pool:enqueue(w.recs("A", "B"), "s")
    w.advance(1)
    check("old two-argument on_landed still called (1 non-final + 1 final)", #w.landed == 2 and w.finals() == 1, #w.landed)
end

print(string.format("test_bo_coverpool: %d passed, %d failed", passes, fails))
return fails > 0
