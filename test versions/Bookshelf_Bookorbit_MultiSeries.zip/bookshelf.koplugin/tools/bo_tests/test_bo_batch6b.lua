-- Batch 6b: the five data-driven Decor specs (Pages turned, Glyph of the day,
-- Tree rings, Next badge, Gathering dust) and the dust actions. (Chapter line
-- was dropped in Batch 7 by the user's decision.)
-- The data side (samples, live dust state, file removal) is in test_bo_data.lua
-- section M. KOReader is stubbed; nothing here draws.
package.path = PLUGIN .. "/?.lua;" .. package.path
local fails, passes = 0, 0
local function check(n, c, x) if c then passes = passes + 1 else fails = fails + 1; print("FAIL: " .. n .. (x and (" -> " .. tostring(x)) or "")) end end

package.preload["logger"] = function() return { warn = function() end, info = function() end, dbg = function() end } end
package.preload["lib/bookshelf_i18n"] = function() return { gettext = function(s) return s end } end

-- ---- adapter-level stubs (specs) ---------------------------------------------------
package.preload["lib/bookshelf_module_kit"] = function() return { CARD_BG = "bg", COLOR_MUTED = "muted",
    fitText = function(o) return { kind = "text", text = o.text, width = o.width } end } end
local seen, drawn, drawn_props = {}, {}, {}
local d_state = { not_configured = true, fingerprint = "f" }
package.preload["lib/bookshelf_bo_data"] = function() return {
    get = function(opts) seen = opts; return d_state end,
    fileRemoved = function(path) _G.__removed = (_G.__removed or {}); table.insert(_G.__removed, path) end,
    invalidate = function() end } end
package.preload["lib/bookshelf_bo_actions"] = function() return { defaultFor = function(t) return { kind = "default", t = t } end,
    run = function() end } end
local hits_out = {}
package.preload["ffi/blitbuffer"] = function() return { new = function() return { fill = function() end, free = function() end } end, TYPE_BB8 = 1, COLOR_WHITE = 0 } end
package.preload["lib/bookorbit_board/ui"] = function() return { surface = nil, pickScope = function() end,
    collectHits = function(fn) local r = fn() return r, hits_out end,
    overlay = function(w, h) return { kind = "overlay", w = w, h = h, paintTo = function()
        for i, a in ipairs(hits_out) do a.dimen = a.dimen or { x = 10 * i, y = 5, w = 20, h = 20 } end end } end,
    box = function() return {} end } end
package.preload["lib/bookorbit_board/metrics"] = function() return { INK = { black = "k", white = "w" }, px = function(x) return x end } end
package.preload["lib/bookorbit_board/widgets"] = function()
    local Wt = setmetatable({}, { __index = function(_t, ty) return function(_ctx, _w, _h, props) table.insert(drawn, ty); drawn_props[#drawn] = props; return { kind = "content" } end end })
    return { W = Wt } end

local specs = dofile(PLUGIN .. "/micromodules/bookorbit_decor.lua")
local by = {}
for _i, sp in ipairs(specs) do by[sp.key] = sp end
local SIX = { "bookorbit_odometer", "bookorbit_glyph", "bookorbit_rings", "bookorbit_badge", "bookorbit_dust" }

check("P1 16 decor specs in all (11 + 5)", #specs == 16, #specs)
local missing
for _i, k in ipairs(SIX) do if not by[k] then missing = k end end
check("P2 the five planned keys exist", missing == nil, missing)
local nonbuddy = 0
for _i, sp in ipairs(specs) do if not sp.key:match("^bookorbit_buddy_") then nonbuddy = nonbuddy + 1 end end
check("P3 9 buddies + 7 other decor widgets", nonbuddy == 7, nonbuddy)
check("P3b Chapter line is not shipped", by.bookorbit_chapters == nil)

local meta_ok = true
for _i, k in ipairs(SIX) do
    local sp = by[k]
    if not sp or sp.category ~= "bookorbit:decor" or sp.is_new ~= true or type(sp.render) ~= "function" then meta_ok = false end
end
check("P4 all five: decor category, New chip, render", meta_ok)

-- taps only where BookOrbit has them
check("P5 only Gathering dust is tappable", by.bookorbit_dust.on_tap
    and not by.bookorbit_odometer.on_tap and not by.bookorbit_glyph.on_tap and not by.bookorbit_rings.on_tap and not by.bookorbit_badge.on_tap)

-- server flag: offline widgets draw when unconfigured, server widgets show the hint
local function renders(k) d_state = { not_configured = true, fingerprint = "f" }; drawn = {}
    return by[k].render{ width = 200, height = 120 } end
check("P6 Pages turned and Glyph draw without BookOrbit", renders("bookorbit_odometer").kind == "overlay" and renders("bookorbit_glyph").kind == "overlay")
local hints = true
for _i, k in ipairs{ "bookorbit_rings", "bookorbit_badge", "bookorbit_dust" } do
    local w = renders(k)
    if not (w.kind == "text" and w.text:find("Set up your BookOrbit server")) then hints = false end
end
check("P7 Tree rings, Next badge, Gathering dust show the set-up hint", hints)

-- each widget type is one decor.lua really defines (read from the source, not stubbed)
local f = io.open(PLUGIN .. "/lib/bookorbit_board/decor.lua"); local src = f:read("a"); f:close()
local list = src:match("Decor%.TYPES%s*=%s*(%b{})") or ""
local types_ok = true
for _i, k in ipairs(SIX) do
    local ty = k:gsub("^bookorbit_", "")
    if not list:find('"' .. ty .. '"', 1, true) then types_ok = false end
end
check("P8 every spec type is in Decor.TYPES", types_ok, list)

-- preview renders and tells the data layer
local prev_ok = true
for _i, k in ipairs(SIX) do
    d_state = { fingerprint = "f", preview = true }; seen = {}
    local ok = pcall(by[k].render, { width = 200, height = 120, preview = true })
    if not ok or seen.preview ~= true then prev_ok = false end
end
check("P9 all five render in preview", prev_ok)

-- what each asks the data layer to fetch
local function needs(k) d_state = { fingerprint = "f" }; seen = {}; by[k].render{ width = 200, height = 120 }; return seen.needs end
local dn = needs("bookorbit_dust")
check("P10 Gathering dust asks for the unopened shelf", dn and dn.shelves and dn.shelves[1] and dn.shelves[1].source == "unopened")
local none = true
for _i, k in ipairs{ "bookorbit_odometer", "bookorbit_glyph", "bookorbit_rings", "bookorbit_badge" } do
    local n = needs(k)
    if n and ((n.shelves and #n.shelves > 0) or (n.names and #n.names > 0)) then none = false end
end
check("P11 the other four fetch no extra shelves or lists", none)

-- Dust: region keep_open (next stays on the card; trash and Open close the menu)
d_state = { fingerprint = "fp-dust", dust = { book = { id = 5 } } }
hits_out = { { action = { kind = "book", book = { id = 5 }, resume = true } },
             { action = { kind = "dust-remove", book = { id = 5 } } },
             { action = { kind = "dust-next" } } }
local regions
local entry = { id = "e1" }          -- per-card state is keyed by this very table
by.bookorbit_dust.render{ width = 300, height = 200, entry = entry, set_tap_regions = function(r) regions = r end }
check("Q1 three tap regions (Open, trash, next)", regions and #regions == 3, regions and #regions)
-- topmost (last built) first: h1 = next, h2 = trash, h3 = Open
local function keep(id) return by.bookorbit_dust.keep_open({ entry = entry, tapped_region = id }) end
check("Q2 'next' keeps the menu open", keep("h1") == true)
check("Q3 trash closes the menu first (it opens a dialog)", keep("h2") == false)
check("Q4 Open closes the menu", keep("h3") == false)

-- ---- the real actions ---------------------------------------------------------------
package.preload["lib/bookshelf_bo_actions"] = nil
package.loaded["lib/bookshelf_bo_actions"] = nil
local shown = {}
package.preload["ui/uimanager"] = function() return { show = function(_, w) table.insert(shown, w) end } end
package.preload["ui/widget/infomessage"] = function() return { new = function(_, o) o.kind = "info" return o end } end
local store = {}
package.preload["lib/bookshelf_bookorbit"] = function() return {
    dustState = function() return store.state or {} end,
    setDustState = function(s) store.state = s; store.sets = (store.sets or 0) + 1 end } end
local downloaded, files = { ["5"] = "/books/dusty.epub" }, { ["/books/dusty.epub"] = true }
package.preload["lib/bookshelf_bookorbit_source"] = function() return {
    downloadedMap = function() return downloaded end,
    toRecord = function(b) return { id = b.id } end } end
package.preload["libs/libkoreader-lfs"] = function() return { attributes = function(p, what)
    if files[p] then return what == "mode" and "file" or 1 end end } end
local fm_instance
local fm_calls = {}
package.preload["apps/filemanager/filemanager"] = function() return setmetatable({}, { __index = function(_t, k)
    if k == "instance" then return fm_instance end end }) end
local A = require("lib/bookshelf_bo_actions")
local function toasts() local t = {} for _i, w in ipairs(shown) do if w.kind == "info" then t[#t + 1] = w.text end end return t end

-- dust-next
local refreshed = 0
local env = { refresh = function() refreshed = refreshed + 1 end }
local today = os.date("%Y-%m-%d")
A.run({ kind = "dust-next" }, {}, env)
check("R1 dust-next stores today with skip 1 and repaints", store.state and store.state.day == today and store.state.skip == 1 and refreshed == 1,
    store.state and (tostring(store.state.day) .. "/" .. tostring(store.state.skip)))
A.run({ kind = "dust-next" }, {}, env)
check("R2 a second tap the same day makes it 2", store.state.skip == 2 and refreshed == 2)
store.state = { day = "2001-01-01", skip = 9 }
A.run({ kind = "dust-next" }, {}, env)
check("R3 a stale day starts over at 1", store.state.day == today and store.state.skip == 1)
local ctx_refresh = 0
A.run({ kind = "dust-next" }, { refresh = function() ctx_refresh = ctx_refresh + 1 end }, nil)
check("R4 without env it repaints through ctx.refresh", ctx_refresh == 1 and store.state.skip == 2)

-- dust-remove
local book = { id = 5, title = "Dusty" }
fm_instance = { showDeleteFileDialog = function(_, path, cb) table.insert(fm_calls, { path = path, cb = cb }) end }
_G.__removed = nil; refreshed = 0
A.run({ kind = "dust-remove", book = book }, {}, env)
check("S1 asks KOReader to delete the book's file", #fm_calls == 1 and fm_calls[1].path == "/books/dusty.epub")
check("S2 nothing is forgotten or repainted before the user confirms", _G.__removed == nil and refreshed == 0)
fm_calls[1].cb()
check("S3 after confirming: data layer told, card repainted", _G.__removed and _G.__removed[1] == "/books/dusty.epub" and refreshed == 1)

fm_instance = nil; fm_calls = {}; shown = {}; _G.__removed = nil
A.run({ kind = "dust-remove", book = book }, {}, env)
local t = toasts()
check("S4 no file manager (a book is open): says to open the file browser", #fm_calls == 0 and t[1] == "Open the file browser to remove this book." and _G.__removed == nil, t[1])

fm_instance = { showDeleteFileDialog = function(_, path, cb) table.insert(fm_calls, { path = path, cb = cb }) end }
files["/books/dusty.epub"] = nil; shown = {}; refreshed = 0
A.run({ kind = "dust-remove", book = book }, {}, env)
t = toasts()
check("S5 file already gone: no dialog, data layer told, repaint, toast", #fm_calls == 0 and _G.__removed and _G.__removed[1] == "/books/dusty.epub"
    and refreshed == 1 and t[1] == "This book is no longer on the device.", t[1])

local before = #fm_calls
A.run({ kind = "dust-remove" }, {}, env)
A.run({ kind = "dust-remove", book = {} }, {}, env)
A.run({ kind = "dust-remove", book = { id = 999 } }, {}, env)   -- not downloaded at all
check("S6 no book / unknown book never opens a dialog", #fm_calls == before)

-- default tap
local dd = A.defaultFor("dust", { dust = { book = { id = 5, title = "Dusty" } } }, nil)
check("T1 whole-card tap on Gathering dust opens the book's details", dd and dd.kind == "detail" and dd.book_id == 5)
check("T2 nothing to open when there is no dusty book", A.defaultFor("dust", { dust = { count = 0 } }, nil) == nil and A.defaultFor("dust", {}, nil) == nil)
local lead = { id = 7 }
local cd = A.defaultFor("forecast", { continue_reading = { lead } }, nil)
check("T3 Forecast tap resumes the lead book", cd and cd.kind == "book" and cd.book == lead and cd.resume == true)
check("T4 Chapter line has no tap action any more", A.defaultFor("chapters", { continue_reading = { lead } }, nil) == nil)

-- ---- strings in the .pot --------------------------------------------------------------
local pf = io.open(PLUGIN .. "/locale/bookshelf.pot"); local pot = pf:read("a"); pf:close()
local pot_ok, pot_miss = true, nil
for _i, k in ipairs(SIX) do
    for _j, field in ipairs{ by[k].title, by[k].summary } do
        if not pot:find('msgid "' .. field:gsub("%p", "%%%0") .. '"') then pot_ok = false; pot_miss = field end
    end
end
for _i, s in ipairs{ "Open the file browser to remove this book.", "This book is no longer on the device." } do
    if not pot:find('msgid "' .. s:gsub("%p", "%%%0") .. '"') then pot_ok = false; pot_miss = s end
end
check("U1 every new title, summary and toast is in locale/bookshelf.pot", pot_ok, pot_miss)

print(string.format("RESULT: %d passed, %d failed", passes, fails))
return fails > 0
