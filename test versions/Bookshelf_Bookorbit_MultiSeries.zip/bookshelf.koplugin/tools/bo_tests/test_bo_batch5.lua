-- Batch 5: Library + Device actions, per-instance state, configurable shelf,
-- the 16 new specs. Same harness as the other tests (KOReader stubbed).
package.path = PLUGIN .. "/?.lua;" .. package.path
local fails, passes = 0, 0
local function check(n, c, x) if c then passes = passes + 1 else fails = fails + 1; print("FAIL: " .. n .. (x and (" -> " .. tostring(x)) or "")) end end

package.preload["logger"] = function() return { warn = function() end, info = function() end, dbg = function() end } end
package.preload["lib/bookshelf_i18n"] = function() return { gettext = function(s) return s end } end
local shown, broadcasts = {}, {}
package.preload["ui/uimanager"] = function() return { show = function(_, w) table.insert(shown, w) end,
    broadcastEvent = function(_, e) table.insert(broadcasts, e.name) end } end
package.preload["ui/event"] = function() return { new = function(_, name) return { name = name } end } end
package.preload["ui/widget/infomessage"] = function() return { new = function(_, o) o.kind = "info" return o end } end

-- catalog stub with every entry point
local cat = {}
package.preload["lib/bookshelf_bookorbit_catalog"] = function() return {
    show = function() table.insert(cat, { "root" }) end,
    showBooks = function(p, t) table.insert(cat, { "books", p, t }) end,
    showSection = function(s, t) table.insert(cat, { "section", s, t }) end,
    search = function() table.insert(cat, { "search" }) end,
    showOnDevice = function() table.insert(cat, { "device" }) end } end
package.preload["lib/bookorbit_board/widgets"] = function() return { shelfTitle = function(p) return p.title or "Shelf" end } end

-- device + network
local light = { brightness = 40, warmth = 10 }
local powerd = { frontlightIntensity = function() return light.brightness end, frontlightWarmth = function() return light.warmth end,
    setIntensity = function(_, v) light.brightness = v end, setWarmth = function(_, v) light.warmth = v end }
local has_fl, has_nat = true, true
package.preload["device"] = function() return { hasFrontlight = function() return has_fl end, hasNaturalLight = function() return has_nat end,
    getPowerDevice = function() return powerd end } end
local wifi_on, wifi_calls = false, {}
package.preload["ui/network/manager"] = function() return {
    isWifiOn = function() return wifi_on end,
    toggleWifiOn = function(_, cb) wifi_on = true table.insert(wifi_calls, "on") cb() end,
    toggleWifiOff = function(_, cb) wifi_on = false table.insert(wifi_calls, "off") cb() end } end

-- BookOrbit client stub
local configured, reader_open = true, false
local rec, retried, synced_now, jobs = {}, 0, 0, {}
local root_ok = true
package.preload["lib/bookshelf_bookorbit"] = function() return {
    isConfigured = function() return configured end,
    SYNC_PRIORITY = { manual = 3 },
    withAutoWifi = function(fn) fn(function() end) end,
    submitSyncJob = function(o) table.insert(jobs, o) o.run() return "started" end,
    retryPendingSyncs = function() retried = retried + 1 end,
    catalogRoot = function() if root_ok then return { sections = {} } end return nil, "offline" end,
    recordSync = function(e) table.insert(rec, e) end,
    syncNow = function() synced_now = synced_now + 1 end } end
package.preload["apps/reader/readerui"] = function() return { instance = reader_open and { document = { file = "/b.epub" } } or nil } end
local inv = 0
package.preload["lib/bookshelf_bo_data"] = function() return { invalidate = function() inv = inv + 1 end, invalidateShelf = function() end } end

local A = require("lib/bookshelf_bo_actions")

-- ---- defaultFor
check("C1 recently-added shelf -> shelf action", A.defaultFor("shelf", {}, { source = "recently-added" }).kind == "shelf")
check("C2 want-to-read without params is not tappable", A.defaultFor("shelf", {}, { source = "want-to-read" }) == nil)
check("C2b want-to-read with a selector is", A.defaultFor("shelf", {}, { source = "want-to-read", params = { x = 1 } }) ~= nil)
check("C3 link default", A.defaultFor("link", {}, { link = "series" }).link == "series")
check("C4 sync online -> sync, offline -> wifi", A.defaultFor("sync", { online = true }).kind == "sync" and A.defaultFor("sync", { online = false }).kind == "wifi")
check("C5 finished shelf unchanged", A.defaultFor("shelf", {}, { source = "finished" }).kind == "books")

-- ---- links
local expect = { library = "books", series = "section", authors = "section", collections = "section", scopes = "section", device = "device", search = "search" }
for link, kind in pairs(expect) do
    cat = {}
    A.run({ kind = "link", link = link }, {})
    check("D1 link " .. link, cat[1] and cat[1][1] == kind, cat[1] and cat[1][1])
end
cat = {}
A.run({ kind = "link", link = "scopes" }, {})
check("D2 scopes -> smart-scopes section", cat[1][2] == "smart-scopes")
A.run({ kind = "link", link = "nonsense" }, {})
check("D3 unknown link ignored", #cat == 1)

-- ---- shelves
cat = {}
A.run({ kind = "shelf", source = "up-next-in-series", props = { source = "up-next-in-series" } }, {})
check("E1 up-next opens the series list", cat[1][1] == "section" and cat[1][2] == "series")
cat = {}
A.run({ kind = "shelf", source = "recently-added", props = { source = "recently-added" } }, {})
check("E2 recently-added list params", cat[1][1] == "books" and cat[1][2].sort == "recently_added")
cat = {}
A.run({ kind = "shelf", source = "pick-back-up", props = { source = "pick-back-up" } }, {})
check("E3 pick-back-up params", cat[1][2].readStatus == "reading" and cat[1][2].order == "asc")
cat = {}
A.run({ kind = "shelf", source = "libraries", props = { source = "libraries", params = { libraryId = 5, sort = "title" }, title = "Sci-fi" } }, {})
check("E4 selector shelf uses its own params + title", cat[1][2].libraryId == 5 and cat[1][3] == "Sci-fi")
cat = {}
A.run({ kind = "books", params = { readStatus = "reading" }, title = "In progress" }, {})
check("E5 books action opens that list now", cat[1][1] == "books" and cat[1][2].readStatus == "reading" and cat[1][3] == "In progress")

-- ---- light
A.run({ kind = "light", what = "brightness", delta = 5 }, {})
check("F1 brightness +5", light.brightness == 45)
A.run({ kind = "light", what = "brightness", delta = -100 }, {})
check("F2 brightness clamps at 0", light.brightness == 0)
A.run({ kind = "light", what = "brightness", delta = 500 }, {})
check("F2b clamps at 100", light.brightness == 100)
A.run({ kind = "light", what = "warmth", delta = -5 }, {})
check("F3 warmth steps", light.warmth == 5 and light.brightness == 100)
has_nat = false
A.run({ kind = "light", what = "warmth", delta = 5 }, {})
check("F4 no natural light: warmth step falls back to brightness (as BookOrbit)", light.warmth == 5 and light.brightness == 100)
has_fl = false
light.brightness = 50
A.run({ kind = "light", what = "brightness", delta = 5 }, {})
check("F5 no frontlight: nothing happens", light.brightness == 50)

-- ---- wifi / night / frontlight / rotate
local reloaded = 0
local ctx = { menu = { _reload = function() reloaded = reloaded + 1 end } }
A.run({ kind = "wifi" }, ctx)
check("G1 wifi on + card reloaded after", wifi_on and reloaded == 1)
A.run({ kind = "wifi" }, ctx)
check("G1b wifi off", not wifi_on and reloaded == 2)
A.run({ kind = "wifi" }, { refresh = function() reloaded = reloaded + 10 end })
check("G1c ctx.refresh preferred", reloaded == 12)
A.run({ kind = "night" }, {}); A.run({ kind = "frontlight" }, {}); A.run({ kind = "rotate" }, {})
check("G2 events broadcast", broadcasts[1] == "ToggleNightMode" and broadcasts[2] == "ShowFlDialog" and broadcasts[3] == "IterateRotation")

-- ---- sync
shown = {}
configured = false
A.run({ kind = "sync" }, {})
check("H1 not configured -> hint, no job", #jobs == 0 and shown[1] and shown[1].text:find("Set up your BookOrbit"))
configured, reader_open = true, true
package.loaded["apps/reader/readerui"] = nil
A.run({ kind = "sync" }, {})
check("H2 reader open -> existing syncNow", synced_now == 1 and #jobs == 0)
reader_open = false
package.loaded["apps/reader/readerui"] = nil
A.run({ kind = "sync" }, ctx)
check("H3 home screen: job retries the outbox + records the sync", #jobs == 1 and retried == 1 and rec[1] == "sync" and inv == 1)
check("H3b job is manual priority, own family", jobs[1].priority == 3 and jobs[1].family == "bo_board:sync")
root_ok = false
A.run({ kind = "sync" }, ctx)
check("H4 server unreachable -> not recorded", #rec == 1 and shown[#shown].text:find("failed"))
check("H5 throwing/garbage still contained", pcall(A.run, { kind = "light" }, nil) and pcall(A.run, { kind = "link" }, {}))

-- ---- adapter: per-instance slots, props_from, keep_open ----------------------
local texts = {}
package.preload["lib/bookshelf_module_kit"] = function() return { CARD_BG = "bg", COLOR_MUTED = "muted",
    fitText = function(o) table.insert(texts, o.text) return { kind = "text" } end } end
local seen_needs
local d_state = { fingerprint = "f" }
package.preload["lib/bookshelf_bo_data"] = function() return { get = function(o) seen_needs = o.needs return d_state end,
    invalidate = function() end, invalidateShelf = function() end } end
local hits_out = {}
local ui = { surface = nil, pickScope = function() end, collectHits = function(fn) return fn(), hits_out end,
    overlay = function(w, h) return { paintTo = function()
        for i, a in ipairs(hits_out) do a.dimen = a.dimen or { x = 10 * i, y = 5, w = 20, h = 20 } end end } end,
    box = function() return {} end }
package.preload["ffi/blitbuffer"] = function() return { new = function() return { fill = function() end, free = function() end } end, TYPE_BB8 = 1, COLOR_WHITE = 0 } end
package.preload["lib/bookorbit_board/ui"] = function() return ui end
package.preload["lib/bookorbit_board/metrics"] = function() return { INK = { black = "k", ge = "g", white = "w" }, px = function(x) return x end, setTextScale = function() end } end
local drawn_props, drawn_cw = {}, {}
package.preload["lib/bookorbit_board/widgets"] = function() return { shelfTitle = function(p) return p.title or "Shelf" end,
    W = { shelf = function(ctx, w, h, props, item) table.insert(drawn_props, props) table.insert(drawn_cw, item.cw) return {} end,
          light = function() return {} end } } end
-- replace the real actions with a recorder for the adapter part
local ran = {}
package.loaded["lib/bookshelf_bo_actions"] = nil
package.loaded["lib/bookshelf_bo_data"] = nil
package.loaded["lib/bookorbit_board/widgets"] = nil
package.loaded["lib/bookshelf_module_kit"] = nil
package.preload["lib/bookshelf_bo_actions"] = function() return {
    defaultFor = function(t, d, p) return { kind = "shelf", props = p } end,
    run = function(a, c, env) table.insert(ran, { a = a, env = env }) end } end
package.loaded["lib/bookshelf_bo_module"] = nil
local Bo = require("lib/bookshelf_bo_module")

local function cfgOf(t) return { get = function(_, k) return t[k] end } end
local spec = Bo.spec{ key = "k", type = "shelf", title = "Shelf from your library", sizes = { "XL", "L" },
    props = { source = "random" }, taps = true,
    props_from = function(c) local s = c:get("shelf") if type(s) == "table" then return { source = s.source, params = s.params, title = s.title } end end }
local entryA = { id = "a" }
local entryB = { id = "b" }
local regs = {}
local function ctxFor(entry, shelf, key)
    return { width = 300, height = 150, entry = entry, config = cfgOf({ shelf = shelf }), tapped_region = nil,
        set_tap_regions = function(r) regs[key] = r end }
end
hits_out = { { action = { kind = "detail", book_id = 1 } } }
spec.render(ctxFor(entryA, { source = "libraries", params = { libraryId = 5 }, title = "Sci-fi" }, "a"))
check("I1 props_from drives the drawn props", drawn_props[#drawn_props].source == "libraries" and drawn_props[#drawn_props].title == "Sci-fi")
check("I2 needs follow the configured source", seen_needs.shelves[1].source == "libraries" and seen_needs.shelves[1].params.libraryId == 5)
check("I3 XL shelf asks for the wide layout", drawn_cw[#drawn_cw] == 4)
spec.render(ctxFor(entryB, { source = "authors", params = { author = "x" }, title = "Le Guin" }, "b"))
spec.on_tap{ entry = entryA, tapped_region = "h1" }
spec.on_tap{ entry = entryB, tapped_region = "h1" }
check("I4 each card keeps its own props for its tap", ran[1].env.props.source == "libraries" and ran[2].env.props.source == "authors")
check("I5 unconfigured card falls back to the spec default", (function()
    spec.render({ width = 300, height = 150, entry = { id = "c" }, config = cfgOf({}), set_tap_regions = function() end })
    return drawn_props[#drawn_props].source == "random" end)())
check("I6 no entry (picker) still renders", pcall(spec.render, { width = 300, height = 150, preview = true }))
-- keep_open: in-place kinds
local light_spec = Bo.spec{ key = "l", type = "light", title = "Light", sizes = { "M" }, taps = true }
hits_out = { { action = { kind = "light", what = "brightness", delta = 5 } }, { action = { kind = "frontlight" } }, { action = { kind = "rotate" } }, { action = { kind = "wifi" } } }
light_spec.render({ width = 200, height = 100, entry = entryA, set_tap_regions = function() end })
-- regions are topmost-first: h1 = wifi, h2 = rotate, h3 = frontlight, h4 = light
local function keep(id) return light_spec.keep_open({ entry = entryA, tapped_region = id }) end
check("J1 wifi / light stay open", keep("h1") == true and keep("h4") == true)
check("J2 rotate / brightness dialog close the menu", keep("h2") == false and keep("h3") == false)
-- whole-card tap on Sync status: default action decides
local sync_spec = Bo.spec{ key = "s", type = "sync", title = "Sync", sizes = { "S" }, taps = true }
hits_out = {}
sync_spec.render({ width = 100, height = 100, entry = entryA, set_tap_regions = function() end })
check("J3 whole-card default consulted", sync_spec.keep_open({ entry = entryA }) == false)  -- stub default is "shelf"

-- ---- the real category files -------------------------------------------------
package.loaded["lib/bookshelf_bo_module"] = nil
package.loaded["lib/bookshelf_bo_actions"] = nil
local all, keys = {}, {}
for _i, f in ipairs{ "bookorbit_library", "bookorbit_device", "bookorbit_reading", "bookorbit_stats" } do
    local list = dofile(PLUGIN .. "/micromodules/" .. f .. ".lua")
    for _j, sp in ipairs(list) do all[#all + 1] = sp; keys[sp.key] = (keys[sp.key] or 0) + 1 end
end
local dupes = {}
for k, n in pairs(keys) do if n > 1 then dupes[#dupes + 1] = k end end
check("K1 no duplicate keys across the four files", #dupes == 0, table.concat(dupes, ","))
local lib = dofile(PLUGIN .. "/micromodules/bookorbit_library.lua")
local dev = dofile(PLUGIN .. "/micromodules/bookorbit_device.lua")
check("K2 library has 12 modules, device has 5", #lib == 12 and #dev == 5, #lib .. "/" .. #dev)
local cats_ok = true
for _i, sp in ipairs(lib) do if sp.category ~= "bookorbit:library" then cats_ok = false end end
for _i, sp in ipairs(dev) do if sp.category ~= "bookorbit:device" then cats_ok = false end end
check("K3 categories", cats_ok)
local by = {}
for _i, sp in ipairs(lib) do by[sp.key] = sp end
for _i, sp in ipairs(dev) do by[sp.key] = sp end
check("K4 only the library shelf is configurable", by.bookorbit_shelf_library.on_add and by.bookorbit_shelf_library.show_settings
    and not by.bookorbit_shelf_random.on_add)
check("K5 new chip: pick back up, want to read, light, toggles", by.bookorbit_shelf_pick_back_up.is_new and by.bookorbit_shelf_want_to_read.is_new
    and by.bookorbit_light.is_new and by.bookorbit_toggles.is_new and not by.bookorbit_sync.is_new and not by.bookorbit_link_device.is_new)
check("K6 every new module is tappable", (function()
    for _i, sp in ipairs(lib) do if not sp.on_tap then return false end end
    for _i, sp in ipairs(dev) do if sp.key ~= "bookorbit_clock" and not sp.on_tap then return false end end
    return true end)())
print(string.format("RESULT: %d passed, %d failed", passes, fails))
return fails > 0
