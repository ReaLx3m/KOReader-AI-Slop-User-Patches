package.path = PLUGIN .. "/?.lua;" .. package.path
local fails, passes = 0, 0
local function check(n, c, x) if c then passes = passes + 1 else fails = fails + 1; print("FAIL: " .. n .. (x and (" -> " .. tostring(x)) or "")) end end

package.preload["logger"] = function() return { warn = function() end, info = function() end, dbg = function() end } end
package.preload["lib/bookshelf_i18n"] = function() return { gettext = function(s) return s end } end
local texts = {}
package.preload["lib/bookshelf_module_kit"] = function() return {
    CARD_BG = "bg", COLOR_MUTED = "muted",
    fitText = function(o) table.insert(texts, o.text); return { kind = "text", text = o.text, width = o.width } end,
} end
local seen = {}
local drawn = {}
local d_state = { not_configured = true, fingerprint = "f" }
package.preload["lib/bookshelf_bo_data"] = function() return { get = function(opts) seen = opts; return d_state end } end
local hits_out = {}
local paints, boxes = 0, {}
local ui = { surface = nil, pickScope = function() end,
    collectHits = function(fn) local r = fn() return r, hits_out end,
    -- paintTo gives every hit area the position the real HitArea would record
    overlay = function(w, h, l) return { kind = "overlay", w = w, h = h, paintTo = function() paints = paints + 1
        for i, a in ipairs(hits_out) do a.dimen = a.dimen or { x = 10 * i, y = 5, w = 20, h = 20 } end end } end,
    box = function(o) table.insert(boxes, o) return {} end }
package.preload["ffi/blitbuffer"] = function() return { new = function() return { fill = function() end, free = function() end } end, TYPE_BB8 = 1, COLOR_WHITE = 0 } end
local ran = {}
package.preload["lib/bookshelf_bo_actions"] = function() return {
    defaultFor = function(t, d, p) return { kind = "default", t = t, props = p } end,
    run = function(a, ctx, env) table.insert(ran, { a = a, ctx = ctx, env = env }) end } end
package.preload["lib/bookorbit_board/ui"] = function() return ui end
package.preload["lib/bookorbit_board/metrics"] = function() return { INK = { black = "k", ge = "g", white = "w" }, px = function(x) return x end } end
package.preload["lib/bookorbit_board/widgets"] = function() return { W = { shelf = function(ctx, w, h) table.insert(drawn, ctx.d); return { kind = "content" } end } } end

local Bo = require("lib/bookshelf_bo_module")
local spec = Bo.spec{ key = "bookorbit_shelf_want_to_read", type = "shelf", title = "Want to read",
    category = "bookorbit:library", sizes = { "L", "XL" }, props = { source = "want-to-read" }, server = true }
local refresh = function() end
local w = spec.render{ width = 300, height = 200, refresh = refresh, scale = 100 }
check("M1 hint when not configured", w.kind == "text" and w.text:find("Set up your BookOrbit server"), w.text)
check("M2 data got refresh", seen.refresh == refresh)
check("M3 data got needs", seen.needs and seen.needs.shelves[1].source == "want-to-read")
check("M4 not a preview", seen.preview == false)
check("M5 nothing drawn", #drawn == 0)

d_state = { server_too_old = true, fingerprint = "f" }
w = spec.render{ width = 300, height = 200 }
check("M6 old-server hint", w.kind == "text" and w.text:find("newer BookOrbit server"), w.text)

d_state = { fingerprint = "f", loading = true }
w = spec.render{ width = 300, height = 200 }
check("M7 normal draw", w.kind == "overlay" and #drawn == 1)

-- a non-server spec draws even when unconfigured
local clock = Bo.spec{ key = "bookorbit_clock", type = "shelf", title = "x", sizes = { "S" } }
d_state = { not_configured = true, fingerprint = "f" }
w = clock.render{ width = 100, height = 100 }
check("M8 non-server spec ignores not_configured", w.kind == "overlay")

-- preview passes through
spec.render{ width = 300, height = 200, preview = true }
check("M9 preview flag forwarded", seen.preview == true)

-- ---- Batch 4: taps -------------------------------------------------------
local tapspec = Bo.spec{ key = "bookorbit_hero", type = "shelf", title = "Continue", sizes = { "W" }, taps = true }
check("T0 no taps -> no on_tap", spec.on_tap == nil)
check("T0b taps -> on_tap", type(tapspec.on_tap) == "function")
d_state = { fingerprint = "fp1" }
hits_out = { { action = { kind = "book", n = 1 } }, { action = { kind = "shuffle" } }, { action = nil } }
local got
local function ctxWith() return { width = 300, height = 100, set_tap_regions = function(r) got = r end } end
tapspec.render(ctxWith())
check("T1 two regions (area without action dropped)", got and #got == 2, got and #got)
check("T1b topmost (last built) first", got and got[1].id == "h1" and got[1].x == 20 and got[2].x == 10)
local before = paints
tapspec.render(ctxWith())
check("T4 same data+size paints no second time", paints == before)
d_state = { fingerprint = "fp2" }
tapspec.render(ctxWith())
check("T4b new data repaints", paints == before + 1)
got = nil
local pctx = ctxWith(); pctx.preview = true
tapspec.render(pctx)
check("T5 preview declares no regions", got == nil)
tapspec.on_tap({ tapped_region = "h2" })
check("T2 region tap runs that region's action", ran[#ran] and ran[#ran].a.kind == "book" and ran[#ran].a.n == 1, ran[#ran] and ran[#ran].a.kind)
tapspec.on_tap({})
check("T3 whole-card tap = default action", ran[#ran].a.kind == "default" and ran[#ran].a.t == "shelf")
check("T6 keep_open only for shuffle", tapspec.keep_open({ tapped_region = "h1" }) == true and tapspec.keep_open({ tapped_region = "h2" }) == false and tapspec.keep_open({}) == false)
-- dark host card: unframed widget gets a light panel
package.loaded["lib/bookshelf_module_kit"].CARD_BG = { getColor8 = function() return { a = 20 } end }
boxes = {}
tapspec.render(ctxWith())
check("T7 dark card -> light panel", boxes[1] and boxes[1].bg == "w" and boxes[1].radius == 10, boxes[1] and tostring(boxes[1].bg))
package.loaded["lib/bookshelf_module_kit"].CARD_BG = { getColor8 = function() return { a = 230 } end }
boxes = {}
tapspec.render(ctxWith())
check("T7b light card keeps the card colour", boxes[1] and boxes[1].radius == 0)
print(string.format("RESULT: %d passed, %d failed", passes, fails))
return fails
