-- Prefetch next page, Batch P1: pure state machine. Off-device; no KOReader, no
-- network, no forks (a fake world stands in for every dep). Proves the LOGIC
-- only (not run on a device). The state machine is NOT wired into the source yet.
package.path = PLUGIN .. "/?.lua;" .. package.path
local fails, passes = 0, 0
local function check(n, c, x)
    if c then passes = passes + 1
    else fails = fails + 1; print("FAIL: " .. n .. (x ~= nil and (" -> " .. tostring(x)) or "")) end
end

local Prefetch = require("lib/bookshelf_bookorbit_prefetch")

-- Fake world ------------------------------------------------------------------
local function world(opts)
    opts = opts or {}
    local w = {
        t = 0, timers = {}, online = true, settled = true,
        cache = {},              -- key -> records
        list_answer = "queued",  -- what request_list answers
        list_calls = {}, covers = {}, cancels = 0, logs = {},
        in_api = 0, cb_in_api = 0,
    }
    local function k(id, o, l) return Prefetch.keyOf(id, o, l) end
    w.k = k
    local deps = {
        schedule = function(delay, fn)
            local h = { at = w.t + delay, fn = fn, live = true }
            w.timers[#w.timers + 1] = h
            return h
        end,
        unschedule = function(h) if h then h.live = false end end,
        online = function() if opts.online_throws then error("boom") end return w.online end,
        settled = function() if opts.settled_throws then error("boom") end return w.settled end,
        cached = function(id, o, l) return w.cache[k(id, o, l)] ~= nil end,
        records = function(id, o, l) return w.cache[k(id, o, l)] end,
        request_list = function(id, o, l)
            if opts.list_throws then error("boom") end
            w.list_calls[#w.list_calls + 1] = k(id, o, l)
            return w.list_answer
        end,
        needs_cover = function(rec) if rec.boom then error("boom") end return rec.need == true end,
        enqueue_covers = function(recs, sid)
            if opts.enqueue_throws then error("boom") end
            w.covers[#w.covers + 1] = { recs = recs, sid = sid }
        end,
        cancel_covers = function() w.cancels = w.cancels + 1 end,
        settle_delay = opts.settle_delay, step_delay = opts.step_delay, done_max = opts.done_max,
        logger = { dbg = function(...) w.logs[#w.logs + 1] = table.concat({ ... }, " ") end },
    }
    if opts.no_logger then deps.logger = nil end
    for _, name in ipairs(opts.drop or {}) do deps[name] = nil end
    w.deps = deps
    w.p = Prefetch.new(deps)
    function w.advance(dt)
        local target = w.t + dt
        while true do
            local nxt
            for _, h in ipairs(w.timers) do
                if h.live and h.at <= target and (not nxt or h.at < nxt.at) then nxt = h end
            end
            if not nxt then break end
            w.t = math.max(w.t, nxt.at)
            nxt.live = false
            nxt.fn()
        end
        w.t = target
    end
    function w.live_timers()
        local n = 0
        for _, h in ipairs(w.timers) do if h.live then n = n + 1 end end
        return n
    end
    function w.put(id, o, l, recs) w.cache[k(id, o, l)] = recs end
    function w.recs(...)
        local list = {}
        for _, spec in ipairs({ ... }) do list[#list + 1] = { id = spec:sub(1, 1), need = spec:sub(2, 2) == "+" } end
        return list
    end
    return w
end

-- constants / key ---------------------------------------------------------------
check("default settle delay 1.0", Prefetch.DEFAULT_SETTLE_DELAY == 1.0)
check("default done max 64", Prefetch.DEFAULT_DONE_MAX == 64)
check("keyOf", Prefetch.keyOf("chip", 24, 24) == "chip:24:24")

-- invalid input -------------------------------------------------------------------
do
    local w = world()
    check("invalid: nil id", w.p:request(nil, 24, 24) == "invalid")
    check("invalid: empty id", w.p:request("", 24, 24) == "invalid")
    check("invalid: bad offset", w.p:request("c", "x", 24) == "invalid")
    check("invalid: negative offset", w.p:request("c", -1, 24) == "invalid")
    check("invalid: zero limit", w.p:request("c", 24, 0) == "invalid")
    check("invalid: nothing armed or scheduled", not w.p:status().armed and w.live_timers() == 0)
    local ok = pcall(function()
        w.p:request({}, {}, {}); w.p:request(true, 1, 1); w.p:notify(); w.p:onListReady(nil, nil); w.p:onListReady({}, true)
        w.p:supersede(); w.p:reset()
    end)
    check("garbage input never throws", ok)
    local ok2 = pcall(function() local p = Prefetch.new(); p:request("c", 0, 1); p:notify(); p:supersede(); p:reset(); p:status() end)
    check("no deps at all never throws", ok2)
end

-- happy path: cached next page -> straight to covers ----------------------------------------------------------
do
    local w = world()
    w.put("c", 24, 24, w.recs("A+", "B-", "C+"))
    check("request arms", w.p:request("c", 24, 24) == "armed")
    check("  armed and one timer", w.p:status().armed and w.live_timers() == 1)
    check("  nothing started inside request()", #w.covers == 0 and #w.list_calls == 0 and w.cancels == 0)
    w.advance(0.9)
    check("  nothing before the settle delay", #w.covers == 0)
    w.advance(0.2)
    check("covers queued after the delay", #w.covers == 1, #w.covers)
    check("  only the records that need a cover", #w.covers[1].recs == 2 and w.covers[1].recs[1].id == "A" and w.covers[1].recs[2].id == "C")
    check("  source id passed", w.covers[1].sid == "c")
    check("  no list request for a cached page", #w.list_calls == 0)
    check("  intent finished, key done", not w.p:status().armed and w.p:status().done == 1 and w.p:status().covers_key == "c:24:24")
    check("  no timers left", w.live_timers() == 0)
    check("  request again -> done, nothing re-queued", w.p:request("c", 24, 24) == "done")
    w.advance(5)
    check("  still one enqueue", #w.covers == 1 and w.cancels == 0)
end

-- not cached: list through the fetcher, then covers ------------------------------------------------------------
do
    local w = world()
    w.p:request("c", 24, 24)
    w.advance(1.1)
    check("list requested once after the delay", #w.list_calls == 1 and w.list_calls[1] == "c:24:24", #w.list_calls)
    check("  waiting for the list", w.p:status().listing and w.live_timers() == 0)
    check("  no covers yet", #w.covers == 0)
    check("  rebuild calls request again: still active, no second list request",
        w.p:request("c", 24, 24) == "active" and (w.advance(3) or true) and #w.list_calls == 1)
    w.put("c", 24, 24, w.recs("A+", "B+"))
    w.p:onListReady("c:24:24", true)
    check("  onListReady schedules, does not enqueue inside the call", #w.covers == 0 and w.live_timers() == 1)
    w.advance(0.1)
    check("covers queued after the list landed", #w.covers == 1 and #w.covers[1].recs == 2, #w.covers)
    check("  done", w.p:status().done == 1 and not w.p:status().armed)
end

-- idempotent request / timer not reset --------------------------------------------------------------------------
do
    local w = world()
    w.put("c", 24, 24, w.recs("A+"))
    w.p:request("c", 24, 24)
    w.advance(0.5)
    check("same key again -> active", w.p:request("c", 24, 24) == "active")
    check("  still one timer", w.live_timers() == 1)
    w.advance(0.55)
    check("  the ORIGINAL timer fired (not pushed back by request)", #w.covers == 1, #w.covers)
end

-- replace on a different key ----------------------------------------------------------------------------------
do
    local w = world()
    w.put("c", 24, 24, w.recs("A+"))
    w.put("c", 48, 24, w.recs("B+"))
    w.p:request("c", 24, 24)
    check("different key replaces", w.p:request("c", 48, 24) == "armed" and w.p:status().key == "c:48:24")
    check("  one timer only", w.live_timers() == 1)
    w.advance(1.1)
    check("  only the new page was prefetched", #w.covers == 1 and w.covers[1].recs[1].id == "B", #w.covers)
    -- the page after that: pending covers of the old page are cancelled
    local before = w.cancels
    w.put("c", 72, 24, w.recs("C+"))
    w.p:request("c", 72, 24)
    check("  moving on cancels the pending prefetch covers", w.cancels == before + 1, w.cancels)
    check("  covers_key cleared", w.p:status().covers_key == nil)
    -- a done key requested again while another intent is armed replaces the stale intent
    w.p:request("c", 48, 24)
    check("  requesting a done key drops the stale intent", not w.p:status().armed and w.live_timers() == 0)
    w.advance(5)
    check("  and nothing else ran", #w.covers == 1)
end

-- own covers are not cancelled by their own (done) key being requested again ---------------------------------------
do
    local w = world()
    w.put("c", 24, 24, w.recs("A+"))
    w.p:request("c", 24, 24); w.advance(1.1)
    check("own key again: no cancel", w.p:request("c", 24, 24) == "done" and w.cancels == 0)
end

-- already cached and covered -> done at once ----------------------------------------------------------------------
do
    local w = world()
    w.put("c", 24, 24, w.recs("A-", "B-"))
    check("cached with nothing to download -> done at once", w.p:request("c", 24, 24) == "done")
    check("  nothing armed, no timer", not w.p:status().armed and w.live_timers() == 0 and w.p:status().done == 1)
    local w2 = world()
    w2.put("c", 24, 24, w2.recs())
    check("cached empty page -> done", w2.p:request("c", 24, 24) == "done")
end

-- settled gating ------------------------------------------------------------------------------------------------------
do
    local w = world()
    w.settled = false
    w.put("c", 24, 24, w.recs("A+"))
    w.p:request("c", 24, 24)
    w.advance(1.1)
    check("not settled: nothing starts", #w.covers == 0 and #w.list_calls == 0)
    check("  no polling loop (no timer)", w.live_timers() == 0)
    w.advance(30)
    check("  still nothing after a long time", #w.covers == 0 and #w.list_calls == 0 and w.live_timers() == 0)
    check("  intent kept", w.p:status().armed)
    w.settled = true
    w.p:notify()
    check("  notify schedules, does not start inside", #w.covers == 0 and w.live_timers() == 1)
    w.advance(0.9)
    check("  nothing before the quiet delay", #w.covers == 0)
    w.advance(0.2)
    check("  started after notify + delay", #w.covers == 1)
end

do -- settled re-checked AT FIRE TIME (turned false between notify and the timer)
    local w = world()
    w.put("c", 24, 24, w.recs("A+"))
    w.p:request("c", 24, 24)
    w.advance(0.5)
    w.settled = false
    w.advance(1)
    check("settled false at fire time: not started", #w.covers == 0 and w.p:status().armed)
    w.settled = true
    w.p:notify(); w.advance(1.1)
    check("  started later", #w.covers == 1)
end

do -- notify pushes the timer back (last notify wins)
    local w = world()
    w.put("c", 24, 24, w.recs("A+"))
    w.p:request("c", 24, 24)
    w.advance(0.8)
    w.p:notify()
    w.advance(0.8)
    check("notify restarts the quiet delay", #w.covers == 0, #w.covers)
    check("  still one timer", w.live_timers() == 1)
    w.advance(0.3)
    check("  fires one delay after the last notify", #w.covers == 1)
end

do -- notify without an intent does nothing; request of a waiting intent re-checks
    local w = world()
    w.p:notify()
    check("notify without intent: no timer", w.live_timers() == 0)
    w.settled = false
    w.put("c", 24, 24, w.recs("A+"))
    w.p:request("c", 24, 24); w.advance(1.1)
    w.settled = true
    check("request of a waiting intent -> active", w.p:request("c", 24, 24) == "active" and w.live_timers() == 1)
    w.advance(1.1)
    check("  and it ran (a missed notify cannot strand it)", #w.covers == 1)
end

-- offline ----------------------------------------------------------------------------------------------------------------
do
    local w = world()
    w.put("c", 24, 24, w.recs("A+"))
    w.p:request("c", 24, 24)
    w.online = false
    w.advance(1.1)
    check("offline at fire time: nothing started, intent dropped", #w.covers == 0 and #w.list_calls == 0 and not w.p:status().armed)
    check("  not marked done (can arm again online)", w.p:status().done == 0)
    w.online = true
    check("  re-armable", w.p:request("c", 24, 24) == "armed")
    w.advance(1.1)
    check("  and then runs", #w.covers == 1)
    local w2 = world({ online_throws = true })
    w2.put("c", 24, 24, w2.recs("A+"))
    w2.p:request("c", 24, 24); w2.advance(2)
    check("online() throwing counts as offline", #w2.covers == 0 and not w2.p:status().armed)
end

do -- offline after the list was requested: onListReady ok, but then offline at step B
    local w = world()
    w.p:request("c", 24, 24); w.advance(1.1)
    w.put("c", 24, 24, w.recs("A+"))
    w.p:onListReady("c:24:24", true)
    w.online = false
    w.advance(0.1)
    check("offline at step B: no covers", #w.covers == 0 and not w.p:status().armed)
end

-- list request outcomes -----------------------------------------------------------------------------------------------
for _, ans in ipairs({ "queued", "joined" }) do
    local w = world()
    w.list_answer = ans
    w.p:request("c", 24, 24); w.advance(1.1)
    check("list " .. ans .. ": waits", w.p:status().armed and w.p:status().listing and #w.list_calls == 1)
end
for _, ans in ipairs({ "failed", "unavailable", "offline", "weird", false }) do
    local w = world()
    w.list_answer = ans
    w.p:request("c", 24, 24); w.advance(1.1)
    check("list " .. tostring(ans) .. ": intent dropped, key done", not w.p:status().armed and w.p:status().done == 1)
    w.advance(20); w.p:notify(); w.advance(5)
    check("  no retry storm", #w.list_calls == 1, #w.list_calls)
    check("  same page requested again -> done", w.p:request("c", 24, 24) == "done")
end
do
    local w = world()
    w.list_answer = "busy"
    w.p:request("c", 24, 24); w.advance(1.1)
    check("list busy: intent kept, not listing, no timer", w.p:status().armed and not w.p:status().listing and w.live_timers() == 0)
    w.advance(10)
    check("  no polling", #w.list_calls == 1)
    w.list_answer = "queued"
    w.p:notify(); w.advance(1.1)
    check("  next notify tries again", #w.list_calls == 2 and w.p:status().listing)
    local w2 = world({ list_throws = true })
    w2.p:request("c", 24, 24); w2.advance(1.1)
    check("request_list throwing -> dropped", not w2.p:status().armed and w2.p:status().done == 1)
end

-- onListReady -----------------------------------------------------------------------------------------------------------
do
    local w = world()
    w.p:request("c", 24, 24); w.advance(1.1)
    w.p:onListReady("c:48:24", true)
    check("onListReady for another key is ignored", w.p:status().armed and w.p:status().listing and w.live_timers() == 0)
    w.p:onListReady("c:24:24", false, "bad_body")
    check("onListReady failed -> dropped and done", not w.p:status().armed and w.p:status().done == 1)
    w.advance(5)
    check("  no covers", #w.covers == 0)
    -- ready arrives with no intent: ignored
    w.p:onListReady("c:24:24", true); w.advance(1)
    check("onListReady without intent is ignored", #w.covers == 0 and w.live_timers() == 0)
end
do
    local w = world()
    w.p:request("c", 24, 24); w.advance(1.1)
    w.p:onListReady("c:24:24", false, "offline")
    check("onListReady offline -> dropped, NOT done", not w.p:status().armed and w.p:status().done == 0)
    w.p:onListReady("c:24:24", false, "fork_broken")
end
do -- list landed ok but the page vanished from the cache
    local w = world()
    w.p:request("c", 24, 24); w.advance(1.1)
    w.p:onListReady("c:24:24", true)
    w.advance(0.1)
    -- cache miss at step B -> check() re-requests the list (joined) instead of giving up silently
    check("list ok but not cached: asks the fetcher again", #w.list_calls == 2, #w.list_calls)
end
do -- list landed, no cover needed
    local w = world()
    w.p:request("c", 24, 24); w.advance(1.1)
    w.put("c", 24, 24, w.recs("A-", "B-"))
    w.p:onListReady("c:24:24", true); w.advance(0.1)
    check("list landed, nothing to download -> done, no enqueue", #w.covers == 0 and w.p:status().done == 1 and w.p:status().covers_key == nil)
end
do -- onListReady ok but not settled at step B (a page turn started a cover chain)
    local w = world()
    w.p:request("c", 24, 24); w.advance(1.1)
    w.put("c", 24, 24, w.recs("A+"))
    w.p:onListReady("c:24:24", true)
    w.settled = false
    w.advance(0.1)
    check("step B waits when no longer settled", #w.covers == 0 and w.p:status().armed)
    w.settled = true
    w.p:notify(); w.advance(1.1)
    check("  and runs after the next notify", #w.covers == 1)
end

-- supersede -----------------------------------------------------------------------------------------------------------------
do
    local w = world()
    w.put("c", 24, 24, w.recs("A+"))
    w.p:request("c", 24, 24)
    w.advance(0.5)
    w.p:supersede()
    check("supersede drops the pending timer", w.live_timers() == 0)
    w.advance(5)
    check("  nothing ran", #w.covers == 0 and w.p:status().armed)
    w.p:notify(); w.advance(1.1)
    check("  intent survives and runs after the next notify", #w.covers == 1)
end
do -- supersede cancels pending prefetch covers
    local w = world()
    w.put("c", 24, 24, w.recs("A+"))
    w.p:request("c", 24, 24); w.advance(1.1)
    local before = w.cancels
    w.p:supersede()
    check("supersede cancels pending prefetch covers once", w.cancels == before + 1 and w.p:status().covers_key == nil)
    w.p:supersede()
    check("  second supersede: no extra cancel", w.cancels == before + 1)
end
do -- supersede while the list is in the fetcher: list may land; step B needs settled
    local w = world()
    w.p:request("c", 24, 24); w.advance(1.1)
    w.p:supersede()
    w.settled = false
    w.put("c", 24, 24, w.recs("A+"))
    w.p:onListReady("c:24:24", true); w.advance(0.2)
    check("supersede then list lands while not settled: no covers", #w.covers == 0)
    w.settled = true; w.p:notify(); w.advance(1.1)
    check("  covers after settling", #w.covers == 1)
end

-- reset -----------------------------------------------------------------------------------------------------------------------
do
    local w = world()
    w.put("c", 24, 24, w.recs("A+"))
    w.p:request("c", 24, 24); w.advance(1.1)
    check("reset: one done key", w.p:status().done == 1)
    local before = w.cancels
    w.p:reset()
    check("reset clears done keys, covers, timers", w.p:status().done == 0 and w.p:status().covers_key == nil and not w.p:status().armed)
    check("  cancels pending covers", w.cancels == before + 1)
    check("  the same page can be prefetched again", w.p:request("c", 24, 24) == "armed")
    w.advance(1.1)
    check("  and runs", #w.covers == 2)
    w.p:request("c", 48, 24); w.p:reset()
    check("reset drops an armed intent and its timer", not w.p:status().armed and w.live_timers() == 0)
    w.advance(5)
    check("  nothing fires after reset", #w.covers == 2)
end

-- done set cap (FIFO) --------------------------------------------------------------------------------------------------------------
do
    local w = world({ done_max = 3 })
    for i = 1, 5 do w.put("c", i * 10, 10, w.recs("A-")); w.p:request("c", i * 10, 10) end
    check("done set is capped", w.p:status().done == 3, w.p:status().done)
    check("  oldest forgotten (FIFO): page 1 can be looked at again -> done again (cached, nothing to do)",
        w.p:request("c", 10, 10) == "done")
    -- a forgotten key whose page needs covers can arm again
    local w2 = world({ done_max = 2 })
    w2.put("c", 10, 10, w2.recs("A+")); w2.put("c", 20, 10, w2.recs("A+")); w2.put("c", 30, 10, w2.recs("A+"))
    for _, o in ipairs({ 10, 20, 30 }) do w2.p:request("c", o, 10); w2.advance(1.1) end
    check("  3 prefetches ran", #w2.covers == 3)
    check("  key 10 was evicted from done: armed again", w2.p:request("c", 10, 10) == "armed")
    w2.advance(1.1)
    check("  key 30 is still done", w2.p:request("c", 30, 10) == "done")
end

-- callbacks only from timers ----------------------------------------------------------------------------------------------------------
do
    local w = world()
    w.put("c", 24, 24, w.recs("A+"))
    local seen = {}
    local function snap() return #w.covers + #w.list_calls end
    local s0 = snap()
    w.p:request("c", 24, 24); w.p:notify(); w.p:supersede(); w.p:notify(); w.p:onListReady("c:24:24", true); w.p:request("c", 24, 24)
    check("request/notify/supersede/onListReady never run effects inside the call", snap() == s0)
    w.p:reset()
    check("reset runs no list request or download", snap() == s0)
end

-- re-entrancy from the effects --------------------------------------------------------------------------------------------------------
do
    local w = world()
    w.put("c", 24, 24, w.recs("A+"))
    w.put("c", 48, 24, w.recs("B+"))
    local orig = w.deps.enqueue_covers
    local p
    w.deps.enqueue_covers = function(recs, sid)
        orig(recs, sid)
        p:request("c", 48, 24)       -- an effect calling back into the machine
        p:notify()
    end
    p = Prefetch.new(w.deps)
    p:request("c", 24, 24)
    local ok = pcall(function() w.advance(1.1); w.advance(1.1) end)
    check("an effect calling back into the machine is safe", ok)
    check("  both pages ended up prefetched once", #w.covers == 2, #w.covers)
end

-- throwing deps ---------------------------------------------------------------------------------------------------------------------------
do
    local w = world({ settled_throws = true })
    w.put("c", 24, 24, w.recs("A+"))
    w.p:request("c", 24, 24)
    local ok = pcall(function() w.advance(2) end)
    check("settled() throwing = not settled", ok and #w.covers == 0 and w.p:status().armed)
    local w2 = world({ enqueue_throws = true })
    w2.put("c", 24, 24, w2.recs("A+"))
    w2.p:request("c", 24, 24)
    local ok2 = pcall(function() w2.advance(2) end)
    check("enqueue_covers throwing does not propagate; page counted done", ok2 and w2.p:status().done == 1 and not w2.p:status().armed)
    local w3 = world()
    w3.put("c", 24, 24, { { id = "A", need = true }, { id = "B", boom = true }, { id = "C", need = true } })
    w3.p:request("c", 24, 24); w3.advance(1.1)
    check("needs_cover throwing skips that record only", #w3.covers == 1 and #w3.covers[1].recs == 2)
    local w4 = world({ no_logger = true })
    w4.put("c", 24, 24, w4.recs("A+"))
    w4.p:request("c", 24, 24)
    check("no logger is fine", pcall(function() w4.advance(2) end) and #w4.covers == 1)
    local w5 = world({ drop = { "schedule" } })
    w5.put("c", 24, 24, w5.recs("A+"))
    check("no schedule dep: arms, never starts, never throws", w5.p:request("c", 24, 24) == "armed" and #w5.covers == 0)
    local w6 = world({ drop = { "settled" } })
    w6.put("c", 24, 24, w6.recs("A+")); w6.p:request("c", 24, 24); w6.advance(3)
    check("no settled dep = never settled", #w6.covers == 0)
    local w7 = world({ drop = { "records" } })
    w7.put("c", 24, 24, w7.recs("A+")); w7.p:request("c", 24, 24); w7.advance(2)
    check("no records dep: page counted done, nothing queued", #w7.covers == 0 and w7.p:status().done == 1)
end

-- custom delays ---------------------------------------------------------------------------------------------------------------------------
do
    local w = world({ settle_delay = 0.2, step_delay = 0 })
    w.put("c", 24, 24, w.recs("A+"))
    w.p:request("c", 24, 24); w.advance(0.25)
    check("custom settle delay honoured", #w.covers == 1)
    local w2 = world({ settle_delay = -5, step_delay = "x" })
    w2.put("c", 24, 24, w2.recs("A+")); w2.p:request("c", 24, 24); w2.advance(0.5)
    check("bad delays fall back to the defaults", #w2.covers == 0)
    w2.advance(1)
    check("  and still run", #w2.covers == 1)
end

-- logging ---------------------------------------------------------------------------------------------------------------------------------
do
    local w = world()
    w.put("c", 24, 24, w.recs("A+"))
    w.p:request("c", 24, 24); w.advance(1.1)
    local joined = table.concat(w.logs, "\n")
    check("log: armed line", joined:find("bo prefetch: armed key=c:24:24", 1, true) ~= nil)
    check("log: covers queued line", joined:find("bo prefetch: covers queued n=1", 1, true) ~= nil)
end


-- S4b: forgetDone() forgets the done keys and NOTHING else ------------------------------------------------------------------
do
    -- a finished prefetch is forgotten; the same page can be prefetched again, the others are untouched
    local w = world()
    w.put("c", 24, 24, w.recs("A+", "B+"))
    w.p:request("c", 24, 24); w.advance(1.1)
    check("S4b: before: page done, covers queued once", w.p:status().done == 1 and #w.covers == 1)
    check("S4b: a done page is not armed again by request()", w.p:request("c", 24, 24) == "done")
    local n = w.p:forgetDone()
    check("S4b: forgetDone() returns how many keys it forgot", n == 1, n)
    check("S4b: the done set is empty", w.p:status().done == 0)
    check("S4b: the same request now arms again (the page still wants covers)", w.p:request("c", 24, 24) == "armed")
    w.advance(1.1)
    check("S4b: ... and the covers are queued a second time", #w.covers == 2 and w.covers[2].sid == "c" and #w.covers[2].recs == 2)
    check("S4b: forgetting twice is harmless: second call forgets the re-marked key once, a third none",
        w.p:forgetDone() == 1 and w.p:forgetDone() == 0)
    check("S4b: fresh machine: 0, no error", select(2, pcall(Prefetch.new({}).forgetDone, Prefetch.new({}))) == 0)
end

do
    -- nothing is cancelled, dropped or scheduled; an armed / listing / downloading prefetch is untouched
    local w = world()
    w.put("c", 24, 24, w.recs("A+"))
    w.p:request("c", 24, 24); w.advance(1.1)                        -- covers queued: covers_key set, key done
    local st0 = w.p:status()
    local cancels0, covers0, lists0, logs0, timers0 = w.cancels, #w.covers, #w.list_calls, #w.logs, w.live_timers()
    -- a different page armed, waiting for its settle timer
    local w2 = world()
    w2.put("c", 24, 24, w2.recs("A+")); w2.p:request("c", 24, 24); w2.advance(1.1)          -- page 24 done, covers_key = 24
    w2.p:request("c", 48, 24)                                                               -- user moved: 24's covers cancelled, 48 armed
    local c2 = w2.cancels
    local s2 = w2.p:status()
    local forgot = w2.p:forgetDone()
    local s3 = w2.p:status()
    check("S4b: an armed intent keeps its key and its pending timer", s3.armed == true and s3.key == s2.key and s3.timer == true and w2.live_timers() == 1)
    check("S4b: no cancel_covers call, nothing enqueued, nothing listed, nothing logged",
        w2.cancels == c2 and #w2.covers == 1 and #w2.list_calls == 0)
    check("S4b: the done key of the page the user left was forgotten", forgot == 1 and s3.done == 0)
    w2.advance(1.1)
    check("S4b: the armed intent still runs afterwards (list requested once)", #w2.list_calls == 1)

    -- listing in progress
    local w3 = world()
    w3.p:request("c", 24, 24); w3.advance(1.1)
    check("S4b: listing: list requested", #w3.list_calls == 1 and w3.p:status().listing == true)
    local before = w3.p:status()
    w3.p:forgetDone()
    local after = w3.p:status()
    check("S4b: listing stays listing, same key, nothing re-requested",
        after.listing == true and after.armed == true and after.key == before.key and #w3.list_calls == 1 and w3.cancels == 0)
    w3.put("c", 24, 24, w3.recs("A+")); w3.p:onListReady(w3.k("c", 24, 24), true); w3.advance(0.2)
    check("S4b: the list landing still leads to exactly one covers enqueue", #w3.covers == 1)

    -- covers_key survives
    check("S4b: covers_key is not touched by forgetDone", w.p:status().covers_key == st0.covers_key)
    w.p:forgetDone()
    check("S4b: ... nor cancels, covers, lists, timers (finished prefetch)",
        w.p:status().covers_key == st0.covers_key and w.cancels == cancels0 and #w.covers == covers0
        and #w.list_calls == lists0 and w.live_timers() == timers0 and #w.logs == logs0)
end

do
    -- keep_key: the page whose covers are downloading right now stays done (no second enqueue under a running chain)
    local w = world()
    w.put("c", 24, 24, w.recs("A+")); w.put("c", 48, 24, w.recs("B+"))
    w.p:request("c", 24, 24); w.advance(1.1)
    w.p:request("c", 48, 24); w.advance(1.1)
    check("S4b: keep: two pages done, the second one's covers are the running download",
        w.p:status().done == 2 and w.p:status().covers_key == w.k("c", 48, 24))
    local n = w.p:forgetDone(w.k("c", 48, 24))
    check("S4b: keep: only the other key is forgotten", n == 1 and w.p:status().done == 1, n)
    local cov0 = #w.covers
    check("S4b: keep: the kept page is not armed again by a rebuild", w.p:request("c", 48, 24) == "done" and #w.covers == cov0)
    w.advance(5)
    check("S4b: keep: nothing was enqueued a second time", #w.covers == cov0)
    check("S4b: keep: the forgotten page can arm again", w.p:request("c", 24, 24) == "armed")
    -- a keep key that is not in the done set / garbage keep keys are plain no-ops for the kept part
    local w2 = world()
    w2.put("c", 24, 24, w2.recs("A+")); w2.p:request("c", 24, 24); w2.advance(1.1)
    check("S4b: keep of an unknown key forgets everything", w2.p:forgetDone("nope") == 1 and w2.p:status().done == 0)
    w2.p:request("c", 24, 24); w2.advance(1.1)
    check("S4b: keep = a number / a table does not throw and forgets everything",
        select(2, pcall(w2.p.forgetDone, w2.p, 42)) == 1 and select(2, pcall(w2.p.forgetDone, w2.p, {})) == 0)
end

do
    -- the FIFO cap keeps working on what is left (done and done_order stay consistent)
    local w = world({ done_max = 3 })
    for i = 1, 3 do w.put("c", i * 10, 10, w.recs("A-")); w.p:request("c", i * 10, 10) end
    check("S4b: fifo: three done keys", w.p:status().done == 3)
    w.p:forgetDone(w.k("c", 20, 10))
    check("S4b: fifo: only the kept key is left", w.p:status().done == 1)
    for i = 4, 6 do w.put("c", i * 10, 10, w.recs("A-")); w.p:request("c", i * 10, 10) end
    check("S4b: fifo: the cap still holds (3) and the kept key is the oldest, so the first one evicted",
        w.p:status().done == 3, w.p:status().done)
    check("S4b: fifo: key 20 was evicted first, keys 40-60 are done", w.p:request("c", 50, 10) == "done" and w.p:request("c", 60, 10) == "done")
    w.put("c", 20, 10, w.recs("A+"))
    check("S4b: fifo: ... so page 20 (now wanting a cover) arms again", w.p:request("c", 20, 10) == "armed")
end

do
    -- a forgotten page with nothing left to do is marked done at once (no covers, no timer)
    local w = world()
    w.put("c", 24, 24, w.recs("A-", "B-"))
    check("S4b: nothing wanted: done at once", w.p:request("c", 24, 24) == "done")
    w.p:forgetDone()
    check("S4b: forgotten, then asked again: done at once, nothing queued, no timer",
        w.p:request("c", 24, 24) == "done" and #w.covers == 0 and w.live_timers() == 0 and w.p:status().done == 1)
    -- a throwing records dep after the forget: no throw, the page is simply armed
    local w2 = world({})
    w2.put("c", 24, 24, w2.recs("A+")); w2.p:request("c", 24, 24); w2.advance(1.1); w2.p:forgetDone()
    w2.put("c", 24, 24, { { id = "x", boom = true } })
    check("S4b: a record whose needs_cover throws counts as not wanted -> done at once", w2.p:request("c", 24, 24) == "done")
end

-- P2: static wiring checks on the REAL source (read as text) -----------------------------------------------
do
    local function slurp(p) local f = assert(io.open(PLUGIN .. "/" .. p, "rb")); local t = f:read("*a"); f:close(); return t end
    local src = slurp("lib/bookshelf_bookorbit_source.lua")
    local repo = slurp("lib/bookshelf_book_repository.lua")
    -- A top-level function: from its header to the next column-0 "end".
    local function fn(header)
        local a = src:find(header, 1, true)
        if not a then return "" end
        local b = src:find("\nend\n", a, true)
        return src:sub(a, b or #src)
    end
    local function has(t, needle) return t:find(needle, 1, true) ~= nil end
    local function before(t, a, b)
        local i, j = t:find(a, 1, true), t:find(b, 1, true)
        return i ~= nil and j ~= nil and i < j
    end

    local pnp = fn("function M.prefetchNextPage(")
    check("W: prefetchNextPage exists and is short", #pnp > 0 and #pnp < 400, #pnp)
    check("W: prefetchNextPage has no blocking M.listBooks call", not has(pnp, "M.listBooks("))
    check("W: prefetchNextPage has no downloadOneThumbnail", not has(pnp, "downloadOneThumbnail"))
    check("W: prefetchNextPage has no prefetchDescriptions", not has(pnp, "prefetchDescriptions"))
    check("W: prefetchNextPage only arms the state machine", has(pnp, "pf:request(source_id, offset, limit)"))
    check("W: no scheduleIn(1.0 ...) blocking tick is left in the prefetch block",
        not has(src:sub(src:find("-- Next-page prefetch (HANDOFF", 1, true), #src):sub(1, 9000), "scheduleIn(1.0"))
    check("W: M.prefetchDescriptions is still there (chip pre-warm)", has(src, "function M.prefetchDescriptions("))
    check("W: downloadOneThumbnail still used by the visible path", has(fn("local function fillOneCover("), "downloadOneThumbnail"))

    local pool = fn("local function getPrefetchPool()")
    check("W: prefetch pool built from the pure CoverPool", has(pool, "CoverPool.new{"))
    check("W: prefetch pool width is PREFETCH_POOL_WIDTH", has(pool, "width = PREFETCH_POOL_WIDTH"))
    -- D2: the prefetch pool now DECODES AHEAD, through the same body as the visible pool.
    local dja = fn("local function decodeJobRecords(")
    check("W: decode-ahead: the prefetch pool decodes through the shared decodeJobRecords", has(pool, "decodeJobRecords(job,"))
    check("W: decode-ahead: the visible pool uses the same shared body (no second copy)",
        has(fn("local function getCoverPool()"), "decodeJobRecords(job)") and not has(fn("local function getCoverPool()"), "decodeThumbnailFile("))
    check("W: decode-ahead: the shared body skips records already _cover_filled (never overwrites a bitmap a widget is about to take)",
        has(dja, "not record._cover_filled"))
    check("W: decode-ahead: the shared body sets bitmap, size, has_cover and _cover_filled together",
        has(dja, "record.cover_bb, record.cover_w, record.cover_h = bb, w, h") and has(dja, "record._cover_filled = true"))
    check("W: decode-ahead: the prefetch pool never assigns a bitmap itself", not has(pool, "cover_bb =") and not has(pool, "decodeThumbnailFile("))
    check("W: decode-ahead: only the CURRENT prefetched page is decoded (stale landings skipped before any decode)",
        has(pool, "_ahead:currentPage() == pid") and has(pool, "_ahead_page_of[record]"))
    check("W: decode-ahead: a decoded record is registered with the holder (with its page id)",
        has(pool, "_ahead:add(record, _ahead_page_of[record])"))
    check("W: decode-ahead: a record the holder refuses is detached, bitmap AND flag together",
        has(pool, "Ahead.dropRecord(record)"))
    check("W: decode-ahead: a refusal / nothing-to-do is not a decode failure (no re-download)",
        has(pool, "return landed or refused or not needed"))
    check("W: decode-ahead: the pool logs n / bytes / ms when it drains",
        has(pool, "on_idle = function()") and has(pool, "bo prefetch: decode-ahead n=%d prescaled=%d raw=%d bytes=%d ms=%.0f prescale_ms=%.0f"))
    -- S2: the ONLY free in the pool is the prescaled branch (the source owns that raw bb:
    -- it never reached a record or a widget). The holder wiring still frees nothing.
    local _, nfree = pool:gsub(":free%(", "")
    check("W: decode-ahead: nothing is freed in the holder wiring; the pool frees only on the prescaled branch (S2)",
        nfree == 1 and not has(fn("local function aheadRelease("), ":free(") and not has(dja, ":free(")
        and has(pool, "pcall(function() bb:free() end)"))
    -- S2 prescale hook (static; behaviour is in test_bo_wiring section 9)
    local presc = pool:match("function%(record, bb, w, h%).-return true\n%s*end%)") or ""
    check("S2: the prefetch pool offers the decoded bitmap to the injected prescaler", has(pool, "local fn = _prescaler") and has(pool, "pcall(fn, record, bb)"))
    check("S2: prescale branch accepts only 'scaled' / 'already'",
        has(presc, 'status ~= "scaled" and status ~= "already"'))
    check("S2: the prescaled branch frees the raw bb AFTER the status check and clears the bitmap fields",
        presc ~= "" and (presc:find('status ~= "scaled"', 1, true) or 1e9) < (presc:find(":free(", 1, true) or 0)
        and has(presc, "record.cover_bb, record.cover_w, record.cover_h = nil, nil, nil")
        and has(presc, "record._cover_filled = true") and has(presc, "record.has_cover = true"))
    check("S2: the prescaled branch never registers with the holder", presc ~= "" and not has(presc, "_ahead:add"))
    check("S2: the main (visible) pool never calls the prescaler",
        not has(fn("local function getCoverPool("), "_prescaler") and not has(fn("local function getCoverPool("), "prescale"))
    check("S2: decodeJobRecords offers the bitmap to prescale BEFORE attaching it",
        has(dja, "if prescale and prescale(record, bb, w, h) then")
        and (dja:find("if prescale and prescale", 1, true) or 1e9) < (dja:find("record.cover_bb, record.cover_w, record.cover_h = bb, w, h", 1, true) or 0))
    check("S2: M.setCoverPrescaler exists and clears on a non-function",
        has(src, "function M.setCoverPrescaler(fn)") and has(src, 'if type(fn) == "function" then _prescaler = fn else _prescaler = nil end'))
    check("S2: prescale counters are reset with the other chain counters",
        select(2, src:gsub("_ahead_prescaled, _ahead_prescale_ms = 0, 0", "")) >= 3)
    check("S2: the source does not require SpineWidget or ScaledCoverCache",
        not has(src, 'require("lib/bookshelf_spine_widget")') and not has(src, 'require("lib/bookshelf_scaled_cover_cache")'))
    -- S4: tile size changes (static; behaviour is in test_bo_wiring 9.18-9.27)
    local ctc_full = fn("function M.coverTileChanged()")
    -- S4b appended one block (marked "-- S4b:") to the same function; the strict S4 checks below
    -- run on the part BEFORE it, the S4b block has its own checks further down.
    local s4b_at = ctc_full:find("-- S4b:", 1, true)
    local ctc = s4b_at and ctc_full:sub(1, s4b_at - 1) or ctc_full
    check("S4: M.coverTileChanged exists once", ctc ~= "" and select(2, src:gsub("function M%.coverTileChanged%(", "")) == 1)
    check("S4: it clears the flag only on the exact prescale state (flagged, no bitmap)",
        has(ctc, "record._cover_filled == true and record.cover_bb == nil") and has(ctc, "record._cover_filled = nil"))
    check("S4: it only drops the flag: no free, no scheduling, no pool / hook / holder / has_cover change",
        ctc ~= "" and not has(ctc, ":free(") and not has(ctc, "scheduleCoverFills") and not has(ctc, "shutdown")
        and not has(ctc, "cancel") and not has(ctc, "setCoverPrescaler") and not has(ctc, "_ahead") and not has(ctc, "has_cover")
        and not has(ctc, "_prescaler") and not ctc:find("cover_bb%s*=[^=]"))
    check("S4: it forgets each record as it goes (a second call finds nothing)", has(ctc, "_prescaled_records[record] = nil"))
    check("S4: the tracking table has weak keys", has(src, "local _prescaled_records = setmetatable({}, { __mode = \"k\" })"))
    check("S4: a record is tracked only on the prescaled branch (exactly one assignment, inside it)",
        select(2, src:gsub("_prescaled_records%[record%] = true", "")) == 1 and has(presc, "_prescaled_records[record] = true")
        and (presc:find("_prescaled_records[record] = true", 1, true) or 0) > (presc:find(":free(", 1, true) or 1e9))
    local lb = fn("function M.listBooks(")
    check("S4: listBooks forgets the page's records at ONE call site, never for a background (preload) request",
        select(2, src:gsub("forgetPrescaled%(", "")) == 2     -- the definition + this call
        and has(lb, "if not (opts and opts.preload) then forgetPrescaled(cached_records) end"))
    check("S4: ... right after the cache hit, before the records are returned",
        (lb:find("forgetPrescaled(cached_records)", 1, true) or 1e9) < (lb:find("return cached_records, cached_total", 1, true) or 0)
        and (lb:find("consumeNextPageCache(id, offset, limit)", 1, true) or 1e9) < (lb:find("forgetPrescaled(cached_records)", 1, true) or 0))
    check("S4: the prefetch's own page lookups (cached / records) never forget",
        not has(fn("local function consumeNextPageCache("), "forgetPrescaled") and not has(fn("local function getPrefetch()"), "forgetPrescaled"))
    -- S4b: forget the prefetch machine's done keys after a tile change (static; behaviour: wiring 9.28+, prefetch suite)
    do
        local blk = s4b_at and ctc_full:sub(s4b_at) or ""
        local code = {}   -- the S4b block without comment lines (a comment may say "no cancel")
        for line in blk:gmatch("[^\n]+") do if not line:match("^%s*%-%-") then code[#code + 1] = line end end
        code = table.concat(code, "\n")
        check("S4b: coverTileChanged has exactly one S4b block, after the flag clearing", s4b_at ~= nil
            and select(2, ctc_full:gsub("%-%- S4b:", "")) == 1
            and s4b_at > (ctc_full:find("record._cover_filled = nil", 1, true) or 1e9))
        check("S4b: the block runs only when a flag was cleared (inside `if n > 0`)",
            (ctc_full:find("if n > 0 then", 1, true) or 1e9) < s4b_at and (ctc_full:find("return n", s4b_at, true) or 0) > s4b_at)
        check("S4b: it calls ONLY Prefetch:forgetDone on the machine (under pcall)",
            has(code, "pcall(_prefetch.forgetDone, _prefetch, keep)"))
        check("S4b: no reset / supersede / request / notify / cancel / shutdown / enqueue / free / holder in the block",
            code ~= "" and not has(code, "_prefetch.reset") and not has(code, "supersede") and not has(code, "_prefetch.request")
            and not has(code, "_prefetch.notify") and not has(code, "prefetchStop") and not has(code, "prefetchYield")
            and not has(code, "cancel") and not has(code, "shutdown") and not has(code, "enqueue") and not has(code, ":free(")
            and not has(code, "_ahead") and not has(code, "aheadRelease") and not has(code, "scheduleCoverFills"))
        check("S4b: only the STATUS of the prefetch pool is read (no other call on the pool)",
            has(code, "pcall(_prefetch_pool.status, _prefetch_pool)") and select(2, code:gsub("_prefetch_pool", "")) == 3)
        check("S4b: the key under a running download is kept (only while the pool chain is active, from status().covers_key)",
            has(code, "ps.chain_active") and has(code, "keep = st.covers_key")
            and (code:find("ps.chain_active", 1, true) or 1e9) < (code:find("keep = st.covers_key", 1, true) or 0)
            and (code:find("keep = st.covers_key", 1, true) or 1e9) < (code:find("forgetDone", 1, true) or 0))
        check("S4b: guarded: a source without a prefetch machine yet does nothing", has(code, "if _prefetch then"))
        check("S4b: the only caller of forgetDone in the source", select(2, src:gsub("forgetDone", "")) >= 1
            and select(2, src:gsub("_prefetch%.forgetDone", "")) == 1)

        local pre = io.open(PLUGIN .. "/lib/bookshelf_bookorbit_prefetch.lua", "rb"):read("*a")
        local s, e = pre:find("function Prefetch:forgetDone%(keep_key%).-\nend\n")
        local fd = s and pre:sub(s, e) or ""
        local fdc = {}
        for line in fd:gmatch("[^\n]+") do if not line:match("^%s*%-%-") then fdc[#fdc + 1] = line end end
        fdc = table.concat(fdc, "\n")
        check("S4b: Prefetch:forgetDone exists once", fd ~= "" and select(2, pre:gsub("function Prefetch:forgetDone", "")) == 1)
        check("S4b: it touches only the done set (no intent, timer, covers_key, dep call, schedule)",
            fdc ~= "" and not has(fdc, "self.intent") and not has(fdc, "self.timer") and not has(fdc, "covers_key")
            and not has(fdc, "call(self") and not has(fdc, "_unsched") and not has(fdc, "_sched") and not has(fdc, "_drop")
            and not has(fdc, "cancel") and not has(fdc, "self.d["))
        check("S4b: it rebuilds both done structures", has(fdc, "self.done[key] = nil") and has(fdc, "self.done_order = kept"))
        check("S4b: reset() is unchanged: it still drops intent, timer and covers",
            has(pre, "function Prefetch:reset()") and has(pre, "self.done, self.done_order = {}, {}"))
    end
    check("W: prefetch pool has no inline fallback", not has(pool, "on_fork_broken =") and not has(pool, "inlineFill("))
    check("W: prefetch pool never repaints", not has(pool, "fireCoversReady"))
    check("W: prefetch pool shares the fork code (makeCoverSpawn)", has(pool, "spawn = makeCoverSpawn(ffiutil)"))
    check("W: main pool shares it too", has(fn("local function getCoverPool()"), "makeCoverSpawn(ffiutil,"))
    check("W: only definitive server answers blacklist a cover for the visible page",
        has(pool, "if definitiveCoverFailure(why) then _thumb_failed[key] = true end"))

    local pf = fn("local function getPrefetch()")
    check("W: settled looks at the main pool chain", has(pf, "_cover_pool:status().chain_active"))
    check("W: settled looks at the inline fill", has(pf, "inlineFillRunning()"))
    check("W: settled looks at urgent page jobs", has(pf, "_page_fetcher:counts()") and has(pf, "c.urgent"))
    check("W: list goes through the NON-urgent page fetcher", has(pf, "urgent = false") and has(pf, "F:request("))
    check("W: no blocking list call in the prefetch deps", not has(pf, "M.listBooks(") and not has(pf, "catalogBooks"))
    check("W: decode-ahead: sub-setting ON -> every record that wants a cover, disk hits included (wantsCoverAhead)",
        has(pf, "if decodeAheadEnabled() then return wantsCoverAhead(record) end")
        and not has(pf, "needs_cover = wantsCoverAhead") and not has(pf, "needs_cover = needsThumbnail"))
    check("W: decode-ahead: sub-setting OFF -> only covers missing from disk (needsThumbnail, download only as before D)",
        before(pf, "if decodeAheadEnabled() then return wantsCoverAhead(record) end", "return needsThumbnail(record)"))
    check("W: decode-ahead: wantsCoverAhead is wantsCover (which skips _cover_filled records)",
        has(fn("local function wantsCoverAhead("), "return wantsCover(record)"))
    check("W: covers go to the prefetch pool", has(pf, "getPrefetchPool()") and has(pf, "pool:enqueue(want, source_id)"))
    check("W: decode-ahead: a new prefetched page releases the previous one first, with a unique page id",
        before(pf, "holder:beginPage(page_id)", "pool:enqueue(want, source_id)") and has(pf, "_ahead_seq = _ahead_seq + 1")
        and has(pf, 'local page_id = tostring(source_id) .. "#" .. _ahead_seq'))
    check("W: decode-ahead: pages over the cap are download only (needsThumbnail), never tagged for decode",
        has(pf, "#records > PREFETCH_AHEAD_MAX_RECORDS") and has(pf, "needsThumbnail(record)")
        and before(pf, "needsThumbnail(record)", "_ahead_page_of[record] = page_id"))
    check("W: decode-ahead: sub-setting OFF takes the same download-only branch (never tagged), beginPage still runs first",
        has(pf, "if not decodeAheadEnabled() or #records > PREFETCH_AHEAD_MAX_RECORDS then")
        and before(pf, "holder:beginPage(page_id)", "if not decodeAheadEnabled() or") and has(pf, "local released = holder:beginPage(page_id)"))
    local dae = fn("local function decodeAheadEnabled()")
    check("W: sub-setting: key bookorbit_prefetch_decode_ahead, ON unless explicitly false, an unreadable store means ON",
        has(dae, '"bookorbit_prefetch_decode_ahead"') and has(dae, "v ~= false") and has(dae, "if not ok then return true end")
        and has(dae, "pcall(BookshelfSettings.read"))
    check("W: sub-setting: M.releaseDecodeAhead releases through aheadRelease and is NOT called from the prefetch deps",
        has(src, "function M.releaseDecodeAhead(reason)") and has(src, 'aheadRelease(reason or "setting")')
        and not has(pf, "releaseDecodeAhead"))
    local settings = slurp("lib/bookshelf_settings.lua")
    local s_i = settings:find('text = _("Decode covers ahead")', 1, true)
    local s_p = settings:find('text = _("Prefetch next page")', 1, true)
    local item = s_i and settings:sub(s_i, s_i + 2200) or ""
    local parent = (s_p and s_i) and settings:sub(s_p, s_i - 1) or ""
    check("W: settings: the sub-setting item sits right after the parent", s_p ~= nil and s_i ~= nil and s_p < s_i and s_i - s_p < 2600)
    check("W: settings: sub-setting default ON (read ~= false), saved under its own key",
        has(item, 'checked_func = function()\n                return BookshelfSettings.read("bookorbit_prefetch_decode_ahead") ~= false')
        and has(item, 'BookshelfSettings.save("bookorbit_prefetch_decode_ahead", not on)'))
    check("W: settings: the sub-setting is only active while the parent is ON",
        has(item, "enabled_func = function()") and has(item:sub(item:find("enabled_func", 1, true), item:find("checked_func", 1, true) or #item),
            'BookshelfSettings.read("bookorbit_prefetch_next_page") == true'))
    check("W: settings: switching the sub-setting OFF releases the held covers (own pcall helper)",
        has(item, "if on then releaseDecodeAhead() end") and has(settings, "local function releaseDecodeAhead()")
        and has(settings, "pcall(BOSource.releaseDecodeAhead"))
    check("W: settings: switching the parent OFF releases too", has(parent, "if on then releaseDecodeAhead() end"))
    check("W: settings: the parent's help text is download-only again (no memory wording)",
        not has(parent, "in memory") and not has(parent, "memory") and has(parent, "so paging forward is faster"))
    check("W: decode-ahead: cancel_covers stops queued decodes as well as pending downloads",
        has(pf, "_prefetch_pool:cancel()") and has(pf, "_prefetch_pool:cancelDecode()"))
    check("W: decode-ahead: cancel_covers releases nothing (it runs inside the page turn)",
        not has(pf, "aheadRelease(") and not has(pf, "_ahead:release") and not has(pf, ":release("))
    check("W: decode-ahead: supersede / yield release nothing (decoded records stay attached)",
        not has(fn("local function prefetchYield()"), "aheadRelease") and not has(fn("local function prefetchYield()"), "_ahead"))
    check("W: discover/similar/want_to_read are not prefetched", has(pf, '"discover"') and has(pf, '"similar"') and has(pf, '"want_to_read"'))
    check("W: settle delay and done cap constants wired", has(pf, "settle_delay = PREFETCH_SETTLE_DELAY_S") and has(pf, "done_max = PREFETCH_DONE_KEYS_MAX"))
    check("W: constants have the D-P4 values",
        has(src, "PREFETCH_SETTLE_DELAY_S = 1.0") and has(src, "PREFETCH_POOL_WIDTH = 1") and has(src, "PREFETCH_DONE_KEYS_MAX = 64"))
    check("W: decode-ahead: cap constant is 36 and the holder gets it",
        has(src, "PREFETCH_AHEAD_MAX_RECORDS = 36") and has(fn("local function getAhead()"), "max_records = PREFETCH_AHEAD_MAX_RECORDS"))
    check("W: decode-ahead: the holder is the pure module, never required lazily from a dep",
        has(src, 'local Ahead     = require("lib/bookshelf_bookorbit_ahead")'))

    -- hooks
    check("W: main pool on_idle notifies the prefetch", has(fn("local function getCoverPool()"), "on_idle = function() prefetchNotify() end"))
    local inl = fn("local function inlineFill(")
    check("W: inline fill end notifies and clears its flag", has(inl, "_inline_gen = nil") and has(inl, "prefetchNotify()"))
    check("W: inline flag only counts for the current generation",
        has(src, "return _inline_gen ~= nil and _inline_gen == _thumb_generation"))
    local pg = fn("local function getPageFetcher()")
    check("W: on_ready tells the prefetch BEFORE the widget callback",
        before(pg, "prefetchPageReady", "local cb = _page_ready_cb"))
    check("W: ... in its own pcall", has(pg, "pcall(prefetchPageReady, info,"))
    local prr = src:sub(src:find("prefetchPageReady = function(info, ok, why)", 1, true), #src):sub(1, 900)
    check("W: page-ready builds the prefetch key from req, not from the fetcher key",
        has(prr, "Prefetch.keyOf(req.id, req.offset, req.limit)") and not has(prr, "info.key"))
    check("W: an urgent (visible) page drops the prefetch intent", has(prr, 'pf:onListReady(key, false, "visible")'))
    local scf = fn("function M.scheduleCoverFills(")
    check("W: scheduleCoverFills yields to the prefetch after cancelling", before(scf, "M.cancelThumbnailJobs()", "prefetchYield()"))
    check("W: ... only when a real chain starts (after the empty-queue return)", before(scf, "if #queue == 0 then return end", "prefetchYield()"))
    local cj = fn("function M.cancelThumbnailJobs(")
    check("W: cancelThumbnailJobs also cancels the prefetch pool's pending list", has(cj, "_prefetch_pool:cancel()"))
    check("W: yield supersedes the machine and shuts the prefetch pool down",
        has(src, "pcall(_prefetch.supersede, _prefetch)") and has(src, "pcall(_prefetch_pool.shutdown, _prefetch_pool)"))

    -- cleanup
    check("W: shutdownCoverPool stops the prefetch", has(fn("function M.shutdownCoverPool("), "prefetchStop()"))
    check("W: shutdownPageFetch stops the prefetch", has(fn("function M.shutdownPageFetch("), "prefetchStop()"))
    check("W: invalidateNextPageCache forgets done keys", has(fn("function M.invalidateNextPageCache("), "pcall(_prefetch.reset, _prefetch)"))
    check("W: decode-ahead: prefetchStop releases the held bitmaps", has(fn("local function prefetchStop()"), 'aheadRelease("stop")'))
    check("W: decode-ahead: invalidateNextPageCache releases them", has(fn("function M.invalidateNextPageCache("), 'aheadRelease("invalidate")'))
    check("W: decode-ahead: shutdown paths reach the release through prefetchStop",
        has(fn("function M.shutdownCoverPool("), "prefetchStop()") and has(fn("function M.shutdownPageFetch("), "prefetchStop()"))
    check("W: decode-ahead: release drops references only (holder.release, no free) and logs the reason",
        has(fn("local function aheadRelease("), "pcall(_ahead.release, _ahead)") and has(fn("local function aheadRelease("), "decode-ahead released n=%d reason=%s"))
    check("W: prefetchStop resets the machine and kills the pool",
        has(fn("local function prefetchStop()"), "_prefetch.reset") and has(fn("local function prefetchStop()"), "_prefetch_pool.shutdown"))

    -- the repo call site is unchanged in P2 (the preload gate is P3)
    check("W: repo still reads the setting before arming",
        has(repo, 'BookshelfSettings.read("bookorbit_prefetch_next_page") == true'))
end

print(string.format("test_bo_prefetch: %d passed, %d failed", passes, fails))
return fails > 0
