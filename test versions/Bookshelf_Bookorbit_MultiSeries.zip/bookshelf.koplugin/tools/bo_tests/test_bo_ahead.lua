-- Decode-ahead, Batch D1: the pure holder (lib/bookshelf_bookorbit_ahead.lua).
-- Off-device; no KOReader. Proves the LOGIC only (not run on a device). The holder
-- is NOT wired into the source yet (Batch D2).
package.path = PLUGIN .. "/?.lua;" .. package.path
local fails, passes = 0, 0
local function check(n, c, x)
    if c then passes = passes + 1
    else fails = fails + 1; print("FAIL: " .. n .. (x ~= nil and (" -> " .. tostring(x)) or "")) end
end

local Ahead = require("lib/bookshelf_bookorbit_ahead")

-- Fakes ----------------------------------------------------------------------------
local frees = 0   -- every bb:free() anywhere; the holder must never cause one
local function fake_bb(stride, h)
    local bb = { stride = stride, h = h }
    function bb:free() frees = frees + 1 end
    return bb
end
-- A record that just got a bitmap from the decode (what the pool's decode does).
local function held_rec(id, stride, h)
    return { remote_id = id, title = "T" .. id, cover_bb = fake_bb(stride or 100, h or 200),
             cover_w = 50, cover_h = h or 200, has_cover = true, _cover_filled = true }
end
local function consumed_rec(id)   -- SpineWidget took it: bb gone, flag stays
    return { remote_id = id, cover_bb = nil, _cover_filled = true, has_cover = true }
end

-- constants / defaults -----------------------------------------------------------------
check("default max_records 36", Ahead.DEFAULT_MAX_RECORDS == 36)
do
    local r = held_rec(1)
    check("recordHeld: true with a bitmap", Ahead.recordHeld(r) == true)
    check("recordHeld: false without", Ahead.recordHeld(consumed_rec(1)) == false)
    check("recordHeld: false for non-tables", Ahead.recordHeld(nil) == false and Ahead.recordHeld("x") == false)
    Ahead.dropRecord(r)
    check("dropRecord clears the bitmap, its size AND the filled flag",
        r.cover_bb == nil and r.cover_w == nil and r.cover_h == nil and r._cover_filled == nil)
    check("dropRecord leaves the other fields alone", r.title == "T1" and r.remote_id == 1 and r.has_cover == true)
    check("dropRecord never frees", frees == 0)
    local ok = pcall(Ahead.dropRecord, nil)
    check("dropRecord(nil) is harmless", ok)
    check("recordBytes: stride * h", Ahead.recordBytes(held_rec(1, 120, 300)) == 36000)
    check("recordBytes: no bitmap -> 0", Ahead.recordBytes(consumed_rec(1)) == 0 and Ahead.recordBytes(nil) == 0)
    local r2 = { cover_bb = { stride = 10, getHeight = function() return 7 end } }
    check("recordBytes: height from getHeight()", Ahead.recordBytes(r2) == 70)
    local r3 = { cover_bb = { stride = 10 }, cover_h = 9 }
    check("recordBytes: height from the record", Ahead.recordBytes(r3) == 90)
    check("recordBytes: unknown stride -> 0", Ahead.recordBytes({ cover_bb = {}, cover_h = 9 }) == 0)
    -- S1: LuaJIT size_t cdata (stride/h are not Lua numbers but tonumber() works).
    -- Plain Lua has no cdata: a numeric STRING is the stand-in (type ~= "number",
    -- tonumber() converts), which is exactly the case the old type() test rejected.
    local fake_stride = "120"
    check("recordBytes: stand-in is not a Lua number", type(fake_stride) ~= "number")
    local r4 = { cover_bb = { stride = fake_stride, h = 300 } }
    check("recordBytes: cdata-like stride (tonumber) counts", Ahead.recordBytes(r4) == 36000, Ahead.recordBytes(r4))
    local r5 = { cover_bb = { stride = 120, h = "300" } }
    check("recordBytes: cdata-like height counts", Ahead.recordBytes(r5) == 36000, Ahead.recordBytes(r5))
    local r6 = { cover_bb = { stride = fake_stride, getHeight = function() return "7" end } }
    check("recordBytes: cdata-like getHeight() counts", Ahead.recordBytes(r6) == 840, Ahead.recordBytes(r6))
    check("recordBytes: non-numeric stride -> 0", Ahead.recordBytes({ cover_bb = { stride = {}, h = 5 } }) == 0)
    check("recordBytes: non-numeric height -> 0", Ahead.recordBytes({ cover_bb = { stride = 5, h = "x" } }) == 0)
    check("recordBytes: stride as a boolean -> 0", Ahead.recordBytes({ cover_bb = { stride = true, h = 5 } }) == 0)
    local r7 = { cover_bb = { stride = fake_stride }, cover_h = "9" }
    check("recordBytes: cdata-like height from the record", Ahead.recordBytes(r7) == 1080, Ahead.recordBytes(r7))
    check("recordBytes: result is a Lua number", type(Ahead.recordBytes(r4)) == "number")
end

-- add ----------------------------------------------------------------------------------
do
    local A = Ahead.new{}
    A:beginPage("p1")
    local r1, r2 = held_rec(1), held_rec(2)
    check("add: a held record is registered", A:add(r1) == true)
    check("add: idempotent (same record again is still true)", A:add(r1) == true)
    A:add(r2)
    local st = A:stats()
    check("stats: page, records, held", st.page == "p1" and st.records == 2 and st.held == 2, st.records)
    check("stats: bytes = sum of stride*h", st.bytes == 2 * 100 * 200, st.bytes)
    check("add: a record holding nothing is refused", A:add(consumed_rec(3)) == false and A:stats().records == 2)
    check("add: nil / string / number refused", A:add(nil) == false and A:add("x") == false and A:add(5) == false)
    check("add: a refused record is not in the stats", A:stats().records == 2)
end

-- max_records ----------------------------------------------------------------------------
do
    local A = Ahead.new{ max_records = 3 }
    A:beginPage("p")
    local rs = {}
    for i = 1, 4 do rs[i] = held_rec(i) end
    check("cap: first three accepted", A:add(rs[1]) and A:add(rs[2]) and A:add(rs[3]))
    check("cap: the fourth is refused", A:add(rs[4]) == false)
    check("cap: the refused record is not counted", A:stats().records == 3)
    check("cap: a registered record at the cap is still true", A:add(rs[2]) == true)
    check("cap: the caller keeps ownership of the refused bitmap (nothing dropped)", rs[4].cover_bb ~= nil and rs[4]._cover_filled == true)
    A:beginPage("q")
    check("cap: a new page starts with a fresh count", A:add(rs[4]) == true and A:stats().records == 1)
end
do
    local A = Ahead.new{}
    A:beginPage("p")
    local ok_all = true
    for i = 1, 36 do ok_all = ok_all and A:add(held_rec(i)) end
    check("default cap: 36 accepted", ok_all)
    check("default cap: the 37th refused", A:add(held_rec(37)) == false)
    local B = Ahead.new{ max_records = 0 }
    B:beginPage("p")
    check("max_records 0 is raised to 1", B:add(held_rec(1)) == true and B:add(held_rec(2)) == false)
end

-- beginPage ------------------------------------------------------------------------------
do
    local A = Ahead.new{}
    check("beginPage on a fresh holder drops nothing", A:beginPage("p1") == 0 and A:stats().page == "p1")
    local r1, r2, r3 = held_rec(1), held_rec(2), held_rec(3)
    A:add(r1); A:add(r2); A:add(r3)
    check("beginPage: the SAME page is a no-op", A:beginPage("p1") == 0)
    check("  ... nothing was dropped", r1.cover_bb ~= nil and r2.cover_bb ~= nil and r3.cover_bb ~= nil
        and r1._cover_filled == true and A:stats().records == 3)
    local b1 = r1.cover_bb
    local dropped = A:beginPage("p2")
    check("beginPage: a DIFFERENT page drops every held record (count returned)", dropped == 3, dropped)
    check("  ... bitmap, size and filled flag all cleared together",
        r1.cover_bb == nil and r1.cover_w == nil and r1.cover_h == nil and r1._cover_filled == nil
        and r2.cover_bb == nil and r2._cover_filled == nil and r3.cover_bb == nil and r3._cover_filled == nil)
    check("  ... never freed (the references are just dropped)", frees == 0 and b1 ~= nil)
    check("  ... the new generation is empty", A:stats().records == 0 and A:stats().page == "p2")
end
do -- a record the widget already consumed is left exactly as it is
    local dropped_calls = 0
    local A = Ahead.new{ drop = function(rec) dropped_calls = dropped_calls + 1; Ahead.dropRecord(rec) end }
    A:beginPage("p1")
    local r1, r2 = held_rec(1), held_rec(2)
    A:add(r1); A:add(r2)
    r2.cover_bb = nil   -- SpineWidget consumed it (and nilled the field)
    check("consumed: stays registered, no longer held", A:stats().records == 2 and A:stats().held == 1)
    check("consumed: bytes count only what is still held", A:stats().bytes == 100 * 200)
    local n = A:beginPage("p2")
    check("consumed: only the still-held record is dropped", n == 1 and dropped_calls == 1)
    check("consumed: its _cover_filled stays set (the cover is in the scaled cache)", r2._cover_filled == true and r2.has_cover == true)
end
do -- a record dropped by an old page can be registered again on a new one
    local A = Ahead.new{}
    A:beginPage("p1")
    local r = held_rec(1)
    A:add(r)
    A:beginPage("p2")
    r.cover_bb, r.cover_w, r.cover_h, r._cover_filled = fake_bb(10, 10), 5, 10, true   -- decoded again
    check("re-add after release: accepted on the new page", A:add(r) == true and A:stats().records == 1)
end

-- add with page_id (stale landings) ---------------------------------------------------
do
    local A = Ahead.new{}
    A:beginPage("p2")
    local r = held_rec(1)
    check("add(page_id): the current page is accepted", A:add(r, "p2") == true)
    local stale = held_rec(2)
    check("add(page_id): another page is refused (a stale download landing late)", A:add(stale, "p1") == false)
    check("  ... the stale record is not registered, nothing dropped by the holder",
        A:stats().records == 1 and stale.cover_bb ~= nil)
    check("add(nil page): accepted whatever the current page", A:add(held_rec(3)) == true)
    A:release()
    check("add(page_id) after release: refused (the page id was forgotten)", A:add(held_rec(4), "p2") == false)
end

-- currentPage -------------------------------------------------------------------------------
do
    local A = Ahead.new{}
    check("currentPage: nil on a fresh holder", A:currentPage() == nil)
    A:beginPage("p7")
    check("currentPage: the page begun", A:currentPage() == "p7")
    A:release()
    check("currentPage: nil again after release", A:currentPage() == nil)
end

-- release ----------------------------------------------------------------------------------
do
    local A = Ahead.new{}
    A:beginPage("p1")
    local r1, r2 = held_rec(1), held_rec(2)
    A:add(r1); A:add(r2)
    r2.cover_bb = nil   -- consumed
    local n = A:release()
    check("release: drops the still-held ones, returns the count", n == 1, n)
    check("  ... cleared together; the consumed one is untouched",
        r1.cover_bb == nil and r1._cover_filled == nil and r2._cover_filled == true)
    check("  ... forgets the page and the records", A:stats().page == nil and A:stats().records == 0)
    check("release twice: second is 0", A:release() == 0)
    check("release: never freed anything", frees == 0)
    local r3 = held_rec(3)
    check("add after release without a page id still works", A:add(r3) == true)
    A:beginPage("p9")
    check("beginPage after release starts clean", A:stats().page == "p9" and A:stats().records == 0 and r3.cover_bb == nil)
end

-- injected deps / robustness --------------------------------------------------------------
do
    local seen = { held = 0, drop = 0, bytes = 0 }
    local A = Ahead.new{
        held = function(rec) seen.held = seen.held + 1; return rec.mine == true end,
        drop = function(rec) seen.drop = seen.drop + 1; rec.mine = false end,
        bytes = function(rec) seen.bytes = seen.bytes + 1; return 7 end,
    }
    A:beginPage("p")
    local r = { mine = true }
    check("custom held decides what can be added", A:add(r) == true and A:add({ mine = false }) == false)
    check("custom bytes is used", A:stats().bytes == 7 and seen.bytes == 1)
    A:release()
    check("custom drop is used", seen.drop == 1 and r.mine == false)
end
do
    local logged = {}
    local logger = { dbg = function(_, ...) logged[#logged + 1] = { ... } end }
    local A = Ahead.new{
        drop = function(rec) if rec.boom then error("drop boom") end; Ahead.dropRecord(rec) end,
        logger = logger,
    }
    A:beginPage("p")
    local bad, good = held_rec(1), held_rec(2)
    bad.boom = true
    A:add(bad); A:add(good)
    local ok, n = pcall(function() return A:beginPage("q") end)
    check("a throwing drop does not break the caller", ok)
    check("  ... the other records are still dropped", good.cover_bb == nil and good._cover_filled == nil)
    check("  ... and the failure is logged", #logged >= 1)
    check("  ... the holder is clean afterwards", A:stats().records == 0 and A:stats().page == "q")
end
do
    local A = Ahead.new{ held = function() error("held boom") end, bytes = function() error("bytes boom") end }
    A:beginPage("p")
    local ok1, added = pcall(function() return A:add(held_rec(1)) end)
    check("a throwing held: add refuses, no error", ok1 and added == false)
    local B = Ahead.new{ bytes = function() error("bytes boom") end }
    B:beginPage("p"); B:add(held_rec(1))
    local ok2, st = pcall(function() return B:stats() end)
    check("a throwing bytes: stats still answer (bytes 0)", ok2 and st.records == 1 and st.bytes == 0)
end

-- the holder never frees, whatever it does ------------------------------------------------
check("no bitmap was ever freed by the holder in any scenario above", frees == 0, frees)

print(string.format("test_bo_ahead: %d passed, %d failed", passes, fails))
return fails > 0
