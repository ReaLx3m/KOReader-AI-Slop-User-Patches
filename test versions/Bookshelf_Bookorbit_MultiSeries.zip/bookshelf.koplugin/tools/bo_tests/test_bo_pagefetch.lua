-- Page fetch, Batch 5: pure page-list fetcher core. Off-device; no KOReader, no
-- network, no real forks (a fake world stands in for every dep). Proves the
-- LOGIC only (not run on a device). The fetcher is NOT wired into the UI yet.
package.path = PLUGIN .. "/?.lua;" .. package.path
local fails, passes = 0, 0
local function check(n, c, x)
    if c then passes = passes + 1
    else fails = fails + 1; print("FAIL: " .. n .. (x ~= nil and (" -> " .. tostring(x)) or "")) end
end

local PF = require("lib/bookshelf_bookorbit_pagefetch")

-- Fake world ------------------------------------------------------------------
local function world(opts)
    opts = opts or {}
    local w = {
        t = 0, timers = {}, files = {}, forks = {}, next_pid = 0,
        spawned = {}, kills = {}, removed = {}, loaded = {}, ready = {}, workers = {},
        online = true, fork_ok = true, bad_body = {}, in_api = 0, api_cb = 0,
    }
    local function path_of(req) return "/p/page_" .. tostring(req.k) .. ".json" end
    local deps = {
        now = function() return w.t end,
        schedule = function(delay, fn)
            local h = { at = w.t + delay, fn = fn, live = true }
            w.timers[#w.timers + 1] = h
            return h
        end,
        unschedule = function(h) if h then h.live = false end end,
        online = function() return w.online end,
        exists = function(path) return w.files[path] == true end,
        describe = function(req)
            if req.bad_describe then error("describe boom") end
            if req.skip then return nil end
            return { key = "page:" .. tostring(req.k), path = path_of(req), part = path_of(req) .. ".part" }
        end,
        spawn = function(job)
            if opts.spawn_throws then error("spawn boom") end
            if not w.fork_ok then return nil, "no fork" end
            w.next_pid = w.next_pid + 1
            local pid = w.next_pid
            w.forks[pid] = { job = job, done = false, out = "", killed = false }
            w.spawned[#w.spawned + 1] = job.key
            return pid, "fd" .. pid
        end,
        is_done = function(pid)
            local f = w.forks[pid]
            if not f then return true end
            if f.done_after and w.t >= f.done_after then f.done = true end
            return f.done
        end,
        readable = function(fd) local f = w.forks[tonumber(fd:sub(3))]; return f and f.out ~= "" end,
        read = function(fd)
            local f = w.forks[tonumber(fd:sub(3))]
            local o = f and f.out or ""
            if f then f.out = "" end
            return o
        end,
        kill = function(pid)
            w.kills[#w.kills + 1] = pid
            local f = w.forks[pid]
            if f then f.killed = true; f.done_after = w.t + (opts.reap_delay or 0) end
        end,
        remove = function(path) w.removed[#w.removed + 1] = path; w.files[path] = nil end,
        load = function(job)
            if opts.load_throws then error("load boom") end
            w.loaded[#w.loaded + 1] = job.key
            return w.bad_body[job.key] ~= true
        end,
        on_ready = function(info, ok, why)
            w.ready[#w.ready + 1] = { key = info.key, ok = ok, why = why, urgent = info.urgent, n = #info.reqs, req = info.req }
            if w.ready_hook then w.ready_hook(info, ok, why) end
            if opts.ready_throws then error("ready boom") end
        end,
        on_worker = function(i) w.workers[#w.workers + 1] = i end,
        width = opts.width, deadline = opts.deadline, fail_retry_after = opts.fail_retry_after,
    }
    w.deps = deps
    w.pf = PF.new(deps)
    function w.advance(dt)
        local target = w.t + dt
        while true do
            local nxt
            for _, h in ipairs(w.timers) do
                if h.live and h.at <= target and (not nxt or h.at < nxt.at) then nxt = h end
            end
            if not nxt then break end
            w.t = math.max(w.t, nxt.at)
            nxt.live = false
            nxt.fn()
        end
        w.t = target
    end
    function w.live_timers()
        local n = 0
        for _, h in ipairs(w.timers) do if h.live then n = n + 1 end end
        return n
    end
    -- Finish a worker: out = "1" creates the body file, anything else does not.
    function w.finish(pid, out, done)
        local f = w.forks[pid]
        f.out = out
        f.done = done ~= false
        if out == "1" then w.files[f.job.path] = true end
    end
    function w.req(k, urgent) return { k = k, urgent = urgent } end
    return w
end

local function key(k) return "page:" .. tostring(k) end
local function spawned(w) return #w.spawned end

-- constants ----------------------------------------------------------------------
check("default width 2", PF.DEFAULT_WIDTH == 2)
check("default deadline 30", PF.DEFAULT_DEADLINE == 30)
check("default fail retry 10", PF.DEFAULT_FAIL_RETRY_AFTER == 10)
check("max pending 4", PF.MAX_PENDING == 4)

-- invalid requests ---------------------------------------------------------------
do
    local w = world()
    check("describe nil -> invalid", w.pf:request({ k = 1, skip = true }) == "invalid")
    check("describe throws -> invalid", w.pf:request({ k = 1, bad_describe = true }) == "invalid")
    check("nothing scheduled for invalid", w.live_timers() == 0)
    check("status of an unknown key", w.pf:status(key(9)) == "none")
end

-- basic flow ---------------------------------------------------------------------
do
    local w = world()
    check("first request queued", w.pf:request(w.req(1, true)) == "queued")
    check("status pending before launch", w.pf:status(key(1)) == "pending")
    check("no fork inside request()", spawned(w) == 0)
    check("no callback inside request()", #w.ready == 0)
    w.advance(0.03)
    check("worker launched after the first poll", spawned(w) == 1, spawned(w))
    check("status loading while in flight", w.pf:status(key(1)) == "loading")
    w.advance(1)
    w.finish(1, "1")
    w.advance(0.5)
    check("body loaded once", #w.loaded == 1 and w.loaded[1] == key(1), #w.loaded)
    check("body file removed after load", w.files["/p/page_1.json"] == nil)
    check("on_ready fired once with ok", #w.ready == 1 and w.ready[1].ok == true and w.ready[1].key == key(1), #w.ready)
    check("urgent flag carried to on_ready", w.ready[1].urgent == true)
    check("status none after ready", w.pf:status(key(1)) == "none")
    check("everything drained, no timers left", w.live_timers() == 0, w.live_timers())
    local c = w.pf:counts()
    check("counts all zero", c.pending == 0 and c.in_flight == 0 and c.loading == 0 and c.reports == 0)
end

-- dedup / join -------------------------------------------------------------------
do
    local w = world()
    check("preload request queued", w.pf:request(w.req(2, false)) == "queued")
    check("second request for same key joins", w.pf:request(w.req(2, true)) == "joined")
    check("third request joins too", w.pf:request(w.req(2, false)) == "joined")
    w.advance(0.03)
    check("one fork for three requests", spawned(w) == 1, spawned(w))
    check("a request joining an in-flight job answers joined", w.pf:request(w.req(2, true)) == "joined")
    w.finish(1, "1")
    w.advance(0.5)
    check("one on_ready for the job", #w.ready == 1, #w.ready)
    check("the join made the job urgent", w.ready[1].urgent == true)
    check("all four requests carried", w.ready[1].n == 4, w.ready[1].n)
    -- joining while the body waits for its load tick
    local w2 = world()
    w2.pf:request(w2.req(3, false)); w2.advance(0.03); w2.finish(1, "1")
    w2.advance(0.16)    -- poll collected it, load tick may not have run yet or just did
    local ans = w2.pf:request(w2.req(3, true))
    check("request after completion is joined or a fresh fork", ans == "joined" or ans == "queued", ans)
end

-- preload then render: one fork, ready carries the key (C19/R14) -----------------------------------
do
    local w = world()
    w.pf:request(w.req(5, false))           -- the preload asks for the next page
    w.advance(0.5)
    check("preload fork running", spawned(w) == 1 and w.pf:status(key(5)) == "loading")
    check("user turns onto it: join, no second fork", w.pf:request(w.req(5, true)) == "joined" and spawned(w) == 1)
    w.finish(1, "1"); w.advance(0.5)
    check("exactly one on_ready for the key", #w.ready == 1 and w.ready[1].key == key(5))
    check("urgent because a render joined", w.ready[1].urgent == true)
    -- a pure preload: nobody waits, urgent false (the widget will only warm)
    local w2 = world()
    w2.pf:request(w2.req(6, false)); w2.advance(0.03); w2.finish(1, "1"); w2.advance(0.5)
    check("pure preload reports urgent=false", #w2.ready == 1 and w2.ready[1].urgent == false)
end

-- width and order ----------------------------------------------------------------------
do
    local w = world()
    for i = 1, 4 do w.pf:request(w.req(i, true)) end
    w.advance(0.1)
    check("width 2: two workers", spawned(w) == 2, spawned(w))
    check("newest urgent request launches first", w.spawned[1] == key(4) and w.spawned[2] == key(3), table.concat(w.spawned, ","))
    w.finish(1, "1"); w.advance(0.4)
    check("a slot freed -> third worker launched", spawned(w) == 3, spawned(w))
    check("then the next newest", w.spawned[3] == key(2), w.spawned[3])
end
do
    local w = world({ width = 3 })
    for i = 1, 5 do w.pf:request(w.req(i, true)) end
    w.advance(0.1)
    -- MAX_PENDING 4 -> 5 urgent requests are never dropped
    check("configured width honoured", spawned(w) == 3, spawned(w))
    check("urgent jobs never dropped (5 kept)", w.pf:counts().pending + w.pf:counts().in_flight == 5)
    local w2 = world({ width = 0 })
    check("width floor 1", (function() w2.pf:request(w2.req(1, true)); w2.pf:request(w2.req(2, true)); w2.advance(0.1); return spawned(w2) end)() == 1)
end

-- urgent before preload; newest first ---------------------------------------------------------
do
    local w = world()
    w.pf:request(w.req(1, true)); w.pf:request(w.req(2, true))   -- fill both slots
    w.advance(0.1)
    w.pf:request(w.req(10, false))
    w.pf:request(w.req(11, false))
    w.pf:request(w.req(12, true))
    local order = {}
    w.finish(1, "1"); w.advance(0.4)
    check("urgent job jumps the preload queue", w.spawned[3] == key(12), w.spawned[3])
    w.finish(2, "1"); w.advance(0.4)
    check("then newest preload first", w.spawned[4] == key(11), w.spawned[4])
end
-- a later preload never overtakes an earlier urgent request
do
    local w = world()
    w.pf:request(w.req(1, true)); w.pf:request(w.req(2, true)); w.advance(0.1)
    w.pf:request(w.req(40, true))
    w.pf:request(w.req(41, false))
    w.finish(1, "1"); w.advance(0.4)
    check("an earlier urgent job launches before a later preload", w.spawned[3] == key(40), w.spawned[3])
end
-- a join upgrades a pending preload
do
    local w = world()
    w.pf:request(w.req(1, true)); w.pf:request(w.req(2, true)); w.advance(0.1)
    w.pf:request(w.req(20, false)); w.pf:request(w.req(21, false))
    w.pf:request(w.req(20, true))      -- the user turned onto the older preload
    w.finish(1, "1"); w.advance(0.4)
    check("joining urgently moves a pending job to the front", w.spawned[3] == key(20), w.spawned[3])
end

-- MAX_PENDING: oldest preload dropped ---------------------------------------------------------
do
    local w = world()
    w.pf:request(w.req(1, true)); w.pf:request(w.req(2, true)); w.advance(0.1)  -- both slots busy
    for i = 30, 35 do w.pf:request(w.req(i, false)) end
    local c = w.pf:counts()
    check("pending capped at 4", c.pending == 4, c.pending)
    check("the oldest preloads were dropped", w.pf:status(key(30)) == "none" and w.pf:status(key(31)) == "none")
    check("the newest preloads kept", w.pf:status(key(35)) == "pending" and w.pf:status(key(32)) == "pending")
    check("dropping fires no callback", #w.ready == 0)
    -- a queue full of urgent jobs refuses a background request
    local w2 = world()
    w2.pf:request(w2.req(1, true)); w2.pf:request(w2.req(2, true)); w2.advance(0.1)
    for i = 3, 6 do w2.pf:request(w2.req(i, true)) end
    check("full of urgent: background request is busy", w2.pf:request(w2.req(99, false)) == "busy")
    check("and nothing was lost", w2.pf:counts().pending == 4)
end

-- supersede keeps in-flight ---------------------------------------------------------------------
do
    local w = world()
    w.pf:request(w.req(1, true)); w.pf:request(w.req(2, true)); w.pf:request(w.req(3, true))
    w.advance(0.1)
    check("two in flight, one pending", w.pf:counts().in_flight == 2 and w.pf:counts().pending == 1)
    w.pf:cancelPending()
    check("cancelPending drops pending only", w.pf:counts().pending == 0 and w.pf:counts().in_flight == 2)
    check("no kill on cancelPending", #w.kills == 0)
    check("no callback on cancelPending", #w.ready == 0)
    w.finish(1, "1"); w.finish(2, "1"); w.advance(0.5)
    check("in-flight jobs still land after a supersede", #w.ready == 2 and w.ready[1].ok and w.ready[2].ok, #w.ready)
    check("the cancelled job was never forked", spawned(w) == 2)
    check("a cancelled key can be requested again", w.pf:request(w.req(3, true)) == "queued")
end

-- definitive failure -----------------------------------------------------------------------------
do
    local w = world()
    w.pf:request(w.req(1, true)); w.advance(0.1)
    w.finish(1, "nf:http_500"); w.advance(0.5)
    check("nf: reported as failed with the reason", #w.ready == 1 and w.ready[1].ok == false and w.ready[1].why == "http_500", w.ready[1] and w.ready[1].why)
    check("nothing was loaded", #w.loaded == 0)
    check("status failed", w.pf:status(key(1)) == "failed")
    check("request right after a failure answers failed (no retry loop)", w.pf:request(w.req(1, true)) == "failed")
    check("no new fork", spawned(w) == 1)
    w.advance(11)
    check("after the cool-down a new attempt starts", w.pf:request(w.req(1, true)) == "queued")
    w.advance(0.1)
    check("second fork launched", spawned(w) == 2)
    -- resetFailures clears at once
    local w2 = world()
    w2.pf:request(w2.req(1, true)); w2.advance(0.1); w2.finish(1, "nf:http_404"); w2.advance(0.5)
    w2.pf:resetFailures()
    check("resetFailures re-opens a failed key", w2.pf:request(w2.req(1, true)) == "queued")
    check("a failure does not narrow the width (server said no)", w2.pf:counts().cap == 2)
end

-- bad body -----------------------------------------------------------------------------------------
do
    local w = world()
    w.bad_body[key(1)] = true
    w.pf:request(w.req(1, true)); w.advance(0.1); w.finish(1, "1"); w.advance(0.5)
    check("load false -> failed bad_body", #w.ready == 1 and w.ready[1].ok == false and w.ready[1].why == "bad_body")
    check("the body file is removed anyway", w.files["/p/page_1.json"] == nil)
    check("bad body is sticky for the cool-down", w.pf:request(w.req(1, true)) == "failed")
    local w2 = world({ load_throws = true })
    w2.pf:request(w2.req(1, true)); w2.advance(0.1); w2.finish(1, "1"); w2.advance(0.5)
    check("a throwing load is a bad body, not a crash", #w2.ready == 1 and w2.ready[1].why == "bad_body")
end

-- "1" without a file / crash ----------------------------------------------------------------------
do
    local w = world()
    w.pf:request(w.req(1, true)); w.advance(0.1)
    local f = w.forks[1]; f.out = "1"; f.done = true      -- "ok" but no body file
    w.advance(0.5)
    check("ok without a file is a crash: one automatic retry", spawned(w) == 2, spawned(w))
    check("no report yet after the first crash", #w.ready == 0)
    w.forks[2].out = ""; w.forks[2].done = true; w.advance(0.5)
    check("second crash is reported failed", #w.ready == 1 and w.ready[1].ok == false and w.ready[1].why == "crash", w.ready[1] and w.ready[1].why)
    check("crash cleans the .part", (function() for _, p in ipairs(w.removed) do if p:match("%.part$") then return true end end end)() == true)
    -- a crash that retries successfully
    local w2 = world()
    w2.pf:request(w2.req(1, true)); w2.advance(0.1)
    w2.forks[1].out = ""; w2.forks[1].done = true; w2.advance(0.5)
    w2.finish(2, "1"); w2.advance(0.5)
    check("retry after a crash can succeed", #w2.ready == 1 and w2.ready[1].ok == true)
end

-- deadline ---------------------------------------------------------------------------------------------
do
    local w = world()
    w.pf:request(w.req(1, true)); w.advance(0.1)
    w.advance(29)
    check("not killed before the deadline", #w.kills == 0)
    w.advance(2)
    check("killed after the deadline", #w.kills == 1 and w.kills[1] == 1, #w.kills)
    check("part file removed on kill", (function() for _, p in ipairs(w.removed) do if p == "/p/page_1.json.part" then return true end end end)() == true)
    check("timeout reported as failed", #w.ready == 1 and w.ready[1].ok == false and w.ready[1].why == "timeout", w.ready[1] and w.ready[1].why)
    check("on_worker timeout", (function() for _, i in ipairs(w.workers) do if i.result == "timeout" then return true end end end)() == true)
    check("timed-out key is sticky for the cool-down", w.pf:request(w.req(1, true)) == "failed")
end
do
    -- width narrows to 1 after a timeout while others still run
    local w = world({ width = 2 })
    w.pf:request(w.req(1, true)); w.pf:request(w.req(2, true)); w.pf:request(w.req(3, true)); w.advance(0.1)
    -- keep job 2 alive by finishing it late; let job 1 time out
    w.advance(30.5)
    check("one timed out and the width halved", w.pf:counts().cap == 1, w.pf:counts().cap)
end

-- reaper -------------------------------------------------------------------------------------------------
do
    local w = world({ reap_delay = 3 })
    w.pf:request(w.req(1, true)); w.advance(0.1)
    w.advance(30.5)
    check("the deadline kill happened", #w.kills == 1, #w.kills)
    check("killed pid waits to be reaped (not done for 3 s)", w.pf:counts().reaping == 1, w.pf:counts().reaping)
    check("a reaper timer is alive meanwhile", w.live_timers() >= 1)
    w.advance(5)
    check("zombie collected after is_done", w.pf:counts().reaping == 0, w.pf:counts().reaping)
    check("reaper timer stops when done", w.live_timers() == 0, w.live_timers())
end

-- offline ------------------------------------------------------------------------------------------------
do
    local w = world()
    w.online = false
    check("request offline -> offline", w.pf:request(w.req(1, true)) == "offline")
    check("nothing scheduled", w.live_timers() == 0 and spawned(w) == 0)
    -- goes offline while jobs wait
    local w2 = world()
    w2.pf:request(w2.req(1, true)); w2.pf:request(w2.req(2, true)); w2.pf:request(w2.req(3, true))
    w2.advance(0.1)
    w2.online = false
    w2.advance(0.5)
    check("waiting jobs told offline", (function()
        local n = 0
        for _, r in ipairs(w2.ready) do if r.why == "offline" and r.ok == false then n = n + 1 end end
        return n == 1
    end)(), #w2.ready)
    -- newest-first: keys 3 and 2 were launched, key 1 was the pending one told "offline"
    check("the pending job (key 1) was the one told offline", w2.ready[1] and w2.ready[1].key == key(1), w2.ready[1] and w2.ready[1].key)
    w2.online = true
    local ans_off = w2.pf:request(w2.req(1, true))
    check("offline is not a failure: key can be requested again", ans_off == "queued", ans_off)
    check("a key still in flight is joined, not duplicated", w2.pf:request(w2.req(3, true)) == "joined")
    -- a worker that reports nf:offline
    local w3 = world()
    w3.pf:request(w3.req(1, true)); w3.advance(0.1); w3.finish(1, "nf:offline"); w3.advance(0.5)
    check("nf:offline reported, not sticky", #w3.ready == 1 and w3.ready[1].why == "offline" and w3.pf:status(key(1)) == "none")
end

-- fork broken ---------------------------------------------------------------------------------------------
do
    local w = world()
    w.fork_ok = false
    w.pf:request(w.req(1, true)); w.pf:request(w.req(2, true)); w.pf:request(w.req(3, false))
    w.advance(0.5)
    check("every waiting job told fork_broken", #w.ready == 3, #w.ready)
    check("reason is fork_broken", w.ready[1].why == "fork_broken" and w.ready[3].why == "fork_broken")
    check("later requests answer fork_broken", w.pf:request(w.req(9, true)) == "fork_broken")
    check("fork_broken is not a sticky failure", w.pf:status(key(1)) == "none")
    local w2 = world({ spawn_throws = true })
    w2.pf:request(w2.req(1, true)); w2.advance(0.5)
    check("a throwing spawn is fork_broken too", w2.pf:request(w2.req(2, true)) == "fork_broken")
end

-- callbacks only from timers --------------------------------------------------------------------------------
do
    local w = world()
    local seen_in_api = false
    w.pf:request(w.req(1, true)); w.advance(0.1); w.finish(1, "1")
    w.advance(0.5)
    w.pf:request(w.req(2, true))
    w.pf:cancelPending()
    w.pf:shutdown()
    check("no callback fired by request/cancel/shutdown", #w.ready == 1)
end

-- re-entrant request from on_ready ------------------------------------------------------------------------------
do
    local w = world()
    local again
    w.ready_hook = function(info, ok)
        if info.key == key(1) and ok then again = w.pf:request(w.req(2, true)) end
    end
    w.pf:request(w.req(1, true)); w.advance(0.1); w.finish(1, "1"); w.advance(0.5)
    check("on_ready may call request()", again == "queued", again)
    w.advance(0.1)
    check("the re-entrant request got its own fork", spawned(w) == 2, spawned(w))
    w.finish(2, "1"); w.advance(0.5)
    check("and its own ready", #w.ready == 2 and w.ready[2].key == key(2))
    -- a failing callback for the same key does not start a retry loop
    local w2 = world()
    local ans
    w2.ready_hook = function(info, ok)
        if not ok then ans = w2.pf:request(w2.req(1, true)) end
    end
    w2.pf:request(w2.req(1, true)); w2.advance(0.1); w2.finish(1, "nf:http_500"); w2.advance(0.5)
    check("rebuild-after-failure cannot start a retry", ans == "failed", ans)
    check("still only one fork", spawned(w2) == 1)
end

-- throwing deps ------------------------------------------------------------------------------------------------------
do
    local w = world({ ready_throws = true })
    w.pf:request(w.req(1, true)); w.pf:request(w.req(2, true)); w.advance(0.1)
    w.finish(1, "1"); w.finish(2, "1"); w.advance(1)
    check("a throwing on_ready does not stop the next one", #w.ready == 2, #w.ready)
    check("and everything drains", w.pf:counts().reports == 0 and w.live_timers() == 0, w.live_timers())
end

-- load budget: one per tick ----------------------------------------------------------------------------------------------
do
    local w = world({ width = 2 })
    w.pf:request(w.req(1, true)); w.pf:request(w.req(2, true)); w.advance(0.1)
    w.finish(1, "1"); w.finish(2, "1")
    w.advance(0.075)      -- t=0.175: the 0.17 poll collected both, no load tick has run yet
    check("collected but not yet loaded", #w.loaded == 0, #w.loaded)
    w.advance(0.02)       -- t=0.195: first load tick (0.19)
    check("first tick loads exactly one body", #w.loaded == 1, #w.loaded)
    w.advance(0.02)       -- t=0.215: second tick (0.21)
    check("second tick loads the other", #w.loaded == 2, #w.loaded)
end

-- shutdown -----------------------------------------------------------------------------------------------------------------
do
    local w = world()
    w.pf:request(w.req(1, true)); w.pf:request(w.req(2, true)); w.pf:request(w.req(3, true)); w.advance(0.1)
    w.finish(1, "1")      -- one finished body waiting for its load
    w.advance(0.16)
    w.pf:request(w.req(4, false))
    w.pf:shutdown()
    check("shutdown killed the running workers", #w.kills >= 1, #w.kills)
    check("shutdown cleared everything", (function()
        local c = w.pf:counts()
        return c.pending == 0 and c.in_flight == 0 and c.loading == 0 and c.reports == 0 and c.chain_active == false
    end)())
    check("shutdown removed the part files", (function() for _, p in ipairs(w.removed) do if p:match("page_2%.json%.part$") then return true end end end)() == true)
    local ready_before = #w.ready
    w.advance(5)
    check("no callbacks after shutdown", #w.ready == ready_before, #w.ready - ready_before)
    check("a request after shutdown works again", w.pf:request(w.req(7, true)) == "queued")
    local before = spawned(w)
    w.advance(0.1)
    check("and forks again", spawned(w) == before + 1, spawned(w))
end

-- status shape ---------------------------------------------------------------------------------------------------------------
do
    local w = world()
    local c = w.pf:counts()
    check("counts shape", c.pending == 0 and c.in_flight == 0 and c.loading == 0 and c.reports == 0
        and c.reaping == 0 and c.cap == 2 and c.fork_broken == false and c.chain_active == false)
    w.pf:request(w.req(1, true))
    check("one poll timer only", w.live_timers() == 1, w.live_timers())
end

-- width resets after the chain drains ------------------------------------------------------------------------------------------
do
    local w = world()
    w.pf:request(w.req(1, true)); w.advance(0.1); w.advance(31)
    w.advance(1)
    check("width reset after drain", w.pf:counts().cap == 2, w.pf:counts().cap)
end

-- ready info carries the first request ------------------------------------------------------------------------------------------
do
    local w = world()
    local first = w.req(8, false)
    w.pf:request(first); w.pf:request(w.req(8, true))
    w.advance(0.1); w.finish(1, "1"); w.advance(0.5)
    check("info.req is the first request", w.ready[1].req == first)
end

-- counts().urgent (prefetch P1): "is a render path still waiting for a page?" -----------------------------------------------------------------------------------
do
    local w = world()
    check("urgent: none at start", w.pf:counts().urgent == 0)
    w.pf:request(w.req(1, false))
    check("urgent: a background job is not urgent", w.pf:counts().urgent == 0)
    w.pf:request(w.req(2, true))
    check("urgent: a queued urgent job counts", w.pf:counts().urgent == 1, w.pf:counts().urgent)
    w.pf:request(w.req(1, true))
    check("urgent: joining with urgent makes the job urgent", w.pf:counts().urgent == 2, w.pf:counts().urgent)
    w.advance(0.03)
    check("urgent: still counted in flight", w.pf:counts().urgent == 2, w.pf:counts().urgent)
    w.finish(1, "1")
    w.advance(0.1)
    -- body on disk, loaded but not yet reported -> still counted until on_ready ran
    w.advance(2)
    w.finish(2, "1")
    w.advance(2)
    check("urgent: zero once everything was reported", w.pf:counts().urgent == 0 and #w.ready == 2, w.pf:counts().urgent)
end

do -- a failed urgent job stops counting; cancelPending and shutdown drop it
    local w = world()
    w.pf:request(w.req(1, true)); w.advance(0.03)
    w.finish(1, "nf:http_500"); w.advance(1)
    check("urgent: a failed job no longer counts", w.pf:counts().urgent == 0 and w.ready[1].ok == false)
    local w2 = world({ width = 1 })
    w2.pf:request(w2.req(1, false)); w2.advance(0.03)
    w2.pf:request(w2.req(2, true))
    check("urgent: pending urgent job counted", w2.pf:counts().urgent == 1)
    w2.pf:cancelPending()
    check("urgent: cancelPending drops it", w2.pf:counts().urgent == 0)
    w2.pf:request(w2.req(3, true))
    w2.pf:shutdown()
    check("urgent: shutdown drops it", w2.pf:counts().urgent == 0)
end

do -- loaded but not yet reported: the render path is still waiting, so it still counts
    local w = world()
    w.pf:request(w.req(1, true)); w.advance(0.03)
    w.finish(1, "1")
    local seen_waiting = false
    for _ = 1, 60 do
        w.advance(0.005)
        local c = w.pf:counts()
        if c.reports == 1 and #w.ready == 0 then
            seen_waiting = true
            check("urgent: counted while the report is queued", c.urgent == 1, c.urgent)
        end
    end
    check("urgent: the loaded-not-yet-reported state was observed", seen_waiting)
    check("urgent: zero after on_ready", w.pf:counts().urgent == 0 and #w.ready == 1)
end

print(string.format("test_bo_pagefetch: %d passed, %d failed", passes, fails))
return fails > 0
