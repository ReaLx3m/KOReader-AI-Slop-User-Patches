-- Section freshness, Batches 1-3: pure helpers + controller core + glue. Off-device; no KOReader, no
-- network. Proves the LOGIC only (not run on a device).
-- NOTE: the real bookshelf_bookorbit_source.lua cannot be loaded under these
-- stubs (known limit), so its section wiring is parse-checked only; the toRecord
-- used here is a minimal stand-in with the same field names.
package.path = PLUGIN .. "/?.lua;" .. package.path
local fails, passes = 0, 0
local function check(n, c, x)
    if c then passes = passes + 1
    else fails = fails + 1; print("FAIL: " .. n .. (x ~= nil and (" -> " .. tostring(x)) or "")) end
end

local Fresh = require("lib/bookshelf_bookorbit_fresh")

-- Stand-in for BOSource.toRecord (same field names the helpers read).
local function toRecord(b)
    local pct = tonumber(b.progressPercentage) or 0
    if pct > 1 then pct = pct / 100 end
    return { remote_id = b.id, title = b.title or "Untitled",
             bookorbit_read_status = b.readStatus, updated_at = b.updatedAt,
             book_pct = pct }
end
local function rec(id, st, upd, pct)
    return { remote_id = id, bookorbit_read_status = st, updated_at = upd, book_pct = pct }
end

-- signature ---------------------------------------------------------------
local base = { rec(1, "reading", "t1", 0.10), rec(2, "unread", "t2", 0) }
local s0 = Fresh.signature(base)
check("sig: string", type(s0) == "string" and s0 ~= "")
check("sig: stable", Fresh.signature({ rec(1, "reading", "t1", 0.10), rec(2, "unread", "t2", 0) }) == s0)
check("sig: order sensitive", Fresh.signature({ base[2], base[1] }) ~= s0)
check("sig: id sensitive", Fresh.signature({ rec(9, "reading", "t1", 0.10), base[2] }) ~= s0)
check("sig: status sensitive", Fresh.signature({ rec(1, "finished", "t1", 0.10), base[2] }) ~= s0)
check("sig: updated_at sensitive", Fresh.signature({ rec(1, "reading", "t9", 0.10), base[2] }) ~= s0)
check("sig: progress change >= 0.5% seen", Fresh.signature({ rec(1, "reading", "t1", 0.20), base[2] }) ~= s0)
check("sig: float noise ignored", Fresh.signature({ rec(1, "reading", "t1", 0.1001), base[2] }) == s0)
check("sig: added book seen", Fresh.signature({ base[1], base[2], rec(3, "unread", "t3", 0) }) ~= s0)
check("sig: nil -> empty string", Fresh.signature(nil) == "")
check("sig: empty -> empty string", Fresh.signature({}) == "")
check("sig: nil fields tolerated", type(Fresh.signature({ { remote_id = 5 } })) == "string")
check("sig: no field-merge collision",
    Fresh.signature({ rec("1", "ab", "c", 0) }) ~= Fresh.signature({ rec("1", "a", "bc", 0) }))
local many = {}
for i = 1, 30 do many[#many + 1] = rec(i, "unread", "t", 0) end
local sk = Fresh.signature(many, 3)
many[10].updated_at = "changed"
check("sig: only first k records count", Fresh.signature(many, 3) == sk)
check("sig: record past k but inside default is seen", Fresh.signature(many) ~= Fresh.signature(many, 3))
local m30 = {}
for i = 1, 30 do m30[#m30 + 1] = rec(i, "unread", "t", 0) end
local d0 = Fresh.signature(m30)
m30[30].updated_at = "x"
check("sig: default k is 24 (record 30 ignored)", Fresh.signature(m30) == d0)
m30[24].updated_at = "x"
check("sig: record 24 seen", Fresh.signature(m30) ~= d0)

-- sectionToRecords --------------------------------------------------------
local body = { section = { books = {
    { id = 7, title = "B7" }, { id = 3, title = "B3", readStatus = "reading" }, { id = 5 } } } }
local recs, meta = Fresh.sectionToRecords(body, toRecord)
check("s2r: count", #recs == 3 and meta.count == 3)
check("s2r: server order kept", recs[1].remote_id == 7 and recs[2].remote_id == 3 and recs[3].remote_id == 5)
check("s2r: missing readStatus filled", recs[1].bookorbit_read_status == "want_to_read")
check("s2r: existing readStatus kept", recs[2].bookorbit_read_status == "reading")
check("s2r: input not mutated", body.section.books[1].readStatus == nil)
check("s2r: minimal book ok", recs[3].title == "Untitled")
check("s2r: keys listed sorted", meta.keys[1] == "books" and #meta.keys == 1)
check("s2r: section returned in meta", meta.section == body.section)
local e1, em = Fresh.sectionToRecords(nil, toRecord)
check("s2r: nil body -> empty", #e1 == 0 and em.count == 0)
local e2 = Fresh.sectionToRecords({ section = {} }, toRecord)
check("s2r: no books -> empty", #e2 == 0)
local e3 = Fresh.sectionToRecords({ section = { books = { "junk", { title = "no id" }, { id = 1 } } } }, toRecord)
check("s2r: junk and id-less entries skipped", #e3 == 1 and e3[1].remote_id == 1)

-- sectionLooksTruncated ---------------------------------------------------
check("trunc: unknown shape false", Fresh.sectionLooksTruncated({ books = {} }, 3) == false)
check("trunc: nil false", Fresh.sectionLooksTruncated(nil, 3) == false)
check("trunc: total > n", Fresh.sectionLooksTruncated({ total = 10 }, 3) == true)
check("trunc: total == n", Fresh.sectionLooksTruncated({ total = 3 }, 3) == false)
check("trunc: totalCount > n", Fresh.sectionLooksTruncated({ totalCount = 4 }, 3) == true)
check("trunc: count > n", Fresh.sectionLooksTruncated({ count = 9 }, 3) == true)
check("trunc: total as string", Fresh.sectionLooksTruncated({ total = "12" }, 3) == true)
check("trunc: hasNext true", Fresh.sectionLooksTruncated({ hasNext = true }, 3) == true)
check("trunc: hasNext false", Fresh.sectionLooksTruncated({ hasNext = false }, 3) == false)
check("trunc: hasMore true", Fresh.sectionLooksTruncated({ hasMore = true }, 3) == true)
check("trunc: nextPage 2", Fresh.sectionLooksTruncated({ nextPage = 2 }, 3) == true)
check("trunc: nextPage 0", Fresh.sectionLooksTruncated({ nextPage = 0 }, 3) == false)
check("trunc: nextPage token", Fresh.sectionLooksTruncated({ nextPage = "abc" }, 3) == true)
check("trunc: nextPage empty string", Fresh.sectionLooksTruncated({ nextPage = "" }, 3) == false)

-- mergeOrder --------------------------------------------------------------
local walked = { rec(1, "want_to_read", "w", 0), rec(2, "want_to_read", "w", 0),
                 rec(3, "want_to_read", "w", 0), rec(4, "want_to_read", "w", 0) }
local m = Fresh.mergeOrder({ 3, 1 }, walked)
check("merge: ids -> section first then walk rest",
    #m == 4 and m[1].remote_id == 3 and m[2].remote_id == 1 and m[3].remote_id == 2 and m[4].remote_id == 4)
check("merge: walked record preferred", m[1] == walked[3])
local srec = { rec(9, "want_to_read", "s", 0) }
local m2 = Fresh.mergeOrder({ srec[1], walked[2] }, walked)
check("merge: section-only record kept, first", m2[1] == srec[1] and m2[2] == walked[2])
check("merge: no duplicates", #m2 == 5)
local m3 = Fresh.mergeOrder({ 99 }, walked)
check("merge: unknown id without record skipped", #m3 == 4 and m3[1].remote_id == 1)
local m4 = Fresh.mergeOrder({ 1, 1, 1 }, walked)
check("merge: repeated section id once", #m4 == 4)
check("merge: empty section -> walk order", #Fresh.mergeOrder({}, walked) == 4
    and Fresh.mergeOrder({}, walked)[1].remote_id == 1)
check("merge: empty walk -> section records", #Fresh.mergeOrder({ srec[1] }, {}) == 1)
check("merge: nils ok", #Fresh.mergeOrder(nil, nil) == 0)
check("merge: string vs number ids match", Fresh.mergeOrder({ "2" }, walked)[1] == walked[2])


-- =========================================================================
-- Controller (Batch 2). Fake clock, fake sync coordinator, fake Wi-Fi gate.
-- =========================================================================

local function newEnv(o)
    o = o or {}
    local E = {
        t = 1000, enabled = true, connected = true,
        chip = "continue:", kinds = { ["continue:"] = "continue", ["want_to_read:"] = "want_to_read" },
        sigs = {}, probes = {}, probe_calls = 0, probe_result = nil, probe_throw = false,
        stored = {}, invalidated = {}, changed = {}, submits = {}, submit_mode = "immediate",
        submit_throw = false, waits = {}, wait_throw = false, release_count = 0,
        on_changed_throw = false,
    }
    E.records = { rec(1, "reading", "t1", 0.1), rec(2, "unread", "t2", 0) }
    local deps = {
        now = function() return E.t end,
        enabled = function() return E.enabled end,
        connected = function() return E.connected end,
        current_chip = function() return E.chip end,
        kind_of = function(id) return E.kinds[id] end,
        probe = function(kind, id)
            E.probe_calls = E.probe_calls + 1
            if E.probe_throw then error("boom") end
            if E.probe_result == "fail" then return nil, "http 500" end
            return E.probe_result or E.records
        end,
        get_sig = function(id) return E.sigs[id] end,
        set_sig = function(id, sig) E.sigs[id] = sig end,
        store_records = function(kind, id, recs) E.stored[#E.stored + 1] = { kind, id, recs } end,
        invalidate = function(kind, id) E.invalidated[#E.invalidated + 1] = { kind, id } end,
        on_changed = function(kind, id)
            E.changed[#E.changed + 1] = { kind, id }
            if E.on_changed_throw then error("redraw boom") end
        end,
        submit = function(job)
            if E.submit_throw then error("submit boom") end
            E.submits[#E.submits + 1] = job
            local function runIt()
                pcall(job.run)            -- like SyncJobRunner: run, then cleanup
                if job.cleanup then pcall(job.cleanup) end
            end
            if E.submit_mode == "immediate" then runIt(); return "started" end
            if E.submit_mode == "drop" then
                if job.cleanup then pcall(job.cleanup) end
                return "kept"
            end
            job._run = runIt             -- "queue": test flushes later
            return "queued"
        end,
        wait_for_network = function(reason, on_ready, on_fail)
            if E.wait_throw then error("wait boom") end
            E.waits[#E.waits + 1] = { reason = reason, ready = on_ready, fail = on_fail }
        end,
        logger = { info = function() end, warn = function() end, dbg = function() end },
    }
    E.fc = Fresh.new(deps)
    -- A lease: afterDone counts releases (exactly once expected per ready).
    function E.afterDone() E.release_count = E.release_count + 1 end
    function E.flush() for _, j in ipairs(E.submits) do if j._run then local r = j._run; j._run = nil; r() end end end
    return E
end

-- unchanged: baseline equal -> no invalidate, no callback ----------------------
do
    local E = newEnv()
    E.sigs["continue:"] = Fresh.signature(E.records)
    check("ctl: submitted", E.fc:check("continue", "continue:") == "submitted")
    check("ctl: unchanged -> no invalidate", #E.invalidated == 0)
    check("ctl: unchanged -> no store", #E.stored == 0)
    check("ctl: unchanged -> no on_changed", #E.changed == 0)
    check("ctl: probed once", E.probe_calls == 1)
    check("ctl: job family", E.submits[1].family == "bo_fresh:continue:")
    check("ctl: job has cleanup", type(E.submits[1].cleanup) == "function")
    check("ctl: job has on_error", type(E.submits[1].on_error) == "function")
    check("ctl: unchanged keeps baseline", E.sigs["continue:"] == Fresh.signature(E.records))
end

-- changed (Continue): invalidate once, callback once ---------------------------
do
    local E = newEnv()
    E.sigs["continue:"] = "old signature"
    E.fc:check("continue", "continue:")
    check("ctl: changed -> invalidate once", #E.invalidated == 1 and E.invalidated[1][1] == "continue"
        and E.invalidated[1][2] == "continue:")
    check("ctl: continue never stores records", #E.stored == 0)
    check("ctl: changed -> on_changed once", #E.changed == 1 and E.changed[1][1] == "continue")
    check("ctl: baseline updated", E.sigs["continue:"] == Fresh.signature(E.records))
    E.t = E.t + 61
    E.fc:check("continue", "continue:")
    check("ctl: second check after change is unchanged", #E.invalidated == 1 and #E.changed == 1)
end

-- changed (Want to read): store the probed records, no invalidate -----------------
do
    local E = newEnv()
    E.sigs["want_to_read:"] = "old"
    E.fc:check("want_to_read", "want_to_read:")
    check("ctl: wtr stores probed records", #E.stored == 1 and E.stored[1][3] == E.records and E.stored[1][2] == "want_to_read:")
    check("ctl: wtr no invalidate", #E.invalidated == 0)
    check("ctl: wtr on_changed", #E.changed == 1 and E.changed[1][1] == "want_to_read")
end

-- no baseline: changed once (D5), then settles ---------------------------------
do
    local E = newEnv()
    E.fc:check("continue", "continue:")
    check("ctl: no baseline -> changed once", #E.invalidated == 1 and #E.changed == 1)
    check("ctl: baseline stored", E.sigs["continue:"] ~= nil)
    E.t = E.t + 61
    E.fc:check("continue", "continue:")
    check("ctl: settles", #E.invalidated == 1 and #E.changed == 1 and E.probe_calls == 2)
end

-- min interval 60 s, force ------------------------------------------------------
do
    local E = newEnv()
    E.fc:check("continue", "continue:")
    E.t = E.t + 30
    check("ctl: inside 60 s skipped", E.fc:check("continue", "continue:") == "interval")
    check("ctl: skipped did not probe", E.probe_calls == 1)
    check("ctl: force bypasses interval", E.fc:check("continue", "continue:", { force = true }) == "submitted"
        and E.probe_calls == 2)
    E.t = E.t + 59
    check("ctl: force reset the gap", E.fc:check("continue", "continue:") == "interval")
    E.t = E.t + 2
    check("ctl: after 60 s runs", E.fc:check("continue", "continue:") == "submitted")
    -- gaps are per chip
    check("ctl: other chip unaffected by the gap", E.fc:check("want_to_read", "want_to_read:") == "submitted")
end

-- chips that are not continue/want_to_read do nothing ------------------------------
do
    local E = newEnv()
    check("ctl: unknown chip ignored", E.fc:check("continue", "recent:") == "ignored")
    check("ctl: kind mismatch ignored", E.fc:check("want_to_read", "continue:") == "ignored")
    check("ctl: nil id ignored", E.fc:check("continue", nil) == "ignored")
    check("ctl: nothing probed or submitted", E.probe_calls == 0 and #E.submits == 0)
end

-- disabled / offline: silent, no backoff ---------------------------------------------
do
    local E = newEnv()
    E.enabled = false
    check("ctl: disabled", E.fc:check("continue", "continue:") == "disabled" and #E.submits == 0)
    E.enabled = true; E.connected = false
    check("ctl: offline skip", E.fc:check("continue", "continue:") == "offline" and #E.submits == 0)
    E.fc:check("continue", "continue:", { force = true })
    E.connected = true
    check("ctl: offline left no backoff", E.fc:check("continue", "continue:") == "submitted")
    check("ctl: offline left no gap", E.probe_calls == 1)
end

-- failure backoff: 120, 240, 360 ... capped 900; success resets -------------------------
do
    local E = newEnv()
    E.probe_result = "fail"
    check("ctl: failing check runs", E.fc:check("continue", "continue:") == "submitted")
    check("ctl: failure is no change", #E.invalidated == 0 and #E.changed == 0 and E.sigs["continue:"] == nil)
    E.t = E.t + 119
    check("ctl: backoff 120 holds", E.fc:check("continue", "continue:") == "backoff")
    E.t = E.t + 1
    check("ctl: backoff 120 over", E.fc:check("continue", "continue:") == "submitted")
    E.t = E.t + 239
    check("ctl: backoff 240 holds", E.fc:check("continue", "continue:") == "backoff")
    E.t = E.t + 1
    check("ctl: backoff 240 over", E.fc:check("continue", "continue:") == "submitted")
    E.t = E.t + 359
    check("ctl: backoff 360 holds", E.fc:check("continue", "continue:") == "backoff")
    E.t = E.t + 1
    -- keep failing up to the cap
    for _ = 1, 10 do E.fc:check("continue", "continue:"); E.t = E.t + 900 end
    local before = E.probe_calls
    E.fc:check("continue", "continue:")           -- fails again, backoff now capped at 900
    E.t = E.t + 899
    check("ctl: capped at 900 holds", E.fc:check("continue", "continue:") == "backoff")
    E.t = E.t + 1
    E.probe_result = nil
    check("ctl: capped over, succeeds", E.fc:check("continue", "continue:") == "submitted" and #E.changed == 1)
    E.t = E.t + 61
    E.probe_result = "fail"
    E.fc:check("continue", "continue:")
    E.t = E.t + 120
    check("ctl: success reset the count (back to 120)", E.fc:check("continue", "continue:") == "submitted")
    -- force bypasses backoff
    E.fc:check("continue", "continue:", { force = true })
    check("ctl: force bypasses backoff", E.fc:check("continue", "continue:", { force = true }) == "submitted")
end

-- throwing probe, probe returns nothing, throwing callbacks ----------------------------------
do
    local E = newEnv()
    E.probe_throw = true
    check("ctl: throwing probe tolerated", E.fc:check("continue", "continue:") == "submitted")
    E.t = E.t + 10
    check("ctl: throwing probe counts as a failure", E.fc:check("continue", "continue:") == "backoff")
    check("ctl: inflight cleared after throw", E.fc.inflight["continue:"] == nil)

    local E2 = newEnv()
    E2.on_changed_throw = true
    E2.fc:check("continue", "continue:")
    check("ctl: throwing on_changed is not a probe failure", E2.fc.fail_count["continue:"] == nil
        and E2.sigs["continue:"] ~= nil)

    local E3 = newEnv()
    E3.submit_throw = true
    check("ctl: submit throwing", E3.fc:check("continue", "continue:") == "submit_failed")
    check("ctl: inflight cleared after submit throw", E3.fc.inflight["continue:"] == nil)
end

-- in-flight dedupe ----------------------------------------------------------------------------
do
    local E = newEnv()
    E.submit_mode = "queue"
    check("ctl: queued", E.fc:check("continue", "continue:") == "submitted")
    check("ctl: second while in flight", E.fc:check("continue", "continue:", { force = true }) == "inflight")
    check("ctl: other chip not blocked", E.fc:check("want_to_read", "want_to_read:") == "submitted")
    check("ctl: nothing probed yet", E.probe_calls == 0)
    E.flush()
    check("ctl: both ran after flush", E.probe_calls == 2)
    check("ctl: inflight cleared", E.fc.inflight["continue:"] == nil)
    E.t = E.t + 61
    check("ctl: can check again", E.fc:check("continue", "continue:") == "submitted")
end

-- dropped job: cleanup + release exactly once -------------------------------------------------
do
    local E = newEnv()
    E.submit_mode = "drop"
    check("ctl: drop reported", E.fc:check("continue", "continue:", { release = E.afterDone }) == "submitted")
    check("ctl: dropped job never probed", E.probe_calls == 0)
    check("ctl: dropped job released the lease once", E.release_count == 1)
    check("ctl: dropped job cleared inflight", E.fc.inflight["continue:"] == nil)
end

-- release exactly once on every check path ----------------------------------------------------
do
    local E = newEnv()
    E.fc:check("continue", "continue:", { release = E.afterDone })
    check("ctl: release after run", E.release_count == 1)
    E.fc:check("continue", "continue:", { release = E.afterDone })            -- interval skip
    check("ctl: release on interval skip", E.release_count == 2)
    E.fc:check("continue", "recent:", { release = E.afterDone })              -- ignored
    check("ctl: release on ignored", E.release_count == 3)
    E.enabled = false
    E.fc:check("continue", "continue:", { release = E.afterDone })
    check("ctl: release on disabled", E.release_count == 4)
    E.enabled = true; E.connected = false
    E.fc:check("continue", "continue:", { release = E.afterDone })
    check("ctl: release on offline", E.release_count == 5)
    E.connected = true; E.probe_throw = true; E.t = E.t + 100
    E.fc:check("continue", "continue:", { release = E.afterDone })
    check("ctl: release after throwing probe", E.release_count == 6)
    E.submit_throw = true; E.t = E.t + 5000
    E.fc:check("continue", "continue:", { release = E.afterDone })
    check("ctl: release after submit throw", E.release_count == 7)
    -- a release that itself throws is tolerated
    local E2 = newEnv()
    check("ctl: throwing release tolerated",
        E2.fc:check("continue", "continue:", { release = function() error("x") end }) == "submitted")
end

-- cancel: in-flight job still stores but does not redraw ----------------------------------------
do
    local E = newEnv()
    E.submit_mode = "queue"
    E.fc:check("continue", "continue:")
    E.fc:cancel()
    E.flush()
    check("ctl: cancel -> still invalidated for next visit", #E.invalidated == 1 and E.sigs["continue:"] ~= nil)
    check("ctl: cancel -> no redraw", #E.changed == 0)
end

-- checkWhenOnline -------------------------------------------------------------------------------
do
    local E = newEnv()
    check("cwo: returns waiting", E.fc:checkWhenOnline({ reason = "wake" }) == "waiting")
    check("cwo: asked for the network with the reason", #E.waits == 1 and E.waits[1].reason == "wake")
    check("cwo: nothing probed while waiting", E.probe_calls == 0 and #E.submits == 0)
    check("cwo: second call while waiting ignored", E.fc:checkWhenOnline({ reason = "wake" }) == "ignored_busy"
        and #E.waits == 1)
    E.waits[1].ready(E.afterDone)
    check("cwo: probes after ready", E.probe_calls == 1)
    check("cwo: changed -> redraw", #E.changed == 1)
    check("cwo: lease released once", E.release_count == 1)
    check("cwo: can wait again afterwards", E.fc:checkWhenOnline({ reason = "wake" }) == "waiting" and #E.waits == 2)
end

-- D10: the chip on screen when Wi-Fi is ready is the one checked ---------------------------------
do
    local E = newEnv()
    E.chip = "continue:"
    E.fc:checkWhenOnline({ reason = "wake" })
    E.chip = "want_to_read:"                 -- user tapped another chip meanwhile
    E.waits[1].ready(E.afterDone)
    check("cwo: D10 checks the chip now on screen", #E.changed == 1 and E.changed[1][2] == "want_to_read:")
    check("cwo: D10 stored wtr records", #E.stored == 1)
    check("cwo: D10 release once", E.release_count == 1)
end

-- D10 skips: other chip kind, nothing showing, book open ------------------------------------------
do
    local E = newEnv()
    E.fc:checkWhenOnline({ reason = "wake" })
    E.chip = "recent:"
    E.waits[1].ready(E.afterDone)
    check("cwo: non-section chip skipped", E.probe_calls == 0 and E.release_count == 1)
    E.fc:checkWhenOnline({ reason = "wake" })
    E.chip = nil                              -- shelf hidden / book open / drilled in
    E.waits[2].ready(E.afterDone)
    check("cwo: nothing on screen skipped", E.probe_calls == 0 and E.release_count == 2)
    check("cwo: skips are no failure", next(E.fc.backoff_until) == nil)
end

-- on_fail (timeout / manual_off): silent, no probe, no lease to release, can retry ----------------------
do
    local E = newEnv()
    E.fc:checkWhenOnline({ reason = "wake" })
    E.waits[1].fail("timeout")
    check("cwo: timeout silent", E.probe_calls == 0 and #E.changed == 0)
    check("cwo: timeout no backoff", next(E.fc.backoff_until) == nil and next(E.fc.fail_count) == nil)
    check("cwo: timeout frees the wait", E.fc:checkWhenOnline({ reason = "wake" }) == "waiting" and #E.waits == 2)
    E.waits[2].fail("manual_off")
    check("cwo: manual_off silent", E.probe_calls == 0)
    check("cwo: manual_off frees the wait", E.fc:checkWhenOnline({ reason = "wake" }) == "waiting")
end

-- Auto Wi-Fi off and offline: gate answers at once with a noop afterDone, radio down -> skip -----------
do
    local E = newEnv()
    E.connected = false
    E.fc:checkWhenOnline({ reason = "book_closed", force = true })
    E.waits[1].ready(function() end)
    check("cwo: offline after gate -> skipped, no probe", E.probe_calls == 0 and #E.submits == 0)
    check("cwo: offline skip leaves no backoff", next(E.fc.backoff_until) == nil)
end

-- cancel during the wait ----------------------------------------------------------------------------------
do
    local E = newEnv()
    E.fc:checkWhenOnline({ reason = "wake" })
    E.fc:cancel()
    check("cwo: cancel frees the wait", E.fc:checkWhenOnline({ reason = "wake" }) == "waiting" and #E.waits == 2)
    E.waits[1].ready(E.afterDone)            -- the old wait answers late
    check("cwo: late answer after cancel releases, does not probe", E.probe_calls == 0 and E.release_count == 1)
    E.waits[1].ready(E.afterDone)            -- a second answer must not release twice more than asked
    E.waits[2].ready(E.afterDone)
    check("cwo: the new wait still works", E.probe_calls == 1)
end

-- force and interval through checkWhenOnline ---------------------------------------------------------------
do
    local E = newEnv()
    E.fc:check("continue", "continue:")
    E.t = E.t + 10
    E.fc:checkWhenOnline({ reason = "wake" })
    E.waits[1].ready(E.afterDone)
    check("cwo: wake respects the 60 s gap and still releases", E.probe_calls == 1 and E.release_count == 1)
    E.fc:checkWhenOnline({ reason = "book_closed", force = true })
    E.waits[2].ready(E.afterDone)
    check("cwo: book_closed (force) bypasses the gap", E.probe_calls == 2 and E.release_count == 2)
end

-- disabled / throwing gate / throwing probe / dropped job ------------------------------------------------------
do
    local E = newEnv()
    E.enabled = false
    check("cwo: disabled does not wait", E.fc:checkWhenOnline({ reason = "wake" }) == "disabled" and #E.waits == 0)

    local E2 = newEnv()
    E2.wait_throw = true
    E2.fc:checkWhenOnline({ reason = "wake" })
    E2.wait_throw = false
    check("cwo: throwing gate frees the wait", E2.fc:checkWhenOnline({ reason = "wake" }) == "waiting" and #E2.waits == 1)

    local E3 = newEnv()
    E3.probe_throw = true
    E3.fc:checkWhenOnline({ reason = "wake" })
    E3.waits[1].ready(E3.afterDone)
    check("cwo: throwing probe releases once", E3.release_count == 1)
    check("cwo: throwing probe backs off", E3.fc.fail_count["continue:"] == 1)

    local E4 = newEnv()
    E4.submit_mode = "drop"
    E4.fc:checkWhenOnline({ reason = "wake" })
    E4.waits[1].ready(E4.afterDone)
    check("cwo: dropped job releases once", E4.release_count == 1 and E4.probe_calls == 0)

    local E5 = newEnv()
    E5.submit_throw = true
    E5.fc:checkWhenOnline({ reason = "wake" })
    E5.waits[1].ready(E5.afterDone)
    check("cwo: submit throw releases once", E5.release_count == 1)

    local E6 = newEnv()
    E6.fc.deps.current_chip = function() error("chip boom") end
    E6.fc:checkWhenOnline({ reason = "wake" })
    E6.waits[1].ready(E6.afterDone)
    check("cwo: throwing current_chip releases once", E6.release_count == 1 and E6.probe_calls == 0)

    local E7 = newEnv()
    E7.fc:checkWhenOnline({ reason = "wake" })
    E7.waits[1].ready(E7.afterDone)
    E7.waits[1].ready(E7.afterDone)          -- a gate that answers twice
    check("cwo: double answer releases the second lease without a second probe",
        E7.probe_calls == 1 and E7.release_count == 2)
end

-- Never turns Wi-Fi on by itself: the controller has no such dependency ------------------------------------------
check("ctl: no wifi-on dependency exists", (function()
    local E = newEnv()
    for k in pairs(E.fc.deps) do if tostring(k):match("turn_on") or tostring(k):match("enable_wifi") then return false end end
    return true
end)())


-- :check with opts.adopt (manual swipe) -----------------------------------------------------------
do
    local E = newEnv()
    E.sigs["continue:"] = "old"
    check("adopt: submitted", E.fc:check("continue", "continue:", { force = true, adopt = true }) == "submitted")
    check("adopt: baseline updated", E.sigs["continue:"] == Fresh.signature(E.records))
    check("adopt: no invalidate/store/redraw", #E.invalidated == 0 and #E.stored == 0 and #E.changed == 0)
    E.t = E.t + 61
    E.fc:check("continue", "continue:")
    check("adopt: next normal check sees no news", #E.changed == 0 and #E.invalidated == 0)
    local E2 = newEnv()
    E2.fc:check("want_to_read", "want_to_read:", { adopt = true, release = E2.afterDone })
    check("adopt: works with no baseline, releases once", E2.sigs["want_to_read:"] ~= nil and E2.release_count == 1
        and #E2.stored == 0)
end

-- =========================================================================
-- Glue (Batch 3): what "the chip on screen" means, when a redraw is allowed,
-- what a tap does. Fakes only; main.lua / widget wiring is parse-checked.
-- =========================================================================
local Glue = require("lib/bookshelf_bookorbit_fresh_glue")

local function newGlue(o)
    o = o or {}
    local G = { t = 5000, shown = true, book_open = false, online = true, configured = true,
        setting_on = true, chip_id = "continue:", q = {}, rebuilds = 0, dirties = 0,
        probes = 0, invalidated = {}, stored = {}, sigs = {}, wifi_calls = {}, wifi_mode = "online",
        pending_sched = nil }
    G.widget = { _drilldown_path = {} }
    function G.widget:_activeFreshChipId() return G.chip_id end
    function G.widget:_rebuild() G.rebuilds = G.rebuilds + 1 end
    G.ui = {}
    function G.ui:isWidgetShown(w) return G.shown end
    function G.ui:setDirty() G.dirties = G.dirties + 1 end
    function G.ui:nextTick(fn) G.q[#G.q + 1] = { at = 0, fn = fn } end
    function G.ui:scheduleIn(s, fn) G.q[#G.q + 1] = { at = s, fn = fn, secs = s } end
    function G.run() local q = G.q; G.q = {}; for _, e in ipairs(q) do e.fn() end end
    G.bo = {
        isConfigured = function() return G.configured end,
        submitSyncJob = function(job) pcall(job.run); if job.cleanup then pcall(job.cleanup) end; return "started" end,
        withAutoWifi = function(schedule, opts)
            G.wifi_calls[#G.wifi_calls + 1] = opts
            G.released = G.released or 0
            if G.wifi_mode == "online" then schedule(function() G.released = G.released + 1 end)
            elseif G.wifi_mode == "off" then schedule(function() end)       -- Auto Wi-Fi off: no wait
            elseif G.wifi_mode == "fail" then opts.on_fail("timeout") end
        end,
    }
    G.bosrc = {
        freshKind = function(id) if id == "continue:" then return "continue" elseif id == "want_to_read:" then return "want_to_read" end end,
        freshProbe = function(kind, id) G.probes = G.probes + 1
            if G.probe_throw then error("net") end
            return { rec(1, "reading", "t1", 0.1) } end,
        freshGetSig = function(id) return G.sigs[id] end,
        freshSetSig = function(id, s) G.sigs[id] = s end,
        freshStoreRecords = function(k, id, r) G.stored[#G.stored + 1] = id end,
        freshInvalidate = function(k, id) G.invalidated[#G.invalidated + 1] = id end,
    }
    G.svc = Glue.build{
        BookOrbit = G.bo, BOSource = G.bosrc, UIManager = G.ui,
        settings = { nilOrTrue = function(k) return G.setting_on end },
        online = function() return G.online end,
        widget = function() return G.widget end,
        book_open = function() return G.book_open end,
        now = function() return G.t end,
        logger = { info = function() end, warn = function() end, dbg = function() end },
    }
    return G
end

-- currentChip -------------------------------------------------------------------------------------
do
    local G = newGlue()
    check("glue: chip on screen", G.svc.currentChip() == "continue:")
    G.shown = false
    check("glue: shelf not shown -> nil", G.svc.currentChip() == nil)
    G.shown = true; G.book_open = true
    check("glue: book open -> nil", G.svc.currentChip() == nil)
    G.book_open = false; G.chip_id = nil
    check("glue: other chip / drilled -> nil", G.svc.currentChip() == nil)
end

-- checkActive: tap path ------------------------------------------------------------------------------
do
    local G = newGlue()
    check("glue: checkActive submits", G.svc.checkActive({ reason = "tap" }) == "submitted")
    check("glue: probed once", G.probes == 1)
    check("glue: no baseline -> invalidated (continue)", #G.invalidated == 1 and G.invalidated[1] == "continue:")
    check("glue: redraw not inline", G.rebuilds == 0)
    G.run()
    check("glue: redraw next tick, once", G.rebuilds == 1 and G.dirties == 1)
    G.t = G.t + 61
    G.svc.checkActive({ reason = "tap" })
    G.run()
    check("glue: unchanged -> no invalidate, no redraw", #G.invalidated == 1 and G.rebuilds == 1)
    check("glue: nothing on screen -> no_chip", (function() G.chip_id = nil; return G.svc.checkActive() == "no_chip" end)())
end

-- Want to read stores probed records (no second fetch) ------------------------------------------------
do
    local G = newGlue(); G.chip_id = "want_to_read:"
    G.svc.checkActive({ reason = "tap" })
    check("glue: wtr stores", #G.stored == 1 and #G.invalidated == 0)
end

-- D6: no redraw when the chip is no longer on screen --------------------------------------------------
do
    local G = newGlue()
    G.svc.checkActive({})
    G.chip_id = "want_to_read:"          -- user switched chip before the tick
    G.run()
    check("glue: chip changed before redraw tick -> no rebuild", G.rebuilds == 0)
    local G2 = newGlue()
    G2.shown = true
    G2.svc.fc.deps.on_changed("continue", "want_to_read:")   -- reported chip is not the one on screen
    G2.run()
    check("glue: reported chip not on screen -> no rebuild", G2.rebuilds == 0 and #G2.q == 0)
    local G3 = newGlue()
    G3.shown = false
    G3.svc.fc.deps.on_changed("continue", "continue:")
    check("glue: shelf hidden -> flag for next show, no rebuild",
        G3.widget._metadata_dirty_force_full_refresh == true and G3.rebuilds == 0)
    local G4 = newGlue()
    G4.book_open = true
    G4.svc.fc.deps.on_changed("continue", "continue:")
    check("glue: book open -> flag, no rebuild", G4.widget._metadata_dirty_force_full_refresh == true and G4.rebuilds == 0)
end

-- tap scheduling ------------------------------------------------------------------------------------
do
    local G = newGlue()
    G.svc.scheduleTapCheck()
    check("glue: tap check scheduled after the paint delay", #G.q == 1 and G.q[1].secs == Glue.TAP_DELAY and G.probes == 0)
    G.chip_id = nil                       -- user moved on to another chip meanwhile
    G.run()
    check("glue: tap check resolves the chip when it fires", G.probes == 0)

    local G2 = newGlue(); G2.chip_id = nil
    G2.svc.scheduleTapCheck()
    check("glue: other chips schedule nothing", #G2.q == 0)

    local G3 = newGlue(); G3.online = false
    G3.svc.scheduleTapCheck(); G3.run()
    check("glue: tap while offline -> silent skip, no probe, no wait", G3.probes == 0 and #G3.wifi_calls == 0)

    local G4 = newGlue(); G4.setting_on = false
    G4.svc.scheduleTapCheck(); G4.run()
    check("glue: setting off -> nothing", G4.probes == 0)

    local G5 = newGlue(); G5.configured = false
    G5.svc.scheduleTapCheck(); G5.run()
    check("glue: not configured -> nothing", G5.probes == 0)
end

-- checkWhenOnline through the Auto Wi-Fi gate --------------------------------------------------------
do
    local G = newGlue()
    check("glue: cwo waiting/ready", G.svc.checkWhenOnline({ reason = "wake" }) ~= nil)
    check("glue: gate asked once", #G.wifi_calls == 1)
    check("glue: never passes trigger (a manual off stays respected)", G.wifi_calls[1].trigger == nil)
    check("glue: lease reason", G.wifi_calls[1].reason == "section_refresh")
    check("glue: probed after ready", G.probes == 1)
    check("glue: lease released once", G.released == 1)

    local G2 = newGlue(); G2.wifi_mode = "fail"
    G2.svc.checkWhenOnline({ reason = "wake" })
    check("glue: timeout/manual_off is silent", G2.probes == 0 and #G2.invalidated == 0)
    G2.wifi_mode = "online"
    G2.svc.checkWhenOnline({ reason = "wake" })
    check("glue: wait is free again after a failed wait", G2.probes == 1)

    local G3 = newGlue(); G3.wifi_mode = "off"; G3.online = false
    G3.svc.checkWhenOnline({ reason = "book_closed", force = true })
    check("glue: Auto Wi-Fi off + offline -> skipped", G3.probes == 0)

    local G4 = newGlue(); G4.chip_id = nil
    G4.svc.checkWhenOnline({ reason = "wake" })
    check("glue: nothing on screen when ready -> skipped, lease released", G4.probes == 0 and G4.released == 1)

    local G5 = newGlue(); G5.probe_throw = true
    G5.svc.checkWhenOnline({ reason = "book_closed", force = true })
    check("glue: failing probe releases the lease once", G5.released == 1)
end

-- cancel + never throws -------------------------------------------------------------------------------
do
    local G = newGlue()
    G.bo.withAutoWifi = function() error("gate boom") end
    check("glue: throwing gate swallowed", pcall(G.svc.checkWhenOnline, { reason = "wake" }) == true)
    check("glue: cancel safe", pcall(G.svc.cancel) == true)
    local G2 = newGlue()
    G2.widget._activeFreshChipId = function() error("widget boom") end
    check("glue: throwing widget swallowed", pcall(G2.svc.checkActive, {}) == true)
    check("glue: scheduleTapCheck swallowed", pcall(G2.svc.scheduleTapCheck) == true)
end


-- =====================================================================================
-- Batch 5 (U6, D11, D14): the "catalog" kind -- Recently added, All books, flat
-- Libraries / Collections / Smart scopes, single Author / Series.
-- =====================================================================================

-- Fresh.kindFor: the pure decision ------------------------------------------------------
do
    check("kindFor: continue", Fresh.kindFor("continue", false) == "continue")
    check("kindFor: want_to_read", Fresh.kindFor("want_to_read", false) == "want_to_read")
    for _, q in ipairs({ "recent", "all", "libraries", "collections", "smart-scopes", "authors", "series" }) do
        check("kindFor: " .. q .. " -> catalog", Fresh.kindFor(q, false) == "catalog")
        check("kindFor: " .. q .. " as group root -> nil", Fresh.kindFor(q, true) == nil)
    end
    for _, q in ipairs({ "discover", "similar", "search", "libraries-groups", "bogus", "" }) do
        check("kindFor: " .. q .. " -> nil", Fresh.kindFor(q, false) == nil)
    end
    check("kindFor: nil / number query -> nil", Fresh.kindFor(nil, false) == nil and Fresh.kindFor(42, false) == nil)
end

-- The REAL freshKind / isGroupRoot / decodeId / freshProbe / freshInvalidate, cut out of
-- the source file text (the whole module cannot be loaded under these stubs) and run
-- against stubs. This ties the test to the shipped code: if the functions change, so does
-- this test.
local function loadSourceBits()
    local f = assert(io.open(PLUGIN .. "/lib/bookshelf_bookorbit_source.lua", "r"))
    local src = f:read("a"); f:close()
    local function cut(pat)
        local s = src:match(pat)
        assert(s, "could not find in source: " .. pat)
        return s
    end
    local pieces = {
        cut("local GROUPED_SECTION_QUERY = {.-\n}\n"),
        cut("function M%.decodeId%(id%).-\nend\n"),
        cut("function M%.queryForId%(id%).-\nend\n"),
        cut("function M%.isGroupRoot%(id%).-\nend\n"),
        cut("function M%.freshKind%(id%).-\nend\n"),
        cut("function M%.freshProbe%(kind, id%).-\nend\n"),
        cut("function M%.freshInvalidate%(kind, id%).-\nend\n"),
    }
    local S = { catalog_calls = {}, page_inval = {}, wtr_inval = {}, offline = false, available = true,
                catalog_body = { items = { { id = 7, title = "x" } } } }
    local header = [[
        local M, Fresh, S = ...
        local FRESH_PROBE_SIZE = 24
        local function _isOffline() return S.offline end
        local BookOrbit = { catalogBooks = function(q) S.catalog_calls[#S.catalog_calls + 1] = q; return S.catalog_body end }
        local function _loadWantToRead() return { records = { { remote_id = 1 } } } end
        local function _afterWantToReadLoad() end
        M.isAvailable = function() return S.available end
        M.toRecord = function(b) return { remote_id = b.id } end
        M.invalidateNextPageCache = function(id) S.page_inval[#S.page_inval + 1] = id end
        M.invalidateWantToReadCache = function(id) S.wtr_inval[#S.wtr_inval + 1] = id end
    ]]
    local chunk = assert(load(header .. table.concat(pieces, "\n"), "source_bits", "t"))
    local M = {}
    chunk(M, Fresh, S)
    return M, S
end

-- id classification on real id strings (R14) -----------------------------------------------
do
    local M = loadSourceBits()
    local yes = { "recent:", "all:", "libraries:", "libraries:12", "collections:", "collections:5",
                  "smart-scopes:", "smart-scopes:7", "authors:Iain Banks", "authors:Banks: Iain",
                  "series:Culture", "series:2139" }
    for _, id in ipairs(yes) do
        check("freshKind: " .. id .. " -> catalog", M.freshKind(id) == "catalog", M.freshKind(id))
    end
    local no = { "authors:", "series:", "libraries-groups:", "collections-groups:", "smart-scopes-groups:",
                 "libraries-groups:12", "discover:", "similar:42", "search:foo", "search:authors:x",
                 "bogus:1", "" }
    for _, id in ipairs(no) do
        check("freshKind: '" .. id .. "' -> nil", M.freshKind(id) == nil, M.freshKind(id))
    end
    check("freshKind: nil / number -> nil", M.freshKind(nil) == nil and M.freshKind(42) == nil)
    check("freshKind: continue", M.freshKind("continue:") == "continue")
    check("freshKind: want_to_read", M.freshKind("want_to_read:") == "want_to_read")
    check("isGroupRoot: authors:/series: are roots", M.isGroupRoot("authors:") and M.isGroupRoot("series:"))
    check("isGroupRoot: single author is not", not M.isGroupRoot("authors:Foo"))
    check("isGroupRoot: bare libraries: is not (flat All list)", not M.isGroupRoot("libraries:"))
end

-- the probe sends the chip's own query: page 1, size 24 ------------------------------------------------
do
    local M, S = loadSourceBits()
    local function probeQuery(id)
        S.catalog_calls = {}
        local recs, err = M.freshProbe("catalog", id)
        return S.catalog_calls[1], recs, err
    end
    local q, recs = probeQuery("recent:")
    check("probe recent: sort recently_added", q and q.sort == "recently_added")
    check("probe recent: page 1 size 24", q.page == 1 and q.size == 24)
    check("probe recent: records mapped", recs and #recs == 1 and recs[1].remote_id == 7)
    q = probeQuery("all:");               check("probe all: sort title", q.sort == "title" and q.page == 1 and q.size == 24)
    q = probeQuery("libraries:12");       check("probe library: libraryId", q.libraryId == "12" and q.size == 24)
    q = probeQuery("collections:5");      check("probe collection: collectionId", q.collectionId == "5")
    q = probeQuery("smart-scopes:7");     check("probe smart scope: smartScopeId", q.smartScopeId == "7")
    q = probeQuery("authors:Iain Banks"); check("probe author: author + sort series", q.author == "Iain Banks" and q.sort == "series")
    q = probeQuery("series:Culture");     check("probe series name: series filter", q.series == "Culture" and q.sort == "series")
    q = probeQuery("series:2139");        check("probe series id: numeric seriesId", q.seriesId == 2139 and q.series == nil)
    q = probeQuery("continue:");          check("probe continue unchanged", q.sort == "recently_read" and q.readStatus == "reading")
    -- failure shapes
    S.catalog_body = nil
    local r, e = M.freshProbe("catalog", "recent:")
    check("probe: bad response -> nil, err", r == nil and e ~= nil)
    S.catalog_body = { items = {} }
    check("probe: empty list is a valid answer", (function() local rr = M.freshProbe("catalog", "recent:"); return type(rr) == "table" and #rr == 0 end)())
    S.offline = true
    local r2, e2 = M.freshProbe("catalog", "recent:")
    check("probe: offline -> nil, 'offline'", r2 == nil and e2 == "offline")
    S.offline = false; S.available = false
    local r3, e3 = M.freshProbe("catalog", "recent:")
    check("probe: not configured -> nil", r3 == nil and e3 == "not_configured")
    S.available = true
    local r4, e4 = M.freshProbe("bogus", "recent:")
    check("probe: unknown kind -> nil", r4 == nil and e4 == "unsupported kind")
end

-- invalidate: catalog and continue drop the page cache (all offsets of that id) ---------------------------
do
    local M, S = loadSourceBits()
    M.freshInvalidate("catalog", "recent:")
    M.freshInvalidate("continue", "continue:")
    M.freshInvalidate("want_to_read", "want_to_read:")
    check("invalidate: catalog drops that id's pages", S.page_inval[1] == "recent:")
    check("invalidate: continue still drops its pages", S.page_inval[2] == "continue:" and #S.page_inval == 2)
    check("invalidate: wtr uses its own cache", #S.wtr_inval == 1 and S.wtr_inval[1] == "want_to_read:")
end

-- page-cache invalidation really covers offset 0 (R13): the real prefix functions run on a fake Cache ----
do
    local f = assert(io.open(PLUGIN .. "/lib/bookshelf_bookorbit_source.lua", "r"))
    local src = f:read("a"); f:close()
    local pk  = assert(src:match('local PAGE_PREFIX = "page:"\n'))
    local pkf = assert(src:match("local function pageKey%(id, offset, limit%).-\nend\n"))
    local inv = assert(src:match("function M%.invalidateNextPageCache%(id%).-\nend\n"))
    local store = {}
    local Cache = {
        set = function(k, v) store[k] = v end,
        invalidatePrefix = function(prefix)
            for k in pairs(store) do if k:sub(1, #prefix) == prefix then store[k] = nil end end
        end,
    }
    local chunk = assert(load("local M, Cache = ...\n" .. pk .. pkf .. inv .. "\nreturn pageKey", "pc", "t"))
    local M = {}
    local pageKey = chunk(M, Cache)
    for _, id in ipairs({ "authors:Foo", "recent:", "authors:Foo:Bar" }) do
        for _, off in ipairs({ 0, 24, 48 }) do Cache.set(pageKey(id, off, 24), { records = {} }) end
    end
    M.invalidateNextPageCache("authors:Foo")
    check("R13: offset 0 of that chip dropped", store[pageKey("authors:Foo", 0, 24)] == nil)
    check("R13: every offset of that chip dropped", store[pageKey("authors:Foo", 24, 24)] == nil and store[pageKey("authors:Foo", 48, 24)] == nil)
    check("R13: other chips untouched", store[pageKey("recent:", 0, 24)] ~= nil)
    check("R13: a longer id sharing the prefix is dropped too (documented, harmless)", store[pageKey("authors:Foo:Bar", 0, 24)] == nil)
end

-- controller with the catalog kind -------------------------------------------------------------------------
do
    local E = newEnv()
    E.kinds["recent:"] = "catalog"; E.kinds["authors:Foo"] = "catalog"; E.kinds["authors:"] = nil
    -- unchanged
    E.sigs["recent:"] = Fresh.signature(E.records)
    check("catalog: submitted", E.fc:check("catalog", "recent:") == "submitted")
    check("catalog: unchanged -> nothing", #E.invalidated == 0 and #E.stored == 0 and #E.changed == 0)
    check("catalog: job family", E.submits[1].family == "bo_fresh:recent:")
    -- changed
    E.sigs["recent:"] = "old"
    E.t = E.t + 61
    E.fc:check("catalog", "recent:")
    check("catalog: changed -> invalidate once with kind catalog", #E.invalidated == 1 and E.invalidated[1][1] == "catalog" and E.invalidated[1][2] == "recent:")
    check("catalog: never stores records", #E.stored == 0)
    check("catalog: on_changed once with kind catalog", #E.changed == 1 and E.changed[1][1] == "catalog" and E.changed[1][2] == "recent:")
    check("catalog: baseline updated", E.sigs["recent:"] == Fresh.signature(E.records))
    -- no baseline: changed once, then settles (D5)
    E.fc:check("catalog", "authors:Foo")
    check("catalog: no baseline -> changed once", #E.invalidated == 2 and E.invalidated[2][2] == "authors:Foo")
    E.t = E.t + 61
    E.fc:check("catalog", "authors:Foo")
    check("catalog: settles", #E.invalidated == 2 and #E.changed == 2)
    -- per-chip gap
    check("catalog: inside the gap skipped", E.fc:check("catalog", "authors:Foo") == "interval")
    -- recent: was last checked 61 s ago, so its own gap is over even though authors:Foo's is not
    check("catalog: gaps are per chip", E.fc:check("catalog", "recent:") == "submitted")
    -- folder-tile chip is ignored (kind_of answers nil)
    check("catalog: folder-tile chip ignored", E.fc:check("catalog", "authors:") == "ignored")
    check("catalog: kind mismatch ignored", E.fc:check("continue", "recent:") == "ignored")
    -- failure backoff applies like for the other kinds
    local F = newEnv(); F.kinds["all:"] = "catalog"; F.probe_result = "fail"
    F.fc:check("catalog", "all:")
    F.t = F.t + 61
    check("catalog: failed check backs off", F.fc:check("catalog", "all:") == "backoff")
end

-- catalog chip through checkWhenOnline (wake / book closed) --------------------------------------------------
do
    local E = newEnv()
    E.kinds["all:"] = "catalog"; E.chip = "all:"
    check("catalog cwo: waiting", E.fc:checkWhenOnline({ reason = "book_closed", force = true }) == "waiting")
    E.waits[1].ready(E.afterDone)
    check("catalog cwo: probed and invalidated", E.probe_calls == 1 and #E.invalidated == 1 and E.invalidated[1][1] == "catalog")
    check("catalog cwo: redraw requested", #E.changed == 1 and E.changed[1][2] == "all:")
    check("catalog cwo: lease released once", E.release_count == 1)
    -- D10: the user moved to a folder-tile chip while we waited -> skipped, lease released
    local E2 = newEnv()
    E2.kinds["all:"] = "catalog"; E2.chip = "all:"
    E2.fc:checkWhenOnline({ reason = "wake" })
    E2.chip = "authors:"                      -- kind_of answers nil for it
    E2.waits[1].ready(E2.afterDone)
    check("catalog cwo: D10 skip on an uncovered chip", E2.probe_calls == 0 and E2.release_count == 1)
end

-- glue with a catalog chip -------------------------------------------------------------------------------------
do
    local G = newGlue()
    G.bosrc.freshKind = function(id) if id == "recent:" then return "catalog" end end
    G.chip_id = "recent:"
    check("glue catalog: current chip", G.svc.currentChip() == "recent:")
    check("glue catalog: submitted", G.svc.checkActive({ reason = "tap" }) == "submitted")
    check("glue catalog: invalidated via the source", #G.invalidated == 1 and G.invalidated[1] == "recent:")
    check("glue catalog: no records stored", #G.stored == 0)
    G.run()
    check("glue catalog: redraw next tick", G.rebuilds == 1 and G.dirties == 1)
    -- chip switched before the redraw tick: cache stays invalidated, no redraw (D6)
    local G2 = newGlue()
    G2.bosrc.freshKind = function(id) if id == "recent:" or id == "all:" then return "catalog" end end
    G2.chip_id = "recent:"
    G2.svc.checkActive({})
    G2.chip_id = "all:"
    G2.run()
    check("glue catalog: D6 no redraw when another chip is on screen", G2.rebuilds == 0)
end

print(("test_bo_fresh: %d passed, %d failed"):format(passes, fails))
return fails > 0
