-- lib/bookshelf_bo_shelf_picker.lua: the add flow of "Shelf from your library".
package.path = PLUGIN .. "/?.lua;" .. package.path
local fails, passes = 0, 0
local function check(n, c, x) if c then passes = passes + 1 else fails = fails + 1; print("FAIL: " .. n .. (x and (" -> " .. tostring(x)) or "")) end end
package.preload["logger"] = function() return { warn = function() end, info = function() end, dbg = function() end } end
package.preload["lib/bookshelf_i18n"] = function() return { gettext = function(s) return s end } end
local shown, closed = {}, {}
package.preload["ui/uimanager"] = function() return {
    show = function(_, w) table.insert(shown, w) end,
    close = function(_, w) table.insert(closed, w); if w and w.close_callback then w.close_callback() end end,
    scheduleIn = function(_, _t, fn) fn() end } end
package.preload["ui/network/manager"] = function() return { runWhenOnline = function(_, fn) fn() end } end
package.preload["ui/widget/infomessage"] = function() return { new = function(_, o) o.kind = "info" return o end } end
package.preload["ui/widget/buttondialog"] = function() return { new = function(_, o) o.kind = "dialog" return o end } end
package.preload["ui/widget/menu"] = function() return { new = function(_, o) o.kind = "menu" return o end } end
package.preload["device"] = function() return { screen = { getWidth = function() return 600 end, getHeight = function() return 800 end } } end
local configured, section_body = true, nil
package.preload["lib/bookshelf_bookorbit"] = function() return {
    isConfigured = function() return configured end,
    catalogSection = function(sec, q) section_body = { sec = sec, page = q.page }
        return { items = { { id = 7, title = "Sci-fi", count = 12 } }, hasNext = true } end } end
package.preload["lib/bookshelf_bookorbit_catalog"] = function() return {
    paramsForEntry = function(sec, e) return { sec = sec, id = e.id } end } end

local P = require("lib/bookshelf_bo_shelf_picker")
local function lastOf(kind) for i = #shown, 1, -1 do if shown[i].kind == kind then return shown[i] end end end

-- happy path
local result, calls = nil, 0
P.pick(function(s) calls = calls + 1; result = s end)
local dlg = lastOf("dialog")
check("P1 asks for the kind of list (5 kinds + cancel)", dlg and #dlg.buttons == 6, dlg and #dlg.buttons)
dlg.buttons[2][1].callback()   -- A collection
check("P2 loads that section, page 1", section_body and section_body.sec == "collections" and section_body.page == 1)
local menu = lastOf("menu")
check("P3 lists the entries + Next page", menu and #menu.item_table == 2 and menu.item_table[1].text == "Sci-fi")
menu.item_table[1].callback()
check("P4 pick returns source/params/title", result and result.source == "collections" and result.params.id == 7 and result.title == "Sci-fi")
check("P5 finished exactly once (closing the menu is not a cancel)", calls == 1, calls)

-- paging does not cancel
result, calls = nil, 0
P.pick(function(s) calls = calls + 1; result = s end)
lastOf("dialog").buttons[1][1].callback()  -- A library
local m1 = lastOf("menu")
m1.item_table[2].callback()                -- Next page
check("P6 next page asks page 2 without cancelling", section_body.page == 2 and calls == 0, calls)

-- cancelling: dialog Cancel, and closing the list
result, calls = nil, 0
P.pick(function(s) calls = calls + 1; result = s end)
local d2 = lastOf("dialog"); d2.buttons[6][1].callback()
check("P7 Cancel -> done(nil)", calls == 1 and result == nil)
calls = 0
P.pick(function(s) calls = calls + 1; result = s end)
lastOf("dialog").buttons[4][1].callback()  -- An author
local m2 = lastOf("menu")
m2.close_callback()
check("P8 closing the list without choosing -> done(nil)", calls == 1 and result == nil)

-- not configured
configured, calls = false, 0
shown = {}
P.pick(function(s) calls = calls + 1 end)
check("P9 not configured: hint + done(nil), no dialog", calls == 1 and lastOf("dialog") == nil and lastOf("info") ~= nil)
print(string.format("RESULT: %d passed, %d failed", passes, fails))
return fails > 0
