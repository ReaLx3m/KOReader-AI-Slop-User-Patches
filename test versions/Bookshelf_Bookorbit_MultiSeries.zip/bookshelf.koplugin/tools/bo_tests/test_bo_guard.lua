-- Batch 6A: pull-before-push guard (D16, D22, D23). Real
-- lib/bookshelf_bookorbit.lua against stubs; the server is a fake injected by
-- overriding BO.pullProgressStatus / BO.pushProgress (both are looked up
-- through the BookOrbit table). Proves the LOGIC only; not run on a device.
package.path = PLUGIN .. "/?.lua;" .. package.path
local fails, passes = 0, 0
local function check(n, c, x)
    if c then passes = passes + 1
    else fails = fails + 1; print("FAIL: " .. n .. (x ~= nil and (" -> " .. tostring(x)) or "")) end
end

package.preload["logger"] = function() return { warn = function() end, info = function() end, dbg = function() end, err = function() end } end
local store = {}
package.preload["datastorage"] = function() return { getSettingsDir = function() return "/s" end } end
package.preload["luasettings"] = function()
    local LS = {}
    function LS:open(file)
        store[file] = store[file] or {}
        local o = { data = store[file] }
        function o:readSetting(k) return self.data[k] end
        function o:saveSetting(k, v) self.data[k] = v end
        function o:delSetting(k) self.data[k] = nil end
        function o:isTrue(k) return self.data[k] == true end
        function o:flush() end
        return o
    end
    return LS
end
package.preload["ui/network/manager"] = function() return { isOnline = function() return true end } end
package.preload["device"] = function() return { model = "ModelA" } end
package.preload["ui/uimanager"] = function() return { show = function() end, scheduleIn = function() end, unschedule = function() end, nextTick = function(_, fn) fn() end } end
package.preload["ui/widget/notification"] = function() return { new = function(_, o) return o end } end
package.preload["lib/bookshelf_i18n"] = function() return { gettext = function(s) return s end } end
package.preload["lib/bookshelf_bookorbit_sync_coordinator"] = function() return { PRIORITY = { auto = 1, manual = 2 }, new = function() return {} end } end
package.preload["lib/bookshelf_bookorbit_sync_job_runner"] = function() return {} end
-- sidecar of the queued book (what pushBookFromDisk reads)
local sidecar = { pct = 0.50, xp = "xp-50" }
package.preload["docsettings"] = function()
    return { open = function(_, fp)
        return { readSetting = function(_, k)
            if k == "partial_md5_checksum" then return "h:" .. fp end
            if k == "percent_finished" then return sidecar.pct end
            if k == "last_xpointer" then return sidecar.xp end
        end }
    end }
end

local ok_load, BO = pcall(require, "lib/bookshelf_bookorbit")
check("G0 real module loads", ok_load, ok_load and nil or BO)
if not ok_load then print(string.format("RESULT: %d passed, %d failed", passes, fails)); return 1 end

local ME = "device-me"
BO.isConfigured = function() return true end
BO.getConfig = function() return { device_id = ME } end
BO.recordSync = function() end
BO.pushBookState = function() return false, "none" end

-- fake server -------------------------------------------------------------
local server, pulls, pushes, pull_err
local function reset()
    -- Clear IN PLACE: the module caches its settings object, which holds
    -- these very tables.
    for _, t in pairs(store) do for k in pairs(t) do t[k] = nil end end
    server, pull_err, pulls, pushes = nil, nil, 0, {}
    sidecar.pct, sidecar.xp = 0.50, "xp-50"
    BO.forgetProgressMark("/b/a.epub")
    BO.forgetProgressMark("/b/b.epub")
    for _, e in ipairs(BO.getPendingSyncs()) do BO.clearPendingSync(e.hash) end
end
BO.pullProgressStatus = function()
    pulls = pulls + 1
    if pull_err then return nil, pull_err end
    return server, nil
end
local push_result, push_err = true, nil
BO.pushProgress = function(fp, pct, pos)
    pushes[#pushes + 1] = { fp = fp, pct = pct, pos = pos }
    if push_result then return true end
    return false, push_err or 500
end
local function remote(o)
    local r = { percentage = o.pct, progress = o.pos or "", device_id = o.dev or "device-other",
                device = o.model or "ModelB", timestamp = o.ts }
    return r
end

-- judgeRemote: pure -------------------------------------------------------
local J = BO.judgeRemote
check("J1 no server place: clear", J(nil, 0.5, "a", nil, ME, "ModelA") == "clear")
check("J2 our own write: clear", J(remote{ pct = 0.9, dev = ME, model = "ModelA" }, 0.5, "a", nil, ME, "ModelA") == "clear")
check("J3 same id, other model name: not treated as ours (belt and braces)",
    J(remote{ pct = 0.9, dev = ME, model = "ModelB" }, 0.5, "a", nil, ME, "ModelA") == "ahead")
check("J4 same place on both sides: clear",
    J(remote{ pct = 0.502 }, 0.5, "a", nil, ME, "ModelA") == "clear"
    and J(remote{ pct = 0.9, pos = "xp9" }, 0.1, "xp9", nil, ME, "ModelA") == "clear")
local seen = { ts = 100, pct = 0.7, pos = "xp-70" }
check("J5 weighed place unchanged (same timestamp): clear",
    J(remote{ pct = 0.7, pos = "xp-70", ts = 100 }, 0.5, "a", seen, ME, "ModelA") == "clear")
check("J6 other device wrote since (newer timestamp): ahead",
    J(remote{ pct = 0.8, pos = "xp-80", ts = 200 }, 0.5, "a", seen, ME, "ModelA") == "ahead")
check("J7 no timestamps: compares the weighed place",
    J(remote{ pct = 0.7, pos = "xp-70" }, 0.5, "a", { pct = 0.7, pos = "xp-70" }, ME, "ModelA") == "clear"
    and J(remote{ pct = 0.8, pos = "xp-80" }, 0.5, "a", { pct = 0.7, pos = "xp-70" }, ME, "ModelA") == "ahead")
check("J8 another device went BACK a chapter after we weighed: still ahead (latest write wins)",
    J(remote{ pct = 0.3, pos = "xp-30", ts = 300 }, 0.5, "a", seen, ME, "ModelA") == "ahead")
check("J9 our own last push, then another device wrote: ahead",
    J(remote{ pct = 0.8, pos = "xp-80" }, 0.5, "a", { own = true }, ME, "ModelA") == "ahead")
check("J10 never weighed: only a further-on place blocks",
    J(remote{ pct = 0.8 }, 0.5, "a", nil, ME, "ModelA") == "ahead"
    and J(remote{ pct = 0.3 }, 0.5, "a", nil, ME, "ModelA") == "clear"
    and J(remote{ pct = 0.8 }, nil, nil, nil, ME, "ModelA") == "ahead")

-- pushProgressGuarded -----------------------------------------------------
local FP = "/b/a.epub"
reset(); server = remote{ pct = 0.9, pos = "xp-90", ts = 10 }
BO.noteRemoteSeen(FP, server)
local ok, err = BO.pushProgressGuarded(FP, 0.5, "xp-50")
check("K1 server place already weighed: push goes out", ok == true and #pushes == 1 and pulls == 1)

reset(); server = remote{ pct = 0.9, pos = "xp-90", ts = 10 }
BO.noteRemoteSeen(FP, remote{ pct = 0.4, pos = "xp-40", ts = 5 })
local ok2, err2, rem2 = BO.pushProgressGuarded(FP, 0.45, "xp-45")
check("K2 another device wrote after we weighed: NOT pushed, returns server_ahead + the place",
    ok2 == false and err2 == "server_ahead" and rem2 == server and #pushes == 0)

reset(); pull_err = 500
ok, err = BO.pushProgressGuarded(FP, 0.5, "xp-50")
check("K3 the check itself fails (server error): push anyway (D22 fail open)", ok == true and #pushes == 1)

reset(); pull_err = "offline"
ok, err = BO.pushProgressGuarded(FP, 0.5, "xp-50")
check("K4 offline: no push, reported as offline (callers queue as before)", ok == false and err == "offline" and #pushes == 0)

reset(); pull_err = 404
ok = BO.pushProgressGuarded(FP, 0.5, "xp-50")
check("K5 server has no place yet (404): push", ok == true and #pushes == 1)

reset(); server = remote{ pct = 0.9, pos = "xp-90", ts = 10 }
BO.noteRemoteSeen(FP, remote{ pct = 0.4, ts = 5 })
BO.pushProgressGuarded(FP, 0.45, "xp-45")
BO.noteRemoteSeen(FP, server)    -- the user was shown it (Dismiss counts as weighed, D23)
ok = BO.pushProgressGuarded(FP, 0.45, "xp-45")
check("K6 after the place was offered (declined), the next push goes out", ok == true and #pushes == 1)

reset(); server = remote{ pct = 0.9, pos = "xp-90", ts = 10 }
BO.noteRemoteSeen(FP, remote{ pct = 0.4, ts = 5 })
store["/s/bookorbit_settings.lua"].sync_forward = "stay"
ok = BO.pushProgressGuarded(FP, 0.45, "xp-45")
check("K7 user chose 'stay' for a further-ahead server place: their place wins, push goes out",
    ok == true and #pushes == 1)

reset(); server = remote{ pct = 0.9, pos = "xp-90", ts = 10 }
BO.noteRemoteSeen(FP, remote{ pct = 0.4, ts = 5 })
BO.forgetProgressMark(FP)   -- a fresh open drops what we knew
ok, err = BO.pushProgressGuarded(FP, 0.45, "xp-45")
check("K8 forgetProgressMark drops the weighed place: unweighed further-on place blocks", ok == false and err == "server_ahead")

-- the pending outbox -------------------------------------------------------
reset(); BO.noteRemoteSeen(FP, remote{ pct = 0.4, pos = "xp-40", ts = 5 })
BO.markPendingSync(FP, "h:" .. FP)
local q = BO.getPendingSyncs()
check("P1 queued entry carries a snapshot of what was known of the server",
    #q == 1 and q[1].seen and q[1].seen.ts == 5 and q[1].seen.pct == 0.4)

-- another device wrote after the entry was queued: retry must not overwrite
server = remote{ pct = 0.8, pos = "xp-80", ts = 50 }
BO.retryPendingSyncs()
check("P2 retry: another device wrote since queuing -> NOT pushed, obsolete entry dropped",
    #pushes == 0 and BO.pendingSyncCount() == 0)

-- unchanged server: retry pushes and clears
reset(); BO.noteRemoteSeen(FP, remote{ pct = 0.4, pos = "xp-40", ts = 5 })
BO.markPendingSync(FP, "h:" .. FP)
server = remote{ pct = 0.4, pos = "xp-40", ts = 5 }
BO.retryPendingSyncs()
check("P3 retry: server unchanged since queuing -> pushed with the sidecar place, entry cleared",
    #pushes == 1 and pushes[1].pct == 0.50 and pushes[1].pos == "xp-50" and BO.pendingSyncCount() == 0)

-- still offline: keep the entry
reset(); BO.markPendingSync(FP, "h:" .. FP)
pull_err = "offline"
BO.retryPendingSyncs()
check("P4 retry while offline: nothing pushed, entry kept", #pushes == 0 and BO.pendingSyncCount() == 1)

-- old entry without a snapshot
reset(); BO.markPendingSync(FP, "h:" .. FP)          -- no seen recorded
server = remote{ pct = 0.2, pos = "xp-20", ts = 1 }
BO.retryPendingSyncs()
check("P5 no snapshot, server place is behind ours: pushed", #pushes == 1 and BO.pendingSyncCount() == 0)
reset(); BO.markPendingSync(FP, "h:" .. FP)
server = remote{ pct = 0.9, pos = "xp-90", ts = 1 }
BO.retryPendingSyncs()
check("P6 no snapshot, server place is further on (other device): NOT pushed, entry dropped",
    #pushes == 0 and BO.pendingSyncCount() == 0)

-- push itself fails (HTTP error): keep for the next try
reset(); BO.markPendingSync(FP, "h:" .. FP)
server = nil; pull_err = 404; push_result = false; push_err = 500
BO.retryPendingSyncs()
check("P7 push fails with a server error: entry kept for the next retry", #pushes == 1 and BO.pendingSyncCount() == 1)
push_result, push_err = true, nil

-- the check itself fails on retry: fail open
reset(); BO.markPendingSync(FP, "h:" .. FP)
pull_err = 500
BO.retryPendingSyncs()
check("P8 retry, check fails (not offline): pushes anyway (D22), entry cleared", #pushes == 1 and BO.pendingSyncCount() == 0)

-- two books are independent
reset(); BO.noteRemoteSeen("/b/a.epub", remote{ pct = 0.4, ts = 5 })
BO.markPendingSync("/b/a.epub", "h:/b/a.epub"); BO.markPendingSync("/b/b.epub", "h:/b/b.epub")
local qq = BO.getPendingSyncs()
local seen_a, seen_b
for _, e in ipairs(qq) do if e.filepath == "/b/a.epub" then seen_a = e.seen else seen_b = e.seen end end
check("P9 the snapshot belongs to its own book", seen_a ~= nil and seen_b == nil)

print(string.format("RESULT: %d passed, %d failed", passes, fails))
return fails > 0 and 1 or nil
