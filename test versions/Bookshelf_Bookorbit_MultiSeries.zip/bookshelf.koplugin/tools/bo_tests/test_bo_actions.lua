package.path = PLUGIN .. "/?.lua;" .. package.path
local fails, passes = 0, 0
local function check(n, c, x) if c then passes = passes + 1 else fails = fails + 1; print("FAIL: " .. n .. (x and (" -> " .. tostring(x)) or "")) end end
package.preload["logger"] = function() return { warn = function() end, info = function() end, dbg = function() end } end
package.preload["lib/bookshelf_i18n"] = function() return { gettext = function(s) return s end } end
local shown = {}
package.preload["ui/uimanager"] = function() return { show = function(_, w) table.insert(shown, w) end } end
package.preload["ui/widget/infomessage"] = function() return { new = function(_, o) o.kind = "info" return o end } end
package.preload["ui/widget/textviewer"] = function() return { new = function(_, o) o.kind = "viewer" return o end } end
local opened, resolved, showReader = {}, {}, {}
package.preload["lib/bookshelf_bookorbit_source"] = function() return {
    toRecord = function(b) return { remote_id = b.id, title = b.title, is_bookorbit = true } end,
    resolveOpenPath = function(rec, cb) table.insert(resolved, rec) cb("/books/x.epub") end } end
package.preload["apps/reader/readerui"] = function() return { showReader = function(_, p) table.insert(showReader, p) end } end
local inv = {}
package.preload["lib/bookshelf_bo_data"] = function() return {
    invalidate = function() table.insert(inv, "all") end,
    invalidateShelf = function(p) table.insert(inv, p.source) end } end
local looked = {}
package.preload["apps/filemanager/filemanager"] = function() return { instance = { dictionary = { onLookupWord = function(_, w) table.insert(looked, w) end } } } end
local catalog = 0
package.preload["lib/bookshelf_bookorbit_catalog"] = function() return { show = function() catalog = catalog + 1 end } end

local A = require("lib/bookshelf_bo_actions")
local bw = { _openBook = function(_, r) table.insert(opened, r) end, _previewBook = function(_, r) table.insert(opened, { preview = r }) end }

-- defaultFor
local d = { continue_reading = { { id = 7, title = "Dune" } }, highlight = { text = "t" }, word = { word = "limn" },
    year_ago = { book = { id = 3 } } }
check("A1 hero resumes lead", A.defaultFor("hero", d).kind == "book" and A.defaultFor("hero", d).book.id == 7 and A.defaultFor("hero", d).resume)
check("A2 hero with no book -> all books", A.defaultFor("hero", {}).kind == "books")
check("A3 also -> in progress", A.defaultFor("also", d).params.readStatus == "reading")
check("A4 highlight / word / yearago", A.defaultFor("highlight", d).kind == "highlight" and A.defaultFor("word", d).word == "limn" and A.defaultFor("yearago", d).book_id == 3)
check("A5 word with no word -> not tappable", A.defaultFor("word", {}) == nil)
check("A6 finished shelf -> books", A.defaultFor("shelf", d, { source = "finished" }).params.readStatus == "finished")
check("A7 streak has no tap", A.defaultFor("streak", d) == nil)

-- run
A.run({ kind = "book", book = { id = 7, title = "Dune" }, resume = true }, { bw = bw })
check("B1 book opens through the widget", opened[1] and opened[1].remote_id == 7)
A.run({ kind = "book", book = { id = 8 } }, {})
check("B2 no widget -> resolve then reader", resolved[1] and resolved[1].remote_id == 8 and showReader[1] == "/books/x.epub")
A.run({ kind = "detail", book_id = 9, list = { books = { { id = 9, title = "Found" } } } }, { bw = bw })
check("B3 detail finds the book in the list", opened[2] and opened[2].preview.title == "Found", opened[2] and opened[2].preview.title)
A.run({ kind = "detail", book_id = 10 }, { bw = bw })
check("B3b detail without list still previews a stub", opened[3] and opened[3].preview.remote_id == 10)
A.run({ kind = "books" }, {})
check("B4 books opens the catalog", catalog == 1)
local refreshed = 0
A.run({ kind = "shuffle" }, {}, { props = { source = "random" }, refresh = function() refreshed = refreshed + 1 end })
check("B5 shelf shuffle invalidates that shelf + repaints", inv[1] == "random" and refreshed == 1)
A.run({ kind = "shuffle" }, {}, { refresh = function() end })
check("B5b hero shuffle invalidates the dashboard", inv[2] == "all")
A.run({ kind = "highlight", highlight = { text = "Hello", bookTitle = "Dune", chapterTitle = "One" } }, {})
check("B6 highlight viewer", shown[#shown].kind == "viewer" and shown[#shown].text:find("Hello") and shown[#shown].text:find("Dune"))
A.run({ kind = "lookup", word = "limn" }, {})
check("B7 lookup", looked[1] == "limn")
check("B8 garbage / unknown / noop never throw", pcall(A.run, nil) and pcall(A.run, { kind = "zzz" }, {}) and pcall(A.run, { kind = "noop" }, {}) and pcall(A.run, { kind = "book" }, {}))
bw._openBook = function() error("boom") end
check("B9 a throwing handler is contained", pcall(A.run, { kind = "book", book = { id = 1 } }, { bw = bw }))
print(string.format("RESULT: %d passed, %d failed", passes, fails))
return fails
