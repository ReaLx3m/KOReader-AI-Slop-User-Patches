-- Batch 6a: the vendored decor code (decor.lua, animal_sprites.lua) and the 11
-- Decor specs in micromodules/bookorbit_decor.lua. KOReader is stubbed; nothing
-- here draws a pixel, so it checks wiring, data and pure logic only.
package.path = PLUGIN .. "/?.lua;" .. package.path
local fails, passes = 0, 0
local function check(n, c, x) if c then passes = passes + 1 else fails = fails + 1; print("FAIL: " .. n .. (x and (" -> " .. tostring(x)) or "")) end end

package.preload["logger"] = function() return { warn = function() end, info = function() end, dbg = function() end } end
package.preload["lib/bookshelf_i18n"] = function() return { gettext = function(s) return s end } end

-- ---- animal sprites: pure data, loaded as is ----------------------------------
local ANIMALS = dofile(PLUGIN .. "/lib/bookorbit_board/animal_sprites.lua")
local POSES = { "wait", "sleep", "ribbon", "party", "yawn", "read" }   -- every pose buddyPose can return
local NINE = { "dog", "rabbit", "owl", "penguin", "robot", "vampire", "dragon", "ghost" }
local sprite_problem
for _i, a in ipairs(NINE) do
    local set = ANIMALS[a]
    if type(set) ~= "table" then sprite_problem = a .. " missing"; break end
    for _j, pose in ipairs(POSES) do
        local rows = set[pose]
        if type(rows) ~= "table" or #rows ~= 40 then sprite_problem = a .. "/" .. pose .. " rows " .. tostring(rows and #rows); break end
        for _k, r in ipairs(rows) do
            if type(r) ~= "string" or #r ~= 40 then sprite_problem = a .. "/" .. pose .. " row width"; break end
        end
        if sprite_problem then break end
    end
    if sprite_problem then break end
end
check("S1 8 animals x 6 poses, all 40x40", sprite_problem == nil, sprite_problem)

-- ---- the vendored decor module loads and installs --------------------------------
local function proxy() return setmetatable({}, { __index = function(t, k) local f = function() return {} end; rawset(t, k, f); return f end }) end
package.preload["ui/widget/container/centercontainer"] = function() return {} end
package.preload["ui/font"] = function() return {} end
package.preload["ui/geometry"] = function() return {} end
package.preload["ui/widget/textwidget"] = function() return {} end
package.preload["ui/widget/widget"] = function() return { extend = function(self, o) o = o or {} return setmetatable(o, { __index = self }) end } end
package.preload["bit"] = function() return {} end
package.preload["ffi/util"] = function() return { template = function(s) return s end } end
package.preload["lib/bookorbit_board/art"] = function() return proxy() end
package.preload["lib/bookorbit_board/data"] = function() return proxy() end
package.preload["lib/bookorbit_board/icons"] = function() return proxy() end
package.preload["lib/bookorbit_board/metrics"] = function() return { INK = {}, px = function(x) return x end, lh1 = function() return 10 end } end
package.preload["lib/bookorbit_board/ui"] = function() return proxy() end
package.preload["lib/bookorbit_board/sprites"] = function() return { wait = { "x" } } end
local okd, Decor = pcall(dofile, PLUGIN .. "/lib/bookorbit_board/decor.lua")
check("D1 decor.lua loads with the vendored requires", okd and type(Decor) == "table", Decor)
Decor = okd and Decor or { TYPES = {}, SIG = {} }
local types = {}
for _i, t in ipairs(Decor.TYPES) do types[t] = true end
check("D2 TYPES lists the 9 decor widget types", (function() local n = 0 for _ in pairs(types) do n = n + 1 end return n == 9 end)())
local W = {}
Decor.install(W, { head = function() end, formatCount = function() end })
check("D3 install registers every type as a widget function", (function()
    for t in pairs(types) do if type(W[t]) ~= "function" then return false end end return true end)())

-- buddyPose is pure; first-load / preview data must not throw
check("D4 pose with an empty d (first load) is wait", Decor.buddyPose({}) == "wait")
check("D5 pose: a book but nothing read today is sleep", Decor.buddyPose({ continue_reading = { {} }, today_min = 0, streak = {} }) == "sleep")
check("D6 pose: read today = read (daytime)", (function()
    local noon = os.time({ year = 2026, month = 3, day = 10, hour = 12 })
    return Decor.buddyPose({ continue_reading = { {} }, today_min = 12, now = noon, streak = { current = 3, longest = 9 } }) == "read" end)())
check("D7 pose: finished today = ribbon", Decor.buddyPose({ continue_reading = { {} }, today_min = 5, finished_today = {}, streak = {} }) == "ribbon")
check("D8 pose: 7-day streak = party", Decor.buddyPose({ continue_reading = { {} }, today_min = 5, streak = { current = 7, longest = 9 } }) == "party")
check("D9 pose: late at night = yawn", (function()
    local late = os.time({ year = 2026, month = 3, day = 10, hour = 23 })
    return Decor.buddyPose({ continue_reading = { {} }, today_min = 5, now = late, streak = { current = 3, longest = 9 } }) == "yawn" end)())
check("D10 SIG for the buddy survives a bare ctx.d", pcall(Decor.SIG.buddy, { d = {} }))

-- ---- the specs ------------------------------------------------------------------
package.preload["lib/bookshelf_module_kit"] = function() return { CARD_BG = "bg", COLOR_MUTED = "muted",
    fitText = function(o) return { kind = "text", text = o.text, width = o.width } end } end
local seen, drawn_props, drawn = {}, {}, {}
local d_state = { not_configured = true, fingerprint = "f" }
package.preload["lib/bookshelf_bo_data"] = function() return { get = function(opts) seen = opts; return d_state end } end
package.preload["lib/bookshelf_bo_actions"] = function() return { defaultFor = function() end, run = function() end } end
package.preload["lib/bookorbit_board/ui"] = function() return { surface = nil, pickScope = function() end,
    collectHits = function(fn) return fn(), {} end,
    overlay = function(w, h) return { kind = "overlay", w = w, h = h } end,
    box = function() return {} end } end
package.preload["lib/bookorbit_board/widgets"] = function()
    local Wt = setmetatable({}, { __index = function(_t, ty) return function(_ctx, _w, _h, props) table.insert(drawn, ty); drawn_props[#drawn] = props; return { kind = "content" } end end })
    return { W = Wt } end
package.loaded["lib/bookorbit_board/ui"] = nil
package.loaded["lib/bookorbit_board/widgets"] = nil

local full = dofile(PLUGIN .. "/micromodules/bookorbit_decor.lua")
-- The file now also holds Batch 6b's five specs (test_bo_batch6b.lua); this
-- test covers the Batch 6a eleven.
local SIX_B = { bookorbit_odometer = true, bookorbit_glyph = true, bookorbit_rings = true,
    bookorbit_badge = true, bookorbit_dust = true }
local specs = {}
for _i, sp in ipairs(full) do if not SIX_B[sp.key] then specs[#specs + 1] = sp end end
check("E1 11 Batch 6a specs (16 in the file with 6b)", #specs == 11 and #full == 16, #specs .. "/" .. #full)

-- keys unique across all five BookOrbit category files and clash with no existing module
local keys, dupes = {}, {}
for _i, f in ipairs{ "bookorbit_library", "bookorbit_device", "bookorbit_reading", "bookorbit_stats", "bookorbit_decor" } do
    package.loaded["lib/bookshelf_bo_module"] = nil
    for _j, sp in ipairs(dofile(PLUGIN .. "/micromodules/" .. f .. ".lua")) do
        if keys[sp.key] then dupes[#dupes + 1] = sp.key end
        keys[sp.key] = true
    end
end
check("E2 no duplicate keys across the five files", #dupes == 0, table.concat(dupes, ","))
local existing_clash
for _i, fname in ipairs(listdir(PLUGIN .. "/micromodules")) do
    if fname:match("%.lua$") and not fname:match("^bookorbit_") then
        local f = io.open(PLUGIN .. "/micromodules/" .. fname)
        local src = f:read("a"); f:close()
        local k = src:match('key%s*=%s*"([^"]+)"')
        if k and keys[k] then existing_clash = k end
    end
end
check("E3 no clash with the existing Bookshelf modules", existing_clash == nil, existing_clash)

local want = { "bookorbit_buddy_cat", "bookorbit_buddy_dog", "bookorbit_buddy_rabbit", "bookorbit_buddy_owl", "bookorbit_buddy_penguin",
    "bookorbit_buddy_robot", "bookorbit_buddy_vampire", "bookorbit_buddy_dragon", "bookorbit_buddy_ghost", "bookorbit_analog", "bookorbit_moon" }
local by = {}
for _i, sp in ipairs(specs) do by[sp.key] = sp end
local missing
for _i, k in ipairs(want) do if not by[k] then missing = k end end
check("E4 exactly the 11 planned keys", missing == nil and #specs == #want, missing)

local allok = true
for _i, sp in ipairs(specs) do
    if sp.category ~= "bookorbit:decor" or sp.is_new ~= true or type(sp.render) ~= "function"
        or sp.on_tap ~= nil or type(sp.title) ~= "string" or type(sp.summary) ~= "string" then allok = false end
end
check("E5 all decor + New chip + render, none tappable", allok)

-- the nine companions: right widget type, right animal, animals match real sprite sets
local animal_ok = true
for _i, k in ipairs(want) do
    if k:match("^bookorbit_buddy_") then
        local ani = k:match("^bookorbit_buddy_(%w+)$")
        drawn, drawn_props = {}, {}
        d_state = { fingerprint = "f", loading = true }
        by[k].render{ width = 300, height = 200 }
        local p = drawn_props[1]
        if drawn[1] ~= "buddy" then animal_ok = false end
        if ani == "cat" then
            if p and p.animal ~= nil then animal_ok = false end            -- cat = default sprites
        else
            if not (p and p.animal == ani and ANIMALS[ani]) then animal_ok = false end
        end
    end
end
check("E6 each buddy draws type buddy with its animal; non-cat animals have sprites", animal_ok)

-- server flag: buddies show the hint until configured; clock and moon do not
d_state = { not_configured = true, fingerprint = "f" }
local hint = by.bookorbit_buddy_dog.render{ width = 300, height = 200 }
check("E7 buddy shows the set-up hint when not configured", hint.kind == "text" and hint.text:find("Set up your BookOrbit server"), hint.text)
drawn = {}
local a = by.bookorbit_analog.render{ width = 120, height = 120 }
local m = by.bookorbit_moon.render{ width = 120, height = 120 }
check("E8 analog clock and moon draw even when not configured", a.kind == "overlay" and m.kind == "overlay" and drawn[1] == "analog" and drawn[2] == "moon")
check("E9 buddies need nothing beyond the dashboard", (function()
    d_state = { fingerprint = "f" }
    by.bookorbit_buddy_owl.render{ width = 300, height = 200 }
    local n = seen.needs
    return n == nil or ((n.shelves == nil or #n.shelves == 0) and (n.names == nil or #n.names == 0)) end)())

-- previews never fetch and never error
local prev_ok = true
for _i, sp in ipairs(specs) do
    d_state = { fingerprint = "f", preview = true }
    seen = {}
    local ok = pcall(sp.render, { width = 200, height = 120, preview = true })
    if not ok or seen.preview ~= true then prev_ok = false end
end
check("E10 every spec renders in preview and tells the data layer it is a preview", prev_ok)

-- minute tick only on the analog clock; squares for the small default shapes
check("E11 only the analog clock ticks each minute", by.bookorbit_analog.wants_minute_tick == true
    and by.bookorbit_moon.wants_minute_tick ~= true and by.bookorbit_buddy_cat.wants_minute_tick ~= true)
check("E12 analog and moon are square (default S); buddies are not", by.bookorbit_analog.aspect == "square"
    and by.bookorbit_moon.aspect == "square" and by.bookorbit_buddy_cat.aspect == nil)

print(string.format("RESULT: %d passed, %d failed", passes, fails))
return fails > 0
