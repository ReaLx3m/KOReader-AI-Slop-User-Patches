-- Auto Wi-Fi sub-setting 2 (sync book progress on sleep), batch 4.
-- Off-device: radio, scheduler and BookOrbit are fakes; time is virtual.
-- Proves the LOGIC only. The real suspend timing (KOReader's ~15 s delay after
-- the Suspend event, Wi-Fi killed before it) is taken from the KOReader source
-- and has NOT been run on a device.
package.path = PLUGIN .. "/?.lua;" .. package.path
local fails, passes = 0, 0
local function check(n, c, x)
    if c then passes = passes + 1
    else fails = fails + 1; print("FAIL: " .. n .. (x ~= nil and (" -> " .. tostring(x)) or "")) end
end

package.preload["logger"] = function() return { warn = function() end, info = function() end, dbg = function() end, err = function() end } end

local function newUI()
    local ui = { t = 0, q = {} }
    function ui:scheduleIn(secs, fn) table.insert(self.q, { at = self.t + secs, fn = fn }) end
    function ui:unschedule(fn)
        for i = #self.q, 1, -1 do if self.q[i].fn == fn then table.remove(self.q, i) end end
    end
    function ui:advance(secs)
        local target = self.t + secs
        while true do
            local best, bi
            for i, e in ipairs(self.q) do
                if e.at <= target and (not best or e.at < best.at) then best, bi = e, i end
            end
            if not best then break end
            table.remove(self.q, bi)
            self.t = math.max(self.t, best.at)
            best.fn()
        end
        self.t = target
    end
    return ui
end

-- Fake NetworkMgr with the REAL entry points the controller now uses.
-- restoreWifiAsync = the quiet path; connect_after = seconds to come online.
local function newNet(ui, o)
    o = o or {}
    local n = { wifi_on = false, online = false, connect_after = o.connect_after,
                restore_calls = 0, enable_calls = 0, disable_calls = 0, raw_off_calls = 0,
                checks = 0 }
    function n:isWifiOn() return self.wifi_on end
    function n:isOnline() return self.online end
    function n:restoreWifiAsync()
        self.restore_calls = self.restore_calls + 1
        self.wifi_on = true
        if self.connect_after then
            ui:scheduleIn(self.connect_after, function() self.online = true end)
        end
    end
    function n:scheduleConnectivityCheck() self.checks = self.checks + 1 end
    function n:enableWifi() self.enable_calls = self.enable_calls + 1 end
    function n:disableWifi() self.disable_calls = self.disable_calls + 1; self.wifi_on = false; self.online = false end
    function n:turnOffWifi() self.raw_off_calls = self.raw_off_calls + 1; self.wifi_on = false; self.online = false end
    return n
end

local Wifi = require("lib/bookshelf_bookorbit_wifi")
local Sleep = require("lib/bookshelf_bookorbit_sleep")

local function env(o)
    o = o or {}
    local ui = newUI()
    local net = newNet(ui, o.net)
    local cfg = { enabled = true, off_in_book = o.off_in_book ~= false }
    local w = Wifi.new{
        network = net, ui = ui,
        settings = { enabled = function() return cfg.enabled end,
                     off_in_book = function() return cfg.enabled and cfg.off_in_book end,
                     can_restore = function() return o.can_restore ~= false end },
    }
    w:noteBookOpened()           -- a book is open (sub-setting 1 policy applies)
    -- fake BookOrbit
    local bo = { pushes = {}, pending = {}, jobs = 0, changed = o.changed ~= false,
                 sleep_on = o.sleep_on ~= false, push_result = o.push_result == nil and true or o.push_result,
                 submit_throws = o.submit_throws, defer_jobs = o.defer_jobs, queued_jobs = {} }
    bo.SYNC_PRIORITY = { auto = 1, manual = 2 }
    function bo.autoWifiSyncOnSleep() return bo.sleep_on end
    function bo.isConfigured() return o.configured ~= false end
    function bo.autoSyncEnabled() return true end
    function bo.getBookHash(fp) return "hash:" .. fp end
    function bo.progressChangedSincePush() return bo.changed end
    function bo.pushProgress(fp, pct, pos)
        table.insert(bo.pushes, { fp = fp, pct = pct, pos = pos })
        return bo.push_result
    end
    function bo.markPendingSync(fp, hash) table.insert(bo.pending, { fp = fp, hash = hash }) end
    function bo.submitSyncJob(job)
        if bo.submit_throws then error("boom") end
        bo.jobs = bo.jobs + 1
        bo.last_job = job
        if bo.defer_jobs then table.insert(bo.queued_jobs, job); return "queued" end
        pcall(job.run)
        if job.cleanup then job.cleanup() end
        return "started"
    end
    local ctx = { bookorbit = bo, wifi = w, fp = "/b/a.epub", pct = 0.42, pos = "xp1",
                  device = o.device }
    return w, ui, net, bo, ctx, cfg
end

-- ---------------------------------------------------------------------
-- cap: always safely below the device's own suspend delay
-- ---------------------------------------------------------------------
check("S1 cap, no device info: 15 - 3 = 12", Sleep.cap(nil) == 12)
check("S2 cap, suspend_wait_timeout 15 -> 12", Sleep.cap({ suspend_wait_timeout = 15 }) == 12)
check("S3 cap follows a longer screensaver delay, never above 15",
    Sleep.cap({ suspend_wait_timeout = 15, screensaver_suspend_wait_timeout = 17 }) == 14
    and Sleep.cap({ screensaver_suspend_wait_timeout = 30 }) == 15)
check("S4 cap never below 5", Sleep.cap({ suspend_wait_timeout = 4 }) == 5)

-- ---------------------------------------------------------------------
-- nothing to do
-- ---------------------------------------------------------------------
do
    local w, ui, net, bo, ctx = env{ sleep_on = false }
    check("T1 sub-setting off: nothing happens",
        Sleep.run(ctx) == "disabled" and net.restore_calls == 0 and #bo.pushes == 0)
end
do
    local w, ui, net, bo, ctx = env{ configured = false }
    check("T2 BookOrbit not configured: nothing happens",
        Sleep.run(ctx) == "not_configured" and net.restore_calls == 0)
end
do
    local w, ui, net, bo, ctx = env{ changed = false }
    check("T3 unchanged since last push: Wi-Fi is NOT woken (D2)",
        Sleep.run(ctx) == "unchanged" and net.restore_calls == 0 and net.enable_calls == 0
        and #bo.pushes == 0 and #bo.pending == 0 and w.count == 0)
end
do
    local w, ui, net, bo, ctx = env{}
    ctx.pct = nil
    check("T4 no live progress: nothing happens", Sleep.run(ctx) == "no_progress" and net.restore_calls == 0)
end

-- ---------------------------------------------------------------------
-- the main flow
-- ---------------------------------------------------------------------
do
    local w, ui, net, bo, ctx = env{ net = { connect_after = 4 } }
    local st = Sleep.run(ctx)
    check("U1 started, quiet non-blocking turn-on used", st == "started" and net.restore_calls == 1 and net.enable_calls == 0)
    check("U1b connectivity check scheduled alongside (KOReader sends NetworkConnected)", net.checks == 1)
    check("U2 nothing pushed before Wi-Fi is up", #bo.pushes == 0 and w.count == 1)
    ui:advance(6)
    check("U3 pushed once with the live place", #bo.pushes == 1 and bo.pushes[1].fp == "/b/a.epub"
        and bo.pushes[1].pct == 0.42 and bo.pushes[1].pos == "xp1")
    check("U4 manual-priority job in the book's progress family",
        bo.last_job.family == "progress:hash:/b/a.epub" and bo.last_job.priority == 2)
    check("U5 lease released and Wi-Fi switched off again via disableWifi (sub-setting 1 policy)",
        w.count == 0 and net.disable_calls == 1 and net.raw_off_calls == 0 and not net.wifi_on)
    check("U6 nothing queued on success", #bo.pending == 0)
end

do -- already online (e.g. a platform that does not kill Wi-Fi)
    local w, ui, net, bo, ctx = env{}
    net.wifi_on, net.online = true, true
    Sleep.run(ctx)
    check("U7 already online: pushed straight away, no turn-on, then off again",
        #bo.pushes == 1 and net.restore_calls == 0 and w.count == 0 and net.disable_calls == 1)
end

-- ---------------------------------------------------------------------
-- failures: sleep is never held up, the place is queued
-- ---------------------------------------------------------------------
do
    local w, ui, net, bo, ctx = env{ net = {} }            -- never connects
    Sleep.run(ctx)
    ui:advance(11)
    check("V1 still waiting just before the cap", #bo.pending == 0 and w.count == 1)
    ui:advance(3)
    check("V2 cap reached: queued, no push", #bo.pending == 1 and #bo.pushes == 0 and bo.pending[1].fp == "/b/a.epub"
        and bo.pending[1].hash == "hash:/b/a.epub")
    check("V3 lease gone and the radio is switched off again", w.count == 0 and not net.wifi_on)
end

do
    local w, ui, net, bo, ctx = env{ net = { connect_after = 2 }, push_result = false }
    Sleep.run(ctx); ui:advance(5)
    check("V4 push fails: queued, lease released", #bo.pending == 1 and w.count == 0)
end

do
    local w, ui, net, bo, ctx = env{ net = { connect_after = 2 }, submit_throws = true }
    Sleep.run(ctx); ui:advance(5)
    check("V5 job submission throws: queued, lease not leaked, radio off",
        #bo.pending == 1 and w.count == 0 and not net.wifi_on)
end

do -- dropped job (coordinator coalescing): cleanup still releases
    local w, ui, net, bo, ctx = env{ net = { connect_after = 2 }, defer_jobs = true }
    Sleep.run(ctx); ui:advance(4)
    check("V6 job queued behind another: lease still held", w.count == 1 and #bo.pushes == 0)
    bo.queued_jobs[1].cleanup()                       -- coordinator dropped it
    check("V7 dropped job's cleanup releases the lease", w.count == 0 and not net.wifi_on)
end

-- ---------------------------------------------------------------------
-- explicit trigger + interplay with the controller
-- ---------------------------------------------------------------------
do
    local w, ui, net, bo, ctx = env{ net = { connect_after = 2 } }
    w.manual_off = true
    Sleep.run(ctx); ui:advance(5)
    check("W1 sleep sync clears a manual off and still syncs", #bo.pushes == 1 and w.manual_off == false)
end

do -- pull-on-open style lease already running: counts keep Wi-Fi up
    local w, ui, net, bo, ctx = env{ net = { connect_after = 2 } }
    local other = w:acquire("other", function() end)
    Sleep.run(ctx); ui:advance(5)
    check("W2 overlapping lease: Wi-Fi stays on until the last one is released",
        #bo.pushes == 1 and net.wifi_on and w.count == 1)
    w:release(other)
    check("W3 last release turns it off", not net.wifi_on and w.count == 0)
end

do -- device without Wi-Fi restore: falls back to enableWifi(cb, false)
    local w, ui, net, bo, ctx = env{ net = { connect_after = 2 }, can_restore = false }
    function net:enableWifi(cb) self.enable_calls = self.enable_calls + 1; self.wifi_on = true
        ui:scheduleIn(2, function() self.online = true; if cb then cb() end end) end
    Sleep.run(ctx); ui:advance(5)
    check("W4 no restore support: enableWifi used, push still goes out",
        net.enable_calls == 1 and net.restore_calls == 0 and #bo.pushes == 1)
end

-- ---------------------------------------------------------------------
-- batch 5: works with sub-setting 1 OFF too (Wi-Fi kept on while reading)
-- ---------------------------------------------------------------------
do
    local w, ui, net, bo, ctx = env{ off_in_book = false, net = { connect_after = 3 } }
    Sleep.run(ctx); ui:advance(6)
    check("X1 sub 1 off: still pushes", #bo.pushes == 1 and #bo.pending == 0)
    check("X2 sub 1 off: Wi-Fi is switched off again afterwards", w.count == 0 and not net.wifi_on and net.disable_calls == 1)
    ui:advance(300)
    check("X3 sub 1 off: and the steady state does NOT reconnect it behind the suspend",
        net.restore_calls == 1 and not net.wifi_on and w.sleeping == true)
    w:trigger("wake_home")
    check("X4 the next trigger ends the sleeping state and brings Wi-Fi back", w.sleeping == false and net.wifi_on)
end

do
    local w, ui, net, bo, ctx = env{ off_in_book = false, net = {} }   -- never connects
    Sleep.run(ctx); ui:advance(16)
    check("X5 sub 1 off, out of range: queued, radio off, no retry storm during suspend",
        #bo.pending == 1 and #bo.pushes == 0 and not net.wifi_on and net.restore_calls == 1,
        string.format("pending=%d pushes=%d wifi_on=%s restore=%d", #bo.pending, #bo.pushes, tostring(net.wifi_on), net.restore_calls))
    ui:advance(400)
    check("X6 still no reconnect attempts while sleeping", net.restore_calls == 1)
end

do
    local w, ui, net, bo, ctx = env{ off_in_book = false, net = { connect_after = 2 } }
    local other = w:acquire("close-push", function() end)
    Sleep.run(ctx); ui:advance(5)
    check("X7 another lease keeps Wi-Fi on until it is released (sub 1 off)", #bo.pushes == 1 and net.wifi_on and w.count == 1)
    w:release(other)
    check("X8 last release switches it off", not net.wifi_on and w.count == 0)
end

do
    local w, ui, net, bo, ctx = env{ off_in_book = false }
    net.wifi_on, net.online = true, true     -- platform that did not kill Wi-Fi
    Sleep.run(ctx)
    check("X9 already online, sub 1 off: pushes then switches off", #bo.pushes == 1 and not net.wifi_on and w.count == 0)
end

-- ---------------------------------------------------------------------
-- batch 6A: the sleep push goes through the pull-before-push guard
-- ---------------------------------------------------------------------
do
    -- server is ahead (another device wrote): skip, do NOT queue, radio off again
    local w, ui, net, bo, ctx = env{ net = { connect_after = 2 }, off_in_book = false }
    local guarded_calls = 0
    function bo.pushProgressGuarded(fp, pct, pos)
        guarded_calls = guarded_calls + 1
        return false, "server_ahead", { percentage = 0.9 }
    end
    Sleep.run(ctx); ui:advance(20)
    check("Y1 server ahead: guarded push attempted once, nothing queued, plain push not used",
        guarded_calls == 1 and #bo.pending == 0 and #bo.pushes == 0)
    check("Y2 server ahead: radio is switched off again, lease released",
        not net.wifi_on and w.count == 0)
end
do
    local w, ui, net, bo, ctx = env{ net = { connect_after = 2 } }
    local seen_args
    function bo.pushProgressGuarded(fp, pct, pos) seen_args = { fp, pct, pos }; return true end
    Sleep.run(ctx); ui:advance(20)
    check("Y3 guard clear: the guarded push carries the live place, nothing queued",
        seen_args and seen_args[1] == "/b/a.epub" and seen_args[2] == 0.42 and seen_args[3] == "xp1" and #bo.pending == 0)
end
do
    -- guarded push fails for another reason (e.g. HTTP error): queued as before
    local w, ui, net, bo, ctx = env{ net = { connect_after = 2 } }
    function bo.pushProgressGuarded() return false, 500 end
    Sleep.run(ctx); ui:advance(20)
    check("Y4 guarded push fails (not server_ahead): place is queued", #bo.pending == 1)
end
do
    -- guarded push throws: queued, lease still released
    local w, ui, net, bo, ctx = env{ net = { connect_after = 2 } }
    function bo.pushProgressGuarded() error("boom") end
    Sleep.run(ctx); ui:advance(20)
    check("Y5 guarded push throws: queued and no lease leaks", #bo.pending == 1 and w.count == 0)
end

print(string.format("RESULT: %d passed, %d failed", passes, fails))
return fails > 0 and 1 or nil
