# Auto Wi-Fi (BookOrbit)

One setting, **Auto Wi-Fi**, with three options, replaces the two older toggles ("Auto-connect Wi-Fi for sync" and
"Auto-connect Wi-Fi on BookOrbit access"). Menu: Bookshelf settings > BookOrbit > Auto Wi-Fi.

**Not run on a device.** The logic is covered by off-device tests with fake radio and scheduler; the KOReader
behaviour it relies on was read from KOReader's source (v2025.08 and master), not observed on hardware. See
"Verify on a device" at the end.

## Settings

| Menu entry | Key | Default | What it does |
|---|---|---|---|
| Enable Auto Wi-Fi | `auto_wifi` | off | Wi-Fi is connected once Bookshelf starts and kept on while you are on the home screen. No idle timeout. |
| Disconnect Wi-Fi when book is opened | `auto_wifi_off_in_book` | off | Wi-Fi goes off when a book is opened (after the check for newer progress has finished) and comes back when the book is closed, so the push goes out and BookOrbit chips load at once. Wi-Fi is turned off even if you had switched it on yourself. |
| Push progress on sleep | `auto_wifi_sync_on_sleep` | off | Pressing sleep with a book open: Wi-Fi on, push your place, Wi-Fi off, then sleep. Works with or without the option above. (Called "Sync book progress on sleep" in earlier builds; the key is unchanged, so the saved choice carries over.) |
| Pull progress on wake | `auto_wifi_pull_on_wake` | off | Waking the device with a book open: Wi-Fi on, ask BookOrbit for a newer place from another device, offer it, Wi-Fi off again (if "Disconnect Wi-Fi when book is opened" is on). Independent of the two options above. |

The three options are greyed out while Auto Wi-Fi is off. While Auto Wi-Fi is on, **Skip when offline** is ignored
and greyed out (Auto Wi-Fi manages Wi-Fi itself and always tries to sync).

## When Wi-Fi is (re)connected ("triggers")

1. The first time the Bookshelf home screen is shown after KOReader starts.
2. A book is closed and you return to the home screen. (Closing one book only to open another does not
   reconnect, to avoid switching the radio off and on in between.)
3. The device wakes while the home screen is showing.
3a. The device wakes with a book open and its place already checked against BookOrbit, with "Pull progress on wake" on ("pull on wake", below).
4. "Sync now" (menu item and the dispatcher action).
5. Push on sleep (above).

Not triggers: opening a BookOrbit chip or section, turning pages, the periodic push while reading.

**Manual off is respected.** If you switch Wi-Fi off yourself, Auto Wi-Fi leaves it off until the next trigger.
It does not keep reconnecting. A radio that is on but out of range is not a manual off. KOReader's own idle
"auto disable Wi-Fi" and its switching Wi-Fi off when the device sleeps also look like a manual off until the
next trigger.

## How it connects

- Where the device supports it (Kobo, Kindle) the connection uses KOReader's quiet background reconnect
  (`restoreWifiAsync`): no dialogs, the interface is not blocked, and out of range of every known network it gives up
  by itself. Otherwise it uses `enableWifi(callback, false)`, KOReader's non-interactive turn-on (on Kobo this
  blocks while scanning and shows KOReader's own "Scanning for networks" notices).
- Home connection: attempts at about 0 s, 30 s, 60 s and 120 s, then it stops until the next trigger.
- Jobs (push on close, pull on open, Sync now, sleep sync) take a lease on the connection. Wi-Fi is only turned
  off when the last lease is gone, so one job can no longer switch Wi-Fi off under another.
- If Wi-Fi does not come up in time, the push is queued (`markPendingSync`) and sent after the next connection,
  instead of being dropped as before.

## Book open and close

- Open, with "Disconnect Wi-Fi when book is opened" off: nothing changes; Wi-Fi stays on and the pull on open runs.
- Open, with it on: the pull on open runs first (Wi-Fi is already up from home); Wi-Fi goes off when that pull
  has finished, succeeded or failed. If auto-sync is off or BookOrbit is not configured, it goes off straight away.
- Close back to home: Wi-Fi reconnects, the push goes out, and you land on a shelf that is already online.

## Push progress on sleep

What KOReader does when you press sleep (read from its source): it shows the sleep screen, switches Wi-Fi off,
sends the `Suspend` event, and only about 15 seconds later really suspends. Bookshelf uses that gap:

- It skips everything if the place has not changed since the last successful push (so Wi-Fi is not woken for
  nothing) or the place was not yet compared with BookOrbit's on open.
- Otherwise: connect, push, switch Wi-Fi off. The time allowed is the device's suspend delay minus 3 s, 12 s on a
  stock device. If it does not make it, or the push fails, the place is queued and the device sleeps on time.
- No message is shown: the sleep screen is already up and anything drawn would stay on it.
- The sleep never waits for the push beyond that limit (a very slow server can still run a little over: the push is
  not aborted).
- The push is checked against the server first (see "Pull-before-push guard" in BOOKORBIT_SYNC_OPTIONS.md). If
  another device wrote a newer place in the meantime, nothing is pushed or queued and Wi-Fi is switched off as usual;
  the newer place is offered the next time the book is opened. The check shares the same connection window.

## Migration

On first start with this version: Auto Wi-Fi is on if either old toggle was on. Both options start off. The old
"On book open" and "Auto-disconnect timeout" settings have no equivalent and are deleted along with the other old
keys. This runs once; the old keys are also cleaned from profiles that an earlier test build had already migrated.

## Pull on wake (a book is open)

When the device wakes with a book open, **Pull progress on wake** is on (which needs Auto Wi-Fi on), BookOrbit is
configured and Auto-sync is on, Bookshelf
connects Wi-Fi quietly (the same background path as sleep sync), asks BookOrbit for its place and, if another device
has written a place you have not looked at yet, offers it with the same notice / "Go to page" prompt as when opening
a book (it follows your forward/backward strategy; "Stay" shows nothing). The decision is the one the push guard
uses (`checkServerBeforePush`), so "ahead" means the same thing everywhere. Offering counts as looking at it.

- It clears a manual Wi-Fi off (a wake is a trigger).
- With "Disconnect Wi-Fi when book is opened" Wi-Fi goes off again as soon as the check is done; without it Wi-Fi
  stays on, as it does in a book today.
- A failed check (out of range, timeout, server error) is quiet; your place is kept.
- No minimum sleep time: every wake pulls. Resume and LeaveStandby for one wake pull once.
- Not on the home screen (that is the reconnect trigger above), and not while the reader is still opening (pull on
  open does that).

## Known limits

- Hot parking: while a parked reader sits under the shelf no close happens, so the book still counts as open. With
  "Disconnect Wi-Fi when book is opened", Wi-Fi stays off on the shelf until the parked book really closes.
- Pull on wake costs battery: there is no minimum sleep time, every wake with a book open connects briefly. That is
  why it has its own switch, off by default.
- Pull on wake needs Auto Wi-Fi: the Wi-Fi controller does nothing while Auto Wi-Fi is off, so the option is greyed out
  then, and a stored "on" has no effect until Auto Wi-Fi is on again.
- Upgrade note: in the earlier Batch 6B build the wake pull ran whenever Auto Wi-Fi was on. It now needs its own switch,
  which starts off: turn on "Pull progress on wake" to get the old behaviour back.
- Pull on wake is skipped quietly while a gesture-unlock screen waits for ~30 s (it runs once you unlock) and while a sleep sync is still running; if neither clears in ~30 s it gives up. The push guard still protects the next push.
- Keeping Wi-Fi on at home uses battery. "Disconnect Wi-Fi when book is opened" is the battery-friendly choice.
- Where `restoreWifiAsync` only enables the radio and lets the framework reconnect (Kindle), the connection can take
  longer than the sleep window; the push is then queued.

## Verify on a device

1. Start with Auto Wi-Fi on: Wi-Fi connects on the home screen and stays on; no "Scanning for networks" notice.
2. Switch Wi-Fi off by hand on home: it stays off. Close a book or wake the device: it reconnects.
3. Option 1 on: open a book, the pull happens, Wi-Fi goes off; close it, Wi-Fi returns and the push goes out.
4. Close a book and quickly open another: Wi-Fi never drops during a push or pull.
5. "Push progress on sleep" on, in range, with option 1 both on and off: press sleep with a changed place: the place reaches
   BookOrbit, Wi-Fi is off afterwards, the device sleeps, the sleep screen shows nothing extra.
6. "Push progress on sleep" on, out of range: the device sleeps within about 15 s; the place is sent after the next connection.
7. Press sleep again without turning a page: Wi-Fi is not woken.
8. Upgrade: a user with either old toggle on gets Auto Wi-Fi on, options off.
9. Two devices, same book. Read ahead on device 2 and let it push. On device 1 (book still open) turn pages: the
   "BookOrbit has progress from another device" prompt appears instead of device 1 overwriting device 2's place.
   Dismiss it, keep reading: pushes from device 1 resume.
10. Same, but press sleep on device 1 with "Push progress on sleep" on: the push is skipped, Wi-Fi ends off, nothing is queued.
11. Read ahead on device 2, then close the (offline-opened) book on device 1: device 2's place survives.
12. A queued push on device 1 (read offline), meanwhile device 2 reads further: after reconnecting, device 2's place
    survives and the queue is empty.
13. (Pull on wake, "Pull progress on wake" on) Two devices, same book open. Read ahead on device 2. Wake device 1 (in range): Wi-Fi comes up
    quietly, the "BookOrbit has progress from another device" prompt appears; with option 1 on Wi-Fi is off again
    afterwards, with option 1 off it stays on.
14. Same, out of range: nothing is shown, the book stays where it was, the device is usable at once.
15. Wake with nothing newer on the server: no prompt. Press sleep and wake twice in a row: it pulls each time.
    With "Pull progress on wake" off (Auto Wi-Fi still on): waking with a book open does not connect Wi-Fi or pull.
    "Push progress on sleep" still works with the wake switch off, and the other way round.
16. Gesture-unlock sleep screen: nothing is shown over it; after unlocking the check runs.
17. Wi-Fi switched off by hand, then sleep and wake in a book: it reconnects for the check.
