# Micro-module height setting

Long-press a micro-module (hero grid or full-screen view): below the page row
there is now a **Height** row: `−`, `Height N` (tap to reset to 0), `+`.
The existing `−` / `+` beside the move arrows still set the width.

- Stored as `entry.vsize`, range -2..4, absent when 0. Width stays `entry.size`.
- A row's height share is the largest height weight among its cards
  (weight = 1 + 0.25 * vsize, so 0.5x .. 2x). A shorter card in the same row is
  centred in it. Rows are normalised to fill the grid, so making one row taller
  squeezes the others.
- If every row is weighted below 1 the grid is shorter than the hero area
  (e.g. a single card at -2 is half height); the hero pads the slack below.
- vsize 0 everywhere gives the old equal-height rows exactly.
- Changed: `lib/bookshelf_hero_modules.lua` (build), `lib/bookshelf_hero_modules_edit.lua`
  (dialog), `locale/bookshelf.pot`, `micromodules/README.md`.
- Not run on a device or under Lua (none available here); static check passes.

## Per-module font size

Long-press a micro-module: **Font N%** row (`−`, value, `+`; tap the value to
reset). Stored as `entry.fscale`, -3..+5 steps of 10% (70%..150%), absent when
0. It multiplies the global "Hero micro-modules" size (`hero_module_font_scale`)
for that card only, and is applied after the auto-fit like the global knob, so
sizes above 100% can overflow the card and get clipped (modules that honour
`ctx.clamp` ellipsise instead). Changed: `lib/bookshelf_hero_modules.lua`
(`_makeCell`), `lib/bookshelf_hero_modules_edit.lua`, `locale/bookshelf.pot`.

### Font size and the BookOrbit widgets (fix)

The first version of the Font row did nothing on the BookOrbit modules: their
adapter (`lib/bookshelf_bo_module.lua`) ignores `ctx.scale`, which is what the
generic font multiplier works through. Now:

- `lib/bookorbit_board/metrics.lua`: new text-only scale (`setTextScale`),
  applied in `fs()` and `fontSize()`, so fonts and the line heights derived from
  them grow, while boxes, icons and spacing do not.
- `lib/bookshelf_bo_module.lua`: `Bo.textPercent(ctx)` = card font step x the
  global micro-module size (grids only), set around each draw and always reset
  to 1. The layout-pick memo and tap-region cache keys include the text size.
  The spec sets `own_font_scale = true` so the host skips its generic multiplier.
- BookOrbit's own layout chooser (`BoardUI.pick`) still runs, so a larger font
  may switch a widget to a more compact layout instead of overflowing.
