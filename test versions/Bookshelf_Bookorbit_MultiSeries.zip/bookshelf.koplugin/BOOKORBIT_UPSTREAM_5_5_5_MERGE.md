# Bookshelf.koplugin BookOrbit fork: upstream 4.7.0 -> 5.5.5 merge

Version string: `5.5.5-bookorbit1` (fork of AndyHazz/bookshelf.koplugin v5.5.5 + the BookOrbit integration).
Minimum KOReader: **v2025.08** (upstream's `lib/bookshelf_version_gate.lua`; older builds get a one-line stub).

Method: 3-way merge (base v4.7.0, ours = the 4.7.0-bookorbit1 fork, theirs = v5.5.5), conflicts resolved file by file in
batches 1-7, verification in batch 8. Rule: upstream wins everywhere except BookOrbit and the fork-only features below.

## Decisions
- D1 Cover cache: upstream's filepath-only cache + `bookshelf_hero_tier.lua`; the fork's size-tier cache is dropped.
  BookOrbit's distorted-covers fix is independent of it (`bookshelf_bookorbit_source.lua` wantsCover(), and the two
  `self.book.cover_bb = nil` spots in the spine widget) and was verified present.
- D2 Last-row gap: upstream's `GridMargins` layout (`grid_between` / `grid_last`). The fork's `_shelfBottomPad`,
  `chip_to_row_pad` and per-row `span_w` are gone. `footer_geom.hitExtension()` is still 0. Visible difference: the gap under
  the last row is upstream's balanced one, not the old tight one. To get it back, shrink `grid_last` / `last_min`
  (separate optional step).
- D3 BookOrbit is NOT moved onto upstream's shelf-source API; both code paths coexist (`_expandBookOrbitGroup` and
  `_expandSourceNav`).
- D4 Storage: BookOrbit files keep their flat names (`bookorbit_settings.lua`, `bookshelf_bookorbit_*`) and are not on
  upstream's storage-move list, so existing credentials and caches survive. The `bookorbit_*` keys live in the store file that
  upstream moves to `settings/bookshelf/settings.lua` by exact filename.
- D5 `_meta.lua` -> `5.5.5-bookorbit1`.
- D6 Fork extras kept: `tools/check_token_parity.sh`, `tools/gen_pinyin_table.py`, all `BOOKORBIT_*.md`, the server patch.
  Empty runtime dirs dropped; the stale 3.10.8->4.7 handoff removed from the package.
- D7 `main.lua`: upstream's dead top-level selection-mode menu item dropped; the fork's DISABLED Updates row kept
  (no auto-update from upstream releases).
- D8 Cover-cache budget menu keeps the fork's 8-1024 MB range; upstream's device-aware default. Upstream's entry-count backstop
  `_capacity = 1024` is unchanged (raise it at ~L95 of `bookshelf_scaled_cover_cache.lua` if a big BookOrbit session
  should cache more than 1024 covers).
- D9 Preview refresh runs inside the fork's `_rebuildRefreshHeroAndChips(after_fn)` so a pending BookOrbit fetch cannot race it.
- D10 Upstream's new vertical-budget code honours the fork's `hero_top_pad` (`self:_topPad(PAD)`), and `foot_offset` uses
  `footer_geom.artSize()` (footer height setting).
- D11 d-pad footer buttons: upstream's code; the fork's `_swapFooterInPlace` after_fn is obsolete (upstream's swap rebuilds the footer).
- D12 `_rebuildRefreshChipStrip` (new upstream) is Trapper-wrapped like its siblings.
- Trapper rule: the fork wraps `_swapShelvesInPlace`, `_rebuildRefreshBelowHero`, `_rebuildRefreshHeroAndChips`,
  `_rebuildRefreshChipStrip` (and others) in a Trapper coroutine with optional `after_fn`, so a BookOrbit fetch inside
  `_rebuild()` can yield. Upstream has no such plumbing; each function's body is upstream's, re-wrapped.

## Fork-only non-BookOrbit features that must keep working
Footer height scale, `chip_height_scale`, `expanded_shelf_columns` / `expanded_shelf_rows` (via `_maxRowsSquashed`, now based on
`_expandedBand`), hero padding settings, `%free_ram` token, hero tags options (`show_similar`, generic author/series labels),
image-cache lifetime fixes, Kobo cover decode check.

## File-by-file outcome (conflicted files)
`_meta.lua`, `sort_engine` (`or item.label` kept), `shelf_row` (`bookorbit_group` branch kept), `scaled_cover_cache` (= upstream),
`spine_widget` (upstream cache-first block), `hero_card` (community stars kept + themed ink), `main.lua` (push-on-close,
pull-on-open kept), `book_repository` (multi-series: upstream's groups + fork's tag-derived `extra_series`; `getBySource`
keeps the `bookorbit` branch), `settings` (cache budget menu), `widget` (40 hunks).
Auto-merged fork-touched files were audited line by line in batch 2 (no fork line lost or duplicated).

## Verification done in batch 8
- No conflict markers anywhere; `luac5.1 -p` passes on every .lua except three that use `goto continue` (LuaJIT-only syntax,
  untouched by the merge).
- Every `require("lib/...")` target exists. No BookOrbit lib calls a missing function in another lib, and no shared file calls a
  missing BookOrbit function.
- Widget: same global-name set as upstream; every `self:_x()` / `bw:_x()` target is defined.
- Not done: `tools/check_token_parity.sh` (needs the sibling `bookends.koplugin` repo), running on a device.
