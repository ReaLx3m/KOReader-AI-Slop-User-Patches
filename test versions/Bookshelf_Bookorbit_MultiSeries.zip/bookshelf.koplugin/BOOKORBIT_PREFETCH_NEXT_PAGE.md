# BookOrbit: non-blocking "Prefetch next page"

Status: implemented and tested off-device only (pure modules, the real source
under fakes). **Not run on a device.**

## Problem
With Settings > BookOrbit > "Prefetch next page" on, page turning became
sluggish. One second after each page, the UI thread did blocking work: a
`catalogBooks` list request, one blocking detail request per book (descriptions)
and one blocking cover download per missing cover, one per 0.08 s tick. A swipe
made in that window waited for the current request. It was also re-armed by
every cascading rebuild and by the automatic warm-up's own fetches.

## New behaviour (setting on)
- Nothing blocks the UI thread. The next page's list goes through the forked,
  non-urgent page fetcher; its covers go through a second, width-1, forked
  download pool.
- Covers are downloaded and, with the sub-setting "Decode covers ahead" on (the
  default), also decoded ahead (see "Decode-ahead" below): the decoded bitmaps are
  attached to the cached records of the next page, so turning to it paints with
  its covers at once instead of decoding them one per tick. With the sub-setting
  off the prefetch is download only: no decode, no bitmaps, no memory held.
- Descriptions are no longer prefetched by this setting.
- One lookahead only: armed from a normal page call, never from the warm-up's
  preload fetch (`opts.preload`).
- Idempotent per page: rebuilds that call it again do nothing.

## "Settled" (when it may start)
All of: the visible page's list is cached (the call comes from the cache-hit
path), the visible page's cover chain has drained (downloaded, given up or
decoded), no inline cover fill is running, no urgent page job is in flight, the
device is online, then `PREFETCH_SETTLE_DELAY_S` (1.0 s) of quiet, re-checked
when the timer fires. Not settled: it waits for the next notification, no polling.

## Yielding and stopping
- A visible cover chain starting shuts the prefetch pool down (its in-flight
  download is killed and its `.part` removed, so two workers never write one file).
  It re-arms itself when the main pool goes idle.
- A page the user turns to (urgent job) drops the intent as `visible`.
- Offline: never starts, intent dropped. Failed or unavailable list: dropped, key
  marked done, no retry loop (the fetcher also has a 10 s cool-down).
- Closing the shelf (`shutdownCoverPool`, `shutdownPageFetch`) kills workers and
  resets state. A manual refresh (`invalidateNextPageCache`) forgets done keys;
  `clearThumbFailures` also resets the prefetch pool's give-up list.
- Cover failures: only definitive server answers (`http_4xx`, `not_an_image`,
  `no_cover`) blacklist a cover for the visible page; timeouts and crashes do not.

## Settings
- **Prefetch next page** (`bookorbit_prefetch_next_page`, default off): the list
  and the cover downloads described above.
- **Decode covers ahead** (`bookorbit_prefetch_decode_ahead`, default ON, i.e. ON
  unless explicitly switched off; shown right below the parent and only active
  while the parent is on): the in-memory decode below. OFF = download only, and a
  page's disk hits are not queued at all (only covers missing from disk are).
- Switching the sub-setting OR the parent OFF frees the covers already held
  (`BOSource.releaseDecodeAhead`, log reason `setting`). Queued decodes of that
  page are then vetoed. Switching it ON takes effect at the next prefetched page.

## Decode-ahead
After the downloads, the prefetch pool decodes every cover of the next page that
`wantsCover` accepts (disk hits included), one per 20 ms tick in the UI process,
and attaches `cover_bb/cover_w/cover_h`, `has_cover = true` and
`_cover_filled = true` to the SAME cached record the grid will receive. A record
that is `_cover_filled` is never queued by `scheduleCoverFills`, so the turn
starts no cover chain and the widget paints straight from `cover_bb`.
- **Holder** (`lib/bookshelf_bookorbit_ahead.lua`): remembers which records carry
  a decoded-ahead bitmap, for ONE prefetched page at a time (`max_records = 36`).
  A bitmap is only ever dropped by clearing `cover_bb`, `cover_w`, `cover_h` AND
  `_cover_filled` together (never `:free()`; the widget frees what it consumes).
  Records the widget already consumed (`cover_bb` nil, `_cover_filled` true) and
  records somebody else filled are left alone.
- **Release** happens only at: the NEXT page's step B (>= 1 s of quiet after it
  settled, `reason=newpage`), `prefetchStop` (shelf closed, `reason=stop`) and
  `invalidateNextPageCache` (manual refresh, `reason=invalidate`) and the menu
  (a setting switched off, `reason=setting`). Never at
  `request()` / `cancel_covers` / `supersede` time: those run inside a page turn,
  before the widget has painted.
- **Stale work:** when another page is armed, pending downloads AND queued
  decodes of the old page are cancelled (`cancelDecode`). A download of a stale
  page that was already in flight still lands; it is NOT decoded (its file stays
  on disk for a later visit).
- **Size cap:** a page of more than 36 records is download-only, exactly as
  before decode-ahead (no decode, no RAM).
- **Bad file:** removed, re-downloaded once, then given up (same as the visible pool).
- Without "Scale ahead" (below) the turn is cheaper than a decode but not free:
  scale + `ScaledCoverCache:put` (+ disk write-through) would still run inside
  the paint. "Scale ahead" moves that work into the idle ticks; this raw path is
  the fallback when it cannot.

## Scale ahead (prescale, part of "Decode covers ahead")
Why: a revisited page is instant because its covers are already scaled in
`ScaledCoverCache`; a decoded-ahead record carried the RAW bitmap, so the first
paint still scaled each cover and wrote it to the flash disk cache synchronously.
That was the assumed cause of the 3-4 s turn on a slow device (assumed, not
measured). No new setting: it is part of "Decode covers ahead".

Flow, per cover, in the prefetch pool's decode tick (one per 20 ms), after the
page-is-still-current veto and the JPEG decode:
1. The source offers the fresh bitmap to an injected hook
   (`M.setCoverPrescaler(fn)`, registered by the widget, cleared at teardown while
   it is still the live widget). `fn(record, bb) -> status, stats`.
2. The widget side (`lib/bookshelf_bookorbit_prescale.lua`, injected deps) works out
   the EXACT painted image size for that book (`SpineWidget.imageDims` on the
   tile size of the page on screen; with "true cover aspect" per book through
   `trueAspectBoxHeight`, like `ShelfRow`), asks `ScaledCoverCache` whether it
   already has that cover at >= that size (`"already"`, no scale, no disk write),
   otherwise scales with `SpineWidget.fillScale` (the same `_coverFillBB` the paint
   uses, so the picture is identical) and `ScaledCoverCache:put` (disk
   write-through included): `"scaled"`.
3. On `"scaled"` / `"already"` the source frees the raw bitmap (it owns it, no
   widget ever saw it), leaves `cover_bb = nil`, sets `has_cover` and
   `_cover_filled` and does NOT register the record with the holder. The record is
   now what a revisited one is: the turn is a cache hit plus a blit, and RAM holds
   no raw bitmap.
4. Anything else (no hook, list mode, hero / folder / author tile, widget closed
   or not yet laid out, `nil`, an unknown string, a throw) falls back to the raw
   decode-ahead path above, unchanged. The visible-page pool never calls the hook.

Grid mode and numeric BookOrbit books (`bookorbit://<id>`) only.

Tile size changes (cover size, columns, rows, shadow, "true cover aspect", view
mode, draft regrid steps). A prescaled entry then has the old size and the paint
would grow it (blurry). The widget compares a geometry signature after every shelf
build / in-place swap (`_syncCoverTile`, class-level, first call only records) and
calls `M.coverTileChanged()`:
- it clears `_cover_filled` (only) on every prescaled record whose page has NOT yet
  been handed to the widget (records are tracked in a weak table; a non-preload
  `listBooks` cache hit counts as the turn, the widget's own next-page warm-up does
  not), so the normal fill chain decodes them at the new size;
- if it cleared anything it also makes the prefetch machine forget its done keys
  (`Prefetch:forgetDone`, S4b; it touches nothing else: no intent, timer, cancel,
  pool or holder), except the page whose covers are downloading right now. The
  widget's next rebuild calls `prefetchNextPage` as always, the waiting page arms
  again, settles 1 s, and its covers are decoded and prescaled at the NEW size.

Log lines (dbg): `bo prefetch: decode-ahead n=<all kept> prescaled=<n> raw=<n>
bytes=<raw bytes still held> ms=<chain wall> prescale_ms=<sum of the hook calls>`;
per scaled cover `bo prescale: id=<id> <w>x<h> scale=<ms>ms put=<ms>ms` (put
includes the disk write: these two numbers say whether scaling or the disk write
dominated); `bo prescale: tile changed, <n> prefetched cover(s) will be decoded
again`; `bo prescale: prefetch will look at <n> page(s) again`.

Risks and limits (none run on a device):
- R-S1 CPU in the idle tick: decode + scale + put + disk write for one cover per
  tick; a tap landing mid-tick waits for it. Unmeasured (100-400 ms guessed). If the
  log shows heavy ticks, split decode and scale+put over two ticks (optional S5b).
- R-S2 tile size changes: handled as above. A page whose covers are downloading at
  the moment of the change keeps its done key, so its covers prescaled BEFORE the
  change take the normal chain at the turn (the rest are prescaled at the new size).
  A turn within about a second of the change also uses the normal chain once.
  Re-arming the same page starts a new holder generation: a record the prescaler had
  declined (raw bitmap held) loses bitmap and flag together and is decoded at the turn.
  All done keys are forgotten, so a page whose list fetch failed earlier may be
  retried once.
- R-S3 true aspect is per book: the size is computed per record exactly like
  `ShelfRow`; a too-small entry would be grown blurry, a too-big one costs one
  `_thumbFor` in the paint.
- R-S4 the result must equal a normal paint: the same `_coverFillBB`, never a copy.
- R-S5 eviction / `clear()` / `drop()`: an evicted prescaled cover comes back from
  the disk cache (write-through); after `clear()` / `drop()` a flagged record with no
  cache entry shows a placeholder, the same exposure a revisited record has.
- R-S6 record identity: unchanged from R-D5 (not provable off-device).
- R-S7 e-ink / colour: `bb:scale` keeps the bitmap type; a scaled 118x158 cover is
  about 19 KB grey / 75 KB colour, and no raw bitmap is held any more.
- Raising `PREFETCH_POOL_WIDTH` (1 now, about 455 ms per cover download, about 4 s
  for a page whose covers are not on disk) to 2-3 would shorten the time until a
  page is ready; deliberately not done (D-S5, only on request).

## Constants (`bookshelf_bookorbit_source.lua`)
`PREFETCH_SETTLE_DELAY_S = 1.0`, `PREFETCH_POOL_WIDTH = 1`,
`PREFETCH_DONE_KEYS_MAX = 64` (session memory, FIFO),
`PREFETCH_AHEAD_MAX_RECORDS = 36`. (Prescale adds none: the tile size comes from
the widget at run time.)

## Debug log lines (all `[bookshelf perf] bo prefetch: ...`)
`armed key=`, `not settled, waiting`, `list requested ->`, `list landed ok=`,
`page gone from the cache`, `nothing to download`, `covers queued n=`,
`superseded`, `dropped reason=`; plus `bo prefetch cover worker: key= ms= result=`
and, for decode-ahead, `decode-ahead n=<records> prescaled=<n> raw=<n> bytes=<held raw bytes> ms=<chain wall> prescale_ms=<sum>`
(when the prefetch pool drains; `bytes` is the RAM the RAW records of one prefetched
page hold, 0 when everything was prescaled; see "Scale ahead" for the `bo prescale:`
lines) and
`decode-ahead released n=<records> reason=<newpage|stop|invalidate|setting>`. Note that
`covers queued n=` is written by the state machine and counts everything the
source accepts (an oversize page shows its full size, then is narrowed to the
missing covers).

## Known limits
- Observation O1 (fixed in P5, not run on a device): the automatic warm-up of
  the on-screen chip's next page (`opts.preload_visible`) no longer runs
  `scheduleCoverFills`, so it cannot replace the visible page's pending covers
  or make the prefetch yield. Consequence: a cached next page gets no covers
  from the warm-up; they come from this setting (if on) or when you turn to it.
  Chip pre-warm of other chips (`opts.preload` only) keeps its cover fills.
- RAM (R-D1): records the prescale handled hold no raw bitmap (their scaled cover
  lives in `ScaledCoverCache`, within its own budget). Only records the prescaler
  declined hold one page of decoded, UNSCALED thumbnails outside the 64 MB
  page-cache budget (that budget does not see bitmaps); the `decode-ahead bytes=`
  log field shows it. Colour devices hold about 4 bytes per pixel.
- CPU (R-D2): one decode per tick in the UI process (as the visible pool); a swipe
  waits at most one decode. Starts only after settle + 1 s of quiet, and a real
  visible chain shuts it down.
- When the next page has nothing wanted (everything already filled, or download
  only and all on disk) step B never reaches the enqueue step, so the previous
  page is not released there; it is released by the menu, `stop`, `invalidate` or
  the next step B that has work. Records the widget consumed hold nothing, so this
  only keeps bitmaps that were never painted.
- Accepted edge (R-D3): a record of the previous page that the widget has NOT
  consumed by the time of the next step B loses its bitmap and flag and is covered
  again by the next normal fill. Not expected in practice.
- Record identity (R-D5): relies on the cache handing back the same record tables
  and the grid passing them to SpineWidget (read in the source, not provable off-device).
  In list mode a row copy carries no bitmap; a cover not yet in `ScaledCoverCache`
  may paint a placeholder there until the normal fill (unverified).
- Not a true revisit (R-D4): see "Decode-ahead".
- discover / similar / want_to_read chips are never prefetched.

## On-device checklist
(0. is the decode-ahead check, S1-S6 below it the scale-ahead checks; the numbered
items 1-9 are the older ones.)
S1. Setting on, Decode covers ahead on, a chip with several pages. Sit on a page
   about 6 s, turn: covers appear with the list, the turn feels like a revisit
   (it took 3-4 s before). Report the `bo prescale: ... scale=.. put=..` numbers and
   `prescaled=`/`raw=` in the `decode-ahead` line (raw > 0 means the prescaler declined).
S2. Swipe repeatedly right after a turn: responsive (a tap waits for at most one
   idle tick); report the slowest tick if noticeable.
S3. Turn while the prefetch still runs, and page back and forth over visited pages:
   no blank, distorted or blurry cover.
S4. Change cover size / columns / shadow / true cover aspect while a prefetched page
   waits (also pinch / draft regrid): covers on the page you turn to are sharp; the
   log shows `tile changed, N ...` then `prefetch will look at N page(s) again`, and
   about a second after the rebuild a new `armed`, `covers queued` and
   `decode-ahead ... prescaled=` for that page. The page on screen keeps its covers.
S5. Wi-Fi off, either toggle off, close the shelf mid-prefetch, manual refresh of the
   chip: nothing breaks.
S6. A large page (e.g. 24 books): no out-of-memory, no slowdown.
0. Setting on, a chip with several pages, Wi-Fi on. Sit on a page until its covers
   show, wait about 3 s, turn the page: the covers must appear WITH the list (no
   blank-then-populate). Log: `decode-ahead n=.. bytes=.. ms=..` after the prefetch
   (report `bytes`) and `decode-ahead released ..` when moving to another page.
   Swipe repeatedly right after a turn: no multi-second stall. Turn while the
   prefetch is still decoding: no cover stays blank. Page back and forth: no blank
   or distorted covers. Wi-Fi off, setting off, close the shelf mid-prefetch, manual
   refresh: nothing breaks, `released reason=stop|invalidate` logged. A large page
   (e.g. 24 books): no out-of-memory, no slowdown. "Decode covers ahead" off with
   Prefetch next page on: the next page's covers are only downloaded (no
   `decode-ahead` log lines) and the turn decodes them as before; the item is greyed
   out while Prefetch next page is off; switching it off with a page held logs
   `released ... reason=setting`.
1. Setting on, a chip with several pages, Wi-Fi on: turn a page, then swipe again
   at once. No multi-second wait.
2. Leave the page alone: after its covers finish plus about 1 s, the next list and
   covers are fetched quietly (log lines above). Turning to it: list instant, covers
   from disk.
3. Turn the page while covers still download: no prefetch starts until they
   finish; a turn drops a not-yet-started prefetch.
4. Wi-Fi off: nothing starts, no error, no prompt.
5. Close the shelf mid-prefetch: no leftover processes, no error on return.
6. Setting off: no prefetch activity in the log.
7. Slow server: no freeze; a failed next list is not retried in a loop.
8. O1: with the setting off, sitting on a page whose next page is cached must not
   disturb the current page's covers; chip pre-warm still gives other chips covers.
9. Hold feature unaffected (a never-fetched page still holds the old screen).
