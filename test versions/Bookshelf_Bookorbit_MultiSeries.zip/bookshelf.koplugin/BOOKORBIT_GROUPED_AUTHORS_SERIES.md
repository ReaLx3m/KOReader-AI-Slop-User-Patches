# BookOrbit chips: grouped Authors / Series browsing

## What changed

A chip pointed at BookOrbit's "All authors" or "All series" leaf (pick
"Authors" or "Series" in the chip editor's BookOrbit picker, then "All
authors"/"All series" instead of one specific entry) now shows one
folder-like tile per author/series -- tap a tile to drill into just that
author's/series' books, same navigation model (breadcrumb, back button,
east-swipe-back) as the local library's Author/Series chips. Previously
this showed every book from every author, flat, unfiltered -- the empty
author/series filter was silently a no-op server-side.

Picking one *specific* author or series in the chip editor is unchanged
and was already correct -- this only affects the "All ..." root.

## How it works

- `BOSource.isGroupRoot(id)` detects the "authors:"/"series:" root id
  (empty entry, i.e. no specific author/series picked).
- `BOSource.listGroups(section, offset, limit)` walks every page of
  `catalogSection()` once (that endpoint has no caller-settable page
  size, unlike `catalogBooks`, so it can't be mapped onto the grid's
  offset/limit window the way the flat book list is -- see the comment
  in the source), caches the flattened author/series list in memory for
  5 minutes, and slices the requested window out of that cache. Each
  visible tile fetches one sample book (for a real cover preview) via
  the existing `listBooks`/`coverBB` path -- same network/disk-cache
  cost as any other BookOrbit cover.
- `Repo.getBySource`'s `bookorbit` branch calls `listGroups` instead of
  `listBooks` when `isGroupRoot` is true.
- Tiles render via the existing `FolderStack` widget (new
  `item.kind == "bookorbit_group"` branch in `bookshelf_shelf_row.lua`)
  -- a single preview cover + label + count badge, not the 3-cover
  `SeriesStack` the local Author/Series/Genre/Tag chips use, since
  fetching 3 sample books per visible tile would triple the per-page
  network cost for a purely cosmetic peek-behind effect.
- Tapping a tile calls `BookshelfWidget:_expandBookOrbitGroup`, which
  pushes a `kind = "bookorbit_group"` entry onto the existing
  `_drilldown_path` (same breadcrumb/back-navigation machinery as every
  other group kind). The payload only carries `source_id` (e.g.
  `"authors:42"`) -- `_fetchChipItems`'s matching branch re-enters
  `Repo.getBySource` with that id, which is *not* a group root, so it
  lands on the plain, already-working flat `listBooks` path used by a
  hand-picked single-author/single-series chip.
- Drilldown persistence (surviving a KOReader restart) and D-pad/
  keyboard navigation both got the same treatment as the other group
  kinds already have.
- The "Refresh library" action (chip menu) now also drops the cached
  author/series lists, alongside the existing Discover-batch drop, so a
  newly added author/series shows up without waiting out the 5-minute
  cache.

## Fix: group tiles had no cover preview

The tiles rendered, but with no cover image. Root cause was in
`FolderStack`, not in the new BookOrbit code: its inner `SpineWidget`
uses a `cover_align_top` render path that *deliberately* ignores
`book.cover_bb` (a real bugfix for local-library covers -- a BIM cover
bb is one-shot/shared and reusing it here caused a double-free, per the
comments on `SpineWidget:_renderCoverAlignTop`) and instead re-fetches
via `Repo.getCoverBB(filepath)`. That function explicitly returns nil
for synthetic `bookorbit://` paths, since there's no real file to look
up -- so the cover we'd already attached to `first_book.cover_bb` in
`listGroups` was never read.

Fixed in `bookshelf_folder_stack.lua`: when `first_book.is_bookorbit` is
true, its `cover_bb` is now passed through as an *explicit* widget-level
override -- the same mechanism the custom-folder-image branch already
uses -- bypassing the lazy filepath-based path entirely. Scoped strictly
to `is_bookorbit` records, so local folder-drilldown tiles (Home chip)
are unaffected and keep using the existing double-free-safe lazy path.



## Performance: grouped chips were slower than the old flat view

Real regression, not perception: the old flat "All authors" page did
**one** `catalogBooks` call for all ~6-9 visible books per page. The
grouped root instead does one `catalogBooks` call *per visible tile*,
since there's no bulk "give me one sample book per author" endpoint --
each tile needs its own round trip just to learn what its preview book
is. Worse, unlike the author/series entries list (already cached 5 min),
those per-tile lookups weren't cached at all -- paging back to an
already-seen page re-paid the full cost every time.

Fixed: each entry's resolved sample book is now cached in the same
bucket as the entries list, same 5-minute TTL (`bucket.first_books`,
keyed by entry id; `false` means "looked up, no book/cover" so a
genuinely uncovered author isn't retried every render either). The very
first view of a page of tiles still pays one `catalogBooks` call per
tile -- that's an inherent cost of no bulk endpoint existing -- but
every view after that, within the TTL, is a pure cache hit.

## Fix: covers distorted after navigating away and back

The performance fix above cached the *entire* resolved `first_book`
record -- including its already-decoded `cover_bb` -- for reuse across
renders. But that same `cover_bb` gets handed to
`SpineWidget:_renderCoverAlignTop` as an explicit `cover_bb_disposable =
true` override (see the cover-preview fix above), which **frees it**
after painting -- correct for a one-shot render, but it meant the second
time a cached tile was rendered (navigate away, come back), its cached
`cover_bb` field pointed at memory that render had already freed. Silent
corruption from painting a dangling bitmap -- exactly the failure mode
`SpineWidget`'s own comments warn about for reused local BIM covers,
just re-triggered here by the cache.

First fixed by NOT caching the bitmap at all: only the sample book's
metadata (title, remote_id, etc.) was cached, and every `listGroups`
call -- cache hit or miss -- called `cachedCoverBB()` fresh, which
always re-decodes from the already disk-cached JPEG (no network round
trip on a hit, just a local decode). Safe, but it traded the corruption
bug for a performance one -- see below.

## Fix: nested/grouped sections decoding covers on every render

The metadata-only fix above meant a real JPEG decode on every single
`listGroups()` call for every visible tile, even when nothing had
changed since the last render -- and one page turn typically triggers
2-4 cascading `_rebuild()` calls as `scheduleCoverFills`'s batches land
and fire `onCoversReady`, so the same tiles decoded repeatedly, back to
back. Flat sections (All books, Recently added, ...) don't have this
problem: `listBooks()` returns the same cached record table across
calls, so `wantsCover()`'s `record.cover_bb` guard skips a cover once
it's filled and it's never touched again. Grouped sections built a
brand-new `first_book` table every call specifically so the disposable-
override/free-after-paint contract above couldn't dangle -- but that
also meant `wantsCover()`'s guard could never fire, since it was always
looking at a table that had never been filled before.

Fixed with a real cache for the *bitmap* -- `bookshelf_group_cover_
cache.lua` (`GroupCoverCache`) -- keyed by the entry's `gid` (e.g.
`"authors:42"`), not by the disposable `first_book` table. It follows
the same ownership contract `bookshelf_scaled_cover_cache.lua` already
uses for book covers: hold a strong Lua reference, hand it out to as
many renders as ask for it, never call `bb:free()` on it (blitbuffer's
`ffi.gc` finalizer reclaims the C memory once every reference is gone).
`listGroups()` now checks `GroupCoverCache:get(gid)` before doing any
decode work at all; only a genuine miss pays for `cachedCoverBB()`, and
that result is immediately cached via `GroupCoverCache:put`. The
returned `first_book.cover_bb_cache_owned = true` flag tells
`bookshelf_folder_stack.lua` to pass `cover_bb_disposable = false` for
that bb -- safe because `SpineWidget:_renderCoverAlignTop` always
`bb:scale()`s a private, disposable COPY before painting regardless of
where the source bb came from, and only frees the *source* when the
caller marked it disposable. So the shared bb survives paint after
paint, and only ever gets decoded once per entry, for the life of the
cache (until `invalidateGroupCache()` -- e.g. "Refresh library" -- drops
it, same moment the entries/metadata bucket is dropped).

## Known limitation

`_jumpToLetterPrefix` ("Go to letter" in the page-jump dialog) works
correctly at the grouped root (jumps to the first author/series starting
with a letter) and while drilled into one author/series (jumps within
that author's/series' books). It has not been specifically verified
against `SortEngine.sortKeyValue`'s handling of the group tile's `.label`
field vs. a flat book's `.title`/`.author` fields -- worth an eye if
letter-jump misbehaves specifically on a BookOrbit Authors/Series chip;
it degrades to "No items start with X" rather than crashing either way.

## Testing

`luaparser`-based syntax check passed on all four touched files
(`bookshelf_widget.lua`, `bookshelf_shelf_row.lua`,
`bookshelf_bookorbit_source.lua`, `bookshelf_book_repository.lua`); not
yet run inside KOReader.
