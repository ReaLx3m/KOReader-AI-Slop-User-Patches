# BookOrbit: duplicate entries in the Authors/Series group-root

## Symptom

After upgrading a BookOrbit server (observed going from v2.3 to v2.8.1),
some authors started appearing twice as tiles under a chip pointed at
BookOrbit's "All authors" root (`bookshelf_bookorbit_source.lua`'s
grouped-browsing feature -- see `BOOKORBIT_GROUPED_AUTHORS_SERIES.md`).
The same class of bug could in principle also hit "All series" and the
other group-root sections (`libraries`, `collections`, `smart-scopes`),
though authors is the one most likely to actually walk enough
`catalogSection()` pages to trigger it.

## Root cause

`fetchSectionBucket(section, needed)` is the function that walks
`catalogSection()` pages and appends them into a shared, cached
`entries` list, called synchronously every time a render touches the
group-root (`listGroups` -> every "All Authors" grid render). Its walk
can yield control back to KOReader's UI loop mid-flight -- either a
plain blocking network call, or (more commonly) a `Trapper
:dismissableRunInSubprocess` fork that shows a cancellable spinner while
waiting on the server.

`continueSectionWalk`, the *background* continuation of the same walk,
has always guarded itself against overlapping with its own previous run
via a `_group_walking[section]` flag. `fetchSectionBucket` -- the walk a
render actually blocks on -- never had the equivalent guard.

So: if a second render fired while the first call's walk was still in
flight (a page turn, a cover-fill repaint, a scroll -- all routine in a
grid view), it would call `fetchSectionBucket` again for the same
section. Since `Cache.get(key)` returns a direct reference to the same
bucket table (not a copy), and the first call's walk hadn't merged its
result yet, the second call would see the *same* `bucket.next_page`,
independently re-fetch the same server page(s), and append its own copy
of those entries into the same shared `bucket.entries` table -- exact
duplicate tiles once both calls' merges landed.

This race was always latent but timing-dependent: it only bites when
the walk stays in flight long enough for a second render to realistically
land mid-walk. A smaller/faster catalog (older server, fewer pages) can
complete the whole walk inside one tick, closing the window before any
re-render sneaks in. A larger library or a slower/more-paginated
`catalogSection("authors")` response (as observed after the v2.3 ->
v2.8.1 server upgrade) widens that window enough for it to show up in
normal use.

## Fix

Two changes in `lib/bookshelf_bookorbit_source.lua`:

1. **`_bucket_fetching[section]`** -- a new reentrancy guard around
   `fetchSectionBucket`'s own walk, mirroring `_group_walking`. A second
   call for a section whose walk is already in flight skips starting its
   own overlapping walk and just returns whatever the bucket currently
   holds (the same "serve what we've got" behavior this function already
   falls back to when offline or when a Trapper fetch is cancelled). This
   closes the race directly.

2. **`appendUniqueEntries(bucket, new_entries)`** -- a shared helper, now
   used by both `fetchSectionBucket`'s merge and `continueSectionWalk`'s
   background merge, that skips appending any entry whose id has already
   been added to the bucket (tracked in `bucket._seen_ids`). This is a
   defense-in-depth measure: it doesn't replace the guard above, but
   means a duplicate can never reach the rendered grid even if some other
   path ever lets two walks race against the same bucket again.

`invalidateGroupCache` deliberately does **not** clear
`_bucket_fetching` the way it clears `_group_walking` -- see the comment
at that call site. A walk genuinely still in flight when a refresh lands
self-clears the flag the moment its own result comes back (merged or
discarded on an epoch mismatch); clearing it early would let a brand-new
call start a second overlapping walk while the stale one is still
pending, which is the exact race being fixed.

## Testing

`luac5.1 -p` syntax check passed on the touched file
(`bookshelf_bookorbit_source.lua`) and on every other `.lua` file in the
plugin except a pre-existing, unrelated `goto`-keyword incompatibility
in `bookshelf_updater.lua` (LuaJIT, which KOReader actually runs on,
supports `goto`; `luac5.1` alone does not). Not yet run inside KOReader
against a live BookOrbit server.
