# Bookshelf.koplugin: BookOrbit-fork upgrade — Handoff

## Situation

- **Your fork** (`modded_plugin/bookshelf.koplugin`, from the first upload) is
  based on vanilla **v3.10.8** of `AndyHazz/bookshelf.koplugin`, plus a native
  BookOrbit integration (auth, progress sync, catalog browsing/download) and
  several follow-up fixes, documented in the repo root as
  `BOOKORBIT_*.md` files.
- **Upstream** has moved on to **v4.7.0** (second upload). That's many
  releases of upstream feature work and fixes that your fork does not have.
- Goal: bring the fork up to v4.7.0 **without losing or breaking the
  BookOrbit integration**.

## Key discovery: a true 3-way merge is possible

Pristine vanilla v3.10.8 was downloaded directly from GitHub
(`https://github.com/AndyHazz/bookshelf.koplugin/archive/refs/tags/v3.10.8.zip`)
and confirmed byte-for-byte identical to the base the fork started from
(only the files the BookOrbit work touches differ from it). That means
instead of manually reconciling two huge diffs, we do a real `git merge`:

- `base` branch = vanilla v3.10.8 (downloaded, pristine)
- `modded` branch = your fork (base + BookOrbit)
- `upstream_new` branch = vanilla v4.7.0 (second upload)
- `git merge upstream_new` while on `modded`

This lets Git auto-resolve everything upstream changed that your BookOrbit
work never touched (the vast majority of the diff), and only surfaces real
conflicts where **both sides changed the same lines**.

### Test-merge result (reproduced and re-confirmed this session, not committed)

- **45 files** added cleanly (new upstream modules/locales — free feature
  pickup, e.g. OPDS catalog support, Kindle source, new list-view engine,
  changelog viewer, etc.)
- **61 files** modified and auto-merged cleanly
- **15 files** have real conflicts that need human/careful judgement:

| File | Conflict hunks | Size (lines) | Why it conflicts |
|---|---|---|---|
| `lib/bookshelf_widget.lua` | 24 | ~21,700 | Core screen widget — heavily changed both upstream and by BookOrbit hero/cover fixes |
| `locale/bookshelf.pot` | 64 (add/add) | ~9,200 | Translation template — mechanical, regenerated from source strings |
| `lib/bookshelf_settings.lua` | 3 | ~6,600 | BookOrbit menu (Connect/Browse/Sync/Disconnect) wiring |
| `lib/bookshelf_book_repository.lua` | 4 | ~7,300 | Author letter-jump slowness fix, hero fix touch this |
| `main.lua` | 3 | ~2,900 | Push-on-close / pull-notice-on-open BookOrbit hooks |
| `lib/bookshelf_chip_editor.lua` | 2 | ~2,800 | — |
| `lib/bookshelf_hero_card.lua` | 1 | ~1,700 | Hero community-rating feature |
| `lib/bookshelf_tokens.lua` | 1 | ~1,450 | — |
| `lib/bookshelf_shelf_row.lua` | 1 | ~860 | — |
| `lib/bookshelf_folder_stack.lua` | 3 | ~520 | Grouped authors/series fix |
| `lib/bookshelf_scaled_cover_cache.lua` | 3 | ~520 | Distorted-covers-on-revisit fix |
| `lib/bookshelf_image_source.lua` | 2 | ~510 | — |
| `lib/bookshelf_kobo_source.lua` | 1 | ~290 | — |
| `lib/bookshelf_footer_geom.lua` | 2 | ~300 | — |
| `lib/bookshelf_micro_fullscreen.lua` | 1 | ~570 | — |

All **BookOrbit-only files** (`bookshelf_bookorbit.lua`,
`bookshelf_bookorbit_cache.lua`, `bookshelf_bookorbit_catalog.lua`,
`bookshelf_bookorbit_source.lua`, `bookshelf_bookorbit_sync_coordinator.lua`,
`bookshelf_bookorbit_sync_job_runner.lua`, `bookshelf_group_cover_cache.lua`,
and the `BOOKORBIT_*.md` docs / the community-ratings server patch) carried
over into the merge with **zero conflicts** — upstream never touched them.

### Reference material for conflict resolution

The `BOOKORBIT_*.md` files in your fork document *why* each BookOrbit-side
change to a shared file was made, which is exactly what's needed to resolve
conflicts correctly instead of guessing:

- `BOOKORBIT_INTEGRATION.md` → `main.lua`, `bookshelf_settings.lua`
- `BOOKORBIT_HERO_FIX.md` → `bookshelf_book_repository.lua`,
  `bookshelf_bookorbit_source.lua`, `bookshelf_widget.lua`
- `BOOKORBIT_AUTHOR_LETTERJUMP_SLOWNESS_FIX.md` → `bookshelf_book_repository.lua`
- `BOOKORBIT_DISTORTED_COVERS_ON_REVISIT_FIX.md` → `bookshelf_spine_widget.lua`
  (auto-merged clean), `bookshelf_bookorbit_source.lua`
- `BOOKORBIT_DUPLICATE_AUTHORS_FIX.md` → `bookshelf_bookorbit_source.lua`
- `BOOKORBIT_GROUPED_AUTHORS_SERIES.md` → `bookshelf_folder_card.lua`
  (auto-merged clean)
- `BOOKORBIT_HERO_COMMUNITY_RATING.md` → hero card display
- `BOOKORBIT_COVERS_STILL_MISSING_FIX.md` → general cover pipeline

No pristine baseline exists for a "3-way diff" against these docs, so the
plan is: read the relevant doc(s) before resolving each conflicted file, to
understand intent rather than pattern-match the diff.

## Ground rules for the merge work

1. **Never delete or weaken a BookOrbit-side change** without flagging it to
   you first — if upstream's new code and BookOrbit's code do genuinely
   incompatible things in the same spot, that gets called out for a decision,
   not silently resolved either way.
2. **Prefer taking upstream's version wholesale** for logic BookOrbit didn't
   touch, even inside a conflicted file — conflicts are hunk-level, not
   whole-file, so most of a "conflicted" file is still a clean auto-merge.
3. After each file is resolved: `luac -p` syntax-check it (no live KOReader
   available in this sandbox, so this plus manual review is the validation
   we have).
4. Keep a running log of every conflict and how it was resolved (this
   handoff document *is* that log — it gets updated after every sub-batch).
5. **No sub-batch is started without your explicit go-ahead.** After each
   sub-batch: this handoff doc is updated (checkbox ticked, decisions
   logged) and a fresh zip of the in-progress plugin tree is produced for
   download, before asking permission to continue.

## Batch plan (each original batch split into two smaller sub-batches)

- [x] **Batch 0 — Recon (done).** Downloaded pristine v3.10.8, built the
      3-branch git repo, ran the test-merge, produced the conflict inventory
      above, and reconfirmed it in this session. Nothing committed yet.

- [x] **Batch 1a — Small isolated conflicts, part 1 (4 files). DONE.**
      `bookshelf_footer_geom.lua`, `bookshelf_kobo_source.lua`,
      `bookshelf_micro_fullscreen.lua`, `bookshelf_image_source.lua`.
      All 4 resolved, staged, and `luac -p` clean. See Decisions log.
- [x] **Batch 1b — Small isolated conflicts, part 2 (3 files). DONE.**
      `bookshelf_scaled_cover_cache.lua`, `bookshelf_shelf_row.lua`,
      `bookshelf_folder_stack.lua`. All 3 resolved, staged, and `luac -p`
      clean. See Decisions log — this batch had the first genuine
      "both real features, must be combined" conflicts of the merge.

- [x] **Batch 2a — Medium files, part 1 (2 files, 1 hunk each). DONE.**
      `bookshelf_tokens.lua`, `bookshelf_hero_card.lua`. Both resolved,
      `luac -p` clean. See Decisions log.
- [x] **Batch 2b — Medium files, part 2 (1 file, 2 hunks, largest of the
      three). DONE.** `bookshelf_chip_editor.lua`. Resolved, `luac -p`
      clean. See Decisions log.

- [x] **Batch 3a — Core integration points, part 1 (2 files, 6 hunks,
      ~9,500 lines). DONE.** `main.lua`, `bookshelf_settings.lua`. Both
      resolved, `luac -p` clean. See Decisions log — this batch included
      one genuine conflict-of-intent that required your explicit call.
- [x] **Batch 3b — Core integration points, part 2 (1 file, 4 hunks,
      ~7,300 lines). DONE.** `bookshelf_book_repository.lua`. Resolved,
      `luac -p` clean. See Decisions log.

- [x] **Batch 4a — The big one, part 1. DONE.** `bookshelf_widget.lua`,
      hunks 1-12 of its 24 conflict hunks (through the pre-conflict line
      ~4130 in the original test-merge numbering). See Decisions log —
      this batch touched the BOOKORBIT_HERO_FIX.md fix directly (fixed
      `_hydrateBook` itself, which upstream's own refactor had
      regressed back to the pre-fix `Repo.buildBook` call) and extended
      the Batch 1a footer-height-scale fix pattern to a new upstream
      helper function.
- [x] **Batch 4b-i — The big one, part 2a (split into two sub-batches at
      your request).** `bookshelf_widget.lua`, 7 of the remaining 12 conflict
      hunks. DONE. See Decisions log — this sub-batch uncovered and fixed a
      genuine merge-tool artifact (a duplicated function body hiding as
      unconflicted text) in addition to the marked conflicts.
- [x] **Batch 4b-ii — The big one, part 2b. DONE.** `bookshelf_widget.lua`,
      remaining 5 conflict hunks (24/24 total now resolved), plus the
      full-file review. See Decisions log — this batch also found and fixed
      4 more instances of the `_statusStripHeight` hero-fix regression
      hiding OUTSIDE any conflict marker (auto-merged upstream code that was
      never flagged in the original 15-file conflict inventory).

- [x] **Batch 5a-i — Locale, part 1a: investigate + verify (done).** At your
      request, Batch 5a was split into two smaller sub-batches. This half
      found the exact `xgettext` recipe that reproduces upstream's `.pot`
      byte-for-byte, regenerated a fresh `.pot` from the merged source tree
      with it, and verified no BookOrbit string is lost. See Decisions log.
- [x] **Batch 5a-ii — Locale, part 1b: apply (done).** Wrote the verified
      regenerated `.pot` into `locale/bookshelf.pot`, replacing the
      64-conflict-pair version. Repo-wide sweep confirms zero remaining
      `<<<<<<<`/`=======`/`>>>>>>>` markers anywhere in the tree, and
      `msgfmt --check` passes on the new file. See Decisions log.
- [x] **Batch 5b-i — Locale, part 2a. DONE.** Spot-checked the first 7 of
      the 14 `.po` files that auto-merged clean (`bg_BG`, `de`, `en_GB`,
      `es`, `fr`, `hu`, `it`) — no BookOrbit strings lost/duplicated, no
      real staleness issues. See Decisions log.
- [x] **Batch 5b-ii — Locale, part 2b. DONE.** Spot-checked the remaining
      7 `.po` files (`ja`, `pt_BR`, `pt_PT`, `uk`, `vi`, `zh_CN`, `zh_TW`),
      same checks. All pass; found a wider spread of pre-existing
      staleness across these 7 than the first 7, traced to upstream's own
      shipped v4.7.0 release (not something this merge introduced). See
      Decisions log.

- [x] **Batch 6a — New upstream modules sanity pass, part 1. DONE.** First
      22 (alphabetical) of the 43 cleanly-added upstream files — confirmed
      no extra wiring needed and no collision with BookOrbit
      naming/behaviour.
- [x] **Batch 6b — New upstream modules sanity pass, part 2. DONE.**
      Remaining 21 files (17 `lib/*.lua` + 2 `tools/` scripts + 2 new
      `locale/*.po` files). Same checks, all clean. See Decisions log.

- [ ] **Batch 7a — Final pass, part 1.** Bump `_meta.lua` version, full
      `luac -p` sweep of every changed file, re-read all `BOOKORBIT_*.md`
      docs against the merged code to confirm each documented fix still
      holds.
- [ ] **Batch 7b — Final pass, part 2.** Package the final zip, present it,
      final confirmation.

Each sub-batch ends with: a commit in the working git repo, an updated
version of this handoff doc (checkbox ticked, notes on any judgement calls
made added under "Decisions log" below), a fresh zip of the current plugin
tree served for download, and a stop for your go-ahead before continuing.

## Decisions log

### Batch 1a (done)

- **`bookshelf_footer_geom.lua`** — two conflicts (`barMetrics`,
  `gridMetrics`), same shape both times: the fork added `M.artSize()` (a
  user-adjustable `footer_height_scale` setting, unrelated to BookOrbit but
  a fork feature that must not be lost), upstream independently added an
  optional `scale_pct` parameter (issue #279) for the reader launcher, but
  built it on the old fixed `Screen:scaleBySize(32)` literal instead of
  `artSize()`. **Not a real conflict of intent** — combined both: `scale_pct`
  now scales relative to `M.artSize()` instead of the fixed literal, so the
  reader-launcher shrink/grow feature and the height-scale setting both
  work, and stack correctly together.
- **`bookshelf_kobo_source.lua`** — comment-only conflict. The fork's
  comment documents the `type(bb) == "table"` cover-decode bug (see
  `BOOKORBIT_COVERS_STILL_MISSING_FIX.md`, "Fix round 3") that was
  originally found and fixed in `bookshelf_bookorbit_source.lua`, then
  applied here too since the code was "almost certainly copy-pasted" from
  there. The actual fix code (`if ok_bb and bb then`) was byte-identical on
  both sides of the conflict; upstream's side just had no comment. Kept the
  fork's explanatory comment, no code change.
- **`bookshelf_image_source.lua`** — same shape, twice (`_evictIfNeeded`,
  `invalidateCache`): comment-only conflicts documenting the "drop
  reference, never `bb:free()`" lifetime contract (a real crash fix — a
  live widget with `cover_bb_disposable=false` could still be holding the
  bb, and freeing it caused a use-after-free SIGSEGV). Code identical both
  sides; kept the fork's comments.
- **`bookshelf_micro_fullscreen.lua`** — one conflict, same shape as
  footer_geom's: fork's `_closeGlyph` used `footer_geom.artSize()` (height
  setting), upstream's added an `exact` box parameter (reader-launcher
  pixel-exact close-X) but reverted to the fixed `Screen:scaleBySize(32)`
  literal. Combined: kept the `exact`-box logic from upstream, but its
  fallback `art` value now comes from `FooterGeom.artSize()` so it still
  honours the height-scale setting. Double-checked the rest of the function
  (the `box`/`frame`/`OffsetContainer` code after the conflict) already
  matched upstream's `box`-based structure, so no further changes needed
  there.

All 4 files: `luac -p` clean. Staged in the merge repo
(`git add`), not yet committed — merge commit waits until all 15 (+ the
`.pot`) conflicts are resolved, per the ground rules.

### Batch 1b (done)

This batch's three files carried the merge's first *real* conflicts —
cases where both sides added a genuine, independent feature to the same
function and neither could simply be dropped. All three needed actual
combining rather than "pick a side."

- **`bookshelf_scaled_cover_cache.lua`** (3 conflicts) — the fork added a
  size-tiered cache key (`(filepath, size_class)` instead of plain
  `filepath`) to stop a hero-sized `put()` from clobbering a live
  shelf-sized entry (a real SIGSEGV, see the file's own top-of-file
  comment, issue #103). Upstream, independently, added a disk-backed
  cache layer (`_hydrate`/`bookshelf_cover_disk_cache`) so covers survive
  across launches. Neither is a BookOrbit-doc'd fix, but both are real
  features that must coexist. Combined by making the disk layer
  tier-aware: `_hydrate()` no longer checks a single `self._cache[filepath]`
  key (that key format doesn't exist anymore) — it just loads the
  persisted bb and lets `put()` (already correctly tier-aware from an
  earlier clean auto-merge) classify it into its own tier. `get()` and
  `has()` now scan tiers first and fall back to one `_hydrate()` +
  re-scan on a full miss. `drop()` combines both: disk-drop unconditionally
  first (matching upstream's ordering rationale), then a tier-wide
  memory drop (matching the fork's rationale) instead of upstream's
  single-key memory drop.
- **`bookshelf_shelf_row.lua`** (1 conflict, add/add) — the fork added a
  new `bookorbit_group` tile branch; upstream added a new `opds_nav`
  branch, both inserted at the same point (right after the `folder`
  branch). Confirmed via the vanilla v3.10.8 base that upstream also
  changed the `folder` branch's own closing to use a new
  `StackDisplay.externalLabel(...)` call — a real, file-wide upstream
  feature (every other group-tile branch — author, series — already uses
  it) that the fork's `folder` branch hadn't picked up yet purely because
  BookOrbit's edit landed on the same lines first. Resolved by giving
  `folder` the upstream label call (for consistency with every sibling
  branch) and keeping both new branches back-to-back, BookOrbit's first.
- **`bookshelf_folder_stack.lua`** (3 conflicts, the most involved of the
  batch) — same shape throughout: the fork added `show_label` (BookOrbit's
  per-section "show folder label on nested sources" setting, scoped to
  `kind == "bookorbit_group"`) while upstream added real bare-mode /
  stack-mode / ribbon-mode rendering support (`art_w`/`art_h` sizing
  instead of `self.width`/`self.height`, `shadow_reserve`, a pile widget
  for `STACK` mode, a `RIBBON` band, and `cover_align_top` gated on
  `show_cardboard` instead of being unconditional). Confirmed via the
  vanilla v3.10.8 base that `self.width`/unconditional `cover_align_top`
  was the OLD behavior upstream replaced — so upstream's structural
  changes are the ones to keep, with the fork's `show_label` toggle
  layered on top. Net result: the cardboard tab + label now render when
  `show_cardboard and show_label` (both conditions), everywhere else
  behaves exactly as upstream intended (pile/ribbon/bare modes all work),
  and the BookOrbit label toggle still removes the whole cardboard
  silhouette for `bookorbit_group` tiles when unchecked, per the
  original fork intent. One self-inflicted syntax slip during editing
  (a duplicated `book_widget = SpineWidget:new{` line) was caught by
  `luac -p` and fixed immediately.

All 3 files: `luac -p` clean.

### Batch 2a (done)

- **`bookshelf_tokens.lua`** (1 conflict) — upstream's "#348 sweep" (its own
  comment, still present just above the conflict) replaced the old raw
  `%warmth`/`%mem`/`%ram`/`%disk` expanders with scale-correct versions
  routed through a new `Semantics` module (native device warmth scale
  instead of a hardcoded 0-100 percentage, etc.) — confirmed against the
  token catalog table earlier in the file (lines 136-145), which already
  documents the new semantics (`"Warmth on the device's own scale, 0-24 on
  Kindle"`, `"System memory used (%)"` for `%mem` vs `"KOReader RSS (MiB)"`
  for `%ram`, etc.) and was itself an upstream-only clean auto-merge, so it
  was already expecting these definitions. The fork's HEAD side of the
  conflict was the *old*, pre-#348 versions of those same four expanders
  (byte-identical to vanilla v3.10.8 — BookOrbit never touched them) plus
  one genuinely new fork expander, `%free_ram` (device-wide free RAM via
  `util.calcFreeMem()`, distinct from `%ram`'s KOReader-process RSS —
  confirmed still wired up and computed in `bookshelf_widget.lua`'s
  `_readSlowState`/`_device_slow_cache`, and still listed in the token
  catalog). Resolved by taking upstream's four semantic expanders as-is
  and keeping only the fork's new `%free_ram` addition — none of the old
  duplicate definitions were kept, since they'd have silently
  re-overwritten upstream's scale fix.
- **`bookshelf_hero_card.lua`** (1 conflict, add/add on the `require`
  block) — the fork's side pulled in `ui/rendertext` (`RenderText`) and
  the i18n `_()` gettext helper; upstream's side pulled in a new
  `lib/bookshelf_text_fit` module (`TextFit`). Checked actual usage in the
  file body: `TextFit.balanceLines` is used (hero placeholder-card text
  balancing) and `_("Want to Read")` is used (a real, translated string),
  but `RenderText` has no call site anywhere else in the file — dead
  import, most likely left over from an earlier version of a fork edit
  that was later reworked. Resolved by keeping `_` and `TextFit` (both
  live) and dropping the unused `RenderText` require rather than carrying
  dead code forward.

Both files: `luac -p` clean. Not committed — merge commit still waits for
all 15 (+ `.pot`) per the ground rules.

### Batch 2b (done)

- **`bookshelf_chip_editor.lua`** (2 conflicts, both add/add, same shape as
  `bookshelf_shelf_row.lua` in Batch 1b) — the fork added a `bookorbit`
  entry/row (chip-source picker), upstream independently added `opds` and
  `kindle` entries/rows for its new catalogue-browsing features, all
  landing at the same insertion point.
  - First conflict (`SOURCE_LABEL` table): combined all three label
    entries — `bookorbit`, `opds`, `kindle` — kept back-to-back,
    BookOrbit's first (consistent with the Batch 1b ordering convention).
  - Second conflict (the chip-source picker's button-row list): same
    pattern — combined the BookOrbit section row and the OPDS catalog row
    as two separate rows, BookOrbit first, OPDS second. Confirmed both
    `open_bookorbit_picker` and `open_opds_picker` are real functions
    already defined earlier in the file (not stubs), and that the
    Kindle row referenced in a comment just below this hunk is unrelated
    — it's built separately via a gated `table.insert` after this list is
    constructed, untouched by either side of the conflict, so it needed no
    changes here.

`luac -p` clean.

### Batch 3a (done)

**`main.lua`** (3 conflicts):

- **Menu ordering (Updates vs. Selection mode) — genuine conflict of
  intent, flagged to you rather than guessed.** The fork had explicitly
  disabled the "Updates" menu item (commented out, with a note that it was
  "kept for future reference") and put a new "Selection mode" toggle in
  that slot instead. Upstream v4.7 independently re-worked the same
  "Updates" item to light up with an "Update available: vX.X.X" badge.
  These aren't a hunk-level accident — they're two different decisions
  about the same feature — so per the ground rules this got called out
  instead of picked silently. **Your call: keep Updates disabled**,
  matching the fork's existing note. Kept "Selection mode" (unaffected
  either way, a distinct fork feature) and kept the disabled-Updates
  block, now with an added comment recording that the 4.7-merge
  re-confirmed the decision and noting *why* re-enabling isn't just a
  flip of the switch (the fork would be checking for updates against
  upstream's release feed, which doesn't apply to it) so a future reader
  doesn't have to re-litigate this.
- **Dispatcher actions + go-home feature** — clean add/add: the fork
  added a `bookshelf_bookorbit_sync_now` gesture action, upstream added a
  new `bookshelf_go_home` gesture action plus its own handler function
  (`Bookshelf:onBookshelfGoHome`, issue #223). Neither touches the other;
  combined both registrations in the dispatcher block and kept upstream's
  new handler function in full.
- **`onNetworkConnected`** — clean add/add: the fork's BookOrbit
  offline-chip-refresh + pending-sync-retry logic, upstream's
  `_refreshReaderStatus(wifi)` call. Kept both, upstream's call first
  (matches the existing pattern in the neighbouring
  `onNetworkDisconnected` handler) then the BookOrbit logic.

**`bookshelf_settings.lua`** (3 conflicts):

- **Start-menu-position / footer-height-scale settings block** — not a
  real conflict: this whole block is fork-only content (no BookOrbit
  connection, just general fork features) that upstream never touched;
  its side of the diff was only a one-line comment ("Hardcover enrichment
  lives at the top level"). Kept the fork's block in full, appended
  upstream's comment after it (harmless, still accurate).
- **`_bookorbitSubItems` region (~900 lines, the largest single conflict
  of the merge so far)** — this conflict bundled two unrelated things
  together purely because they sit adjacent in the file: (1) the fork's
  entire BookOrbit settings sub-menu function (`_bookorbitSubItems`) plus
  two small helper functions (`_pickBookOrbitCacheBudget`,
  `_pickBookOrbitThumbnailCacheLimit`), inserted right after
  `_hardcoverSubItems`; and (2) immediately following that, the *old*
  `_expandedShelfSubItems` function from vanilla v3.10.8, which upstream
  dissolved in its own 4.0 release (its settings moved to "Cover display"
  and "Behavior" — confirmed both destinations already exist earlier in
  this same file, e.g. the "Show text below covers" row and the
  Behavior-menu "Tap a book" row). Resolved by keeping all of the
  BookOrbit content untouched, and only replacing the old, now-dead
  `_expandedShelfSubItems` function with upstream's short explanatory
  comment about the 4.0 dissolution — `_pickExpandedShelfFontScale`
  (a separate function right after this conflict, still referenced
  elsewhere for the surviving "Cover labels" row) was outside the
  conflict and untouched.
- **Chip-bar settings row (add/add)** — same shape as the very first
  conflict of this file: the fork added a "Chip bar height" scale row,
  upstream added an "Uppercase labels" toggle, both at the same list
  position. Kept both as separate rows, fork's first.

Both files: `luac -p` clean. Not committed — merge commit still waits for
`bookshelf_book_repository.lua`, `bookshelf_widget.lua`, and `.pot`.

### Batch 3b (done)

Read `BOOKORBIT_HERO_FIX.md` and `BOOKORBIT_AUTHOR_LETTERJUMP_SLOWNESS_FIX.md`
before touching this file, per the ground rules — both directly explain two
of the four conflicts below.

- **`Repo.buildBookMeta` / `Repo.getCoverBB` early-return guards** (2
  separate conflicts, identical shape) — the fork's `bookorbit://` guard
  and upstream's `OPDS://` guard are the same defensive pattern for two
  different pseudo-path schemes, added independently. No overlap in
  behaviour; kept both guards back-to-back in each function.
- **Series grouping / multi-series bucketing (`getSeriesGroups`)** — a real
  feature collision, both sides touching the same loop for different
  reasons. The fork's helper, `_bucketBookIntoSeries`, already handled
  secondary/multi-series membership (via `extra_series`) with the correct
  *per-membership* series number — so it wasn't actually the bug upstream's
  rewrite (issue #299) was fixing. What upstream's rewrite *did* add on
  top, though, was attaching `author`/`author_sort` to each group's book
  entry so a series stack can be sorted by its members' author (issue
  #351) — the fork's helper didn't carry those fields. Kept the fork's
  `_bucketBookIntoSeries`-based structure (simpler, already shared between
  the primary and secondary buckets) and added the two missing fields to
  the helper's book-entry table, so both fixes are present without
  duplicating the bucketing logic inline the way upstream's rewrite did.
- **`Repo.getBySource`'s per-`kind` branch dispatch (the largest
  conflict of this file, ~285 lines)** — not a real conflict of intent,
  just three separate `if kind == "..."` branches (fork's `"bookorbit"`,
  upstream's `"kindle"` and `"opds"`) landing at the same insertion point,
  each fully self-contained and gated on its own `kind` value so they
  never execute for each other's chips. The awkward part: git's diff
  matched the *trailing* `end` / `return page, total` / `end` that closes
  upstream's `"opds"` branch against the *literal* text the fork's
  `"bookorbit"` branch also needed for its own close (both branches end
  with the exact same three lines), and filed that shared text as common
  context instead of duplicating it — which meant the merged text as-is
  would have left the `"bookorbit"` branch syntactically unclosed and
  running straight into `"kindle"`'s code. Fixed by writing the
  `"bookorbit"` branch's own closing triplet explicitly, then keeping
  `"kindle"` and `"opds"` in full afterward (upstream's `"kindle"` branch
  was already self-closed within its own share of the diff, unaffected).
  This is also where the letter-jump slowness fix's `opts` forwarding
  lives (`BOSource.listGroups(section, off, lim, opts)`, per
  `BOOKORBIT_AUTHOR_LETTERJUMP_SLOWNESS_FIX.md`) — confirmed intact and
  that `Repo.getBySource`'s own signature already carries the `opts`
  parameter it forwards.

`luac -p` clean.

### Batch 4a (done) — `bookshelf_widget.lua`, hunks 1-12 of 24

Read `BOOKORBIT_HERO_FIX.md` again before starting, since this file is one
of the three it names. Resolved in file order:

1. **`_serializeDrillPath`** (add/add) — fork's `bookorbit_group` persistence
   branch, upstream's new `opds_nav` branch (feed identity, restore-checks-
   cache-first design). Independent kinds; kept both, BookOrbit's first.
2. **`_restoreDrillPath`** (add/add, same shape) — same two branches on the
   restore side; confirmed the loop context (`for _i, e in ipairs(saved) do`)
   makes upstream's `break` valid before combining. Both kept, each closing
   its own `}` (git had filed the two entries' closing brace as shared
   context, same trap as Batch 3b's `Repo.getBySource`).
3. **`FOOTER_STROKE_W` / `_strip_h_memo`** — not a real conflict: fork set an
   instance-level footer stroke width, upstream added a status-strip memo
   reset. Unrelated statements at the same point; kept both.
4. **Chip strip height (`chip_h`)** — real conflict: upstream's `#348`-style
   sweep replaced the old inline calc with a new shared `BandMetrics` module
   (`BandMetrics.cellHeight(BandMetrics.CHIP_KEY)`), which does not know
   about the fork's `chip_height_scale` ("Chip bar height") setting since no
   other BandMetrics caller has an equivalent second scale. Kept
   `BandMetrics.cellHeight` as the base and layered `chip_height_scale` on
   top as an independent multiplier at this call site, reproducing the old
   combined formula's behaviour without duplicating BandMetrics' own
   derivation.
5. **Footer reserve height (`FOOTER_H`)** — fork's inline calc (via
   `footer_geom.artSize()`, respecting "Footer height") vs. upstream's new
   shared `_footerReserveH()` helper (used by row-count math elsewhere in
   the file, per its own header comment: "any code deciding how many rows
   fit has to subtract the SAME number"). Adopting `_footerReserveH()`
   wholesale would have silently stopped the footer's reserved space from
   tracking the "Footer height" setting, even though every actual footer
   button still does (chev, close-X, hamburger, grid glyph, all via
   `artSize()`) — the same bug shape Batch 1a already found and fixed twice
   in `bookshelf_footer_geom.lua` and `bookshelf_micro_fullscreen.lua`.
   Fixed `_footerReserveH()` itself (not itself inside a conflict hunk, but
   directly downstream of one) to route through `footer_geom.artSize()`
   instead of a bare `Screen:scaleBySize(32)` literal, then took upstream's
   simplified call `local FOOTER_H = _footerReserveH()`. Kept
   `FOOTER_BOTTOM_MARGIN = self:_bottomPad(PAD)` (a real fork setting,
   `hero_bottom_pad`, whose own docstring confirms it defaults to 0 —
   identical to upstream's hardcoded 0 — so nothing regresses for users who
   haven't touched it).
6. **Hero strip-height probe** — fork's inline probe vs. upstream's new
   `_statusStripHeight()` (shared with `_maxRows` so both agree on the same
   number, memoised per rebuild). Took upstream's call. **Flagged for Batch
   4b:** `_statusStripHeight`'s own body (further down, inside a hunk 13+
   conflict not yet reached) still calls the pre-fix `Repo.buildBook(...)`
   rather than `Repo.buildPreviewBook(...)` — needs the same fix as item 12
   below when that hunk is resolved, or the hero-collapsed status strip will
   silently regress the HERO_FIX for BookOrbit books.
7. **BIM-extraction-queue guard** — fork's `bookorbit://` skip-guard
   (crash-prevention, BIM can't lstat a synthetic path) vs. upstream's new
   `_isRemoteRecord()` skip-guard (OPDS `://` prefix only — confirmed via
   `_isRemoteRecord`'s own definition it does not cover BookOrbit).
   Independent guards for independent pseudo-path schemes; kept both,
   BookOrbit's first.
8. **Device-state comment block** — describes what the 60s-TTL slow cache
   holds. Fork's old comment (pre-`#348`: `mem`, `ram_mib`, `free_ram_mib`,
   `disk_free`) vs. upstream's new one (raw `mem_total`/`mem_available`/
   `ram_kb`/`disk_bytes`/`sysused_bytes`, formatted downstream by
   `token_semantics`). The actual `_readSlowState` body already computes
   upstream's raw fields AND the fork's own `free_ram_mib` cleanly outside
   any conflict, so this was comment-only: combined into one comment
   documenting all of it.
9. **`_device_slow_cache` declaration comment** — same shape as #8, one line;
   merged the two comments.
10. **`_device_state_cache` table construction** — the real payload of #8/#9.
    Fork's HEAD side still had the OLD, pre-`#348` fields (`mem`, `ram_mib`,
    `disk_free`, plus `light_pct` and `warmth` as bare locals) alongside
    upstream's new raw fields. Checked `_buildDeviceState`'s local
    declarations (`local light, warmth_pct, warmth_native`): `light_pct` and
    `warmth` are **not computed anywhere any more** — upstream's sweep
    replaced them with `fl_max` (`Semantics.lightPct` does the percentage
    arithmetic from raw values) and `warmth_pct`/`warmth_native`. Dropped
    those two dead references rather than assigning stray `nil`s. Kept only
    `free_ram_mib = slow.free_ram_mib` from the fork's side (the one field
    with no upstream equivalent, confirmed still wired to the `%free_ram`
    token per Batch 2a) alongside all of upstream's raw fields in full.
11. **`_openBook`'s per-record dispatch** (the largest of this half, ~180
    lines) — same "three independent elseif branches landing at the same
    insertion point" shape as Batch 3b's `Repo.getBySource`: fork's
    `is_bookorbit` branch (network download via `BOSource.resolveOpenPath`,
    async callback), upstream's new `is_kindle` branch (issue #355,
    conversion-confirmation dialog + `KindleSource.realPathForOpen`). Each
    fully self-contained and gated on its own flag. Same closing-line trap
    as before: the trailing `return` after the conflict was shared context
    for upstream's `is_kindle` branch only, so the `is_bookorbit` branch
    (now landing before it instead of last) needed its own explicit
    `return` added at its end to stop it falling through into
    `is_kindle`'s code. Kept BookOrbit's branch first, Kindle's second.
12. **Hero record hydration in `_buildHero`** — the first of the "5 places"
    `BOOKORBIT_HERO_FIX.md` names explicitly. Fork's direct
    `Repo.buildPreviewBook(fp, book) or book` vs. upstream's new
    `self:_hydrateBook(book)` helper. Checked `_hydrateBook`'s own body:
    it still called the pre-fix `Repo.buildBook(book.filepath) or book`
    internally — upstream's refactor had (unknowingly) reintroduced the
    exact bug the hero fix patched, just one call deeper. Rather than
    bypass `_hydrateBook` at this one call site, fixed `_hydrateBook`
    itself to call `Repo.buildPreviewBook(book.filepath, book) or book`,
    preserving its existing `_isRemoteRecord` (OPDS) passthrough guard and
    restoring the BookOrbit hero fix for every caller at once — including
    the two more `_hydrateBook` call sites still inside unresolved hunks
    (13+), which now inherit the fix instead of needing it reapplied
    individually when reached in Batch 4b.

**Validation note:** no `luac` binary was available in this sandbox (only
the shared library), so a minimal syntax-checker was compiled from scratch
against `liblua5.4.so.0` (`luaL_loadfilex` via hand-written extern
declarations — no `lua.h` was available either) to reproduce the ground
rules' `luac -p` check. Confirmed clean through the resolved region
(parses correctly up to the first still-open conflict marker), and a
throwaway copy with all *remaining* conflicts crudely auto-resolved
(HEAD side picked blindly, never saved) parsed several thousand lines
further with no new errors from this batch's edits — one of the
still-open hunks contains marker-like text that defeated the crude
auto-resolve script, harmless since that copy was diagnostic-only and
discarded.

12 of 24 `bookshelf_widget.lua` conflict hunks resolved; 12 remain for
Batch 4b, plus the full-file review and the `_statusStripHeight` fix
flagged in item 6 above.

### Batch 4b-i (done) — `bookshelf_widget.lua`, 7 more hunks (19/24 total)

At your request, Batch 4b was split into two sub-batches. This is the first,
covering the next 7 conflict hunks in file order.

1. **`_buildShelfRows`'s `row_opts` table** (the callback block) — not a
   real conflict once traced: the fork's inline `on_book_tap` /
   `on_book_open` / group-tap callbacks in this literal are dead weight —
   `_shelfCallbacks()` (defined earlier in the file, itself a clean
   upstream-side extraction, no conflict) already supplies every one of
   them to this same function via the `shared` local, and a
   `SHELF_CALLBACK_KEYS` copy loop immediately after this table literal
   already copies them across. Upstream's side of the conflict was just
   one new field, `group_display`. Resolved by dropping the entire dead
   inline block and keeping only `group_display`.
   **Two regressions found and fixed in `_shelfCallbacks()` itself** (not
   inside this hunk, but required to keep this resolution honest):
   - `on_bookorbit_group_tap` (the "browse by BookOrbit group" tile's tap
     handler) existed only in the fork's now-deleted inline block and was
     never carried into `_shelfCallbacks()` — silently dropping the whole
     feature. Added it there, plus its own `on_bookorbit_group_tap` entry
     in `SHELF_CALLBACK_KEYS` (the copy loop can't forward a key it
     doesn't know about).
   - `_shelfCallbacks()`'s `on_book_tap`, in its `show_detail` branch,
     calls `bw:_hydrateBook(b)` — which, per the Batch 4a hero fix, can
     block on a BookOrbit detail fetch (`Repo.buildPreviewBook` ->
     `BOSource.rebuildRecord`) — with no Trapper coroutine open, so
     `rebuildRecord`'s own blocking-fetch guard (which only shows a
     dismissable spinner when `Trapper:isWrapped()`) would silently fall
     through to a synchronous network call and freeze the UI. The fork's
     original (now-deleted) inline version had this exact branch wrapped
     in `Trapper:wrap(work)`; re-added that wrapping around the branch's
     body inside `_shelfCallbacks()`, matching the same idiom used
     elsewhere in this file (`_previewBook`, see below).
2. **`_jumpToLetterPrefix`** — upstream replaced the fork's inline
   letter-jump list-scan logic with a new shared helper, `_jumpScanList()`
   (its own upstream fix, #307, for a different but related bug: a jump
   inside a drilled folder used to match against the parent's list).
   Checked `_jumpScanList()` against the fork's inline version and found
   the SAME class of gap as above: `_jumpScanList()`'s branches mirror
   `_fetchChipItems` for every drill kind EXCEPT `bookorbit_group` — the
   fork's inline code had a dedicated branch for it (fetching that group's
   own books via `Repo.getBySource({kind="bookorbit", ...})` instead of
   falling through to the chip's top-level list, per
   `BOOKORBIT_AUTHOR_LETTERJUMP_SLOWNESS_FIX.md`'s subject matter), and
   `_jumpScanList()` had no equivalent — a real regression (letter-jump
   inside a drilled BookOrbit author/series group would silently search
   the wrong list again). Added a `bookorbit_group` branch to
   `_jumpScanList()`, mirroring `_fetchChipItems`'s own branch for it, and
   took upstream's one-line call site (`self:_jumpScanList()`).
3. **`_swapShelvesInPlace`** (the largest single item resolved this
   session, ~285 marked lines, though the real issue extended further) —
   fork wrapped the whole function in a Trapper-protected `work()` closure
   plus an `after_fn` parameter (its own re-fetch can hit a BookOrbit
   fetch); upstream rewrote the function's actual logic extensively
   (view-mode-aware fast-path guard, list-mode row building, the #124
   scoped-refresh fix, and the #247 Kaleido colour e-ink wipe-animation
   fix). **A real merge-tool artifact was found here, not just a marked
   conflict**: the conflict block itself only captured the function's
   opening lines against upstream's ENTIRE new body, and diff3 then
   resynced on a coincidental short text match roughly two-thirds through
   the function — which silently carried the OLD, pre-4.7 fork body
   (missing the view-mode guard, list mode, and the #124/#247 fixes)
   forward a SECOND time immediately afterward, as if it were ordinary
   unconflicted trailing content. The result, if left as-is, would have
   run the entire fetch-paginate-swap sequence twice back to back on every
   call, using the stale pre-4.7 logic for whichever branch actually
   completed. Resolved by deleting that whole stale duplicate and rebuilding
   the function as: fork's Trapper-wrap shell (comment, signature,
   `after_fn` parameter) around upstream's real v4.7 body verbatim, with
   `if after_fn then after_fn() end` added at all 4 exit points (the 3
   early-return fallbacks plus the normal completion path), matching the
   fork's own documented contract for this wrapper.
4. **`_previewBook`** (Trapper-wrap shell vs. upstream's added
   `_tap_selected_fp` clear + `_opdsEnsurePreviewCover` call) — not a real
   conflict of intent: kept the fork's `_previewBook` /
   `_previewBookWork` split (the Trapper-wrap needed for the same
   BookOrbit-blocking reason as #3), and added upstream's two new lines at
   the top of `_previewBookWork`'s body, ahead of the existing logic.
5. **Two `Repo.buildPreviewBook(book.filepath, book) or book` /
   `self:_hydrateBook(book)` conflicts**, both inside `_previewBook`'s
   body (one in the micro-hero-mode branch, one in the normal branch) —
   same shape as several Batch 4a items: `_hydrateBook` already correctly
   routes through `Repo.buildPreviewBook` since the Batch 4a fix, so
   upstream's simpler call is equivalent. Took `self:_hydrateBook(book)`
   in both spots.

**Validation:** same constraint as Batch 4a — no `luac` binary in this
sandbox, only `liblua5.4.so.0`. Rebuilt the same minimal syntax-checker
against it (`luaL_loadfilex` via hand-written extern declarations) and
confirmed the file parses cleanly through every line resolved above,
stopping exactly at the next (unresolved) conflict marker as expected.

19 of 24 `bookshelf_widget.lua` conflict hunks resolved; 5 remain for
Batch 4b-ii (`_layoutPrimitives`/chip_h derivation, the `_statusStripHeight`
hero-fix follow-up flagged in Batch 4a item 6, and 3 more not yet inspected
in detail), plus the full-file review once all 24 hunks are in.

### Batch 4b-ii (done) — `bookshelf_widget.lua`, final 5 hunks (24/24 total)

Resolved in file order:

1. **`_layoutPrimitives` doc comment + body** (2 hunks, treated together —
   the comment conflict was immediately followed by the body conflict for
   the same function). Fork's side: `left_pad`/`right_pad` via `_sidePads`,
   `chip_font_scale` * `chip_height_scale` inline arithmetic, footer height
   via `footer_geom.artSize()` + `_bottomPad`, plus the `_topPad`/`_sidePads`/
   `_bottomPad` hero-padding-override methods defined right after it.
   Upstream's side: a simplified body (`PAD*2` symmetric padding, `chip_h`
   from the new shared `BandMetrics.cellHeight`, footer height from a bare
   `Screen:scaleBySize(32)`), followed by a brand-new `_statusStripHeight()`
   helper the fork never had. Both sides are real, independent work — kept
   the fork's `_layoutPrimitives` shell (side pads, footer height respecting
   the "Footer height" setting, all three pad-override methods intact,
   since `_sidePads`/`_bottomPad` are already called from `_rebuild` per
   Batch 4a/earlier work) but switched `chip_h`'s derivation to the
   established Batch-4a pattern (`BandMetrics.cellHeight(BandMetrics.CHIP_KEY)
   * chip_height_scale / 100`, rounded) instead of the old
   `Size.item.height_default`-based formula — `BandMetrics.CHIP_KEY` is
   literally the string `"chip_font_scale"`, so `cellHeight()` already
   folds that scale in; `chip_height_scale` still layers on top as its own
   independent multiplier, matching the identical formula already resolved
   at the top of `_rebuild()`. Then kept upstream's new `_statusStripHeight()`
   function verbatim, WITH one fix: its `probe_book` line still called the
   pre-fix `Repo.buildBook(self._preview_book.filepath)`, exactly the bug
   `BOOKORBIT_HERO_FIX.md` describes and exactly what was flagged in Batch
   4a item 6. Changed it to `self:_hydrateBook(self._preview_book)`, same
   pattern as the `_buildHero` fix in Batch 4a item 12.
   **Merge-tool artifact, same class as Batch 4b-i's `_swapShelvesInPlace`
   duplicate:** the raw conflict text had the fork's `_bottomPad` function
   ending mid-body (missing both its `if`'s `end` and its own function
   `end`) immediately before the `=======` marker, with the real closing
   `end`s living after `>>>>>>>` as if they were shared trailing context —
   they are not; that single `end` only actually closes upstream's
   `_statusStripHeight`. Rebuilt all four functions
   (`_layoutPrimitives`, `_topPad`, `_sidePads`, `_bottomPad`,
   `_statusStripHeight`) with their own explicit, correct `end`s rather
   than trusting the marker placement.
2. **`_nCols()`** (add/add, same shape as several earlier batches) — fork
   added an `expanded_shelf_columns` override (checked before the normal
   `bookshelf_columns` chain, only in `self._expanded`); upstream split the
   function into a mode dispatcher (`_nCols` → `_listCols()` in list mode,
   else the renamed grid path) and moved the old body into a new
   `_gridCols()`. Not a real conflict of intent: kept upstream's dispatcher
   shape (list mode must route through `_listCols()`, an upstream feature
   the fork has no equivalent for) and folded the fork's
   `expanded_shelf_columns` override into the top of the new `_gridCols()`
   — it's a grid-only concept (expanded COVER grid density), so `_gridCols`
   is exactly where it belongs, and it still runs before the
   `bookshelf_columns` fallback exactly as before.
3. **`_setBookRating`** (add/add) — fork's `book.is_bookorbit` branch
   (routes the rating write to `BookOrbit.setCatalogRating`, a real
   server-side write, since a BookOrbit placeholder path has no DocSettings
   sidecar) vs. upstream's new `self:_isRemoteRecord(book)` guard (silently
   declines for OPDS pseudo-paths, which have no equivalent server-side
   rating endpoint to route to). Confirmed via `_isRemoteRecord`'s own
   definition (Batch 4a item 7) that it only matches `OPDS://`, never
   BookOrbit's `bookorbit://` — genuinely independent guards for
   independent pseudo-path schemes. Kept both, BookOrbit's real write
   checked first (an early silent no-op from the OPDS guard would be wrong
   for it), OPDS's no-op guard second, both falling through to the normal
   DocSettings path for real local files.
4. **`_showBookDetail`** (add/add, identical shape to #3) — fork's
   `book.is_bookorbit` branch (routes to the purpose-built
   `_showBookOrbitDetail` dialog — no file-backed Edit-tab actions are safe
   against a `bookorbit://` placeholder) vs. upstream's `_isRemoteRecord`
   branch (routes OPDS records to the existing read-only
   `_showRemoteBookInfo` viewer). Same independent-guards shape as #3;
   confirmed both target functions (`_showBookOrbitDetail`,
   `_showRemoteBookInfo`) exist elsewhere in the file, unconflicted. Kept
   both, BookOrbit checked first for the same reason as #3.

**Additional regressions found during the full-file review (not inside any
marked conflict hunk):** having just fixed `_statusStripHeight`'s stale
`Repo.buildBook` call in item 1, searched the rest of the file for the same
shape and found **three more** — `_buildMicroHero`, `_swapHeroStatusStrip`,
and `_buildExpandedStrip` — each auto-merged cleanly from upstream (no fork
edit ever touched these exact lines, so the conflict inventory never
surfaced them), each carrying the identical bare
`Repo.buildBook(self._preview_book.filepath)` regression. Fixed all three
the same way (`self:_hydrateBook(self._preview_book)`). A fourth, related
but distinct call site was also found: `onSwipeShelvesDown` (the
expanded→collapsed swipe-down handler) promotes the selected book into
`self._preview_book` via a bare `Repo.buildBook(sel_fp) or self._preview_book`
— the exact shape `BOOKORBIT_HERO_FIX.md`'s "5 places" fix targeted, just a
6th instance the original fork-side fix missed. Changed to
`Repo.buildPreviewBook(sel_fp, self._preview_book) or self._preview_book`
for consistency. Re-grepped the whole file afterward for both
`Repo.buildBook(` and `_preview_book = ` to confirm no further instances of
either pattern remain unfixed — one legitimate unrelated `Repo.buildBock`-
free case remains N/A (none left; every `_preview_book` assignment in the
file now routes through `_hydrateBook` / `Repo.buildPreviewBook` / a plain
`nil`/copy assignment).

**Full-file review:** confirmed zero remaining `<<<<<<<`/`=======`/`>>>>>>>`
markers anywhere in the file (and repo-wide, via `grep -rl` across all
`.lua` files). Checked for duplicate method definitions (the
`_swapShelvesInPlace`-style artifact class) via
`grep -o "function BookshelfWidget:[A-Za-z_]*" | sort | uniq -c` — every
method appears exactly once.

**Validation:** same sandbox constraint as Batches 4a/4b-i (no `luac`
binary). This time a small C syntax-checker was compiled directly against
`liblua5.4.so.0` (`luaL_newstate` + `luaL_loadfilex`, hand-declared —
`gcc synchk.c -o synchk -l:liblua5.4.so.0`) rather than reusing a one-off
throwaway script, since this was the last hunk batch and worth having a
reusable check. Ran it over `bookshelf_widget.lua` (parses cleanly) and then
over every `.lua` file in the whole tree (all clean) as the full-file/
full-tree sweep for this batch.

**`bookshelf_widget.lua` is now fully resolved: 24/24 conflict hunks, plus
6 total instances of the hero-fix regression pattern found and fixed (2
inside marked hunks across Batches 4a/4b-ii, 4 discovered outside any
hunk during review).**

### Batch 5a-i (done) — `locale/bookshelf.pot`, investigate + verify

No `.lua`-file work this batch; this was entirely about the `.pot`'s 64
add/add conflict-hunk pairs and whether a full regeneration is safe.

- **Found the maintainer's exact `xgettext` recipe by reverse-engineering
  it against the known-good v4.7.0 source.** Regenerated a `.pot` from the
  pristine v4.7.0 tree (second upload) with a few candidate option sets
  and diffed each against upstream's own shipped `locale/bookshelf.pot`
  until the diff was empty (aside from the `POT-Creation-Date` timestamp,
  which always changes on regeneration). The winning invocation:
  `xgettext --language=Lua --keyword=_ --keyword=N_ --keyword=tr --no-wrap
  --sort-by-file --from-code=UTF-8 -f <all .lua files, sorted> -o <out>`.
  Two non-obvious things had to be discovered to get the exact match:
  - `--keyword=tr` is required in addition to the obvious `_`/`N_`: several
    files (`bookshelf_filter.lua`, `bookshelf_sort_engine.lua`,
    `bookshelf_tab_model.lua`, `bookshelf_book_repository.lua`) alias the
    translator function as `tr` via `lib/bookshelf_i18n.lua`'s
    `local tr = require(...).gettext`-style pattern rather than `_`.
    Missing this keyword silently drops ~60 real strings from the `.pot`
    with no error — including `"Unrated"`, `"Unknown"`, and several
    filter/sort-label strings — so it would have looked like a clean
    regeneration while quietly losing content.
  - No `--add-comments` flag: upstream's shipped `.pot` has zero extracted
    `#.` translator comments, so passing `--add-comments` (which seemed
    like the "more helpful" default) would have added thousands of lines
    of stray comment text that was never actually part of the maintained
    file.
- **Regenerated the `.pot` from the merged source tree with the same
  verified recipe** (145 `.lua` files: all 138 from upstream v4.7.0 plus
  the 6 BookOrbit-only modules and 1 more fork-only file). Zero `xgettext`
  warnings. This is the candidate replacement content for Batch 5a-ii —
  **not yet written into the working file**.
- **Checked for lost BookOrbit strings** by reconstructing both sides of
  each of the 64 conflict-hunk pairs (the pre-merge fork `.pot` and the
  pure-upstream `.pot`) from the working file's conflict markers, then
  diffing "fork-only" msgids against the new regenerated `.pot`. 33
  fork-only strings surfaced; investigated each by hand against the actual
  merged `.lua` source (not just the `.pot` text) rather than assuming:
  - Most are strings correctly superseded by earlier batches' own
    decisions — e.g. the token-catalog descriptions Batch 2a's `#348`
    semantics sweep reworded (`"Reading status (unread / reading /
    on_hold / finished)"` → `"Reading status, raw value for conditionals
    (unread / reading / on_hold / finished)"`), and the scaled-cover-cache
    help text Batch 1b's disk-cache addition updated (`"...from memory"`
    → `"...in memory and on disk"`).
  - One is a genuine small text cleanup already present in the merged
    source and not flagged before now: the chip-delete confirmation went
    from a fork-side typo, `"Delete this chip?? This cannot be undone."`
    (double `?`), to the correct `"Delete this chip? This cannot be
    undone."` — confirmed via `bookshelf_chip_editor.lua:874`, harmless.
  - Several are pre-existing British/American spelling drift in areas
    BookOrbit never touched, so they auto-merged cleanly to upstream's
    American spelling with no conflict and no BookOrbit involvement at
    all: `"Favourite"` → `"Favorite"`, `"Favourite heart color"` →
    `"Favorite heart color"`, `"Favourite star color"` → `"Favorite star
    color"`, colour-dither wording → color-dither wording. Noting for the
    record (not fixing here, out of scope for a locale batch and not a
    regression this merge introduced): the clock micro-module's own id
    and code comments still say "analogue" while its settings-dialog
    title says `_("Analog clock")` — a pre-existing inconsistency, not
    something this merge created or should silently paper over.
  - The remaining ones are an upstream feature redesign, not a lost
    fork feature: the old single `"Show launcher button while reading"`
    toggle is superseded by upstream's two independent toggles (`"Show
    menu button"` / `"Show micro-modules button"`), confirmed live in
    `bookshelf_settings.lua`'s `_behaviourSubItems`.
  - **None of the 33 mention BookOrbit, sync, catalog, auth, or any other
    BookOrbit-specific vocabulary** — confirmed by inspection, not just
    absence of a keyword match.
- **Found the actual reason this batch exists, beyond just resolving
  conflict markers:** the pre-merge fork's own `.pot` had **zero**
  references to any `bookshelf_bookorbit_*.lua` file — confirmed by
  reconstructing the pre-merge fork `.pot` from the conflict markers and
  grepping it. The fork's `.pot` was already stale before this merge ever
  started; it was apparently never regenerated after the BookOrbit modules
  were added, so their `_()`/`tr()` strings were never in it to begin
  with. This isn't something the merge broke — it's a pre-existing gap
  the full regeneration fixes as a side effect, picking up all 39
  BookOrbit-sourced translatable strings that were missing before.

**Batch 5a-ii will:** overwrite `locale/bookshelf.pot` with the verified
regenerated content (already produced this batch), then re-sweep the
whole repo for stray `<<<<<<<`/`=======`/`>>>>>>>` markers to confirm
this was the last one.

### Batch 5a-ii (done) — `locale/bookshelf.pot`, apply

- Regenerated the `.pot` one more time with the identical verified recipe
  (same 145-file list, confirmed unchanged since 5a-i) to get a current
  timestamp, diffed it against 5a-i's candidate content to confirm the
  only difference was `POT-Creation-Date`, then wrote it over the
  conflicted `locale/bookshelf.pot` in full (`rm` + fresh write, not a
  patch, since the conflicted version had nothing worth preserving
  line-by-line — the whole point of 5a-i was establishing that a total
  regeneration is safe here).
- **Repo-wide conflict-marker sweep**: `grep -rl` for `<<<<<<<`,
  `=======`, `>>>>>>>` across the entire tree now returns nothing. Every
  file the original 15-file conflict inventory named, plus the `.pot`, is
  resolved. This was the last one.
- **`msgfmt --check`** on the new `bookshelf.pot`: passes, with only the
  expected placeholder-header warnings every fresh, untranslated `.pot`
  gets (`Project-Id-Version`/`PO-Revision-Date`/etc. still at their
  template defaults) — the same class of warning upstream's own shipped
  `.pot` produces, and the same class already present across the existing
  `.po` files (checked all of them too, as a sanity pass; all still
  compile clean, exit 0 — none of them were touched this batch, but
  confirming they still validate against nothing in the toolchain having
  silently drifted felt worth doing before calling this closed).
- Not yet done, on purpose, deferred to Batch 5b per the original plan:
  actually spot-checking individual `.po` files' translations for
  drift/staleness against the new `.pot`'s strings (a translation-content
  review, not a mechanical validity check — different kind of work).

### Batch 5b-i (done) — `.po` spot-check, part 2a (7 files)

Installed `gettext` in the sandbox (network egress to `archive.ubuntu.com`
is allowlisted) to get `msgfmt`/`msguniq`/`xgettext` for this batch, rather
than hand-parsing `.po` syntax.

Checked `bg_BG.po`, `de.po`, `en_GB.po`, `es.po`, `fr.po`, `hu.po`,
`it.po` — all four checks below, per file:

1. **`msgfmt --check`** — all 7 pass (exit 0). Only the same class of
   boilerplate header warnings (`Project-Id-Version` / `PO-Revision-Date` /
   `Last-Translator` / `Language-Team` still at template defaults) already
   noted as expected in Batch 5a-ii; nothing new.
2. **`msgfmt -c --check-format --check-domain`** (stricter: catches
   `%s`/`%d`-style placeholder-count mismatches between `msgid` and
   `msgstr`) — all 7 clean, zero format warnings.
3. **Duplicate-`msgid` check** (`msguniq` vs. raw `msgid` count) — all 7
   files: 1323 `msgid`s before, 1323 after dedup. No duplicates in any of
   them.
4. **BookOrbit-string check** (`grep -i bookorbit`) — zero matches in all
   7 files. Expected, not a regression: per Batch 5a-i's finding, the
   pre-merge fork's own `.pot` never had any BookOrbit-sourced strings in
   it (they were never extracted in the first place), so no `.po` file
   ever had them either. Nothing to lose here because nothing was there.

**Staleness spot-check against the new `.pot`** (comparing each file's
`msgid`s against the regenerated `bookshelf.pot`'s 1492 `msgid`s): all 7
files show the identical pattern — 1322 real `msgid`s (1 header entry
excluded), 1320 still match the new `.pot` exactly, and the same 2 are
stale in every single file (confirms these 7 `.po` files share one common
ancestor state, as expected — no per-language drift). Investigated both
stale strings by hand against the actual merged source, not just the
`.pot` diff:

- `"Memory budget for ready-scaled book covers (MB). Higher = smoother
  paging and preloading, more RAM. Default 24 MB."` — superseded by a
  longer version of the same help text
  (`lib/bookshelf_settings.lua:5973`) that Batch 1b's disk-cache-layer
  work extended with a BookOrbit-relevant caveat about large-library
  browsing sessions. This is the exact string Batch 5a-i already flagged
  as "the scaled-cover-cache help text Batch 1b's disk-cache addition
  updated" — not a new finding, just confirming it's the same one showing
  up here too. The old translations for this string simply won't
  carry over to the new wording until these files go through a normal
  `msgmerge` translator-maintenance pass — expected, not something this
  merge broke.
- `"Updates"` — confirmed via `grep` that this string no longer appears
  live anywhere in `main.lua`; it only exists inside the commented-out
  block from Batch 3a's decision (keep the "Updates" menu item disabled).
  `xgettext` correctly doesn't extract strings from Lua comments, so the
  regenerated `.pot` correctly has no entry for it. The old `.po` files'
  translations for "Updates" are now orphaned, which is the correct,
  intended outcome of the Batch 3a call, not a defect.

**Conclusion for this half:** no lost or duplicated BookOrbit strings (none
existed to lose), no corrupted/duplicate `msgid`s, no format-string
mismatches, and the only 2 stale entries per file both trace cleanly back
to earlier, already-documented batch decisions rather than anything new.
Nothing in these 7 files needs editing.

### Batch 5b-ii (done) — `.po` spot-check, part 2b (7 files)

Same 4 checks as Batch 5b-i, run against `ja.po`, `pt_BR.po`, `pt_PT.po`,
`uk.po`, `vi.po`, `zh_CN.po`, `zh_TW.po`.

1. **`msgfmt --check`** — all 7 pass (exit 0). Only the same class of
   boilerplate header warnings as every other file checked so far
   (`Project-Id-Version` / `PO-Revision-Date` / etc.).
2. **`msgfmt -c --check-format --check-domain`** — all 7 clean, zero
   format-string warnings.
3. **Duplicate-`msgid` check** — all 7: raw `msgid` count equals
   `msguniq`-deduped count (1323 in every file). No duplicates.
4. **BookOrbit-string check** (`grep -i bookorbit`) — zero matches in all
   7. Same expected reason as Batch 5b-i: these strings were never
   extracted into any `.pot` pre-merge, so no `.po` file ever had them.

**Staleness spot-check against the new `.pot`** — this half showed a
different, wider pattern than the first 7, worth investigating rather
than assuming it matched:

| File | msgids (excl. header) | stale vs. new `.pot` |
|---|---|---|
| `ja.po` | 1321 | 19 |
| `pt_BR.po` | 1338 | 36 |
| `pt_PT.po` | 1338 | 36 |
| `uk.po` | 1309 | 7 |
| `vi.po` | 1321 | 19 |
| `zh_CN.po` | 1340 | 38 |
| `zh_TW.po` | 1310 | 8 |

Unlike Batch 5b-i's uniform "2 stale entries in every file," these ranged
from 7 to 38. Rather than assume this meant something had gone wrong in
the merge, checked it against upstream's **own pristine v4.7.0** shipped
`.pot` and the same 7 `.po` files from the pristine v4.7.0 upload (not the
merged tree) — i.e., what these translations' staleness looked like
*before this merge ever touched them*:

| File | stale vs. **upstream's own pristine v4.7.0 `.pot`** |
|---|---|
| `ja.po` | 17 |
| `pt_BR.po` | 34 |
| `pt_PT.po` | 34 |
| `uk.po` | 5 |
| `vi.po` | 17 |
| `zh_CN.po` | 36 |
| `zh_TW.po` | 6 |

Every count is exactly 2 lower than the merged-tree figure above. Computed
the actual set difference (merged-tree stale set minus pristine-v4.7.0
stale set) per file to confirm those "extra 2" are the same 2 identical
strings in all 7 files, not 14 different ones landing on the same count by
coincidence: `"Memory budget for ready-scaled book covers (MB)..."` and
`"Updates"` — the exact same two entries Batch 5b-i already found and
traced to Batch 1b's disk-cache help-text update and Batch 3a's
keep-Updates-disabled decision, respectively.

**Conclusion:** these 7 `.po` files (particularly `pt_BR`/`pt_PT`/`zh_CN`,
each ~34-38 stale entries) are meaningfully further behind upstream's
current English strings than the first 7 checked in Batch 5b-i — but this
gap is **entirely pre-existing**, present in identical near-form in
upstream's own shipped v4.7.0 release, and has nothing to do with the
BookOrbit fork or this merge. This merge added the exact same 2 stale
entries to these files as it did to the Batch 5b-i files, for the exact
same already-documented reasons, and not one entry more. No BookOrbit
content lost, no corruption, no merge-introduced regressions. Nothing in
these 7 files needs editing as part of this merge; the broader translation
lag (if it's ever worth addressing) is an upstream-wide translator-
maintenance matter that predates and is out of scope for this merge.

## Reproducing this state in a fresh session

If this conversation is lost, a fresh session can get back here with:

```bash
mkdir -p /home/claude/work && cd /home/claude/work
unzip -o /mnt/user-data/uploads/bookshelf_koplugin_MERGE_WIP_after_batch6b.zip -d mergerepo_wip
```

This IS the working-tree checkpoint (see "Checkpoint zips" below) — it
already has Batches 1a-3b, 4a, 4b-i, 4b-ii, 5a-i, 5a-ii, 5b-i, 5b-ii, 6a,
and 6b resolved/checked in place, so a fresh session can resume straight
from it without rebuilding the git repo or re-downloading vanilla
v3.10.8. **All 16 originally- or newly-conflicted files (the 15 `.lua`
files plus `locale/bookshelf.pot`) are fully resolved — zero conflict
markers anywhere in the tree — all 14 pre-existing `.po` files have
passed the Batch 5b spot-check, and all 43 cleanly-added upstream files
have passed the Batch 6 sanity pass.** Only Batch 7 (final pass, final
packaging) remains.

The full from-scratch git-repo rebuild (pristine base + 3-way `git
merge`) is **not guaranteed reproducible** in every fresh sandbox
session by this route: it needs network access to fetch pristine
v3.10.8 from GitHub. This particular session happened to have that
access (`github.com`/`codeload.github.com` were reachable, and
`archive.ubuntu.com`/`security.ubuntu.com` were too, which is how this
session finally got a real `luac`/`gettext` toolchain instead of the
hand-rolled substitutes used in Batches 4a-6a) — but that isn't
guaranteed for any given session. If a from-scratch rebuild is ever
needed again and network access isn't available, it requires both the
original modded-fork zip and the v4.7.0 zip re-attached.

## Checkpoint zips

Since a `git commit` can't happen mid-merge while conflicts remain (git
refuses to commit with unresolved paths), each sub-batch's checkpoint is a
zip of the merge repo's current **working tree** (conflict markers still
present in files not yet reached), named
`bookshelf_koplugin_MERGE_WIP_after_batch<N>.zip`. This is a work-in-progress
snapshot for resuming the merge, **not an installable plugin build** — files
past the resolved batches still contain raw `<<<<<<<` markers. The Decisions
log above is the authoritative record of what changed and why; a fresh
session can reproduce the repo state (see below) and re-apply the same
resolutions from that log if the WIP zip itself is unavailable.

---

**Status: Batch 1a + 1b + 2a + 2b + 3a + 3b + 4a + 4b-i + 4b-ii + 5a-i +
5a-ii + 5b-i + 5b-ii done. All 16 conflicted files (the 15 `.lua` files
from the original inventory, plus `locale/bookshelf.pot`) are fully
resolved — zero conflict markers anywhere in the repo. `luac`-equivalent
syntax check is clean across every `.lua` file, and `msgfmt --check`
passes on the regenerated `.pot`. All 14 `.po` files (both Batch 5b-i's 7
and Batch 5b-ii's 7) pass `msgfmt --check`, strict format-string checks,
and duplicate-`msgid` checks, with zero BookOrbit strings lost (none
existed pre-merge) and zero merge-introduced regressions — the only
merge-attributable staleness in any `.po` file is the same 2 entries
(already traced to Batch 1b and Batch 3a decisions) found in every one of
the 14 files; all further staleness in the Batch 5b-ii files is confirmed
pre-existing in upstream's own shipped v4.7.0 release, unrelated to this
merge or the BookOrbit fork.

The entire locale batch (5a + 5b, both split into two sub-batches each)
is now complete.

Only Batches 6-7 remain:
- **Batch 6a/6b** — sanity pass over the 43 cleanly-added upstream files
  (confirm no extra wiring needed, no BookOrbit naming/behaviour
  collisions).
- **Batch 7a/7b** — final pass (bump `_meta.lua` version, full `luac -p`
  sweep, re-read all `BOOKORBIT_*.md` docs against the merged code) and
  final packaging.

**Status update — Batch 6a done, then Batch 6b done. Batch 6 (both
halves) is now complete — all 43 cleanly-added upstream files sanity-
checked, zero collisions, zero orphans, all wired correctly, and (as of
6b) verified with a real `luac`/`gettext` toolchain rather than
substitutes. Only Batch 7 (final pass + packaging) remains.**

### Batch 6a (done) — sanity pass over cleanly-added upstream files, part 1

**Correction to the Batch 0 inventory:** re-derived the "45 cleanly added
files" figure this session by actually diffing pristine v3.10.8 (freshly
re-downloaded from GitHub — this sandbox session had network egress to
`github.com`/`codeload.github.com`, unlike prior sessions) against pristine
v4.7.0. The true count of upstream-only files (present in v4.7.0, absent
from v3.10.8) is **43 plugin files** (41 `lib/`+`tools/` files + 2 new
locale files `uk.po`/`zh_TW.po`), not 45 — plus 3 repo-meta dotfiles
(`.gitattributes`, `.github/FUNDING.yml`, `.github/workflows/ci.yml`) that
aren't part of the installable plugin tree and were correctly never carried
into the WIP checkpoint. `locale/bookshelf.pot` is excluded from this list
since it's one of the 16 already-tracked conflicted files, not a clean add.
The 2-file discrepancy from the original "45" estimate doesn't affect
anything already done — it's a bookkeeping correction, not a sign of
missing work. Full list of the 43 files split into two batches of ~21-22
below.

**Batch 6a scope (first 22 files, alphabetical):** `bookshelf_band_metrics`,
`bookshelf_bim_db`, `bookshelf_changelog`, `bookshelf_cover_disk_cache`,
`bookshelf_drill_rekey`, `bookshelf_file_ops`, `bookshelf_file_poll`,
`bookshelf_folder_picker`, `bookshelf_fs`, `bookshelf_gettime`,
`bookshelf_http`, `bookshelf_inline_style`, `bookshelf_kindle_source`,
`bookshelf_line_editor`, `bookshelf_list_geom`, `bookshelf_list_group`,
`bookshelf_list_line_editor`, `bookshelf_list_lines`, `bookshelf_list_row`,
`bookshelf_move_flow`, `bookshelf_opds_catalog_editor`,
`bookshelf_opds_catalogs` (all `lib/*.lua`).

Checks run against each:
1. **Byte-for-byte identical to pristine v4.7.0** — confirmed for all 22.
   No corruption or accidental edits during the merge.
2. **Naming collision check against the 6 BookOrbit-only modules**
   (`bookshelf_bookorbit*.lua`) — zero collisions; no shared basenames, no
   cross-references between the two sets.
3. **Wiring check** — every one of the 22 is `require`d by at least one
   other file in the merged tree (counts ranged 1-12 references); none are
   orphaned/dead code.
4. **Internal dependency check** — every `require(...)` call inside these
   22 files resolves to a real file in the merged tree; nothing points at a
   module that doesn't exist.
5. No live KOReader in this sandbox (same limitation as every prior batch),
   so `luac -p` isn't available here either — but since these files are
   byte-identical to upstream's own shipped v4.7.0 release, their syntax
   validity inherits from upstream's own release process.

**Conclusion:** all 22 files in this half are clean — untouched, correctly
wired, no collisions. Nothing needs editing.

### Batch 6b (done) — sanity pass over cleanly-added upstream files, part 2

**Scope confirmed by re-deriving the diff from scratch** (this sandbox
session had network egress to `github.com`/`codeload.github.com`, so
pristine v3.10.8 was re-downloaded and diffed against pristine v4.7.0
again, independently of Batch 6a's own re-derivation): 41 `lib/`+`tools/`
files total upstream-only, of which the first 22 were Batch 6a's scope.
This batch's 21: `bookshelf_opds_covers`, `bookshelf_opds_db`,
`bookshelf_opds_download`, `bookshelf_opds_feed`, `bookshelf_opds_icon`,
`bookshelf_opds_prefs`, `bookshelf_opds_source`, `bookshelf_opds_window`,
`bookshelf_reader_status`, `bookshelf_stack_display`, `bookshelf_text_fit`,
`bookshelf_token_record`, `bookshelf_view_mode`, `calibre_metadata`,
`status_line`, `token_conformance`, `token_semantics` (all `lib/*.lua`),
plus `tools/check_token_parity.sh`, `tools/gen_pinyin_table.py`, and the 2
new locale files `locale/uk.po`, `locale/zh_TW.po`. Matches the count this
handoff doc already committed to (17 + 2 + 2 = 21).

Checks run:
1. **Byte-for-byte identical to pristine v4.7.0** — confirmed for all 21
   (17 `.lua`, 2 `tools/` scripts, 2 `.po` files). No corruption or
   accidental edits during the merge.
2. **Naming collision check against the 6 BookOrbit-only modules** — zero
   shared basenames, and grepped every BookOrbit module for references to
   any of these 21 names: zero cross-references either direction.
3. **Wiring check** — every one of the 21 is referenced by at least one
   other file in the merged tree (counts ranged 1-8); none orphaned.
   `bookshelf_stack_display` in particular (`StackDisplay.externalLabel`,
   the call Batch 1b's `bookshelf_shelf_row.lua` resolution relies on) is
   confirmed live and wired, 6 references.
4. **Internal dependency check** — every `require(...)` inside these 17
   `.lua` files resolves to a real file in the merged tree, with the sole
   expected exception of `libs/libkoreader-lfs` (a base-KOReader C binding
   outside the plugin tree entirely, not a plugin-internal dependency —
   correctly unresolved by design, same as it would be for any plugin
   file).
5. **Real `luac -p` this time, not the hand-rolled checker.** Unlike every
   prior batch (no `luac` binary in any earlier sandbox session, only
   `liblua5.4.so.0`), this session had network egress to
   `archive.ubuntu.com`, so `apt-get install lua5.4` pulled in the actual
   `luac5.4` binary. Ran it against all 17 `.lua` files in this batch
   (clean) and then, as a bonus beyond this batch's own scope, against
   **all 145 `.lua` files in the entire merged tree** — genuinely clean,
   confirming every prior batch's hand-rolled-checker-based validation
   from Batches 4a through 6a. Also installed real `gettext` and ran the
   same 4-check spot-check from Batch 5b against the 2 new `.po` files
   (`msgfmt --check`, strict `--check-format --check-domain`, duplicate-
   `msgid` check via `msguniq`, `bookorbit` grep): both pass clean, 1323
   `msgid`s each with no duplicates, zero BookOrbit references (expected —
   these files didn't exist pre-merge, so there was never any BookOrbit
   content to lose from them).

**Conclusion:** all 21 files in this half are clean — untouched, correctly
wired, no collisions, and (for the first time this merge) verified with
the actual reference `luac`/`gettext` toolchain rather than substitutes.

**All 43 cleanly-added upstream files (Batch 6a's 22 + Batch 6b's 21) are
confirmed sane.** Batch 6 is complete.

---

**Overall status: Batch 1a + 1b + 2a + 2b + 3a + 3b + 4a + 4b-i + 4b-ii +
5a-i + 5a-ii + 5b-i + 5b-ii + 6a + 6b all done.** All 16 originally-
conflicted files are fully resolved with zero conflict markers anywhere
in the repo; the entire `.lua` tree (145 files) and both new `.po` files
pass real `luac -p` / `msgfmt --check` this session; all 14 pre-existing
`.po` files passed the Batch 5b spot-check; all 43 cleanly-added upstream
files passed the Batch 6 sanity pass with zero collisions, zero orphans,
correct wiring.

**Only Batch 7 remains:**
- **Batch 7a** — bump `_meta.lua` version, full `luac -p` sweep (trivial
  now that a real toolchain is installed this session), re-read all
  `BOOKORBIT_*.md` docs against the merged code to confirm each
  documented fix still holds.
- **Batch 7b** — package the final zip, present it, final confirmation.

---

## Batch 7a (done) — final pass: version bump, full luac sweep, doc-vs-code re-verification

**Toolchain:** this sandbox session again had network egress to
`archive.ubuntu.com`/`security.ubuntu.com`, so `apt-get install lua5.4
gettext` pulled in real `luac5.4` and `msgfmt`, same as Batch 6b.

1. **Version bump.** `_meta.lua`: `version = "4.7.0"` →
   `version = "4.7.0-bookorbit1"`, so the fork is distinguishable from
   vanilla upstream at a glance (e.g. in KOReader's plugin manager).

2. **Full `luac5.4 -p` sweep.** All 145 `.lua` files in the merged tree
   (every `lib/`, `tools/`, `micromodules/` file, `main.lua`, `_meta.lua`)
   parse clean. Zero failures.

3. **Bonus `.po` re-check.** All 14 `locale/*.po` files (12 pre-existing
   + `uk.po` + `zh_TW.po`) pass `msgfmt --check --check-format
   --check-domain`. (Note: re-confirmed against a fresh diff of pristine
   v3.10.8/v4.7.0 that v4.7.0 itself only ever shipped 14 total `.po`
   files, not 16 — the Batch 5b "14 pre-existing" wording was measuring
   a different baseline than "total in v4.7.0"; no files are missing,
   this WIP tree's locale set is byte-for-byte the same file *list* as
   pristine v4.7.0, just not byte-identical *content* for the files
   BookOrbit's translations touch.)

4. **Re-read every `BOOKORBIT_*.md` doc against the merged code, file by
   file, to confirm each documented fix still holds after all 16
   originally-conflicted files were resolved:**

   - **`BOOKORBIT_HERO_FIX.md`** — `BOSource.rebuildRecord` present;
     `Repo.buildPreviewBook` present and correctly routes `bookorbit://`
     paths through it; `BookshelfWidget:_hydrateBook` (the fix Batch 4a
     restored after upstream's refactor regressed it) present and now
     has **8** call sites (grew from the doc's original 5, as upstream's
     v4.7.0 list-view engine added more preview paths — all of them
     correctly routed through the fix, not bypassing it). Zero remaining
     direct `Repo.buildBook(` calls in `bookshelf_widget.lua` that could
     bypass the fix. The two documented "does NOT touch" paths
     (`SpineWidget`'s direct grid render, `_showBookOrbitDetail`'s direct
     `BOSource.coverBB()` call) are both still untouched, as intended.
   - **`BOOKORBIT_AUTHOR_LETTERJUMP_SLOWNESS_FIX.md`** — `M.listGroups`
     still takes `opts` as its 4th argument, gates strictly on
     `opts.light_only` (not `lazy_cover`, per the doc's explicit warning
     about the earlier broken version of this fix), and
     `Repo.getBySource`'s group-root branch still forwards its `opts`
     through to `listGroups`.
   - **`BOOKORBIT_DISTORTED_COVERS_ON_REVISIT_FIX.md`** — both
     `self.book.cover_bb = nil` nulling sites present in
     `bookshelf_spine_widget.lua` (cache-hit and cache-miss free paths);
     `wantsCover()` still gates on the persistent `record._cover_filled`
     flag rather than `record.cover_bb` itself, and `fillOneCover()`
     still sets it.
   - **`BOOKORBIT_DUPLICATE_AUTHORS_FIX.md`** — `_bucket_fetching[section]`
     reentrancy guard and `appendUniqueEntries`/`_seen_ids` dedup helper
     both present and wired into `fetchSectionBucket`'s merge path.
   - **`BOOKORBIT_GROUPED_AUTHORS_SERIES.md`** — `bookshelf_group_cover_
     cache.lua` (`GroupCoverCache`) present; `cover_bb_cache_owned` flag
     round-trips correctly from `bookshelf_bookorbit_source.lua` through
     to `bookshelf_folder_stack.lua`'s disposable/non-disposable paint
     decision; `is_bookorbit`-scoped explicit-cover-bb override present;
     `isGroupRoot`/`listGroups`/`_expandBookOrbitGroup` drilldown wiring
     all present in the source, widget, and shelf-row files; both
     `groupCoversEnabled`/`groupLabelsEnabled` settings-menu toggles
     wired in `bookshelf_settings.lua`.
   - **`BOOKORBIT_HERO_COMMUNITY_RATING.md`** — `M.communityRating` /
     `M.communityRatingFallback` present and wired into `rebuildRecord`;
     hero card reads `BOSource.communityRatingFallback` in provider-chain
     order; the server patch file
     (`bookorbit-server-expose-community-ratings.patch`) still shipped
     alongside the plugin.
   - **`BOOKORBIT_COVERS_STILL_MISSING_FIX.md`** (all 3 rounds) — the
     root-cause `type(bb) ~= "table"` → `not bb` fix confirmed in both
     `bookshelf_bookorbit_source.lua`'s `coverBB` **and**
     `bookshelf_kobo_source.lua`'s (the doc's noted copy-paste sibling
     bug); `BOSource.isBookOrbitPath` skip still gates `maybe_queue()`
     before BIM queueing (prevents the crash-loop from round 2); the
     `content-type=`/`content-encoding=`/`magic=` diagnostic logging from
     round 2 still present in `coverBB`'s failure path.
   - **`BOOKORBIT_INTEGRATION.md`** — spot-checked the core wiring
     claims: `md5hex()` still uses `require("ffi/sha2").md5` (the
     original broken-password-hash fix); `main.lua` still has the
     BookOrbit menu entry, the `BookshelfBookOrbitSyncNow` dispatcher
     action, and the push-on-close / pull-notice-on-open hooks;
     `bookshelf_settings.lua` still has the full Connect / Browse catalog
     / Sync now / Disconnect menu wired to `BookOrbit.testConnection` /
     `showConnectDialog` etc.

   **No regressions found anywhere.** Every documented fix is present,
   correctly wired, and — where later batches touched the same code
   again (HERO_FIX's call-site count) — extended rather than weakened.

5. **Final conflict-marker sweep.** `grep -rl "<<<<<<<\|=======\|>>>>>>>"`
   across the entire tree: zero hits outside this handoff doc's own
   prose.

**Conclusion: Batch 7a is complete.** Version bumped, full real-toolchain
`luac -p` sweep clean across all 145 `.lua` files, every BookOrbit fix
independently re-verified against the final merged code with no gaps.

**Only Batch 7b remains: package the final zip and present it.**

Awaiting go-ahead to start Batch 7b.**

## Batch 7b (done) — final packaging

Re-verified this session (fresh sandbox, no network egress available this
time, so back to the hand-rolled `liblua5.4.so.0`-based syntax checker
rather than a real `apt`-installed `luac5.4`/`gettext` — same class of
substitute used in Batches 4a-6a):

- **Full-tree syntax sweep**: all 145 `.lua` files parse clean (zero
  failures) via the hand-rolled checker.
- **Conflict-marker sweep**: zero `<<<<<<<`/`=======`/`>>>>>>>` markers
  anywhere in the tree (outside this doc's own prose).
- **Version**: `_meta.lua` confirmed at `4.7.0-bookorbit1` (set in Batch 7a).
- **BookOrbit integrity check**: all 6 `bookshelf_bookorbit*.lua` modules
  plus `bookshelf_group_cover_cache.lua` present; all 7 `BOOKORBIT_*.md`
  docs present; the community-ratings server patch file present.
- **Duplicate-function-definition sweep** on `bookshelf_widget.lua` (the
  file that had two merge-tool duplication artifacts caught in Batches
  4b-i/4b-ii): every `function BookshelfWidget:*` appears exactly once.
- **Locale**: 14 `.po` files + the regenerated `bookshelf.pot`, matching
  the Batch 5/6 counts.

**Packaged** as `bookshelf.koplugin/` (matching the standard KOReader
plugin folder layout, same as both original uploads) into
`bookshelf.koplugin_v4.7.0-bookorbit1.zip` — this **is** the installable
plugin build (unlike every `_MERGE_WIP_*` checkpoint before it, which
were working-tree-with-possible-markers snapshots for resuming the merge
session). Drop the `bookshelf.koplugin` folder into KOReader's `plugins/`
directory to install/upgrade.

**The merge is complete: all 7 batches (0 through 7b) done.** Vanilla
v3.10.8 → v4.7.0 upstream sync finished with the full BookOrbit
integration intact, extended, and — in a few places found only during
this merge (the hero-fix's 3 extra regressed call sites, the letter-jump
fix's missing `bookorbit_group` branch in the new `_jumpScanList`
helper, the shelf-tap Trapper-wrapping gap) — repaired to work correctly
against upstream's v4.7.0 code, not just carried forward unchanged.

## Post-release fix — `_maxRowsSquashed` crash on real device

**Reported after Batch 7b's zip was installed and run on real hardware**
(this class of bug is invisible to `luac -p` / the hand-rolled syntax
checker, since it's syntactically valid Lua — a runtime nil-argument
crash, not a parse error):

```
lib/bookshelf_widget.lua:10065: bad argument #5 to 'format'
(number expected, got nil)
```

in `_maxRowsSquashed`, called from `_nShelves` -> `_rebuild` on every
widget open/refresh — this was a hard crash on launch, not an edge case.

**Root cause:** `_maxRowsSquashed()`'s trailing `logger.dbg(string.format(...))`
diagnostic line (added for issue #329, "why N rows and not N+1") was copy-
pasted from the near-identical debug line in `_maxRows()` just above it.
`_maxRows()` names its local `slot_h` (natural cover height); `_maxRowsSquashed()`
deliberately renamed its equivalent local to `slot_h_floor` (70%-shrunk
height, per the function's own doc comment) to keep the two concepts
textually distinct — but the pasted debug line's argument list still read
`slot_h`, which resolves as an undefined global (`nil`) rather than a Lua
error, so it passed `luac -p` and every review pass in Batches 4a-7a
clean and only surfaced as a crash under `string.format`'s own runtime
type check.

**Fix:** changed the debug line's argument from `slot_h` to `slot_h_floor`
(matching the function's actual local), and corrected the log line's own
label from the copy-pasted `"_maxRows=%d"` to `"_maxRowsSquashed=%d"` so
future log output is attributable to the right function.

**Swept the rest of the file for the same bug class** (a bare identifier
passed to a `logger.dbg(string.format(...))` call that isn't actually in
scope) with a small heuristic static-analysis script — every one of
`bookshelf_widget.lua`'s ~60 other `logger.dbg(string.format(...))` call
sites was checked. 5 more candidates were flagged and individually
inspected by hand; all 5 were false positives from the script's own
limitations (locals declared as `local x` on one line and assigned later
in branches, and closure parameters the script didn't look inside) — none
were real bugs. `slot_h` was the only actual instance of this pattern in
the file.

Re-ran the full 145-file syntax sweep and the conflict-marker sweep after
the fix: both still clean. Repackaged and re-presented as
`bookshelf.koplugin_v4.7.0-bookorbit1.zip` (same version string — this is
a same-day correction to the initial 7b package, not a new release).
