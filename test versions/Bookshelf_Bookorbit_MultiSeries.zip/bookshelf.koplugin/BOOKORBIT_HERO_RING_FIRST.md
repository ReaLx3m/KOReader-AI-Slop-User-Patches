# BookOrbit: selection ring first, hero detail later (5.5.5-bookorbit9)

Status: **not run on a device.** Checked off-device only (Lua suite `ringfirst`,
158 checks, plus every older suite). The real source function
`BOSource.rebuildRecord` is run against fake BookOrbit client / caches / lfs /
RenderImage / Trapper; the real text of `Repo.buildPreviewBook`,
`BookshelfWidget:_hydrateBook` and `BookshelfWidget:_deferBookOrbitDetail` is
extracted and run under stubs; the big widget function `_previewBookWork` is
checked as source text only (plus one extracted slice that is run).

## The problem

Selecting a BookOrbit book whose synopsis is not cached on disk (first time
selected, or after "Refresh library") took a few seconds before the hero showed
the synopsis AND before the cover got its selection box. The tap handler built
the full record first, which includes a blocking detail request to the server,
and only then swapped the hero and drew the ring. A cached synopsis made it
instant.

## What it does now

Two phases, in `_previewBookWork` (grid selection by tap or d-pad):

1. **Phase 1, immediate, no network.** The record is built from local data only:
   shelf record, local rating override, cached synopsis / genres / community
   ratings when present, cover only when the thumbnail is already on disk. The
   hero swaps (title, author, cover) and the selection ring is drawn at once.
   When the synopsis is cached this is the complete record and nothing else
   happens (one step, as before).
2. **Phase 2, afterwards.** When the synopsis (or the thumbnail) was missing, the
   fetch is queued with `tickAfterNext` so the phase-1 paint is flushed first,
   then runs in a Trapper coroutine: the same blocking detail fetch as before,
   **with the same dismissable "Loading..." popup**, which now appears after the
   ring is drawn. When it lands, the hero is swapped once more and the synopsis,
   genres and community rating appear.

A phase-2 result is dropped silently when the widget was closed, another book
was selected meanwhile, or a newer deferral superseded it. A failed or dismissed
fetch keeps the phase-1 hero (title, author, cover, ring), the same fallback as
a failed fetch always had.

## API (all additive; calls without options behave exactly as before)

- `BOSource.rebuildRecord(fallback, opts)` returns `record, pending`.
  `opts.no_fetch == true` never calls the server and never downloads a
  thumbnail (cover via `cachedCoverBB` only); `pending` is true when the synopsis
  was not cached or a wanted cover is not on disk. Any other `opts` is the old
  path.
- `Repo.buildPreviewBook(filepath, fallback, opts)` forwards `opts` (BookOrbit
  only) and returns both values.
- `BookshelfWidget:_hydrateBook(book, opts)` returns `record_or_book, pending`
  (`pending` is always a boolean; false for remote/OPDS records, records without
  a filepath, failed rebuilds and every non-BookOrbit record). All other callers
  ignore the second value.
- `BookshelfWidget:_deferBookOrbitDetail(book)` is phase 2; field
  `self._bo_detail_token` numbers the deferrals.

## What is unchanged

The micro-module hero path (tap a cover while the module grid is shown) keeps the
blocking hydrate and the ring after the hero loads. The expanded-shelf tap,
`_buildHero`, `_swapHeroInPlace`, `_repaintSelectionHighlight`, the open-same
branch (tapping the selected book opens it), the covers / prefetch / decode-ahead
/ prescale / hold code, settings, translations (no new user-visible strings) and
the `_meta.lua` version are untouched. There is no setting or constant to turn
the feature off; reverting means restoring the one `_hydrateBook(book)` line in
the main path of `_previewBookWork` (and dropping the `pending` call below it).

## Debug log lines

`[bookshelf perf] bo hero detail: deferred`, `... landed ms=<n> swapped=<bool>`,
`... dropped reason=<stale|closed|superseded|failed>`. The existing
`_previewBook: buildBook=<n>ms` line now measures phase 1.

## Limits (all unverified on a device)

- **Ring before popup.** The design relies on UIManager painting the dirty
  regions of phase 1 before the Trapper popup of phase 2 appears. Not checked.
- **Second hero refresh.** The hero is refreshed twice on a miss: possible
  e-ink ghosting / flash, and a possible layout jump if the hero's height depends
  on the synopsis.
- **A rebuild between the phases** (anything that calls `_rebuild`) hydrates in
  full with the popup, as before; it fills the cache, so phase 2 then hits it.
- **Selecting another book while the fetch runs:** the first result is dropped,
  the new tap runs its own phase 1. A second tap on the SAME book opens it.
- **Dismissing the popup** keeps the phase-1 hero and the ring.
- The description cache is written by the parent process after the fetch returns
  (unchanged).
- Bitmaps are one-shot: each record gets its own fresh cover bitmap, and none is
  freed by the new code (dropped records rely on the bitmap finalizer).

## On-device checklist

1. A BookOrbit chip, a book whose synopsis is NOT cached: tap its cover. The
   selection box appears over the cover at once; the hero shows title / author /
   cover without synopsis; the "Loading..." popup may show; then the synopsis
   (and genres / community rating) fills in. Note how long the ring took and
   whether the hero jumped.
2. A book whose synopsis IS cached: behaves as before (one step, no popup).
3. Tap book A (uncached), then quickly book B before A's detail lands: the hero
   ends on B, no flicker back to A, no stale synopsis.
4. Dismiss the "Loading..." popup: the hero stays on the phase-1 version, the
   ring stays.
5. Wi-Fi off / server unreachable: ring at once, hero without synopsis, no error
   loop.
6. Tap an already selected book: still opens the book.
7. D-pad selection (non-touch devices) behaves the same as a tap.
8. Micro-module hero (tap a cover while the module grid is shown): unchanged,
   ring after the hero loads as before.
9. Log (debug): `bo hero detail: deferred` / `landed ms=.. swapped=..` /
   `dropped reason=..`.

As with the rest of this integration, all touched files pass a Lua syntax check
but this has not been run inside an actual KOReader process -- please test
on-device before relying on it.
