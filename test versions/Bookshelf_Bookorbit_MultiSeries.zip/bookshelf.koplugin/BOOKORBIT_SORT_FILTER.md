# BookOrbit Authors / Series: per-chip sort and filter

Each BookOrbit **Authors** or **Series** folder chip can carry its own server-side sort and
filter, as the official BookOrbit KOReader plugin (2.0.0) does. Edited in the chip editor
(`Sort:` and `Show:` buttons); not a shared shelf control.

| Chip | Sort | Show |
|---|---|---|
| Authors | Name A-Z, Name Z-A, Most books | Everyone, Reading now, Read |
| Series | Name A-Z, Name Z-A, Most books | All series, In progress, Finished |

## Storage
Two optional keys on the chip's source table: `source.bo_sort` (`nil` | `"name_desc"` | `"books"`) and
`source.bo_filter` (`nil` | `"reading"` | `"finished"`). `nil` is the default. Picking a different
BookOrbit section replaces the source table and so clears them.

## Server parameters
Sent to `GET /koreader/plugin/catalog/sections/<authors|series>` only when the server advertises
`catalogListsV2`: `sort=name_desc|books`, `filter=reading|finished` (omitted for the defaults),
next to `size`/`offset`. On older servers the options are ignored and the editor shows
"Needs a newer BookOrbit server" once the capability is known to be missing.

## Behaviour
- Authors, default or Name Z-A: the fork's client-side given-name order (reversed for Z-A) with the
  background walk. "Most books" and all Series orders keep the server's order, no client re-sort.
- Each sort/filter combination has its own cached list (`group2:<section>|<sort>|<filter>`; the default
  keeps `group2:<section>`). A refresh drops every combination of the section.
- The exact `total` from the server is used when present.
- "Go to letter" shows a notice on a "Most books" chip.
- Drilling into a tile is unchanged; sort/filter do not carry into the drilled-in list.
- Only the default Authors list is warmed at startup.

## Limits
Not verified on a device. Unverified: the server's maximum section page size (60 is used) and
whether every V2 server sends `previewBooks`/`hasPhoto` without extra parameters. A failed request
ends the walk as before (no retries).
