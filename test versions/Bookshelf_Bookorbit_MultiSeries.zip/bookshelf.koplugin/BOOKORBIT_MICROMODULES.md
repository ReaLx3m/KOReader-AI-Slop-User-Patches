# BookOrbit micro-modules (Batches 1-7)

48 of the 49 widgets on the BookOrbit plugin's dashboard board are available as
Bookshelf micro-modules, in the hero grid, the full-screen micro view and the start
menu. The Add micro-module dialog has two tabs, **Bookshelf** and **BookOrbit**; the
BookOrbit tab has the chips New, Reading, Stats, Library, Device and Decor.

- Reading 6, Stats 9, Library 12, Device 5, Decor 16. Full key list and the spec
  options: `micromodules/README.md`, section "BookOrbit micro-modules".
- **Not ported: Chapter line.** It needs a chapter map of the current book, and only
  the BookOrbit plugin saves those. Dropped on purpose (Batch 7).
- Needs a BookOrbit server: 37 of the 48. Work offline: `clock`, `analog`, `moon`,
  `odometer`, `glyph`, `light`, `toggles`, `link_device`, `word`, `records`, `hours`.
- Dark themes: widgets other than the `ink`/`fill` chrome ones are drawn on a light
  rounded panel when the host card is dark, so BookOrbit's black text stays legible.
- Behaviour that differs from the BookOrbit plugin: Sync now from the home screen
  pushes the pending outbox and probes the server instead of a full sweep; "On device"
  lists file names; Search opens a text prompt, then a plain list.

Not verified on a real KOReader (everything was checked off device): drawing and
fonts, icon/SVG caching, tap regions measured by painting off screen, Light / Wi-Fi /
rotate / night mode / Sync now / dust delete on real hardware, sqlite stats and
`partialMD5`, the background fetch job, picker rendering, dark-card look.
