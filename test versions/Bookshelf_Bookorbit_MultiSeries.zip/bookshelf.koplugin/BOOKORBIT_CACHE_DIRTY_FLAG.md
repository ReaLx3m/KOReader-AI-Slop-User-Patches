# BookOrbit catalog cache: dirty flag

Version string: `5.5.5-bookorbit10`. Touches `lib/bookshelf_bookorbit_cache.lua` (logic) and a comment in
`lib/bookshelf_widget.lua` (`_flushBookOrbitCache`). Nothing was run on a device; the logic is covered off-device by
`tools/bo_tests/test_bo_cachedirty.lua`.

## Problem
The whole catalog cache is one key (`cache_state`) in `settings/bookshelf_bookorbit_catalog_cache.lua`. `Cache.flush()`
was unconditional: on every suspend (and autosave / close) it loaded the file, deep-copied every entry and rewrote the
whole file, even if nothing had changed. The module's header promised a "dirty" state, but none existed. With many
cached items (PocketBook) that is a long write on the sleep path.

## Change
- Module-level `_dirty`, set by `set`, `evict` (when it pops entries), `invalidate` (only when something was removed),
  `invalidateAll`, and `checkVersionAndInvalidate` (only when it adopts a new version).
- `persist(force)` is a no-op when clean (forced calls too). The 30 s debounce is unchanged and a debounced skip keeps
  `_dirty` set, so a later `flush()` still writes it.
- `_dirty` is cleared only after a successful save; a failed write is retried at the next flush. `_last_flush_time` is
  still stamped per attempt, so a failing disk is not retried on every `set()`.
- `flush()` returns immediately if the cache was never loaded (nothing could have changed) or is clean, so an untouched
  cache is not read or parsed on suspend.
- New `M.isDirty()` for tests/diagnostics. On-disk format, key, file name and cache size default are unchanged; existing
  cache files load as before.

## Behaviour notes
- `get()` reorders the LRU list but does not dirty the cache. A pure reorder is lost on an unclean exit; harmless, it only
  changes which entry is evicted first. It is persisted along with the next real change.
- `evict()` marks dirty on any pop from the LRU order, which only happens when over budget.
- Callers (`onSuspend`, `onFlushSettings`, `onCloseWidget`) are unchanged.

## On-device checklist
1. Note size and modification time of `koreader/settings/bookshelf_bookorbit_catalog_cache.lua` on both devices.
2. Browse nothing, sleep and wake: the file's modification time must NOT change (before the patch it changed every sleep).
3. Browse a BookOrbit chip (new pages get cached), wait 30+ s or sleep: the file updates once; a second sleep with no
   browsing leaves it untouched.
4. Compare PocketBook wake time before and after. If still slow, A/B test: Auto Wi-Fi off; pull-on-wake off; cache size
   8 MB; look at debug-log timestamps between Suspend/Resume and `[bookshelf]` lines.
5. Delete the cache file and confirm the plugin still starts and rebuilds the cache.
