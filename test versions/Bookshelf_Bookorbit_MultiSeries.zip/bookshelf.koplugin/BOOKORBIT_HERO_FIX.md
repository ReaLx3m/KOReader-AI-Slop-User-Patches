# Fix: BookOrbit chip covers/synopsis missing in the hero

## Root causes

1. **No description was ever fetched.** `bookshelf_bookorbit_source.lua`'s
   `toRecord()` builds a book from a `catalogBooks()` list item, and that
   endpoint never returns a `description` (confirmed against the official
   `bookorbit.koplugin` -- only the per-book detail endpoint,
   `GET /catalog/books/<id>`, does). The hero's description region reads
   `book.description` (`%description` token in `bookshelf_tokens.lua`), which
   was simply never set for BookOrbit records.

2. **Hero covers went blank after a tap.** The grid attaches a cover
   correctly (`Repo.getBySource`'s `kind == "bookorbit"` branch calls
   `BOSource.coverBB(rec)`), but that `cover_bb` is a ONE-SHOT blitbuffer --
   freed the moment the grid tile paints it. Tapping a book to preview it in
   the hero did `Repo.buildBook(book.filepath) or book`, and `Repo.buildBook`
   / `buildBookMeta` always `return nil` for a `bookorbit://` placeholder
   path (there's no real file for BIM to read) -- so it always fell back to
   reusing the *same* grid record, including its by-then-freed `cover_bb`.
   Real BIM-backed books don't hit this because `buildBookMeta` re-decodes a
   fresh cover on every call; BookOrbit records had no equivalent refresh.

## Fix

- `lib/bookshelf_bookorbit_source.lua`: new `M.rebuildRecord(fallback)` --
  fetches the book's detail (for `description`) and a fresh cover via the
  existing `coverBB()`, keeping every other field from the list record.
  Returns `nil` on failure (offline, 401, etc.) so the caller falls back to
  the existing record untouched.
- `lib/bookshelf_book_repository.lua`: new `Repo.buildPreviewBook(filepath,
  fallback_book)` -- routes `bookorbit://` paths to `BOSource.rebuildRecord`
  (guarded so a mismatched fallback safely no-ops instead of rebuilding the
  wrong book); delegates to the existing `Repo.buildBook` for everything
  else.
- `lib/bookshelf_widget.lua`: the 5 places that promoted a tapped/selected
  book into `self._preview_book` via `Repo.buildBook(fp) or book` now call
  `Repo.buildPreviewBook(fp, book) or book` instead.

## What this does NOT touch

- The main cover grid itself (`bookshelf_shelf_row.lua` / `SpineWidget`)
  already renders correctly straight off `Repo.getBySource`'s attached
  `cover_bb` -- no reuse-across-widgets there, so nothing changed.
- The reduced BookOrbit long-press dialog (`_showBookOrbitDetail`) already
  fetches its own fresh cover via a direct `BOSource.coverBB(book)` call and
  by design doesn't show a description -- untouched.

## Verified

All `.lua` files in the plugin (including the 3 edited ones) parse cleanly
under `luac5.4 -p`. Not yet run inside an actual KOReader process -- please
test on-device.

## Testing checklist

1. Bookshelf menu -> Edit chips -> New chip -> BookOrbit section... -> pick
   any section with books that have covers/descriptions on the server.
2. Open the chip, tap a book's cover (don't open it). The hero should now
   show BOTH the cover and the synopsis text, not just title/author.
3. Tap a different book in the grid -- the hero should update to that
   book's own cover + synopsis (not the previous book's, not blank).
4. Long-press a book -- the small Open/Close dialog should still show its
   cover as before (no description, by design).
5. Toggle WiFi off, tap a book you haven't previewed yet -- hero should
   fall back gracefully to the list-level record (title/author/cover from
   the grid, no synopsis) rather than erroring or hanging.
