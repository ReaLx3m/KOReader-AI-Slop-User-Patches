# BookOrbit cover loading: faster and non-blocking (5.5.5-bookorbit9)

Status: **not run on a device.** Checked off-device only (Lua suites `covers`,
`coverpool`, `wiring`, run through a fake clock, fake forks and fake files).

## The problem

Switching BookOrbit chips or turning pages could freeze the UI. Covers were
filled on the UI thread, two per tick, each with a blocking HTTP download (a
long socket timeout) and a synchronous JPEG decode. After every two covers the
whole shelf was rebuilt and repainted, about 10 full rebuilds for a 24-book
page.

## What changed

1. **Repaint coalescing** (`lib/bookshelf_bookorbit_coalesce.lua`). The first
   cover repaint is immediate, later ones inside a 0.5 s gap merge into one,
   and the end of the cover queue always flushes. Constant: the gap in
   `bookshelf_widget.lua` (`0.5`).
   Hold (E1, pure pieces only): `Coalesce:request(source_id, final, hold)` and
   the pool's third `on_landed` argument `decode_left` still exist and are
   tested, but NOTHING passes them: the E2 wiring was removed on request, so a
   page turn keeps the plain 2-3 repaints (turn paint, leading-edge repaint,
   final repaint). To re-enable: pass `hold` from the main pool's `on_landed`
   through `fireCoversReady`, forward it in the widget's `onCoversReady`
   callback and give `Coalesce.new` a `hold_max` (previously 1.0 s).
2. **Forked downloads** (`lib/bookshelf_bookorbit_coverpool.lua`). Up to 3
   worker processes download covers while the UI stays free. The parent only
   decodes finished files, one cover per 0.02 s tick. Constants in
   `bookshelf_bookorbit_source.lua`: `COVER_POOL_WIDTH = 3`,
   `COVER_FORK_DEADLINE = 25`.
3. **Atomic files.** A worker writes `<cover>.jpg.part` and renames it only
   after a full 200 response with an `image/` content type. A killed worker can
   no longer leave a truncated cover under its final name. Stale `*.part` files
   are removed once per session.
4. **Short timeout tier for inline paths.** Downloads that still wait on the UI
   thread (the no-fork fallback, board covers) use the short
   socket timeout. A timeout there is retried later, not blacklisted. The hero
   cover (`coverBB`) and the forked workers keep the long tier.

## Behaviour worth knowing

- The pool **narrows** (halves, floor 1) after a timeout or transport error and
  never widens again within one run. A server answer such as 404 or "not an
  image" gives that cover up at once and does not narrow the pool.
- A stuck worker is killed after 25 s. A kill or crash costs a try; the second
  one gives the cover up for the session (manual swipe-refresh clears this).
- A page rebuild replaces only the pool's *pending* list. Running workers
  survive, so no download is wasted. A prewarm of a background chip does the
  same, so it can delay (not lose) the visible page's not-yet-started covers
  until the next rebuild.
- Closing the shelf kills all workers. Offline, nothing is launched and Wi-Fi is
  never turned on.
- No fork support (`ffi/util.runInSubProcess` missing) or a failed fork falls
  back to the old inline loop.
- No new setting and no new user-visible string.

## Debug log lines

- `[bookshelf perf] bo covers: n= disk= forked= failed= landed= wall= width_end=`
  once per finished run (distinct covers, already cached, workers launched,
  given up, decoded, time, final pool width).
- `[bookshelf perf] bo covers: repaint rebuild+dirty=<ms>` per repaint.
- `[bookshelf perf] bo covers: run queued= landed= wall=` for the inline fallback.

## Related

The page list itself is fetched in a worker too; `BOOKORBIT_HOLD_PAGE.md` keeps the
previous screen up while an uncached page loads, so title cards appear before
the covers here start.

## Known limits

- Decoding still happens in the parent, so a page of covers still costs CPU
  there (spread at one per tick).
- With "Prefetch next page" and its sub-setting "Decode covers ahead" (default on)
  on, the next page's covers are also decoded ahead and attached to the cached records (one page at a time, released when you move on):
  see `BOOKORBIT_PREFETCH_NEXT_PAGE.md`. In grid mode the idle tick also scales
  each cover to the tile size and stores it in `ScaledCoverCache` ("Scale ahead" in
  that file), so the page turn only blits; not run on a device.
- The next-page warm-up of the on-screen chip schedules no cover fills (P5, see
  `BOOKORBIT_PREFETCH_NEXT_PAGE.md`); chip pre-warm still does.
- The hero's `coverBB` writes straight to the final cache name; a partial file
  could be decoded once and is then retried. (`prefetchNextPage` no longer
  downloads on the UI thread: see `BOOKORBIT_PREFETCH_NEXT_PAGE.md`.)
- Real fork cost on low-RAM devices, and `request()` inside a forked child, are
  unverified.

## On-device checklist

1. Switch chips and turn pages on a library of 100+ books: UI stays responsive,
   covers appear in a few steps. Note any remaining freeze and its length.
2. Slow or far-away server: covers still arrive without freezing; a stuck cover
   is dropped after about 25 s and retried at most once.
3. Page forward and back quickly: no crash, no duplicate downloads in the log.
4. Wi-Fi off mid-load: stops quietly, no prompt, cached covers still show.
5. Close the Bookshelf (open a book) mid-load: no leftover or zombie processes,
   no error on return.
6. After the above and a restart, no `*.part` files in the cover cache folder.
7. Swipe-refresh still clears failed covers and re-fetches them.
8. If still slow, send the `[bookshelf perf] bo covers:` log lines.
