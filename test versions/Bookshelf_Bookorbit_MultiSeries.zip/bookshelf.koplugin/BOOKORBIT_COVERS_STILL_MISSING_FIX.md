# Fix round 3: root cause found -- `type(bb) == "table"` never true

Your latest log confirms it: the new diagnostics show every failing
"cover" as `content-type= image/jpeg`, no `content-encoding`, and a
completely standard, valid JPEG header (`FF D8 FF DB 00 43 00 03 ...` --
SOI + a textbook DQT segment). The download was never the problem.

**Root cause:** `coverBB`'s check `type(bb) ~= "table"` can never be
false on success. `RenderImage:renderImageFile` returns a `BlitBuffer` on
success -- and KOReader builds BlitBuffers via `ffi.metatype`, so their
Lua `type()` is `"cdata"`, never `"table"`. Every successful decode was
being thrown away and logged as a failure. This lines up exactly with
the log right before each failure: `RenderImage:scaleBlitBuffer: no
need` only fires *after* TurboJPEG has already produced a real
BlitBuffer -- it's KOReader's own decoder succeeding, immediately
followed by our code discarding the result.

The identical bug (`type(bb) == "table"`) existed in
`bookshelf_kobo_source.lua`'s `coverBB` too -- almost certainly where
this was copy-pasted from -- so Kobo virtual-library thumbnail covers
were likely silently broken the same way. Fixed both: the check is now
simply "did we get a non-nil result", matching how the rest of the
codebase (e.g. `bookshelf_image_source.lua`) already treats
`RenderImage:renderImageFile`'s return value.

This should be the actual fix for the "no covers anywhere" issue --
rounds 1/2 below were real bugs too (the BIM crash, and the diagnostic
logging that's what caught this), just not the reason covers were
blank.

---

# Fix round 2: crash spam + cover-decode diagnostics

Your log (`v2026.07`, PBInkPad3Pro) shows the hero-fix from
`BOOKORBIT_HERO_FIX.md` is in place and working as designed, but two
separate problems are still stopping covers from showing at all.

## Bug found and fixed: BIM crash-loop on every BookOrbit book

```
error in subprocess: plugins/coverbrowser.koplugin/bookinfomanager.lua:492:
attempt to index local 'file_attr' (a nil value)
...
in function 'extractInBackground'
...bookshelf_widget.lua:2272: in function '_fireBimExtraction'
```

**Cause:** `_kickOffMeta`'s `maybe_queue()` (in `bookshelf_widget.lua`)
queues *every* visible book's filepath into KOReader's generic
`bookinfomanager` (BIM) for metadata/cover extraction -- including
BookOrbit's synthetic `bookorbit://<id>` paths. BIM's subprocess assumes a
real file and calls `lfs.attributes()` on it; for a fake path that returns
`nil`, and `bookinfomanager.lua:492` immediately indexes the `nil` result,
crashing the subprocess. Since the attempt never produces a usable BIM row,
the same fake path gets queued again on the very next rebuild -- your log
shows this crash firing repeatedly (`kickoff`, `kickoff-interrupt`,
`orphan-retry`, `orphan-retry` again...) for the same handful of book ids,
burning through BIM's subprocess budget and needlessly competing with any
real BIM work (e.g. your comics library) for the same slot.

This is pure overhead/log noise, not the reason covers are blank --
BookOrbit covers were always meant to bypass BIM entirely and come from
`BOSource.coverBB()` directly (see `getBySource`'s `kind == "bookorbit"`
branch and `rebuildRecord`) -- but it's worth fixing on its own, since a
crash-looping subprocess is never harmless.

**Fix:** `maybe_queue()` now skips any `fp` for which
`BOSource.isBookOrbitPath(fp)` is true, before it ever reaches BIM.

## Not fixed yet, but now diagnosable: covers still don't decode

Every single cover in your log fails the same way:

```
[bookshelf][bookorbit] coverBB: downloaded file for book 27888 did not
decode as an image (ok= true ) -- removed cached file
```

`ok=true` means the HTTP GET succeeded (200, bytes landed on disk) --
`RenderImage:renderImageFile` is the thing failing, silently. The
100% failure rate (0/3, every page, every book id) points at something
systemic rather than a handful of missing covers -- e.g. the server
returning a non-image body (an HTML error page, a JSON error wrapped in a
200, or a placeholder response) for the thumbnail endpoint, or a proxy
still not honouring `Accept-Encoding: identity` despite that header being
sent (confirmed present in the request -- see `bookshelf_bookorbit.lua`).

I couldn't reproduce this without a live server to hit, so instead of
guessing further I made the failure path tell you what it actually
downloaded:

- `BookOrbit.downloadCatalogThumbnail` now also returns the response
  headers on success.
- `coverBB` now logs, right before deleting the bad file: the response's
  `Content-Type` / `Content-Encoding`, the file's byte size, and a hex +
  ASCII dump of its first 16 bytes.

Next time you hit this, the log line will look like:

```
coverBB: downloaded file for book 27888 did not decode as an image
(ok= true ) content-type= ... content-encoding= ... size= ... bytes
magic= 1F 8B 08 00 ... (........) -- removed cached file
```

What to look for:
- `magic= 1F 8B ...` → still gzip-compressed on disk; the proxy is
  ignoring `Accept-Encoding: identity`, needs a server/proxy-side fix.
- `magic= 3C 68 74 6D 6C` / ASCII starts with `<html` or `<!DOC` → the
  "thumbnail" is actually an HTML error page (likely a 200-wrapped error,
  auth issue, or wrong path on the server).
- `content-type=` something that isn't `image/...` → server isn't sending
  an image for this endpoint at all (worth checking directly with `curl`
  against `<server>/api/v1/koreader/plugin/catalog/books/<id>/thumbnail`
  using the same `X-Auth-User`/`X-Auth-Key` headers).
- `size= 0` → empty body, likely a server-side error being swallowed as
  200.
- A plausible JPEG/PNG magic number (`FF D8 FF` / `89 50 4E 47`) with a
  believable size but still a decode failure → worth a report upstream,
  since at that point the bytes look right and KOReader's own image
  decoder is the suspect.

## Testing

1. `luaparser`-based syntax check passed on all three touched files
   (`bookshelf_widget.lua`, `bookshelf_bookorbit.lua`,
   `bookshelf_bookorbit_source.lua`); not yet run inside KOReader.
2. Confirm the `bookinfomanager.lua:492` crash no longer appears in the log
   for `bookorbit://` books.
3. Open a BookOrbit chip with debug logging on, and check the new
   `content-type=/size=/magic=` fields in the `coverBB` log line to pin
   down the actual server-side cause of the decode failures.
