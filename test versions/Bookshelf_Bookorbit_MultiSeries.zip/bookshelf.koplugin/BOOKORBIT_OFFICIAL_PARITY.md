# BookOrbit: parity with official plugin 2.0.0

Compared `bookorbit.koplugin` 2.0.0 against this fork's BookOrbit client.

## What the official plugin does differently
1. **Capability detection.** `GET /koreader/plugin/version` -> `capabilities[]`; new wire
   features (here `catalogListsV2`) are only used once the server names them. Cached per
   server+user; only a definitive 4xx records "unsupported", transient errors stay unknown.
2. **Authors / Series (catalogListsV2).** Paged by `offset`+`size` (+`sort`, `filter`,
   `buckets` for the A-Z index). Each entry carries `previewBooks`; authors also carry
   `authorId` + `hasPhoto`.
3. **Author portraits.** `GET /koreader/plugin/catalog/authors/<id>/photo`, cached beside
   covers under an `a<id>_` prefix (author ids and book ids can collide).
4. **Libraries / Collections / Smart scopes.** One unparameterised request each; entries
   carry `previewBooks`, so tiles never need an extra per-entry book request.
5. **Image downloads** require an `image/*` Content-Type (a proxy login page is not cached).
6. **Manifest** requests always send `deviceId`.

## What this fork did before
Legacy `page`-based walks, tile covers fetched by a one-book request per tile (N+1), no
portraits, no capability check, manifest version probe without `deviceId`.

## Changes (lib/bookshelf_bookorbit.lua)
- `getServerCapabilities()`, `serverSupports()`, `listsV2()`, `resetCapabilities()`
  (reset on save/clear config).
- `downloadCatalogAuthorPhoto()`; shared `downloadImage()` with Content-Type check.
- `getLibraryVersion()` sends `deviceId`.

## Changes (lib/bookshelf_bookorbit_source.lua)
- Authors/Series walk uses `offset`+`size` (60) on V2 servers, `page` otherwise; mode is
  fixed per bucket. Libraries/collections/scopes unchanged (already parameterless).
- `tileCoverRecord()`: author tile = portrait if `hasPhoto`, else first `previewBooks`
  cover; other tiles use `previewBooks`. Falls back to the old sample-book fetch when an
  entry has neither (older servers).
- Cover pipeline keyed by `coverKey()` (`a` prefix for portraits) and `downloadCover()`.
- `GROUP_PREFIX` `group:` -> `group2:` so cached buckets without the new fields are
  dropped once.

## Deliberately not changed
- Given-name sort of the Authors root (fork feature; the official sorts server-side by name).
- The A-Z jump index (`buckets`) - Bookshelf's tile grid has no equivalent.
  (Server-side sort and filter ARE supported per chip now; see `BOOKORBIT_SORT_FILTER.md`.)
- Chip-editor section picker still loads page 1 only.
- Official dashboard/board, delivery variants, bulk download, sidecar/bookmark sync.

Not run on a device; `luac5.1 -p` passes on both files. Test: connect, open an Authors chip
(portraits where the server has them), a Series chip, Libraries; check no per-tile requests.
