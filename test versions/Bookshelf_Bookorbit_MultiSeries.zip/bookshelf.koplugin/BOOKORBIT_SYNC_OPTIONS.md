# BookOrbit sync options (parity with official plugin 2.0.0, Sync page)

Menu: Bookshelf settings > BookOrbit. Stored in the BookOrbit module's settings file.

| Option | Key | Default here | Official default |
|---|---|---|---|
| Auto-sync (pull on open, push on close and sleep) | `auto_sync` | on | off |
| Push while reading (every N page turns, after ~10 s idle; 0 = off) | `pages_before_update` | 0 (off) | 3 |
| Skip when offline (never wake Wi-Fi; close queues the push). Ignored, and greyed out, while Auto Wi-Fi is on | `skip_sync_when_offline` | off | off |
| Auto Wi-Fi (keep Wi-Fi on at home) and its three options (Disconnect Wi-Fi when book is opened, Push progress on sleep, Pull progress on wake): see `BOOKORBIT_AUTO_WIFI.md` | `auto_wifi`, `auto_wifi_off_in_book`, `auto_wifi_sync_on_sleep`, `auto_wifi_pull_on_wake` | off | n/a |
| BookOrbit is further ahead: Jump / Ask / Stay | `sync_forward` | Ask (Jump if the old "Jump to remote progress automatically" switch was on) | Ask |
| BookOrbit is further behind: Jump / Ask / Stay | `sync_backward` | Stay | Stay |

Defaults for auto-sync and push-while-reading differ on purpose so existing users of this fork see no
change until they opt in.

## Behaviour
- On open the pull compares places: identical place does nothing; otherwise the "ahead" or "behind" choice applies.
  (Before, any difference produced the notice, even when BookOrbit was behind.) Stay on an ahead place shows a short
  "Kept your place" notice.
- Push while reading and push on sleep only run after the place was compared with BookOrbit's on open, so a
  stale local place cannot overwrite a further one. (A book whose last place came from this same device now
  counts as compared; before, in that ordinary single-device case neither push ever started.)
- Push while reading never wakes Wi-Fi. Push on sleep: KOReader switches Wi-Fi off BEFORE it announces the sleep,
  so on Kobo and Kindle the plain "push if already online" check finds the device offline and does nothing.
  The "Push progress on sleep" option of Auto Wi-Fi is what makes the sleep push work (it turns Wi-Fi on
  again for the moment it needs).
- Pending-push retries after reconnecting respect Auto-sync.
- **Pull-before-push guard.** Before any progress push (push while reading, push on close, push on sleep, "Sync now"
  and the retries of queued pushes) the server's place is checked first. If ANOTHER device wrote a place this device
  has not looked at yet, the push is not sent, so a stale place can no longer overwrite a newer one:
  - Push while reading and "Sync now" (you are present): the same notice or "Go to page" prompt as on open is shown,
    following your forward/backward strategy. Dismissing counts as having looked at it, so pushes resume.
  - Push on close, push on sleep and queued retries (nobody is looking): the push is skipped. A skipped place is not
    queued, because it would be out of date; the newer place is offered the next time the book is opened.
  - Queued retries compare against the server place that was known when the push was queued; an old queue entry
    without that record is only blocked when the server place is further on.
  - Your "Stay" choice wins: if you set the forward (or backward) strategy to "stay", that place is never blocked.
  - If the check itself fails (server error, bad answer) the push goes out as before so progress is not lost; if the
    device is offline the push is queued as before. The check costs one extra request per push.
  - "Another device" uses the same test as pull-on-open (the install id, plus the model name). Devices that share an
    install id would not protect each other.
- **Pull on wake.** With "Pull progress on wake" on (an Auto Wi-Fi option, so Auto Wi-Fi is on too), waking the device with a book open checks BookOrbit with the same decision as
  the guard above and offers a newer place from another device (same prompt as on open). Details:
  BOOKORBIT_AUTO_WIFI.md. It uses a little battery on every wake (no minimum sleep time).

## Not included
Two-way highlights and bookmarks (`annotation_sync`) - a separate subsystem in the official plugin (annotations,
sidecar, lifecycle outbox); not ported.

Not run on a device. `luac5.1 -p` passes on main.lua, lib/bookshelf_bookorbit.lua, lib/bookshelf_settings.lua.
