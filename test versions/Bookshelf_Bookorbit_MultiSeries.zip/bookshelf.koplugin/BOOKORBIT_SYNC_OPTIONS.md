# BookOrbit sync options (parity with official plugin 2.0.0, Sync page)

Menu: Bookshelf settings > BookOrbit. Stored in the BookOrbit module's settings file.

| Option | Key | Default here | Official default |
|---|---|---|---|
| Auto-sync (pull on open, push on close and sleep) | `auto_sync` | on | off |
| Push while reading (every N page turns, after ~10 s idle; 0 = off) | `pages_before_update` | 0 (off) | 3 |
| Skip when offline (never wake Wi-Fi; close queues the push) | `skip_sync_when_offline` | off | off |
| BookOrbit is further ahead: Jump / Ask / Stay | `sync_forward` | Ask (Jump if the old "Jump to remote progress automatically" switch was on) | Ask |
| BookOrbit is further behind: Jump / Ask / Stay | `sync_backward` | Stay | Stay |

Defaults for auto-sync and push-while-reading differ on purpose so existing users of this fork see no
change until they opt in.

## Behaviour
- On open the pull compares places: identical place does nothing; otherwise the "ahead" or "behind" choice applies.
  (Before, any difference produced the notice, even when BookOrbit was behind.) Stay on an ahead place shows a short
  "Kept your place" notice.
- Push while reading and push on sleep only run when already online, and only after the place was compared with
  BookOrbit's on open, so a stale local place cannot overwrite a further one. Neither wakes Wi-Fi.
- Pending-push retries after reconnecting respect Auto-sync.

## Not included
Two-way highlights and bookmarks (`annotation_sync`) - a separate subsystem in the official plugin (annotations,
sidecar, lifecycle outbox); not ported.

Not run on a device. `luac5.1 -p` passes on main.lua, lib/bookshelf_bookorbit.lua, lib/bookshelf_settings.lua.
