# BookOrbit: hold the previous screen until the book list lands (5.5.5-bookorbit9)

Status: **not run on a device.** Checked off-device only (Lua suite `hold`, 329
checks, plus every older suite; the pre-flight, the hold helpers and the
page-ready callback are executed against fake UIManager / Screen / TabModel, the
two big widget functions `_rebuild` and `_swapShelvesInPlace` are checked as
source only).

## The problem

A BookOrbit page that was never fetched used to paint a blank shelf first (the
"pending" page), then, when the book list landed, the title cards, then the
covers. The blank phase is the one this feature hides.

## What it does

While the book list of an uncached page is being fetched (still in a forked
worker, so the UI stays responsive), the screen **keeps the previous content,
untouched**. When the list lands, one normal rebuild paints the title cards
straight away (book name and author), then covers fill in as before.

Applies to BookOrbit flat catalog pages in **cover grid view** only, on both
paths: a chip switch / full rebuild (`_rebuild`, through a pre-flight at its very
first statement) and a page turn (`_swapShelvesInPlace`).

## Behaviour worth knowing

- A tapped or swiped chip keeps its black pending ring while the old screen stays.
- A page turn gives no cue while held; the footer page label and chevrons still
  show the old page.
- A tap during the hold acts on the old visible books. The last chip or page you
  ask for wins; an older request landing later is ignored.
- Cached pages and chips are not affected: instant, as before.
- **Never held (today's blank rows, or the normal paint):** the first paint of
  the shelf (no previous screen), list view, spine view, any layout change
  (rotation, expand/collapse, night mode, hero mode, columns, cover aspect),
  retries and the forced paint of a safety release, a pending go-home or drill
  restore, a chip that is no longer active, any non-BookOrbit chip.
- **Failure:** a failed fetch (including the 30 s fetch deadline) is never held;
  the normal "Couldn't load <chip> · Pull down to try again" placeholder shows.
- **Safety release:** if no page-ready callback arrives within 35 s the widget
  forces one normal paint (blank rows or the failure state). A late landing then
  repaints it with the list.
- Closing the shelf cancels the timer and drops the hold state.
- Each held request costs one redundant partial repaint of unchanged pixels (the
  caller's `setDirty`), and persisted nav state and preload scheduling happen on
  landing instead of at request time.
- A setting that changes the look without touching a layout-stamp field (a font
  scale, the chip-bar height) is not detected; if its rebuild hits an uncached
  page the change appears when the list lands.

## Constants and files

In `lib/bookshelf_widget.lua`:

- `BO_HOLD_PREVIOUS = true`. Set it to `false` to restore the blank-row
  behaviour exactly. No setting, no user-visible string.
- `BO_HOLD_TIMEOUT_S = 35`.

Pure decision module: `lib/bookshelf_hold_gate.lua` (`stamp`, `sameLayout`,
`decide`, `eligible`). Tests: `tools/bo_tests/test_bo_hold.lua`.

## Debug log lines

- `[bookshelf perf] bo hold: begin key=<k> via=swap|rebuild chip=<chip>`
- `[bookshelf perf] bo hold: key=<k> held_ms=<n> reason=landed ok=<true|false>`
- `[bookshelf perf] bo hold: key=<k> held_ms=<n> reason=timeout`
- `[bookshelf perf] bo hold: rebuild paints, reason=<why>` and
  `... swap paints blank rows, reason=<why>` (why a hold did not happen)
- Existing: `[bookshelf perf] bo page: key=... ms=... result=...` and
  `[bookshelf perf] bo page: ready key=... ok=... rebuild+dirty=...ms`

## Known limits

- Everything is unverified on a device (fork, rapidjson, e-ink refresh, the
  pre-flight ordering).
- A hold can last the full 30 s fetch deadline before the failure placeholder.
- No ghost slots and no loading cue for page turns (dropped on purpose).

## On-device checklist

1. Tap a BookOrbit chip you have never opened (Wi-Fi on): the old screen stays
   (the tapped chip shows its pending ring), nothing freezes, then the new
   chip's books appear as title cards with names, then covers fill in. Note how
   long the old screen stayed.
2. Turn onto an uncached page: the old page stays until the list lands, then
   title cards, then covers. Note the delay.
3. Tap or swipe while held: no crash; the last chip or page you ask for wins; a
   tap on a visible old book acts on that old book.
4. Slow or far server: no freeze; after about 30 s the failure placeholder
   appears; pull-down retries.
5. Wi-Fi off, or close the shelf mid-fetch: no stuck stale screen, no leftover
   processes, no error.
6. Rotate, expand/collapse, night mode, switch view mode during or right after
   a hold: the screen repaints normally (blank rows are acceptable there).
7. First open of the plugin on a never-cached chip: paints once (blank rows are
   acceptable), then books.
8. Cached pages and chips: instant, as before.
9. If anything looks wrong, send the log lines listed above.
