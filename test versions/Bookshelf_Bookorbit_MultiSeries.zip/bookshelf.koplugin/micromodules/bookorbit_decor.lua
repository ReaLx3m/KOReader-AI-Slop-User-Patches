--[[
BookOrbit micro-modules, "Decor" category (file returns a LIST of specs; see
README.md "One file, many modules"). Each is a widget of the BookOrbit plugin's
dashboard board, drawn by lib/bookshelf_bo_module; the pictures come from the
vendored lib/bookorbit_board/decor.lua and animal_sprites.lua.

The nine reading companions, the analog clock and the moon are pure
decoration: no tappable part, so none sets `taps`. The companions react to the
reader's streak and today's minutes, which come from the server dashboard, so
they carry `server = true` (a hint until BookOrbit is set up). The clock and the
moon need nothing and work offline.

The data-driven ones follow: Pages turned and Glyph of the day read only this
device (offline); Tree rings, Next badge and Gathering dust need the dashboard
(`server = true`). Gathering dust (Open / remove the file / next book) is
tappable. All are also under the New chip, as in BookOrbit.

BookOrbit's "Chapter line" widget is deliberately NOT ported: it needs a saved
chapter map of the book, which only the BookOrbit plugin writes.
]]
local _ = require("lib/bookshelf_i18n").gettext
local Bo = require("lib/bookshelf_bo_module")

-- One row per companion; every one is the same widget type ("buddy") with a
-- different `animal` prop, so the nine specs are built from this table and
-- cannot drift apart. The cat is the default (no prop), as in BookOrbit.
-- Titles and summaries are literal _() calls so the string extractor sees them.
local BUDDIES = {
    { key = "bookorbit_buddy_cat", title = _("Reading buddy"),
      summary = _("BookOrbit. A cat that keeps you company. Needs a BookOrbit server.") },
    { key = "bookorbit_buddy_dog", animal = "dog", title = _("Reading dog"),
      summary = _("BookOrbit. A floppy-eared friend for every chapter. Needs a BookOrbit server.") },
    { key = "bookorbit_buddy_rabbit", animal = "rabbit", title = _("Reading rabbit"),
      summary = _("BookOrbit. A quiet companion with a curious nose. Needs a BookOrbit server.") },
    { key = "bookorbit_buddy_owl", animal = "owl", title = _("Reading owl"),
      summary = _("BookOrbit. A feathered friend for one more page. Needs a BookOrbit server.") },
    { key = "bookorbit_buddy_penguin", animal = "penguin", title = _("Reading penguin"),
      summary = _("BookOrbit. A little bookworm in a feathered coat. Needs a BookOrbit server.") },
    { key = "bookorbit_buddy_robot", animal = "robot", title = _("Reading robot"),
      summary = _("BookOrbit. Recharges with a good book. Needs a BookOrbit server.") },
    { key = "bookorbit_buddy_vampire", animal = "vampire", title = _("Reading vampire"),
      summary = _("BookOrbit. A tiny night owl with a cape and fangs. Needs a BookOrbit server.") },
    { key = "bookorbit_buddy_dragon", animal = "dragon", title = _("Reading dragon"),
      summary = _("BookOrbit. A little dragon guarding a hoard of stories. Needs a BookOrbit server.") },
    { key = "bookorbit_buddy_ghost", animal = "ghost", title = _("Reading ghost"),
      summary = _("BookOrbit. A friendly spirit between the pages. Needs a BookOrbit server.") },
}

local specs = {}
for _i, b in ipairs(BUDDIES) do
    table.insert(specs, {
        key = b.key, type = "buddy", title = b.title,
        summary = b.summary,
        category = "bookorbit:decor", is_new = true, sizes = { "L", "M", "S" },
        props = b.animal and { animal = b.animal } or nil,
        server = true,
    })
end

table.insert(specs, {
    key = "bookorbit_analog", type = "analog", title = _("Analog clock"),
    summary = _("BookOrbit. A clock face, each minute. Works offline."),
    category = "bookorbit:decor", is_new = true, sizes = { "S", "M" }, chrome = "ink",
    wants_minute_tick = true,
})
table.insert(specs, {
    key = "bookorbit_moon", type = "moon", title = _("Moon phase"),
    summary = _("BookOrbit. Tonight's moon. Works offline."),
    category = "bookorbit:decor", is_new = true, sizes = { "S", "M" }, chrome = "ink",
})

table.insert(specs, {
    key = "bookorbit_odometer", type = "odometer", title = _("Pages turned"),
    summary = _("BookOrbit. Every page, on a counter. Works offline."),
    category = "bookorbit:decor", is_new = true, sizes = { "M", "S" },
})
table.insert(specs, {
    key = "bookorbit_glyph", type = "glyph", title = _("Glyph of the day"),
    summary = _("BookOrbit. One letter from your fonts. Works offline."),
    category = "bookorbit:decor", is_new = true, sizes = { "S", "M", "L" },
})
table.insert(specs, {
    key = "bookorbit_rings", type = "rings", title = _("Tree rings"),
    summary = _("BookOrbit. A ring for every month you read. Needs a BookOrbit server."),
    category = "bookorbit:decor", is_new = true, sizes = { "L", "M" }, server = true,
})
table.insert(specs, {
    key = "bookorbit_badge", type = "badge", title = _("Next badge"),
    summary = _("BookOrbit. The badge you are closest to earning. Needs a BookOrbit server."),
    category = "bookorbit:decor", is_new = true, sizes = { "M", "L", "S" }, server = true,
})
table.insert(specs, {
    key = "bookorbit_dust", type = "dust", title = _("Gathering dust"),
    summary = _("BookOrbit. Books you downloaded and never opened. Needs a BookOrbit server."),
    category = "bookorbit:decor", is_new = true, sizes = { "M", "L", "S" }, server = true,
    taps = true,
})

return Bo.specs(specs)
