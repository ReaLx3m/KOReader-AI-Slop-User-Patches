--[[
BookOrbit micro-modules, "Library" category (file returns a LIST of specs; see
README.md "One file, many modules"): six shelves of covers and six launcher
tiles. Shelves and counts come from the BookOrbit server (cached, fetched in
the background by lib/bookshelf_bo_data); every one shows a hint until
BookOrbit is set up. Taps are handled by lib/bookshelf_bo_actions: a cover
opens its book's preview, the header ("See all") and the launcher tiles open
the matching list in the BookOrbit catalog.

"Shelf from your library" is the one configurable module: add it several times,
each with its own library / collection / SmartScope / author / series (chosen
when added, changed from the module's settings; lib/bookshelf_bo_shelf_picker).
Its key is bookorbit_shelf_library (BookOrbit's own board reuses the "random"
shelf type for it, which here is the Discover shelf's key).
Pick back up and Want to read are also under the New chip.
]]
local _ = require("lib/bookshelf_i18n").gettext
local Bo = require("lib/bookshelf_bo_module")

local function shelfFromConfig(config)
    local shelf = config:get("shelf")
    if type(shelf) == "table" and shelf.source then
        return { source = shelf.source, params = shelf.params, title = shelf.title }
    end
    return nil
end

return Bo.specs{
    { key = "bookorbit_shelf_pick_back_up", type = "shelf", title = _("Pick back up"),
      summary = _("BookOrbit. Books you put down a while ago. Needs a BookOrbit server."),
      category = "bookorbit:library", is_new = true, sizes = { "XL", "L" },
      props = { source = "pick-back-up" }, server = true, taps = true },
    { key = "bookorbit_shelf_want_to_read", type = "shelf", title = _("Want to read"),
      summary = _("BookOrbit. Books waiting for their turn. Needs a BookOrbit server."),
      category = "bookorbit:library", is_new = true, sizes = { "L", "XL" },
      props = { source = "want-to-read" }, server = true, taps = true },
    { key = "bookorbit_shelf_up_next_in_series", type = "shelf", title = _("Up next in series"),
      summary = _("BookOrbit. The next book in each series you read. Needs a BookOrbit server."),
      category = "bookorbit:library", sizes = { "L", "XL" },
      props = { source = "up-next-in-series" }, server = true, taps = true },
    { key = "bookorbit_shelf_random", type = "shelf", title = _("Discover"),
      summary = _("BookOrbit. A shuffle of your library. Needs a BookOrbit server."),
      category = "bookorbit:library", sizes = { "XL", "L" },
      props = { source = "random", shuffle = true }, server = true, taps = true },
    { key = "bookorbit_shelf_recently_added", type = "shelf", title = _("Recently added"),
      summary = _("BookOrbit. The newest books in your library. Needs a BookOrbit server."),
      category = "bookorbit:library", sizes = { "XL", "L" },
      props = { source = "recently-added" }, server = true, taps = true },
    { key = "bookorbit_shelf_library", type = "shelf", title = _("Shelf from your library"),
      summary = _("BookOrbit. One library, collection, SmartScope, author or series. Needs a BookOrbit server."),
      category = "bookorbit:library", sizes = { "XL", "L" },
      props = { source = "random" }, props_from = shelfFromConfig,
      on_add = function(_host_ctx, done)
          require("lib/bookshelf_bo_shelf_picker").pick(function(shelf)
              if shelf then done({ shelf = shelf }) else done(nil) end
          end)
      end,
      show_settings = function(ctx)
          if not (ctx and ctx.config) then return end
          require("lib/bookshelf_bo_shelf_picker").pick(function(shelf)
              if shelf then ctx.config:set("shelf", shelf) end
          end)
      end,
      server = true, taps = true },
    { key = "bookorbit_link_library", type = "link", title = _("Library"),
      summary = _("BookOrbit. All your books. Needs a BookOrbit server."),
      category = "bookorbit:library", sizes = { "S" }, props = { link = "library" },
      server = true, taps = true },
    { key = "bookorbit_link_series", type = "link", title = _("Series"),
      summary = _("BookOrbit. Every series. Needs a BookOrbit server."),
      category = "bookorbit:library", sizes = { "S" }, props = { link = "series" },
      server = true, taps = true },
    { key = "bookorbit_link_authors", type = "link", title = _("Authors"),
      summary = _("BookOrbit. Every author. Needs a BookOrbit server."),
      category = "bookorbit:library", sizes = { "S" }, props = { link = "authors" },
      server = true, taps = true },
    { key = "bookorbit_link_collections", type = "link", title = _("Collections"),
      summary = _("BookOrbit. Your collections. Needs a BookOrbit server."),
      category = "bookorbit:library", sizes = { "S" }, props = { link = "collections" },
      server = true, taps = true },
    { key = "bookorbit_link_scopes", type = "link", title = _("SmartScopes"),
      summary = _("BookOrbit. Your saved SmartScopes. Needs a BookOrbit server."),
      category = "bookorbit:library", sizes = { "S" }, props = { link = "scopes" },
      server = true, taps = true },
    { key = "bookorbit_link_search", type = "link", title = _("Search"),
      summary = _("BookOrbit. Search your library. Needs a BookOrbit server."),
      category = "bookorbit:library", sizes = { "S" }, props = { link = "search" },
      server = true, taps = true },
}
