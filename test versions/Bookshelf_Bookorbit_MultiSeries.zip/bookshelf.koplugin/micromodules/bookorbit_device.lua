--[[
BookOrbit micro-modules, "Device" category. Returns a LIST of specs (see
README.md "One file, many modules"); each is built by lib/bookshelf_bo_module
from a widget of the BookOrbit plugin's dashboard board.

Clock needs nothing. Light and Quick settings act on this device in place
(frontlight steps, Wi-Fi, night mode; Rotate and the brightness dialog close the
menu first). On device lists the BookOrbit books downloaded here and works
offline. Sync status shows the last sync and has Sync now (Connect when
offline). Light and Quick settings are also under the New chip (as in BookOrbit).
]]
local _ = require("lib/bookshelf_i18n").gettext
local Bo = require("lib/bookshelf_bo_module")

return Bo.specs{
    { key = "bookorbit_clock", type = "clock", title = _("Clock"),
      summary = _("BookOrbit. Device clock. Works offline."),
      category = "bookorbit:device", sizes = { "S", "M" }, chrome = "ink",
      wants_minute_tick = true },
    { key = "bookorbit_light", type = "light", title = _("Light"),
      summary = _("BookOrbit. Brightness and warmth steppers. Works offline."),
      category = "bookorbit:device", is_new = true, sizes = { "M", "S" }, taps = true },
    { key = "bookorbit_toggles", type = "toggles", title = _("Quick settings"),
      summary = _("BookOrbit. Wi-Fi, light, night mode, rotate, sync. Works offline."),
      category = "bookorbit:device", is_new = true, sizes = { "M", "S" }, taps = true },
    { key = "bookorbit_link_device", type = "link", title = _("On device"),
      summary = _("BookOrbit. Books on this device, and space left. Works offline."),
      category = "bookorbit:device", sizes = { "S" }, props = { link = "device" }, taps = true },
    { key = "bookorbit_sync", type = "sync", title = _("Sync status"),
      summary = _("BookOrbit. Last sync, with Sync now. Needs a BookOrbit server."),
      category = "bookorbit:device", sizes = { "S" }, server = true, taps = true },
}
