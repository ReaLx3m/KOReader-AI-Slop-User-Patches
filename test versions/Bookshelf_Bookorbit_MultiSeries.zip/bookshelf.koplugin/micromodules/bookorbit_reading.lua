--[[
BookOrbit micro-modules, "Reading" category (file returns a LIST of specs; see
README.md "One file, many modules"). Each is a widget of the BookOrbit plugin's
dashboard board, drawn by lib/bookshelf_bo_module from the data layer
(lib/bookshelf_bo_data). `server = true` = draws server data, so it shows a
hint until BookOrbit is set up; `taps = true` = it has tappable parts (Resume,
a book row ...) handled by lib/bookshelf_bo_actions.
Forecast, Word of the day and A year ago are also under the New chip.
]]
local _ = require("lib/bookshelf_i18n").gettext
local Bo = require("lib/bookshelf_bo_module")

return Bo.specs{
    { key = "bookorbit_hero", type = "hero", title = _("Continue reading"),
      summary = _("BookOrbit. Your current book, with Resume. Needs a BookOrbit server."),
      category = "bookorbit:reading", sizes = { "W", "M", "L" }, chrome = "ink",
      server = true, taps = true },
    { key = "bookorbit_also", type = "also", title = _("Also reading"),
      summary = _("BookOrbit. The rest of your pile. Needs a BookOrbit server."),
      category = "bookorbit:reading", sizes = { "L", "M" },
      server = true, taps = true },
    { key = "bookorbit_highlight", type = "highlight", title = _("Highlight of the day"),
      summary = _("BookOrbit. One of your highlights, daily. Needs a BookOrbit server."),
      category = "bookorbit:reading", sizes = { "L", "M", "W" }, chrome = "fill",
      server = true, taps = true },
    { key = "bookorbit_forecast", type = "forecast", title = _("Finish forecast"),
      summary = _("BookOrbit. When your book ends at your pace. Needs a BookOrbit server."),
      category = "bookorbit:reading", is_new = true, sizes = { "M", "S", "L" },
      server = true, taps = true },
    { key = "bookorbit_word", type = "word", title = _("Word of the day"),
      summary = _("BookOrbit. A word you looked up, in context. Works offline."),
      category = "bookorbit:reading", is_new = true, sizes = { "M", "L" },
      taps = true },
    { key = "bookorbit_yearago", type = "yearago", title = _("A year ago"),
      summary = _("BookOrbit. What you were reading last year. Needs a BookOrbit server."),
      category = "bookorbit:reading", is_new = true, sizes = { "M", "L" },
      server = true, taps = true },
}
