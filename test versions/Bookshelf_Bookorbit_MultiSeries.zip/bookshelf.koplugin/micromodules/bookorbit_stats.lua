--[[
BookOrbit micro-modules, "Stats" category (file returns a LIST of specs; see
README.md "One file, many modules"). Minutes, streaks and calendars come from
KOReader's own statistics database (read off the draw path by
lib/bookshelf_bo_data); goal and year figures from the BookOrbit dashboard.
Replaces the Batch 1 placeholder. Keys are permanent.
]]
local _ = require("lib/bookshelf_i18n").gettext
local Bo = require("lib/bookshelf_bo_module")

return Bo.specs{
    { key = "bookorbit_streak", type = "streak", title = _("Streak"),
      summary = _("BookOrbit. Days in a row, and your best. Needs a BookOrbit server."),
      category = "bookorbit:stats", sizes = { "S", "M" }, server = true },
    { key = "bookorbit_week", type = "week", title = _("This week"),
      summary = _("BookOrbit. Minutes read each day. Needs a BookOrbit server."),
      category = "bookorbit:stats", sizes = { "M", "S" }, server = true },
    { key = "bookorbit_today", type = "today", title = _("Today"),
      summary = _("BookOrbit. Minutes read today. Needs a BookOrbit server."),
      category = "bookorbit:stats", sizes = { "S" }, server = true },
    { key = "bookorbit_calendar", type = "calendar", title = _("Reading calendar"),
      summary = _("BookOrbit. This month, one square a day. Needs a BookOrbit server."),
      category = "bookorbit:stats", sizes = { "M", "L" }, server = true },
    { key = "bookorbit_heatmap", type = "heatmap", title = _("Year in reading"),
      summary = _("BookOrbit. One square a day for a whole year. Needs a BookOrbit server."),
      category = "bookorbit:stats", is_new = true, sizes = { "XL", "L" }, server = true },
    { key = "bookorbit_goalpace", type = "goalpace", title = _("Goal pace"),
      summary = _("BookOrbit. Ahead or behind on your yearly goal. Needs a BookOrbit server."),
      category = "bookorbit:stats", is_new = true, sizes = { "M", "S" },
      server = true, taps = true },
    { key = "bookorbit_records", type = "records", title = _("Reading records"),
      summary = _("BookOrbit. Your longest and average sessions. Works offline."),
      category = "bookorbit:stats", is_new = true, sizes = { "L", "M" } },
    { key = "bookorbit_hours", type = "hours", title = _("When you read"),
      summary = _("BookOrbit. Your reading by hour of the day. Works offline."),
      category = "bookorbit:stats", is_new = true, sizes = { "M", "L" } },
    { key = "bookorbit_shelf_finished", type = "shelf", title = _("Finished this year"),
      summary = _("BookOrbit. Covers of the books you finished. Needs a BookOrbit server."),
      category = "bookorbit:stats", is_new = true, sizes = { "L", "XL" },
      props = { source = "finished" }, server = true, taps = true },
}
