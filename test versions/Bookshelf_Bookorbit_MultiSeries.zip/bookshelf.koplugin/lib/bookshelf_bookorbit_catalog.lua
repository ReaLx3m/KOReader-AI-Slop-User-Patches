-- bookshelf_bookorbit_catalog.lua
-- On-device catalog browser for a BookOrbit server. Talks JSON REST
-- (see bookshelf_bookorbit.lua's catalogRoot/catalogSection/catalogBooks/
-- catalogBook/downloadCatalogFile) -- BookOrbit does not speak OPDS, despite
-- what its public marketing copy implies. Built on KOReader's stock Menu
-- widget since this is a plain hierarchical list-with-paging UI.

local ConfirmBox   = require("ui/widget/confirmbox")
local InfoMessage  = require("ui/widget/infomessage")
local Menu         = require("ui/widget/menu")
local UIManager    = require("ui/uimanager")
local Device       = require("device")
local NetworkMgr   = require("ui/network/manager")
local Screen       = Device.screen
local _            = require("lib/bookshelf_i18n").gettext
local T            = require("ffi/util").template
local BookOrbit    = require("lib/bookshelf_bookorbit")

local Catalog = {}

local PAGE_SIZE = 30

local function notify(text, timeout)
    UIManager:show(InfoMessage:new{ text = text, timeout = timeout or 3 })
end

-- Every view in this browser is a live network call to the BookOrbit server,
-- so replace the old bare UIManager:nextTick(fn) with this: auto-connect
-- Wi-Fi first (turns it on / reconnects a saved network, prompting only if
-- none is saved) via KOReader's own runWhenOnline, THEN show the progress
-- toast and run fn -- instead of failing immediately with "No network
-- connection." while the radio is simply off. Mirrors the pattern the
-- weather/trivia/etc. micromodules already use elsewhere in this plugin.
local function runOnline(msg, fn)
    NetworkMgr:runWhenOnline(function()
        if msg then notify(msg, 1) end
        UIManager:scheduleIn(0.05, fn)
    end)
end

local function errorText(err)
    if err == 401 or err == 403 then
        return _("BookOrbit login failed. Check your username/password in Bookshelf menu → BookOrbit.")
    elseif err == "offline" then
        return _("No network connection.")
    elseif err == "not_configured" then
        return _("Set up your BookOrbit server first (Bookshelf menu → BookOrbit → Connect).")
    elseif type(err) == "number" then
        return T(_("BookOrbit server error (HTTP %1)."), err)
    end
    return T(_("Couldn't reach the BookOrbit server (%1)."), tostring(err))
end

local function firstAuthor(book)
    return book.authors and book.authors[1] or nil
end

local function formatSeries(book)
    if not book.seriesName then return nil end
    if book.seriesIndex then
        return book.seriesName .. " #" .. tostring(book.seriesIndex)
    end
    return book.seriesName
end

local function bookSubtitle(book)
    local parts = {}
    local author = firstAuthor(book)
    if author then parts[#parts + 1] = author end
    local series = formatSeries(book)
    if series then parts[#parts + 1] = series end
    if book.formats and book.formats[1] then
        parts[#parts + 1] = table.concat(book.formats, ", ")
    end
    return #parts > 0 and table.concat(parts, " · ") or nil
end

-- ---------------------------------------------------------------------
-- Download
-- ---------------------------------------------------------------------

-- Delegates to BookOrbit.downloadDir(), which prefers the user's chosen
-- download folder (Bookshelf menu -> BookOrbit -> Download folder) and
-- falls back to the same home_dir/full-data-dir auto-detection this used
-- to do locally -- kept as a thin wrapper so callers below don't change.
local function destDir()
    return BookOrbit.downloadDir()
end

local function uniquePath(dir, base, ext)
    local path = dir .. "/" .. base .. "." .. ext
    local lfs_ok, lfs = pcall(require, "libs/libkoreader-lfs")
    if not lfs_ok then return path end
    local n = 1
    while lfs.attributes(path) do
        path = dir .. "/" .. base .. " (" .. n .. ")." .. ext
        n = n + 1
    end
    return path
end

local function doDownload(file, title, book)
    local dir = BookOrbit.downloadDestDir(destDir(), book)
    local base = BookOrbit.buildFilenameBase(book, title)
    local path = uniquePath(dir, base, file.format or "epub")
    runOnline(_("Downloading…"), function()
        local ok, err = BookOrbit.downloadCatalogFile(file.id, path)
        if ok then
            notify(_("Saved to ") .. path, 4)
        else
            notify(_("Download failed: ") .. errorText(err), 4)
        end
    end)
end

--- Fetch a book's file list and either download the single/primary file or
-- let the user choose among several.
local function openBook(book)
    runOnline(_("Loading…"), function()
        local detail, err = BookOrbit.catalogBook(book.id)
        if not detail then
            notify(errorText(err), 4)
            return
        end
        local files = detail.files or {}
        if #files == 0 then
            notify(_("No downloadable file found for this book."), 3)
            return
        end
        local title = detail.title or book.title or _("this book")
        if #files == 1 then
            UIManager:show(ConfirmBox:new{
                text = T(_("Download \"%1\" from BookOrbit?"), title),
                ok_text = _("Download"),
                ok_callback = function() doDownload(files[1], title, detail) end,
            })
            return
        end
        local item_table = {}
        for _, file in ipairs(files) do
            item_table[#item_table + 1] = {
                text = (file.format or "?"):upper() .. (file.role == "primary" and (" (" .. _("primary") .. ")") or ""),
                callback = function() doDownload(file, title, detail) end,
            }
        end
        local menu
        menu = Menu:new{
            title = T(_("Choose a file for \"%1\""), title),
            item_table = item_table,
            is_borderless = true,
            is_popout = false,
            width = Screen:getWidth(),
            height = math.floor(Screen:getHeight() * 0.6),
            onMenuChoice = function(_self, item)
                UIManager:close(menu)
                item.callback()
            end,
        }
        UIManager:show(menu)
    end)
end

-- ---------------------------------------------------------------------
-- Views
-- ---------------------------------------------------------------------

local showBooks, showSection, showRoot

--- Books list: params drives the /koreader/plugin/catalog/books query.
showBooks = function(params, title, page)
    page = page or 1
    runOnline(_("Loading books…"), function()
        local query = {}
        for k, v in pairs(params or {}) do query[k] = v end
        query.page = page
        query.size = PAGE_SIZE
        query.sort = query.sort or "title"

        local body, err = BookOrbit.catalogBooks(query)
        if not body then
            notify(errorText(err), 4)
            return
        end

        local items = {}
        if page > 1 then
            items[#items + 1] = {
                text = _("← Previous page"),
                callback = function() showBooks(params, title, page - 1) end,
            }
        end
        for _, book in ipairs(body.items or {}) do
            items[#items + 1] = {
                text = book.title or _("Untitled"),
                mandatory = bookSubtitle(book),
                callback = function() openBook(book) end,
            }
        end
        if body.hasNext then
            items[#items + 1] = {
                text = _("Next page →"),
                callback = function() showBooks(params, title, page + 1) end,
            }
        end
        if #items == 0 then
            items[#items + 1] = { text = _("No books here yet."), enabled = false }
        end

        local menu
        menu = Menu:new{
            title      = title or _("Books"),
            item_table = items,
            is_borderless = true,
            is_popout  = false,
            width      = Screen:getWidth(),
            height     = Screen:getHeight(),
        }
        UIManager:show(menu)
    end)
end

--- Params to pass to catalogBooks() when drilling into one entry of a
-- section list (libraries/collections/smart-scopes/authors/series).
local function paramsForEntry(section, entry)
    local params = { sort = "title" }
    if section == "libraries" then
        params.libraryId = entry.id
    elseif section == "collections" then
        params.collectionId = entry.id
    elseif section == "smart-scopes" then
        params.smartScopeId = entry.id
    elseif section == "authors" then
        params.author = entry.id
    elseif section == "series" then
        if entry.seriesId then params.seriesId = entry.seriesId else params.series = entry.id end
        params.sort = "series"
    end
    return params
end

--- Section list: e.g. "libraries", "collections", "authors", "series".
showSection = function(section, title, page)
    page = page or 1
    runOnline(_("Loading…"), function()
        local body, err = BookOrbit.catalogSection(section, { page = page })
        if not body then
            notify(errorText(err), 4)
            return
        end
        local items = {}
        if page > 1 then
            items[#items + 1] = {
                text = _("← Previous page"),
                callback = function() showSection(section, title, page - 1) end,
            }
        end
        for _, entry in ipairs(body.items or {}) do
            items[#items + 1] = {
                text = entry.title or _("Untitled"),
                mandatory = entry.count and tostring(entry.count) or nil,
                callback = function()
                    showBooks(paramsForEntry(section, entry), entry.title)
                end,
            }
        end
        if body.hasNext then
            items[#items + 1] = {
                text = _("Next page →"),
                callback = function() showSection(section, title, page + 1) end,
            }
        end
        if #items == 0 then
            items[#items + 1] = { text = _("Nothing here yet."), enabled = false }
        end

        local menu
        menu = Menu:new{
            title      = title or _("BookOrbit"),
            item_table = items,
            is_borderless = true,
            is_popout  = false,
            width      = Screen:getWidth(),
            height     = Screen:getHeight(),
        }
        UIManager:show(menu)
    end)
end

--- Root: whatever sections the server advertises.
showRoot = function()
    runOnline(_("Loading catalog…"), function()
        local body, err = BookOrbit.catalogRoot()
        if not body then
            notify(errorText(err), 4)
            return
        end
        local items = {}
        for _, section in ipairs(body.sections or {}) do
            if section.section == "search" then
                -- no dedicated search UI here yet; skip.
            elseif section.section == "recent" then
                items[#items + 1] = {
                    text = section.title or _("Recently added"),
                    callback = function() showBooks({ sort = "recently_added" }, section.title) end,
                }
            elseif section.section == "continue-reading" then
                items[#items + 1] = {
                    text = section.title or _("Continue reading"),
                    callback = function()
                        showBooks({ sort = "recently_read", readStatus = "reading" }, section.title)
                    end,
                }
            elseif section.section == "all-books" then
                items[#items + 1] = {
                    text = section.title or _("All books"),
                    callback = function() showBooks({ sort = "title" }, section.title) end,
                }
            else
                items[#items + 1] = {
                    text = (section.title or section.section) .. "  ▸",
                    callback = function() showSection(section.section, section.title) end,
                }
            end
        end
        if #items == 0 then
            items[#items + 1] = { text = _("The server returned an empty catalog."), enabled = false }
        end

        local menu
        menu = Menu:new{
            title      = _("BookOrbit catalog"),
            item_table = items,
            is_borderless = true,
            is_popout  = false,
            width      = Screen:getWidth(),
            height     = Screen:getHeight(),
        }
        UIManager:show(menu)
    end)
end

--- Entry point, called from Bookshelf menu → BookOrbit → Browse catalog.
function Catalog.show()
    if not BookOrbit.isConfigured() then
        notify(_("Set up your BookOrbit server first (Bookshelf menu → BookOrbit → Connect)."))
        return
    end
    showRoot()
end

return Catalog
