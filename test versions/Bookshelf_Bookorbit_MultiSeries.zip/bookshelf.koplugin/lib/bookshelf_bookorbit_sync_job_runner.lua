--[[--
Thin KOReader-aware adapter for bookshelf_bookorbit_sync_coordinator.

The coordinator itself has no idea what Trapper or a coroutine is -- it
just calls job.run(done, job) and expects done() to be called once (see
bookshelf_bookorbit_sync_coordinator.lua). Every BookOrbit sync call in
this plugin is a plain *blocking* socket request though, so it still needs
the same Trapper:wrap protection the rest of the BookOrbit integration
uses (main.lua's push-on-close and pull-on-open hooks, both of which cite
this exact reasoning): without it, a slow/unresponsive server would sit
directly in the UI thread with no way for the user to back out.

SyncJobRunner.prepare(job) takes a job whose `run` is a plain synchronous
function -- run(job) with no `done` callback, doing its network call and
returning -- and turns it into the async, Trapper-wrapped shape the
coordinator expects. Call this once per job before handing it to
coordinator:submit().
]]

local logger = require("logger")

local SyncJobRunner = {}

--- Wrap job.run (a plain, synchronous, no-callback function) so it runs
-- inside Trapper:wrap and reports completion back to the coordinator via
-- done(). Mutates and returns job.
function SyncJobRunner.prepare(job)
    local original_run = job.run

    job.async = true
    job.run = function(done, submitted_job)
        local ok_t, Trapper = pcall(require, "ui/trapper")
        local function guarded()
            local ok, err = xpcall(function()
                original_run(submitted_job)
            end, debug.traceback)
            if not ok then
                logger.err("Bookshelf: BookOrbit sync job failed:", err)
            end
            done()
        end
        if ok_t and Trapper and Trapper.wrap then
            Trapper:wrap(guarded)
        else
            -- No Trapper available (shouldn't happen inside KOReader, but
            -- this module is also require()able standalone) -- run inline
            -- rather than silently dropping the job.
            guarded()
        end
        return true
    end

    return job
end

return SyncJobRunner
