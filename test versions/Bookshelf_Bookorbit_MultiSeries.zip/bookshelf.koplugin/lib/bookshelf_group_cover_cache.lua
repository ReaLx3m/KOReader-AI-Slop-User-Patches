-- bookshelf_group_cover_cache.lua
-- LRU of decoded preview-cover bbs for BookOrbit group tiles (the
-- Authors/Series "All ..." root -- see listGroups in
-- bookshelf_bookorbit_source.lua), keyed by group entry id (e.g.
-- "authors:42"), NOT by the disposable per-render first_book table.
--
-- Why this exists: listGroups() used to decode a group tile's preview
-- cover fresh from disk on EVERY call (cachedCoverBB()), even though
-- the entries/first_book METADATA is fully warm in the shared
-- bookshelf_bookorbit_cache bucket. That cache deliberately never
-- stored the decoded bb alongside the metadata (see its own comment on
-- approxSize) because FolderStack/SpineWidget's cover_align_top path
-- treats a group tile's cover_bb as a disposable, one-shot override and
-- FREES it after painting -- reusing a stored bb across renders would
-- paint from memory that was already freed on a prior render (the
-- distorted-covers-after-navigating-back bug this module's sibling fix
-- in bookshelf_folder_stack.lua also references). The old fix avoided
-- that by simply never caching the bb and re-decoding every render
-- instead -- correct, but it meant one real JPEG decode per visible
-- tile per _rebuild(), and a single page turn can trigger 2-4 cascading
-- rebuilds as scheduleCoverFills' batches land, so the same tiles got
-- re-decoded repeatedly even though nothing on disk had changed.
--
-- This module gives group-tile covers a REAL cache instead, following
-- exactly the ownership contract bookshelf_scaled_cover_cache.lua
-- already uses for book covers: hold a strong Lua reference to each
-- cached bb, hand it out to as many renders as ask for it, and never
-- call bb:free() on it ourselves. blitbuffer sets up an ffi.gc
-- finalizer at allocate time, so the C memory is reclaimed once every
-- Lua reference (ours and any live widget's) is gone -- no explicit
-- free needed, and critically, no use-after-free from a widget freeing
-- a bb this cache is still holding.
--
-- The other half of that contract lives in bookshelf_folder_stack.lua:
-- when it hands a cache-owned bb to SpineWidget as an explicit
-- cover_bb override, it now passes cover_bb_disposable = false (instead
-- of always true) for bbs this cache produced, so SpineWidget's
-- cover_align_top path does its usual bb:scale() (a private, disposable
-- COPY, made fresh every render regardless) but skips freeing the
-- shared source bb afterwards. That's what makes reuse across renders
-- safe: only the private per-render scaled copy is ever freed; the
-- cached source bb lives on for the next render to scale from again.

local logger = require("logger")

-- Group tile previews are small (shelf-sized thumbnails, same JPEGs the
-- flat book grid decodes), and there's normally at most a screen's
-- worth of visible tiles per section -- a much smaller working set than
-- ScaledCoverCache's whole-library book covers. A modest fixed budget
-- is enough to keep every visible tile warm without needing a user-
-- facing setting of its own.
local BYTE_BUDGET = 6 * 1024 * 1024
local ENTRY_CAP    = 256

local function _bbBytes(bb)
    if not bb then return 0 end
    local ok, n = pcall(function()
        local h = (bb.getHeight and bb:getHeight()) or tonumber(bb.h) or 0
        local stride = tonumber(bb.stride)
        if stride and h > 0 then return stride * h end
        local w   = (bb.getWidth and bb:getWidth()) or 0
        local bpp = (bb.getBpp and bb:getBpp()) or 8
        return w * h * math.ceil(bpp / 8)
    end)
    return (ok and n) or 0
end

local GroupCoverCache = {
    _cache = {},  -- gid -> { bb, w, h }
    _order = {},  -- gids, oldest (LRU) first
    _sizes = {},  -- gid -> bytes
    _bytes = 0,
    _hits  = 0,
    _puts  = 0,
    _evictions = 0,
}

function GroupCoverCache:_removeKey(key)
    for i, k in ipairs(self._order) do
        if k == key then
            table.remove(self._order, i)
            return
        end
    end
end

function GroupCoverCache:_evictIfNeeded()
    -- Keep at least the most-recently-inserted entry (#order > 1 guard)
    -- so a single oversized cover can't evict itself right after being
    -- put in, same guard ScaledCoverCache uses.
    while #self._order > 1
          and (#self._order > ENTRY_CAP or self._bytes > BYTE_BUDGET) do
        local key = table.remove(self._order, 1)
        -- Drop our reference only -- do NOT bb:free(). A live FolderStack
        -- tile from a previous render may still be mid-paint with a
        -- private bb:scale() copy taken FROM this bb, but never the bb
        -- itself (see the module doc above), so there is nothing to
        -- free here regardless; GC reclaims once unreachable.
        local entry = self._cache[key]
        self._cache[key] = nil
        self._bytes = self._bytes - (self._sizes[key] or 0)
        if self._bytes < 0 then self._bytes = 0 end
        self._sizes[key] = nil
        self._evictions = self._evictions + 1
    end
end

--- get(gid) -> bb, w, h  (or nil if not cached). A hit promotes the
-- entry to MRU. The returned bb is the cache's own live reference --
-- callers must treat it as read-only/shared (never free it; scale a
-- private copy off it if you need to transform it).
function GroupCoverCache:get(gid)
    if not gid or gid == "" then return nil end
    local entry = self._cache[gid]
    if not entry then return nil end
    self._hits = self._hits + 1
    self:_removeKey(gid)
    self._order[#self._order + 1] = gid
    return entry.bb, entry.w, entry.h
end

--- put(gid, bb, w, h) -- caches bb under gid. If gid already has an
-- entry, the old one is just dropped from our bookkeeping (never
-- freed -- see lifetime note above); the new bb becomes the cache
-- entry going forward.
function GroupCoverCache:put(gid, bb, w, h)
    if not gid or gid == "" or not bb then return end
    if self._cache[gid] and self._cache[gid].bb == bb then return end
    if self._cache[gid] then
        self:_removeKey(gid)
        self._bytes = self._bytes - (self._sizes[gid] or 0)
        if self._bytes < 0 then self._bytes = 0 end
        self._sizes[gid] = nil
    end
    self._cache[gid] = { bb = bb, w = w, h = h }
    self._order[#self._order + 1] = gid
    local nbytes = _bbBytes(bb)
    self._sizes[gid] = nbytes
    self._bytes = self._bytes + nbytes
    self._puts = self._puts + 1
    self:_evictIfNeeded()
end

--- invalidate(gid) -- drops one entry, if present. Doesn't free the bb
-- (see lifetime note above).
function GroupCoverCache:invalidate(gid)
    if not gid or gid == "" then return end
    if not self._cache[gid] then return end
    self._bytes = self._bytes - (self._sizes[gid] or 0)
    if self._bytes < 0 then self._bytes = 0 end
    self._cache[gid] = nil
    self._sizes[gid] = nil
    self:_removeKey(gid)
end

--- clearPrefix(prefix) -- drops every entry whose gid starts with
-- `prefix` (e.g. "authors:", "series:"), for a scoped invalidation --
-- a manual refresh of one BookOrbit group-root chip shouldn't evict
-- every OTHER section's tile covers along with it. Doesn't free any bb
-- (see lifetime note above).
function GroupCoverCache:clearPrefix(prefix)
    local doomed = {}
    for key in pairs(self._cache) do
        if key:sub(1, #prefix) == prefix then doomed[#doomed + 1] = key end
    end
    for _, key in ipairs(doomed) do self:invalidate(key) end
end

--- clear() -- drops every cached entry (e.g. on "Refresh library", same
-- moment invalidateGroupCache() drops the entries/first_book metadata
-- bucket, so a stale cover can never survive alongside a fresh entries
-- list). Doesn't free any bb -- see lifetime note above.
function GroupCoverCache:clear()
    logger.dbg(string.format(
        "[bookshelf perf] GroupCoverCache: clear hits=%d puts=%d evictions=%d",
        self._hits, self._puts, self._evictions))
    self._cache = {}
    self._order = {}
    self._sizes = {}
    self._bytes = 0
    self._hits  = 0
    self._puts  = 0
    self._evictions = 0
end

return GroupCoverCache
