-- bookshelf_bookorbit.lua
-- Native client for a self-hosted BookOrbit server (https://bookorbit.app).
--
-- This module talks to BookOrbit directly over the network -- unlike
-- bookshelf_hardcover.lua, which only *reads* another plugin's cache, this
-- one owns its own credentials, HTTP calls, and on-disk state. It covers:
--
--   1. Auth + progress sync, using the same kosync-compatible scheme as
--      KOReader's own "Progress sync" plugin: requests carry
--      X-Auth-User: <username> and X-Auth-Key: <md5(password)>. Book
--      identity is the partial MD5 checksum of the file (the same value
--      KOReader already computes via util.partialMD5 / caches as
--      "partial_md5_checksum" in each book's DocSettings sidecar).
--        GET  /koreader/users/auth               -- verify credentials
--        PUT  /koreader/syncs/progress            -- push position
--        GET  /koreader/syncs/progress/<md5>      -- pull latest position
--
--   2. Catalog browsing + download. Confirmed against BookOrbit's own
--      official koplugin source (bookorbit_api.lua / bookorbit_catalog.lua):
--      BookOrbit does NOT speak OPDS. It has its own JSON REST API, mounted
--      under <server_url>/api/v1, using the same X-Auth-User/X-Auth-Key
--      headers as progress sync:
--        GET /koreader/plugin/catalog/root                 -- section list
--        GET /koreader/plugin/catalog/sections/<section>    -- e.g. libraries,
--                                                               collections,
--                                                               authors, series
--        GET /koreader/plugin/catalog/books                 -- paged book list
--        GET /koreader/plugin/catalog/books/<id>             -- book detail + files
--        GET /koreader/plugin/catalog/files/<file_id>/download
--
--   3. Auth/config storage local to this plugin (does not touch or require
--      any other plugin's settings file).
--
-- NOTE: `pushStats` below is a stub. The real server has no simple
-- "one session" stats endpoint -- its equivalent
-- (/koreader/plugin/page-stats) takes a batch of already-aggregated
-- per-book page-stat records wrapped with device metadata, which is a
-- bigger integration than a single push call. Left disabled rather than
-- sending a shape the server will just reject.

local DataStorage = require("datastorage")
local LuaSettings = require("luasettings")
local NetworkMgr  = require("ui/network/manager")
local Device       = require("device")
local logger      = require("logger")
local UIManager   = require("ui/uimanager")
local Notification = require("ui/widget/notification")
local _           = require("lib/bookshelf_i18n").gettext
local SyncCoordinator = require("lib/bookshelf_bookorbit_sync_coordinator")
local SyncJobRunner   = require("lib/bookshelf_bookorbit_sync_job_runner")

local BookOrbit = {}

BookOrbit.SYNC_PRIORITY = SyncCoordinator.PRIORITY

local SETTINGS_FILE = DataStorage:getSettingsDir() .. "/bookorbit_settings.lua"

-- All real endpoints live under /api/v1 on the server. Users type in the
-- bare server address (e.g. "http://127.0.0.1:3000"); we append this once
-- when building the API base, the same way the official plugin's
-- BookOrbitApi.normalizeServerUrl does.
local API_PREFIX = "/api/v1"

local AUTH_PATH             = "/koreader/users/auth"
local PROGRESS_PATH         = "/koreader/syncs/progress"
local BOOK_STATES_PATH      = "/koreader/plugin/book-states"
local CATALOG_ROOT_PATH     = "/koreader/plugin/catalog/root"
local CATALOG_SECTION_PATH  = "/koreader/plugin/catalog/sections/"
local CATALOG_BOOKS_PATH    = "/koreader/plugin/catalog/books"
local CATALOG_BOOK_PATH     = "/koreader/plugin/catalog/books/"
local CATALOG_FILE_PATH     = "/koreader/plugin/catalog/files/"
local CATALOG_DISCOVER_PATH = "/koreader/plugin/catalog/dashboard/discover"
local CATALOG_MANIFEST_PATH = "/koreader/plugin/catalog/manifest"

local _settings -- lazy LuaSettings instance

local function settings()
    if not _settings then
        _settings = LuaSettings:open(SETTINGS_FILE)
    end
    return _settings
end

-- Cached plugin version. nil = not yet resolved; false = resolved, no
-- usable version found (so we don't retry the dofile every call).
local _plugin_version

--- Returns this plugin's version string (from ITS OWN _meta.lua), or nil.
--
-- Deliberately NOT `require("_meta")`. Every KOReader plugin ships its own
-- _meta.lua, and Lua's require() caches modules by bare name globally
-- across the whole process -- so a bare require("_meta") returns whichever
-- plugin's _meta.lua happened to load under that name first in the
-- session (ours, the official bookorbit.koplugin's, or any other
-- installed plugin's), not reliably this one. Confirmed as the cause of
-- the match-check/book-states 400s: bookshelf's own _meta.lua has
-- version = "3.10.8", but the official bookorbit.koplugin's _meta.lua has
-- no `version` field at all -- so depending on load order, pluginVersion
-- was going out as either the wrong plugin's string or nil/non-string,
-- and the server rejects the whole request for it.
--
-- dofile-ing our own _meta.lua by its full, unambiguous path sidesteps
-- the require() cache entirely. Same pattern as bookshelf_settings.lua's
-- _about() and bookshelf_updater.lua's version lookup.
local function getPluginVersion()
    if _plugin_version ~= nil then
        return _plugin_version or nil
    end
    -- This file lives at <plugin_dir>/lib/bookshelf_bookorbit.lua, so
    -- strip one path segment to reach _meta.lua.
    local src = debug.getinfo(1, "S").source:match("@(.*)$")
    local plugin_dir = src and src:match("^(.*)/lib/[^/]+%.lua$")
    local version
    if plugin_dir then
        local ok, meta = pcall(dofile, plugin_dir .. "/_meta.lua")
        if ok and type(meta) == "table" and type(meta.version) == "string" then
            version = meta.version
        end
    end
    _plugin_version = version or false
    return version
end

-- ---------------------------------------------------------------------
-- Config
-- ---------------------------------------------------------------------

--- Returns the saved {server_url, username, password, device_id} or nil
-- fields if never configured. password is stored locally the same way
-- kosync.koplugin stores its own credentials (KOReader's settings dir is
-- the trust boundary here); only the MD5 digest ever goes on the wire.
function BookOrbit.getConfig()
    local s = settings()
    return {
        server_url = s:readSetting("server_url"),
        username   = s:readSetting("username"),
        password   = s:readSetting("password"),
        device_id  = s:readSetting("device_id"),
    }
end

function BookOrbit.isConfigured()
    local c = BookOrbit.getConfig()
    return c.server_url ~= nil and c.server_url ~= ""
        and c.username ~= nil and c.username ~= ""
        and c.password ~= nil and c.password ~= ""
end

--- Persists credentials. Does not itself verify them -- call
-- BookOrbit.testConnection() first and only save on success.
function BookOrbit.saveConfig(server_url, username, password)
    local s = settings()
    -- Strip a trailing slash so path concatenation below never yields "//".
    server_url = (server_url or ""):gsub("/+$", "")
    s:saveSetting("server_url", server_url)
    s:saveSetting("username", username)
    s:saveSetting("password", password)
    if not s:readSetting("device_id") then
        -- Stable per-install identifier, same role as kosync's device_id:
        -- lets the server tell "this device" apart from your phone/Kobo.
        math.randomseed(os.time() + (tonumber(tostring({}):match("0x(%x+)"), 16) or 0))
        local id = string.format("bookshelf-%08x%08x", math.random(0, 0xffffffff), math.random(0, 0xffffffff))
        s:saveSetting("device_id", id)
    end
    s:flush()
    _settings = nil -- force reload next read, keeps this module stateless-ish
end

function BookOrbit.clearConfig()
    local s = settings()
    s:delSetting("server_url")
    s:delSetting("username")
    s:delSetting("password")
    s:delSetting("device_id")
    s:flush()
end

-- ---------------------------------------------------------------------
-- Pending-sync outbox
-- ---------------------------------------------------------------------
--
-- request() (below) short-circuits to `false, "offline"` before ever
-- touching the network, and every call site -- main.lua's push-on-close
-- hook in particular -- fires this through the sync coordinator, whose
-- SyncJobRunner wrapper discards run()'s return value entirely (it only
-- needs to know the job *completed*, not whether the network call inside
-- it actually succeeded). So a push that fails purely because Wi-Fi was
-- off completes instantly, looks identical to a real success to
-- everything downstream, and was previously never retried: not on
-- reconnect, not on next launch, not until something happened to reopen
-- that exact book while online. This outbox is what closes that gap --
-- keyed by book hash (not filepath) since hash is the stable identity a
-- retry actually needs, same as everywhere else in this file.
function BookOrbit.markPendingSync(filepath, hash)
    hash = hash or BookOrbit.getBookHash(filepath)
    if not hash then return end
    local s = settings()
    local pending = s:readSetting("pending_syncs") or {}
    pending[hash] = { filepath = filepath, marked_at = os.time() }
    s:saveSetting("pending_syncs", pending)
    s:flush()
    _settings = nil
end

--- Drop hash from the outbox once it's synced -- called by pushProgress
-- itself on success (see below), so a book that gets reopened and closed
-- online again clears its own stale marker without waiting on a
-- reconnect event that may never come for it specifically.
function BookOrbit.clearPendingSync(hash)
    if not hash then return end
    local s = settings()
    local pending = s:readSetting("pending_syncs")
    if not (pending and pending[hash]) then return end
    pending[hash] = nil
    s:saveSetting("pending_syncs", pending)
    s:flush()
    _settings = nil
end

--- Returns a list of {hash, filepath, marked_at}, oldest first.
function BookOrbit.getPendingSyncs()
    local s = settings()
    local pending = s:readSetting("pending_syncs") or {}
    local out = {}
    for hash, entry in pairs(pending) do
        if type(entry) == "table" and entry.filepath then
            out[#out + 1] = { hash = hash, filepath = entry.filepath, marked_at = entry.marked_at or 0 }
        end
    end
    table.sort(out, function(a, b) return a.marked_at < b.marked_at end)
    return out
end

--- Cheap count for the "Sync status" dialog -- avoids building the full
-- list (with sort) just to show a number.
function BookOrbit.pendingSyncCount()
    local s = settings()
    local pending = s:readSetting("pending_syncs") or {}
    local n = 0
    for _ in pairs(pending) do n = n + 1 end
    return n
end

-- ---------------------------------------------------------------------
-- Low-level HTTP
-- ---------------------------------------------------------------------

local function md5hex(str)
    -- ffi/sha2 is KOReader's own bundled hash implementation -- the same
    -- one BookOrbit's official plugin uses for this exact purpose
    -- (`local md5 = require("ffi/sha2").md5`), and it's always present,
    -- unlike the "md5" luarocks module this used to (wrongly) assume was
    -- available, silently falling back to util.partialMD5 -- a *sampled*
    -- per-file digest meant for book identity, not a real MD5 of an
    -- arbitrary string. That fallback produced a key that could never
    -- match the server's own md5(password), so every request 401'd.
    local ok, sha2 = pcall(require, "ffi/sha2")
    if ok and sha2 and sha2.md5 then return sha2.md5(str) end
    -- Last-resort fallback if ffi/sha2 is ever missing.
    local ok2, md5 = pcall(require, "md5")
    if ok2 and md5 and md5.sumhexa then return md5.sumhexa(str) end
    return nil
end

--- "http://host:port" or ".../api/v1" or ".../api/v1/koreader" (all things
-- BookOrbit itself has printed at one point or another) all normalize to
-- the same "http://host:port/api/v1" base, mirroring the official plugin's
-- BookOrbitApi.normalizeServerUrl.
local function apiBase(server_url)
    local url = (server_url or ""):gsub("/+$", "")
    url = url:gsub("/api/v1/koreader$", "/api/v1")
    if not url:match("/api/v1$") then
        url = url .. API_PREFIX
    end
    return url
end

--- Resolve a Location header against the URL it was received on. Most
-- servers send an absolute URL (BookOrbit itself always would, and so
-- would any CDN/S3 redirect for a thumbnail), so that's the common case;
-- a scheme-relative "//host/path" or absolute-path "/path" are handled
-- too since some reverse proxies emit those. Anything stranger just
-- fails the hop (better to stop than to build a bogus URL and 404).
local function resolveLocation(base_url, location)
    if not location or location == "" then return nil end
    if location:match("^https?://") then return location end
    local scheme, host = base_url:match("^(https?://[^/]+)")
    if not scheme then return nil end
    if location:match("^//") then return (base_url:match("^(https?:)") or "http:") .. location end
    if location:match("^/") then return scheme .. location end
    return nil
end

--- True if url_a and url_b share a scheme+host (used to decide whether
-- our BookOrbit auth headers should follow a redirect -- they shouldn't
-- leak to a different host, e.g. a signed CDN/S3 URL).
local function sameOrigin(url_a, url_b)
    local origin_a = url_a and url_a:match("^https?://[^/]+")
    local origin_b = url_b and url_b:match("^https?://[^/]+")
    return origin_a ~= nil and origin_a == origin_b
end

--- Core request helper. Returns (ok, code_or_err, body, headers).
-- opts: { method, path, query, json_body, raw_sink, sink_factory,
--         extra_headers, full_url }
-- path is relative to the API base (e.g. "/koreader/users/auth"); pass
-- full_url instead to hit an absolute URL verbatim (e.g. a download link
-- returned by a previous response, if it's ever a full URL).
--
-- Redirects are followed manually (NOT via LuaSocket's own
-- `redirect = true`): that option re-issues the whole request but keeps
-- the SAME sink across every hop, so with a raw file sink the bytes of
-- the redirect response (however small -- some servers send a short
-- HTML body with a 301/302) and the bytes of the final response both
-- land in the same file, back to back. The result "downloads" fine (a
-- 2xx, no error) but is no longer valid image data, and RenderImage
-- silently fails to decode it later -- 100% of the time, for every
-- book, since every thumbnail request takes the same redirected path.
-- Callers that use raw_sink for a *file* download should pass
-- sink_factory instead: a function returning a fresh sink, called once
-- per hop, so a redirect can't corrupt the file. (Plain raw_sink is
-- still accepted for callers where redirects are never expected, but
-- prefer sink_factory for anything that writes to disk.)
local function request(opts)
    if not NetworkMgr:isOnline() then
        return false, "offline"
    end
    local cfg = BookOrbit.getConfig()
    if not cfg.server_url then return false, "not_configured" end

    local http, ltn12, socket, socketutil, json
    local ok_req = pcall(function()
        http       = require("socket/http")
        ltn12      = require("ltn12")
        socket     = require("socket")
        socketutil = require("socketutil")
        json       = require("rapidjson")
    end)
    if not ok_req then return false, "no_http_stack" end

    local url = opts.full_url or (apiBase(cfg.server_url) .. opts.path)
    if opts.query then
        local parts = {}
        for k, v in pairs(opts.query) do
            if v ~= nil and v ~= "" then
                parts[#parts + 1] = tostring(k) .. "=" .. tostring(v):gsub("[^%w%-_.~]", function(c)
                    return string.format("%%%02X", c:byte())
                end)
            end
        end
        if #parts > 0 then
            url = url .. (url:find("?") and "&" or "?") .. table.concat(parts, "&")
        end
    end

    local base_headers = {
        ["User-Agent"] = "KOReader-Bookshelf-BookOrbit",
        ["Accept"]     = "application/json",
    }
    if cfg.username and cfg.password then
        base_headers["x-auth-user"] = cfg.username
        base_headers["x-auth-key"]  = md5hex(cfg.password)
    end
    if opts.extra_headers then
        for k, v in pairs(opts.extra_headers) do base_headers[k] = v end
    end

    local request_body
    if opts.json_body then
        request_body = json.encode(opts.json_body)
    end

    local hop_url = url
    local first_url = url
    local code, resp_headers, body
    local MAX_HOPS = 5
    for hop = 1, MAX_HOPS do
        local headers = {}
        for k, v in pairs(base_headers) do headers[k] = v end
        if request_body then
            headers["Content-Type"] = "application/json"
            headers["Content-Length"] = tostring(#request_body)
        end
        -- Don't forward BookOrbit credentials to a different host a
        -- redirect sends us to (e.g. a signed CDN URL for a thumbnail).
        if hop > 1 and not sameOrigin(first_url, hop_url) then
            headers["x-auth-user"], headers["x-auth-key"] = nil, nil
        end

        local response_body
        local sink
        if opts.sink_factory then
            local ok_sink, made_sink = pcall(opts.sink_factory)
            if not ok_sink or not made_sink then
                return false, tostring(made_sink or "sink_factory_error")
            end
            sink = made_sink
        elseif opts.raw_sink then
            sink = opts.raw_sink
        else
            response_body = {}
            sink = ltn12.sink.table(response_body)
        end

        local ok, hop_code, hop_headers = pcall(function()
            -- Timeout tier: LARGE_* (default) is sized for real file/
            -- thumbnail downloads and can legitimately take tens of
            -- seconds. Metadata/listing calls made synchronously from the
            -- shelf's render path (catalogSection -- see its own comment)
            -- pass opts.timeout = "block" to use the much smaller BLOCK_/
            -- TOTAL_TIMEOUT tier instead, so a slow or flaky connection
            -- fails fast and the caller falls back to whatever's cached
            -- rather than freezing the UI for the full LARGE window on
            -- every chip tap / page turn while the device is reconnecting
            -- to Wi-Fi.
            if opts.timeout == "block" then
                socketutil:set_timeout(socketutil.BLOCK_TIMEOUT, socketutil.TOTAL_TIMEOUT)
            else
                socketutil:set_timeout(socketutil.LARGE_BLOCK_TIMEOUT, socketutil.LARGE_TOTAL_TIMEOUT)
            end
            local c, h = socket.skip(1, http.request({
                url      = hop_url,
                method   = opts.method or "GET",
                headers  = headers,
                source   = request_body and ltn12.source.string(request_body) or nil,
                sink     = sink,
                redirect = false,
            }))
            socketutil:reset_timeout()
            return c, h
        end)
        if not ok then
            logger.warn("BookOrbit: request failed", hop_url, hop_code)
            return false, hop_code
        end
        -- A failed connection (bad TLS handshake/cert, DNS failure,
        -- connection refused, etc.) doesn't raise a Lua error here --
        -- LuaSocket's http.request just returns nil plus a string
        -- reason, which surfaces as a non-numeric `code` rather than an
        -- HTTP status. Mirrors the same guard in BookOrbit's own
        -- official plugin (bookorbit_api.lua).
        if type(hop_code) ~= "number" then
            logger.warn("BookOrbit: transport error", hop_url, hop_code)
            return false, tostring(hop_code or "network_error")
        end

        if hop_code == 301 or hop_code == 302 or hop_code == 303
                or hop_code == 307 or hop_code == 308 then
            local location = hop_headers and (hop_headers.location or hop_headers.Location)
            local next_url = resolveLocation(hop_url, location)
            if not next_url then
                logger.warn("BookOrbit: redirect with no usable Location", hop_url, hop_code)
                code, resp_headers = hop_code, hop_headers
                break
            end
            hop_url = next_url
            -- 303 always downgrades to GET; 301/302 conventionally do
            -- too for a non-GET/HEAD request (matches every browser and
            -- LuaSocket's own built-in redirect handling).
            if hop_code == 303 or ((hop_code == 301 or hop_code == 302)
                    and opts.method and opts.method ~= "GET" and opts.method ~= "HEAD") then
                opts = setmetatable({ method = "GET" }, { __index = opts })
                request_body = nil
            end
            -- loop again with a fresh sink for the next hop
        else
            code, resp_headers = hop_code, hop_headers
            if not opts.raw_sink and not opts.sink_factory and type(response_body) == "table" then
                body = table.concat(response_body)
            end
            break
        end
    end
    if not code then
        return false, "too_many_redirects"
    end
    return true, code, body, resp_headers
end

--- rapidjson.decode() represents a JSON `null` as the rapidjson.null
-- sentinel -- a lightuserdata, NOT Lua nil -- so a plain `foo ~= nil`
-- check on a maybe-null field is silently always true, and printing/
-- concatenating it yields literal "userdata: 0x...". catalogBooks() list
-- items happen to just omit a field entirely when it has no value, so
-- this never came up there; the book-detail endpoint (and, via it, the
-- author/series/similar "related books" lists embedded in a detail
-- response -- see bookshelf_bookorbit_source.lua's M.toRecord, which reads
-- b.seriesName/b.seriesIndex straight off these) sends explicit nulls for
-- unset optional fields instead, which is what actually surfaced this: a
-- book with no series showed a garbled "#userdata: 0x..." badge (from
-- `b.seriesIndex ~= nil and tostring(b.seriesIndex)`) instead of no series
-- info at all. Recursively strip every null sentinel out of a decoded
-- response (turning it into a real absent key) right here, once, so every
-- caller downstream sees the same "field simply isn't there" shape either
-- way. _seen guards against a (currently theoretical, but cheap to guard)
-- cyclic table crashing this with infinite recursion.
local function stripJsonNull(value, json_null, _seen)
    if type(value) ~= "table" then return value end
    _seen = _seen or {}
    if _seen[value] then return value end
    _seen[value] = true
    for k, v in pairs(value) do
        if v == json_null then
            value[k] = nil
        elseif type(v) == "table" then
            stripJsonNull(v, json_null, _seen)
        end
    end
    return value
end

--- GET/PUT/POST helper that also JSON-decodes a 2xx body. Returns
-- decoded_body, err (err is an HTTP status number or a string like
-- "offline"/"not_configured"/"invalid_json").
local function jsonRequest(opts)
    local ok, code, body = request(opts)
    if not ok then return nil, code end
    if code == 401 or code == 403 then return nil, code end
    if code < 200 or code >= 300 then return nil, code end
    if not body or body == "" then return {}, nil end
    local ok_json, json = pcall(require, "rapidjson")
    if not ok_json then return nil, "no_json_lib" end
    local ok_decode, data = pcall(json.decode, body)
    if not ok_decode or type(data) ~= "table" then return nil, "invalid_json" end
    return stripJsonNull(data, json.null), nil
end

-- ---------------------------------------------------------------------
-- Book identity (mirrors bookshelf_book_repository's enrichStats pattern)
-- ---------------------------------------------------------------------

function BookOrbit.getBookHash(filepath)
    if not filepath then return nil end
    local hash
    local ok_ds, DocSettings = pcall(require, "docsettings")
    if ok_ds and DocSettings then
        local ok_open, ds = pcall(function() return DocSettings:open(filepath) end)
        if ok_open and ds and ds.readSetting then
            hash = ds:readSetting("partial_md5_checksum")
        end
    end
    if not hash then
        local ok_util, u = pcall(require, "util")
        if ok_util and u and u.partialMD5 then
            hash = u.partialMD5(filepath)
        end
    end
    return hash
end

--- Sets (or clears, with rating=nil) the rating for a BookOrbit catalog
-- book directly by its server-side id -- PUT /koreader/plugin/catalog/
-- books/<id>/rating, body { rating }. Mirrors the official plugin's
-- BookOrbitApi:catalogSetRating exactly (same path, same body shape, same
-- explicit JSON null for clearing).
--
-- This is deliberately a SEPARATE path from pushBookState/readLocalBookState
-- below. Those key everything off a local DocSettings sidecar + the file's
-- partial-MD5 hash -- both of which require an actual on-disk file. A book
-- browsed via a BookOrbit chip but not yet downloaded has neither: its
-- filepath is the synthetic "bookorbit://<id>" placeholder (see
-- bookshelf_bookorbit_source.lua's toRecord), so DocSettings:open() on it
-- has no real file to attach a sidecar to and nothing persists. Use this
-- function instead whenever book.is_bookorbit is true; use pushBookState
-- for an on-device book with a real filepath.
--
-- Returns ok(bool), err(string|number|nil).
function BookOrbit.setCatalogRating(remote_id, rating)
    if not BookOrbit.isConfigured() then return false, "not_configured" end
    if not remote_id then return false, "no_remote_id" end
    local ok_json, json = pcall(require, "rapidjson")
    local rating_value = rating
    if rating_value == nil and ok_json then
        -- A Lua nil table field is simply omitted by json.encode -- the
        -- server would see no `rating` key at all (and, per the official
        -- plugin's own handling of this same case, likely leave the
        -- existing rating untouched rather than clear it). Force an
        -- explicit JSON null so "clear" actually clears.
        rating_value = json.null
    end
    local ok, code, body = request{
        method = "PUT",
        path   = CATALOG_BOOK_PATH .. tostring(remote_id) .. "/rating",
        json_body = { rating = rating_value },
    }
    if not (ok and code and code >= 200 and code < 300) then
        logger.info("BookOrbit: setCatalogRating failed", code, body)
        return false, code
    end
    return true
end

--- Sets a BookOrbit catalog book's read status directly by its server-side
-- id -- PUT /koreader/plugin/catalog/books/<id>/read-status, body
-- { status }. Mirrors the official plugin's BookOrbitApi:catalogSetReadStatus
-- exactly (same path, method, and body shape). Same "is_bookorbit path,
-- separate from pushBookState" reasoning as setCatalogRating right above --
-- a book only browsed via a BookOrbit chip (never downloaded) has no
-- on-disk file for a DocSettings sidecar to attach to, so its status has
-- to live on the server, not locally.
--
-- status is one of CatalogUtil.SETTABLE_READ_STATUSES' ids in the reference
-- plugin ("want_to_read", "reading", "on_hold", "read", "abandoned") --
-- this wrapper doesn't validate against that list, it just forwards
-- whatever the caller passes.
--
-- status == nil would mean "clear" (back to the default unread state), but
-- there is no route for that reachable from the plugin's credentials.
-- Confirmed against the live server:
--   * PUT .../koreader/plugin/catalog/books/<id>/read-status validates
--     `status` against the settable enum unconditionally -- 400s on null,
--     and on the literal string "unread" too.
--   * DELETE on that same path isn't a routed verb -- 404.
--   * The dashboard's own "Unread" control (sniffed from its network
--     traffic) hits a completely different, non-plugin route --
--     PATCH /books/<id>/status, body {"status":"unread"} -- authenticated
--     with the browser's session/JWT. Tried from the plugin with its
--     x-auth-user/x-auth-key headers: 401 Unauthorized.
-- So this isn't a client-side bug to work around -- the server simply
-- doesn't expose "reset to unread" on the plugin-facing API surface at
-- all, only on the session-authenticated dashboard route. The current
-- caller (_setWantToRead in bookshelf_widget.lua) no longer passes nil
-- for this reason -- it sends "abandoned" (or a remembered prior status)
-- instead, since that IS settable. This guard stays as a defensive
-- backstop against a future/other caller passing nil by mistake, so it
-- still fails fast with a distinct reason instead of firing a request
-- guaranteed to 401, rather than because it's expected to fire today.
--
-- Returns ok(bool), code(string|number|nil), body(string|nil) on failure.
function BookOrbit.setCatalogReadStatus(remote_id, status)
    if not BookOrbit.isConfigured() then return false, "not_configured" end
    if not remote_id then return false, "no_remote_id" end
    if status == nil then return false, "unread_unsupported" end
    local ok, code, body = request{
        method = "PUT",
        path   = CATALOG_BOOK_PATH .. tostring(remote_id) .. "/read-status",
        json_body = { status = status },
    }
    if not (ok and code and code >= 200 and code < 300) then
        logger.info("BookOrbit: setCatalogReadStatus failed", code, body)
        return false, code, body
    end
    return true
end

-- ---------------------------------------------------------------------
-- Auth test
-- ---------------------------------------------------------------------

--- Verifies server_url/username/password work, without saving them.
-- Returns ok(bool), message(string).
function BookOrbit.testConnection(server_url, username, password)
    server_url = (server_url or ""):gsub("/+$", "")
    if server_url == "" or not username or username == "" or not password or password == "" then
        return false, "Server URL, username, and password are all required."
    end
    if not NetworkMgr:isOnline() then
        return false, "No network connection."
    end
    -- Temporarily swap in the candidate credentials for one probe request
    -- without persisting them.
    local saved = _settings
    _settings = LuaSettings:open(SETTINGS_FILE .. ".probe.tmp")
    _settings:saveSetting("server_url", server_url)
    _settings:saveSetting("username", username)
    _settings:saveSetting("password", password)
    local ok, code, body = request{ method = "GET", path = AUTH_PATH }
    _settings = saved
    os.remove(SETTINGS_FILE .. ".probe.tmp")

    if not ok then
        if code == "offline" then return false, "No network connection." end
        return false, "Could not reach " .. server_url .. " (" .. tostring(code) .. ")."
    end
    if code == 401 or code == 403 then
        return false, "Server rejected the username/password."
    end
    if code ~= 200 then
        return false, "Unexpected response from server (HTTP " .. tostring(code) .. "). "
            .. "Check the server URL, or that " .. apiBase(server_url) .. AUTH_PATH .. " is reachable. "
            .. tostring(body or "")
    end
    return true, "Connected."
end

-- ---------------------------------------------------------------------
-- Sync coordination
-- ---------------------------------------------------------------------

local _sync_coordinator

--- Shared coordinator for every BookOrbit push/pull this plugin makes.
-- Lazily created so requiring this module never pulls in Trapper etc.
-- unless a sync job is actually submitted. See
-- bookshelf_bookorbit_sync_coordinator.lua for why a single shared
-- coordinator exists: without it, the push-on-close hook, the
-- pull-on-open check, and a manual "Sync now" tap can all fire their own
-- blocking network call at once.
function BookOrbit.getSyncCoordinator()
    if not _sync_coordinator then
        _sync_coordinator = SyncCoordinator.new()
    end
    return _sync_coordinator
end

--- Queue a BookOrbit sync job through the shared coordinator instead of
-- firing it directly. opts:
--   family   (string, required) -- jobs in the same family coalesce while
--            queued; pass BookOrbit.getBookHash(filepath) so a push and a
--            pull for the same book never race each other.
--   run      (function(job), required) -- plain, synchronous code that
--            does the blocking BookOrbit network call and returns.
--            SyncJobRunner wraps this in Trapper:wrap and reports
--            completion back to the coordinator -- callers don't need
--            their own Trapper handling any more.
--   label    (string, optional) -- for status()/diagnostics.
--   priority (BookOrbit.SYNC_PRIORITY.*, optional) -- defaults to .auto;
--            use .manual for a user-initiated "Sync now".
--   on_error (function(err), optional).
-- Returns the coordinator's submit() result: "started", "queued", or
-- "kept" (a higher-priority job already queued for this family).
function BookOrbit.submitSyncJob(opts)
    assert(type(opts) == "table", "submitSyncJob needs an opts table")
    local job = SyncJobRunner.prepare{
        family   = opts.family,
        label    = opts.label,
        priority = opts.priority,
        run      = opts.run,
        on_error = opts.on_error,
    }
    return BookOrbit.getSyncCoordinator():submit(job)
end

-- ---------------------------------------------------------------------
-- Auto Wi-Fi for sync
-- ---------------------------------------------------------------------
--
-- Off by default: automatically toggling the device's radio is more
-- intrusive than anything else this plugin does on its own (battery,
-- surprising the user if something else was relying on Wi-Fi staying up),
-- so it's opt-in -- same stance as "Jump to remote progress automatically".
function BookOrbit.autoWifiEnabled()
    return settings():isTrue("auto_wifi")
end

function BookOrbit.setAutoWifiEnabled(on)
    local s = settings()
    s:saveSetting("auto_wifi", on and true or false)
    s:flush()
    _settings = nil
end

--- Sub-setting of the above: also do the same connect-sync-disconnect dance
-- when a book is OPENED (the pull-on-open check in main.lua's
-- onReaderReady), not just on close or "Sync now". Off by
-- default even when the parent setting is on -- opening a book is the most
-- frequent trigger of the three, so it's the one most likely to catch
-- someone out with an unexpected radio-on if they didn't specifically ask
-- for it. Nested under the parent: true here is meaningless (and treated
-- as false) if the parent itself is off, since there'd be nothing for it
-- to layer on top of.
function BookOrbit.autoWifiOnOpenEnabled()
    return BookOrbit.autoWifiEnabled() and settings():isTrue("auto_wifi_on_open")
end

function BookOrbit.setAutoWifiOnOpenEnabled(on)
    local s = settings()
    s:saveSetting("auto_wifi_on_open", on and true or false)
    s:flush()
    _settings = nil
end

--- Separate from the two above: those gate an actual sync job (push on
-- close, pull on open, "Sync now"). This one instead
-- gates bookshelf_bookorbit_source.lua's _tryAutoConnect -- fired when a
-- BookOrbit chip/section is browsed (listBooks/listGroups) while offline,
-- to bring Wi-Fi up so the catalog can actually load instead of showing an
-- empty shelf. Not nested under autoWifiEnabled(): browsing a catalog isn't
-- "a sync", so tying it to the sync toggle would force someone who wants
-- one but not the other to get both. Off by default, same rationale as the
-- above -- toggling the radio on its own is the most intrusive thing this
-- plugin does unprompted.
function BookOrbit.autoWifiOnAccessEnabled()
    return settings():isTrue("auto_wifi_on_access")
end

function BookOrbit.setAutoWifiOnAccessEnabled(on)
    local s = settings()
    s:saveSetting("auto_wifi_on_access", on and true or false)
    s:flush()
    _settings = nil
end

-- Default inactivity window (seconds) before a Wi-Fi connection that
-- autoWifiOnAccessEnabled brought up on its own gets turned back off --
-- see bookshelf_bookorbit_source.lua's access-timeout bookkeeping.
BookOrbit.AUTO_WIFI_ACCESS_TIMEOUT_DEFAULT = 180

--- How long (seconds) to leave Wi-Fi up after the last BookOrbit
-- chip/section access before auto-disconnecting again, when that
-- connection is one autoWifiOnAccessEnabled brought up itself. Each
-- access resets the clock; this only controls the length of the window,
-- not whether the feature is on at all (that's the toggle above).
function BookOrbit.autoWifiOnAccessTimeoutSeconds()
    local v = tonumber(settings():readSetting("auto_wifi_on_access_timeout"))
    return (v and v > 0) and v or BookOrbit.AUTO_WIFI_ACCESS_TIMEOUT_DEFAULT
end

function BookOrbit.setAutoWifiOnAccessTimeoutSeconds(seconds)
    seconds = tonumber(seconds)
    if not (seconds and seconds > 0) then
        seconds = BookOrbit.AUTO_WIFI_ACCESS_TIMEOUT_DEFAULT
    end
    local s = settings()
    s:saveSetting("auto_wifi_on_access_timeout", seconds)
    s:flush()
    _settings = nil
end

--- Run schedule(afterDone) -- schedule is called exactly once, either:
--   * immediately, with a no-op afterDone, when the setting is off,
--     NetworkMgr is missing an API this needs, or the device is already
--     online (nothing to bring up, so nothing to tear down either); or
--   * once Wi-Fi has actually come up (via the same runWhenOnline helper
--     already used elsewhere in this plugin -- bookshelf_bookorbit_source
--     .lua's _tryAutoConnect, the weather/trivia/etc. micromodules --
--     which prompts for a saved network if needed and never forces a
--     silent connection past that), with a real afterDone that turns the
--     radio back off.
--
-- Callers MUST call the afterDone() they're given once their sync work
-- has actually finished, success or failure alike -- that call is the
-- "and once it's done, auto-disconnect" half of the feature. afterDone
-- only turns Wi-Fi off if THIS call is what turned it on: if the radio
-- was already on when this ran (whether fully connected yet or not --
-- e.g. the user turned it on themselves, or it's mid-handshake), it's
-- left alone, so this can never cut a connection out from under
-- something else that's using it.
local function withWifiGate(enabled, schedule)
    local noop = function() end
    if not enabled then return schedule(noop) end
    if not (NetworkMgr and NetworkMgr.isOnline and NetworkMgr.isWifiOn
            and NetworkMgr.runWhenOnline and NetworkMgr.turnOffWifi) then
        return schedule(noop)
    end

    local ok_online, online = pcall(function() return NetworkMgr:isOnline() end)
    if not ok_online or online then return schedule(noop) end

    -- Not online yet -- remember whether the radio itself was off before
    -- we do anything, so afterDone knows whether turning it off again is
    -- this call's responsibility.
    local ok_wifi, was_wifi_on = pcall(function() return NetworkMgr:isWifiOn() end)
    was_wifi_on = ok_wifi and was_wifi_on

    NetworkMgr:runWhenOnline(function()
        schedule(function()
            if not was_wifi_on then
                pcall(function() NetworkMgr:turnOffWifi() end)
                -- See bookshelf_bookorbit_source.lua's onAutoWifiOff/
                -- notifyWifiOff doc comments: NetworkMgr's own
                -- "NetworkDisconnected" broadcast isn't reliable enough
                -- after a purely programmatic turnOffWifi() call to trust
                -- for keeping the shelf's Wi-Fi icon in sync, so report it
                -- explicitly through the same path the access-timeout
                -- disconnect uses.
                local ok_src, BOSource = pcall(require, "lib/bookshelf_bookorbit_source")
                if ok_src and BOSource and BOSource.notifyWifiOff then
                    BOSource.notifyWifiOff()
                end
            end
        end)
    end)
end

function BookOrbit.withAutoWifi(schedule)
    return withWifiGate(BookOrbit.autoWifiEnabled(), schedule)
end

--- Same as withAutoWifi above, gated on the "on book open" sub-setting
-- instead of the parent setting directly (autoWifiOnOpenEnabled() already
-- folds the parent flag in, so a plugin call site never has to check both).
-- Used by main.lua's onReaderReady pull-on-open check so that check can
-- actually reach the server when Wi-Fi is off, instead of silently failing
-- to find newer progress from another device.
function BookOrbit.withAutoWifiOnOpen(schedule)
    return withWifiGate(BookOrbit.autoWifiOnOpenEnabled(), schedule)
end

--- Push the CURRENTLY OPEN book's progress, status, and rating to
-- BookOrbit right away, instead of waiting for it to close. Shared by
-- the "Sync now" settings menu item (bookshelf_settings.lua) and the
-- "Bookshelf: BookOrbit sync now" Dispatcher action (main.lua's
-- onBookshelfBookOrbitSyncNow) -- both just call this, so a gesture/key
-- bound to the latter behaves identically to tapping the former,
-- including the auto-Wi-Fi and pending-sync-outbox handling above.
-- No-ops with an on-screen notice (rather than failing silently) when
-- there's no book open or BookOrbit isn't configured yet -- both are
-- useful things for a gesture-triggered action to surface, since there's
-- no menu item nearby to explain why nothing happened.
-- Returns ok(bool), err(string|nil).
function BookOrbit.syncNow()
    local function notify(text, timeout)
        pcall(function()
            UIManager:show(Notification:new{ text = text, timeout = timeout or 3 })
        end)
    end

    if not (BookOrbit.isConfigured and BookOrbit.isConfigured()) then
        notify(_("BookOrbit isn't configured yet -- add your server first."))
        return false, "not_configured"
    end

    local ok_ui, ReaderUI = pcall(require, "apps/reader/readerui")
    local ui = ok_ui and ReaderUI and ReaderUI.instance
    if not (ui and ui.document and ui.document.file) then
        notify(_("Open a book first to sync its progress."))
        return false, "no_reader"
    end

    local fp = ui.document.file
    -- percentage + position, both needed: percentage alone can't drive
    -- another device's "Go to page" button, only the "X% synced" text.
    local percentage, position = BookOrbit.readLiveProgress(ui)
    if not percentage then
        pcall(function() percentage = ui.document:getPageProgress() end)
    end
    notify(_("Syncing…"), 1)

    -- Same "progress:<hash>" family as main.lua's push-on-close and
    -- pull-on-open hooks, at manual priority, so this can't land in the
    -- middle of (or be clobbered by) an automatic sync for the same book
    -- -- see bookshelf_bookorbit_sync_coordinator.lua.
    local hash = BookOrbit.getBookHash(fp)
    BookOrbit.withAutoWifi(function(afterDone)
        BookOrbit.submitSyncJob{
            family   = "progress:" .. (hash or fp),
            label    = "push progress + state (manual)",
            priority = BookOrbit.SYNC_PRIORITY.manual,
            run      = function()
                local ok, err = BookOrbit.pushProgress(fp, percentage, position)
                local ok2, _state_ok, state_err = pcall(BookOrbit.pushBookState, fp)
                if err == "offline" or (ok2 and state_err == "offline") then
                    pcall(BookOrbit.markPendingSync, fp, hash)
                end
                notify(ok and _("Synced.") or _("Sync failed -- check your connection."))
                afterDone()
            end,
        }
    end)
    return true
end

-- ---------------------------------------------------------------------
-- Progress sync
-- ---------------------------------------------------------------------

--- Read {percentage, position} from a live ReaderUI. Both fields matter:
-- percentage alone is enough for the "X% synced" notice, but position
-- (an xpointer for reflowable docs, a page number string for
-- fixed-layout ones) is what lets another device's "Go to page" button
-- actually jump anywhere. Mirrors the official plugin's
-- ProgressSync:getLastPercent()/getLastProgress(), which read off
-- ui.paging/ui.rolling -- the ReaderPaging/ReaderRolling modules that
-- track the reader's last-committed position -- rather than querying the
-- document object directly. (An earlier version of this call site tried
-- ui.view:getBookLocation(), which isn't a real KOReader API -- the
-- guard around it was always false, so position silently stayed nil and
-- every push went out with progress = "", which is why the "Go to page"
-- button on the pull-notice had nothing to jump to.)
function BookOrbit.readLiveProgress(ui)
    if not (ui and ui.document) then return nil, nil end
    local ok_hp, has_pages = pcall(function() return ui.document.info.has_pages end)
    if not ok_hp then return nil, nil end
    local percentage, position
    pcall(function()
        if has_pages then
            if ui.paging then
                percentage = ui.paging:getLastPercent()
                position = ui.paging:getLastProgress()
            end
        else
            if ui.rolling then
                percentage = ui.rolling:getLastPercent()
                position = ui.rolling:getLastProgress()
            end
        end
    end)
    return percentage, position
end

--- Push this device's current position for a book.
-- percentage: 0.0-1.0 float. progress: an opaque position string (KOReader
-- convention: xpointer for EPUB, page number as string for PDF/DjVu/etc).
function BookOrbit.pushProgress(filepath, percentage, progress)
    if not BookOrbit.isConfigured() then return false, "not_configured" end
    local hash = BookOrbit.getBookHash(filepath)
    if not hash then return false, "no_hash" end
    local cfg = BookOrbit.getConfig()
    local ok, code, body = request{
        method = "PUT",
        path   = PROGRESS_PATH,
        json_body = {
            document   = hash,
            progress   = tostring(progress or ""),
            percentage = percentage,
            device     = Device.model,
            device_id  = cfg.device_id,
            timestamp  = os.time(),
        },
    }
    if ok and (code == 200 or code == 201) then
        -- Clears any stale pending-sync marker for this book (see the
        -- outbox above) -- covers the case where a book gets reopened
        -- and closed again while online before a NetworkConnected event
        -- ever fires a retry, so the marker doesn't linger forever.
        pcall(BookOrbit.clearPendingSync, hash)
        return true
    end
    logger.info("BookOrbit: pushProgress failed", code, body)
    return false, code
end

--- Pull the latest known progress for a book. Returns a table
-- {percentage, progress, device, device_id, timestamp} or nil if none / on
-- error. device is only the human-readable model name (e.g. "Kobo Clara
-- HD") and can collide across devices -- callers that need to tell "this
-- install" apart from others must compare device_id, the stable per-install
-- id from BookOrbit.getConfig().device_id.
function BookOrbit.pullProgress(filepath)
    if not BookOrbit.isConfigured() then return nil end
    local hash = BookOrbit.getBookHash(filepath)
    if not hash then return nil end
    local data, err = jsonRequest{ method = "GET", path = PROGRESS_PATH .. "/" .. hash }
    if not data then
        if err then logger.info("BookOrbit: pullProgress failed", err) end
        return nil
    end
    return data
end

--- Not implemented: the real server's stats endpoint takes a batch of
-- pre-aggregated per-book page-stat records with device metadata attached,
-- not a single reading-session snapshot. Kept as a stub so callers that
-- guard on isConfigured() don't error if this is ever wired up.
function BookOrbit.pushStats(_session)
    return false, "not_implemented"
end

-- ---------------------------------------------------------------------
-- Status / rating sync
-- ---------------------------------------------------------------------

-- KOReader's own Book Status dialog only ever writes one of these three
-- into summary.status (nil/absent means "new", never uploaded) -- same
-- vocabulary the official BookOrbit plugin's ALLOWED_STATUSES accepts.
-- Bookshelf's own UI normalises "complete"->"finished" and
-- "abandoned"->"on_hold" for display (see bookshelf_book_repository.lua),
-- but the wire format must stay in KOReader's raw vocabulary.
local ALLOWED_STATUSES = { reading = true, complete = true, abandoned = true }

local function isDateOnly(value)
    return type(value) == "string" and value:match("^%d%d%d%d%-%d%d%-%d%d$") ~= nil
end

--- Read {status, status_modified, rating, review_note} straight off the
-- on-disk sidecar's `summary` setting (the same field KOReader's Book
-- Status dialog writes to, and the same one Bookshelf's own hero-card
-- rating and cover-progress indicators already read -- see
-- bookshelf_book_repository.lua). Always reads from disk rather than a
-- live ui.doc_settings table so this works the same whether the book is
-- currently open or not, which pushBookFromDisk below needs (it can run
-- against a book that isn't currently open, e.g. from the pending-sync
-- outbox retry).
function BookOrbit.readLocalBookState(filepath)
    local ok_ds, DocSettings = pcall(require, "docsettings")
    if not (ok_ds and DocSettings) then return {} end
    local ok_open, ds = pcall(function() return DocSettings:open(filepath) end)
    if not (ok_open and ds and ds.readSetting) then return {} end
    local summary = ds:readSetting("summary")
    if type(summary) ~= "table" then return {} end
    local rating = tonumber(summary.rating)
    if rating and (rating < 1 or rating > 5) then rating = nil end
    if rating then rating = math.floor(rating) end
    return {
        status          = ALLOWED_STATUSES[summary.status] and summary.status or nil,
        status_modified = isDateOnly(summary.modified) and summary.modified or nil,
        rating          = rating,
        review_note     = type(summary.note) == "string" and summary.note:sub(1, 10000) or nil,
    }
end

--- True once this device has confirmed the server's status/rating/review
-- for `hash` at least once -- either because a real local value was
-- successfully pushed, or via a one-time "empty" push whose only purpose
-- was to pull down whatever the server already had (see pushBookState
-- below). Persisted so that one-time pull is only paid for once per
-- book, not on every single push -- mirrors the official plugin's
-- book.ratingSyncedKnown / reviewSyncedKnown flags (bookorbit_sidecar.lua).
function BookOrbit.isBookStateKnown(hash)
    if not hash then return false end
    local s = settings()
    local known = s:readSetting("book_state_known") or {}
    return known[hash] == true
end

--- Marks `hash` as confirmed -- see isBookStateKnown above.
function BookOrbit.markBookStateKnown(hash)
    if not hash then return end
    local s = settings()
    local known = s:readSetting("book_state_known") or {}
    known[hash] = true
    s:saveSetting("book_state_known", known)
    s:flush()
    _settings = nil
end

--- Drops the whole book_state_known cache, so the next push for any book
-- force-pulls its status/rating/review from the server again -- backstop for
-- a rating/status/review set server-side that this device somehow missed
-- (a push that failed silently, say). Wired into the manual "Refresh
-- library" action, same as bookshelf_bookorbit_source.lua's
-- invalidateDescriptionCache.
function BookOrbit.clearBookStateKnown()
    pcall(function()
        local s = settings()
        s:saveSetting("book_state_known", {})
        s:flush()
        _settings = nil
    end)
end

--- Write a server-confirmed rating/review back to the sidecar, mirroring
-- BookOrbitSidecar.applyServerStateSidecar in the official plugin. Only
-- touches fields the server actually reported (ratingSet/reviewNoteSet);
-- a field the server is silent on is left exactly as it was locally.
local function applyServerBookState(filepath, result)
    if not (filepath and type(result) == "table") then return false end
    local has_rating = type(result.ratingSet) == "boolean"
    local has_review = type(result.reviewNoteSet) == "boolean"
    if not (has_rating or has_review) then return false end

    local ok_ds, DocSettings = pcall(require, "docsettings")
    if not (ok_ds and DocSettings) then return false end
    local ok_open, ds = pcall(function() return DocSettings:open(filepath) end)
    if not (ok_open and ds) then return false end

    local summary = ds:readSetting("summary") or {}
    local touched = false
    if has_rating then
        local server_rating = result.ratingSet and tonumber(result.rating) or nil
        if server_rating then server_rating = math.floor(server_rating) end
        if summary.rating ~= server_rating then
            summary.rating = server_rating
            touched = true
        end
    end
    if has_review then
        local server_note = result.reviewNoteSet and result.reviewNote or nil
        if summary.note ~= server_note then
            summary.note = server_note
            touched = true
        end
    end
    if touched then
        summary.modified = os.date("%Y-%m-%d")
        ds:saveSetting("summary", summary)
        pcall(function() ds:flush() end)
    end
    return touched
end

--- Push this device's local status/rating/review for a book, and
-- reconcile the sidecar against whatever the server reports back as
-- current (a tie or an older local value is silently overwritten by the
-- server's copy -- same policy as the official plugin's book-states
-- upload). No-ops (returns true, "nothing_to_sync") when the book has
-- neither a status, a rating, nor a review note set locally AND this
-- device has already confirmed the server's state for it at least once
-- (see isBookStateKnown above) -- nothing new to upload and nothing left
-- to learn, so there's no reason to spend a request on every untouched
-- book on every single push.
--
-- The first time a book is seen with nothing set locally, though, this
-- still makes the request -- an "empty" state push whose only real
-- purpose is to pull down whatever status/rating/review the server
-- already has for it (set from the web UI or another device, say) via
-- applyServerBookState below. Without this, a book that was only ever
-- rated on the server -- never touched from this device -- would return
-- "nothing_to_sync" forever and its rating would never reach this
-- device's sidecar. Mirrors the official plugin's force_pull behaviour
-- in BookOrbitSidecar.buildStatePayload.
-- Returns ok(bool), err_or_reason(string|number|nil).
function BookOrbit.pushBookState(filepath)
    if not BookOrbit.isConfigured() then return false, "not_configured" end
    local hash = BookOrbit.getBookHash(filepath)
    if not hash then return false, "no_hash" end

    local state = BookOrbit.readLocalBookState(filepath)
    local has_local = state.status or state.rating or state.review_note
    if not has_local and BookOrbit.isBookStateKnown(hash) then
        return true, "nothing_to_sync"
    end

    local cfg = BookOrbit.getConfig()
    local payload = {
        hash           = hash,
        status         = state.status,
        statusModified = state.status_modified,
        rating         = state.rating,
        reviewNote     = state.review_note,
    }
    -- deviceId/deviceModel/pluginVersion/deviceTime go at the TOP level of
    -- the request body (sibling of `books`), not inside each book item --
    -- same withDevice() shape every /koreader/plugin/* POST endpoint
    -- expects. Putting them per-item, as this used to, risked a 400 for
    -- the same reason.
    local data, err = jsonRequest{
        method = "POST",
        path = BOOK_STATES_PATH,
        json_body = {
            books         = { payload },
            deviceId      = cfg.device_id,
            deviceModel   = Device.model,
            pluginVersion = getPluginVersion(),
            deviceTime    = os.date("%Y-%m-%d %H:%M:%S"),
        },
    }
    if not data then
        logger.info("BookOrbit: pushBookState failed", err)
        return false, err
    end

    local result = data.results and data.results[1] or nil
    if result then
        pcall(applyServerBookState, filepath, result)
        -- Only mark the book "known" once a result actually came back --
        -- an unmatched/otherwise-empty response means we still don't
        -- genuinely know the server's state for it, so a later push
        -- should keep trying rather than silently giving up forever.
        pcall(BookOrbit.markBookStateKnown, hash)
    end
    return true
end

--- Push progress + status/rating for filepath straight off its on-disk
-- sidecar, without needing a live ReaderUI -- works whether or not the
-- book is currently open, which is the whole point: a pending-sync
-- retry's book won't be. Used by retryPendingSyncs below.
-- Returns ok(bool) -- true if the progress push, the state push, or both
-- succeeded (a book can validly have only one of the two set) -- and
-- err(string|number|nil), the most informative single failure reason
-- when ok is false.
function BookOrbit.pushBookFromDisk(filepath)
    if not BookOrbit.isConfigured() then return false, "not_configured" end
    local hash = BookOrbit.getBookHash(filepath)
    if not hash then return false, "no_hash" end

    local percentage, position
    local ok_ds, DocSettings = pcall(require, "docsettings")
    if ok_ds and DocSettings then
        local ok_open, ds = pcall(function() return DocSettings:open(filepath) end)
        if ok_open and ds and ds.readSetting then
            percentage = ds:readSetting("percent_finished")
            position = ds:readSetting("last_xpointer")
            if position == nil then
                local last_page = ds:readSetting("last_page")
                if last_page ~= nil then position = tostring(last_page) end
            end
        end
    end

    local push_ok, push_err = false, nil
    if percentage ~= nil then
        local ok_call, result, err = pcall(BookOrbit.pushProgress, filepath, percentage, position)
        if ok_call then
            push_ok, push_err = result, err
        else
            push_err = result
        end
    end

    local state_ok, state_err = false, nil
    do
        local ok_call, result, err = pcall(BookOrbit.pushBookState, filepath)
        if ok_call then
            state_ok, state_err = result, err
        else
            state_err = result
        end
    end

    if push_ok or state_ok then return true end
    -- Prefer "offline" over any other reason when both are offered, so
    -- callers that branch on the reason (retryPendingSyncs's caller,
    -- markPendingSync sites) see the one that actually explains why nothing
    -- went out.
    if push_err == "offline" or state_err == "offline" then return false, "offline" end
    return false, push_err or state_err
end

--- Retry every push recorded in the pending-sync outbox (see
-- markPendingSync above). Meant to be called from main.lua's
-- onNetworkConnected once connectivity is back -- a push that failed
-- purely because the device was offline is otherwise never retried
-- automatically; nothing else in this plugin would ever revisit it (see
-- the outbox's header comment for why). Safe to call with nothing
-- pending (just an empty loop) and safe to call repeatedly -- entries
-- that still fail (offline again, or some other error) are simply left
-- in the outbox for the next call rather than being dropped.
function BookOrbit.retryPendingSyncs()
    if not BookOrbit.isConfigured() then return end
    local pending = BookOrbit.getPendingSyncs()
    for _, entry in ipairs(pending) do
        local ok_call, ok = pcall(BookOrbit.pushBookFromDisk, entry.filepath)
        if ok_call and ok then
            BookOrbit.clearPendingSync(entry.hash)
        end
    end
end

-- ---------------------------------------------------------------------
-- Catalog (JSON REST, NOT OPDS -- see header comment)
-- ---------------------------------------------------------------------

--- GET /koreader/plugin/catalog/root. Returns { sections = {{section, title}, ...} }.
function BookOrbit.catalogRoot()
    return jsonRequest{ method = "GET", path = CATALOG_ROOT_PATH }
end

--- GET /koreader/plugin/catalog/sections/<section>. params: { page, q }.
-- Returns { items = {{id, title, count, seriesId, ...}}, page, hasNext, query }.
-- timeout = "block": this is called synchronously from listGroups /
-- fetchSectionBucket / continueSectionWalk on the shelf's render path
-- (chip taps, pagination, background sort walk) -- often with no
-- dismissable spinner around it if Trapper's subprocess fork isn't
-- available on this platform. A page of catalog metadata is tiny, so it
-- should time out in a few seconds on a bad connection, not sit on the
-- same tens-of-seconds budget as a multi-MB file download.
function BookOrbit.catalogSection(section, params)
    return jsonRequest{ method = "GET", path = CATALOG_SECTION_PATH .. section,
        query = params, timeout = "block" }
end

--- GET /koreader/plugin/catalog/books. params may include: page, size,
-- sort, order, q, libraryId, collectionId, smartScopeId, author, series,
-- seriesId, readStatus, format, ids.
-- Returns { items = {{id, title, authors={}, formats={}, seriesName,
--           seriesIndex, progressPercentage, readStatus, ...}}, page, hasNext }.
function BookOrbit.catalogBooks(params)
    return jsonRequest{ method = "GET", path = CATALOG_BOOKS_PATH, query = params }
end

--- GET /koreader/plugin/catalog/dashboard/discover. Returns a curated,
-- randomised { discover = {{id, title, authors, ...}} } batch -- same
-- endpoint the official plugin's "Discover" dashboard row and its reroll
-- button use. Takes no page/size params: every call is a fresh random
-- selection, not a page of a stable, orderable list -- so callers must
-- fetch it once and paginate the result in memory rather than calling
-- this again per page turn (see bookshelf_bookorbit_source.lua).
function BookOrbit.catalogDiscover()
    return jsonRequest{ method = "GET", path = CATALOG_DISCOVER_PATH }
end

--- GET /koreader/plugin/catalog/books/<id>. Returns book detail including
-- files = {{id, format, sizeBytes, role}}.
function BookOrbit.catalogBook(book_id)
    local cfg = BookOrbit.getConfig()
    return jsonRequest{
        method = "GET",
        path = CATALOG_BOOK_PATH .. tostring(book_id),
        query = { deviceId = cfg.device_id },
    }
end

--- getLibraryVersion() -> version_string, err
--
-- A cheap "has anything in this user's accessible libraries changed"
-- token, for gating disk-cached catalog pages (see
-- bookshelf_bookorbit_cache.lua) instead of trusting them forever or
-- re-fetching on a fixed schedule. Confirmed directly against the
-- official server source (server/src/modules/koreader/
-- koreader-plugin.service.ts, computeLibraryVersion): an md5 over
-- (accessible library ids, max file timestamp across them, a
-- hash-link count+timestamp), recomputed from two lightweight
-- aggregate queries -- NOT a full catalog scan. Same value = nothing
-- relevant changed since the last check; different value = something
-- did (a book added/removed/edited anywhere in scope), with no
-- indication of WHAT changed or where, so a caller can only treat a
-- mismatch as "invalidate everything", not "invalidate this one
-- section" -- see bookshelf_bookorbit_cache.lua's checkVersionAndInvalidate.
--
-- There is no dedicated endpoint for this token -- it only exists as a
-- field on two responses not designed for polling (this catalog
-- manifest, and the plugin's own sweep-complete call). This uses the
-- manifest one: GET .../catalog/manifest, discarding the (paginated)
-- `items` array and keeping only `manifestVersion` off the top. The
-- server validates `size` with @Min(1) @Max(200) (default 100) --
-- size=0 is rejected, so size=1 is the cheapest legal call, still one
-- full book row fetched and thrown away. Marked Cache-Control: no-store
-- server-side, i.e. explicitly not meant to be cached by an
-- intermediary -- exactly right for a value whose entire point is to
-- always reflect the current state.
--
-- IMPORTANT: this is an internal server implementation detail riding
-- along on an endpoint built for bulk-download enumeration, not a
-- documented/stable public contract the way the auth and progress-sync
-- endpoints are. It could change shape or disappear in a future
-- BookOrbit release without notice -- same category of risk already
-- accepted for this integration's reverse-engineered catalog endpoints
-- (see BOOKORBIT_INTEGRATION.md).
--
-- Returns nil, err on any failure (offline, non-2xx, bad JSON, field
-- missing) -- callers MUST treat that as "couldn't verify, assume
-- unchanged" (fail open) rather than invalidating a good cache just
-- because the version-check call itself failed.
function BookOrbit.getLibraryVersion()
    local data, err = jsonRequest{
        method = "GET",
        path = CATALOG_MANIFEST_PATH,
        query = { size = 1 },
        timeout = "block",
    }
    if not data then return nil, err end
    local version = data.manifestVersion
    if type(version) ~= "string" or version == "" then
        return nil, "no_manifest_version"
    end
    return version, nil
end

--- GET /koreader/plugin/catalog/books/<id>/thumbnail -- a cover image for
-- one catalog book. Mirrors the official plugin's
-- BookOrbitApi:downloadCatalogThumbnail. Returns true, resp_headers on
-- success (headers included so a caller whose RenderImage decode still
-- fails afterwards can log Content-Type/Content-Encoding to see WHAT
-- actually landed on disk, instead of just "didn't decode"), or nil, err.
function BookOrbit.downloadCatalogThumbnail(book_id, dest_path)
    local ltn12_ok, ltn12 = pcall(require, "ltn12")
    if not ltn12_ok then return nil, "no_http_stack" end
    local ok, code, _body, headers = request{
        method = "GET",
        path   = CATALOG_BOOK_PATH .. tostring(book_id) .. "/thumbnail",
        sink_factory = function()
            local fh, open_err = io.open(dest_path, "wb")
            if not fh then error(open_err or "open_error") end
            return ltn12.sink.file(fh)
        end,
        -- Accept-Encoding: identity matters here: without it, a gzipping
        -- reverse proxy can hand back compressed bytes straight into this
        -- raw file sink (LuaSocket doesn't inflate for us) -- the download
        -- "succeeds" (200, bytes on disk) but the file isn't a valid JPEG,
        -- so RenderImage silently fails to decode it later. Matches the
        -- header set our own downloadCatalogFile (and the official
        -- plugin's BookOrbitApi:download) already use for this reason.
        extra_headers = { ["Accept"] = "image/jpeg,image/*", ["Accept-Encoding"] = "identity" },
    }
    if ok and code == 200 then return true, headers end
    os.remove(dest_path)
    if not ok then return nil, code end
    return nil, "http_" .. tostring(code)
end

-- ---------------------------------------------------------------------
-- Shared download-destination helpers (used by both the plain-menu
-- catalog browser and the chip-source grid browser, so a book saved
-- from either path lands in the same place with the same naming rules).
-- ---------------------------------------------------------------------

function BookOrbit.defaultDownloadDir()
    local DataStorage = require("datastorage")
    local ok_settings, LuaSettingsMod = pcall(require, "luasettings")
    local ok_g, G_reader_settings = pcall(function()
        return ok_settings and LuaSettingsMod
            and LuaSettingsMod:open(DataStorage:getSettingsDir() .. "/g_reader_settings.lua")
    end)
    local home = ok_g and G_reader_settings and G_reader_settings:readSetting("home_dir")
    return home or DataStorage:getFullDataDir()
end

--- Returns the user-chosen download folder (Bookshelf menu -> BookOrbit ->
-- Download folder), or nil if never set / no longer valid.
function BookOrbit.getDownloadDir()
    local dir = settings():readSetting("download_dir")
    if not dir or dir == "" then return nil end
    local lfs_ok, lfs = pcall(require, "libs/libkoreader-lfs")
    if lfs_ok and lfs.attributes(dir, "mode") ~= "directory" then
        -- Chosen folder vanished (SD card removed, etc.) -- fall back
        -- silently rather than erroring on every download.
        return nil
    end
    return dir
end

--- Persists the download folder override. Pass nil/"" to clear it and
-- go back to auto-detecting (home_dir, then the full data dir).
function BookOrbit.setDownloadDir(dir)
    local s = settings()
    if dir and dir ~= "" then
        s:saveSetting("download_dir", dir)
    else
        s:delSetting("download_dir")
    end
    s:flush()
    _settings = nil
end

--- The folder BookOrbit downloads should actually land in: the user's
-- explicit choice if one is set and still valid, else the auto-detected
-- default. Both the plain-menu catalog browser and the chip-source grid
-- browser call this (not defaultDownloadDir directly) so a folder picked
-- in Bookshelf menu -> BookOrbit -> Download folder applies everywhere.
function BookOrbit.downloadDir()
    return BookOrbit.getDownloadDir() or BookOrbit.defaultDownloadDir()
end

function BookOrbit.sanitizeFilename(name)
    name = (name or "book"):gsub('[/\\:*?"<>|]', "_"):gsub("%s+", " "):gsub("^%s+", ""):gsub("%s+$", "")
    if name == "" then name = "book" end
    return name
end

--- Folder layout: which subfolders (if any) get appended under the
-- download folder. "flat" (no subfolders), "author" (Author only),
-- "author_series" (Author, then Series when the book has one -- this was
-- the only behaviour before this setting existed, so it's the default),
-- or "custom" (customFolderTemplate() below).
function BookOrbit.folderLayout()
    local v = settings():readSetting("folder_layout")
    if v == "flat" or v == "author" or v == "author_series" or v == "custom" then
        return v
    end
    return "author_series"
end

--- Persists the folder layout. Pass nil/"" to clear it back to the default
-- ("author_series").
function BookOrbit.setFolderLayout(layout)
    local s = settings()
    if layout and layout ~= "author_series" and layout ~= "" then
        s:saveSetting("folder_layout", layout)
    else
        s:delSetting("folder_layout")
    end
    s:flush()
    _settings = nil
end

-- Default templates, used until the user sets their own (Bookshelf menu ->
-- BookOrbit -> Download format -> Folder layout/Filename -> Custom).
-- Placeholders: {title}, {author}, {series}, {series_num} (zero-padded
-- series index), {year} -- each renders as "" for a book that doesn't have
-- that field, never an error. Folder templates are split on "/" into
-- subfolder segments; a segment that renders empty (e.g. {series} on a
-- standalone book) is skipped rather than creating a blank folder level.
-- See renderTemplate/templateFields below for exactly how a template with
-- missing fields gets cleaned up.
BookOrbit.DEFAULT_CUSTOM_FOLDER_TEMPLATE = "{author}/{series}"
BookOrbit.DEFAULT_CUSTOM_FILENAME_TEMPLATE = "{series_num} {title} - {author} ({year})"

--- The user's custom folder template (see above), or the default until
-- they set one.
function BookOrbit.customFolderTemplate()
    local v = settings():readSetting("custom_folder_template")
    if type(v) == "string" and v ~= "" then return v end
    return BookOrbit.DEFAULT_CUSTOM_FOLDER_TEMPLATE
end

--- Persists the custom folder template. Pass nil/"" to clear it back to
-- the default.
function BookOrbit.setCustomFolderTemplate(template)
    local s = settings()
    if template and template ~= "" then
        s:saveSetting("custom_folder_template", template)
    else
        s:delSetting("custom_folder_template")
    end
    s:flush()
    _settings = nil
end

--- Filename pattern: how the saved file is named, before its extension.
-- "title" (default -- just the title), "title_author", "author_title",
-- "series_title", "series_num_title_author_year", or "custom"
-- (customFilenameTemplate() below). Falls back to plain "title" whenever
-- the book is missing the field the chosen pattern needs (e.g. no author
-- on file), or a custom template renders empty.
function BookOrbit.filenamePattern()
    local v = settings():readSetting("filename_pattern")
    if v == "title_author" or v == "author_title" or v == "series_title"
        or v == "series_num_title_author_year" or v == "custom" then
        return v
    end
    return "title"
end

--- Persists the filename pattern. Pass nil/"" to clear it back to the
-- default ("title").
function BookOrbit.setFilenamePattern(pattern)
    local s = settings()
    if pattern and pattern ~= "title" and pattern ~= "" then
        s:saveSetting("filename_pattern", pattern)
    else
        s:delSetting("filename_pattern")
    end
    s:flush()
    _settings = nil
end

--- The user's custom filename template (see above), or the default until
-- they set one.
function BookOrbit.customFilenameTemplate()
    local v = settings():readSetting("custom_filename_template")
    if type(v) == "string" and v ~= "" then return v end
    return BookOrbit.DEFAULT_CUSTOM_FILENAME_TEMPLATE
end

--- Persists the custom filename template. Pass nil/"" to clear it back to
-- the default.
function BookOrbit.setCustomFilenameTemplate(template)
    local s = settings()
    if template and template ~= "" then
        s:saveSetting("custom_filename_template", template)
    else
        s:delSetting("custom_filename_template")
    end
    s:flush()
    _settings = nil
end

--- Zero-pads a series index for filename use: 1 -> "01", 21 -> "21",
-- 100 -> "100" (never truncates, only pads up to 2 digits). Fractional
-- indices (e.g. 1.5, for a novella slotted between books 1 and 2) keep
-- their fractional part: 1.5 -> "01.5". Returns nil for anything that
-- isn't a number.
local function formatSeriesIndex(idx)
    local num = tonumber(idx)
    if not num then return nil end
    if num == math.floor(num) then
        return string.format("%02d", math.floor(num))
    end
    local int_str, frac_str = tostring(num):match("^(%d+)%.(%d+)$")
    if int_str then
        return string.format("%02d", tonumber(int_str)) .. "." .. frac_str
    end
    return tostring(num)
end

--- Best-effort publication year, pulled from whichever field the server
-- happens to populate -- the catalog API's documented shape (see
-- catalogBooks/catalogBook above) doesn't list a year field, so this
-- checks a handful of plausible names and also accepts a full date string
-- (e.g. "2015-06-01"), pulling just the leading 4-digit year out of it.
-- Returns nil if nothing usable is found, so callers degrade gracefully.
local function extractYear(book)
    local v = book.year or book.publishedYear or book.publishYear
        or book.releaseYear or book.publicationYear or book.publishedDate
        or book.releaseDate
    if not v then return nil end
    local s = tostring(v)
    return s:match("(%d%d%d%d)")
end

--- Field values a custom folder/filename template can reference -- the
-- same data every preset pattern already draws from. Missing fields
-- render as "" (never an error), which renderTemplate below then cleans
-- up rather than leaving stray punctuation behind.
local function templateFields(book, fallback_title)
    book = book or {}
    local title = book.title
    if not title or title == "" then title = fallback_title end
    if not title or title == "" then title = "book" end
    return {
        title      = title,
        author     = book.authors and book.authors[1] or "",
        series     = book.seriesName or "",
        series_num = formatSeriesIndex(book.seriesIndex) or "",
        year       = extractYear(book) or "",
    }
end

--- Substitutes {title}/{author}/{series}/{series_num}/{year} in `template`
-- with `fields`' values, then cleans up the punctuation a blank field
-- usually leaves behind: empty "( )"/"[ ]", doubled or dangling " - "
-- separators, doubled spaces, and leading/trailing whitespace or
-- separators. Handles reasonable templates like
-- "{series_num} {title} - {author} ({year})" gracefully when a field is
-- missing; unusual templates may still need a manual glance. Unknown
-- {placeholders} are left as literal text rather than erroring, so a typo
-- shows up in the preview instead of silently breaking the download.
local function renderTemplate(template, fields)
    local s = (template or ""):gsub("{(%a+)}", function(key)
        if fields[key] ~= nil then return fields[key] end
        return "{" .. key .. "}"
    end)
    s = s:gsub("%(%s*%)", "")            -- empty "( )"
    s = s:gsub("%[%s*%]", "")            -- empty "[ ]"
    s = s:gsub("%s*%-%s*%-%s*", " - ")   -- doubled " - "
    s = s:gsub("^%s*%-%s*", "")          -- leading " - "
    s = s:gsub("%s*%-%s*$", "")          -- trailing " - "
    s = s:gsub("%s+", " ")
    s = s:gsub("^%s+", ""):gsub("%s+$", "")
    return s
end

--- Renders `template` against a fixed example book -- for the settings
-- menu to preview a custom folder/filename template as the user types it,
-- without duplicating renderTemplate/templateFields (both local to this
-- file) or requiring a real book on hand. `kind` is "folder" (splits on
-- "/" into segments, joins the non-empty ones back with "/") or anything
-- else for a plain filename render.
function BookOrbit.previewTemplate(template, kind)
    local example = {
        title      = "The Hitchhiker's Guide to the Galaxy",
        authors    = { "Douglas Adams" },
        seriesName = "The Hitchhiker's Guide to the Galaxy",
        seriesIndex = 1,
        publishedYear = 1979,
    }
    local fields = templateFields(example, nil)
    if kind == "folder" then
        local parts = {}
        for segment in ((template or "") .. "/"):gmatch("([^/]*)/") do
            local rendered = renderTemplate(segment, fields)
            if rendered ~= "" then parts[#parts + 1] = rendered end
        end
        return #parts > 0 and table.concat(parts, "/") or ""
    end
    return renderTemplate(template, fields)
end


-- "<dir>/Douglas Adams/Hitchhiker's Guide to the Galaxy" under the default
-- "author_series" layout, or whatever customFolderTemplate() renders under
-- "custom". Creates the subfolder (mkdir -p) if needed. Falls back to
-- `dir` itself when the layout is "flat", the book has no author (preset
-- layouts) / every template segment renders empty (custom), or the
-- subfolder can't be created.
-- `book` is anything shaped like a catalog list item or catalogBook()
-- detail table -- both use `authors` (array) and `seriesName`.
function BookOrbit.downloadDestDir(dir, book)
    book = book or {}
    local layout = BookOrbit.folderLayout()
    if layout == "flat" then return dir end

    local sub
    if layout == "custom" then
        local fields = templateFields(book, nil)
        sub = dir
        for segment in (BookOrbit.customFolderTemplate() .. "/"):gmatch("([^/]*)/") do
            local rendered = renderTemplate(segment, fields)
            if rendered ~= "" then
                sub = sub .. "/" .. BookOrbit.sanitizeFilename(rendered)
            end
        end
        if sub == dir then return dir end -- every segment rendered empty
    else
        local author = book.authors and book.authors[1]
        if not author or author == "" then return dir end

        sub = dir .. "/" .. BookOrbit.sanitizeFilename(author)
        if layout == "author_series" then
            local series = book.seriesName
            if series and series ~= "" then
                sub = sub .. "/" .. BookOrbit.sanitizeFilename(series)
            end
        end
    end

    local ok_util, util = pcall(require, "util")
    if ok_util and util.makePath then
        util.makePath(sub)
    end

    local lfs_ok, lfs = pcall(require, "libs/libkoreader-lfs")
    if lfs_ok and lfs.attributes(sub, "mode") ~= "directory" then
        -- Couldn't create it (read-only fs, bad chars survived sanitizing,
        -- etc.) -- fall back to the plain download folder rather than
        -- erroring the whole download out.
        return dir
    end
    return sub
end

--- Builds the sanitized filename (without extension) for `book` according
-- to the user's chosen filename pattern (Bookshelf menu -> BookOrbit ->
-- Download format). `fallback_title` is used when `book.title` is blank --
-- e.g. the locally-cached record, before the detail fetch fills `title`
-- in. `book` is anything shaped like a catalog list item or catalogBook()
-- detail table (both use `authors` array and `seriesName`); a plain
-- string may also be passed as `book` for the title-only case.
function BookOrbit.buildFilenameBase(book, fallback_title)
    if type(book) == "string" then
        return BookOrbit.sanitizeFilename(book)
    end
    book = book or {}
    local title = book.title
    if not title or title == "" then title = fallback_title end
    if not title or title == "" then title = "book" end

    local author = book.authors and book.authors[1]
    local series = book.seriesName

    local pattern = BookOrbit.filenamePattern()
    local base
    if pattern == "custom" then
        base = renderTemplate(BookOrbit.customFilenameTemplate(), templateFields(book, fallback_title))
        if base == "" then base = title end
    elseif pattern == "title_author" and author and author ~= "" then
        base = title .. " - " .. author
    elseif pattern == "author_title" and author and author ~= "" then
        base = author .. " - " .. title
    elseif pattern == "series_title" and series and series ~= "" then
        base = series .. " - " .. title
    elseif pattern == "series_num_title_author_year" then
        -- "01. Title - Author (Year)" -- each piece is optional and
        -- simply omitted when the book doesn't carry it, so a book with
        -- no series index/author/year still ends up with a sane name
        -- instead of an empty one.
        local idx_str = formatSeriesIndex(book.seriesIndex)
        local year = extractYear(book)
        base = (idx_str and (idx_str .. ". ") or "") .. title
        if author and author ~= "" then
            base = base .. " - " .. author
        end
        if year then
            base = base .. " (" .. year .. ")"
        end
    else
        base = title
    end
    return BookOrbit.sanitizeFilename(base)
end

--- Returns a path in `dir` for `base.ext` that doesn't already exist,
-- appending " (n)" as needed.
function BookOrbit.uniqueDownloadPath(dir, base, ext)
    local path = dir .. "/" .. base .. "." .. ext
    local lfs_ok, lfs = pcall(require, "libs/libkoreader-lfs")
    if not lfs_ok then return path end
    local n = 1
    while lfs.attributes(path) do
        path = dir .. "/" .. base .. " (" .. n .. ")." .. ext
        n = n + 1
    end
    return path
end

--- Download a catalog file to dest_path. Returns true, or nil, err.
function BookOrbit.downloadCatalogFile(file_id, dest_path, progress_cb)
    local ltn12_ok, ltn12 = pcall(require, "ltn12")
    if not ltn12_ok then return nil, "no_http_stack" end

    local ok, code = request{
        method = "GET",
        path = CATALOG_FILE_PATH .. tostring(file_id) .. "/download",
        sink_factory = function()
            local fh, open_err = io.open(dest_path, "wb")
            if not fh then error(open_err or "open_error") end
            local file_sink = ltn12.sink.file(fh)
            if not progress_cb then return file_sink end
            local received = 0
            return function(chunk, err)
                if chunk and chunk ~= "" then
                    received = received + #chunk
                    progress_cb(received)
                end
                return file_sink(chunk, err)
            end
        end,
        extra_headers = { ["Accept"] = "application/octet-stream", ["Accept-Encoding"] = "identity" },
    }
    if ok and code == 200 then return true end
    os.remove(dest_path)
    if not ok then return nil, code end
    return nil, "http_" .. tostring(code)
end

return BookOrbit
