-- bookshelf_bookorbit.lua
-- Native client for a self-hosted BookOrbit server (https://bookorbit.app).
--
-- This module talks to BookOrbit directly over the network -- unlike
-- bookshelf_hardcover.lua, which only *reads* another plugin's cache, this
-- one owns its own credentials, HTTP calls, and on-disk state. It covers:
--
--   1. Auth + progress sync, using the same kosync-compatible scheme as
--      KOReader's own "Progress sync" plugin: requests carry
--      X-Auth-User: <username> and X-Auth-Key: <md5(password)>. Book
--      identity is the partial MD5 checksum of the file (the same value
--      KOReader already computes via util.partialMD5 / caches as
--      "partial_md5_checksum" in each book's DocSettings sidecar).
--        GET  /koreader/users/auth               -- verify credentials
--        PUT  /koreader/syncs/progress            -- push position
--        GET  /koreader/syncs/progress/<md5>      -- pull latest position
--
--   2. Catalog browsing + download. Confirmed against BookOrbit's own
--      official koplugin source (bookorbit_api.lua / bookorbit_catalog.lua):
--      BookOrbit does NOT speak OPDS. It has its own JSON REST API, mounted
--      under <server_url>/api/v1, using the same X-Auth-User/X-Auth-Key
--      headers as progress sync:
--        GET /koreader/plugin/catalog/root                 -- section list
--        GET /koreader/plugin/catalog/sections/<section>    -- e.g. libraries,
--                                                               collections,
--                                                               authors, series
--        GET /koreader/plugin/catalog/books                 -- paged book list
--        GET /koreader/plugin/catalog/books/<id>             -- book detail + files
--        GET /koreader/plugin/catalog/files/<file_id>/download
--
--   3. Auth/config storage local to this plugin (does not touch or require
--      any other plugin's settings file).
--
-- NOTE: `pushStats` below is a stub. The real server has no simple
-- "one session" stats endpoint -- its equivalent
-- (/koreader/plugin/page-stats) takes a batch of already-aggregated
-- per-book page-stat records wrapped with device metadata, which is a
-- bigger integration than a single push call. Left disabled rather than
-- sending a shape the server will just reject.

local DataStorage = require("datastorage")
local LuaSettings = require("luasettings")
local NetworkMgr  = require("ui/network/manager")
local Device       = require("device")
local logger      = require("logger")

local BookOrbit = {}

local SETTINGS_FILE = DataStorage:getSettingsDir() .. "/bookorbit_settings.lua"

-- All real endpoints live under /api/v1 on the server. Users type in the
-- bare server address (e.g. "http://127.0.0.1:3000"); we append this once
-- when building the API base, the same way the official plugin's
-- BookOrbitApi.normalizeServerUrl does.
local API_PREFIX = "/api/v1"

local AUTH_PATH             = "/koreader/users/auth"
local PROGRESS_PATH         = "/koreader/syncs/progress"
local CATALOG_ROOT_PATH     = "/koreader/plugin/catalog/root"
local CATALOG_SECTION_PATH  = "/koreader/plugin/catalog/sections/"
local CATALOG_BOOKS_PATH    = "/koreader/plugin/catalog/books"
local CATALOG_BOOK_PATH     = "/koreader/plugin/catalog/books/"
local CATALOG_FILE_PATH     = "/koreader/plugin/catalog/files/"

local _settings -- lazy LuaSettings instance

local function settings()
    if not _settings then
        _settings = LuaSettings:open(SETTINGS_FILE)
    end
    return _settings
end

-- ---------------------------------------------------------------------
-- Config
-- ---------------------------------------------------------------------

--- Returns the saved {server_url, username, password, device_id} or nil
-- fields if never configured. password is stored locally the same way
-- kosync.koplugin stores its own credentials (KOReader's settings dir is
-- the trust boundary here); only the MD5 digest ever goes on the wire.
function BookOrbit.getConfig()
    local s = settings()
    return {
        server_url = s:readSetting("server_url"),
        username   = s:readSetting("username"),
        password   = s:readSetting("password"),
        device_id  = s:readSetting("device_id"),
    }
end

function BookOrbit.isConfigured()
    local c = BookOrbit.getConfig()
    return c.server_url ~= nil and c.server_url ~= ""
        and c.username ~= nil and c.username ~= ""
        and c.password ~= nil and c.password ~= ""
end

--- Persists credentials. Does not itself verify them -- call
-- BookOrbit.testConnection() first and only save on success.
function BookOrbit.saveConfig(server_url, username, password)
    local s = settings()
    -- Strip a trailing slash so path concatenation below never yields "//".
    server_url = (server_url or ""):gsub("/+$", "")
    s:saveSetting("server_url", server_url)
    s:saveSetting("username", username)
    s:saveSetting("password", password)
    if not s:readSetting("device_id") then
        -- Stable per-install identifier, same role as kosync's device_id:
        -- lets the server tell "this device" apart from your phone/Kobo.
        math.randomseed(os.time() + (tonumber(tostring({}):match("0x(%x+)"), 16) or 0))
        local id = string.format("bookshelf-%08x%08x", math.random(0, 0xffffffff), math.random(0, 0xffffffff))
        s:saveSetting("device_id", id)
    end
    s:flush()
    _settings = nil -- force reload next read, keeps this module stateless-ish
end

function BookOrbit.clearConfig()
    local s = settings()
    s:delSetting("server_url")
    s:delSetting("username")
    s:delSetting("password")
    s:delSetting("device_id")
    s:flush()
end

-- ---------------------------------------------------------------------
-- Low-level HTTP
-- ---------------------------------------------------------------------

local function md5hex(str)
    -- ffi/sha2 is KOReader's own bundled hash implementation -- the same
    -- one BookOrbit's official plugin uses for this exact purpose
    -- (`local md5 = require("ffi/sha2").md5`), and it's always present,
    -- unlike the "md5" luarocks module this used to (wrongly) assume was
    -- available, silently falling back to util.partialMD5 -- a *sampled*
    -- per-file digest meant for book identity, not a real MD5 of an
    -- arbitrary string. That fallback produced a key that could never
    -- match the server's own md5(password), so every request 401'd.
    local ok, sha2 = pcall(require, "ffi/sha2")
    if ok and sha2 and sha2.md5 then return sha2.md5(str) end
    -- Last-resort fallback if ffi/sha2 is ever missing.
    local ok2, md5 = pcall(require, "md5")
    if ok2 and md5 and md5.sumhexa then return md5.sumhexa(str) end
    return nil
end

--- "http://host:port" or ".../api/v1" or ".../api/v1/koreader" (all things
-- BookOrbit itself has printed at one point or another) all normalize to
-- the same "http://host:port/api/v1" base, mirroring the official plugin's
-- BookOrbitApi.normalizeServerUrl.
local function apiBase(server_url)
    local url = (server_url or ""):gsub("/+$", "")
    url = url:gsub("/api/v1/koreader$", "/api/v1")
    if not url:match("/api/v1$") then
        url = url .. API_PREFIX
    end
    return url
end

--- Resolve a Location header against the URL it was received on. Most
-- servers send an absolute URL (BookOrbit itself always would, and so
-- would any CDN/S3 redirect for a thumbnail), so that's the common case;
-- a scheme-relative "//host/path" or absolute-path "/path" are handled
-- too since some reverse proxies emit those. Anything stranger just
-- fails the hop (better to stop than to build a bogus URL and 404).
local function resolveLocation(base_url, location)
    if not location or location == "" then return nil end
    if location:match("^https?://") then return location end
    local scheme, host = base_url:match("^(https?://[^/]+)")
    if not scheme then return nil end
    if location:match("^//") then return (base_url:match("^(https?:)") or "http:") .. location end
    if location:match("^/") then return scheme .. location end
    return nil
end

--- True if url_a and url_b share a scheme+host (used to decide whether
-- our BookOrbit auth headers should follow a redirect -- they shouldn't
-- leak to a different host, e.g. a signed CDN/S3 URL).
local function sameOrigin(url_a, url_b)
    local origin_a = url_a and url_a:match("^https?://[^/]+")
    local origin_b = url_b and url_b:match("^https?://[^/]+")
    return origin_a ~= nil and origin_a == origin_b
end

--- Core request helper. Returns (ok, code_or_err, body, headers).
-- opts: { method, path, query, json_body, raw_sink, sink_factory,
--         extra_headers, full_url }
-- path is relative to the API base (e.g. "/koreader/users/auth"); pass
-- full_url instead to hit an absolute URL verbatim (e.g. a download link
-- returned by a previous response, if it's ever a full URL).
--
-- Redirects are followed manually (NOT via LuaSocket's own
-- `redirect = true`): that option re-issues the whole request but keeps
-- the SAME sink across every hop, so with a raw file sink the bytes of
-- the redirect response (however small -- some servers send a short
-- HTML body with a 301/302) and the bytes of the final response both
-- land in the same file, back to back. The result "downloads" fine (a
-- 2xx, no error) but is no longer valid image data, and RenderImage
-- silently fails to decode it later -- 100% of the time, for every
-- book, since every thumbnail request takes the same redirected path.
-- Callers that use raw_sink for a *file* download should pass
-- sink_factory instead: a function returning a fresh sink, called once
-- per hop, so a redirect can't corrupt the file. (Plain raw_sink is
-- still accepted for callers where redirects are never expected, but
-- prefer sink_factory for anything that writes to disk.)
local function request(opts)
    if not NetworkMgr:isOnline() then
        return false, "offline"
    end
    local cfg = BookOrbit.getConfig()
    if not cfg.server_url then return false, "not_configured" end

    local http, ltn12, socket, socketutil, json
    local ok_req = pcall(function()
        http       = require("socket/http")
        ltn12      = require("ltn12")
        socket     = require("socket")
        socketutil = require("socketutil")
        json       = require("json")
    end)
    if not ok_req then return false, "no_http_stack" end

    local url = opts.full_url or (apiBase(cfg.server_url) .. opts.path)
    if opts.query then
        local parts = {}
        for k, v in pairs(opts.query) do
            if v ~= nil and v ~= "" then
                parts[#parts + 1] = tostring(k) .. "=" .. tostring(v):gsub("[^%w%-_.~]", function(c)
                    return string.format("%%%02X", c:byte())
                end)
            end
        end
        if #parts > 0 then
            url = url .. (url:find("?") and "&" or "?") .. table.concat(parts, "&")
        end
    end

    local base_headers = {
        ["User-Agent"] = "KOReader-Bookshelf-BookOrbit",
        ["Accept"]     = "application/json",
    }
    if cfg.username and cfg.password then
        base_headers["x-auth-user"] = cfg.username
        base_headers["x-auth-key"]  = md5hex(cfg.password)
    end
    if opts.extra_headers then
        for k, v in pairs(opts.extra_headers) do base_headers[k] = v end
    end

    local request_body
    if opts.json_body then
        request_body = json.encode(opts.json_body)
    end

    local hop_url = url
    local first_url = url
    local code, resp_headers, body
    local MAX_HOPS = 5
    for hop = 1, MAX_HOPS do
        local headers = {}
        for k, v in pairs(base_headers) do headers[k] = v end
        if request_body then
            headers["Content-Type"] = "application/json"
            headers["Content-Length"] = tostring(#request_body)
        end
        -- Don't forward BookOrbit credentials to a different host a
        -- redirect sends us to (e.g. a signed CDN URL for a thumbnail).
        if hop > 1 and not sameOrigin(first_url, hop_url) then
            headers["x-auth-user"], headers["x-auth-key"] = nil, nil
        end

        local response_body
        local sink
        if opts.sink_factory then
            local ok_sink, made_sink = pcall(opts.sink_factory)
            if not ok_sink or not made_sink then
                return false, tostring(made_sink or "sink_factory_error")
            end
            sink = made_sink
        elseif opts.raw_sink then
            sink = opts.raw_sink
        else
            response_body = {}
            sink = ltn12.sink.table(response_body)
        end

        local ok, hop_code, hop_headers = pcall(function()
            socketutil:set_timeout(socketutil.LARGE_BLOCK_TIMEOUT, socketutil.LARGE_TOTAL_TIMEOUT)
            local c, h = socket.skip(1, http.request({
                url      = hop_url,
                method   = opts.method or "GET",
                headers  = headers,
                source   = request_body and ltn12.source.string(request_body) or nil,
                sink     = sink,
                redirect = false,
            }))
            socketutil:reset_timeout()
            return c, h
        end)
        if not ok then
            logger.warn("BookOrbit: request failed", hop_url, hop_code)
            return false, hop_code
        end
        -- A failed connection (bad TLS handshake/cert, DNS failure,
        -- connection refused, etc.) doesn't raise a Lua error here --
        -- LuaSocket's http.request just returns nil plus a string
        -- reason, which surfaces as a non-numeric `code` rather than an
        -- HTTP status. Mirrors the same guard in BookOrbit's own
        -- official plugin (bookorbit_api.lua).
        if type(hop_code) ~= "number" then
            logger.warn("BookOrbit: transport error", hop_url, hop_code)
            return false, tostring(hop_code or "network_error")
        end

        if hop_code == 301 or hop_code == 302 or hop_code == 303
                or hop_code == 307 or hop_code == 308 then
            local location = hop_headers and (hop_headers.location or hop_headers.Location)
            local next_url = resolveLocation(hop_url, location)
            if not next_url then
                logger.warn("BookOrbit: redirect with no usable Location", hop_url, hop_code)
                code, resp_headers = hop_code, hop_headers
                break
            end
            hop_url = next_url
            -- 303 always downgrades to GET; 301/302 conventionally do
            -- too for a non-GET/HEAD request (matches every browser and
            -- LuaSocket's own built-in redirect handling).
            if hop_code == 303 or ((hop_code == 301 or hop_code == 302)
                    and opts.method and opts.method ~= "GET" and opts.method ~= "HEAD") then
                opts = setmetatable({ method = "GET" }, { __index = opts })
                request_body = nil
            end
            -- loop again with a fresh sink for the next hop
        else
            code, resp_headers = hop_code, hop_headers
            if not opts.raw_sink and not opts.sink_factory and type(response_body) == "table" then
                body = table.concat(response_body)
            end
            break
        end
    end
    if not code then
        return false, "too_many_redirects"
    end
    return true, code, body, resp_headers
end

--- GET/PUT/POST helper that also JSON-decodes a 2xx body. Returns
-- decoded_body, err (err is an HTTP status number or a string like
-- "offline"/"not_configured"/"invalid_json").
local function jsonRequest(opts)
    local ok, code, body = request(opts)
    if not ok then return nil, code end
    if code == 401 or code == 403 then return nil, code end
    if code < 200 or code >= 300 then return nil, code end
    if not body or body == "" then return {}, nil end
    local ok_json, json = pcall(require, "json")
    if not ok_json then return nil, "no_json_lib" end
    local ok_decode, data = pcall(json.decode, body)
    if not ok_decode or type(data) ~= "table" then return nil, "invalid_json" end
    return data, nil
end

-- ---------------------------------------------------------------------
-- Book identity (mirrors bookshelf_book_repository's enrichStats pattern)
-- ---------------------------------------------------------------------

function BookOrbit.getBookHash(filepath)
    if not filepath then return nil end
    local hash
    local ok_ds, DocSettings = pcall(require, "docsettings")
    if ok_ds and DocSettings then
        local ok_open, ds = pcall(function() return DocSettings:open(filepath) end)
        if ok_open and ds and ds.readSetting then
            hash = ds:readSetting("partial_md5_checksum")
        end
    end
    if not hash then
        local ok_util, u = pcall(require, "util")
        if ok_util and u and u.partialMD5 then
            hash = u.partialMD5(filepath)
        end
    end
    return hash
end

-- ---------------------------------------------------------------------
-- Auth test
-- ---------------------------------------------------------------------

--- Verifies server_url/username/password work, without saving them.
-- Returns ok(bool), message(string).
function BookOrbit.testConnection(server_url, username, password)
    server_url = (server_url or ""):gsub("/+$", "")
    if server_url == "" or not username or username == "" or not password or password == "" then
        return false, "Server URL, username, and password are all required."
    end
    if not NetworkMgr:isOnline() then
        return false, "No network connection."
    end
    -- Temporarily swap in the candidate credentials for one probe request
    -- without persisting them.
    local saved = _settings
    _settings = LuaSettings:open(SETTINGS_FILE .. ".probe.tmp")
    _settings:saveSetting("server_url", server_url)
    _settings:saveSetting("username", username)
    _settings:saveSetting("password", password)
    local ok, code, body = request{ method = "GET", path = AUTH_PATH }
    _settings = saved
    os.remove(SETTINGS_FILE .. ".probe.tmp")

    if not ok then
        if code == "offline" then return false, "No network connection." end
        return false, "Could not reach " .. server_url .. " (" .. tostring(code) .. ")."
    end
    if code == 401 or code == 403 then
        return false, "Server rejected the username/password."
    end
    if code ~= 200 then
        return false, "Unexpected response from server (HTTP " .. tostring(code) .. "). "
            .. "Check the server URL, or that " .. apiBase(server_url) .. AUTH_PATH .. " is reachable. "
            .. tostring(body or "")
    end
    return true, "Connected."
end

-- ---------------------------------------------------------------------
-- Progress sync
-- ---------------------------------------------------------------------

--- Push this device's current position for a book.
-- percentage: 0.0-1.0 float. progress: an opaque position string (KOReader
-- convention: xpointer for EPUB, page number as string for PDF/DjVu/etc).
function BookOrbit.pushProgress(filepath, percentage, progress)
    if not BookOrbit.isConfigured() then return false, "not_configured" end
    local hash = BookOrbit.getBookHash(filepath)
    if not hash then return false, "no_hash" end
    local cfg = BookOrbit.getConfig()
    local ok, code, body = request{
        method = "PUT",
        path   = PROGRESS_PATH,
        json_body = {
            document   = hash,
            progress   = tostring(progress or ""),
            percentage = percentage,
            device     = Device.model,
            device_id  = cfg.device_id,
            timestamp  = os.time(),
        },
    }
    if ok and (code == 200 or code == 201) then return true end
    logger.info("BookOrbit: pushProgress failed", code, body)
    return false, code
end

--- Pull the latest known progress for a book. Returns a table
-- {percentage, progress, device, timestamp} or nil if none / on error.
function BookOrbit.pullProgress(filepath)
    if not BookOrbit.isConfigured() then return nil end
    local hash = BookOrbit.getBookHash(filepath)
    if not hash then return nil end
    local data, err = jsonRequest{ method = "GET", path = PROGRESS_PATH .. "/" .. hash }
    if not data then
        if err then logger.info("BookOrbit: pullProgress failed", err) end
        return nil
    end
    return data
end

--- Not implemented: the real server's stats endpoint takes a batch of
-- pre-aggregated per-book page-stat records with device metadata attached,
-- not a single reading-session snapshot. Kept as a stub so callers that
-- guard on isConfigured() don't error if this is ever wired up.
function BookOrbit.pushStats(_session)
    return false, "not_implemented"
end

-- ---------------------------------------------------------------------
-- Catalog (JSON REST, NOT OPDS -- see header comment)
-- ---------------------------------------------------------------------

--- GET /koreader/plugin/catalog/root. Returns { sections = {{section, title}, ...} }.
function BookOrbit.catalogRoot()
    return jsonRequest{ method = "GET", path = CATALOG_ROOT_PATH }
end

--- GET /koreader/plugin/catalog/sections/<section>. params: { page, q }.
-- Returns { items = {{id, title, count, seriesId, ...}}, page, hasNext, query }.
function BookOrbit.catalogSection(section, params)
    return jsonRequest{ method = "GET", path = CATALOG_SECTION_PATH .. section, query = params }
end

--- GET /koreader/plugin/catalog/books. params may include: page, size,
-- sort, order, q, libraryId, collectionId, smartScopeId, author, series,
-- seriesId, readStatus, format, ids.
-- Returns { items = {{id, title, authors={}, formats={}, seriesName,
--           seriesIndex, progressPercentage, readStatus, ...}}, page, hasNext }.
function BookOrbit.catalogBooks(params)
    return jsonRequest{ method = "GET", path = CATALOG_BOOKS_PATH, query = params }
end

--- GET /koreader/plugin/catalog/books/<id>. Returns book detail including
-- files = {{id, format, sizeBytes, role}}.
function BookOrbit.catalogBook(book_id)
    local cfg = BookOrbit.getConfig()
    return jsonRequest{
        method = "GET",
        path = CATALOG_BOOK_PATH .. tostring(book_id),
        query = { deviceId = cfg.device_id },
    }
end

--- GET /koreader/plugin/catalog/books/<id>/thumbnail -- a cover image for
-- one catalog book. Mirrors the official plugin's
-- BookOrbitApi:downloadCatalogThumbnail. Returns true, resp_headers on
-- success (headers included so a caller whose RenderImage decode still
-- fails afterwards can log Content-Type/Content-Encoding to see WHAT
-- actually landed on disk, instead of just "didn't decode"), or nil, err.
function BookOrbit.downloadCatalogThumbnail(book_id, dest_path)
    local ltn12_ok, ltn12 = pcall(require, "ltn12")
    if not ltn12_ok then return nil, "no_http_stack" end
    local ok, code, _body, headers = request{
        method = "GET",
        path   = CATALOG_BOOK_PATH .. tostring(book_id) .. "/thumbnail",
        sink_factory = function()
            local fh, open_err = io.open(dest_path, "wb")
            if not fh then error(open_err or "open_error") end
            return ltn12.sink.file(fh)
        end,
        -- Accept-Encoding: identity matters here: without it, a gzipping
        -- reverse proxy can hand back compressed bytes straight into this
        -- raw file sink (LuaSocket doesn't inflate for us) -- the download
        -- "succeeds" (200, bytes on disk) but the file isn't a valid JPEG,
        -- so RenderImage silently fails to decode it later. Matches the
        -- header set our own downloadCatalogFile (and the official
        -- plugin's BookOrbitApi:download) already use for this reason.
        extra_headers = { ["Accept"] = "image/jpeg,image/*", ["Accept-Encoding"] = "identity" },
    }
    if ok and code == 200 then return true, headers end
    os.remove(dest_path)
    if not ok then return nil, code end
    return nil, "http_" .. tostring(code)
end

-- ---------------------------------------------------------------------
-- Shared download-destination helpers (used by both the plain-menu
-- catalog browser and the chip-source grid browser, so a book saved
-- from either path lands in the same place with the same naming rules).
-- ---------------------------------------------------------------------

function BookOrbit.defaultDownloadDir()
    local DataStorage = require("datastorage")
    local ok_settings, LuaSettingsMod = pcall(require, "luasettings")
    local ok_g, G_reader_settings = pcall(function()
        return ok_settings and LuaSettingsMod
            and LuaSettingsMod:open(DataStorage:getSettingsDir() .. "/g_reader_settings.lua")
    end)
    local home = ok_g and G_reader_settings and G_reader_settings:readSetting("home_dir")
    return home or DataStorage:getFullDataDir()
end

--- Returns the user-chosen download folder (Bookshelf menu -> BookOrbit ->
-- Download folder), or nil if never set / no longer valid.
function BookOrbit.getDownloadDir()
    local dir = settings():readSetting("download_dir")
    if not dir or dir == "" then return nil end
    local lfs_ok, lfs = pcall(require, "libs/libkoreader-lfs")
    if lfs_ok and lfs.attributes(dir, "mode") ~= "directory" then
        -- Chosen folder vanished (SD card removed, etc.) -- fall back
        -- silently rather than erroring on every download.
        return nil
    end
    return dir
end

--- Persists the download folder override. Pass nil/"" to clear it and
-- go back to auto-detecting (home_dir, then the full data dir).
function BookOrbit.setDownloadDir(dir)
    local s = settings()
    if dir and dir ~= "" then
        s:saveSetting("download_dir", dir)
    else
        s:delSetting("download_dir")
    end
    s:flush()
    _settings = nil
end

--- The folder BookOrbit downloads should actually land in: the user's
-- explicit choice if one is set and still valid, else the auto-detected
-- default. Both the plain-menu catalog browser and the chip-source grid
-- browser call this (not defaultDownloadDir directly) so a folder picked
-- in Bookshelf menu -> BookOrbit -> Download folder applies everywhere.
function BookOrbit.downloadDir()
    return BookOrbit.getDownloadDir() or BookOrbit.defaultDownloadDir()
end

function BookOrbit.sanitizeFilename(name)
    name = (name or "book"):gsub('[/\\:*?"<>|]', "_"):gsub("%s+", " "):gsub("^%s+", ""):gsub("%s+$", "")
    if name == "" then name = "book" end
    return name
end

--- Returns the directory a book should actually be downloaded into: `dir`
-- with an Author/Series subfolder appended when the book carries that
-- metadata, e.g. "<dir>/Douglas Adams/Hitchhiker's Guide to the Galaxy".
-- Creates the subfolder (mkdir -p) if needed. Falls back to `dir` itself
-- when the book has no author, or the subfolder can't be created.
-- `book` is anything shaped like a catalog list item or catalogBook()
-- detail table -- both use `authors` (array) and `seriesName`.
function BookOrbit.downloadDestDir(dir, book)
    book = book or {}
    local author = book.authors and book.authors[1]
    if not author or author == "" then return dir end

    local sub = dir .. "/" .. BookOrbit.sanitizeFilename(author)
    local series = book.seriesName
    if series and series ~= "" then
        sub = sub .. "/" .. BookOrbit.sanitizeFilename(series)
    end

    local ok_util, util = pcall(require, "util")
    if ok_util and util.makePath then
        util.makePath(sub)
    end

    local lfs_ok, lfs = pcall(require, "libs/libkoreader-lfs")
    if lfs_ok and lfs.attributes(sub, "mode") ~= "directory" then
        -- Couldn't create it (read-only fs, bad chars survived sanitizing,
        -- etc.) -- fall back to the plain download folder rather than
        -- erroring the whole download out.
        return dir
    end
    return sub
end

--- Returns a path in `dir` for `base.ext` that doesn't already exist,
-- appending " (n)" as needed.
function BookOrbit.uniqueDownloadPath(dir, base, ext)
    local path = dir .. "/" .. base .. "." .. ext
    local lfs_ok, lfs = pcall(require, "libs/libkoreader-lfs")
    if not lfs_ok then return path end
    local n = 1
    while lfs.attributes(path) do
        path = dir .. "/" .. base .. " (" .. n .. ")." .. ext
        n = n + 1
    end
    return path
end

--- Download a catalog file to dest_path. Returns true, or nil, err.
function BookOrbit.downloadCatalogFile(file_id, dest_path, progress_cb)
    local ltn12_ok, ltn12 = pcall(require, "ltn12")
    if not ltn12_ok then return nil, "no_http_stack" end

    local ok, code = request{
        method = "GET",
        path = CATALOG_FILE_PATH .. tostring(file_id) .. "/download",
        sink_factory = function()
            local fh, open_err = io.open(dest_path, "wb")
            if not fh then error(open_err or "open_error") end
            local file_sink = ltn12.sink.file(fh)
            if not progress_cb then return file_sink end
            local received = 0
            return function(chunk, err)
                if chunk and chunk ~= "" then
                    received = received + #chunk
                    progress_cb(received)
                end
                return file_sink(chunk, err)
            end
        end,
        extra_headers = { ["Accept"] = "application/octet-stream", ["Accept-Encoding"] = "identity" },
    }
    if ok and code == 200 then return true end
    os.remove(dest_path)
    if not ok then return nil, code end
    return nil, "http_" .. tostring(code)
end

return BookOrbit
