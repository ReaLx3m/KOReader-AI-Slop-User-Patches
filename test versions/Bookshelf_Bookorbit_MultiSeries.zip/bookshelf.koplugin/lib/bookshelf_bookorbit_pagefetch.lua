--[[--
Page-list fetcher for BookOrbit (pure logic, no KOReader dependency).

Problem (see HANDOFF_cover_speed, phase 2): on a cache MISS, BOSource.listBooks
made a blocking catalogBooks() request on the UI thread with the LARGE timeout,
so a page turn / chip switch froze until the list arrived, and the next-page
PRELOAD did the same thing 0.8-5.7 s at a time. This object runs those requests
through forked workers instead, a couple at a time. The worker writes the
response body to a file; the parent loads it (decode, toRecord, cache write)
one job per timer tick.

Everything it touches is passed in, so it can be tested off-device with fake
forks and a fake clock (tools/bo_tests/test_bo_pagefetch.lua). NOT wired into
the UI yet (Batch 6). Same shape as bookshelf_bookorbit_coverpool.lua.

  local F = PageFetch.new{
    now = function() return seconds end,
    schedule = function(delay, fn) return handle end,   -- handle must be non-nil
    unschedule = function(handle) end,
    online = function() return bool end,
    exists = function(path) return bool end,
    describe = function(req) -> { key=, path=, part= } | nil,
    spawn = function(job) -> pid, fd | nil, err,
    is_done = function(pid) -> bool,
    readable = function(fd) -> bool,
    read = function(fd) -> string,
    kill = function(pid),
    remove = function(path),
    load = function(job) -> bool,     -- parent: read job.path, decode, cache; false = bad body
    on_ready = function(info, ok, why),
    on_worker = function(info),       -- optional, log only: { key=, ms=, result= }
    width = 2, deadline = 30, fail_retry_after = 10, logger = optional (needs :dbg)
  }

  F:request(req) -> "queued" | "joined" | "failed" | "offline" | "fork_broken" | "invalid" | "busy"
  F:status(key)  -> "none" | "pending" | "loading" | "failed"
  F:cancelPending()   -- drop PENDING jobs only (no callbacks); in-flight work goes on
  F:shutdown()        -- kill in-flight workers, drop everything, no callbacks
  F:resetFailures()   -- forget failed keys and retry counts (manual refresh)
  F:counts()          -- numbers, for tests and logs; `urgent` = urgent jobs still waited for
                      -- (queued, in flight, loading or awaiting on_ready): the prefetch asks this

`req` is whatever the caller wants (id / offset / limit ...); the module only
reads `req.urgent` (true = a render path is waiting for this page, false/nil =
a background preload) and passes req on to `describe`.

Rules (decisions C13-C19 in the handoff):
  * One job per key. A second request for a key that is pending, in flight or
    waiting to be loaded JOINS it (answer "joined", no second fork). Joining
    with an urgent request makes the job urgent.
  * Pending order: urgent jobs first, newest first within each class. At most
    MAX_PENDING jobs wait; beyond that the OLDEST non-urgent one is dropped
    (silently: nobody is waiting for it). Urgent jobs are never dropped.
  * Width starts at `width` (default 2) and halves after a timeout (floor 1);
    it resets when everything has drained.
  * The worker writes the body to `part` and renames it to `path` on success;
    it reports exactly "1" or "nf:<why>". The module trusts "1" only if
    `exists(path)`. "nf:offline" is not a failure of the page.
  * Failures: "nf:<why>" (server said no), a bad body (`load` false), a
    timeout, or a second crash report on_ready(info, false, why) and mark the
    key failed. A failed key answers "failed" to request() for
    `fail_retry_after` seconds (so the rebuild that follows the failure cannot
    start a retry loop), then a new request starts a fresh attempt.
    resetFailures() clears it at once. A first crash is retried once
    automatically. Nothing failed is ever cached by this module.
  * Offline: request() answers "offline"; waiting jobs are reported as
    on_ready(info, false, "offline") (not a failure, not sticky) and nothing
    is launched.
  * A spawn that returns no pid (no fork available) sets fork_broken: every
    waiting job is reported on_ready(info, false, "fork_broken") and later
    request() calls answer "fork_broken" so the caller uses its blocking path.
  * Callbacks (`on_ready`) are only ever fired from timers, never from
    request/cancelPending/shutdown, so a callback may call request() again.
  * `load` runs at most once per timer tick (LOAD_TICK), in the parent.
  * Killed pids are re-checked every second until `is_done` says so.
  * Every dep call is pcall-wrapped.
]]

local PageFetch = {}
PageFetch.__index = PageFetch

PageFetch.DEFAULT_WIDTH = 2
PageFetch.DEFAULT_DEADLINE = 30
PageFetch.DEFAULT_FAIL_RETRY_AFTER = 10
PageFetch.MAX_PENDING = 4
PageFetch.POLL = 0.15
PageFetch.FIRST_POLL = 0.02
PageFetch.LOAD_TICK = 0.02
PageFetch.REAP_TICK = 1
PageFetch.MAX_CRASH_TRIES = 2
PageFetch.OK = "1"
PageFetch.FAIL_PREFIX = "nf:"

function PageFetch.new(deps)
    deps = deps or {}
    local self = setmetatable({}, PageFetch)
    self.d = deps
    self.base_width = math.max(1, math.floor(tonumber(deps.width) or PageFetch.DEFAULT_WIDTH))
    self.deadline = tonumber(deps.deadline) or PageFetch.DEFAULT_DEADLINE
    self.fail_retry_after = tonumber(deps.fail_retry_after) or PageFetch.DEFAULT_FAIL_RETRY_AFTER
    self.cap = self.base_width
    self.pending = {}          -- jobs waiting for a worker, in launch order
    self.in_flight = {}        -- { pid=, fd=, job=, t0= }
    self.ready_q = {}          -- jobs whose body file is on disk, waiting for load
    self.report_q = {}         -- { job=, ok=, why= } waiting for an on_ready tick
    self.by_key = {}           -- key -> job (pending, in flight or ready_q)
    self.reap = {}             -- pids that must still be collected
    self.crashes = {}          -- key -> crash reports this session
    self.failed = {}           -- key -> { t=, why= }
    self.chain_active = false
    self.fork_broken = false
    self.poll_h, self.load_h, self.report_h, self.reap_h = nil, nil, nil, nil
    return self
end

-- Safe call into a dep: never throws. Returns ok, a, b.
local function call(self, name, ...)
    local fn = self.d[name]
    if type(fn) ~= "function" then return false end
    return pcall(fn, ...)
end

local function nowOf(self)
    local ok, t = call(self, "now")
    return (ok and tonumber(t)) or 0
end

local function dbg(self, ...)
    local lg = self.d.logger
    if lg and lg.dbg then pcall(lg.dbg, ...) end
end

local function removeFirst(list, item)
    for i = 1, #list do
        if list[i] == item then table.remove(list, i); return true end
    end
    return false
end

local function workerDone(self, e, result)
    if type(self.d.on_worker) ~= "function" then return end
    local ms = (nowOf(self) - (e.t0 or 0)) * 1000
    call(self, "on_worker", { key = e.job and e.job.key, ms = ms, result = result })
end

-- Timers -----------------------------------------------------------------------

function PageFetch:_sched(fieldname, delay, fn)
    if self[fieldname] ~= nil then return end
    local ok, h = call(self, "schedule", delay, function()
        self[fieldname] = nil
        fn(self)
    end)
    if ok and h ~= nil then self[fieldname] = h end
end

function PageFetch:_unsched(fieldname)
    local h = self[fieldname]
    self[fieldname] = nil
    if h ~= nil then call(self, "unschedule", h) end
end

function PageFetch:_ensureTimers()
    if self.chain_active then self:_sched("poll_h", PageFetch.POLL, PageFetch._poll) end
    if #self.ready_q > 0 then self:_sched("load_h", PageFetch.LOAD_TICK, PageFetch._loadTick) end
    if #self.report_q > 0 then self:_sched("report_h", PageFetch.LOAD_TICK, PageFetch._reportTick) end
    if #self.reap > 0 then self:_sched("reap_h", PageFetch.REAP_TICK, PageFetch._reapTick) end
end

-- Zombie control ------------------------------------------------------------------

function PageFetch:_reapLater(pid)
    if pid == nil then return end
    self.reap[#self.reap + 1] = pid
end

function PageFetch:_reapTick()
    local keep = {}
    for _, pid in ipairs(self.reap) do
        local ok, done = call(self, "is_done", pid)
        if not (ok and done) then keep[#keep + 1] = pid end
    end
    self.reap = keep
    self:_ensureTimers()
end

-- Job bookkeeping -------------------------------------------------------------------

local function isUrgent(job) return job.urgent == true end

-- Insert a job into the pending list: urgent first, newest first in each class.
function PageFetch:_insertPending(job)
    local pos = 1
    if not isUrgent(job) then
        while pos <= #self.pending and isUrgent(self.pending[pos]) do pos = pos + 1 end
    end
    table.insert(self.pending, pos, job)
end

-- Keep the pending list within MAX_PENDING by dropping the OLDEST non-urgent job.
function PageFetch:_trimPending()
    while #self.pending > PageFetch.MAX_PENDING do
        local victim
        for i = #self.pending, 1, -1 do
            if not isUrgent(self.pending[i]) then victim = i; break end
        end
        if not victim then return end   -- only urgent jobs left: keep them all
        local job = table.remove(self.pending, victim)
        self.by_key[job.key] = nil
        dbg(self, "[bookshelf perf] bo page: dropped old preload", job.key)
    end
end

function PageFetch:_report(job, ok, why)
    self.by_key[job.key] = nil
    self.report_q[#self.report_q + 1] = { job = job, ok = ok, why = why }
end

function PageFetch:_markFailed(job, why)
    self.failed[job.key] = { t = nowOf(self), why = why }
    self:_report(job, false, why)
end

-- Public: request / cancel / shutdown ---------------------------------------------------

function PageFetch:request(req)
    if self.fork_broken then return "fork_broken" end
    local okd, d = call(self, "describe", req)
    if not (okd and type(d) == "table" and d.key ~= nil and d.path) then return "invalid" end
    local urgent = type(req) == "table" and req.urgent == true

    local existing = self.by_key[d.key]
    if existing then
        existing.reqs[#existing.reqs + 1] = req
        if urgent and not existing.urgent then
            existing.urgent = true
            -- A pending job that just became urgent moves up the queue.
            if removeFirst(self.pending, existing) then self:_insertPending(existing) end
        end
        return "joined"
    end

    local f = self.failed[d.key]
    if f then
        if (nowOf(self) - f.t) < self.fail_retry_after then return "failed" end
        self.failed[d.key] = nil
        self.crashes[d.key] = nil
    end

    local okn, on = call(self, "online")
    if not (okn and on) then return "offline" end

    local job = {
        key = d.key, path = d.path, part = d.part,
        req = req, reqs = { req }, urgent = urgent,
    }
    self.by_key[job.key] = job
    self:_insertPending(job)
    self:_trimPending()
    if self.by_key[job.key] ~= job then
        return "busy"      -- a background request that did not fit (queue full of urgent jobs)
    end
    self.chain_active = true
    self:_sched("poll_h", PageFetch.FIRST_POLL, PageFetch._poll)
    self:_ensureTimers()
    return "queued"
end

function PageFetch:status(key)
    local job = self.by_key[key]
    if job then
        for _, p in ipairs(self.pending) do
            if p == job then return "pending" end
        end
        return "loading"
    end
    if self.failed[key] then return "failed" end
    return "none"
end

--- Drop PENDING jobs only. Never fires callbacks.
function PageFetch:cancelPending()
    for _, job in ipairs(self.pending) do self.by_key[job.key] = nil end
    self.pending = {}
    self:_ensureTimers()   -- the chain end is still detected on the next poll
end

--- Kill everything and stand down. Never fires callbacks.
function PageFetch:shutdown()
    for _, e in ipairs(self.in_flight) do
        call(self, "kill", e.pid)
        if e.fd then call(self, "read", e.fd) end
        if e.job.part then call(self, "remove", e.job.part) end
        self:_reapLater(e.pid)
    end
    for _, job in ipairs(self.ready_q) do
        if job.path then call(self, "remove", job.path) end
    end
    self.in_flight, self.pending, self.ready_q, self.report_q = {}, {}, {}, {}
    self.by_key = {}
    self:_unsched("poll_h")
    self:_unsched("load_h")
    self:_unsched("report_h")
    self.chain_active = false
    self.cap = self.base_width
    self:_ensureTimers()   -- keep the reaper alive until every pid is collected
end

function PageFetch:resetFailures()
    self.crashes, self.failed = {}, {}
end

function PageFetch:counts()
    -- urgent = jobs a render path is still waiting for: queued, in flight,
    -- waiting to be loaded, or loaded but not yet reported through on_ready.
    local urgent = 0
    for _, job in pairs(self.by_key) do
        if job.urgent == true then urgent = urgent + 1 end
    end
    for _, item in ipairs(self.report_q) do
        if item.job and item.job.urgent == true then urgent = urgent + 1 end
    end
    return {
        pending = #self.pending, in_flight = #self.in_flight, loading = #self.ready_q,
        reports = #self.report_q, reaping = #self.reap, cap = self.cap,
        fork_broken = self.fork_broken, chain_active = self.chain_active,
        urgent = urgent,
    }
end

-- Poll: collect finished workers, enforce the deadline, launch new ones ---------------------

function PageFetch:_narrow()
    local n = math.max(1, math.floor(self.cap / 2))
    if n < self.cap then
        dbg(self, "[bookshelf perf] bo page: pool narrowed", self.cap, "->", n)
    end
    self.cap = n
end

function PageFetch:_finishEntry(e, out, done)
    removeFirst(self.in_flight, e)
    local job = e.job
    if not done then self:_reapLater(e.pid) end

    if out == PageFetch.OK then
        workerDone(self, e, "ok")
        local ok, there = call(self, "exists", job.path)
        if ok and there then
            self.ready_q[#self.ready_q + 1] = job
        else
            if job.part then call(self, "remove", job.part) end
            self:_crashed(job, "missing")
        end
        return
    end
    if type(out) == "string" and out:sub(1, #PageFetch.FAIL_PREFIX) == PageFetch.FAIL_PREFIX then
        local why = out:sub(#PageFetch.FAIL_PREFIX + 1)
        workerDone(self, e, PageFetch.FAIL_PREFIX .. why)
        if job.part then call(self, "remove", job.part) end
        if why == "offline" then
            self:_report(job, false, "offline")     -- not a failure of the page
        else
            self:_markFailed(job, why)
        end
        return
    end
    -- Empty or unknown result from a finished worker: it crashed.
    workerDone(self, e, "crash")
    if job.part then call(self, "remove", job.part) end
    self:_crashed(job, "crash")
end

-- A crash (or an "ok" with no file): retry once automatically, then fail.
function PageFetch:_crashed(job, why)
    local n = (self.crashes[job.key] or 0) + 1
    self.crashes[job.key] = n
    if n >= PageFetch.MAX_CRASH_TRIES then
        self:_markFailed(job, why)
        return
    end
    self:_insertPending(job)   -- still registered in by_key
end

function PageFetch:_collect()
    local now = nowOf(self)
    local snapshot = {}
    for i, e in ipairs(self.in_flight) do snapshot[i] = e end
    for _, e in ipairs(snapshot) do
        local okd, done = call(self, "is_done", e.pid)
        done = okd and done and true or false
        local readable = false
        if e.fd then
            local okr, r = call(self, "readable", e.fd)
            readable = okr and r and true or false
        end
        if done or readable then
            local out = ""
            if e.fd then
                local okx, got = call(self, "read", e.fd)
                if okx and type(got) == "string" then out = got end
            end
            if out ~= "" or done then
                self:_finishEntry(e, out, done)
            end
        elseif (now - e.t0) > self.deadline then
            -- Hard deadline: kill, drop the half-written file, report failure.
            workerDone(self, e, "timeout")
            call(self, "kill", e.pid)
            if e.fd then call(self, "read", e.fd) end
            if e.job.part then call(self, "remove", e.job.part) end
            removeFirst(self.in_flight, e)
            self:_reapLater(e.pid)
            self:_narrow()
            self:_markFailed(e.job, "timeout")
        end
    end
end

function PageFetch:_launch()
    if not self.chain_active then return end
    local okn, on = call(self, "online")
    if not (okn and on) then
        -- Offline: never launch. Waiting jobs are told, without a failure mark.
        local waiting = self.pending
        self.pending = {}
        for _, job in ipairs(waiting) do self:_report(job, false, "offline") end
        return
    end
    while #self.in_flight < self.cap and #self.pending > 0 and not self.fork_broken do
        local job = table.remove(self.pending, 1)
        local oke, there = call(self, "exists", job.path)
        if oke and there then
            self.ready_q[#self.ready_q + 1] = job      -- a body is already waiting
        else
            local oks, pid, fd = call(self, "spawn", job)
            if not (oks and pid) then
                self.fork_broken = true
                self:_report(job, false, "fork_broken")
                local waiting = self.pending
                self.pending = {}
                for _, j in ipairs(waiting) do self:_report(j, false, "fork_broken") end
                break
            end
            self.in_flight[#self.in_flight + 1] = { pid = pid, fd = fd, job = job, t0 = nowOf(self) }
        end
    end
end

function PageFetch:_idleCheck()
    if not self.chain_active then return end
    if #self.pending > 0 or #self.in_flight > 0 or #self.ready_q > 0 or #self.report_q > 0 then return end
    self.chain_active = false
    self.cap = self.base_width
    self:_unsched("poll_h")
end

function PageFetch:_poll()
    self:_collect()
    self:_launch()
    self:_idleCheck()
    self:_ensureTimers()
end

-- Load: one body per tick, in the parent ----------------------------------------------------------

function PageFetch:_loadTick()
    local job = table.remove(self.ready_q, 1)
    if job then
        local ok, res = call(self, "load", job)
        if job.path then call(self, "remove", job.path) end
        if ok and res then
            self.crashes[job.key] = nil
            self:_report(job, true, nil)
        else
            self:_markFailed(job, "bad_body")
        end
    end
    self:_idleCheck()
    self:_ensureTimers()
end

-- Report: fire on_ready, one per tick, outside any API call ------------------------------------------

function PageFetch:_reportTick()
    local item = table.remove(self.report_q, 1)
    if item then
        local job = item.job
        local info = { key = job.key, req = job.req, reqs = job.reqs, urgent = job.urgent == true }
        -- The job left by_key when it was reported, so a callback that calls
        -- request() for the same key sees a settled state (failed / none).
        call(self, "on_ready", info, item.ok, item.why)
    end
    self:_idleCheck()
    self:_ensureTimers()
end

return PageFetch
