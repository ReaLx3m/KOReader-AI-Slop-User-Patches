--[[--
Decode-ahead holder for BookOrbit (pure logic, no KOReader dependency).

Problem (see HANDOFF_prefetch_decode_ahead): with "Prefetch next page" ON the
next page's covers are already DOWNLOADED when the user turns to it, but each
one still has to be decoded from disk (one per 20 ms tick) before the grid can
paint it. Decode-ahead decodes them in the background and attaches the bitmap
to the cached page records (cover_bb / cover_w / cover_h plus the _cover_filled
flag), so the turn paints at once.

A bitmap sitting on a CACHED record is invisible to the page cache's byte
budget (it counts a cdata bitmap as 8 bytes), so something has to bound it.
This object is that bound: it remembers which records of ONE prefetched page
carry a bitmap, refuses more than `max_records`, and releases them when the
page is replaced, the prefetch stops or the page cache is invalidated.

It decides nothing about WHEN; the source calls it. It never frees a bitmap
(a BlitBuffer has an ffi finalizer; a widget that already holds the bitmap
keeps it alive): it only DROPS the references, and it always drops the bitmap
AND the _cover_filled flag together. Leaving the flag set on a record without a
bitmap would make wantsCover() false forever: that book would never get a cover.

  local A = Ahead.new{
    held = function(record) -> bool,    -- optional; default: record.cover_bb ~= nil
    drop = function(record),            -- optional; default: Ahead.dropRecord
    bytes = function(record) -> n,      -- optional; default: Ahead.recordBytes
    max_records = 36,                   -- default Ahead.DEFAULT_MAX_RECORDS
    logger = optional (needs :dbg),
  }

  A:beginPage(page_id) -> n   -- release what is held for a DIFFERENT page (n records
                              -- dropped), then start a new generation. Same id: no-op, 0.
  A:add(record, page_id) -> bool
                              -- register a record that just got a bitmap. Idempotent.
                              -- false (nothing registered) when: not a table, it holds
                              -- nothing, page_id is given and is not the current page
                              -- (a stale download landing late), or max_records is reached.
                              -- The caller must then NOT keep the bitmap attached.
  A:release() -> n            -- drop every still-held record, forget the page (n dropped)
  A:currentPage() -> page_id | nil   -- cheap: no scan (the decode checks it per record)
  A:stats() -> { page=, records=, held=, bytes= }

Rules:
  * Only records that are STILL held are dropped. A record the widget already
    consumed (cover_bb nil, _cover_filled true) is left exactly as it is.
  * release() forgets the page id, so a stale add(record, old_page_id) that
    arrives after it is refused.
  * A throwing dep never breaks the caller: errors are swallowed (and logged).
]]

local Ahead = {}
Ahead.__index = Ahead

Ahead.DEFAULT_MAX_RECORDS = 36

--- Default `held`: the record carries a bitmap.
function Ahead.recordHeld(rec)
    return type(rec) == "table" and rec.cover_bb ~= nil
end

--- Default `drop`: forget the bitmap AND the filled flag together, never free it.
function Ahead.dropRecord(rec)
    if type(rec) ~= "table" then return end
    rec.cover_bb = nil
    rec.cover_w = nil
    rec.cover_h = nil
    rec._cover_filled = nil
end

--- Default `bytes`: stride * height of the bitmap (0 when it cannot be told).
function Ahead.recordBytes(rec)
    if type(rec) ~= "table" or rec.cover_bb == nil then return 0 end
    local bb = rec.cover_bb
    local stride = bb.stride
    local h = bb.h
    if h == nil and type(bb.getHeight) == "function" then
        local ok, v = pcall(bb.getHeight, bb)
        if ok then h = v end
    end
    if h == nil then h = rec.cover_h end
    -- LuaJIT: bb.stride is a 64-bit size_t cdata, not a Lua number, so type()
    -- would reject it (the old "bytes=0" log). tonumber() turns the cdata (and
    -- plain numbers) into a number and gives nil for anything else.
    stride = tonumber(stride)
    h = tonumber(h)
    if stride and h then return stride * h end
    return 0
end

function Ahead.new(deps)
    deps = deps or {}
    local self = setmetatable({}, Ahead)
    self.d = deps
    self.max_records = math.max(1, math.floor(tonumber(deps.max_records) or Ahead.DEFAULT_MAX_RECORDS))
    self.page = nil
    self.list = {}      -- registered records, in order
    self.set = {}       -- record -> true
    return self
end

local function call(self, name, fallback, ...)
    local fn = self.d[name] or fallback
    local ok, res = pcall(fn, ...)
    if not ok then
        local lg = self.d.logger
        if lg and lg.dbg then pcall(lg.dbg, lg, "ahead: dep failed", name, tostring(res)) end
        return false, nil
    end
    return true, res
end

local function isHeld(self, rec)
    local ok, res = call(self, "held", Ahead.recordHeld, rec)
    return ok and res and true or false
end

-- Drop every registered record that is still held; forget all of them.
local function releaseAll(self)
    local dropped = 0
    for _, rec in ipairs(self.list) do
        if isHeld(self, rec) then
            call(self, "drop", Ahead.dropRecord, rec)
            dropped = dropped + 1
        end
    end
    self.list, self.set = {}, {}
    return dropped
end

function Ahead:beginPage(page_id)
    if page_id == self.page then return 0 end
    local dropped = releaseAll(self)
    self.page = page_id
    return dropped
end

function Ahead:add(record, page_id)
    if type(record) ~= "table" then return false end
    if page_id ~= nil and page_id ~= self.page then return false end
    if self.set[record] then return true end
    if not isHeld(self, record) then return false end
    if #self.list >= self.max_records then return false end
    self.list[#self.list + 1] = record
    self.set[record] = true
    return true
end

function Ahead:release()
    local dropped = releaseAll(self)
    self.page = nil
    return dropped
end

function Ahead:currentPage()
    return self.page
end

function Ahead:stats()
    local held, bytes = 0, 0
    for _, rec in ipairs(self.list) do
        if isHeld(self, rec) then
            held = held + 1
            local ok, n = call(self, "bytes", Ahead.recordBytes, rec)
            if ok and type(n) == "number" then bytes = bytes + n end
        end
    end
    return { page = self.page, records = #self.list, held = held, bytes = bytes }
end

return Ahead
