--[[
bookshelf_bookorbit_source.lua — bridges a BookOrbit server's catalog into
Bookshelf's chip/source system, the same role bookshelf_kobo_source.lua
plays for the Kobo virtual library: it is the ONLY point of contact between
Repo.getBySource / the chip editor and lib/bookshelf_bookorbit.lua's HTTP
client, so callers never touch BookOrbit directly.

Where this differs from the Kobo bridge: Kobo's virtual library is local and
synchronous (decrypt-on-demand); BookOrbit's catalog is a REMOTE, PAGED list,
and its covers are separate network downloads. So instead of one
`listBooks()` that returns everything, this module fetches one page at a
time (`listBooks(id, offset, limit)`), and `coverBB` downloads (and disk-
caches) a thumbnail synchronously the first time a given book is asked for —
the same "blocking network call from a UI callback" style already used by
bookshelf_bookorbit_catalog.lua and bookshelf_cover_fetch.lua elsewhere in
this plugin, so a chip switch or page turn costs one request per book
whose cover isn't cached yet, then nothing on repaint.

Chip "source.id" encoding: "<query>:<rest>", e.g. "all:", "recent:",
"continue:", "libraries:42", "collections:7", "smart-scopes:3",
"authors:Iain M. Banks", "series:Culture". Built by the chip editor's
BookOrbit picker (encodeId below); decoded here into a catalogBooks() query.
This mirrors bookshelf_bookorbit_catalog.lua's paramsForEntry, independently,
since that file is a separate, already-shipped browsing UI this integration
does not touch.
]]

local BookOrbit = require("lib/bookshelf_bookorbit")
local Cache     = require("lib/bookshelf_bookorbit_cache")
local GroupCoverCache = require("lib/bookshelf_group_cover_cache")
local BookshelfSettings = require("lib/bookshelf_settings_store")
local _         = require("lib/bookshelf_i18n").gettext
-- Only used to derive a "given name" sort key for the Authors group-root's
-- folder tiles (see listGroups below) -- pcall'd the same defensive way
-- bookshelf_sort_engine.lua requires it, so a missing/renamed module just
-- degrades that one sort back to server order instead of erroring the
-- whole source.
local ok_author_name, AuthorName = pcall(require, "lib/bookshelf_author_name")

local M = {}

function M.isAvailable()
    return BookOrbit.isConfigured()
end

-- ---------------------------------------------------------------------
-- Source id encode/decode
-- ---------------------------------------------------------------------

-- Root-level "special" sections that page straight into catalogBooks
-- without a section/entry drill-down.
local ROOT_SPECIAL = {
    ["all"]      = true,
    ["recent"]   = true,
    ["continue"] = true,
    ["discover"] = true,
}

function M.encodeId(query, rest)
    return tostring(query or "all") .. ":" .. tostring(rest or "")
end

function M.decodeId(id)
    local query, rest = (id or ""):match("^([^:]*):(.*)$")
    if not query or query == "" then return "all", "" end
    return query, rest
end

-- Sections that can be browsed as live folder tiles in the shelf grid
-- (see isGroupRoot/groupSection/listGroups further below), keyed by the
-- id query token their "Browse as folders" picker row uses, valued by
-- the real catalogSection()/catalogBooks() section name to walk.
--
-- Authors and Series aren't in here: their existing "All <title>" row
-- (the plain M.encodeId(section, "") id, same as every other section
-- gets below) has meant "browse as folders" ever since isGroupRoot was
-- introduced, and that's unchanged -- adding them here too would just
-- give them a second, redundant picker row.
--
-- Libraries/Collections/SmartScopes get a SEPARATE id+row instead of
-- reusing their own "All <title>" id, specifically so any chip already
-- pinned to that id keeps its current flat, ungrouped book list --
-- widening isGroupRoot to match their bare id too would have silently
-- turned an existing "All Libraries" chip into a folder view underneath
-- whoever already had it pinned.
local GROUPED_SECTION_QUERY = {
    ["libraries-groups"]    = "libraries",
    ["collections-groups"]  = "collections",
    ["smart-scopes-groups"] = "smart-scopes",
}

-- Builds the catalogBooks() query table for one chip's source.id.
function M.queryForId(id)
    local query, rest = M.decodeId(id)
    if query == "recent" then
        return { sort = "recently_added" }
    elseif query == "continue" then
        return { sort = "recently_read", readStatus = "reading" }
    elseif query == "libraries" then
        return { libraryId = rest, sort = "title" }
    elseif query == "collections" then
        return { collectionId = rest, sort = "title" }
    elseif query == "smart-scopes" then
        return { smartScopeId = rest, sort = "title" }
    elseif query == "authors" then
        -- "series" (not "title") so a drilled-in single-author chip --
        -- whether reached via the Authors group-root's folder tiles
        -- (BookshelfWidget:_expandBookOrbitGroup) or a chip pinned
        -- directly to one author -- lists that author's books in series
        -- order (series name, then series index within it; standalones
        -- fall back to the server's natural tie-break) instead of flat
        -- alphabetical-by-title. Same server sort id the "series:" query
        -- below already uses for a single series' books.
        return { author = rest, sort = "series" }
    elseif query == "series" then
        return { series = rest, sort = "series" }
    end
    return { sort = "title" } -- "all" and anything unrecognised
end

-- Friendly default label for a chip whose source.id is `id` -- used by the
-- chip editor's "New chip" auto-rename QoL. Doesn't hit the network.
function M.labelForId(id, fallback_title)
    if fallback_title and fallback_title ~= "" then return fallback_title end
    local query = M.decodeId(id)
    if query == "recent" then return "Recently added"
    elseif query == "continue" then return "Continue reading"
    elseif query == "all" then return "All books"
    elseif query == "discover" then return "Discover something new"
    elseif query == "similar" then return "Similar books"
    end
    return "BookOrbit"
end

-- ---------------------------------------------------------------------
-- Picker data (used only by the chip editor, never by getBySource)
-- ---------------------------------------------------------------------

--- Root choices for the "BookOrbit section" picker: the special shortcuts
-- always offered, plus whatever drill-down sections the server advertises.
-- Returns { { value = id, label = str, needs_drill = bool, section = str|nil } }, err
function M.fetchRootChoices()
    local body, err = BookOrbit.catalogRoot()
    if not body then return nil, err end
    local choices = {
        { value = { id = M.encodeId("all"),      label = "All books" },      label = "All books" },
        { value = { id = M.encodeId("recent"),   label = "Recently added" }, label = "Recently added" },
        { value = { id = M.encodeId("continue"), label = "Continue reading" }, label = "Continue reading" },
        { value = { id = M.encodeId("discover"), label = "Discover something new" }, label = "Discover something new" },
    }
    local seen_special = { ["all-books"] = true, ["recent"] = true, ["continue-reading"] = true, ["search"] = true }
    for _, section in ipairs(body.sections or {}) do
        if not seen_special[section.section] then
            -- value is a marker table, never nil -- nil is reserved for
            -- "the user cancelled" in the chip editor's picker callback.
            choices[#choices + 1] = {
                value = { drill = section.section, title = section.title },
                label = (section.title or section.section) .. "  \xE2\x96\xB8", -- ▸
            }
        end
    end
    return choices
end

--- Entries within one drill-down section (libraries/collections/
-- smart-scopes/authors/series). `title` is the section's display title
-- (from fetchRootChoices), used to label the prepended "whole section"
-- choice below -- falls back to a generic "All items" if omitted.
-- Returns { { value = id, label = str } }, err
function M.fetchSectionChoices(section, title)
    local body, err = BookOrbit.catalogSection(section, { page = 1 })
    if not body then return nil, err end
    local choices = {}
    -- A leaf for the section itself, not one entry within it -- e.g.
    -- picking "Authors" without drilling into a specific author. Maps to
    -- an id with an empty `rest` ("authors:"), which queryForId turns into
    -- a query with no author/library/collection/etc. filter -- effectively
    -- every book, same as the "All books" shortcut, but reachable from
    -- (and named after) this section for chip-naming purposes.
    local all_label = title and ("All " .. title) or _("All items")
    choices[#choices + 1] = {
        value = { id = M.encodeId(section, ""), label = all_label },
        label = all_label,
    }
    -- Second, separate entry point for the three sections that don't
    -- already get folder browsing via their "All <title>" row above (see
    -- GROUPED_SECTION_QUERY's comment) -- picking this instead of "All
    -- <title>" gets a chip that shows one tile per entry, drilled into
    -- live, same as "All Authors"/"All Series" already do.
    for groups_query, real_section in pairs(GROUPED_SECTION_QUERY) do
        if real_section == section then
            local folders_label = title and ("Browse " .. title .. " as folders") or _("Browse as folders")
            choices[#choices + 1] = {
                value = { id = M.encodeId(groups_query, ""), label = folders_label },
                label = folders_label,
            }
            break
        end
    end
    for _, entry in ipairs(body.items or {}) do
        local label = entry.title or "Untitled"
        if entry.count then label = label .. "  (" .. tostring(entry.count) .. ")" end
        choices[#choices + 1] = {
            value = { id = M.encodeId(section, entry.id), label = entry.title or "Untitled" },
            label = label,
        }
    end
    return choices, nil, body.hasNext
end

-- ---------------------------------------------------------------------
-- Book records (used by Repo.getBySource)
-- ---------------------------------------------------------------------

local function firstAuthor(b)
    return b.authors and b.authors[1] or nil
end

local function statusFor(b, pct)
    local s = b.readStatus
    if s == "unread" or s == "reading" or s == "on_hold" or s == "finished" then return s end
    if pct >= 1 then return "finished" end
    if pct > 0 then return "reading" end
    return "unread"
end

function M.toRecord(b)
    local pct_raw = tonumber(b.progressPercentage) or 0
    local pct = pct_raw > 1 and (pct_raw / 100) or pct_raw
    local author = firstAuthor(b)
    -- Defensive type checks, not just `~= nil` -- belt-and-braces on top of
    -- bookshelf_bookorbit.lua's jsonRequest, which already strips JSON
    -- null down to a real Lua nil before this ever runs. Without this, a
    -- stray non-string/non-number value here (e.g. a null sentinel that
    -- slipped through) would previously pass a bare `~= nil` check and get
    -- tostring()'d straight into a "#userdata: 0x..." series badge instead
    -- of the book simply having no series.
    local series_name = type(b.seriesName) == "string" and b.seriesName ~= ""
        and b.seriesName or nil
    local series_num  = (type(b.seriesIndex) == "number" or type(b.seriesIndex) == "string")
        and tostring(b.seriesIndex) or nil
    return {
        -- Not a real path: distinguishes these records everywhere the grid
        -- keys by filepath (selection, cache, cover frame refresh) without
        -- colliding with any real file. Never handed to lfs/io directly --
        -- _openBook resolves a real path before opening (see is_bookorbit).
        filepath       = "bookorbit://" .. tostring(b.id),
        filename       = b.title or "Untitled",
        title          = b.title or "Untitled",
        display_title  = b.title or "Untitled",
        author         = author,
        authors        = b.authors,
        -- `series` mirrors book_repository.lua's on-device raw "<name>
        -- #<n>" form (KOReader's own BIM/info.series shape) -- NOT just a
        -- convenience duplicate of series_name/series_num below. %series /
        -- [if:series] (bookshelf_tokens.lua's Tokens.expanders.series)
        -- deliberately reads THIS field, not series_name -- it's what the
        -- hero's default Metadata-region template gates on
        -- ("[if:series]%series_name...[/if]", see bookshelf_hero_regions.lua)
        -- so a book with a series never showed one in that line without
        -- it, even though series_name/series_num were both populated the
        -- whole time.
        series         = series_name
                          and (series_name .. (series_num and (" #" .. series_num) or ""))
                          or nil,
        series_name    = series_name,
        series_num     = series_num,
        book_pct       = pct,
        status         = statusFor(b, pct),
        read_status    = statusFor(b, pct),
        rating         = nil,
        added_time     = 0,
        last_read_time = 0,
        attr           = { mode = "file", size = 0, modification = 0 },
        format         = b.formats and b.formats[1],
        remote_id      = b.id,
        has_cover      = b.hasCover ~= false,
        -- Carried through so coverBB's cache filename can be versioned by
        -- it (see coverToken below) -- same field the official plugin
        -- reads off its own book objects for the same purpose.
        updated_at     = b.updatedAt,
        is_bookorbit   = true,
    }
end

--- Set (by listBooks below) when a shelf chip came up empty purely because
-- the device was offline -- as opposed to BookOrbit being unconfigured, or a
-- real HTTP/server error. main.lua's onNetworkConnected consumes this to
-- decide whether a freshly-restored connection is worth an automatic shelf
-- refresh, without forcing a rebuild on every unrelated Wi-Fi event.
local _offline_miss = false

--- consumeOfflineMiss() -> bool
-- Read-and-clear _offline_miss. Called once per NetworkConnected broadcast.
function M.consumeOfflineMiss()
    local v = _offline_miss
    _offline_miss = false
    return v
end

-- Debounce guard for _tryAutoConnect below -- shared across all callers/pages
-- since a page-turn or repeated rebuild can call listBooks many times a
-- second while still offline.
local _reconnect_pending = false

--- Kick off (at most once per ~30s while offline) an attempt to bring Wi-Fi
-- up in the background: turns it on / reconnects a saved network, prompting
-- the user only if none is saved (NetworkMgr:runWhenOnline never forces a
-- silent connection past that). Debounced so a shelf that's rendered or
-- scrolled repeatedly while offline doesn't retry -- or re-prompt -- on
-- every single call; roughly once per this window instead.
--
-- Deliberately fire-and-forget: the actual shelf refresh happens via
-- main.lua's onNetworkConnected + consumeOfflineMiss above once the
-- connection (this attempt, or the user turning Wi-Fi on themselves)
-- actually lands -- not via a callback threaded back through here, since
-- listBooks itself must stay synchronous for the grid's rebuild path.
local function _tryAutoConnect()
    if _reconnect_pending then return end
    local ok_net, NetworkMgr = pcall(require, "ui/network/manager")
    if not (ok_net and NetworkMgr and NetworkMgr.runWhenOnline) then return end
    _reconnect_pending = true
    local ok_ui, UIManager = pcall(require, "ui/uimanager")
    if ok_ui and UIManager then
        -- Release the guard after a while regardless of outcome -- a
        -- dismissed Wi-Fi prompt (or no saved network at all) shouldn't
        -- permanently block every later retry for the rest of the session.
        UIManager:scheduleIn(30, function() _reconnect_pending = false end)
    end
    NetworkMgr:runWhenOnline(function() _reconnect_pending = false end)
end

-- One cached Discover batch per source id (there's really only ever one,
-- "discover:", but keying by id costs nothing and stays consistent with
-- _known_total below). /catalog/dashboard/discover has no page/size params
-- -- every request is a fresh random selection -- so unlike the other
-- root queries, this can't be re-fetched per page turn without silently
-- swapping in different books on every "next page" tap. Fetched once,
-- then paginated client-side out of this cache; the total is exact and
-- known from the very first page, since the whole batch is already held.
--
-- Held in the shared bookshelf_bookorbit_cache module (see that file) --
-- the same size-budgeted RAM cache every other BookOrbit section below
-- now uses, kept until this key is invalidated or evicted for space,
-- never on a timer.
local DISCOVER_PREFIX = "discover:"

-- fetchDiscover(id, force) -> records (array, may be empty on failure)
-- force=true re-hits the server for a brand-new random batch (the
-- "reroll" -- see M.rerollDiscover / invalidateDiscoverCache below);
-- otherwise reuses whatever batch this source id already has cached.
local function fetchDiscover(id, force)
    local key = DISCOVER_PREFIX .. id
    if not force then
        local cached = Cache.get(key)
        if cached then return cached end
    end
    local body, err = BookOrbit.catalogDiscover()
    if not body then
        local ok_log, logger = pcall(require, "logger")
        if ok_log then logger.info("Bookshelf BookOrbit: catalogDiscover failed", err) end
        -- Keep serving the last good batch (if any) rather than blanking
        -- the shelf on a transient network hiccup; only a genuine first
        -- fetch failure returns empty.
        return Cache.get(key) or {}
    end
    local records = {}
    for _, b in ipairs(body.discover or {}) do
        records[#records + 1] = M.toRecord(b)
    end
    Cache.set(key, records)
    return records
end

--- rerollDiscover(id) -> fetches and caches a brand-new random batch for
-- this source id, mirroring the official plugin's Discover reroll button.
-- Callers should rebuild the chip afterwards to show the new set.
function M.rerollDiscover(id)
    return fetchDiscover(id, true)
end

--- invalidateDiscoverCache() -> drops every cached Discover batch, so the
-- next fetch for any Discover chip re-rolls. Cheap to call unconditionally
-- (e.g. from the shelf's existing manual swipe-down refresh) even when no
-- Discover chip is currently in view.
function M.invalidateDiscoverCache()
    Cache.invalidatePrefix(DISCOVER_PREFIX)
end

-- One cached "Similar books" batch per remote book id ("similar:<id>").
-- Like Discover above, this isn't a page/size-able catalogBooks() filter --
-- it's one section of the per-book detail response (GET .../books/<id>,
-- the same endpoint rebuildRecord/prefetchDescriptions already call for
-- the synopsis) -- so the whole section is fetched once and paginated
-- client-side out of this cache, the same "fetch once, slice in memory"
-- shape fetchDiscover uses for its own single, un-page-able batch.
local SIMILAR_PREFIX = "similar:"

-- fetchSimilar(remote_id, force) -> records (array, may be empty on failure
-- or if the server has nothing similar for this book). force=true re-hits
-- the server; otherwise reuses whatever's already cached for this id.
--
-- Two server calls, not one: the "similar" section's own book objects
-- (embedded in the per-book detail response) turned out to be a slimmer
-- shape than a normal catalog list item -- no series/progress/read-status
-- at all, not merely null -- which is why Similar results showed no series
-- badge/pill even after fixing the earlier JSON-null-sentinel bug (that
-- fix was real and still needed, just not sufficient here). So this only
-- uses the detail response to learn WHICH books are similar and in what
-- order, then re-fetches those same book ids through the normal
-- catalogBooks() "ids" filter -- the same call the official plugin's own
-- "On device" virtual library uses (see the reference bookorbit.koplugin's
-- bookorbit_catalog.lua) -- to get the full list-item shape every other
-- section (Author/Series/Discover/...) already relies on. The extra
-- request is cheap: one per Similar pill tap (cached after that), same as
-- every other group drilldown here.
local function fetchSimilar(remote_id, force)
    local key = SIMILAR_PREFIX .. tostring(remote_id)
    if not force then
        local cached = Cache.get(key)
        if cached then return cached end
    end
    local detail, err = BookOrbit.catalogBook(remote_id)
    if not detail then
        local ok_log, logger = pcall(require, "logger")
        if ok_log then logger.info("Bookshelf BookOrbit: catalogBook (similar) failed", err) end
        -- Keep serving the last good batch (if any) rather than blanking
        -- the drilldown on a transient network hiccup.
        return Cache.get(key) or {}
    end

    -- Slim ids-only pass: just enough to know which books, and the
    -- server's similarity ranking (position in this list), NOT their full
    -- metadata -- see above for why.
    local similar_ids, rank = {}, {}
    for _, section in ipairs(detail.relatedSections or {}) do
        if section.id == "similar" then
            for _, b in ipairs(section.books or {}) do
                if b.id ~= nil then
                    local id_str = tostring(b.id)
                    if not rank[id_str] then
                        similar_ids[#similar_ids + 1] = id_str
                        rank[id_str] = #similar_ids
                    end
                end
            end
            break
        end
    end
    if #similar_ids == 0 then
        Cache.set(key, {})
        return {}
    end

    local records
    local body, body_err = BookOrbit.catalogBooks{
        ids  = table.concat(similar_ids, ","),
        size = #similar_ids,
    }
    if body and type(body.items) == "table" then
        -- catalogBooks(ids=...) doesn't promise to preserve the `ids`
        -- order, so re-sort the full-shaped results back into the
        -- server's original similarity ranking learned above.
        records = {}
        for _, b in ipairs(body.items) do
            records[#records + 1] = b
        end
        table.sort(records, function(a, b2)
            return (rank[tostring(a.id)] or math.huge) < (rank[tostring(b2.id)] or math.huge)
        end)
        for i, b in ipairs(records) do records[i] = M.toRecord(b) end
    else
        local ok_log, logger = pcall(require, "logger")
        if ok_log then
            logger.info("Bookshelf BookOrbit: catalogBooks(ids=...) for similar failed", body_err)
        end
        -- Fall back to the slim relatedSections shape rather than an
        -- empty drilldown -- still tappable/openable, just without
        -- series/progress until the next successful fetch.
        records = {}
        for _, section in ipairs(detail.relatedSections or {}) do
            if section.id == "similar" then
                for _, b in ipairs(section.books or {}) do
                    records[#records + 1] = M.toRecord(b)
                end
                break
            end
        end
    end
    Cache.set(key, records)
    return records
end

--- invalidateSimilarCache() -> drops every cached "Similar books" batch, so
-- the next Similar pill tap re-fetches. Mirrors invalidateDiscoverCache
-- above; wired into the shelf's manual refresh alongside it.
function M.invalidateSimilarCache()
    Cache.invalidatePrefix(SIMILAR_PREFIX)
end

-- Highest "total" ever synthesised per source id -- fallback path only,
-- for the rare response that omits body.total (see listBooks below). Keyed
-- by the chip's source.id string, so different chips/sections never bleed
-- into each other's count. Paging backward must not forget a total the
-- forward page already confirmed to exist -- otherwise the footer
-- regresses from e.g. "3 of 4" back down to "2 of 3" the moment the user
-- taps the left chevron, even though page 3 is known to exist.
local _known_total = {}

--- listBooks(id, offset, limit) -> records, total
-- Maps the grid's offset/limit window onto one catalogBooks() page (limit
-- is the view size, so this is exactly one request per page turn).
--
-- /koreader/plugin/catalog/books actually DOES report an exact total --
-- confirmed against the official bookorbit.koplugin's catalog browser
-- (bookorbit_catalog.lua), which already computes
-- `page_count = ceil(body.total / body.size)` for its own pagination.
-- This bridge previously ignored that field and synthesised a fake total
-- from `hasNext` alone (just far enough past the current window to keep
-- forward paging enabled), which is why the chip footer always read
-- "page N of N+1" instead of the real page count. Now body.total is used
-- whenever the server sends it; the old hasNext-based guess only kicks in
-- as a fallback for a response that (for whatever reason) omits it, and
-- even then never regresses below a total a later page already confirmed.
-- Cache holding every listBooks() page fetched over the wire, keyed by
-- the full (id, offset, limit) -- either warmed ahead of time by
-- prefetchNextPage (see that function below), or -- the common case,
-- since prefetchNextPage is currently disabled -- the page listBooks()
-- itself *just* fetched a moment ago, cached right after the HTTP
-- response comes back (see the bottom of listBooks below).
--
-- This is load-bearing even without prefetchNextPage: bookshelf_widget.lua's
-- onCoversReady callback calls a full _rebuild() after EVERY batch
-- scheduleCoverFills lands (batches of THUMBNAIL_BATCH_SIZE), and
-- _rebuild() -> getBySource -> listBooks() for the exact same
-- (id, offset, limit) that was just rendered -- 2-4 times over for one
-- 18-24 book page. Without this cache each of those cover-fill-triggered
-- rebuilds re-issued a fresh blocking catalogBooks() request for a page
-- that hadn't changed at all; with it, only the very first fetch touches
-- the network and every cascading rebuild for that same page is served
-- from here.
--
-- Now held in the shared, size-budgeted RAM cache alongside Discover and
-- the Author/Series group buckets below: no TTL, kept until this key is
-- superseded, invalidateNextPageCache() runs (manual refresh), or the
-- shared byte budget evicts it as the least-recently-used entry. Keying
-- by the full (id, offset, limit) -- rather than the single shared slot
-- this used to be -- also means paging back to an earlier page, or
-- switching between two chips pinned side by side, can now be served
-- from RAM too, instead of always re-fetching once a different page
-- would have overwritten the old slot.
local PAGE_PREFIX = "page:"

local function pageKey(id, offset, limit)
    return PAGE_PREFIX .. id .. ":" .. offset .. ":" .. limit
end

local function cacheNextPage(id, offset, limit, records, total)
    Cache.set(pageKey(id, offset, limit), { records = records, total = total })
end

--- consumeNextPageCache(id, offset, limit) -> records, total (or nil).
-- Exact match on (id, offset, limit). Kept for continuity with
-- prefetchNextPage's doc comments elsewhere in this file.
local function consumeNextPageCache(id, offset, limit)
    local c = Cache.get(pageKey(id, offset, limit))
    if not c then return nil end
    return c.records, c.total
end

--- invalidateNextPageCache() -- drops every cached book page, so the
-- next listBooks() call for any id/offset/limit re-fetches over the
-- wire. Mirrors invalidateDiscoverCache/invalidateGroupCache above;
-- called from the shelf's manual refresh so a forced refresh can't be
-- served a page this cache fetched before the refresh was requested.
function M.invalidateNextPageCache()
    Cache.invalidatePrefix(PAGE_PREFIX)
end

function M.listBooks(id, offset, limit)
    if not M.isAvailable() then return {}, offset or 0 end
    offset = offset or 0
    limit  = (limit and limit > 0) and limit or 24

    local cached_records, cached_total = consumeNextPageCache(id, offset, limit)
    if cached_records then return cached_records, cached_total end

    local ok_net, NetworkMgr = pcall(require, "ui/network/manager")
    if ok_net and NetworkMgr and NetworkMgr.isOnline and not NetworkMgr:isOnline() then
        _offline_miss = true
        _tryAutoConnect()
        return {}, offset
    end

    -- Discover doesn't come from catalogBooks at all -- it's a fixed,
    -- pre-fetched random batch (see fetchDiscover above), sliced here the
    -- same way the "search" tip and group drilldowns slice their own
    -- fully-hydrated lists. Total is exact: it's just the batch size.
    if (M.decodeId(id)) == "discover" then
        local records = fetchDiscover(id, false)
        local total   = #records
        local stop    = math.min(offset + limit, total)
        local page_slice = {}
        for i = offset + 1, stop do
            page_slice[#page_slice + 1] = records[i]
        end
        return page_slice, total
    end

    -- "similar:<remote_id>" -- one book's "Similar books" server section
    -- (see _buildPillSpecs' Similar pill in bookshelf_widget.lua), not a
    -- catalogBooks() filter -- same fetch-once-then-slice shape as
    -- Discover just above, keyed by remote_id instead of the fixed
    -- "discover" id.
    do
        local query, remote_id = M.decodeId(id)
        if query == "similar" then
            local records = fetchSimilar(remote_id, false)
            local total   = #records
            local stop    = math.min(offset + limit, total)
            local page_slice = {}
            for i = offset + 1, stop do
                page_slice[#page_slice + 1] = records[i]
            end
            return page_slice, total
        end
    end

    local page = math.floor(offset / limit) + 1
    local query = M.queryForId(id)
    query.page = page
    query.size = limit

    local body, err = BookOrbit.catalogBooks(query)
    if not body then
        local ok_log, logger = pcall(require, "logger")
        if ok_log then logger.info("Bookshelf BookOrbit: listBooks failed", err) end
        return {}, offset
    end
    local records = {}
    for _, b in ipairs(body.items or {}) do
        records[#records + 1] = M.toRecord(b)
    end
    local total = tonumber(body.total)
    if not total then
        -- Fallback for a response that didn't include total: same
        -- "just far enough ahead to keep paging" guess as before, clamped
        -- so it never undercuts a total a later page already proved.
        total = offset + #records + (body.hasNext and limit or 0)
        local prev = _known_total[id]
        if prev and prev > total then total = prev end
        _known_total[id] = total
    end
    cacheNextPage(id, offset, limit, records, total)
    return records, total
end

-- ---------------------------------------------------------------------
-- Grouped browsing (Authors / Series root -> folder-like group tiles)
--
-- A chip pointed at the "All authors"/"All series" leaf (id "authors:" /
-- "series:", built by fetchSectionChoices above) used to fall straight
-- into listBooks with an empty author/series filter -- i.e. every book,
-- flat, no grouping at all, even though the "Browse catalog" menu already
-- lets you drill authors/series like folders. This section gives chips
-- the same folder-like browsing: the root shows one tile per author/
-- series (see listGroups), and BookshelfWidget:_expandBookOrbitGroup
-- drills into a specific one via the existing _drilldown_path machinery
-- -- which then lands back on plain listBooks with that one entry's id,
-- so the drilled-in list is exactly the already-working single-author/
-- single-series chip path.
--
-- catalogSection() has no caller-controllable page size (unlike
-- catalogBooks, which takes size=), so it can't be mapped onto the grid's
-- offset/limit window the way listBooks() maps onto catalogBooks() --
-- the server's own fixed page size and the grid's view size (3/6/9
-- depending on layout) would drift apart. Authors/series lists are just
-- names + counts (no per-entry paging concern), so instead this caches a
-- flattened list per section (held in the shared cache, same as Discover
-- above) and slices offset/limit out of it locally.
--
-- The flattened list is built LAZILY, though: fetchSectionBucket only
-- walks as many catalogSection() pages as needed to cover the CURRENT
-- offset+limit window, resuming from where a prior call left off rather
-- than re-walking from page 1. A first render (offset=0, one shelf's
-- worth of tiles) typically costs a single round trip; scrolling further
-- resumes the walk for just the extra entries that page needs. This used
-- to walk every page up to GROUP_FETCH_PAGE_CAP unconditionally on the
-- very first call -- up to 40 synchronous, un-yielded catalogSection()
-- round trips back to back, from the render path (_rebuild ->
-- _fetchChipItems -> Repo.getBySource), which could freeze the reader for
-- the sum of all of them on a library with many authors/series. Bookshelf's
-- own plain-text catalog browser (bookshelf_bookorbit_catalog.lua) and the
-- official plugin both page lazily, one screen at a time -- this now does
-- the same instead of being the odd one out in the same codebase.
-- ---------------------------------------------------------------------

-- section -> { entries, first_books, next_page, exhausted } bucket, held
-- in the shared bookshelf_bookorbit_cache module the same way Discover
-- and book pages are above -- no TTL; a bucket lives until
-- invalidateGroupCache() (manual refresh) drops it or the shared byte
-- budget evicts it as the least-recently-used entry.
local GROUP_PREFIX = "group:"
-- Safety cap on how many catalogSection() pages fetchSectionBucket will
-- ever walk for one section (across however many calls it takes to get
-- there, since the walk now resumes incrementally rather than happening
-- in one shot). Generous for any realistic author/series list; bounded so
-- a server bug (hasNext always true) can't loop forever.
local GROUP_FETCH_PAGE_CAP = 40

--- True if `id` is a "browse as folders" root -- either the ungrouped
-- root of Authors/Series (what fetchSectionChoices labels "All
-- <section>": "authors:"/"series:" with no specific entry picked, a
-- meaning that id has had since this function was introduced), or one
-- of the separate Libraries/Collections/SmartScopes "-groups" ids from
-- GROUPED_SECTION_QUERY above (their OWN "All <section>" id is
-- deliberately left alone -- see that table's comment). Any other id
-- (a specific entry, or a non-groupable root like "recent"/"all"/
-- "discover") is unaffected and keeps going through the flat
-- listBooks path.
function M.isGroupRoot(id)
    local query, rest = M.decodeId(id)
    if not (rest == nil or rest == "") then return false end
    return query == "authors" or query == "series" or GROUPED_SECTION_QUERY[query] ~= nil
end

--- groupSection(id) -> the real catalogSection()/catalogBooks() section
-- name to walk for a group-root id (only meaningful when
-- isGroupRoot(id) is true). Authors/Series ids already carry their real
-- section name as the query token, so this only needs to translate the
-- "-groups" tokens back to their underlying section.
function M.groupSection(id)
    local query = M.decodeId(id)
    return GROUPED_SECTION_QUERY[query] or query
end

-- fetchSectionBucket(section, needed) -> the cache bucket for `section`,
-- walking just enough catalogSection() pages to cover `needed` entries
-- (typically the caller's offset+limit) if the cached bucket doesn't
-- already have that many. Holds the flat entries list AND (see
-- listGroups) each entry's resolved first_book, keyed by entry id -- a
-- single shared bucket/TTL so a section refresh naturally drops both
-- together.
--
-- Resumable: bucket.next_page/exhausted persist across calls, so paging
-- forward through a chip extends the same walk instead of restarting it
-- -- each individual call only pays for the NEW pages that call's window
-- needs, not the whole section. A bucket now lives until
-- invalidateGroupCache() drops it or the shared cache evicts it for
-- space, rather than expiring on a fixed timer.
-- givenNameKey(entry) -> lowercased "given name" sort key for an Authors
-- group-root tile, e.g. "Iain M. Banks" -> "iain m. banks" (the surname
-- stays in the key too -- AuthorName.givenOf only strips the trailing
-- surname token(s), so "Iain M. Banks" keeps "Iain M." -- but since every
-- entry here is compared the same way, tiles still land in first-name
-- order; a shared first name then falls through to the rest of the
-- string, which reads naturally). Falls back to the raw title (still
-- alphabetical, just surname-first) if AuthorName didn't load or the
-- entry has no usable title, so a missing module degrades this sort
-- rather than erroring the whole section.
local function givenNameKey(entry)
    local title = entry and entry.title
    if type(title) ~= "string" or title == "" then return "" end
    if ok_author_name and AuthorName and AuthorName.givenOf then
        local given = AuthorName.givenOf(title)
        if given and given ~= "" then return given:lower() end
    end
    return title:lower()
end

-- sortAuthorEntries(entries) -- orders the Authors group-root's tiles
-- alphabetically by first/given name (catalogSection("authors") returns
-- entries in whatever order the server's database query happens to
-- yield -- effectively unordered from the user's point of view -- and
-- unlike catalogBooks() there's no `sort=` param to ask the server to do
-- this instead; see the module doc comment above fetchSectionBucket).
-- Ties (two authors sharing a first name) break on the full title so the
-- order stays deterministic across repeated sorts of the same list.
--
-- Called every time fetchSectionBucket appends newly-walked pages (see
-- below), not just once: the bucket is built up LAZILY, so a tile at
-- position N on a page the user already saw can, in principle, move once
-- more entries load in from a later page. In practice this only bites
-- once, right as the walk that spans the visited page's boundary
-- happens -- once `bucket.exhausted` (or the walk has covered every
-- position up to the highest offset the user has scrolled to), the order
-- is stable. No worse than the "report one page's worth more than we've
-- fetched" total-count fuzziness fetchSectionBucket's caller already
-- lives with for the same reason.
local function sortAuthorEntries(entries)
    table.sort(entries, function(a, b)
        local ka, kb = givenNameKey(a), givenNameKey(b)
        if ka ~= kb then return ka < kb end
        return (a.title or "") < (b.title or "")
    end)
end

local function fetchSectionBucket(section, needed)
    needed = needed or 0
    local key = GROUP_PREFIX .. section
    local bucket = Cache.get(key)
    if not bucket then
        bucket = { entries = {}, first_books = {}, next_page = 1, exhausted = false }
    end
    local fetched_more = false
    while (not bucket.exhausted) and #bucket.entries < needed
            and bucket.next_page <= GROUP_FETCH_PAGE_CAP do
        local body, err = BookOrbit.catalogSection(section, { page = bucket.next_page })
        if not body then
            local ok_log, logger = pcall(require, "logger")
            if ok_log then
                logger.info("Bookshelf BookOrbit: listGroups section fetch failed", section, err)
            end
            -- Mark exhausted (rather than leaving the bucket to retry the
            -- same failing page on every render) so a persistent server
            -- error doesn't retry the walk on every single call -- same
            -- "serve what we've got" trade-off fetchDiscover makes on
            -- failure, just without a prior-batch fallback since there's
            -- nothing to fall back to on the very first page.
            bucket.exhausted = true
            break
        end
        for _, entry in ipairs(body.items or {}) do
            bucket.entries[#bucket.entries + 1] = entry
        end
        fetched_more = true
        bucket.next_page = bucket.next_page + 1
        if not body.hasNext then bucket.exhausted = true end
    end
    -- Authors get a client-side alphabetical-by-first-name re-sort (see
    -- sortAuthorEntries above) since the server has no equivalent of
    -- catalogBooks()'s `sort=` for this endpoint. Only re-sort when this
    -- call actually walked new pages -- an already-sorted, unchanged
    -- bucket doesn't need the O(n log n) pass again on every render.
    if section == "authors" and fetched_more then
        sortAuthorEntries(bucket.entries)
    end
    -- Re-set (rather than relying on the reference Cache.get returned)
    -- so the cache's byte accounting picks up whatever this walk just
    -- appended to the bucket's entries -- and so a first-ever fetch for
    -- this section gets stored at all.
    Cache.set(key, bucket)
    return bucket
end

--- invalidateGroupCache() -- drops the cached author/series lists (and
-- their resolved first-book previews), AND the decoded cover bbs
-- GroupCoverCache is holding for them, so the next listGroups call
-- re-walks the server and re-decodes covers from scratch. Both are
-- dropped together so a newly added/changed author or series can never
-- show a stale cover left over from before the refresh. Cheap to call
-- unconditionally; mirrors invalidateDiscoverCache above (e.g. from a
-- manual refresh).
function M.invalidateGroupCache()
    Cache.invalidatePrefix(GROUP_PREFIX)
    GroupCoverCache:clear()
end

--- listGroups(section, offset, limit) -> records, total
-- section is a real catalogSection() name -- "authors", "series",
-- "libraries", "collections", or "smart-scopes" (callers get here via
-- isGroupRoot + groupSection above, which resolve any of those
-- section's group-root ids down to this real name). Each record is a
-- folder-like tile (kind = "bookorbit_group") shaped for FolderStack:
-- .label, .count, .first_book (a single hydrated sample book for the
-- tile's preview image -- its cover fills in asynchronously via
-- scheduleCoverFills below, same as every other BookOrbit cover), and
-- .source_id -- the id to drill into, in exactly the single-entry form
-- M.queryForId already understands (e.g. "authors:42").
function M.listGroups(section, offset, limit)
    if not M.isAvailable() then return {}, offset or 0 end
    local ok_net, NetworkMgr = pcall(require, "ui/network/manager")
    if ok_net and NetworkMgr and NetworkMgr.isOnline and not NetworkMgr:isOnline() then
        _offline_miss = true
        _tryAutoConnect()
        return {}, offset or 0
    end
    offset = offset or 0
    limit  = (limit and limit > 0) and limit or 24
    local bucket = fetchSectionBucket(section, offset + limit)
    local entries = bucket.entries
    -- Once the walk has exhausted the section (hit the last server page,
    -- or gave up after an error), #entries IS the true total. Until then,
    -- we've deliberately only walked enough pages to cover this window,
    -- so report one page's worth more than we've fetched -- enough for
    -- the grid to keep offering a "next" page. Visiting that next page
    -- resumes the walk above and the count firms up from there (or the
    -- walk finishes and the exact total takes over).
    local total = bucket.exhausted and #entries or (#entries + limit)
    local records = {}
    -- Preview covers for this page's tiles are filled ASYNC via
    -- scheduleCoverFills below, not by calling the blocking M.coverBB()
    -- here -- coverBB() downloads AND decodes synchronously, so calling
    -- it once per tile in this loop meant every render of a folder-tile
    -- page (author/series browsing) sat behind up to a page's worth of
    -- JPEG decodes/downloads, back to back, on the render path -- exactly
    -- the "device feels busy right as you turn the page" stall
    -- scheduleCoverFills exists to avoid for the flat listBooks/
    -- getBySource path (see that function's doc comment), just never
    -- applied here. group_first_books collects this page's sample books
    -- (metadata only, no cover attached yet) so they can be handed to
    -- scheduleCoverFills together, the same way getBySource hands it a
    -- flat page: filled in place, off the render path, in small batches,
    -- firing onCoversReady (which the grid widget already listens for,
    -- see its init) to repaint once a batch lands.
    local group_first_books = {}
    for i = offset + 1, math.min(offset + limit, #entries) do
        local entry = entries[i]
        local gid = M.encodeId(section, entry.id)
        -- Cache hit: this entry's sample book METADATA was already
        -- resolved earlier (a prior page view, or a previous visit to
        -- this chip) -- skip the catalogBooks round trip. `false` is a
        -- cached "no book" result, distinct from "not yet looked up"
        -- (nil), so a genuinely empty author isn't retried every render
        -- either.
        --
        -- This bucket holds first_book METADATA only, never a decoded
        -- cover_bb -- that lives separately in GroupCoverCache, keyed by
        -- gid (see below), so a section refresh (invalidateGroupCache)
        -- can drop stale covers independently of whether the metadata
        -- walk itself needs re-fetching, and so this cache's byte
        -- accounting (bookshelf_bookorbit_cache.lua's approxSize) never
        -- has to reason about blitbuffer memory.
        local cached_fb = bucket.first_books[entry.id]
        if cached_fb == nil then
            local sample = M.listBooks(gid, 0, 1)
            cached_fb = (sample and sample[1]) or false
            bucket.first_books[entry.id] = cached_fb
        end
        local first_book
        if cached_fb then
            first_book = {}
            for k, v in pairs(cached_fb) do first_book[k] = v end
            -- wantsCover()/scheduleCoverFills' "already filled" guard is
            -- keyed off record.cover_bb on THIS table -- but first_book is
            -- a brand-new table every single render (metadata only --
            -- see the comment above bucket.first_books), so that guard
            -- can never see a previous fill on its own. Left alone (and
            -- with no real cover cache), every render would hand
            -- scheduleCoverFills a "needs a cover" copy again, each fill
            -- fires onCoversReady, which triggers a full _rebuild(),
            -- which calls listGroups() again, which builds fresh copies
            -- again -- forever, on scheduleCoverFills' ~0.02s timer,
            -- pegging the UI and never letting the folder-like group
            -- chip (Series/Authors/etc.) settle.
            --
            -- Break the cascade with a REAL cache (GroupCoverCache,
            -- keyed by this entry's gid, not by the disposable
            -- first_book table): once an entry's cover has been decoded
            -- once, every later render -- this cascade or any future one
            -- -- reuses the SAME bb instead of re-decoding from disk.
            -- This is safe despite FolderStack/SpineWidget's
            -- cover_align_top path treating a group tile's cover_bb as a
            -- disposable, freed-after-paint override: SpineWidget always
            -- scales a PRIVATE copy off the bb before painting
            -- (bb:scale(), see _renderCoverAlignTop) and only frees the
            -- ORIGINAL when the caller marked it disposable.
            -- first_book.cover_bb_cache_owned (read by
            -- bookshelf_folder_stack.lua) tells it NOT to -- the same
            -- "hold a reference, never explicitly free it, let GC
            -- reclaim" contract bookshelf_scaled_cover_cache.lua already
            -- uses for book covers.
            local bb, w, h = GroupCoverCache:get(gid)
            if not bb then
                -- Cache miss: cachedCoverBB is disk-only (no network),
                -- so this is just a cheap JPEG decode when the cover is
                -- already on disk from an earlier fetch -- and, unlike
                -- before, it now happens at most ONCE per entry ever,
                -- rather than once per render.
                bb, w, h = M.cachedCoverBB and M.cachedCoverBB(first_book)
                if bb then GroupCoverCache:put(gid, bb, w, h) end
            end
            if bb then
                first_book.cover_bb, first_book.cover_w, first_book.cover_h = bb, w, h
                first_book.has_cover = true
                first_book.cover_bb_cache_owned = true
            else
                -- Genuinely never decoded (not on disk yet): still goes
                -- through the async queue below. Once that download+
                -- decode lands and a later render's cachedCoverBB call
                -- above succeeds, GroupCoverCache:put catches it and it
                -- never gets re-decoded again either.
                group_first_books[#group_first_books + 1] = first_book
            end
        end
        records[#records + 1] = {
            kind       = "bookorbit_group",
            label      = entry.title or "Untitled",
            count      = entry.count,
            first_book = first_book,
            source_id  = gid,
        }
    end
    if M.scheduleCoverFills then
        M.scheduleCoverFills(group_first_books, section)
    end
    return records, total
end

-- ---------------------------------------------------------------------
-- Cover thumbnails (disk-cached). Filenames are versioned by the book's
-- updatedAt (see coverToken below), same scheme as the official plugin's
-- bookorbit_catalog_thumbnails.lua: a server-side cover change or a
-- library rescan that reassigns book ids invalidates the cached image
-- instead of silently serving a stale/wrong one. The cache dir also gets
-- a soft file-count cap (Settings > BookOrbit > Cover cache limit,
-- default 600), pruned oldest-first,
-- so it can't grow without bound -- again mirroring the official plugin.
-- ---------------------------------------------------------------------

-- Debug-level tracing of the cover download chain -- silent in normal use,
-- available when a tester runs with debug logging on. Mirrors
-- bookshelf_kobo_source.lua's `diag` helper.
local function diag(...)
    local ok, logger = pcall(require, "logger")
    if ok and logger and logger.dbg then logger.dbg("[bookshelf][bookorbit]", ...) end
end

local function thumbDir()
    local DataStorage = require("datastorage")
    return DataStorage:getSettingsDir() .. "/bookshelf_bookorbit_covers"
end

-- Soft cap on the cover cache dir. Oldest files (by mtime) are evicted
-- past this count -- same value and eviction strategy as the official
-- plugin's THUMBNAIL_CACHE_MAX_FILES, except here it's user-configurable
-- (Settings > BookOrbit > Cover cache limit) rather than fixed, read
-- fresh on every prune so a change takes effect on the very next prune
-- without needing a restart -- same live-read pattern
-- bookshelf_bookorbit_cache.lua already uses for "bookorbit_cache_mb".
local THUMBNAIL_CACHE_MAX_FILES_DEFAULT = 600
local function thumbnailCacheMaxFiles()
    local n = tonumber(BookshelfSettings.read("bookorbit_thumbnail_cache_max_files"))
    return (n and n > 0) and math.floor(n) or THUMBNAIL_CACHE_MAX_FILES_DEFAULT
end

-- Cover cache files are versioned by the book's updated_at (see toRecord)
-- so a server-side cover change invalidates the cached image instead of
-- being masked by a filename-only cache hit. Falls back to "0" for
-- records that don't carry updated_at (never invalidates on its own, but
-- still gets swept by the size-capped prune below).
local function coverToken(record)
    local value = record and record.updated_at
    if not value then return "0" end
    local token = tostring(value):gsub("%D", "")
    return token ~= "" and token or "0"
end

-- One-time sweep of pre-versioning cache files ("<id>.jpg", no "_token"
-- suffix) left behind by earlier Bookshelf versions -- they'd otherwise
-- sit in the cache dir forever, never matched (and never evicted by
-- pruneThumbnailCache, since it does no filename parsing). Mirrors the
-- official plugin's cleanLegacyThumbnails. Runs at most once per session.
local _legacy_swept = false
local function cleanLegacyThumbnails()
    if _legacy_swept then return end
    _legacy_swept = true
    local lfs = require("libs/libkoreader-lfs")
    local dir = thumbDir()
    if lfs.attributes(dir, "mode") ~= "directory" then return end
    for name in lfs.dir(dir) do
        if name:match("^%d+%.jpg$") then
            os.remove(dir .. "/" .. name)
        end
    end
end

-- Evicts the oldest cached covers once the cache exceeds its soft file
-- cap. Same strategy as the official plugin's pruneThumbnailCache: list,
-- sort by mtime, drop the oldest overflow.
local function pruneThumbnailCache()
    local lfs = require("libs/libkoreader-lfs")
    local dir = thumbDir()
    if lfs.attributes(dir, "mode") ~= "directory" then return end
    local files = {}
    for name in lfs.dir(dir) do
        if name:match("%.jpg$") then
            local path = dir .. "/" .. name
            local mtime = lfs.attributes(path, "modification") or 0
            files[#files + 1] = { path = path, mtime = mtime }
        end
    end
    if #files <= thumbnailCacheMaxFiles() then return end
    table.sort(files, function(a, b) return a.mtime < b.mtime end)
    for i = 1, #files - thumbnailCacheMaxFiles() do
        os.remove(files[i].path)
    end
end

-- Books whose thumbnail download failed THIS SESSION -- mirrors the official
-- plugin's per-generation thumbnail_failures set, so a broken/missing cover
-- doesn't re-issue a failing HTTP request on every single page repaint.
-- Cleared naturally on KOReader restart; nothing here persists to disk.
local _thumb_failed = {}

--- decodeThumbnailFile(path, key, dl_headers) -> bb, w, h (or nil).
-- Shared decode step used by both coverBB (fresh download or cache hit)
-- and cachedCoverBB (cache hit only, see below). dl_headers is only
-- ever present right after a fresh download, so a cache-hit re-decode
-- of a pre-existing bad file just logs without them.
local function decodeThumbnailFile(path, key, dl_headers)
    local ok_r, RenderImage = pcall(require, "ui/renderimage")
    if not ok_r or not RenderImage or not RenderImage.renderImageFile then return nil end
    local ok_bb, bb = pcall(function() return RenderImage:renderImageFile(path, false) end)
    -- BUG (root cause of every "did not decode" failure below): a successful
    -- decode returns a BlitBuffer, which KOReader builds via ffi.metatype --
    -- its Lua type() is "cdata", NEVER "table". The old `type(bb) ~= "table"`
    -- check therefore rejected every single valid decode, unconditionally,
    -- which is exactly what the content-type=image/jpeg + valid-JPEG-magic
    -- diagnostics above proved was happening: the bytes were fine the whole
    -- time. RenderImage:renderImageFile returns nil (falsy) on a genuine
    -- decode failure and a non-nil BlitBuffer on success, so `not bb` is the
    -- correct check -- same pattern used elsewhere in this codebase (e.g.
    -- bookshelf_image_source.lua just returns/uses the value directly).
    if not ok_bb or not bb then
        -- Downloaded fine but didn't decode as an image -- almost always
        -- means the bytes on disk aren't actually a JPEG (an HTML error
        -- page saved by a lenient sink, or a gzipped body a proxy sent
        -- without Accept-Encoding: identity being honoured). Log what we
        -- actually got -- Content-Type/Content-Encoding from the response
        -- (when this was a fresh download, i.e. dl_headers is set -- a
        -- cache-hit re-decode of a pre-existing bad file won't have these),
        -- the on-disk size, and the first bytes' magic number -- so the
        -- real cause (wrong content-type, still-gzipped body starting with
        -- 0x1F 0x8B, an HTML error page starting with "<", a 0-byte/
        -- truncated file, etc.) shows up in the log instead of a bare
        -- "did not decode". Then remove the bad file so the next attempt
        -- re-downloads instead of forever trying to decode the same broken
        -- bytes, and don't sit in _thumb_failed permanently -- a
        -- proxy/server fix should recover without a KOReader restart.
        local size, magic_hex, magic_ascii
        local fh = io.open(path, "rb")
        if fh then
            size = fh:seek("end")
            fh:seek("set", 0)
            local head = fh:read(16) or ""
            fh:close()
            magic_hex = head:gsub(".", function(c) return string.format("%02X ", c:byte()) end)
            magic_ascii = head:gsub("[^%g%s]", ".")
        end
        os.remove(path)
        local ct = dl_headers and (dl_headers["content-type"] or dl_headers["Content-Type"])
        local ce = dl_headers and (dl_headers["content-encoding"] or dl_headers["Content-Encoding"])
        local ok_log2, logger2 = pcall(require, "logger")
        if ok_log2 then
            logger2.info("[bookshelf][bookorbit] coverBB: downloaded file for book", key,
                "did not decode as an image (ok=", tostring(ok_bb), ")",
                "content-type=", tostring(ct), "content-encoding=", tostring(ce),
                "size=", tostring(size), "bytes",
                "magic=", tostring(magic_hex), "(", tostring(magic_ascii), ")",
                "-- removed cached file")
        end
        diag("coverBB: RenderImage failed to decode downloaded file for book", key,
             "(ok=", tostring(ok_bb), ") content-type=", tostring(ct),
             "size=", tostring(size), "magic=", tostring(magic_hex),
             "-- removed cached file")
        return nil
    end
    local w = bb.getWidth and bb:getWidth() or nil
    local h = bb.getHeight and bb:getHeight() or nil
    return bb, w, h
end

--- coverBB(record) -> bb, w, h  (or nil). Caller owns the returned bb.
-- Blocking: downloads the thumbnail synchronously on a cache miss (and
-- decodes synchronously even on a cache hit). Kept for callers that
-- genuinely need a cover right now and can afford to wait for it (e.g.
-- the hero / rebuildRecord below, showing one book, not a whole page of
-- them); the grid's render path uses scheduleCoverFills instead (see
-- further down) so a page's worth of decodes/downloads never blocks
-- the page turn itself.
function M.coverBB(record)
    if not record or not record.remote_id or record.has_cover == false then return nil end
    local key = tostring(record.remote_id)
    if _thumb_failed[key] then return nil end
    local util = require("util")
    if not util.makePath(thumbDir()) then return nil end
    cleanLegacyThumbnails()
    local path = thumbDir() .. "/" .. key .. "_" .. coverToken(record) .. ".jpg"
    local dl_headers -- captured for diagnostics if the decode below fails
    local lfs = require("libs/libkoreader-lfs")
    if lfs.attributes(path, "mode") ~= "file" then
        local ok, err_or_headers = BookOrbit.downloadCatalogThumbnail(record.remote_id, path)
        if not ok then
            _thumb_failed[key] = true
            local ok_log, logger = pcall(require, "logger")
            if ok_log then
                logger.info("[bookshelf][bookorbit] coverBB: thumbnail download failed for book",
                    key, "->", tostring(err_or_headers))
            end
            diag("coverBB: download failed for book", key, "->", tostring(err_or_headers))
            return nil
        end
        dl_headers = err_or_headers
        pruneThumbnailCache()
    end
    return decodeThumbnailFile(path, key, dl_headers)
end

--- cachedCoverBB(record) -> bb, w, h (or nil). NON-blocking in the sense
-- that it never triggers a download -- but it does still decode
-- synchronously on a disk hit, which is why the grid's render path
-- doesn't call this directly any more (see scheduleCoverFills below,
-- which decodes off the render path for hits and misses alike).
-- Exported for any caller that wants a one-off "cover if it's already
-- cached, nothing otherwise" lookup without paying for a download.
function M.cachedCoverBB(record)
    if not record or not record.remote_id or record.has_cover == false then return nil end
    local key = tostring(record.remote_id)
    local lfs = require("libs/libkoreader-lfs")
    local path = thumbDir() .. "/" .. key .. "_" .. coverToken(record) .. ".jpg"
    if lfs.attributes(path, "mode") ~= "file" then return nil end
    return decodeThumbnailFile(path, key, nil)
end

-- ---------------------------------------------------------------------
-- Batched cover fills (async decode + download)
--
-- coverBB/cachedCoverBB above are both blocking in the way that matters
-- here: coverBB downloads AND decodes synchronously, cachedCoverBB at
-- least skips the download but still decodes synchronously. Calling
-- either once per record for a whole grid page means the page's render
-- (or a page turn) sits behind N JPEG decodes and however many HTTP
-- round-trips, back to back. This section is the async alternative --
-- mirrors the official plugin's bookorbit_catalog_thumbnails.lua
-- (scheduleThumbnailDownloads / prefetchThumbnails / thumbnail_
-- generation), adapted from its Menu-based pager to Bookshelf's grid,
-- and further widened here to cover disk hits as well as misses (see
-- scheduleCoverFills' own doc comment for why):
--   * getBySource (bookshelf_book_repository.lua) hands back a page's
--     records with NO cover attached at all, then calls
--     scheduleCoverFills() with the whole page.
--   * Each record is filled in place off the render path, in small
--     batches: a decode for a disk hit, a download-then-decode for a
--     miss. onCoversReady fires after each batch that landed something
--     so the grid can repaint with whatever just landed.
--   * prefetchNextPage (currently unused -- see its own call site
--     comment in bookshelf_book_repository.lua) warms the covers for a
--     page the user hasn't paged to yet, at a slower cadence and with
--     no repaint.
-- Every entry point here is generation-gated: each fresh
-- scheduleCoverFills call bumps the generation, so a superseded
-- page/chip's leftover queue just stops touching the network/disk or
-- firing repaints instead of piling up behind the new one.
-- ---------------------------------------------------------------------

-- Same value as the official bookorbit.koplugin's identical batching
-- pattern (bookorbit_catalog_thumbnails.lua) -- a larger batch here blocks
-- roughly proportionally longer before yielding back to the UI each tick.
local THUMBNAIL_BATCH_SIZE = 2

local _thumb_generation = 0

--- cancelThumbnailJobs() -- bumps the generation, turning every
-- in-flight scheduleCoverFills/prefetchNextPage queue into a no-op on
-- its next step. Called automatically by scheduleCoverFills (a fresh
-- page always supersedes the previous one); exposed here too for
-- callers like a manual "refresh library" action that want to drop
-- stale jobs immediately.
function M.cancelThumbnailJobs()
    _thumb_generation = _thumb_generation + 1
end

-- Registered once by the grid widget (see bookshelf_widget.lua's init),
-- fired after each downloaded batch lands so the caller can repaint.
-- A single slot is enough -- there's only ever one live grid instance.
--
-- source_id (optional) identifies which chip/source the batch that just
-- landed belongs to -- the same string bookshelf_widget.lua compares
-- against the currently VISIBLE chip's source before deciding whether a
-- repaint is actually warranted. This is what lets pre-warming a
-- BookOrbit chip the user hasn't tapped to yet fill its covers quietly
-- in the background: a batch landing for a chip that isn't on screen no
-- longer forces a full _rebuild() of whatever IS on screen. A nil
-- source_id (any caller that hasn't been updated to pass one) is
-- treated as "unknown -- repaint to be safe", matching the old
-- always-repaint behaviour.
local _covers_ready_cb
function M.onCoversReady(cb)
    _covers_ready_cb = cb
end

local function fireCoversReady(source_id)
    if not _covers_ready_cb then return end
    local ok, err = pcall(_covers_ready_cb, source_id)
    if not ok then
        local ok_log, logger = pcall(require, "logger")
        if ok_log then logger.info("Bookshelf BookOrbit: onCoversReady callback failed", err) end
    end
end

--- True if `record` needs a cover download: has_cover isn't false, no
-- file already on disk at its (versioned) cache path, and it hasn't
-- already failed this session. Used by prefetchNextPage below, which
-- only wants to warm what's actually missing from disk.
local function needsThumbnail(record)
    if not (record and record.remote_id and record.has_cover ~= false) then return false end
    local key = tostring(record.remote_id)
    if _thumb_failed[key] then return false end
    local lfs = require("libs/libkoreader-lfs")
    local path = thumbDir() .. "/" .. key .. "_" .. coverToken(record) .. ".jpg"
    return lfs.attributes(path, "mode") ~= "file"
end

--- True if `record` is eligible for a cover fill at all: has_cover
-- isn't false and it hasn't already failed this session. Unlike
-- needsThumbnail above, this does NOT check disk first -- used by
-- scheduleCoverFills below, which handles disk hits and misses the
-- same way (see its doc comment for why).
local function wantsCover(record)
    if not (record and record.remote_id and record.has_cover ~= false) then return false end
    -- Already filled in (by a previous scheduleCoverFills pass over this
    -- SAME record table) -- must be excluded, not just has_cover==false.
    -- getBySource's listBooks() call can now return the identical
    -- (cached, mutated-in-place) record objects across repeated calls
    -- (see the page cache in listBooks above), and onCoversReady's
    -- _rebuild() calls scheduleCoverFills(page) again on the WHOLE page
    -- every time a batch lands. Without this check, an already-covered
    -- record decodes "successfully" again instantly (it's on disk),
    -- fireCoversReady() fires again, triggering another _rebuild(), which
    -- calls scheduleCoverFills(page) again -- forever, on a fast
    -- ~0.02s timer, since nothing ever shrinks the requeued set. This
    -- check is what makes the queue actually shrink call over call
    -- (fewer records still need a cover each time) so the cascade
    -- terminates once the whole page is filled, instead of freezing
    -- the UI in a tight synchronous rebuild loop.
    --
    -- Deliberately checks record._cover_filled, NOT record.cover_bb.
    -- cover_bb is a ONE-SHOT bb: SpineWidget frees it once a grid tile
    -- consumes it, and (as of the fix alongside this one) nils the field
    -- back out when it does, specifically so a later revisit of this same
    -- cached record doesn't pick up a dangling pointer. If this guard
    -- checked record.cover_bb directly, that nil-out would make an
    -- already-filled record look "never filled" and get silently
    -- re-downloaded/re-decoded every revisit -- harmless but wasteful.
    -- Worse, before cover_bb was ever nulled, a freed-but-still-set
    -- cover_bb made this return false forever, so a page revisited after
    -- its bb had been consumed never got queued again: the grid picked
    -- the stale/freed bb back up as effective_bb and either double-freed
    -- it or scaled it as source pixels -- the distorted-covers-after-
    -- paging-away-and-back bug. _cover_filled is a plain boolean set once
    -- in fillOneCover and never cleared, independent of the bb's runtime
    -- lifetime, so the anti-loop dedup here keeps working regardless of
    -- whether/when cover_bb itself gets freed and nulled.
    if record._cover_filled then return false end
    return not _thumb_failed[tostring(record.remote_id)]
end

local function downloadOneThumbnail(record, tag)
    local key = tostring(record.remote_id)
    local path = thumbDir() .. "/" .. key .. "_" .. coverToken(record) .. ".jpg"
    local ok, err = BookOrbit.downloadCatalogThumbnail(record.remote_id, path)
    if not ok then
        _thumb_failed[key] = true
        diag(tag, ": download failed for book", key, "->", tostring(err))
    end
    return ok
end

--- fillOneCover(record, tag) -- decodes record's cover if it's already
-- on disk, otherwise downloads it first (same HTTP call
-- downloadOneThumbnail makes) and then decodes -- and on success sets
-- record.cover_bb/cover_w/cover_h (and record.has_cover = true) on the
-- record in place. Returns true if it actually changed anything a
-- caller should repaint for.
local function fillOneCover(record, tag)
    local key = tostring(record.remote_id)
    local path = thumbDir() .. "/" .. key .. "_" .. coverToken(record) .. ".jpg"
    local lfs = require("libs/libkoreader-lfs")
    if lfs.attributes(path, "mode") ~= "file" then
        if not downloadOneThumbnail(record, tag) then return false end
    end
    local bb, w, h = decodeThumbnailFile(path, key, nil)
    if not bb then return false end
    record.cover_bb, record.cover_w, record.cover_h = bb, w, h
    record.has_cover = true
    -- Persistent "we've filled this at least once" marker, independent of
    -- cover_bb's own lifetime -- see wantsCover's comment above for why
    -- this can't just be `record.cover_bb`.
    record._cover_filled = true
    return true
end

--- scheduleCoverFills(records) -- fills EVERY eligible record's cover in
-- place (decoding a disk hit, or downloading-then-decoding a miss),
-- off the render path, in small batches -- getBySource hands back
-- `records` with no cover attached at all, and this fills them in
-- shortly after, firing onCoversReady() after each batch that landed
-- something so the caller can repaint.
--
-- This deliberately includes disk HITS too, not just misses: even
-- decoding an already-downloaded JPEG is real synchronous CPU work
-- (RenderImage), and doing a whole page's worth of that inline in the
-- render path (the old behaviour) was exactly the "device feels busy
-- right as you turn the page" stall this exists to avoid -- covers
-- being ready doesn't help if reaching them still means decoding
-- a dozen-plus JPEGs before the page can paint. The trade-off: a page
-- turn now always paints covers-blank-then-fills-in a beat later, even
-- for a page that's 100% disk-cached, rather than occasionally
-- painting fully populated on the first frame.
--
-- Safe to call on every render (e.g. once per _rebuild): a no-op when
-- nothing's eligible, and any leftover queue from a previous call is
-- superseded (see cancelThumbnailJobs above) rather than running
-- alongside the new one.
--
-- `source_id` (optional) is passed straight through to onCoversReady so
-- the caller can tell a background-warmed chip's batch apart from the
-- currently-visible chip's -- see onCoversReady's doc comment above.
function M.scheduleCoverFills(records, source_id)
    local queue = {}
    for _, record in ipairs(records or {}) do
        if wantsCover(record) then queue[#queue + 1] = record end
    end
    if #queue == 0 then return end

    local util = require("util")
    if not util.makePath(thumbDir()) then return end

    M.cancelThumbnailJobs()
    local generation = _thumb_generation
    local ok_ui, UIManager = pcall(require, "ui/uimanager")
    if not (ok_ui and UIManager) then return end

    local function step()
        if generation ~= _thumb_generation then return end
        local landed_any = false
        for _ = 1, THUMBNAIL_BATCH_SIZE do
            local record = table.remove(queue, 1)
            if not record then break end
            if fillOneCover(record, "scheduleCoverFills") then
                landed_any = true
            end
        end
        if generation ~= _thumb_generation then return end
        if landed_any then fireCoversReady(source_id) end
        if #queue > 0 then
            -- Short tick either way -- decode-only batches are cheap
            -- enough that this cadence barely matters for them; download
            -- batches are still gated by the HTTP round-trip itself, not
            -- by this delay.
            UIManager:scheduleIn(0.02, step)
        else
            pruneThumbnailCache()
        end
    end
    UIManager:scheduleIn(0.02, step)
end

--- prefetchNextPage(source_id, offset, limit) -- off the render path,
-- fetches the book list for the given page (and caches it -- see
-- cacheNextPage/consumeNextPageCache above -- so the actual page turn,
-- when it happens, is served from that cache instead of paying for the
-- same catalogBooks() request a second time) and warms (downloads,
-- doesn't decode/repaint) whatever covers it's missing, at a slower
-- cadence than scheduleCoverFills since nothing's waiting on it. Purely a nice-to-have: silent on any failure (offline, server
-- error, superseded generation, etc.) since there's no visible page
-- depending on this succeeding yet. Callers pass the offset/limit of
-- the page one step past what's currently on screen.
function M.prefetchNextPage(source_id, offset, limit)
    local generation = _thumb_generation
    local ok_ui, UIManager = pcall(require, "ui/uimanager")
    if not (ok_ui and UIManager) then return end
    UIManager:scheduleIn(1.0, function()
        if generation ~= _thumb_generation then return end
        local ok_net, NetworkMgr = pcall(require, "ui/network/manager")
        if not (ok_net and NetworkMgr and NetworkMgr.isOnline and NetworkMgr:isOnline()) then return end
        -- listBooks does its own blocking HTTP call, same as everywhere
        -- else in this module -- fine here since this whole function
        -- already runs on a deferred tick, off the caller's render path.
        local records, total = M.listBooks(source_id, offset, limit)
        if generation ~= _thumb_generation then return end
        -- Cache the list itself (not just the covers below) -- this is
        -- the fix for page turns feeling slow even once covers were
        -- already warmed: without this, the actual book-list fetch for
        -- the page you turn to was always a fresh network round-trip,
        -- identical to the one this function just made.
        cacheNextPage(source_id, offset, limit, records, total)
        -- Warm the next page's synopses too (disk cache only, no repaint
        -- -- see prefetchDescriptions' doc comment below) alongside its
        -- covers, so paging forward and then opening a book's hero view
        -- doesn't pay for the description round trip either.
        M.prefetchDescriptions(records)
        local queue = {}
        for _, record in ipairs(records or {}) do
            if needsThumbnail(record) then queue[#queue + 1] = record end
        end
        if #queue == 0 then return end
        local util = require("util")
        if not util.makePath(thumbDir()) then return end
        local function step()
            if generation ~= _thumb_generation then return end
            local record = table.remove(queue, 1)
            if not record then
                pruneThumbnailCache()
                return
            end
            downloadOneThumbnail(record, "prefetchNextPage")
            UIManager:scheduleIn(0.08, step)
        end
        UIManager:scheduleIn(0.08, step)
    end)
end

-- ---------------------------------------------------------------------
-- Description cache (hero synopsis)
--
-- The grid's listBooks() records come from catalogBooks(), which never
-- returns a description (only the per-book detail endpoint does) -- so a
-- plain toRecord() has no synopsis for the hero to show, and rebuildRecord
-- below has always fetched it fresh from /catalog/books/<id>. Until now
-- that fetch was UNCACHED: every single tap that promotes a BookOrbit
-- book into the hero paid a full blocking HTTP round trip for the
-- synopsis, even for a book whose detail was already fetched and shown
-- a minute (or one tap) ago -- e.g. tap A, tap B, tap A again re-fetched
-- A's description from the server a second time. Local library books
-- never pay this: their description already lives in KOReader's own
-- on-disk BIM cache from the last library scan (Repo.buildBook just
-- reads it), which is why they show a synopsis noticeably faster than
-- a BookOrbit book on the same tap.
--
-- Cached to disk (survives a KOReader restart, unlike an in-memory
-- table) and versioned by the book's updated_at -- same field, same
-- reasoning as coverToken above: a real server-side edit to the book
-- still invalidates the cached synopsis instead of serving it stale
-- forever. A record with no updated_at at all (older/partial data)
-- degrades to "never self-invalidates", same fallback behaviour
-- coverToken already has -- the manual "Refresh library" action drops
-- this cache too (see bookshelf_widget.lua) as a backstop.
-- ---------------------------------------------------------------------
local _desc_cache_settings

local function descCacheSettings()
    if not _desc_cache_settings then
        local LuaSettings = require("luasettings")
        local DataStorage = require("datastorage")
        _desc_cache_settings = LuaSettings:open(
            DataStorage:getSettingsDir() .. "/bookshelf_bookorbit_descriptions.lua")
    end
    return _desc_cache_settings
end

--- cachedDescription(remote_id, updated_at) -> description string, or
-- nil on a cold cache OR a version mismatch (the cached entry's
-- updated_at disagrees with the caller's) -- either way the caller
-- should treat this as a miss and re-fetch.
local function cachedDescription(remote_id, updated_at)
    local ok, entry = pcall(function()
        return descCacheSettings():readSetting(tostring(remote_id))
    end)
    if not ok or not entry then return nil end
    if entry.updated_at and updated_at and entry.updated_at ~= updated_at then
        return nil
    end
    return entry.description
end

local function cacheDescription(remote_id, updated_at, description)
    if not remote_id or not description or description == "" then return end
    pcall(function()
        local settings = descCacheSettings()
        settings:saveSetting(tostring(remote_id), {
            description = description,
            updated_at  = updated_at,
        })
        settings:flush()
    end)
end

--- invalidateDescriptionCache() -- drops every cached synopsis, so the
-- next hero view of any BookOrbit book re-fetches it. Mirrors
-- invalidateDiscoverCache/invalidateGroupCache above; wired into the
-- manual "Refresh library" action as a backstop for the "no updated_at
-- to compare" case noted above.
function M.invalidateDescriptionCache()
    pcall(function()
        descCacheSettings():purge()
    end)
end

-- Per-session "already tried, gave up" set for description fetches --
-- same role _thumb_failed plays for covers above: a book whose detail
-- request failed once (offline, 401, deleted server-side, ...) isn't
-- retried on every subsequent pre-warm/prefetch pass this session. Reset
-- implicitly on plugin reload; a manual retry always happens the next
-- time the book is actually opened to the hero view (rebuildRecord
-- doesn't consult this set).
local _desc_failed = {}

--- needsDescription(record) -> true if `record` is a BookOrbit book
-- whose synopsis isn't already cached on disk (see cachedDescription
-- above) and hasn't already failed to fetch this session. Mirrors
-- needsThumbnail's shape for covers.
local function needsDescription(record)
    if not (record and record.remote_id) then return false end
    if _desc_failed[tostring(record.remote_id)] then return false end
    return cachedDescription(record.remote_id, record.updated_at) == nil
end

--- prefetchDescriptions(records) -- for each record in `records` that's
-- missing a cached synopsis (needsDescription above), fetches the
-- per-book detail endpoint and caches the description to disk via the
-- same cachedDescription/cacheDescription pair rebuildRecord uses for an
-- on-demand hero-view open. By the time a warmed book is actually
-- opened, rebuildRecord's cachedDescription() call is a cache hit and
-- skips the network round trip entirely -- the same win prefetched
-- covers already give a page turn, just for the synopsis instead of the
-- thumbnail.
--
-- Deliberately does NOT mutate the records passed in (no
-- record.description, no cover work) -- unlike rebuildRecord, this never
-- feeds a live render, so there's nothing to repaint and covers already
-- have their own warm path (scheduleCoverFills / the thumbnail queue in
-- prefetchNextPage below). This function's only job is populating the
-- on-disk description cache ahead of time.
--
-- Throttled one book at a time -- a blocking HTTP request per book, same
-- cost class as a single cover download -- and generation-gated against
-- the SAME _thumb_generation counter cover jobs use (see
-- cancelThumbnailJobs's doc comment): a chip switch or manual refresh
-- should drop all of a superseded chip's background BookOrbit work
-- uniformly, not just its cover queue.
function M.prefetchDescriptions(records)
    local generation = _thumb_generation
    local ok_ui, UIManager = pcall(require, "ui/uimanager")
    if not (ok_ui and UIManager) then return end
    local queue = {}
    local seen = {}
    for _, record in ipairs(records or {}) do
        local key = record and record.remote_id and tostring(record.remote_id)
        if key and not seen[key] and needsDescription(record) then
            seen[key] = true
            queue[#queue + 1] = record
        end
    end
    if #queue == 0 then return end
    local function step()
        if generation ~= _thumb_generation then return end
        local record = table.remove(queue, 1)
        if not record then return end
        local detail, err = BookOrbit.catalogBook(record.remote_id)
        if detail then
            cacheDescription(record.remote_id, detail.updatedAt or record.updated_at,
                detail.description)
        else
            _desc_failed[tostring(record.remote_id)] = true
            diag("prefetchDescriptions: detail fetch failed for book",
                record.remote_id, "->", tostring(err))
        end
        if #queue > 0 then UIManager:scheduleIn(0.08, step) end
    end
    UIManager:scheduleIn(0.08, step)
end

-- ---------------------------------------------------------------------
-- Full-record rebuild (hero / preview)
--
-- Separately from the description above, the cover_bb the grid attached
-- to a record is a ONE-SHOT bb: the grid tile already painted (and
-- freed) it by the time a tap promotes that same record into the hero,
-- so reusing it there paints nothing. Repo.buildBook can't fix either of
-- these for a "bookorbit://" filepath (there's no real file/DocSettings
-- for it), so callers that promote a tapped/selected BookOrbit book into
-- the hero should call this instead of relying on the generic
-- Repo.buildBook -- see Repo.buildPreviewBook.
-- ---------------------------------------------------------------------

--- rebuildRecord(fallback) -> record or nil
-- fallback is the existing list record for this book (must carry
-- remote_id). Resolves the book's description -- from the on-disk cache
-- above on a hit, otherwise the per-book detail endpoint (which also
-- populates the cache for next time) -- and a fresh cover thumbnail;
-- every other field is carried over from fallback unchanged. Returns nil
-- if a required detail request fails (offline, 401, server error, etc.)
-- so the caller falls back to reusing fallback as-is -- same
-- nil-means-"use the old record" contract Repo.buildBookMeta uses.
function M.rebuildRecord(fallback)
    if not fallback or not fallback.remote_id then return nil end
    if not M.isAvailable() then return nil end

    local record = {}
    for k, v in pairs(fallback) do
        -- Never carry the old cover_bb forward -- it may already be freed
        -- (see above); coverBB below gets a fresh one.
        if k ~= "cover_bb" then record[k] = v end
    end

    local cached_desc = cachedDescription(fallback.remote_id, fallback.updated_at)
    if cached_desc ~= nil then
        record.description = cached_desc
    else
        local detail, err = BookOrbit.catalogBook(fallback.remote_id)
        if not detail then
            local ok_log, logger = pcall(require, "logger")
            if ok_log then logger.info("Bookshelf BookOrbit: rebuildRecord failed", err) end
            return nil
        end
        record.description = detail.description
        if detail.updatedAt then record.updated_at = detail.updatedAt end
        cacheDescription(fallback.remote_id, record.updated_at, record.description)
    end

    local bb, cw, ch = M.coverBB(record)
    if bb then
        record.cover_bb, record.cover_w, record.cover_h = bb, cw, ch
        record.has_cover = true
    end
    return record
end

-- ---------------------------------------------------------------------
-- Opening: download the book's primary file on first open, then remember
-- where it landed so a later tap just opens the local copy.
-- ---------------------------------------------------------------------

local LuaSettings = require("luasettings")
local DataStorage = require("datastorage")
local _dl_settings

local function dlSettings()
    if not _dl_settings then
        _dl_settings = LuaSettings:open(DataStorage:getSettingsDir() .. "/bookshelf_bookorbit_downloads.lua")
    end
    return _dl_settings
end

--- True if `filepath` is one of this module's synthetic placeholders.
function M.isBookOrbitPath(filepath)
    return type(filepath) == "string" and filepath:sub(1, 12) == "bookorbit://"
end

--- resolveOpenPath(record, callback, hooks) -- callback(path) on success,
-- callback(nil, err) on failure. Non-blocking from the caller's point of
-- view: does its own network calls, then invokes callback once it knows
-- the answer. If a previous download for this book is still on disk, the
-- callback fires with that path immediately and no network is touched.
--
-- `hooks` (optional) lets the caller give progress feedback without having
-- to guess up front whether this call will need the network at all:
--   * hooks.on_download_start() -- fired right before bytes are actually
--     requested from the server, i.e. only when the dedupe check against
--     the expected on-disk path misses. Not fired for the instant
--     settings-cache hit, nor when that dedupe check finds an existing file
--     to open instead -- the catalog-detail lookup itself stays silent.
function M.resolveOpenPath(record, callback, hooks)
    hooks = hooks or {}
    if not record or not record.remote_id then
        callback(nil, "bad_record")
        return
    end
    local lfs = require("libs/libkoreader-lfs")
    local s = dlSettings()
    local key = tostring(record.remote_id)
    local cached = s:readSetting(key)
    if cached and lfs.attributes(cached, "mode") == "file" then
        -- Already downloaded -- opening it needs no network at all, so this
        -- path stays fully offline-safe (no Wi-Fi auto-connect below). No
        -- hook fires: the caller should treat this exactly like opening any
        -- other on-device book, with no "talking to BookOrbit" message.
        callback(cached)
        return
    end
    -- Everything past this point (fetch detail, download the file) is a
    -- network call, but the catalog-detail lookup alone is quick and may
    -- still end in a dedupe hit, so no message is shown yet -- only
    -- hooks.on_download_start (below) warrants telling the user anything.
    -- Auto-connect first -- turns Wi-Fi on / reconnects a saved network,
    -- prompting only if none is saved -- instead of the old behaviour of
    -- failing immediately with "offline" while the radio is simply off.
    local ok_net, NetworkMgr = pcall(require, "ui/network/manager")
    local runWhenOnline = (ok_net and NetworkMgr and NetworkMgr.runWhenOnline)
        and function(fn) NetworkMgr:runWhenOnline(fn) end
        or function(fn) fn() end  -- NetworkMgr unavailable -- fall back to trying directly
    runWhenOnline(function()
        local detail, err = BookOrbit.catalogBook(record.remote_id)
        if not detail then
            callback(nil, err)
            return
        end
        local files = detail.files or {}
        if #files == 0 then
            callback(nil, "no_file")
            return
        end
        local file = files[1]
        for _, f in ipairs(files) do
            if f.role == "primary" then file = f; break end
        end
        local dir  = BookOrbit.downloadDestDir(BookOrbit.downloadDir(), detail)
        local base = BookOrbit.buildFilenameBase(detail, record.title)
        local ext  = file.format or "epub"
        local canonical_path = dir .. "/" .. base .. "." .. ext
        -- If the exact file we'd otherwise download to already exists --
        -- placed there by other means, left over from a previous install,
        -- downloaded outside this plugin, etc. -- treat it as this book
        -- and open it directly instead of downloading a second copy and
        -- suffixing it "(1)". This is a filename match, not a content
        -- verification: the server doesn't expose a comparable hash for
        -- the remote file before downloading it (BookOrbit.getBookHash is
        -- a LOCAL partial-MD5 of bytes already on disk, used for progress
        -- sync -- there's nothing to compare it against here without
        -- downloading first, which defeats the point). In practice a
        -- false match needs two different books landing at the exact same
        -- sanitized title AND the exact same Author[/Series] subfolder,
        -- which is unlikely but not impossible -- if that ever bites,
        -- deleting the wrongly-matched local file forces a real
        -- (uniquely-suffixed) download next time.
        if lfs.attributes(canonical_path, "mode") == "file" then
            local ok_log, logger = pcall(require, "logger")
            if ok_log then
                logger.info("BookOrbit: resolveOpenPath found an existing file at the expected " ..
                    "download path, opening it instead of re-downloading:", canonical_path)
            end
            s:saveSetting(key, canonical_path)
            s:flush()
            callback(canonical_path)
            return
        end
        local path = BookOrbit.uniqueDownloadPath(dir, base, ext)
        if hooks.on_download_start then hooks.on_download_start() end
        local ok, derr = BookOrbit.downloadCatalogFile(file.id, path)
        if not ok then
            callback(nil, derr)
            return
        end
        s:saveSetting(key, path)
        s:flush()
        callback(path)
    end)
end

return M
