--[[
bookshelf_bookorbit_source.lua — bridges a BookOrbit server's catalog into
Bookshelf's chip/source system, the same role bookshelf_kobo_source.lua
plays for the Kobo virtual library: it is the ONLY point of contact between
Repo.getBySource / the chip editor and lib/bookshelf_bookorbit.lua's HTTP
client, so callers never touch BookOrbit directly.

Where this differs from the Kobo bridge: Kobo's virtual library is local and
synchronous (decrypt-on-demand); BookOrbit's catalog is a REMOTE, PAGED list,
and its covers are separate network downloads. So instead of one
`listBooks()` that returns everything, this module fetches one page at a
time (`listBooks(id, offset, limit)`), and `coverBB` downloads (and disk-
caches) a thumbnail synchronously the first time a given book is asked for —
the same "blocking network call from a UI callback" style already used by
bookshelf_bookorbit_catalog.lua and bookshelf_cover_fetch.lua elsewhere in
this plugin, so a chip switch or page turn costs one request per book
whose cover isn't cached yet, then nothing on repaint.

Chip "source.id" encoding: "<query>:<rest>", e.g. "all:", "recent:",
"continue:", "libraries:42", "collections:7", "smart-scopes:3",
"authors:Iain M. Banks", "series:Culture". Built by the chip editor's
BookOrbit picker (encodeId below); decoded here into a catalogBooks() query.
This mirrors bookshelf_bookorbit_catalog.lua's paramsForEntry, independently,
since that file is a separate, already-shipped browsing UI this integration
does not touch.
]]

local BookOrbit = require("lib/bookshelf_bookorbit")
local _         = require("lib/bookshelf_i18n").gettext

local M = {}

function M.isAvailable()
    return BookOrbit.isConfigured()
end

-- ---------------------------------------------------------------------
-- Source id encode/decode
-- ---------------------------------------------------------------------

-- Root-level "special" sections that page straight into catalogBooks
-- without a section/entry drill-down.
local ROOT_SPECIAL = {
    ["all"]      = true,
    ["recent"]   = true,
    ["continue"] = true,
    ["discover"] = true,
}

function M.encodeId(query, rest)
    return tostring(query or "all") .. ":" .. tostring(rest or "")
end

function M.decodeId(id)
    local query, rest = (id or ""):match("^([^:]*):(.*)$")
    if not query or query == "" then return "all", "" end
    return query, rest
end

-- Builds the catalogBooks() query table for one chip's source.id.
function M.queryForId(id)
    local query, rest = M.decodeId(id)
    if query == "recent" then
        return { sort = "recently_added" }
    elseif query == "continue" then
        return { sort = "recently_read", readStatus = "reading" }
    elseif query == "libraries" then
        return { libraryId = rest, sort = "title" }
    elseif query == "collections" then
        return { collectionId = rest, sort = "title" }
    elseif query == "smart-scopes" then
        return { smartScopeId = rest, sort = "title" }
    elseif query == "authors" then
        return { author = rest, sort = "title" }
    elseif query == "series" then
        return { series = rest, sort = "series" }
    end
    return { sort = "title" } -- "all" and anything unrecognised
end

-- Friendly default label for a chip whose source.id is `id` -- used by the
-- chip editor's "New chip" auto-rename QoL. Doesn't hit the network.
function M.labelForId(id, fallback_title)
    if fallback_title and fallback_title ~= "" then return fallback_title end
    local query = M.decodeId(id)
    if query == "recent" then return "Recently added"
    elseif query == "continue" then return "Continue reading"
    elseif query == "all" then return "All books"
    elseif query == "discover" then return "Discover something new"
    end
    return "BookOrbit"
end

-- ---------------------------------------------------------------------
-- Picker data (used only by the chip editor, never by getBySource)
-- ---------------------------------------------------------------------

--- Root choices for the "BookOrbit section" picker: the special shortcuts
-- always offered, plus whatever drill-down sections the server advertises.
-- Returns { { value = id, label = str, needs_drill = bool, section = str|nil } }, err
function M.fetchRootChoices()
    local body, err = BookOrbit.catalogRoot()
    if not body then return nil, err end
    local choices = {
        { value = { id = M.encodeId("all"),      label = "All books" },      label = "All books" },
        { value = { id = M.encodeId("recent"),   label = "Recently added" }, label = "Recently added" },
        { value = { id = M.encodeId("continue"), label = "Continue reading" }, label = "Continue reading" },
        { value = { id = M.encodeId("discover"), label = "Discover something new" }, label = "Discover something new" },
    }
    local seen_special = { ["all-books"] = true, ["recent"] = true, ["continue-reading"] = true, ["search"] = true }
    for _, section in ipairs(body.sections or {}) do
        if not seen_special[section.section] then
            -- value is a marker table, never nil -- nil is reserved for
            -- "the user cancelled" in the chip editor's picker callback.
            choices[#choices + 1] = {
                value = { drill = section.section, title = section.title },
                label = (section.title or section.section) .. "  \xE2\x96\xB8", -- ▸
            }
        end
    end
    return choices
end

--- Entries within one drill-down section (libraries/collections/
-- smart-scopes/authors/series). `title` is the section's display title
-- (from fetchRootChoices), used to label the prepended "whole section"
-- choice below -- falls back to a generic "All items" if omitted.
-- Returns { { value = id, label = str } }, err
function M.fetchSectionChoices(section, title)
    local body, err = BookOrbit.catalogSection(section, { page = 1 })
    if not body then return nil, err end
    local choices = {}
    -- A leaf for the section itself, not one entry within it -- e.g.
    -- picking "Authors" without drilling into a specific author. Maps to
    -- an id with an empty `rest` ("authors:"), which queryForId turns into
    -- a query with no author/library/collection/etc. filter -- effectively
    -- every book, same as the "All books" shortcut, but reachable from
    -- (and named after) this section for chip-naming purposes.
    local all_label = title and ("All " .. title) or _("All items")
    choices[#choices + 1] = {
        value = { id = M.encodeId(section, ""), label = all_label },
        label = all_label,
    }
    for _, entry in ipairs(body.items or {}) do
        local label = entry.title or "Untitled"
        if entry.count then label = label .. "  (" .. tostring(entry.count) .. ")" end
        choices[#choices + 1] = {
            value = { id = M.encodeId(section, entry.id), label = entry.title or "Untitled" },
            label = label,
        }
    end
    return choices, nil, body.hasNext
end

-- ---------------------------------------------------------------------
-- Book records (used by Repo.getBySource)
-- ---------------------------------------------------------------------

local function firstAuthor(b)
    return b.authors and b.authors[1] or nil
end

local function statusFor(b, pct)
    local s = b.readStatus
    if s == "unread" or s == "reading" or s == "on_hold" or s == "finished" then return s end
    if pct >= 1 then return "finished" end
    if pct > 0 then return "reading" end
    return "unread"
end

function M.toRecord(b)
    local pct_raw = tonumber(b.progressPercentage) or 0
    local pct = pct_raw > 1 and (pct_raw / 100) or pct_raw
    local author = firstAuthor(b)
    return {
        -- Not a real path: distinguishes these records everywhere the grid
        -- keys by filepath (selection, cache, cover frame refresh) without
        -- colliding with any real file. Never handed to lfs/io directly --
        -- _openBook resolves a real path before opening (see is_bookorbit).
        filepath       = "bookorbit://" .. tostring(b.id),
        filename       = b.title or "Untitled",
        title          = b.title or "Untitled",
        display_title  = b.title or "Untitled",
        author         = author,
        authors        = b.authors,
        series_name    = b.seriesName,
        series_num     = b.seriesIndex ~= nil and tostring(b.seriesIndex) or nil,
        book_pct       = pct,
        status         = statusFor(b, pct),
        read_status    = statusFor(b, pct),
        rating         = nil,
        added_time     = 0,
        last_read_time = 0,
        attr           = { mode = "file", size = 0, modification = 0 },
        format         = b.formats and b.formats[1],
        remote_id      = b.id,
        has_cover      = b.hasCover ~= false,
        is_bookorbit   = true,
    }
end

--- Set (by listBooks below) when a shelf chip came up empty purely because
-- the device was offline -- as opposed to BookOrbit being unconfigured, or a
-- real HTTP/server error. main.lua's onNetworkConnected consumes this to
-- decide whether a freshly-restored connection is worth an automatic shelf
-- refresh, without forcing a rebuild on every unrelated Wi-Fi event.
local _offline_miss = false

--- consumeOfflineMiss() -> bool
-- Read-and-clear _offline_miss. Called once per NetworkConnected broadcast.
function M.consumeOfflineMiss()
    local v = _offline_miss
    _offline_miss = false
    return v
end

-- Debounce guard for _tryAutoConnect below -- shared across all callers/pages
-- since a page-turn or repeated rebuild can call listBooks many times a
-- second while still offline.
local _reconnect_pending = false

--- Kick off (at most once per ~30s while offline) an attempt to bring Wi-Fi
-- up in the background: turns it on / reconnects a saved network, prompting
-- the user only if none is saved (NetworkMgr:runWhenOnline never forces a
-- silent connection past that). Debounced so a shelf that's rendered or
-- scrolled repeatedly while offline doesn't retry -- or re-prompt -- on
-- every single call; roughly once per this window instead.
--
-- Deliberately fire-and-forget: the actual shelf refresh happens via
-- main.lua's onNetworkConnected + consumeOfflineMiss above once the
-- connection (this attempt, or the user turning Wi-Fi on themselves)
-- actually lands -- not via a callback threaded back through here, since
-- listBooks itself must stay synchronous for the grid's rebuild path.
local function _tryAutoConnect()
    if _reconnect_pending then return end
    local ok_net, NetworkMgr = pcall(require, "ui/network/manager")
    if not (ok_net and NetworkMgr and NetworkMgr.runWhenOnline) then return end
    _reconnect_pending = true
    local ok_ui, UIManager = pcall(require, "ui/uimanager")
    if ok_ui and UIManager then
        -- Release the guard after a while regardless of outcome -- a
        -- dismissed Wi-Fi prompt (or no saved network at all) shouldn't
        -- permanently block every later retry for the rest of the session.
        UIManager:scheduleIn(30, function() _reconnect_pending = false end)
    end
    NetworkMgr:runWhenOnline(function() _reconnect_pending = false end)
end

-- One cached Discover batch per source id (there's really only ever one,
-- "discover:", but keying by id costs nothing and stays consistent with
-- _known_total below). /catalog/dashboard/discover has no page/size params
-- -- every request is a fresh random selection -- so unlike the other
-- root queries, this can't be re-fetched per page turn without silently
-- swapping in different books on every "next page" tap. Fetched once,
-- then paginated client-side out of this cache; the total is exact and
-- known from the very first page, since the whole batch is already held.
local _discover_cache = {}

-- fetchDiscover(id, force) -> records (array, may be empty on failure)
-- force=true re-hits the server for a brand-new random batch (the
-- "reroll" -- see M.rerollDiscover / invalidateDiscoverCache below);
-- otherwise reuses whatever batch this source id already has cached.
local function fetchDiscover(id, force)
    if not force and _discover_cache[id] then return _discover_cache[id] end
    local body, err = BookOrbit.catalogDiscover()
    if not body then
        local ok_log, logger = pcall(require, "logger")
        if ok_log then logger.info("Bookshelf BookOrbit: catalogDiscover failed", err) end
        -- Keep serving the last good batch (if any) rather than blanking
        -- the shelf on a transient network hiccup; only a genuine first
        -- fetch failure returns empty.
        return _discover_cache[id] or {}
    end
    local records = {}
    for _, b in ipairs(body.discover or {}) do
        records[#records + 1] = M.toRecord(b)
    end
    _discover_cache[id] = records
    return records
end

--- rerollDiscover(id) -> fetches and caches a brand-new random batch for
-- this source id, mirroring the official plugin's Discover reroll button.
-- Callers should rebuild the chip afterwards to show the new set.
function M.rerollDiscover(id)
    return fetchDiscover(id, true)
end

--- invalidateDiscoverCache() -> drops every cached Discover batch, so the
-- next fetch for any Discover chip re-rolls. Cheap to call unconditionally
-- (e.g. from the shelf's existing manual swipe-down refresh) even when no
-- Discover chip is currently in view.
function M.invalidateDiscoverCache()
    _discover_cache = {}
end

-- Highest "total" ever synthesised per source id -- fallback path only,
-- for the rare response that omits body.total (see listBooks below). Keyed
-- by the chip's source.id string, so different chips/sections never bleed
-- into each other's count. Paging backward must not forget a total the
-- forward page already confirmed to exist -- otherwise the footer
-- regresses from e.g. "3 of 4" back down to "2 of 3" the moment the user
-- taps the left chevron, even though page 3 is known to exist.
local _known_total = {}

--- listBooks(id, offset, limit) -> records, total
-- Maps the grid's offset/limit window onto one catalogBooks() page (limit
-- is the view size, so this is exactly one request per page turn).
--
-- /koreader/plugin/catalog/books actually DOES report an exact total --
-- confirmed against the official bookorbit.koplugin's catalog browser
-- (bookorbit_catalog.lua), which already computes
-- `page_count = ceil(body.total / body.size)` for its own pagination.
-- This bridge previously ignored that field and synthesised a fake total
-- from `hasNext` alone (just far enough past the current window to keep
-- forward paging enabled), which is why the chip footer always read
-- "page N of N+1" instead of the real page count. Now body.total is used
-- whenever the server sends it; the old hasNext-based guess only kicks in
-- as a fallback for a response that (for whatever reason) omits it, and
-- even then never regresses below a total a later page already confirmed.
function M.listBooks(id, offset, limit)
    if not M.isAvailable() then return {}, offset or 0 end
    local ok_net, NetworkMgr = pcall(require, "ui/network/manager")
    if ok_net and NetworkMgr and NetworkMgr.isOnline and not NetworkMgr:isOnline() then
        _offline_miss = true
        _tryAutoConnect()
        return {}, offset or 0
    end
    offset = offset or 0
    limit  = (limit and limit > 0) and limit or 24

    -- Discover doesn't come from catalogBooks at all -- it's a fixed,
    -- pre-fetched random batch (see fetchDiscover above), sliced here the
    -- same way the "search" tip and group drilldowns slice their own
    -- fully-hydrated lists. Total is exact: it's just the batch size.
    if (M.decodeId(id)) == "discover" then
        local records = fetchDiscover(id, false)
        local total   = #records
        local stop    = math.min(offset + limit, total)
        local page_slice = {}
        for i = offset + 1, stop do
            page_slice[#page_slice + 1] = records[i]
        end
        return page_slice, total
    end

    local page = math.floor(offset / limit) + 1
    local query = M.queryForId(id)
    query.page = page
    query.size = limit

    local body, err = BookOrbit.catalogBooks(query)
    if not body then
        local ok_log, logger = pcall(require, "logger")
        if ok_log then logger.info("Bookshelf BookOrbit: listBooks failed", err) end
        return {}, offset
    end
    local records = {}
    for _, b in ipairs(body.items or {}) do
        records[#records + 1] = M.toRecord(b)
    end
    local total = tonumber(body.total)
    if not total then
        -- Fallback for a response that didn't include total: same
        -- "just far enough ahead to keep paging" guess as before, clamped
        -- so it never undercuts a total a later page already proved.
        total = offset + #records + (body.hasNext and limit or 0)
        local prev = _known_total[id]
        if prev and prev > total then total = prev end
        _known_total[id] = total
    end
    return records, total
end

-- ---------------------------------------------------------------------
-- Grouped browsing (Authors / Series root -> folder-like group tiles)
--
-- A chip pointed at the "All authors"/"All series" leaf (id "authors:" /
-- "series:", built by fetchSectionChoices above) used to fall straight
-- into listBooks with an empty author/series filter -- i.e. every book,
-- flat, no grouping at all, even though the "Browse catalog" menu already
-- lets you drill authors/series like folders. This section gives chips
-- the same folder-like browsing: the root shows one tile per author/
-- series (see listGroups), and BookshelfWidget:_expandBookOrbitGroup
-- drills into a specific one via the existing _drilldown_path machinery
-- -- which then lands back on plain listBooks with that one entry's id,
-- so the drilled-in list is exactly the already-working single-author/
-- single-series chip path.
--
-- catalogSection() has no caller-controllable page size (unlike
-- catalogBooks, which takes size=), so it can't be mapped onto the grid's
-- offset/limit window the way listBooks() maps onto catalogBooks() --
-- the server's own fixed page size and the grid's view size (3/6/9
-- depending on layout) would drift apart. Authors/series lists are just
-- names + counts (no per-entry paging concern), so instead this walks
-- every catalogSection() page once, caches the flattened list in memory
-- (TTL below, same shape as _discover_cache above), and slices
-- offset/limit out of that cached list locally.
-- ---------------------------------------------------------------------

local _group_cache = {}  -- section -> { entries = {...}, first_books = {[entry_id]=book|false}, at = os.time() }
local GROUP_CACHE_TTL = 300  -- seconds
-- Safety cap on how many catalogSection() pages fetchSectionBucket
-- will walk for one section. Generous for any realistic author/series
-- list; bounded so a server bug (hasNext always true) can't loop forever.
local GROUP_FETCH_PAGE_CAP = 40

--- True if `id` is the ungrouped root of a groupable section -- what
-- fetchSectionChoices labels "All <section>" ("authors:" or "series:"
-- with no specific entry picked). Any other id (a specific author/
-- series, or a non-groupable root like "recent"/"all"/"discover") is
-- unaffected and keeps going through the flat listBooks path.
function M.isGroupRoot(id)
    local query, rest = M.decodeId(id)
    return (query == "authors" or query == "series") and (rest == nil or rest == "")
end

-- fetchSectionBucket(section) -> the cache bucket for `section`, walking
-- every catalogSection() page to (re)build it if stale/missing. Holds
-- both the flat entries list AND (see listGroups) each entry's resolved
-- first_book, keyed by entry id -- a single shared bucket/TTL so a
-- section refresh naturally drops both together.
local function fetchSectionBucket(section)
    local cached = _group_cache[section]
    if cached and (os.time() - cached.at) < GROUP_CACHE_TTL then
        return cached
    end
    local entries = {}
    local page = 1
    while page <= GROUP_FETCH_PAGE_CAP do
        local body, err = BookOrbit.catalogSection(section, { page = page })
        if not body then
            local ok_log, logger = pcall(require, "logger")
            if ok_log then
                logger.info("Bookshelf BookOrbit: listGroups section fetch failed", section, err)
            end
            break
        end
        for _, entry in ipairs(body.items or {}) do
            entries[#entries + 1] = entry
        end
        if not body.hasNext then break end
        page = page + 1
    end
    -- Cache even a failed/partial walk (rather than leaving _group_cache[section]
    -- nil) so a persistent server error doesn't retry the full page walk on
    -- every single render -- same "serve what we've got" trade-off
    -- fetchDiscover makes on failure, just without a prior-batch fallback
    -- since there's nothing to fall back to on the very first call.
    local bucket = { entries = entries, first_books = {}, at = os.time() }
    _group_cache[section] = bucket
    return bucket
end

--- invalidateGroupCache() -- drops the cached author/series lists (and
-- their resolved first-book previews) so the next listGroups call
-- re-walks the server. Cheap to call unconditionally; mirrors
-- invalidateDiscoverCache above (e.g. from a manual refresh).
function M.invalidateGroupCache()
    _group_cache = {}
end

--- listGroups(section, offset, limit) -> records, total
-- section is "authors" or "series". Each record is a folder-like tile
-- (kind = "bookorbit_group") shaped for FolderStack: .label, .count,
-- .first_book (a single hydrated + covered sample book for the tile's
-- preview image), and .source_id -- the id to drill into, in exactly the
-- single-entry form M.queryForId already understands (e.g. "authors:42").
function M.listGroups(section, offset, limit)
    if not M.isAvailable() then return {}, offset or 0 end
    local ok_net, NetworkMgr = pcall(require, "ui/network/manager")
    if ok_net and NetworkMgr and NetworkMgr.isOnline and not NetworkMgr:isOnline() then
        _offline_miss = true
        _tryAutoConnect()
        return {}, offset or 0
    end
    offset = offset or 0
    limit  = (limit and limit > 0) and limit or 24
    local bucket = fetchSectionBucket(section)
    local entries = bucket.entries
    local total = #entries
    local records = {}
    for i = offset + 1, math.min(offset + limit, total) do
        local entry = entries[i]
        local gid = M.encodeId(section, entry.id)
        -- Cache hit: this entry's sample book METADATA was already
        -- resolved earlier in this TTL window (a prior page view, or a
        -- previous visit to this chip) -- skip the catalogBooks round
        -- trip. `false` is a cached "no book" result, distinct from "not
        -- yet looked up" (nil), so a genuinely empty author isn't retried
        -- every render either.
        --
        -- Deliberately NOT caching the decoded cover_bb alongside it: this
        -- record's cover_bb gets handed to FolderStack/SpineWidget as an
        -- explicit, disposable override (see bookshelf_folder_stack.lua),
        -- which FREES it after painting -- exactly right for a one-shot
        -- render, but it means a cached bb would already be freed by the
        -- time a *second* render (navigate away and back) reused it,
        -- painting from dangling memory. That's the distorted-covers-
        -- after-navigating-back bug: SpineWidget's own comments document
        -- this exact failure mode (silent corruption, only visible after
        -- a rebuild, never on first paint) for local BIM covers reused
        -- the same way. coverBB() always re-decodes from the on-disk-
        -- cached JPEG (no network on a hit), so doing that fresh on every
        -- call is cheap and gives every render its own private bb.
        local cached_fb = bucket.first_books[entry.id]
        if cached_fb == nil then
            local sample = M.listBooks(gid, 0, 1)
            cached_fb = (sample and sample[1]) or false
            bucket.first_books[entry.id] = cached_fb
        end
        local first_book
        if cached_fb then
            first_book = {}
            for k, v in pairs(cached_fb) do first_book[k] = v end
            local bb, cw, ch = M.coverBB(first_book)
            if bb then
                first_book.cover_bb, first_book.cover_w, first_book.cover_h = bb, cw, ch
                first_book.has_cover = true
            end
        end
        records[#records + 1] = {
            kind       = "bookorbit_group",
            label      = entry.title or "Untitled",
            count      = entry.count,
            first_book = first_book,
            source_id  = gid,
        }
    end
    return records, total
end

-- ---------------------------------------------------------------------
-- Cover thumbnails (disk-cached; one download per book, ever, unless the
-- cache is cleared -- catalog thumbnails have no version token here, so a
-- server-side cover change won't invalidate a hit; acceptable for a first
-- pass, same trade-off noted for the main catalog browser's cache).
-- ---------------------------------------------------------------------

-- Debug-level tracing of the cover download chain -- silent in normal use,
-- available when a tester runs with debug logging on. Mirrors
-- bookshelf_kobo_source.lua's `diag` helper.
local function diag(...)
    local ok, logger = pcall(require, "logger")
    if ok and logger and logger.dbg then logger.dbg("[bookshelf][bookorbit]", ...) end
end

local function thumbDir()
    local DataStorage = require("datastorage")
    return DataStorage:getSettingsDir() .. "/bookshelf_bookorbit_covers"
end

-- Books whose thumbnail download failed THIS SESSION -- mirrors the official
-- plugin's per-generation thumbnail_failures set, so a broken/missing cover
-- doesn't re-issue a failing HTTP request on every single page repaint.
-- Cleared naturally on KOReader restart; nothing here persists to disk.
local _thumb_failed = {}

--- coverBB(record) -> bb, w, h  (or nil). Caller owns the returned bb.
function M.coverBB(record)
    if not record or not record.remote_id or record.has_cover == false then return nil end
    local key = tostring(record.remote_id)
    if _thumb_failed[key] then return nil end
    local util = require("util")
    if not util.makePath(thumbDir()) then return nil end
    local path = thumbDir() .. "/" .. key .. ".jpg"
    local dl_headers -- captured for diagnostics if the decode below fails
    local lfs = require("libs/libkoreader-lfs")
    if lfs.attributes(path, "mode") ~= "file" then
        local ok, err_or_headers = BookOrbit.downloadCatalogThumbnail(record.remote_id, path)
        if not ok then
            _thumb_failed[key] = true
            local ok_log, logger = pcall(require, "logger")
            if ok_log then
                logger.info("[bookshelf][bookorbit] coverBB: thumbnail download failed for book",
                    key, "->", tostring(err_or_headers))
            end
            diag("coverBB: download failed for book", key, "->", tostring(err_or_headers))
            return nil
        end
        dl_headers = err_or_headers
    end
    local ok_r, RenderImage = pcall(require, "ui/renderimage")
    if not ok_r or not RenderImage or not RenderImage.renderImageFile then return nil end
    local ok_bb, bb = pcall(function() return RenderImage:renderImageFile(path, false) end)
    -- BUG (root cause of every "did not decode" failure below): a successful
    -- decode returns a BlitBuffer, which KOReader builds via ffi.metatype --
    -- its Lua type() is "cdata", NEVER "table". The old `type(bb) ~= "table"`
    -- check therefore rejected every single valid decode, unconditionally,
    -- which is exactly what the content-type=image/jpeg + valid-JPEG-magic
    -- diagnostics above proved was happening: the bytes were fine the whole
    -- time. RenderImage:renderImageFile returns nil (falsy) on a genuine
    -- decode failure and a non-nil BlitBuffer on success, so `not bb` is the
    -- correct check -- same pattern used elsewhere in this codebase (e.g.
    -- bookshelf_image_source.lua just returns/uses the value directly).
    if not ok_bb or not bb then
        -- Downloaded fine but didn't decode as an image -- almost always
        -- means the bytes on disk aren't actually a JPEG (an HTML error
        -- page saved by a lenient sink, or a gzipped body a proxy sent
        -- without Accept-Encoding: identity being honoured). Log what we
        -- actually got -- Content-Type/Content-Encoding from the response
        -- (when this was a fresh download, i.e. dl_headers is set -- a
        -- cache-hit re-decode of a pre-existing bad file won't have these),
        -- the on-disk size, and the first bytes' magic number -- so the
        -- real cause (wrong content-type, still-gzipped body starting with
        -- 0x1F 0x8B, an HTML error page starting with "<", a 0-byte/
        -- truncated file, etc.) shows up in the log instead of a bare
        -- "did not decode". Then remove the bad file so the next attempt
        -- re-downloads instead of forever trying to decode the same broken
        -- bytes, and don't sit in _thumb_failed permanently -- a
        -- proxy/server fix should recover without a KOReader restart.
        local size, magic_hex, magic_ascii
        local fh = io.open(path, "rb")
        if fh then
            size = fh:seek("end")
            fh:seek("set", 0)
            local head = fh:read(16) or ""
            fh:close()
            magic_hex = head:gsub(".", function(c) return string.format("%02X ", c:byte()) end)
            magic_ascii = head:gsub("[^%g%s]", ".")
        end
        os.remove(path)
        local ct = dl_headers and (dl_headers["content-type"] or dl_headers["Content-Type"])
        local ce = dl_headers and (dl_headers["content-encoding"] or dl_headers["Content-Encoding"])
        local ok_log2, logger2 = pcall(require, "logger")
        if ok_log2 then
            logger2.info("[bookshelf][bookorbit] coverBB: downloaded file for book", key,
                "did not decode as an image (ok=", tostring(ok_bb), ")",
                "content-type=", tostring(ct), "content-encoding=", tostring(ce),
                "size=", tostring(size), "bytes",
                "magic=", tostring(magic_hex), "(", tostring(magic_ascii), ")",
                "-- removed cached file")
        end
        diag("coverBB: RenderImage failed to decode downloaded file for book", key,
             "(ok=", tostring(ok_bb), ") content-type=", tostring(ct),
             "size=", tostring(size), "magic=", tostring(magic_hex),
             "-- removed cached file")
        return nil
    end
    local w = bb.getWidth and bb:getWidth() or nil
    local h = bb.getHeight and bb:getHeight() or nil
    return bb, w, h
end

-- ---------------------------------------------------------------------
-- Full-record rebuild (hero / preview)
--
-- The grid's listBooks() records come from catalogBooks(), which never
-- returns a description (only the per-book detail endpoint does) -- so a
-- plain toRecord() has no synopsis for the hero to show. Separately, the
-- cover_bb the grid attached to a record is a ONE-SHOT bb: the grid tile
-- already painted (and freed) it by the time a tap promotes that same
-- record into the hero, so reusing it there paints nothing. Repo.buildBook
-- can't fix either of these for a "bookorbit://" filepath (there's no real
-- file/DocSettings for it), so callers that promote a tapped/selected
-- BookOrbit book into the hero should call this instead of relying on the
-- generic Repo.buildBook -- see Repo.buildPreviewBook.
-- ---------------------------------------------------------------------

--- rebuildRecord(fallback) -> record or nil
-- fallback is the existing list record for this book (must carry
-- remote_id). Fetches the book's detail (for description) and a fresh
-- cover thumbnail; every other field is carried over from fallback
-- unchanged. Returns nil if the detail request fails (offline, 401,
-- server error, etc.) so the caller falls back to reusing fallback as-is
-- -- same nil-means-"use the old record" contract Repo.buildBookMeta uses.
function M.rebuildRecord(fallback)
    if not fallback or not fallback.remote_id then return nil end
    if not M.isAvailable() then return nil end
    local detail, err = BookOrbit.catalogBook(fallback.remote_id)
    if not detail then
        local ok_log, logger = pcall(require, "logger")
        if ok_log then logger.info("Bookshelf BookOrbit: rebuildRecord failed", err) end
        return nil
    end
    local record = {}
    for k, v in pairs(fallback) do
        -- Never carry the old cover_bb forward -- it may already be freed
        -- (see above); coverBB below gets a fresh one.
        if k ~= "cover_bb" then record[k] = v end
    end
    record.description = detail.description
    local bb, cw, ch = M.coverBB(record)
    if bb then
        record.cover_bb, record.cover_w, record.cover_h = bb, cw, ch
        record.has_cover = true
    end
    return record
end

-- ---------------------------------------------------------------------
-- Opening: download the book's primary file on first open, then remember
-- where it landed so a later tap just opens the local copy.
-- ---------------------------------------------------------------------

local LuaSettings = require("luasettings")
local DataStorage = require("datastorage")
local _dl_settings

local function dlSettings()
    if not _dl_settings then
        _dl_settings = LuaSettings:open(DataStorage:getSettingsDir() .. "/bookshelf_bookorbit_downloads.lua")
    end
    return _dl_settings
end

--- True if `filepath` is one of this module's synthetic placeholders.
function M.isBookOrbitPath(filepath)
    return type(filepath) == "string" and filepath:sub(1, 12) == "bookorbit://"
end

--- resolveOpenPath(record, callback, hooks) -- callback(path) on success,
-- callback(nil, err) on failure. Non-blocking from the caller's point of
-- view: does its own network calls, then invokes callback once it knows
-- the answer. If a previous download for this book is still on disk, the
-- callback fires with that path immediately and no network is touched.
--
-- `hooks` (optional) lets the caller give progress feedback without having
-- to guess up front whether this call will need the network at all:
--   * hooks.on_download_start() -- fired right before bytes are actually
--     requested from the server, i.e. only when the dedupe check against
--     the expected on-disk path misses. Not fired for the instant
--     settings-cache hit, nor when that dedupe check finds an existing file
--     to open instead -- the catalog-detail lookup itself stays silent.
function M.resolveOpenPath(record, callback, hooks)
    hooks = hooks or {}
    if not record or not record.remote_id then
        callback(nil, "bad_record")
        return
    end
    local lfs = require("libs/libkoreader-lfs")
    local s = dlSettings()
    local key = tostring(record.remote_id)
    local cached = s:readSetting(key)
    if cached and lfs.attributes(cached, "mode") == "file" then
        -- Already downloaded -- opening it needs no network at all, so this
        -- path stays fully offline-safe (no Wi-Fi auto-connect below). No
        -- hook fires: the caller should treat this exactly like opening any
        -- other on-device book, with no "talking to BookOrbit" message.
        callback(cached)
        return
    end
    -- Everything past this point (fetch detail, download the file) is a
    -- network call, but the catalog-detail lookup alone is quick and may
    -- still end in a dedupe hit, so no message is shown yet -- only
    -- hooks.on_download_start (below) warrants telling the user anything.
    -- Auto-connect first -- turns Wi-Fi on / reconnects a saved network,
    -- prompting only if none is saved -- instead of the old behaviour of
    -- failing immediately with "offline" while the radio is simply off.
    local ok_net, NetworkMgr = pcall(require, "ui/network/manager")
    local runWhenOnline = (ok_net and NetworkMgr and NetworkMgr.runWhenOnline)
        and function(fn) NetworkMgr:runWhenOnline(fn) end
        or function(fn) fn() end  -- NetworkMgr unavailable -- fall back to trying directly
    runWhenOnline(function()
        local detail, err = BookOrbit.catalogBook(record.remote_id)
        if not detail then
            callback(nil, err)
            return
        end
        local files = detail.files or {}
        if #files == 0 then
            callback(nil, "no_file")
            return
        end
        local file = files[1]
        for _, f in ipairs(files) do
            if f.role == "primary" then file = f; break end
        end
        local dir  = BookOrbit.downloadDestDir(BookOrbit.downloadDir(), detail)
        local base = BookOrbit.buildFilenameBase(detail, record.title)
        local ext  = file.format or "epub"
        local canonical_path = dir .. "/" .. base .. "." .. ext
        -- If the exact file we'd otherwise download to already exists --
        -- placed there by other means, left over from a previous install,
        -- downloaded outside this plugin, etc. -- treat it as this book
        -- and open it directly instead of downloading a second copy and
        -- suffixing it "(1)". This is a filename match, not a content
        -- verification: the server doesn't expose a comparable hash for
        -- the remote file before downloading it (BookOrbit.getBookHash is
        -- a LOCAL partial-MD5 of bytes already on disk, used for progress
        -- sync -- there's nothing to compare it against here without
        -- downloading first, which defeats the point). In practice a
        -- false match needs two different books landing at the exact same
        -- sanitized title AND the exact same Author[/Series] subfolder,
        -- which is unlikely but not impossible -- if that ever bites,
        -- deleting the wrongly-matched local file forces a real
        -- (uniquely-suffixed) download next time.
        if lfs.attributes(canonical_path, "mode") == "file" then
            local ok_log, logger = pcall(require, "logger")
            if ok_log then
                logger.info("BookOrbit: resolveOpenPath found an existing file at the expected " ..
                    "download path, opening it instead of re-downloading:", canonical_path)
            end
            s:saveSetting(key, canonical_path)
            s:flush()
            callback(canonical_path)
            return
        end
        local path = BookOrbit.uniqueDownloadPath(dir, base, ext)
        if hooks.on_download_start then hooks.on_download_start() end
        local ok, derr = BookOrbit.downloadCatalogFile(file.id, path)
        if not ok then
            callback(nil, derr)
            return
        end
        s:saveSetting(key, path)
        s:flush()
        callback(path)
    end)
end

return M
