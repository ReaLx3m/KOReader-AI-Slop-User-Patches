--[[
bookshelf_bookorbit_source.lua — bridges a BookOrbit server's catalog into
Bookshelf's chip/source system, the same role bookshelf_kobo_source.lua
plays for the Kobo virtual library: it is the ONLY point of contact between
Repo.getBySource / the chip editor and lib/bookshelf_bookorbit.lua's HTTP
client, so callers never touch BookOrbit directly.

Where this differs from the Kobo bridge: Kobo's virtual library is local and
synchronous (decrypt-on-demand); BookOrbit's catalog is a REMOTE, PAGED list,
and its covers are separate network downloads. So instead of one
`listBooks()` that returns everything, this module fetches one page at a
time (`listBooks(id, offset, limit)`), and `coverBB` downloads (and disk-
caches) a thumbnail synchronously the first time a given book is asked for —
the same "blocking network call from a UI callback" style already used by
bookshelf_bookorbit_catalog.lua and bookshelf_cover_fetch.lua elsewhere in
this plugin, so a chip switch or page turn costs one request per book
whose cover isn't cached yet, then nothing on repaint.

Chip "source.id" encoding: "<query>:<rest>", e.g. "all:", "recent:",
"continue:", "libraries:42", "collections:7", "smart-scopes:3",
"authors:Iain M. Banks", "series:Culture". Built by the chip editor's
BookOrbit picker (encodeId below); decoded here into a catalogBooks() query.
This mirrors bookshelf_bookorbit_catalog.lua's paramsForEntry, independently,
since that file is a separate, already-shipped browsing UI this integration
does not touch.
]]

local BookOrbit = require("lib/bookshelf_bookorbit")
local _         = require("lib/bookshelf_i18n").gettext

local M = {}

function M.isAvailable()
    return BookOrbit.isConfigured()
end

-- ---------------------------------------------------------------------
-- Source id encode/decode
-- ---------------------------------------------------------------------

-- Root-level "special" sections that page straight into catalogBooks
-- without a section/entry drill-down.
local ROOT_SPECIAL = {
    ["all"]      = true,
    ["recent"]   = true,
    ["continue"] = true,
}

function M.encodeId(query, rest)
    return tostring(query or "all") .. ":" .. tostring(rest or "")
end

function M.decodeId(id)
    local query, rest = (id or ""):match("^([^:]*):(.*)$")
    if not query or query == "" then return "all", "" end
    return query, rest
end

-- Builds the catalogBooks() query table for one chip's source.id.
function M.queryForId(id)
    local query, rest = M.decodeId(id)
    if query == "recent" then
        return { sort = "recently_added" }
    elseif query == "continue" then
        return { sort = "recently_read", readStatus = "reading" }
    elseif query == "libraries" then
        return { libraryId = rest, sort = "title" }
    elseif query == "collections" then
        return { collectionId = rest, sort = "title" }
    elseif query == "smart-scopes" then
        return { smartScopeId = rest, sort = "title" }
    elseif query == "authors" then
        return { author = rest, sort = "title" }
    elseif query == "series" then
        return { series = rest, sort = "series" }
    end
    return { sort = "title" } -- "all" and anything unrecognised
end

-- Friendly default label for a chip whose source.id is `id` -- used by the
-- chip editor's "New chip" auto-rename QoL. Doesn't hit the network.
function M.labelForId(id, fallback_title)
    if fallback_title and fallback_title ~= "" then return fallback_title end
    local query = M.decodeId(id)
    if query == "recent" then return "Recently added"
    elseif query == "continue" then return "Continue reading"
    elseif query == "all" then return "All books"
    end
    return "BookOrbit"
end

-- ---------------------------------------------------------------------
-- Picker data (used only by the chip editor, never by getBySource)
-- ---------------------------------------------------------------------

--- Root choices for the "BookOrbit section" picker: the special shortcuts
-- always offered, plus whatever drill-down sections the server advertises.
-- Returns { { value = id, label = str, needs_drill = bool, section = str|nil } }, err
function M.fetchRootChoices()
    local body, err = BookOrbit.catalogRoot()
    if not body then return nil, err end
    local choices = {
        { value = { id = M.encodeId("all"),      label = "All books" },      label = "All books" },
        { value = { id = M.encodeId("recent"),   label = "Recently added" }, label = "Recently added" },
        { value = { id = M.encodeId("continue"), label = "Continue reading" }, label = "Continue reading" },
    }
    local seen_special = { ["all-books"] = true, ["recent"] = true, ["continue-reading"] = true, ["search"] = true }
    for _, section in ipairs(body.sections or {}) do
        if not seen_special[section.section] then
            -- value is a marker table, never nil -- nil is reserved for
            -- "the user cancelled" in the chip editor's picker callback.
            choices[#choices + 1] = {
                value = { drill = section.section, title = section.title },
                label = (section.title or section.section) .. "  \xE2\x96\xB8", -- ▸
            }
        end
    end
    return choices
end

--- Entries within one drill-down section (libraries/collections/
-- smart-scopes/authors/series). `title` is the section's display title
-- (from fetchRootChoices), used to label the prepended "whole section"
-- choice below -- falls back to a generic "All items" if omitted.
-- Returns { { value = id, label = str } }, err
function M.fetchSectionChoices(section, title)
    local body, err = BookOrbit.catalogSection(section, { page = 1 })
    if not body then return nil, err end
    local choices = {}
    -- A leaf for the section itself, not one entry within it -- e.g.
    -- picking "Authors" without drilling into a specific author. Maps to
    -- an id with an empty `rest` ("authors:"), which queryForId turns into
    -- a query with no author/library/collection/etc. filter -- effectively
    -- every book, same as the "All books" shortcut, but reachable from
    -- (and named after) this section for chip-naming purposes.
    local all_label = title and ("All " .. title) or _("All items")
    choices[#choices + 1] = {
        value = { id = M.encodeId(section, ""), label = all_label },
        label = all_label,
    }
    for _, entry in ipairs(body.items or {}) do
        local label = entry.title or "Untitled"
        if entry.count then label = label .. "  (" .. tostring(entry.count) .. ")" end
        choices[#choices + 1] = {
            value = { id = M.encodeId(section, entry.id), label = entry.title or "Untitled" },
            label = label,
        }
    end
    return choices, nil, body.hasNext
end

-- ---------------------------------------------------------------------
-- Book records (used by Repo.getBySource)
-- ---------------------------------------------------------------------

local function firstAuthor(b)
    return b.authors and b.authors[1] or nil
end

local function statusFor(b, pct)
    local s = b.readStatus
    if s == "unread" or s == "reading" or s == "on_hold" or s == "finished" then return s end
    if pct >= 1 then return "finished" end
    if pct > 0 then return "reading" end
    return "unread"
end

function M.toRecord(b)
    local pct_raw = tonumber(b.progressPercentage) or 0
    local pct = pct_raw > 1 and (pct_raw / 100) or pct_raw
    local author = firstAuthor(b)
    return {
        -- Not a real path: distinguishes these records everywhere the grid
        -- keys by filepath (selection, cache, cover frame refresh) without
        -- colliding with any real file. Never handed to lfs/io directly --
        -- _openBook resolves a real path before opening (see is_bookorbit).
        filepath       = "bookorbit://" .. tostring(b.id),
        filename       = b.title or "Untitled",
        title          = b.title or "Untitled",
        display_title  = b.title or "Untitled",
        author         = author,
        authors        = b.authors,
        series_name    = b.seriesName,
        series_num     = b.seriesIndex ~= nil and tostring(b.seriesIndex) or nil,
        book_pct       = pct,
        status         = statusFor(b, pct),
        read_status    = statusFor(b, pct),
        rating         = nil,
        added_time     = 0,
        last_read_time = 0,
        attr           = { mode = "file", size = 0, modification = 0 },
        format         = b.formats and b.formats[1],
        remote_id      = b.id,
        has_cover      = b.hasCover ~= false,
        is_bookorbit   = true,
    }
end

--- listBooks(id, offset, limit) -> records, total
-- Maps the grid's offset/limit window onto one catalogBooks() page (limit
-- is the view size, so this is exactly one request per page turn). `total`
-- is not reported by the API (only hasNext), so it's synthesised just far
-- enough past the current window to keep forward paging enabled -- the
-- same trick is safe here as it only ever affects cursor clamping.
function M.listBooks(id, offset, limit)
    if not M.isAvailable() then return {}, offset or 0 end
    local ok_net, NetworkMgr = pcall(require, "ui/network/manager")
    if ok_net and NetworkMgr and NetworkMgr.isOnline and not NetworkMgr:isOnline() then
        return {}, offset or 0
    end
    offset = offset or 0
    limit  = (limit and limit > 0) and limit or 24
    local page = math.floor(offset / limit) + 1
    local query = M.queryForId(id)
    query.page = page
    query.size = limit

    local body, err = BookOrbit.catalogBooks(query)
    if not body then
        local ok_log, logger = pcall(require, "logger")
        if ok_log then logger.info("Bookshelf BookOrbit: listBooks failed", err) end
        return {}, offset
    end
    local records = {}
    for _, b in ipairs(body.items or {}) do
        records[#records + 1] = M.toRecord(b)
    end
    local total = offset + #records + (body.hasNext and limit or 0)
    return records, total
end

-- ---------------------------------------------------------------------
-- Cover thumbnails (disk-cached; one download per book, ever, unless the
-- cache is cleared -- catalog thumbnails have no version token here, so a
-- server-side cover change won't invalidate a hit; acceptable for a first
-- pass, same trade-off noted for the main catalog browser's cache).
-- ---------------------------------------------------------------------

-- Debug-level tracing of the cover download chain -- silent in normal use,
-- available when a tester runs with debug logging on. Mirrors
-- bookshelf_kobo_source.lua's `diag` helper.
local function diag(...)
    local ok, logger = pcall(require, "logger")
    if ok and logger and logger.dbg then logger.dbg("[bookshelf][bookorbit]", ...) end
end

local function thumbDir()
    local DataStorage = require("datastorage")
    return DataStorage:getSettingsDir() .. "/bookshelf_bookorbit_covers"
end

-- Books whose thumbnail download failed THIS SESSION -- mirrors the official
-- plugin's per-generation thumbnail_failures set, so a broken/missing cover
-- doesn't re-issue a failing HTTP request on every single page repaint.
-- Cleared naturally on KOReader restart; nothing here persists to disk.
local _thumb_failed = {}

--- coverBB(record) -> bb, w, h  (or nil). Caller owns the returned bb.
function M.coverBB(record)
    if not record or not record.remote_id or record.has_cover == false then return nil end
    local key = tostring(record.remote_id)
    if _thumb_failed[key] then return nil end
    local util = require("util")
    if not util.makePath(thumbDir()) then return nil end
    local path = thumbDir() .. "/" .. key .. ".jpg"
    local dl_headers -- captured for diagnostics if the decode below fails
    local lfs = require("libs/libkoreader-lfs")
    if lfs.attributes(path, "mode") ~= "file" then
        local ok, err_or_headers = BookOrbit.downloadCatalogThumbnail(record.remote_id, path)
        if not ok then
            _thumb_failed[key] = true
            local ok_log, logger = pcall(require, "logger")
            if ok_log then
                logger.info("[bookshelf][bookorbit] coverBB: thumbnail download failed for book",
                    key, "->", tostring(err_or_headers))
            end
            diag("coverBB: download failed for book", key, "->", tostring(err_or_headers))
            return nil
        end
        dl_headers = err_or_headers
    end
    local ok_r, RenderImage = pcall(require, "ui/renderimage")
    if not ok_r or not RenderImage or not RenderImage.renderImageFile then return nil end
    local ok_bb, bb = pcall(function() return RenderImage:renderImageFile(path, false) end)
    -- BUG (root cause of every "did not decode" failure below): a successful
    -- decode returns a BlitBuffer, which KOReader builds via ffi.metatype --
    -- its Lua type() is "cdata", NEVER "table". The old `type(bb) ~= "table"`
    -- check therefore rejected every single valid decode, unconditionally,
    -- which is exactly what the content-type=image/jpeg + valid-JPEG-magic
    -- diagnostics above proved was happening: the bytes were fine the whole
    -- time. RenderImage:renderImageFile returns nil (falsy) on a genuine
    -- decode failure and a non-nil BlitBuffer on success, so `not bb` is the
    -- correct check -- same pattern used elsewhere in this codebase (e.g.
    -- bookshelf_image_source.lua just returns/uses the value directly).
    if not ok_bb or not bb then
        -- Downloaded fine but didn't decode as an image -- almost always
        -- means the bytes on disk aren't actually a JPEG (an HTML error
        -- page saved by a lenient sink, or a gzipped body a proxy sent
        -- without Accept-Encoding: identity being honoured). Log what we
        -- actually got -- Content-Type/Content-Encoding from the response
        -- (when this was a fresh download, i.e. dl_headers is set -- a
        -- cache-hit re-decode of a pre-existing bad file won't have these),
        -- the on-disk size, and the first bytes' magic number -- so the
        -- real cause (wrong content-type, still-gzipped body starting with
        -- 0x1F 0x8B, an HTML error page starting with "<", a 0-byte/
        -- truncated file, etc.) shows up in the log instead of a bare
        -- "did not decode". Then remove the bad file so the next attempt
        -- re-downloads instead of forever trying to decode the same broken
        -- bytes, and don't sit in _thumb_failed permanently -- a
        -- proxy/server fix should recover without a KOReader restart.
        local size, magic_hex, magic_ascii
        local fh = io.open(path, "rb")
        if fh then
            size = fh:seek("end")
            fh:seek("set", 0)
            local head = fh:read(16) or ""
            fh:close()
            magic_hex = head:gsub(".", function(c) return string.format("%02X ", c:byte()) end)
            magic_ascii = head:gsub("[^%g%s]", ".")
        end
        os.remove(path)
        local ct = dl_headers and (dl_headers["content-type"] or dl_headers["Content-Type"])
        local ce = dl_headers and (dl_headers["content-encoding"] or dl_headers["Content-Encoding"])
        local ok_log2, logger2 = pcall(require, "logger")
        if ok_log2 then
            logger2.info("[bookshelf][bookorbit] coverBB: downloaded file for book", key,
                "did not decode as an image (ok=", tostring(ok_bb), ")",
                "content-type=", tostring(ct), "content-encoding=", tostring(ce),
                "size=", tostring(size), "bytes",
                "magic=", tostring(magic_hex), "(", tostring(magic_ascii), ")",
                "-- removed cached file")
        end
        diag("coverBB: RenderImage failed to decode downloaded file for book", key,
             "(ok=", tostring(ok_bb), ") content-type=", tostring(ct),
             "size=", tostring(size), "magic=", tostring(magic_hex),
             "-- removed cached file")
        return nil
    end
    local w = bb.getWidth and bb:getWidth() or nil
    local h = bb.getHeight and bb:getHeight() or nil
    return bb, w, h
end

-- ---------------------------------------------------------------------
-- Full-record rebuild (hero / preview)
--
-- The grid's listBooks() records come from catalogBooks(), which never
-- returns a description (only the per-book detail endpoint does) -- so a
-- plain toRecord() has no synopsis for the hero to show. Separately, the
-- cover_bb the grid attached to a record is a ONE-SHOT bb: the grid tile
-- already painted (and freed) it by the time a tap promotes that same
-- record into the hero, so reusing it there paints nothing. Repo.buildBook
-- can't fix either of these for a "bookorbit://" filepath (there's no real
-- file/DocSettings for it), so callers that promote a tapped/selected
-- BookOrbit book into the hero should call this instead of relying on the
-- generic Repo.buildBook -- see Repo.buildPreviewBook.
-- ---------------------------------------------------------------------

--- rebuildRecord(fallback) -> record or nil
-- fallback is the existing list record for this book (must carry
-- remote_id). Fetches the book's detail (for description) and a fresh
-- cover thumbnail; every other field is carried over from fallback
-- unchanged. Returns nil if the detail request fails (offline, 401,
-- server error, etc.) so the caller falls back to reusing fallback as-is
-- -- same nil-means-"use the old record" contract Repo.buildBookMeta uses.
function M.rebuildRecord(fallback)
    if not fallback or not fallback.remote_id then return nil end
    if not M.isAvailable() then return nil end
    local detail, err = BookOrbit.catalogBook(fallback.remote_id)
    if not detail then
        local ok_log, logger = pcall(require, "logger")
        if ok_log then logger.info("Bookshelf BookOrbit: rebuildRecord failed", err) end
        return nil
    end
    local record = {}
    for k, v in pairs(fallback) do
        -- Never carry the old cover_bb forward -- it may already be freed
        -- (see above); coverBB below gets a fresh one.
        if k ~= "cover_bb" then record[k] = v end
    end
    record.description = detail.description
    local bb, cw, ch = M.coverBB(record)
    if bb then
        record.cover_bb, record.cover_w, record.cover_h = bb, cw, ch
        record.has_cover = true
    end
    return record
end

-- ---------------------------------------------------------------------
-- Opening: download the book's primary file on first open, then remember
-- where it landed so a later tap just opens the local copy.
-- ---------------------------------------------------------------------

local LuaSettings = require("luasettings")
local DataStorage = require("datastorage")
local _dl_settings

local function dlSettings()
    if not _dl_settings then
        _dl_settings = LuaSettings:open(DataStorage:getSettingsDir() .. "/bookshelf_bookorbit_downloads.lua")
    end
    return _dl_settings
end

--- True if `filepath` is one of this module's synthetic placeholders.
function M.isBookOrbitPath(filepath)
    return type(filepath) == "string" and filepath:sub(1, 12) == "bookorbit://"
end

--- resolveOpenPath(record, callback) -- callback(path) on success,
-- callback(nil, err) on failure. Non-blocking from the caller's point of
-- view: does its own network calls, then invokes callback once it knows
-- the answer. If a previous download for this book is still on disk, the
-- callback fires with that path immediately and no network is touched.
function M.resolveOpenPath(record, callback)
    if not record or not record.remote_id then
        callback(nil, "bad_record")
        return
    end
    local lfs = require("libs/libkoreader-lfs")
    local s = dlSettings()
    local key = tostring(record.remote_id)
    local cached = s:readSetting(key)
    if cached and lfs.attributes(cached, "mode") == "file" then
        callback(cached)
        return
    end
    local detail, err = BookOrbit.catalogBook(record.remote_id)
    if not detail then
        callback(nil, err)
        return
    end
    local files = detail.files or {}
    if #files == 0 then
        callback(nil, "no_file")
        return
    end
    local file = files[1]
    for _, f in ipairs(files) do
        if f.role == "primary" then file = f; break end
    end
    local dir  = BookOrbit.downloadDestDir(BookOrbit.downloadDir(), detail)
    local base = BookOrbit.sanitizeFilename(detail.title or record.title or "book")
    local path = BookOrbit.uniqueDownloadPath(dir, base, file.format or "epub")
    local ok, derr = BookOrbit.downloadCatalogFile(file.id, path)
    if not ok then
        callback(nil, derr)
        return
    end
    s:saveSetting(key, path)
    s:flush()
    callback(path)
end

return M
