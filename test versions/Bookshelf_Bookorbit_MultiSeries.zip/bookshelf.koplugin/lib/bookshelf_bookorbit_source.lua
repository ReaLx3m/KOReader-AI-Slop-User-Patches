--[[
bookshelf_bookorbit_source.lua — bridges a BookOrbit server's catalog into
Bookshelf's chip/source system, the same role bookshelf_kobo_source.lua
plays for the Kobo virtual library: it is the ONLY point of contact between
Repo.getBySource / the chip editor and lib/bookshelf_bookorbit.lua's HTTP
client, so callers never touch BookOrbit directly.

Where this differs from the Kobo bridge: Kobo's virtual library is local and
synchronous (decrypt-on-demand); BookOrbit's catalog is a REMOTE, PAGED list,
and its covers are separate network downloads. So instead of one
`listBooks()` that returns everything, this module fetches one page at a
time (`listBooks(id, offset, limit)`), and `coverBB` downloads (and disk-
caches) a thumbnail synchronously the first time a given book is asked for —
the same "blocking network call from a UI callback" style already used by
bookshelf_bookorbit_catalog.lua and bookshelf_cover_fetch.lua elsewhere in
this plugin, so a chip switch or page turn costs one request per book
whose cover isn't cached yet, then nothing on repaint.

Chip "source.id" encoding: "<query>:<rest>", e.g. "all:", "recent:",
"continue:", "libraries:42", "collections:7", "smart-scopes:3",
"authors:Iain M. Banks", "series:Culture". Built by the chip editor's
BookOrbit picker (encodeId below); decoded here into a catalogBooks() query.
This mirrors bookshelf_bookorbit_catalog.lua's paramsForEntry, independently,
since that file is a separate, already-shipped browsing UI this integration
does not touch.
]]

local BookOrbit = require("lib/bookshelf_bookorbit")
local Cache     = require("lib/bookshelf_bookorbit_cache")
local GroupCoverCache = require("lib/bookshelf_group_cover_cache")
local BookshelfSettings = require("lib/bookshelf_settings_store")
local _         = require("lib/bookshelf_i18n").gettext
-- Only used to derive a "given name" sort key for the Authors group-root's
-- folder tiles (see listGroups below) -- pcall'd the same defensive way
-- bookshelf_sort_engine.lua requires it, so a missing/renamed module just
-- degrades that one sort back to server order instead of erroring the
-- whole source.
local ok_author_name, AuthorName = pcall(require, "lib/bookshelf_author_name")

local M = {}

function M.isAvailable()
    return BookOrbit.isConfigured()
end

-- ---------------------------------------------------------------------
-- Source id encode/decode
-- ---------------------------------------------------------------------

-- Root-level "special" sections that page straight into catalogBooks
-- without a section/entry drill-down.
local ROOT_SPECIAL = {
    ["all"]           = true,
    ["recent"]        = true,
    ["continue"]      = true,
    ["want_to_read"]  = true,
    ["discover"]      = true,
}

function M.encodeId(query, rest)
    return tostring(query or "all") .. ":" .. tostring(rest or "")
end

function M.decodeId(id)
    local query, rest = (id or ""):match("^([^:]*):(.*)$")
    if not query or query == "" then return "all", "" end
    return query, rest
end

-- Sections that can be browsed as live folder tiles in the shelf grid
-- (see isGroupRoot/groupSection/listGroups further below), keyed by the
-- id query token their "Browse as folders" picker row uses, valued by
-- the real catalogSection()/catalogBooks() section name to walk.
--
-- Authors and Series aren't in here: their existing "All <title>" row
-- (the plain M.encodeId(section, "") id, same as every other section
-- gets below) has meant "browse as folders" ever since isGroupRoot was
-- introduced, and that's unchanged -- adding them here too would just
-- give them a second, redundant picker row.
--
-- Libraries/Collections/SmartScopes get a SEPARATE id+row instead of
-- reusing their own "All <title>" id, specifically so any chip already
-- pinned to that id keeps its current flat, ungrouped book list --
-- widening isGroupRoot to match their bare id too would have silently
-- turned an existing "All Libraries" chip into a folder view underneath
-- whoever already had it pinned.
local GROUPED_SECTION_QUERY = {
    ["libraries-groups"]    = "libraries",
    ["collections-groups"]  = "collections",
    ["smart-scopes-groups"] = "smart-scopes",
}

-- ---------------------------------------------------------------------
-- Per-section folder-tile toggles ("Show folder label on nested
-- sources" / "Show covers on nested sections")
-- ---------------------------------------------------------------------
-- Both settings used to be one blanket on/off switch each
-- (bookorbit_group_labels / bookorbit_group_covers) covering every
-- listGroups() section. They're now submenus with one toggle per
-- section -- Authors, Series, Libraries, Collections, Smart Scopes --
-- so e.g. Series tiles can keep their cover/name while Smart Scope
-- tiles hide theirs. GROUP_TILE_SECTIONS is the canonical list both
-- settings submenus (bookshelf_settings.lua) and FolderStack
-- (bookshelf_folder_stack.lua) build off of; the section tokens are
-- exactly listGroups()'s own `section` argument, so a record's
-- source_id round-trips straight back to the right key via M.decodeId.
local GROUP_TILE_SECTIONS = { "authors", "series", "libraries", "collections", "smart-scopes" }

--- groupTileSections() -> GROUP_TILE_SECTIONS, for the settings submenus
-- to iterate without duplicating the list.
function M.groupTileSections()
    return GROUP_TILE_SECTIONS
end

--- groupLabelSettingKey(section) -> the BookshelfSettings key for one
-- section's toggle, e.g. "libraries" -> "bookorbit_group_labels_libraries".
function M.groupLabelSettingKey(section)
    return "bookorbit_group_labels_" .. tostring(section):gsub("%-", "_")
end

--- groupLabelsEnabled(section) -> whether folder-tile labels should show
-- for this section. Falls back to the old single "bookorbit_group_labels"
-- toggle when the per-section key hasn't been set yet, so upgrading users
-- who'd already turned the old setting off don't silently get every
-- section's labels back on the next render.
function M.groupLabelsEnabled(section)
    local v = BookshelfSettings.read(M.groupLabelSettingKey(section))
    if v == nil then
        v = BookshelfSettings.read("bookorbit_group_labels")
    end
    return v ~= false
end

--- groupCoverSettingKey(section) -> the BookshelfSettings key for one
-- section's cover toggle, e.g. "libraries" -> "bookorbit_group_covers_libraries".
function M.groupCoverSettingKey(section)
    return "bookorbit_group_covers_" .. tostring(section):gsub("%-", "_")
end

--- groupCoversEnabled(section) -> whether folder tiles in this section
-- should resolve/show a sample-book cover peek. Falls back to the old
-- single "bookorbit_group_covers" toggle when the per-section key hasn't
-- been set yet, same upgrade-safety reasoning as groupLabelsEnabled above.
function M.groupCoversEnabled(section)
    local v = BookshelfSettings.read(M.groupCoverSettingKey(section))
    if v == nil then
        v = BookshelfSettings.read("bookorbit_group_covers")
    end
    return v ~= false
end

-- Builds the catalogBooks() query table for one chip's source.id.
function M.queryForId(id)
    local query, rest = M.decodeId(id)
    if query == "recent" then
        return { sort = "recently_added" }
    elseif query == "continue" then
        return { sort = "recently_read", readStatus = "reading" }
    elseif query == "want_to_read" then
        -- NOT actually used by listBooks any more -- readStatus does not
        -- accept "want_to_read" server-side (see fetchWantToRead's doc
        -- comment near the bottom of this file), so listBooks special-
        -- cases this id and never reaches M.queryForId for it. Kept
        -- returning something sane anyway since labelForId/fetchRootChoices
        -- style callers only care about the id round-tripping, not this
        -- table.
        return { sort = "recently_added" }
    elseif query == "libraries" then
        return { libraryId = rest, sort = "title" }
    elseif query == "collections" then
        return { collectionId = rest, sort = "title" }
    elseif query == "smart-scopes" then
        return { smartScopeId = rest, sort = "title" }
    elseif query == "authors" then
        -- "series" (not "title") so a drilled-in single-author chip --
        -- whether reached via the Authors group-root's folder tiles
        -- (BookshelfWidget:_expandBookOrbitGroup) or a chip pinned
        -- directly to one author -- lists that author's books in series
        -- order (series name, then series index within it; standalones
        -- fall back to the server's natural tie-break) instead of flat
        -- alphabetical-by-title. Same server sort id the "series:" query
        -- below already uses for a single series' books.
        --
        -- (This was briefly swapped to "title" on a wrong hunch that
        -- author+sort=series was silently emptying results server-side.
        -- The real cause was a stale, disk-persistent page cache serving
        -- cached-empty answers without ever reaching the network -- see
        -- invalidateGroupCache's doc comment below for the actual fix.
        -- sort was never the problem.)
        return { author = rest, sort = "series" }
    elseif query == "series" then
        -- `rest` is normally a series NAME (see this function's header
        -- comment example, "series:Culture") and goes to the server as a
        -- name filter. But listGroups (below) now prefers entry.seriesId
        -- -- a genuinely numeric id -- when a server's "series" section
        -- entries carry one (see that function's own comment for why:
        -- some servers return an opaque .id like "series:2139" instead of
        -- a bare name). When `rest` is numeric, it's one of those raw
        -- seriesId values, not a name, and must go to the server as
        -- seriesId=, not series= -- a name filter will never match a
        -- literal number.
        local as_number = tonumber(rest)
        if as_number then
            return { seriesId = as_number, sort = "series" }
        end
        return { series = rest, sort = "series" }
    elseif query == "search" then
        -- "search:<query text>" -- see M.encodeId's caller in
        -- BookshelfWidget:_searchBookOrbitAndDrill (the search dialog's
        -- "Search BookOrbit" button). `rest` is the raw query text, not an
        -- id: decodeId's rest capture (".*") is greedy past the first
        -- colon, so a query containing ":" round-trips intact. `q` is the
        -- same catalogBooks() free-text filter the official plugin's own
        -- search box uses (see BookOrbit.catalogBooks's doc comment in
        -- bookshelf_bookorbit.lua and bookorbit_catalog.lua's runSearch),
        -- so this reaches the exact same server-side search the official
        -- plugin's search dialog does. sort defaults to "title" for the
        -- same reason the official plugin's runSearch does: matches on a
        -- free-text query don't carry a distinct relevance field over
        -- this endpoint, so title order keeps results stable across pages.
        return { q = rest, sort = "title" }
    end
    return { sort = "title" } -- "all" and anything unrecognised
end

-- Friendly default label for a chip whose source.id is `id` -- used by the
-- chip editor's "New chip" auto-rename QoL. Doesn't hit the network.
function M.labelForId(id, fallback_title)
    if fallback_title and fallback_title ~= "" then return fallback_title end
    local query = M.decodeId(id)
    if query == "recent" then return "Recently added"
    elseif query == "continue" then return "Continue reading"
    elseif query == "want_to_read" then return "Want to read"
    elseif query == "all" then return "All books"
    elseif query == "discover" then return "Discover something new"
    elseif query == "similar" then return "Similar books"
    end
    return "BookOrbit"
end

-- ---------------------------------------------------------------------
-- Picker data (used only by the chip editor, never by getBySource)
-- ---------------------------------------------------------------------

--- Root choices for the "BookOrbit section" picker: the special shortcuts
-- always offered, plus whatever drill-down sections the server advertises.
-- Returns { { value = id, label = str, needs_drill = bool, section = str|nil } }, err

-- _fetchRootChoicesWork() -- the actual network call + choice-building.
-- Kept pure -- builds and returns a plain table, no writes to shared/
-- cached state -- so it can run either inline or inside a
-- Trapper:dismissableRunInSubprocess fork below, same reasoning as
-- fetchDiscover's _fetchDiscoverWork above.
local function _fetchRootChoicesWork()
    local body, err = BookOrbit.catalogRoot()
    if not body then return nil, err end
    local choices = {
        { value = { id = M.encodeId("all"),      label = "All books" },      label = "All books" },
        { value = { id = M.encodeId("recent"),   label = "Recently added" }, label = "Recently added" },
        { value = { id = M.encodeId("continue"), label = "Continue reading" }, label = "Continue reading" },
        { value = { id = M.encodeId("want_to_read"), label = "Want to read" }, label = "Want to read" },
        { value = { id = M.encodeId("discover"), label = "Discover something new" }, label = "Discover something new" },
    }
    local seen_special = {
        ["all-books"] = true, ["recent"] = true, ["continue-reading"] = true,
        ["want-to-read"] = true, ["want_to_read"] = true, ["search"] = true,
    }
    for _, section in ipairs(body.sections or {}) do
        if not seen_special[section.section] then
            -- value is a marker table, never nil -- nil is reserved for
            -- "the user cancelled" in the chip editor's picker callback.
            choices[#choices + 1] = {
                value = { drill = section.section, title = section.title },
                label = (section.title or section.section) .. "  \xE2\x96\xB8", -- ▸
            }
        end
    end
    return choices
end

function M.fetchRootChoices()
    local choices, err
    local ok_t, Trapper = pcall(require, "ui/trapper")
    if ok_t and Trapper and Trapper.isWrapped and Trapper:isWrapped()
            and Trapper.dismissableRunInSubprocess then
        -- Already inside a Trapper coroutine (opened by the chip editor's
        -- BookOrbit picker -- see lib/bookshelf_chip_editor.lua) -- run the
        -- fetch in a dismissable subprocess so a slow/unresponsive server
        -- shows a cancellable spinner instead of freezing the dialog.
        local completed, result = Trapper:dismissableRunInSubprocess(function()
            local ok, c, werr = pcall(_fetchRootChoicesWork)
            if not ok then return { err = tostring(c) } end
            if not c then return { err = werr } end
            return { choices = c }
        end, _("Loading\xE2\x80\xA6"))
        if not completed then
            -- Cancelled -- same "couldn't reach the server" fallback a
            -- failed fetch already gets from this function's caller;
            -- nothing to invent here.
            return nil, "cancelled"
        end
        result = result or {}
        choices, err = result.choices, result.err
    else
        -- Not inside a Trapper coroutine (Trapper unavailable, or a future
        -- caller that doesn't open one) -- today's plain blocking call,
        -- unchanged.
        choices, err = _fetchRootChoicesWork()
    end
    return choices, err
end

--- Entries within one drill-down section (libraries/collections/
-- smart-scopes/authors/series). `title` is the section's display title
-- (from fetchRootChoices), used to label the prepended "whole section"
-- choice below -- falls back to a generic "All items" if omitted.
-- Returns { { value = id, label = str } }, err, hasNext

-- _fetchSectionChoicesWork(section, title) -- the actual network call +
-- choice-building. Kept pure, same reasoning as _fetchRootChoicesWork
-- above -- safe to run inline or inside a Trapper fork.
local function _fetchSectionChoicesWork(section, title)
    local body, err = BookOrbit.catalogSection(section, { page = 1 })
    if not body then return nil, err end
    local choices = {}
    -- A leaf for the section itself, not one entry within it -- e.g.
    -- picking "Authors" without drilling into a specific author. Maps to
    -- an id with an empty `rest` ("authors:"), which queryForId turns into
    -- a query with no author/library/collection/etc. filter -- effectively
    -- every book, same as the "All books" shortcut, but reachable from
    -- (and named after) this section for chip-naming purposes.
    local all_label = title and ("All " .. title) or _("All items")
    choices[#choices + 1] = {
        value = { id = M.encodeId(section, ""), label = all_label },
        label = all_label,
    }
    -- Second, separate entry point for the three sections that don't
    -- already get folder browsing via their "All <title>" row above (see
    -- GROUPED_SECTION_QUERY's comment) -- picking this instead of "All
    -- <title>" gets a chip that shows one tile per entry, drilled into
    -- live, same as "All Authors"/"All Series" already do.
    for groups_query, real_section in pairs(GROUPED_SECTION_QUERY) do
        if real_section == section then
            local folders_label = title and ("Browse " .. title .. " as folders") or _("Browse as folders")
            choices[#choices + 1] = {
                value = { id = M.encodeId(groups_query, ""), label = folders_label },
                label = folders_label,
            }
            break
        end
    end
    for _, entry in ipairs(body.items or {}) do
        local label = entry.title or "Untitled"
        if entry.count then label = label .. "  (" .. tostring(entry.count) .. ")" end
        choices[#choices + 1] = {
            value = { id = M.encodeId(section, entry.id), label = entry.title or "Untitled" },
            label = label,
        }
    end
    return choices, nil, body.hasNext
end

function M.fetchSectionChoices(section, title)
    local choices, err, has_next
    local ok_t, Trapper = pcall(require, "ui/trapper")
    if ok_t and Trapper and Trapper.isWrapped and Trapper:isWrapped()
            and Trapper.dismissableRunInSubprocess then
        -- Already inside a Trapper coroutine (opened by the chip editor's
        -- BookOrbit picker) -- run the fetch in a dismissable subprocess so
        -- a slow/unresponsive server shows a cancellable spinner instead of
        -- freezing the dialog.
        local completed, result = Trapper:dismissableRunInSubprocess(function()
            local ok, c, werr, hn = pcall(_fetchSectionChoicesWork, section, title)
            if not ok then return { err = tostring(c) } end
            if not c then return { err = werr } end
            return { choices = c, has_next = hn }
        end, _("Loading\xE2\x80\xA6"))
        if not completed then
            -- Cancelled -- same "nothing here yet" fallback the chip
            -- editor's caller already gives an empty/nil choices list.
            return nil, "cancelled"
        end
        result = result or {}
        choices, err, has_next = result.choices, result.err, result.has_next
    else
        -- Not inside a Trapper coroutine (Trapper unavailable, or a future
        -- caller that doesn't open one) -- today's plain blocking call,
        -- unchanged.
        choices, err, has_next = _fetchSectionChoicesWork(section, title)
    end
    return choices, err, has_next
end

-- ---------------------------------------------------------------------
-- Book records (used by Repo.getBySource)
-- ---------------------------------------------------------------------

local function firstAuthor(b)
    return b.authors and b.authors[1] or nil
end

local function statusFor(b, pct)
    local s = b.readStatus
    if s == "unread" or s == "reading" or s == "on_hold" or s == "finished" then return s end
    if pct >= 1 then return "finished" end
    if pct > 0 then return "reading" end
    return "unread"
end

-- ---------------------------------------------------------------------
-- Local rating override for BookOrbit catalog books
--
-- A "bookorbit://<id>" record's `rating` (see toRecord above) has nowhere
-- else to live: unlike an on-device book, there's no DocSettings sidecar
-- to read/write it from (see the comment on BookOrbit.setCatalogRating in
-- bookshelf_bookorbit.lua for why). setCatalogRating PUTs a new rating
-- straight to the server -- durable there -- but the very next time this
-- record gets rebuilt from a fresh catalogBooks()/catalogBook() fetch
-- (switch cover away and back, chip refresh, ...), toRecord would have
-- nothing to source the rating from again and the star row would appear
-- to "forget" what was just set, even though the server remembers it
-- fine. Stash a copy here, keyed by remote_id, and prefer it in toRecord
-- so the UI stays consistent across fetches within this session.
-- ---------------------------------------------------------------------
local _rating_override_settings

local function ratingOverrideSettings()
    if not _rating_override_settings then
        local LuaSettings = require("luasettings")
        local DataStorage = require("datastorage")
        _rating_override_settings = LuaSettings:open(
            DataStorage:getSettingsDir() .. "/bookshelf_bookorbit_rating_overrides.lua")
    end
    return _rating_override_settings
end

--- Call after a successful BookOrbit.setCatalogRating so the value sticks
-- locally until a future server response reports one directly.
function M.setLocalRatingOverride(remote_id, rating)
    if not remote_id then return end
    pcall(function()
        local settings = ratingOverrideSettings()
        if rating == nil then
            settings:delSetting(tostring(remote_id))
        else
            settings:saveSetting(tostring(remote_id), rating)
        end
        settings:flush()
    end)
end

local function localRatingOverride(remote_id)
    local ok, value = pcall(function()
        return ratingOverrideSettings():readSetting(tostring(remote_id))
    end)
    if not ok then return nil end
    return value
end

-- ---------------------------------------------------------------------
-- Local "flagged at" timestamp for Want to Read ordering
--
-- fetchWantToRead below re-sorts its results by each record's own
-- `updated_at` (server updatedAt) as a proxy for "most recently flagged
-- want-to-read first", since there's no server field for that
-- specifically -- see that function's doc comment. That proxy is only as
-- good as updatedAt actually being: (a) present in the plain catalogBooks()
-- list response for every item, and (b) bumped ONLY by the read-status PUT
-- and nothing else. Neither is guaranteed -- a list endpoint that omits
-- timestamps to stay lightweight, or any other metadata/rating/progress
-- PUT touching the same field, both silently degrade the resort back to
-- "whatever order the server happened to return", which is exactly the
-- scrambled-looking order the fix was meant to eliminate.
--
-- This device controls its own flagging taps completely, though, so it
-- doesn't need to trust the server's timestamp for THOSE: record the
-- local wall-clock time the moment _setWantToRead's PUT succeeds, keyed
-- by remote_id, the same way ratingOverrideSettings stashes a rating this
-- device just set. fetchWantToRead prefers this local timestamp over
-- updated_at whenever it's present, and only falls back to updated_at for
-- books flagged from another device (or before this store existed).
-- ---------------------------------------------------------------------
local _want_to_read_flag_settings

local function wantToReadFlagSettings()
    if not _want_to_read_flag_settings then
        local LuaSettings = require("luasettings")
        local DataStorage = require("datastorage")
        _want_to_read_flag_settings = LuaSettings:open(
            DataStorage:getSettingsDir() .. "/bookshelf_bookorbit_want_to_read_flags.lua")
    end
    return _want_to_read_flag_settings
end

--- Call after a successful BookOrbit.setCatalogReadStatus toggle so the
-- Want to Read chip can order by "flagged on this device just now" without
-- waiting on (or trusting) the server's own updatedAt. flagged=true stores
-- the current time; flagged=false (toggled back off) clears the entry so
-- it doesn't linger and confuse a future re-flag.
function M.setLocalWantToReadFlag(remote_id, flagged)
    if not remote_id then return end
    pcall(function()
        local settings = wantToReadFlagSettings()
        if flagged then
            settings:saveSetting(tostring(remote_id), os.time())
        else
            settings:delSetting(tostring(remote_id))
        end
        settings:flush()
    end)
end

local function localWantToReadFlagTime(remote_id)
    local ok, value = pcall(function()
        return wantToReadFlagSettings():readSetting(tostring(remote_id))
    end)
    if not ok then return nil end
    return value
end

function M.toRecord(b)
    local pct_raw = tonumber(b.progressPercentage) or 0
    local pct = pct_raw > 1 and (pct_raw / 100) or pct_raw
    local author = firstAuthor(b)
    -- Defensive type checks, not just `~= nil` -- belt-and-braces on top of
    -- bookshelf_bookorbit.lua's jsonRequest, which already strips JSON
    -- null down to a real Lua nil before this ever runs. Without this, a
    -- stray non-string/non-number value here (e.g. a null sentinel that
    -- slipped through) would previously pass a bare `~= nil` check and get
    -- tostring()'d straight into a "#userdata: 0x..." series badge instead
    -- of the book simply having no series.
    local series_name = type(b.seriesName) == "string" and b.seriesName ~= ""
        and b.seriesName or nil
    local series_num  = (type(b.seriesIndex) == "number" or type(b.seriesIndex) == "string")
        and tostring(b.seriesIndex) or nil
    return {
        -- Not a real path: distinguishes these records everywhere the grid
        -- keys by filepath (selection, cache, cover frame refresh) without
        -- colliding with any real file. Never handed to lfs/io directly --
        -- _openBook resolves a real path before opening (see is_bookorbit).
        filepath       = "bookorbit://" .. tostring(b.id),
        filename       = b.title or "Untitled",
        title          = b.title or "Untitled",
        display_title  = b.title or "Untitled",
        author         = author,
        authors        = b.authors,
        -- `series` mirrors book_repository.lua's on-device raw "<name>
        -- #<n>" form (KOReader's own BIM/info.series shape) -- NOT just a
        -- convenience duplicate of series_name/series_num below. %series /
        -- [if:series] (bookshelf_tokens.lua's Tokens.expanders.series)
        -- deliberately reads THIS field, not series_name -- it's what the
        -- hero's default Metadata-region template gates on
        -- ("[if:series]%series_name...[/if]", see bookshelf_hero_regions.lua)
        -- so a book with a series never showed one in that line without
        -- it, even though series_name/series_num were both populated the
        -- whole time.
        series         = series_name
                          and (series_name .. (series_num and (" #" .. series_num) or ""))
                          or nil,
        series_name    = series_name,
        series_num     = series_num,
        book_pct       = pct,
        status         = statusFor(b, pct),
        read_status    = statusFor(b, pct),
        -- Prefer whatever the server itself reports for this list item
        -- (if the catalog list JSON carries the caller's own rating --
        -- unconfirmed either way, so check rather than assume) and fall
        -- back to the local rating-override cache above -- needed because
        -- a rating just set from the hero would otherwise vanish on the
        -- very next fetch of this same record, whether or not the server
        -- echoes it back at list level.
        rating         = tonumber(b.rating) or localRatingOverride(b.id),
        added_time     = 0,
        last_read_time = 0,
        attr           = { mode = "file", size = 0, modification = 0 },
        format         = b.formats and b.formats[1],
        remote_id      = b.id,
        -- Raw server read status, kept SEPARATE from status/read_status
        -- above (statusFor normalizes "want_to_read" down to "unread" for
        -- badge purposes -- bookshelf's badge icons have no distinct
        -- "want to read" glyph). This is what the hero's Want to Read pill
        -- (bookshelf_hero_card.lua) checks to decide its pressed/unpressed
        -- state, and what BookshelfWidget:_setWantToRead flips locally
        -- straight after a successful server PUT so the pill updates
        -- immediately without waiting on a fresh fetch.
        bookorbit_read_status = b.readStatus,
        has_cover      = b.hasCover ~= false,
        -- Carried through so coverBB's cache filename can be versioned by
        -- it (see coverToken below) -- same field the official plugin
        -- reads off its own book objects for the same purpose.
        updated_at     = b.updatedAt,
        -- This device's own record of when IT flagged this book want-to-
        -- read (see setLocalWantToReadFlag above) -- nil for a book
        -- flagged from another device, before this store existed, or
        -- never flagged at all. fetchWantToRead's re-sort prefers this
        -- over updated_at when present.
        want_to_read_flagged_at = localWantToReadFlagTime(b.id),
        is_bookorbit   = true,
    }
end

--- Set (by listBooks below) when a shelf chip access happened while the
-- device was offline -- as opposed to BookOrbit being unconfigured, or a
-- real HTTP/server error. main.lua's onNetworkConnected consumes this to
-- decide whether a freshly-restored connection is worth an automatic shelf
-- refresh, without forcing a rebuild on every unrelated Wi-Fi event. Set
-- unconditionally on every offline access -- including one served from
-- Batch 5's stale-disk-cache fallback below, not just a genuinely empty
-- result -- since a reconnect should refresh a chip that showed stale data
-- just as much as one that showed nothing.
local _offline_miss = false

--- consumeOfflineMiss() -> bool
-- Read-and-clear _offline_miss. Called once per NetworkConnected broadcast.
function M.consumeOfflineMiss()
    local v = _offline_miss
    _offline_miss = false
    return v
end

--- onAutoWifiOff(fn) -- registers a callback main.lua runs whenever THIS
-- module turns Wi-Fi back off (the inactivity timeout below, or another
-- caller's explicit shutdown via notifyWifiOff). The bookshelf home
-- screen's Wi-Fi status icon only repaints itself off a
-- "NetworkDisconnected" broadcast (BookshelfWidget:onNetworkDisconnected),
-- and on at least some devices/backends that broadcast doesn't reliably
-- follow a purely programmatic NetworkMgr:turnOffWifi() call the way it
-- follows a user toggling Wi-Fi from KOReader's own Network menu --
-- symptom: the shelf's Wi-Fi icon keeps showing "on" after the
-- auto-connect-on-access inactivity timeout silently turns the radio back
-- off, until something else forces a repaint. Calling this directly, right
-- after the turnOffWifi() that's known to have happened, doesn't depend on
-- that broadcast at all.
local _autowifioff_cb
function M.onAutoWifiOff(fn)
    _autowifioff_cb = fn
end

--- notifyWifiOff() -- fires the onAutoWifiOff callback, if one is
-- registered. Exposed (not just called internally by _disconnectAutoWifi
-- below) so other call sites in this plugin that also call
-- NetworkMgr:turnOffWifi() after borrowing the radio (e.g. bookshelf_
-- bookorbit.lua's withWifiGate, used by the sync feature's auto-Wi-Fi) can
-- report the same state change through the same single path.
function M.notifyWifiOff()
    if not _autowifioff_cb then return end
    local ok_cb, err = pcall(_autowifioff_cb)
    if not ok_cb then
        require("logger").warn("[bookshelf] auto-wifi-off notify failed:", err)
    end
end

--- onReconnected(fn) -- registers a callback main.lua runs whenever a Wi-Fi
-- connection THIS module brought up (_tryAutoConnect below) is confirmed
-- genuinely online. This is a second, more reliable trigger for the
-- offline-chip refresh alongside main.lua's NetworkConnected broadcast
-- handler: that broadcast can fire as soon as Wi-Fi associates with an AP,
-- BEFORE NetworkMgr:isOnline() actually confirms internet access, so a
-- rebuild triggered from it can race a still-offline listGroups/listBooks
-- call, re-arm _offline_miss, and then have nothing left to consume the
-- flag once real connectivity lands a moment later -- leaving a BookOrbit
-- chip (e.g. the Authors group view) empty until the user manually
-- refreshes. NetworkMgr:runWhenOnline's own callback only fires once
-- connectivity is actually confirmed, so re-running the same
-- consumeOfflineMiss + rebuild check there closes that race regardless of
-- which trigger ends up firing last.
local _reconnected_cb
function M.onReconnected(fn)
    _reconnected_cb = fn
end

-- Debounce guard for _tryAutoConnect below -- shared across all callers/pages
-- since a page-turn or repeated rebuild can call listBooks many times a
-- second while still offline.
local _reconnect_pending = false

-- ---------------------------------------------------------------------
-- Auto Wi-Fi on BookOrbit access -- inactivity-timeout bookkeeping
-- ---------------------------------------------------------------------
-- _access_wifi_owned is true only for the stretch where THIS feature is
-- the one that brought Wi-Fi up (radio was off, _tryAutoConnect turned it
-- on) -- never when the radio was already on for some other reason (user
-- turned it on, a sync's withAutoWifi is using it, etc.), mirroring the
-- "only turn off what it turned on" rule that follows. While true, every
-- further BookOrbit chip/section access (_noteAccess, called from
-- listBooks/listGroups on every entry, not just offline ones) pushes the
-- auto-disconnect timer back out by autoWifiOnAccessTimeoutSeconds(); if
-- that many seconds pass with no access, _disconnectAutoWifi fires and
-- turns the radio back off.
local _access_wifi_owned = false

local function _disconnectAutoWifi()
    _access_wifi_owned = false
    local ok_net, NetworkMgr = pcall(require, "ui/network/manager")
    if ok_net and NetworkMgr and NetworkMgr.turnOffWifi then
        pcall(function() NetworkMgr:turnOffWifi() end)
    end
    -- Don't rely solely on NetworkMgr's own "NetworkDisconnected" broadcast
    -- to update the shelf's Wi-Fi icon -- see onAutoWifiOff's doc comment
    -- above for why that broadcast can't be trusted to follow every
    -- programmatic turnOffWifi() call.
    M.notifyWifiOff()
end

local function _armAccessTimeout()
    local ok_ui, UIManager = pcall(require, "ui/uimanager")
    if not (ok_ui and UIManager) then return end
    local secs = (BookOrbit.autoWifiOnAccessTimeoutSeconds and BookOrbit.autoWifiOnAccessTimeoutSeconds())
        or 180
    UIManager:unschedule(_disconnectAutoWifi)
    UIManager:scheduleIn(secs, _disconnectAutoWifi)
end

--- _isOffline() -> true only if NetworkMgr positively reports the radio is
-- off/disconnected. A missing/broken NetworkMgr (pcall failure, or no
-- isOnline method) is treated as "online" -- i.e. never used to withhold a
-- fetch that might otherwise have worked -- same fail-open spirit as the
-- version-gate check below. Shared by listBooks/listGroups' top-level
-- check and by Batch 5's per-fetch offline short-circuits (fetchDiscover,
-- fetchSimilar, fetchWantToRead, fetchSectionBucket) below, so there's one
-- place that defines what "offline" means for this whole module.
local function _isOffline()
    local ok_net, NetworkMgr = pcall(require, "ui/network/manager")
    return (ok_net and NetworkMgr and NetworkMgr.isOnline and not NetworkMgr:isOnline()) or false
end

--- Called on every listBooks/listGroups entry, online or off, so browsing
-- around resets the inactivity clock. No-op unless _access_wifi_owned --
-- if this feature doesn't own the current connection there's no timer of
-- its to push out.
local function _noteAccess()
    if _access_wifi_owned then _armAccessTimeout() end
end

-- ---------------------------------------------------------------------
-- Disk-cache version gate (Batch 4) -- see bookshelf_bookorbit_cache.lua's
-- checkVersionAndInvalidate and bookshelf_bookorbit.lua's
-- getLibraryVersion for the full design/risk writeup this wires together.
-- ---------------------------------------------------------------------
-- BookOrbit.getLibraryVersion() is one blocking HTTP round-trip. Doing it
-- on every listBooks/listGroups entry (i.e. every page turn, and every
-- onCoversReady-triggered _rebuild() of the SAME page -- see listBooks'
-- doc comment on cacheNextPage above, 2-4 rebuilds per page landing is
-- normal) would add a network request to interactions that currently cost
-- zero once a page is cached, defeating the entire point of this batch.
--
-- There is no distinct "chip opened" event this module gets called on --
-- the widget re-enters listBooks/listGroups for page turns, repaint-
-- triggered rebuilds, and internal helper lookups (e.g. listGroups'
-- per-tile sample-book fetch, M.listBooks(gid, 0, 1)) all the same way.
-- So "once per chip-open" is approximated with a time debounce instead of
-- an exact event: at most one getLibraryVersion() call per
-- VERSION_CHECK_MIN_INTERVAL_SECONDS, mirroring the same 30s-debounce
-- shape already used twice elsewhere for an identical reason --
-- bookshelf_bookorbit_cache.lua's own FLUSH_MIN_INTERVAL_SECONDS for
-- disk writes, and this file's own _tryAutoConnect ("at most once per
-- ~30s while offline"). A burst of same-page rebuilds a few hundred ms
-- apart shares one check; actually reopening a chip after a real pause
-- gets a fresh one. This does mean two chip-opens inside the same 30s
-- window share a single check rather than each getting their own --
-- an acceptable approximation, since nothing server-side plausibly
-- changes on a sub-30s cadence and the fail-open behavior below means
-- the worst case of a skipped check is one extra page of staleness, not
-- a correctness bug.
local VERSION_CHECK_MIN_INTERVAL_SECONDS = 30
local _version_check_last_time = nil

--- Runs BookOrbit.getLibraryVersion() (at most once per debounce window)
-- and feeds the result into Cache.checkVersionAndInvalidate(), which just
-- tracks whether the server-side baseline has moved -- it does NOT wipe
-- anything on a detected change any more (see that function's own doc
-- comment for why: the token is library-wide with no per-section detail,
-- so the only invalidation it could ever drive was "wipe literally
-- everything", which meant one book added anywhere nuked every chip's
-- cache including ones the user never touched). This call is now purely
-- a diagnostic/bookkeeping step from this file's point of view -- the
-- actual mechanisms that keep a chip current are natural cache misses
-- (paging into something never fetched always hits the network) and
-- manual refresh (invalidateAll() / the per-family invalidate*Cache()
-- calls in bookshelf_widget.lua's swipe refresh, unconditional and
-- independent of this check entirely).
--
-- cache_key (optional): the specific cache entry this listBooks/listGroups
-- call is about to read. If it's already resident (a cache HIT), this
-- skips the version check entirely -- there's a real page to render
-- immediately either way, so paying for a blocking manifest round-trip
-- before showing it would only slow down the one case (revisiting a chip
-- you've already opened) where speed matters most. Skipping here does
-- NOT advance _version_check_last_time, so a genuine cache MISS reached
-- moments later (a different id/offset, or a newly-opened chip) still
-- gets checked on its own merits. If cache_key is omitted, this always
-- checks (subject to the normal debounce) -- used for callers that don't
-- have a single specific key to gate on.
--
-- Always safe to call unconditionally from listBooks/listGroups: the
-- debounce makes repeats a no-op, and a failed/offline version check
-- fails open (Cache.checkVersionAndInvalidate gets nil, returns
-- "skipped", cache untouched) rather than ever treating "couldn't
-- verify" as "must be stale".
local function _checkLibraryVersionIfDue(cache_key)
    if cache_key ~= nil and Cache.get(cache_key) ~= nil then
        return
    end
    local now = os.time()
    if _version_check_last_time
        and (now - _version_check_last_time) < VERSION_CHECK_MIN_INTERVAL_SECONDS
    then
        return
    end
    _version_check_last_time = now
    local version = BookOrbit.getLibraryVersion()
    Cache.checkVersionAndInvalidate(version)
end

--- Kick off (at most once per ~30s while offline) an attempt to bring Wi-Fi
-- up in the background: turns it on / reconnects a saved network, prompting
-- the user only if none is saved (NetworkMgr:runWhenOnline never forces a
-- silent connection past that). Gated on the "Auto-connect Wi-Fi on
-- BookOrbit access" setting (autoWifiOnAccessEnabled, off by default) -- a
-- no-op straight away if that's off, same as it always was before that
-- setting existed. Debounced so a shelf that's rendered or scrolled
-- repeatedly while offline doesn't retry -- or re-prompt -- on every single
-- call; roughly once per this window instead.
--
-- Deliberately fire-and-forget: the actual shelf refresh happens via
-- main.lua's onNetworkConnected + consumeOfflineMiss above once the
-- connection (this attempt, or the user turning Wi-Fi on themselves)
-- actually lands -- not via a callback threaded back through here, since
-- listBooks itself must stay synchronous for the grid's rebuild path.
local function _tryAutoConnect()
    if not (BookOrbit.autoWifiOnAccessEnabled and BookOrbit.autoWifiOnAccessEnabled()) then
        return
    end
    if _reconnect_pending then return end
    local ok_net, NetworkMgr = pcall(require, "ui/network/manager")
    if not (ok_net and NetworkMgr and NetworkMgr.runWhenOnline) then return end
    _reconnect_pending = true

    -- Remember whether the radio itself was off before this call -- same
    -- bookkeeping the sync-side withAutoWifi does -- so the inactivity
    -- timeout above never cuts a connection out from under something
    -- else that's using it (was_wifi_on true means this call isn't the
    -- one responsible for it, so it never claims ownership below).
    local ok_wifi, was_wifi_on = pcall(function() return NetworkMgr:isWifiOn() end)
    was_wifi_on = ok_wifi and was_wifi_on

    local ok_ui, UIManager = pcall(require, "ui/uimanager")
    if ok_ui and UIManager then
        -- Release the guard after a while regardless of outcome -- a
        -- dismissed Wi-Fi prompt (or no saved network at all) shouldn't
        -- permanently block every later retry for the rest of the session.
        UIManager:scheduleIn(30, function() _reconnect_pending = false end)
    end
    NetworkMgr:runWhenOnline(function()
        _reconnect_pending = false
        if not was_wifi_on then
            _access_wifi_owned = true
            _armAccessTimeout()
        end
        -- Connectivity is confirmed genuine at this point (unlike the
        -- NetworkConnected broadcast, which can fire on mere Wi-Fi
        -- association) -- run the registered refresh so a chip that missed
        -- the broadcast's earlier, possibly-still-offline rebuild attempt
        -- still gets populated without a manual refresh.
        if _reconnected_cb then
            local ok_cb, err = pcall(_reconnected_cb)
            if not ok_cb then
                require("logger").warn("[bookshelf] bookorbit reconnect refresh failed:", err)
            end
        end
    end)
end

-- One cached Discover batch per source id (there's really only ever one,
-- "discover:", but keying by id costs nothing and stays consistent with
-- _known_total below). /catalog/dashboard/discover has no page/size params
-- -- every request is a fresh random selection -- so unlike the other
-- root queries, this can't be re-fetched per page turn without silently
-- swapping in different books on every "next page" tap. Fetched once,
-- then paginated client-side out of this cache; the total is exact and
-- known from the very first page, since the whole batch is already held.
--
-- Held in the shared bookshelf_bookorbit_cache module (see that file) --
-- the same size-budgeted RAM cache every other BookOrbit section below
-- now uses, kept until this key is invalidated or evicted for space,
-- never on a timer.
local DISCOVER_PREFIX = "discover:"

-- _fetchDiscoverWork() -- the actual network call + record-building for
-- Discover. Kept pure -- no Cache.set inside -- so it can run either
-- inline or inside a Trapper:dismissableRunInSubprocess fork below
-- without a fork's write to the cache silently vanishing (a forked
-- subprocess's writes to shared/module state never make it back to the
-- parent process -- same reasoning as _fetchBooksPage/_walkSectionPages
-- elsewhere in this file).
local function _fetchDiscoverWork()
    local body, err = BookOrbit.catalogDiscover()
    if not body then return nil, err end
    local records = {}
    for _, b in ipairs(body.discover or {}) do
        records[#records + 1] = M.toRecord(b)
    end
    return records
end

-- fetchDiscover(id, force) -> records (array, may be empty on failure)
-- force=true re-hits the server for a brand-new random batch (the
-- "reroll" -- see M.rerollDiscover / invalidateDiscoverCache below);
-- otherwise reuses whatever batch this source id already has cached.
local function fetchDiscover(id, force)
    local key = DISCOVER_PREFIX .. id
    if not force then
        local cached = Cache.get(key)
        if cached then return cached end
    end

    -- Batch 5: offline -- don't attempt a network call that can only fail
    -- (this is exactly the case BOOKORBIT_INTEGRATION.md's testing
    -- checklist flags as "should show an empty grid rather than erroring
    -- or hanging"). Serve whatever this id's last successful Discover
    -- batch was, if any -- same fallback shape a failed fetch gets below,
    -- just reached without paying for the doomed attempt first.
    if _isOffline() then
        return Cache.get(key) or {}
    end

    local records, err
    local ok_t, Trapper = pcall(require, "ui/trapper")
    if ok_t and Trapper and Trapper.isWrapped and Trapper:isWrapped()
            and Trapper.dismissableRunInSubprocess then
        -- Already inside a Trapper coroutine (opened by whichever chip/
        -- drilldown reached M.listBooks -- see that function's "discover"
        -- branch) -- run the fetch in a dismissable subprocess so a slow/
        -- unresponsive server shows a cancellable spinner instead of
        -- freezing the reader.
        local completed, result = Trapper:dismissableRunInSubprocess(function()
            local ok, recs, werr = pcall(_fetchDiscoverWork)
            if not ok then return { err = tostring(recs) } end
            if not recs then return { err = werr } end
            return { records = recs }
        end, _("Loading\xE2\x80\xA6"))
        if not completed then
            -- Cancelled -- keep serving the last good batch (if any),
            -- same "nothing new yet" fallback a failed fetch gets below.
            return Cache.get(key) or {}
        end
        result = result or {}
        records, err = result.records, result.err
    else
        -- Not inside a Trapper coroutine (background/proactive caller --
        -- e.g. M.rerollDiscover called from outside a render path -- or
        -- Trapper unavailable) -- today's plain blocking call, unchanged.
        records, err = _fetchDiscoverWork()
    end

    if not records then
        local ok_log, logger = pcall(require, "logger")
        if ok_log then logger.info("Bookshelf BookOrbit: catalogDiscover failed", err) end
        -- Keep serving the last good batch (if any) rather than blanking
        -- the shelf on a transient network hiccup; only a genuine first
        -- fetch failure returns empty.
        return Cache.get(key) or {}
    end
    Cache.set(key, records)
    return records
end

--- rerollDiscover(id) -> fetches and caches a brand-new random batch for
-- this source id, mirroring the official plugin's Discover reroll button.
-- Callers should rebuild the chip afterwards to show the new set.
function M.rerollDiscover(id)
    return fetchDiscover(id, true)
end

--- invalidateDiscoverCache(id) -> drops one Discover chip's cached batch
-- (id is the chip's own encoded "discover:..." id), or -- when called
-- with no argument -- every cached Discover batch, so the next fetch for
-- any Discover chip re-rolls. The scoped form is what a manual refresh
-- of ONE chip should use (see bookshelf_widget.lua's _refreshLibrary):
-- refreshing one Discover chip has no business re-rolling every OTHER
-- Discover chip's batch too. The unscoped form is kept for callers that
-- genuinely mean "everything" (e.g. Settings' "Clear BookOrbit cache").
function M.invalidateDiscoverCache(id)
    if id then
        Cache.invalidate(DISCOVER_PREFIX .. id)
    else
        Cache.invalidatePrefix(DISCOVER_PREFIX)
    end
end

-- One cached "Similar books" batch per remote book id ("similar:<id>").
-- Like Discover above, this isn't a page/size-able catalogBooks() filter --
-- it's one section of the per-book detail response (GET .../books/<id>,
-- the same endpoint rebuildRecord/prefetchDescriptions already call for
-- the synopsis) -- so the whole section is fetched once and paginated
-- client-side out of this cache, the same "fetch once, slice in memory"
-- shape fetchDiscover uses for its own single, un-page-able batch.
local SIMILAR_PREFIX = "similar:"

-- fetchSimilar(remote_id, force) -> records (array, may be empty on failure
-- or if the server has nothing similar for this book). force=true re-hits
-- the server; otherwise reuses whatever's already cached for this id.
--
-- Two server calls, not one: the "similar" section's own book objects
-- (embedded in the per-book detail response) turned out to be a slimmer
-- shape than a normal catalog list item -- no series/progress/read-status
-- at all, not merely null -- which is why Similar results showed no series
-- badge/pill even after fixing the earlier JSON-null-sentinel bug (that
-- fix was real and still needed, just not sufficient here). So this only
-- uses the detail response to learn WHICH books are similar and in what
-- order, then re-fetches those same book ids through the normal
-- catalogBooks() "ids" filter -- the same call the official plugin's own
-- "On device" virtual library uses (see the reference bookorbit.koplugin's
-- bookorbit_catalog.lua) -- to get the full list-item shape every other
-- section (Author/Series/Discover/...) already relies on. The extra
-- request is cheap: one per Similar pill tap (cached after that), same as
-- every other group drilldown here.
-- _fetchSimilarWork(remote_id) -- the actual two-call network body: the
-- per-book detail lookup (to learn which books are similar and in what
-- order), then, on success, the catalogBooks(ids=...) refetch for the
-- full list-item shape (see the doc comment above fetchSimilar for why
-- two calls). Kept pure -- no Cache.set inside -- so it can run either
-- inline or inside a single Trapper:dismissableRunInSubprocess fork below
-- -- BOTH calls in the same fork, not two separate forks, mirroring
-- resolveOpenPath's _resolveWork elsewhere in this file.
local function _fetchSimilarWork(remote_id)
    local detail, err = BookOrbit.catalogBook(remote_id)
    if not detail then return nil, err end

    -- Slim ids-only pass: just enough to know which books, and the
    -- server's similarity ranking (position in this list), NOT their full
    -- metadata -- see above for why.
    local similar_ids, rank = {}, {}
    for _, section in ipairs(detail.relatedSections or {}) do
        if section.id == "similar" then
            for _, b in ipairs(section.books or {}) do
                if b.id ~= nil then
                    local id_str = tostring(b.id)
                    if not rank[id_str] then
                        similar_ids[#similar_ids + 1] = id_str
                        rank[id_str] = #similar_ids
                    end
                end
            end
            break
        end
    end
    if #similar_ids == 0 then return {} end

    local records
    local body, body_err = BookOrbit.catalogBooks{
        ids  = table.concat(similar_ids, ","),
        size = #similar_ids,
    }
    if body and type(body.items) == "table" then
        -- catalogBooks(ids=...) doesn't promise to preserve the `ids`
        -- order, so re-sort the full-shaped results back into the
        -- server's original similarity ranking learned above.
        records = {}
        for _, b in ipairs(body.items) do
            records[#records + 1] = b
        end
        table.sort(records, function(a, b2)
            return (rank[tostring(a.id)] or math.huge) < (rank[tostring(b2.id)] or math.huge)
        end)
        for i, b in ipairs(records) do records[i] = M.toRecord(b) end
    else
        local ok_log, logger = pcall(require, "logger")
        if ok_log then
            logger.info("Bookshelf BookOrbit: catalogBooks(ids=...) for similar failed", body_err)
        end
        -- Fall back to the slim relatedSections shape rather than an
        -- empty drilldown -- still tappable/openable, just without
        -- series/progress until the next successful fetch.
        records = {}
        for _, section in ipairs(detail.relatedSections or {}) do
            if section.id == "similar" then
                for _, b in ipairs(section.books or {}) do
                    records[#records + 1] = M.toRecord(b)
                end
                break
            end
        end
    end
    return records
end

-- fetchSimilar(remote_id, force) -> records (array, may be empty on failure
-- or if the server has nothing similar for this book). force=true re-hits
-- the server; otherwise reuses whatever's already cached for this id.
local function fetchSimilar(remote_id, force)
    local key = SIMILAR_PREFIX .. tostring(remote_id)
    if not force then
        local cached = Cache.get(key)
        if cached then return cached end
    end

    -- Batch 5: offline -- see fetchDiscover's identical check above for
    -- the reasoning; same fallback shape.
    if _isOffline() then
        return Cache.get(key) or {}
    end

    local records, err
    local ok_t, Trapper = pcall(require, "ui/trapper")
    if ok_t and Trapper and Trapper.isWrapped and Trapper:isWrapped()
            and Trapper.dismissableRunInSubprocess then
        -- Already inside a Trapper coroutine (opened by whichever chip/
        -- drilldown reached M.listBooks -- see that function's "similar"
        -- branch) -- run both calls in one dismissable subprocess so a
        -- slow/unresponsive server on either one shows a cancellable
        -- spinner instead of freezing the reader.
        local completed, result = Trapper:dismissableRunInSubprocess(function()
            local ok, recs, werr = pcall(_fetchSimilarWork, remote_id)
            if not ok then return { err = tostring(recs) } end
            if not recs then return { err = werr } end
            return { records = recs }
        end, _("Loading\xE2\x80\xA6"))
        if not completed then
            -- Cancelled -- keep serving the last good batch (if any),
            -- same "nothing new yet" fallback a failed fetch gets below.
            return Cache.get(key) or {}
        end
        result = result or {}
        records, err = result.records, result.err
    else
        -- Not inside a Trapper coroutine (background/proactive caller, or
        -- Trapper unavailable) -- today's plain blocking calls, unchanged.
        records, err = _fetchSimilarWork(remote_id)
    end

    if not records then
        local ok_log, logger = pcall(require, "logger")
        if ok_log then logger.info("Bookshelf BookOrbit: catalogBook (similar) failed", err) end
        -- Keep serving the last good batch (if any) rather than blanking
        -- the drilldown on a transient network hiccup.
        return Cache.get(key) or {}
    end
    Cache.set(key, records)
    return records
end

--- invalidateSimilarCache(remote_id) -> drops one book's cached "Similar
-- books" batch, or -- with no argument -- every cached batch, so the
-- next Similar pill tap re-fetches. Mirrors invalidateDiscoverCache
-- above; the scoped form is what the shelf's manual refresh uses (only
-- the currently-previewed book's Similar batch is even visible right
-- now, so that's all a refresh needs to drop).
function M.invalidateSimilarCache(remote_id)
    if remote_id then
        Cache.invalidate(SIMILAR_PREFIX .. tostring(remote_id))
    else
        Cache.invalidatePrefix(SIMILAR_PREFIX)
    end
end

--- findCatalogIdForLocalBook(book) -> remote_id, or nil, err. Looks up a
-- LOCAL (non-BookOrbit) book's title/author against the server's catalog
-- (GET .../catalog/books?q=<title>&author=<author>) to find the matching
-- catalog record, so its Similar pill (see _buildPillSpecs in
-- bookshelf_widget.lua) has a remote_id to key "similar:<id>" off of --
-- exactly like a BookOrbit-sourced book already carries one. One request
-- per tap, same "blocking network call from a UI callback" style as
-- coverBB/rebuildRecord elsewhere in this module; not cached, since a
-- local book's match can't be invalidated the way a remote id's own
-- Similar batch can.
--
-- Matching is deliberately simple (exact, case-insensitive title, then
-- author if more than one title matches) rather than the full fuzzy
-- scorer bookshelf_hardcover_match.lua uses for a different service --
-- the query already asks the server to narrow by q/author, so this only
-- has to pick among a handful of close candidates it returns.
function M.findCatalogIdForLocalBook(book)
    if not M.isAvailable() then return nil, "not_configured" end
    local title = book and book.title
    if not title or title == "" then return nil, "no_title" end
    local author = (type(book.authors) == "table" and book.authors[1])
        or (book.author and book.author ~= "" and book.author or nil)
    local body, err = BookOrbit.catalogBooks{ q = title, author = author, size = 5 }
    if not body or not body.items or #body.items == 0 then
        return nil, err or "no_match"
    end
    local title_l = title:lower()
    local candidates = body.items
    local exact = {}
    for _, item in ipairs(candidates) do
        if item.title and item.title:lower() == title_l then
            exact[#exact + 1] = item
        end
    end
    if #exact == 1 then return exact[1].id end
    if #exact > 1 and author then
        local author_l = author:lower()
        for _, item in ipairs(exact) do
            for _, a in ipairs(item.authors or {}) do
                if type(a) == "string" and a:lower() == author_l then
                    return item.id
                end
            end
        end
    end
    if #exact >= 1 then return exact[1].id end
    -- No exact title match: fall back to the server's top hit for the
    -- query rather than showing nothing for a book it clearly has under
    -- a slightly different title string.
    return candidates[1].id
end

--- communityRating(record, provider) -> rating (number, 0-5, may be
-- fractional), ratingCount, or nil if this record has no cached rating
-- from `provider` (no server-side rating for this book from that
-- provider, an unpatched BookOrbit server that never sent
-- communityRatings at all, or a local/non-BookOrbit record). `provider`
-- is one of the server's MetadataProviderKey strings this plugin
-- exposes a choice for: "hardcover", "goodreads", "amazon", "itunes".
function M.communityRating(record, provider)
    if not (record and provider and record.community_ratings) then return nil end
    for _, entry in ipairs(record.community_ratings) do
        if entry.provider == provider and tonumber(entry.rating) then
            return tonumber(entry.rating), tonumber(entry.ratingCount)
        end
    end
    return nil
end

--- communityRatingFallback(record, providers) -> rating, ratingCount,
-- provider, or nil if none of `providers` (an ordered array of provider
-- keys, e.g. { "goodreads", "itunes", "hardcover" } from the Settings >
-- BookOrbit > "Community rating in hero" picker) has a rating for this
-- record. Tries each in the given order and stops at the first hit --
-- exactly the "goodreads > apple books > hardcover" priority chain
-- described in the setting's help text, rather than always preferring
-- one fixed provider regardless of what the person actually asked for.
function M.communityRatingFallback(record, providers)
    if not (record and providers) then return nil end
    for _, provider in ipairs(providers) do
        local rating, count = M.communityRating(record, provider)
        if rating then return rating, count, provider end
    end
    return nil
end


-- ever one, "want_to_read:", but keyed the same way Discover/Similar are
-- above for consistency). This is NOT a plain catalogBooks(readStatus=...)
-- filter, unlike "continue" (readStatus="reading") right above it in
-- queryForId -- confirmed against the reference bookorbit.koplugin: its
-- CatalogUtil.READ_STATUS_FILTERS (bookorbit_catalog_util.lua), the ONLY
-- table anywhere in that plugin that lists values the server's `readStatus`
-- catalogBooks() query param actually accepts, has just three entries --
-- "unread", "reading", "finished" -- and nothing in the whole reference
-- plugin (dashboard, catalog browser, section root) ever sends
-- readStatus="want_to_read" over the wire. "want_to_read" IS a real
-- per-book status (CatalogUtil.SETTABLE_READ_STATUSES, set via
-- catalogSetReadStatus and read back as book.readStatus), it's just not
-- one of the three the *filter* endpoint understands -- so the query this
-- file used to build for the "Want to read" chip (queryForId's
-- readStatus="want_to_read" branch, still above for reference/labelForId)
-- asked the server to filter on a value it has no bucket for, which is
-- why that chip came back empty instead of erroring loudly.
--
-- Fixed the same way Similar re-derives full records from a slim id list
-- above: fetch normally (no readStatus filter, so every status comes
-- back) and keep only the items whose own book.readStatus is literally
-- "want_to_read", walking pages until either the server runs out
-- (hasNext false) or WANT_TO_READ_MAX_SCAN books have been examined --
-- a hand-flagged "want to read" list is expected to be a small minority
-- of the catalog, not something worth an unbounded full-library walk.
--
-- Sort/order: there's no server field for "date flagged want to read"
-- specifically -- CatalogUtil.SORTS (the reference plugin's only sort
-- menu) has title/author/recently_added/recently_updated/recently_read/
-- series, nothing want-to-read-specific. "recently_added" (what this
-- first shipped with) is the book's LIBRARY add date, unrelated to when
-- it was flagged -- walking pages in that order and just keeping matches
-- effectively scatters them, which is why the chip looked randomly
-- ordered instead of matching the server's own "most recently flagged
-- first" view. book.readStatus is set via a plain PUT
-- .../read-status (BookOrbit.setCatalogReadStatus), which -- like any
-- other field-changing PUT on a book -- bumps its updatedAt, so
-- "recently_updated" is the closest available proxy for "most recently
-- flagged first". Requesting that sort AND re-sorting the filtered
-- result by each record's own updated_at (set below) is belt-and-braces:
-- the explicit re-sort is what actually guarantees the final order,
-- independent of whether the server's own recently_updated tie-breaking
-- matches ours exactly.
local WANT_TO_READ_PREFIX   = "want_to_read:"
local WANT_TO_READ_MAX_SCAN = 2000
local WANT_TO_READ_PAGE     = 100

-- fetchWantToRead(id, force) -> records (array, may be empty on failure or
-- if nothing is flagged). force=true re-walks the catalog from page 1;
-- otherwise reuses whatever's already cached for this id.
-- _walkWantToReadPages() -- the actual bounded network walk + client-side
-- filter/sort (see the doc comment above fetchWantToRead for why the
-- filter-then-sort is needed instead of a single catalogBooks() filter
-- call). Kept pure -- no Cache.set inside -- so it can run either inline
-- or inside a Trapper:dismissableRunInSubprocess fork below, same shape
-- as _walkSectionPages elsewhere in this file. On a mid-walk failure this
-- discards whatever partial page results this call had already collected
-- and returns nil, err -- same "don't cache a partial scan" behaviour the
-- original inline loop had.
local function _walkWantToReadPages()
    local records, scanned, page = {}, 0, 1
    while scanned < WANT_TO_READ_MAX_SCAN do
        local body, err = BookOrbit.catalogBooks{
            sort = "recently_updated",
            page = page,
            size = WANT_TO_READ_PAGE,
        }
        if not body then return nil, err end
        local items = body.items or {}
        for _, b in ipairs(items) do
            if b.readStatus == "want_to_read" then
                records[#records + 1] = M.toRecord(b)
            end
        end
        scanned = scanned + #items
        if not body.hasNext or #items == 0 then break end
        page = page + 1
    end
    -- Explicit re-sort, newest-flagged first -- see the doc comment above
    -- fetchWantToRead for why this (not just the server's own
    -- recently_updated ordering) is what actually pins the final order
    -- down.
    --
    -- Primary key is THIS device's own want_to_read_flagged_at (set the
    -- instant _setWantToRead's PUT succeeds -- see that field's doc
    -- comment in toRecord/setLocalWantToReadFlag above), since that's the
    -- one timestamp guaranteed to both exist and mean exactly "flagged
    -- want-to-read", independent of whether the server's list response
    -- includes updatedAt at all, or bumps it for reasons unrelated to
    -- flagging (a rating/progress/metadata PUT touches the same field).
    -- Falls back to updated_at for a book flagged from another device (or
    -- before this local store existed), and finally to a stable no-op so
    -- two records with neither timestamp keep whatever relative order the
    -- scan found them in rather than bouncing around on every fetch.
    local function sortKey(r) return r.want_to_read_flagged_at, r.updated_at end
    table.sort(records, function(a, b)
        local afl, au = sortKey(a)
        local bfl, bu = sortKey(b)
        if afl or bfl then
            if not afl then return false end
            if not bfl then return true end
            if afl == bfl then return false end
            return afl > bfl
        end
        if not au or au == "" then return false end
        if not bu or bu == "" then return true end
        return au > bu
    end)
    return records
end

local function fetchWantToRead(id, force)
    local key = WANT_TO_READ_PREFIX .. id
    if not force then
        local cached = Cache.get(key)
        if cached then return cached end
    end

    -- Batch 5: offline -- see fetchDiscover's identical check above for
    -- the reasoning; same fallback shape.
    if _isOffline() then
        return Cache.get(key) or {}
    end

    local records, err
    local ok_t, Trapper = pcall(require, "ui/trapper")
    if ok_t and Trapper and Trapper.isWrapped and Trapper:isWrapped()
            and Trapper.dismissableRunInSubprocess then
        -- Already inside a Trapper coroutine (opened by whichever chip/
        -- drilldown reached M.listBooks -- see that function's
        -- "want_to_read" branch) -- run the bounded walk in a dismissable
        -- subprocess so a slow/unresponsive server shows a cancellable
        -- spinner instead of freezing the reader, same as
        -- fetchSectionBucket's walk elsewhere in this file.
        local completed, result = Trapper:dismissableRunInSubprocess(function()
            local ok, recs, werr = pcall(_walkWantToReadPages)
            if not ok then return { err = tostring(recs) } end
            if not recs then return { err = werr } end
            return { records = recs }
        end, _("Loading\xE2\x80\xA6"))
        if not completed then
            -- Cancelled -- keep serving the last good batch (if any),
            -- same "nothing new yet" fallback a failed fetch gets below.
            return Cache.get(key) or {}
        end
        result = result or {}
        records, err = result.records, result.err
    else
        -- Not inside a Trapper coroutine (background/proactive caller, or
        -- Trapper unavailable) -- today's plain blocking walk, unchanged.
        records, err = _walkWantToReadPages()
    end

    if not records then
        local ok_log, logger = pcall(require, "logger")
        if ok_log then logger.info("Bookshelf BookOrbit: fetchWantToRead failed", err) end
        -- Keep serving the last good batch (if any) rather than
        -- blanking the chip on a transient network hiccup; only a
        -- genuine first-fetch failure returns empty.
        return Cache.get(key) or {}
    end
    Cache.set(key, records)
    return records
end

--- invalidateWantToReadCache(id) -- drops one "Want to read" chip's cached
-- batch, or -- with no argument -- every cached batch, so the next fetch
-- re-walks the catalog. Mirrors invalidateDiscoverCache/
-- invalidateSimilarCache above. The unscoped form stays the right call
-- after a status flip (bookshelf_widget.lua's _setBookorbitReadStatus):
-- that book could belong to ANY Want-to-read chip's cached list, and
-- there's no cheap way to know which id(s) without re-walking anyway.
-- The scoped form is for the shelf's manual refresh of one specific
-- chip -- see _refreshLibrary.
function M.invalidateWantToReadCache(id)
    if id then
        Cache.invalidate(WANT_TO_READ_PREFIX .. id)
    else
        Cache.invalidatePrefix(WANT_TO_READ_PREFIX)
    end
end

-- Highest "total" ever synthesised per source id -- fallback path only,
-- for the rare response that omits body.total (see listBooks below). Keyed
-- by the chip's source.id string, so different chips/sections never bleed
-- into each other's count. Paging backward must not forget a total the
-- forward page already confirmed to exist -- otherwise the footer
-- regresses from e.g. "3 of 4" back down to "2 of 3" the moment the user
-- taps the left chevron, even though page 3 is known to exist.
local _known_total = {}

--- listBooks(id, offset, limit) -> records, total
-- Maps the grid's offset/limit window onto one catalogBooks() page (limit
-- is the view size, so this is exactly one request per page turn).
--
-- /koreader/plugin/catalog/books actually DOES report an exact total --
-- confirmed against the official bookorbit.koplugin's catalog browser
-- (bookorbit_catalog.lua), which already computes
-- `page_count = ceil(body.total / body.size)` for its own pagination.
-- This bridge previously ignored that field and synthesised a fake total
-- from `hasNext` alone (just far enough past the current window to keep
-- forward paging enabled), which is why the chip footer always read
-- "page N of N+1" instead of the real page count. Now body.total is used
-- whenever the server sends it; the old hasNext-based guess only kicks in
-- as a fallback for a response that (for whatever reason) omits it, and
-- even then never regresses below a total a later page already confirmed.
-- Cache holding every listBooks() page fetched over the wire, keyed by
-- the full (id, offset, limit) -- either warmed ahead of time by
-- prefetchNextPage (see that function below), or -- the common case,
-- since prefetchNextPage is currently disabled -- the page listBooks()
-- itself *just* fetched a moment ago, cached right after the HTTP
-- response comes back (see the bottom of listBooks below).
--
-- This is load-bearing even without prefetchNextPage: bookshelf_widget.lua's
-- onCoversReady callback calls a full _rebuild() after EVERY batch
-- scheduleCoverFills lands (batches of THUMBNAIL_BATCH_SIZE), and
-- _rebuild() -> getBySource -> listBooks() for the exact same
-- (id, offset, limit) that was just rendered -- 2-4 times over for one
-- 18-24 book page. Without this cache each of those cover-fill-triggered
-- rebuilds re-issued a fresh blocking catalogBooks() request for a page
-- that hadn't changed at all; with it, only the very first fetch touches
-- the network and every cascading rebuild for that same page is served
-- from here.
--
-- Now held in the shared, size-budgeted RAM cache alongside Discover and
-- the Author/Series group buckets below: no TTL, kept until this key is
-- superseded, invalidateNextPageCache() runs (manual refresh), or the
-- shared byte budget evicts it as the least-recently-used entry. Keying
-- by the full (id, offset, limit) -- rather than the single shared slot
-- this used to be -- also means paging back to an earlier page, or
-- switching between two chips pinned side by side, can now be served
-- from RAM too, instead of always re-fetching once a different page
-- would have overwritten the old slot.
local PAGE_PREFIX = "page:"

local function pageKey(id, offset, limit)
    return PAGE_PREFIX .. id .. ":" .. offset .. ":" .. limit
end

local function cacheNextPage(id, offset, limit, records, total)
    Cache.set(pageKey(id, offset, limit), { records = records, total = total })
end

--- consumeNextPageCache(id, offset, limit) -> records, total (or nil).
-- Exact match on (id, offset, limit). Kept for continuity with
-- prefetchNextPage's doc comments elsewhere in this file.
local function consumeNextPageCache(id, offset, limit)
    local c = Cache.get(pageKey(id, offset, limit))
    if not c then return nil end
    return c.records, c.total
end

--- invalidateNextPageCache(id) -- drops every cached page for one source
-- id, or -- with no argument -- every cached book page for every id, so
-- the next listBooks() call re-fetches over the wire. Mirrors
-- invalidateDiscoverCache/invalidateGroupCache above. The scoped form is
-- what the shelf's manual refresh of one chip uses (see
-- _refreshLibrary), so a forced refresh of THAT chip can't be served a
-- page this cache fetched before the refresh, without also nuking every
-- other chip's already-fetched pages.
function M.invalidateNextPageCache(id)
    if id then
        Cache.invalidatePrefix(PAGE_PREFIX .. id .. ":")
    else
        Cache.invalidatePrefix(PAGE_PREFIX)
    end
end

function M.listBooks(id, offset, limit)
    if not M.isAvailable() then return {}, offset or 0 end
    _noteAccess()
    offset = offset or 0
    limit  = (limit and limit > 0) and limit or 24

    -- Gate the version check on whichever cache entry THIS call would
    -- actually read -- see _checkLibraryVersionIfDue's doc comment. Each
    -- id shape below reads from a different bucket (a fixed pre-fetched
    -- batch for discover/similar/want_to_read, a per-page slot for
    -- everything else), so the key has to match that same branch or the
    -- gate would check the wrong thing (e.g. a page-cache key that's
    -- empty because this id is actually "discover", wrongly forcing a
    -- version check even though the real target -- the discover batch --
    -- is warm).
    local decoded_query, decoded_remote_id = M.decodeId(id)
    local version_gate_key
    if decoded_query == "discover" then
        version_gate_key = DISCOVER_PREFIX .. id
    elseif decoded_query == "similar" then
        version_gate_key = SIMILAR_PREFIX .. tostring(decoded_remote_id)
    elseif decoded_query == "want_to_read" then
        version_gate_key = WANT_TO_READ_PREFIX .. id
    else
        version_gate_key = pageKey(id, offset, limit)
    end
    _checkLibraryVersionIfDue(version_gate_key)

    local cached_records, cached_total = consumeNextPageCache(id, offset, limit)
    if cached_records then return cached_records, cached_total end

    -- Batch 5: note the offline condition and keep the auto-connect/
    -- reconnect bookkeeping this always had, but don't return early here
    -- any more -- discover/similar/want_to_read (just below) and the
    -- plain catalog-page path (at the bottom of this function) each now
    -- decide for themselves whether they have a cached fallback worth
    -- serving instead of an empty grid.
    if _isOffline() then
        _offline_miss = true
        _tryAutoConnect()
    end

    -- Discover doesn't come from catalogBooks at all -- it's a fixed,
    -- pre-fetched random batch (see fetchDiscover above), sliced here the
    -- same way the "search" tip and group drilldowns slice their own
    -- fully-hydrated lists. Total is exact: it's just the batch size.
    if (M.decodeId(id)) == "discover" then
        local records = fetchDiscover(id, false)
        local total   = #records
        local stop    = math.min(offset + limit, total)
        local page_slice = {}
        for i = offset + 1, stop do
            page_slice[#page_slice + 1] = records[i]
        end
        return page_slice, total
    end

    -- "similar:<remote_id>" -- one book's "Similar books" server section
    -- (see _buildPillSpecs' Similar pill in bookshelf_widget.lua), not a
    -- catalogBooks() filter -- same fetch-once-then-slice shape as
    -- Discover just above, keyed by remote_id instead of the fixed
    -- "discover" id.
    do
        local query, remote_id = M.decodeId(id)
        if query == "similar" then
            local records = fetchSimilar(remote_id, false)
            local total   = #records
            local stop    = math.min(offset + limit, total)
            local page_slice = {}
            for i = offset + 1, stop do
                page_slice[#page_slice + 1] = records[i]
            end
            return page_slice, total
        end
    end

    -- "want_to_read" -- also not a real catalogBooks() filter (see
    -- fetchWantToRead's doc comment above for why); same fetch-once
    -- (well, walk-once-across-pages), then-slice shape as Discover/Similar
    -- just above.
    if (M.decodeId(id)) == "want_to_read" then
        local records = fetchWantToRead(id, false)
        local total   = #records
        local stop    = math.min(offset + limit, total)
        local page_slice = {}
        for i = offset + 1, stop do
            page_slice[#page_slice + 1] = records[i]
        end
        return page_slice, total
    end

    local page = math.floor(offset / limit) + 1
    local query = M.queryForId(id)
    query.page = page
    query.size = limit

    -- Batch 5: unlike Discover/Similar/Want-to-read above, an arbitrary
    -- (id, offset, limit) catalog page has no "last known batch" to serve
    -- when offline beyond the exact-match check consumeNextPageCache
    -- already did at the very top of this function -- if that missed,
    -- there's genuinely nothing cached for THIS page to fall back to, so
    -- this is still the "empty grid" case BOOKORBIT_INTEGRATION.md's
    -- testing checklist describes, just reached without attempting (and
    -- waiting on) a network call that offline can only fail.
    if _isOffline() then
        return {}, offset
    end

    -- _fetchBooksPage(query) -- the actual network call + record-building
    -- (M.toRecord per item). Returns records, raw body.total, body.hasNext
    -- on success, or nil, err on failure. Kept pure -- no Cache/
    -- _known_total writes -- so it can run either inline or inside a
    -- Trapper:dismissableRunInSubprocess fork below without those writes
    -- ever happening in a forked child (a fork's writes to _known_total,
    -- a plain module-level table, wouldn't make it back to the parent
    -- process -- same reasoning as _resolveWork/dlSettings and
    -- _walkSectionPages/Cache.set above).
    local function _fetchBooksPage(q)
        local body, err = BookOrbit.catalogBooks(q)
        if not body then return nil, err end
        local records = {}
        for _, b in ipairs(body.items or {}) do
            records[#records + 1] = M.toRecord(b)
        end
        return records, tonumber(body.total), body.hasNext
    end

    local records, body_total, has_next
    local ok_t, Trapper = pcall(require, "ui/trapper")
    if ok_t and Trapper and Trapper.isWrapped and Trapper:isWrapped()
            and Trapper.dismissableRunInSubprocess then
        -- Already inside a Trapper coroutine (currently opened only by
        -- BookshelfWidget:_drillInto -- so this protects drilling into a
        -- specific BookOrbit author/series/search result, and, since
        -- listGroups' per-tile sample-book lookup calls back into this
        -- same function, the Authors/Series groups-root's cover-tile
        -- lookups too; chip switching and pagination aren't wrapped yet)
        -- -- run the fetch in a dismissable subprocess so a slow/
        -- unresponsive server shows a cancellable spinner instead of
        -- freezing the reader.
        local completed, result = Trapper:dismissableRunInSubprocess(function()
            local ok, recs, tot_or_err, has = pcall(_fetchBooksPage, query)
            if not ok then return { err = tostring(recs) } end
            if not recs then return { err = tot_or_err } end
            return { records = recs, total = tot_or_err, has_next = has }
        end, _("Loading\xE2\x80\xA6"))
        if not completed then
            -- Cancelled -- same empty-page shape listBooks already
            -- returns for an offline miss or a hard fetch failure, so
            -- callers (grid pagination) need no special-case handling.
            return {}, offset
        end
        result = result or {}
        if not result.records then
            local ok_log, logger = pcall(require, "logger")
            if ok_log then logger.info("Bookshelf BookOrbit: listBooks failed", result.err) end
            return {}, offset
        end
        records, body_total, has_next = result.records, result.total, result.has_next
    else
        -- Not inside a Trapper coroutine (chip switch, pagination, or
        -- Trapper unavailable) -- today's plain blocking call, unchanged.
        local recs, tot_or_err, has = _fetchBooksPage(query)
        if not recs then
            local ok_log, logger = pcall(require, "logger")
            if ok_log then logger.info("Bookshelf BookOrbit: listBooks failed", tot_or_err) end
            return {}, offset
        end
        records, body_total, has_next = recs, tot_or_err, has
    end

    local total = body_total
    if not total then
        -- Fallback for a response that didn't include total: same
        -- "just far enough ahead to keep paging" guess as before, clamped
        -- so it never undercuts a total a later page already proved.
        total = offset + #records + (has_next and limit or 0)
        local prev = _known_total[id]
        if prev and prev > total then total = prev end
        _known_total[id] = total
    end
    cacheNextPage(id, offset, limit, records, total)
    return records, total
end

-- ---------------------------------------------------------------------
-- Grouped browsing (Authors / Series root -> folder-like group tiles)
--
-- A chip pointed at the "All authors"/"All series" leaf (id "authors:" /
-- "series:", built by fetchSectionChoices above) used to fall straight
-- into listBooks with an empty author/series filter -- i.e. every book,
-- flat, no grouping at all, even though the "Browse catalog" menu already
-- lets you drill authors/series like folders. This section gives chips
-- the same folder-like browsing: the root shows one tile per author/
-- series (see listGroups), and BookshelfWidget:_expandBookOrbitGroup
-- drills into a specific one via the existing _drilldown_path machinery
-- -- which then lands back on plain listBooks with that one entry's id,
-- so the drilled-in list is exactly the already-working single-author/
-- single-series chip path.
--
-- catalogSection() has no caller-controllable page size (unlike
-- catalogBooks, which takes size=), so it can't be mapped onto the grid's
-- offset/limit window the way listBooks() maps onto catalogBooks() --
-- the server's own fixed page size and the grid's view size (3/6/9
-- depending on layout) would drift apart. Authors/series lists are just
-- names + counts (no per-entry paging concern), so instead this caches a
-- flattened list per section (held in the shared cache, same as Discover
-- above) and slices offset/limit out of it locally.
--
-- The flattened list is built LAZILY, though: fetchSectionBucket only
-- walks as many catalogSection() pages as needed to cover the CURRENT
-- offset+limit window, resuming from where a prior call left off rather
-- than re-walking from page 1. A first render (offset=0, one shelf's
-- worth of tiles) typically costs a single round trip; scrolling further
-- resumes the walk for just the extra entries that page needs. This used
-- to walk every page up to GROUP_FETCH_PAGE_CAP unconditionally on the
-- very first call -- up to 40 synchronous, un-yielded catalogSection()
-- round trips back to back, from the render path (_rebuild ->
-- _fetchChipItems -> Repo.getBySource), which could freeze the reader for
-- the sum of all of them on a library with many authors/series. Bookshelf's
-- own plain-text catalog browser (bookshelf_bookorbit_catalog.lua) and the
-- official plugin both page lazily, one screen at a time -- this now does
-- the same instead of being the odd one out in the same codebase.
-- ---------------------------------------------------------------------

-- section -> { entries, first_books, next_page, exhausted } bucket, held
-- in the shared bookshelf_bookorbit_cache module the same way Discover
-- and book pages are above -- no TTL; a bucket lives until
-- invalidateGroupCache() (manual refresh) drops it or the shared byte
-- budget evicts it as the least-recently-used entry.
local GROUP_PREFIX = "group:"
-- Safety cap on how many catalogSection() pages fetchSectionBucket will
-- ever walk for one section (across however many calls it takes to get
-- there, since the walk now resumes incrementally rather than happening
-- in one shot). Generous for any realistic author/series list; bounded so
-- a server bug (hasNext always true) can't loop forever.
local GROUP_FETCH_PAGE_CAP = 40

--- True if `id` is a "browse as folders" root -- either the ungrouped
-- root of Authors/Series (what fetchSectionChoices labels "All
-- <section>": "authors:"/"series:" with no specific entry picked, a
-- meaning that id has had since this function was introduced), or one
-- of the separate Libraries/Collections/SmartScopes "-groups" ids from
-- GROUPED_SECTION_QUERY above (their OWN "All <section>" id is
-- deliberately left alone -- see that table's comment). Any other id
-- (a specific entry, or a non-groupable root like "recent"/"all"/
-- "discover") is unaffected and keeps going through the flat
-- listBooks path.
function M.isGroupRoot(id)
    local query, rest = M.decodeId(id)
    if not (rest == nil or rest == "") then return false end
    return query == "authors" or query == "series" or GROUPED_SECTION_QUERY[query] ~= nil
end

--- groupSection(id) -> the real catalogSection()/catalogBooks() section
-- name to walk for a group-root id (only meaningful when
-- isGroupRoot(id) is true). Authors/Series ids already carry their real
-- section name as the query token, so this only needs to translate the
-- "-groups" tokens back to their underlying section.
function M.groupSection(id)
    local query = M.decodeId(id)
    return GROUPED_SECTION_QUERY[query] or query
end

-- fetchSectionBucket(section, needed) -> the cache bucket for `section`,
-- walking just enough catalogSection() pages to cover `needed` entries
-- (typically the caller's offset+limit) if the cached bucket doesn't
-- already have that many. Holds the flat entries list AND (see
-- listGroups) each entry's resolved first_book, keyed by entry id -- a
-- single shared bucket/TTL so a section refresh naturally drops both
-- together.
--
-- Resumable: bucket.next_page/exhausted persist across calls, so paging
-- forward through a chip extends the same walk instead of restarting it
-- -- each individual call only pays for the NEW pages that call's window
-- needs, not the whole section. A bucket now lives until
-- invalidateGroupCache() drops it or the shared cache evicts it for
-- space, rather than expiring on a fixed timer.
-- givenNameKey(entry) -> lowercased "given name" sort key for an Authors
-- group-root tile, e.g. "Iain M. Banks" -> "iain m. banks" (the surname
-- stays in the key too -- AuthorName.givenOf only strips the trailing
-- surname token(s), so "Iain M. Banks" keeps "Iain M." -- but since every
-- entry here is compared the same way, tiles still land in first-name
-- order; a shared first name then falls through to the rest of the
-- string, which reads naturally). Falls back to the raw title (still
-- alphabetical, just surname-first) if AuthorName didn't load or the
-- entry has no usable title, so a missing module degrades this sort
-- rather than erroring the whole section.
local function givenNameKey(entry)
    local title = entry and entry.title
    if type(title) ~= "string" or title == "" then return "" end
    if ok_author_name and AuthorName and AuthorName.givenOf then
        local given = AuthorName.givenOf(title)
        if given and given ~= "" then return given:lower() end
    end
    return title:lower()
end

-- sortAuthorEntries(entries) -- orders the Authors group-root's tiles
-- alphabetically by first/given name (catalogSection("authors") returns
-- entries in whatever order the server's database query happens to
-- yield -- effectively unordered from the user's point of view -- and
-- unlike catalogBooks() there's no `sort=` param to ask the server to do
-- this instead; see the module doc comment above fetchSectionBucket).
-- Ties (two authors sharing a first name) break on the full title so the
-- order stays deterministic across repeated sorts of the same list.
--
-- Called every time fetchSectionBucket appends newly-walked pages (see
-- below), not just once: the bucket is built up LAZILY, so a tile at
-- position N on a page the user already saw can, in principle, move once
-- more entries load in from a later page. In practice this only bites
-- once, right as the walk that spans the visited page's boundary
-- happens -- once `bucket.exhausted` (or the walk has covered every
-- position up to the highest offset the user has scrolled to), the order
-- is stable. No worse than the "report one page's worth more than we've
-- fetched" total-count fuzziness fetchSectionBucket's caller already
-- lives with for the same reason.
local function sortAuthorEntries(entries)
    table.sort(entries, function(a, b)
        local ka, kb = givenNameKey(a), givenNameKey(b)
        if ka ~= kb then return ka < kb end
        return (a.title or "") < (b.title or "")
    end)
end

-- Forward declaration: fireCoversReady is defined properly further down
-- (right next to M.onCoversReady, which is where the callback it fires
-- actually belongs), but continueSectionWalk below -- which lives before
-- that point in the file so fetchSectionBucket can call it -- needs to
-- reach it too. Declaring the local here and filling it in later (with
-- a plain `fireCoversReady = function(...)`, no `local`) lets both ends
-- of the file share the one upvalue instead of duplicating the
-- _covers_ready_cb plumbing.
local fireCoversReady

-- continueSectionWalk(section) -- resumes fetchSectionBucket's walk for
-- `section` IN THE BACKGROUND, one server page per tick, until the
-- bucket is exhausted (or hits GROUP_FETCH_PAGE_CAP / a fetch error).
--
-- Only meaningful for "authors": that's the one group-root section
-- fetchSectionBucket re-sorts client-side (sortAuthorEntries above)
-- because catalogSection() has no server-side equivalent of
-- catalogBooks()'s `sort=`. That re-sort is exactly why a page sliced
-- from a PARTIAL walk can be wrong in a way "series"/"libraries"/
-- "collections"/"smart-scopes" never are: those trust the server's own
-- (stable, if arbitrary) ordering, so whatever's been walked so far is
-- already a correct prefix of the final order. Authors don't have that
-- guarantee -- the entries that truly belong at offset..offset+limit in
-- alphabetical-by-given-name order may still be sitting unfetched on a
-- later server page, in whatever order the server's own query happens
-- to return them. fetchSectionBucket's `needed`-only walk satisfies the
-- CURRENT render fast, but leaves that gap open until something walks
-- the rest.
--
-- This fills the rest in without blocking the render that triggered it:
-- one page per scheduled tick, re-sorting and firing the same
-- onCoversReady repaint hook scheduleCoverFills uses (see
-- fireCoversReady) after each page lands. So a page that rendered with
-- the wrong entries (or the wrong order) while the walk was still
-- catching up corrects itself in place a moment later -- the grid just
-- repaints -- instead of only fixing itself the next time the user
-- happens to revisit that page after the walk finished some other way
-- (e.g. by scrolling to the end and back, which is the workaround this
-- was papering over before).
-- _group_epoch(section) is a generation counter bumped by
-- invalidateGroupCache() every time a section's bucket is dropped/
-- replaced (e.g. pull-to-refresh). continueSectionWalk and
-- fetchSectionBucket's walk both snapshot the epoch before doing any
-- (possibly-blocking, possibly-scheduled-later) network I/O, then check
-- it again once the response lands. A mismatch means the bucket this
-- walk started against no longer exists -- some other refresh replaced
-- it while the request was in flight -- so the response is discarded
-- outright instead of being merged: merging would append entries and
-- advance next_page relative to the OLD bucket's bookkeeping, then
-- write that stale, wrongly-numbered bucket back into the cache,
-- clobbering whatever fresh walk the refresh had just started. This is
-- the root cause of folders permanently losing their first-book/cover
-- resolution after a pull-to-refresh races a background walk.
local _group_epoch = {}
local function _sectionEpoch(section)
    return _group_epoch[section] or 0
end
local function _bumpSectionEpoch(section)
    _group_epoch[section] = (_group_epoch[section] or 0) + 1
end

local _group_walking = {}

-- BUGFIX (duplicate Authors/Series tiles): _bucket_fetching guards
-- fetchSectionBucket's OWN network walk (further down this file) the
-- same way _group_walking above already guards continueSectionWalk's
-- background one -- see that function's use below for the full story.
local _bucket_fetching = {}

-- appendUniqueEntries(bucket, new_entries) -- appends `new_entries` onto
-- bucket.entries, skipping any entry whose id has already been added to
-- this bucket. Tracks seen ids in bucket._seen_ids, built lazily from
-- whatever's already in bucket.entries the first time this runs against
-- a given bucket, so fetchSectionBucket's own merge and
-- continueSectionWalk's background merge share one dedupe set instead of
-- each re-deriving it from scratch on every call.
--
-- This is a defense-in-depth measure, not the primary fix: the actual
-- bug was that fetchSectionBucket had no equivalent of _group_walking,
-- so two overlapping calls for the same section (routine once the
-- server's authors walk got slow enough for a second render to land
-- mid-walk -- see _bucket_fetching's use below) could each independently
-- re-fetch and re-append the same catalogSection() page into the same
-- shared bucket.entries table, producing exact duplicate tiles. Adding
-- the _bucket_fetching guard closes that race directly; this dedupe
-- sits alongside it so a duplicate can never reach the rendered grid
-- even if some other path ever lets two walks race against the same
-- bucket again. Entries lacking an id (shouldn't happen against a
-- well-behaved server, but cheap to handle) are always appended.
local function appendUniqueEntries(bucket, new_entries)
    local seen = bucket._seen_ids
    if not seen then
        seen = {}
        for _, e in ipairs(bucket.entries) do
            if e and e.id ~= nil then seen[e.id] = true end
        end
        bucket._seen_ids = seen
    end
    for _, entry in ipairs(new_entries or {}) do
        local id = entry and entry.id
        if id == nil or not seen[id] then
            bucket.entries[#bucket.entries + 1] = entry
            if id ~= nil then seen[id] = true end
        end
    end
end

local function continueSectionWalk(section)
    if section ~= "authors" then return end
    if _group_walking[section] then return end
    local ok_ui, UIManager = pcall(require, "ui/uimanager")
    if not (ok_ui and UIManager) then return end
    _group_walking[section] = true
    local key = GROUP_PREFIX .. section
    -- Snapshot the epoch for the ENTIRE walk, not just the first page --
    -- a stale walk from before a refresh must not resume itself either,
    -- it must die on its very next tick.
    local epoch = _sectionEpoch(section)
    local function step()
        if _sectionEpoch(section) ~= epoch then
            -- Section was invalidated since this walk started (or since
            -- its last tick) -- abort instead of resuming against a
            -- bucket this walk no longer owns.
            _group_walking[section] = nil
            return
        end
        local bucket = Cache.get(key)
        if not bucket or bucket.exhausted or bucket.next_page > GROUP_FETCH_PAGE_CAP then
            _group_walking[section] = nil
            return
        end
        local page_requested = bucket.next_page
        local body, err = BookOrbit.catalogSection(section, { page = page_requested })
        if _sectionEpoch(section) ~= epoch then
            -- A refresh invalidated (and possibly already re-walked)
            -- this section while `catalogSection` was in flight. `body`
            -- describes page `page_requested` of the OLD bucket -- merge
            -- it into whatever bucket exists under `key` now and its
            -- page bookkeeping would be meaningless (duplicating or
            -- skipping pages of the NEW walk). Drop it on the floor.
            _group_walking[section] = nil
            return
        end
        if not body then
            local ok_log, logger = pcall(require, "logger")
            if ok_log then
                logger.info("Bookshelf BookOrbit: continueSectionWalk fetch failed", section, err)
            end
            bucket.exhausted = true
            Cache.set(key, bucket)
            _group_walking[section] = nil
            return
        end
        appendUniqueEntries(bucket, body.items)
        bucket.next_page = page_requested + 1
        if not body.hasNext then bucket.exhausted = true end
        sortAuthorEntries(bucket.entries)
        Cache.set(key, bucket)
        -- Same id shape the grid's currently-visible chip compares
        -- against (see fireCoversReady's own doc comment below) -- a
        -- repaint only actually happens if "authors:" is what's on
        -- screen right now.
        fireCoversReady(M.encodeId(section, ""))
        if bucket.exhausted then
            _group_walking[section] = nil
        else
            UIManager:scheduleIn(0.05, step)
        end
    end
    UIManager:scheduleIn(0.05, step)
end

--- _walkSectionPages(section, next_page, exhausted, needed, have) -- the
-- actual network walk: pages catalogSection() forward from `next_page`
-- until either `needed` entries are covered, the section is exhausted, or
-- GROUP_FETCH_PAGE_CAP is hit. Returns a plain { entries, next_page,
-- exhausted, fetched_more } table instead of mutating a bucket directly,
-- so fetchSectionBucket below can run this either inline or inside a
-- Trapper:dismissableRunInSubprocess fork without duplicating the walk
-- logic for both -- the fork only gets plain data in and a plain table
-- back, never a reference to the shared cache bucket itself.
local function _walkSectionPages(section, next_page, exhausted, needed, have)
    local entries, fetched_more = {}, false
    while (not exhausted) and (have + #entries) < needed
            and next_page <= GROUP_FETCH_PAGE_CAP do
        local body, err = BookOrbit.catalogSection(section, { page = next_page })
        if not body then
            local ok_log, logger = pcall(require, "logger")
            if ok_log then
                logger.info("Bookshelf BookOrbit: listGroups section fetch failed", section, err)
            end
            -- Mark exhausted (rather than leaving the bucket to retry the
            -- same failing page on every render) so a persistent server
            -- error doesn't retry the walk on every single call -- same
            -- "serve what we've got" trade-off fetchDiscover makes on
            -- failure, just without a prior-batch fallback since there's
            -- nothing to fall back to on the very first page.
            exhausted = true
            break
        end
        for _, entry in ipairs(body.items or {}) do
            entries[#entries + 1] = entry
        end
        fetched_more = true
        next_page = next_page + 1
        if not body.hasNext then exhausted = true end
    end
    return { entries = entries, next_page = next_page, exhausted = exhausted, fetched_more = fetched_more }
end

local function fetchSectionBucket(section, needed)
    needed = needed or 0
    local key = GROUP_PREFIX .. section
    local bucket = Cache.get(key)
    if not bucket then
        bucket = { entries = {}, first_books = {}, next_page = 1, exhausted = false }
    end
    -- Batch 5: offline -- skip the network walk attempt entirely (it can
    -- only fail) and fall straight through to returning whatever this
    -- bucket already has, even if that's short of `needed` or empty. This
    -- is what lets listGroups (which no longer short-circuits on offline
    -- itself -- see that function below) serve a previously-cached
    -- Authors/Series/Libraries/etc. page instead of an empty grid.
    if _isOffline() then
        return bucket
    end
    -- Snapshot before the walk (which may block on network I/O, or fork
    -- into a Trapper subprocess that yields for a while) so the merge
    -- below can tell whether a refresh replaced this section's bucket
    -- while the walk was in flight -- see _group_epoch's doc comment
    -- above continueSectionWalk.
    local epoch = _sectionEpoch(section)
    -- BUGFIX (duplicate Authors/Series tiles after a slow/paginated
    -- catalogSection walk): this function is called synchronously from
    -- every render that touches this section's group root (listGroups
    -- below), and the walk it kicks off can yield control back to
    -- KOReader's UI loop -- either a genuinely blocking network call, or
    -- (more commonly) the Trapper dismissable-subprocess fork just
    -- below. continueSectionWalk has always guarded its own background
    -- walk with _group_walking; this function, which does the WALK a
    -- render actually waits on, never had the equivalent guard. A second
    -- render firing while the first call's walk was still in flight (a
    -- page turn, a cover-fill repaint, a scroll -- all routine) would
    -- see the SAME bucket.next_page, since the first call hadn't merged
    -- its result yet, and independently re-walk and re-append the same
    -- page(s) into the same shared bucket.entries table -- producing
    -- exact duplicate tiles once both merges landed. Always possible in
    -- principle; only reliably reachable once the server's authors walk
    -- got slow/long enough (bigger library, more pages) for a second
    -- render to realistically land mid-walk.
    --
    -- Fixed the same way continueSectionWalk already protects itself:
    -- a second call for a section whose walk is already in flight skips
    -- starting its own overlapping walk and just returns whatever the
    -- bucket already holds -- same "serve what we've got" behaviour this
    -- function already falls back to on offline/cancel. The in-flight
    -- call's own merge (or the background continueSectionWalk once it
    -- takes over) fills the rest in on a later render.
    if (not _bucket_fetching[section]) and (not bucket.exhausted) and #bucket.entries < needed then
        _bucket_fetching[section] = true
        local result
        local ok_t, Trapper = pcall(require, "ui/trapper")
        if ok_t and Trapper and Trapper.isWrapped and Trapper:isWrapped()
                and Trapper.dismissableRunInSubprocess then
            -- Already inside a Trapper coroutine (opened by whichever
            -- caller triggered this fetch -- e.g. BookshelfWidget:_drillInto
            -- drilling into the Authors/Series "browse as folders" root)
            -- -- run the walk in a dismissable subprocess so a slow/
            -- unresponsive server shows a cancellable spinner instead of
            -- freezing the reader. dismissableRunInSubprocess behaves
            -- synchronously from THIS coroutine's point of view (it
            -- yields internally, but only resumes here once the fork
            -- finishes or is cancelled), so fetchSectionBucket can still
            -- just `return bucket` normally below -- no callback-style
            -- restructuring needed anywhere in this function.
            local completed, r = Trapper:dismissableRunInSubprocess(function()
                local ok, res = pcall(_walkSectionPages, section, bucket.next_page,
                    bucket.exhausted, needed, #bucket.entries)
                if not ok then
                    return { entries = {}, next_page = bucket.next_page,
                             exhausted = bucket.exhausted, fetched_more = false }
                end
                return res
            end, _("Loading\xE2\x80\xA6"))
            if completed then result = r end
            -- On cancel (completed == false): result stays nil, bucket is
            -- returned exactly as it was -- listGroups just renders
            -- however many entries the bucket already has (possibly
            -- zero, on a first-ever open), same as any other short page;
            -- the walk resumes from where it left off on the next call.
        else
            -- Not inside a Trapper coroutine (e.g. a proactive warm-up
            -- call from warmAuthorsSort, or Trapper unavailable) --
            -- today's plain blocking walk, unchanged.
            result = _walkSectionPages(section, bucket.next_page, bucket.exhausted,
                needed, #bucket.entries)
        end
        if result then
            if _sectionEpoch(section) ~= epoch then
                -- invalidateGroupCache() dropped/replaced this section's
                -- bucket while the (possibly-blocking) walk above was in
                -- flight. `result` was walked against the OLD bucket's
                -- next_page/exhausted state, which is meaningless applied
                -- to whatever's under `key` now -- merging it in would
                -- duplicate or skip pages of the fresh walk. Discard the
                -- result and hand the caller whatever the fresh bucket
                -- (started by the refresh, or just empty/never-fetched)
                -- currently holds instead; the next call keeps walking
                -- that one forward normally.
                bucket = Cache.get(key) or bucket
            else
                appendUniqueEntries(bucket, result.entries)
                bucket.next_page = result.next_page
                bucket.exhausted = result.exhausted
                -- Authors get a client-side alphabetical-by-first-name re-sort
                -- (see sortAuthorEntries above) since the server has no
                -- equivalent of catalogBooks()'s `sort=` for this endpoint.
                -- Only re-sort when this call actually walked new pages -- an
                -- already-sorted, unchanged bucket doesn't need the
                -- O(n log n) pass again on every render.
                if section == "authors" and result.fetched_more then
                    sortAuthorEntries(bucket.entries)
                end
                -- Re-set (rather than relying on the reference Cache.get
                -- returned) so the cache's byte accounting picks up whatever
                -- this walk just appended to the bucket's entries -- and so a
                -- first-ever fetch for this section gets stored at all.
                Cache.set(key, bucket)
            end
        end
        -- Release the guard set above -- whether the walk merged
        -- normally, got discarded on an epoch mismatch, or (Trapper
        -- branch) was cancelled by the user. Any of those leaves this
        -- section free for the NEXT call to walk again if it still
        -- needs to; only genuinely concurrent calls against this same
        -- in-flight walk are what the guard exists to block.
        _bucket_fetching[section] = nil
    end
    -- The loop above only walked far enough to cover THIS call's window
    -- (`needed`) -- fine for "series"/"libraries"/"collections"/
    -- "smart-scopes", which trust server order, but not for "authors",
    -- whose client-side re-sort means a page beyond what's been walked
    -- so far can still be wrong (see continueSectionWalk's doc comment
    -- above). Kick off (or no-op into, if one's already running) the
    -- background continuation so the rest of the section fills in on
    -- its own, repainting whichever page is on screen if/when the sort
    -- order settles further -- without holding up THIS render for it.
    if section == "authors" and not bucket.exhausted then
        continueSectionWalk(section)
    end
    return bucket
end

-- warmAuthorsSort() -- proactively seeds + kicks off the Authors
-- group-root's background sort walk (fetchSectionBucket ->
-- continueSectionWalk above), the same walk that would otherwise only
-- start the first time a chip actually opens "All Authors". Called from
-- BookshelfWidget's init for anyone with a chip pinned to that
-- group-root, so the sort has usually finished converging by the time
-- they tap it, instead of starting cold on first open.
--
-- Metadata-only (page listings, no cover downloads) -- much cheaper than
-- the "prewarm_chip_cache_bookorbit" toggle, so this isn't gated behind
-- it; it's cheap and safe to fire unconditionally for anyone who
-- actually has the chip.
--
-- Once per session: repeat calls (e.g. a re-shown widget instance) are a
-- no-op once the first has fired, since fetchSectionBucket/
-- continueSectionWalk already take over from there (cached bucket +
-- their own dedup). invalidateGroupCache resets the flag so a manual
-- refresh gets a fresh proactive warm too.
local _authors_warm_started = false
function M.warmAuthorsSort()
    if _authors_warm_started then return end
    if not M.isAvailable() then return end
    _authors_warm_started = true
    -- Small `needed` -- just enough to seed the bucket and let
    -- fetchSectionBucket's own not-exhausted check hand off to
    -- continueSectionWalk for the rest. No caller is waiting on a
    -- render here, so the exact size doesn't matter.
    fetchSectionBucket("authors", 24)
end

--- invalidateGroupCache(section) -- drops one section's cached author/
-- series-style list (and its resolved first-book previews), AND the
-- decoded cover bbs GroupCoverCache is holding for just that section, so
-- the next listGroups(section) call re-walks the server and re-decodes
-- covers from scratch. Both are dropped together so a newly added/
-- changed entry can never show a stale cover left over from before the
-- refresh. With no argument, drops every section instead (e.g. Settings'
-- group-cover-toggle callback, which genuinely affects every section at
-- once). The scoped form is what the shelf's manual refresh of one
-- group-root chip uses -- see _refreshLibrary; refreshing "Authors" has
-- no business re-walking "Series" too.
function M.invalidateGroupCache(section)
    if section then
        if section == "authors" then
            _authors_warm_started = false
            -- Drop the walking flag too (not just bump the epoch) so a
            -- fresh continueSectionWalk can start immediately -- without
            -- this, a walk mid-flight when the refresh landed would
            -- leave _group_walking[section] set until its next tick
            -- notices the epoch mismatch and clears it itself, briefly
            -- blocking the new walk from starting via fetchSectionBucket.
            _group_walking[section] = nil
        end
        -- Deliberately NOT clearing _bucket_fetching[section] here, unlike
        -- _group_walking above: that guard exists specifically to stop two
        -- overlapping fetchSectionBucket() walks from racing against the
        -- same in-flight HTTP round trip(s) (see its use in
        -- fetchSectionBucket). If a walk is genuinely still in flight when
        -- a refresh lands, it already self-clears the flag the moment its
        -- own result comes back (whether merged or discarded on epoch
        -- mismatch) -- clearing it early here would let a brand-new call
        -- start a SECOND overlapping walk while the stale one is still
        -- pending, which is the exact race this guard exists to prevent.
        -- Worst case, one render right after a refresh briefly serves an
        -- empty/short bucket until the stale walk finishes and releases
        -- the flag a moment later.
        -- Bump BEFORE dropping the cache entry: any walk step/merge
        -- already past its epoch check but not yet at its Cache.set is
        -- vanishingly unlikely given Lua's cooperative scheduling, but
        -- ordering it this way costs nothing and closes even that gap.
        _bumpSectionEpoch(section)
        Cache.invalidate(GROUP_PREFIX .. section)
        GroupCoverCache:clearPrefix(section .. ":")
        -- BUGFIX (authors covers never recovering from refresh/restart):
        -- listGroups' per-tile sample-book lookup calls M.listBooks(gid,
        -- 0, 1) with gid = "<section>:<entry id>" (e.g.
        -- "authors:Adrian Tchaikovsky") -- a DIFFERENT id from this
        -- chip's own root id ("authors:", empty rest), and listBooks
        -- checks its own disk-persistent, no-TTL page cache
        -- (consumeNextPageCache, keyed "page:<id>:<offset>:<limit>")
        -- BEFORE ever calling catalogBooks. Dropping only GROUP_PREFIX
        -- above clears the entries list/first_books bucket, forcing a
        -- fresh listBooks(gid,0,1) call per tile -- but if THAT call's
        -- own page-cache slot already holds a cached empty result (e.g.
        -- from before a since-fixed query bug), it short-circuits
        -- straight back to that stale empty answer without ever
        -- touching the network, and no ordinary refresh clears it since
        -- invalidateNextPageCache(id) above (in bookshelf_widget.lua's
        -- _refreshLibrary) only scopes to the chip's own root id, not
        -- every "<section>:<entry>" id the tiles fan out into. Clear
        -- every page-cache slot under this section's prefix too, so a
        -- section refresh actually forces every tile's sample-book
        -- lookup back out to the network, not just the entries walk.
        Cache.invalidatePrefix(PAGE_PREFIX .. section .. ":")
    else
        _authors_warm_started = false
        for s in pairs(_group_walking) do _group_walking[s] = nil end
        -- Make sure "authors" has an epoch entry even if no walk has
        -- ever run yet (nothing has called _bumpSectionEpoch for it, so
        -- _sectionEpoch would still read the implicit 0 default) --
        -- otherwise the loop below would have nothing to bump for it and
        -- a walk kicked off later would snapshot the same 0 a stale one
        -- might still be about to compare against.
        if _group_epoch.authors == nil then _group_epoch.authors = 0 end
        for s in pairs(_group_epoch) do _bumpSectionEpoch(s) end
        Cache.invalidatePrefix(GROUP_PREFIX)
        -- Same reasoning as the scoped branch above: dropping every
        -- section's entries bucket still leaves every tile's own
        -- "<section>:<entry>" page-cache slot untouched. Drop the whole
        -- page cache too when invalidating everything.
        Cache.invalidatePrefix(PAGE_PREFIX)
        GroupCoverCache:clear()
    end
end

--- listGroups(section, offset, limit, opts) -> records, total
-- section is a real catalogSection() name -- "authors", "series",
-- "libraries", "collections", or "smart-scopes" (callers get here via
-- isGroupRoot + groupSection above, which resolve any of those
-- section's group-root ids down to this real name). Each record is a
-- folder-like tile (kind = "bookorbit_group") shaped for FolderStack:
-- .label, .count, .first_book (a single hydrated sample book for the
-- tile's preview image -- its cover fills in asynchronously via
-- scheduleCoverFills below, same as every other BookOrbit cover), and
-- .source_id -- the id to drill into, in exactly the single-entry form
-- M.queryForId already understands (e.g. "authors:42").
--
-- opts.light_only tells this call it's a metadata-only scan (the
-- contract BookshelfWidget:_jumpToLetterPrefix's bulk sort-key scan
-- uses): skip the per-tile sample-book/cover resolution below
-- entirely, regardless of the "Show covers on Author/Series tiles"
-- setting. Note this is opts.light_only SPECIFICALLY, not
-- opts.lazy_cover -- see the doc comment on show_covers below for why
-- that distinction matters here.
function M.listGroups(section, offset, limit, opts)
    if not M.isAvailable() then return {}, offset or 0 end
    _noteAccess()
    -- Gate on this section's own bucket -- see _checkLibraryVersionIfDue's
    -- doc comment. A section already resident (Authors revisited within
    -- the same session) renders straight from it with no network call;
    -- an empty/never-fetched section still gets checked as before.
    _checkLibraryVersionIfDue(GROUP_PREFIX .. section)
    -- Batch 5: keep the auto-connect/reconnect bookkeeping, but no longer
    -- return {} here -- fetchSectionBucket (below) skips its own network
    -- walk when offline and serves whatever's already in the bucket
    -- instead, same reasoning as listBooks' Discover/Similar/Want-to-read
    -- paths above.
    if _isOffline() then
        _offline_miss = true
        _tryAutoConnect()
    end
    offset = offset or 0
    limit  = (limit and limit > 0) and limit or 24
    local bucket = fetchSectionBucket(section, offset + limit)
    local entries = bucket.entries
    -- Once the walk has exhausted the section (hit the last server page,
    -- or gave up after an error), #entries IS the true total. Until then,
    -- we've deliberately only walked enough pages to cover this window,
    -- so report one page's worth more than we've fetched -- enough for
    -- the grid to keep offering a "next" page. Visiting that next page
    -- resumes the walk above and the count firms up from there (or the
    -- walk finishes and the exact total takes over).
    local total = bucket.exhausted and #entries or (#entries + limit)
    local records = {}
    -- Preview covers for this page's tiles are filled ASYNC via
    -- scheduleCoverFills below, not by calling the blocking M.coverBB()
    -- here -- coverBB() downloads AND decodes synchronously, so calling
    -- it once per tile in this loop meant every render of a folder-tile
    -- page (author/series browsing) sat behind up to a page's worth of
    -- JPEG decodes/downloads, back to back, on the render path -- exactly
    -- the "device feels busy right as you turn the page" stall
    -- scheduleCoverFills exists to avoid for the flat listBooks/
    -- getBySource path (see that function's doc comment), just never
    -- applied here. group_first_books collects this page's sample books
    -- (metadata only, no cover attached yet) so they can be handed to
    -- scheduleCoverFills together, the same way getBySource hands it a
    -- flat page: filled in place, off the render path, in small batches,
    -- firing onCoversReady (which the grid widget already listens for,
    -- see its init) to repaint once a batch lands.
    --
    -- Settings > BookOrbit > "Show covers on nested sections" (submenu
    -- with one toggle per section -- Authors, Series, Libraries,
    -- Collections, Smart Scopes -- see M.groupCoversEnabled): first_book
    -- exists ONLY to supply a tile's preview cover -- nothing else reads
    -- it for a bookorbit_group record (FolderStack/shelf_row only touch
    -- .cover_bb/.filepath off it, and shelf_row's .filepath read is for
    -- the unrelated local kind=="folder" case). So when the setting is
    -- off for THIS section, skip resolving it at all rather than just
    -- discarding the cover: that also skips the M.listBooks(gid, 0, 1)
    -- catalogBooks round trip below, which is the actual per-tile
    -- network cost (the GroupCoverCache decode is comparatively cheap).
    -- FolderStack already renders a tile with no first_book correctly
    -- -- it's the same fallback path a genuinely empty local folder uses
    -- (cardboard card + "?" placeholder spine + label + count badge), so
    -- there's no rendering change needed, only whether this loop bothers.
    --
    -- BUGFIX (30+ second "Go to letter" with group covers enabled):
    -- BookshelfWidget:_jumpToLetterPrefix needs the FULL sorted list just
    -- to find which page a letter falls on, so on the Authors/Series
    -- "All ..." root it calls Repo.getBySource with offset=0 and a
    -- BIG_LIMIT (up to 10000) plus { lazy_cover = true, light_only =
    -- true }. But Repo.getBySource's group-root branch dropped those
    -- opts on the floor and called this function with no 4th argument
    -- at all, and show_covers below used to consult ONLY the
    -- per-section setting -- so with that setting on, a single letter-
    -- jump synchronously fired one blocking M.listBooks(gid, 0, 1)
    -- catalogBooks() round trip PER ENTRY across the entire (thousands-
    -- large) window the jump requested, not just the handful of tiles
    -- actually on screen. That's the 30+ second stall: hundreds of
    -- authors x one blocking HTTP request each, back to back, before the
    -- letter search could even start. With the setting off this whole
    -- block was already skipped, which is why disabling covers "fixed"
    -- it.
    --
    -- Gate on opts.light_only ONLY, not opts.lazy_cover: light_only is
    -- set exclusively by _jumpToLetterPrefix's metadata-only bulk scan
    -- (the one actually responsible for the slowness above).
    -- lazy_cover, by contrast, is set unconditionally on EVERY ordinary
    -- chip render (_fetchChipItems always sets `fetch_opts = {
    -- lazy_cover = true }`) -- there it just means "don't do a blocking
    -- decode inline, scheduleCoverFills will fill it asynchronously
    -- instead", not "skip cover resolution altogether". An earlier
    -- version of this fix keyed off `light_only or lazy_cover`, which
    -- meant lazy_cover being true on literally every normal render made
    -- this branch treat EVERY render as metadata-only and never resolve
    -- an author's sample-book/cover at all -- Authors folder tiles lost
    -- their covers entirely, regardless of the settings toggle. Only
    -- light_only actually distinguishes "just scanning sort keys, don't
    -- bother" from "this is a real render, please fetch covers".
    local skip_covers = opts and opts.light_only
    local show_covers = (not skip_covers) and M.groupCoversEnabled(section)
    local group_first_books = {}
    for i = offset + 1, math.min(offset + limit, #entries) do
        local entry = entries[i]
        -- Some BookOrbit servers return "series" section entries with an
        -- OPAQUE/compound .id -- observed in the wild as literally
        -- "series:<numericId>" (e.g. "series:2139") -- rather than a bare
        -- series name or a bare numeric id. bookshelf_bookorbit_catalog.lua's
        -- paramsForEntry already works around exactly this by preferring
        -- entry.seriesId (a separate, genuinely-numeric field the API doc
        -- promises: "{{id, title, count, seriesId, ...}}") over entry.id
        -- for "series" specifically. Follow the same preference here:
        -- blindly using entry.id would double-encode into something like
        -- "series:series:2139" (M.encodeId prefixing a value that's
        -- ALREADY prefixed), which M.queryForId's "series" branch then
        -- decodes back into a `series=series:2139` NAME filter -- one
        -- that can never match a real series. That's what made every
        -- series' sample-book lookup (and, worse, actually drilling into
        -- the series folder itself, since this same gid becomes the
        -- tile's source_id) silently come back empty -- not a caching or
        -- timing issue at all, a genuinely wrong query on every attempt.
        local raw_id = (section == "series" and entry.seriesId) or entry.id
        local gid = M.encodeId(section, raw_id)
        local first_book
        if show_covers then
            -- Cache hit: this entry's sample book METADATA was already
            -- resolved earlier (a prior page view, or a previous visit to
            -- this chip) -- skip the catalogBooks round trip. `false` is a
            -- cached "no book" result, distinct from "not yet looked up"
            -- (nil), so a genuinely empty author isn't retried every render
            -- either.
            --
            -- This bucket holds first_book METADATA only, never a decoded
            -- cover_bb -- that lives separately in GroupCoverCache, keyed by
            -- gid (see below), so a section refresh (invalidateGroupCache)
            -- can drop stale covers independently of whether the metadata
            -- walk itself needs re-fetching, and so this cache's byte
            -- accounting (bookshelf_bookorbit_cache.lua's approxSize) never
            -- has to reason about blitbuffer memory.
            local cached_fb = bucket.first_books[entry.id]
            if cached_fb == nil then
                local sample = M.listBooks(gid, 0, 1)
                if (not sample or not sample[1]) and entry.count and entry.count > 0 then
                    -- entry.count says this author/series genuinely HAS
                    -- books, so an empty result here is far more likely a
                    -- transient fetch failure (timeout, momentary server
                    -- error, refresh-induced request pile-up) than a real
                    -- "no books" case. Caching `false` in that situation
                    -- would permanently blank this tile's cover for the
                    -- rest of the bucket's lifetime -- no later render
                    -- retries it, since `cached_fb == nil` is what gates
                    -- the retry above, and a false result short-circuits
                    -- past that check forever. Leave it uncached (nil)
                    -- instead, so a later render (revisit, next page-turn
                    -- through this tile, or just the next _rebuild) tries
                    -- again -- exactly like a genuinely-not-yet-looked-up
                    -- entry would, at the cost of one extra request if the
                    -- failure repeats. Only a TRULY empty entry
                    -- (count == 0 or unset) gets the permanent `false`.
                    cached_fb = false
                    local ok_log, logger = pcall(require, "logger")
                    if ok_log then
                        logger.info("[bookshelf][bookorbit] listGroups: sample-book fetch",
                            "came back empty for", gid, "despite count=", tostring(entry.count),
                            "-- leaving uncached so a later render retries")
                    end
                else
                    cached_fb = (sample and sample[1]) or false
                    bucket.first_books[entry.id] = cached_fb
                end
            end
            if cached_fb then
                first_book = {}
                for k, v in pairs(cached_fb) do first_book[k] = v end
                -- wantsCover()/scheduleCoverFills' "already filled" guard is
                -- keyed off record.cover_bb on THIS table -- but first_book is
                -- a brand-new table every single render (metadata only --
                -- see the comment above bucket.first_books), so that guard
                -- can never see a previous fill on its own. Left alone (and
                -- with no real cover cache), every render would hand
                -- scheduleCoverFills a "needs a cover" copy again, each fill
                -- fires onCoversReady, which triggers a full _rebuild(),
                -- which calls listGroups() again, which builds fresh copies
                -- again -- forever, on scheduleCoverFills' ~0.02s timer,
                -- pegging the UI and never letting the folder-like group
                -- chip (Series/Authors/etc.) settle.
                --
                -- Break the cascade with a REAL cache (GroupCoverCache,
                -- keyed by this entry's gid, not by the disposable
                -- first_book table): once an entry's cover has been decoded
                -- once, every later render -- this cascade or any future one
                -- -- reuses the SAME bb instead of re-decoding from disk.
                -- This is safe despite FolderStack/SpineWidget's
                -- cover_align_top path treating a group tile's cover_bb as a
                -- disposable, freed-after-paint override: SpineWidget always
                -- scales a PRIVATE copy off the bb before painting
                -- (bb:scale(), see _renderCoverAlignTop) and only frees the
                -- ORIGINAL when the caller marked it disposable.
                -- first_book.cover_bb_cache_owned (read by
                -- bookshelf_folder_stack.lua) tells it NOT to -- the same
                -- "hold a reference, never explicitly free it, let GC
                -- reclaim" contract bookshelf_scaled_cover_cache.lua already
                -- uses for book covers.
                local bb, w, h = GroupCoverCache:get(gid)
                if not bb then
                    -- Cache miss: cachedCoverBB is disk-only (no network),
                    -- so this is just a cheap JPEG decode when the cover is
                    -- already on disk from an earlier fetch -- and, unlike
                    -- before, it now happens at most ONCE per entry ever,
                    -- rather than once per render.
                    bb, w, h = M.cachedCoverBB and M.cachedCoverBB(first_book)
                    if bb then GroupCoverCache:put(gid, bb, w, h) end
                end
                if bb then
                    first_book.cover_bb, first_book.cover_w, first_book.cover_h = bb, w, h
                    first_book.has_cover = true
                    first_book.cover_bb_cache_owned = true
                else
                    -- Genuinely never decoded (not on disk yet): still goes
                    -- through the async queue below. Once that download+
                    -- decode lands and a later render's cachedCoverBB call
                    -- above succeeds, GroupCoverCache:put catches it and it
                    -- never gets re-decoded again either.
                    group_first_books[#group_first_books + 1] = first_book
                end
            end
        end
        records[#records + 1] = {
            kind       = "bookorbit_group",
            label      = entry.title or "Untitled",
            count      = entry.count,
            first_book = first_book,
            source_id  = gid,
        }
    end
    if show_covers and M.scheduleCoverFills then
        M.scheduleCoverFills(group_first_books, section)
    end
    return records, total
end

-- ---------------------------------------------------------------------
-- Cover thumbnails (disk-cached). Filenames are versioned by the book's
-- updatedAt (see coverToken below), same scheme as the official plugin's
-- bookorbit_catalog_thumbnails.lua: a server-side cover change or a
-- library rescan that reassigns book ids invalidates the cached image
-- instead of silently serving a stale/wrong one. The cache dir also gets
-- a soft file-count cap (Settings > BookOrbit > Cover cache limit,
-- default 600), pruned oldest-first,
-- so it can't grow without bound -- again mirroring the official plugin.
-- ---------------------------------------------------------------------

-- Debug-level tracing of the cover download chain -- silent in normal use,
-- available when a tester runs with debug logging on. Mirrors
-- bookshelf_kobo_source.lua's `diag` helper.
local function diag(...)
    local ok, logger = pcall(require, "logger")
    if ok and logger and logger.dbg then logger.dbg("[bookshelf][bookorbit]", ...) end
end

local function thumbDir()
    local DataStorage = require("datastorage")
    return DataStorage:getSettingsDir() .. "/bookshelf_bookorbit_covers"
end

-- Soft cap on the cover cache dir. Oldest files (by mtime) are evicted
-- past this count -- same value and eviction strategy as the official
-- plugin's THUMBNAIL_CACHE_MAX_FILES, except here it's user-configurable
-- (Settings > BookOrbit > Cover cache limit) rather than fixed, read
-- fresh on every prune so a change takes effect on the very next prune
-- without needing a restart -- same live-read pattern
-- bookshelf_bookorbit_cache.lua already uses for "bookorbit_cache_mb".
local THUMBNAIL_CACHE_MAX_FILES_DEFAULT = 600
local function thumbnailCacheMaxFiles()
    local n = tonumber(BookshelfSettings.read("bookorbit_thumbnail_cache_max_files"))
    return (n and n > 0) and math.floor(n) or THUMBNAIL_CACHE_MAX_FILES_DEFAULT
end

-- Cover cache files are versioned by the book's updated_at (see toRecord)
-- so a server-side cover change invalidates the cached image instead of
-- being masked by a filename-only cache hit. Falls back to "0" for
-- records that don't carry updated_at (never invalidates on its own, but
-- still gets swept by the size-capped prune below).
local function coverToken(record)
    local value = record and record.updated_at
    if not value then return "0" end
    local token = tostring(value):gsub("%D", "")
    return token ~= "" and token or "0"
end

-- One-time sweep of pre-versioning cache files ("<id>.jpg", no "_token"
-- suffix) left behind by earlier Bookshelf versions -- they'd otherwise
-- sit in the cache dir forever, never matched (and never evicted by
-- pruneThumbnailCache, since it does no filename parsing). Mirrors the
-- official plugin's cleanLegacyThumbnails. Runs at most once per session.
local _legacy_swept = false
local function cleanLegacyThumbnails()
    if _legacy_swept then return end
    _legacy_swept = true
    local lfs = require("libs/libkoreader-lfs")
    local dir = thumbDir()
    if lfs.attributes(dir, "mode") ~= "directory" then return end
    for name in lfs.dir(dir) do
        if name:match("^%d+%.jpg$") then
            os.remove(dir .. "/" .. name)
        end
    end
end

-- Evicts the oldest cached covers once the cache exceeds its soft file
-- cap. Same strategy as the official plugin's pruneThumbnailCache: list,
-- sort by mtime, drop the oldest overflow.
local function pruneThumbnailCache()
    local lfs = require("libs/libkoreader-lfs")
    local dir = thumbDir()
    if lfs.attributes(dir, "mode") ~= "directory" then return end
    local files = {}
    for name in lfs.dir(dir) do
        if name:match("%.jpg$") then
            local path = dir .. "/" .. name
            local mtime = lfs.attributes(path, "modification") or 0
            files[#files + 1] = { path = path, mtime = mtime }
        end
    end
    if #files <= thumbnailCacheMaxFiles() then return end
    table.sort(files, function(a, b) return a.mtime < b.mtime end)
    for i = 1, #files - thumbnailCacheMaxFiles() do
        os.remove(files[i].path)
    end
end

-- Books whose thumbnail download failed THIS SESSION -- mirrors the official
-- plugin's per-generation thumbnail_failures set, so a broken/missing cover
-- doesn't re-issue a failing HTTP request on every single page repaint.
-- Nothing here persists to disk, but unlike the rest of this module's
-- state, nothing was resetting it in-session either -- see
-- M.clearThumbFailures below for why that made a manual refresh unable
-- to fix it.
local _thumb_failed = {}

--- clearThumbFailures() -- drops every book id this session has marked
-- as "cover download failed, don't retry" (wantsCover/coverBB's
-- _thumb_failed guard above). This table is intentionally global across
-- every section (a download failure is keyed by remote_id, with no
-- section attached), so unlike invalidateGroupCache there's no scoped
-- form -- called unconditionally from the manual "swipe down to
-- refresh" action (see _refreshLibrary in bookshelf_widget.lua),
-- alongside its other session-wide backstops like
-- BookOrbit.clearBookStateKnown().
--
-- Without this, a cover that failed to download once (a flaky
-- connection, a request caught mid-flight by cancelThumbnailJobs'
-- generation bump, a transient server error) stayed permanently
-- blacklisted for the rest of the KOReader session: nothing else in
-- this file ever wrote _thumb_failed[key] back to nil, so wantsCover()
-- and coverBB() kept silently skipping that book's cover forever, even
-- through the exact user action (pull-to-refresh) that exists specifically
-- to say "the data may have changed, or that failure may have been
-- transient -- try again." That's the root cause of folders whose covers
-- never came back no matter how many times the chip was refreshed, and
-- why the set only grows over a session instead of ever shrinking.
function M.clearThumbFailures()
    _thumb_failed = {}
end

--- decodeThumbnailFile(path, key, dl_headers) -> bb, w, h (or nil).
-- Shared decode step used by both coverBB (fresh download or cache hit)
-- and cachedCoverBB (cache hit only, see below). dl_headers is only
-- ever present right after a fresh download, so a cache-hit re-decode
-- of a pre-existing bad file just logs without them.
local function decodeThumbnailFile(path, key, dl_headers)
    local ok_r, RenderImage = pcall(require, "ui/renderimage")
    if not ok_r or not RenderImage or not RenderImage.renderImageFile then return nil end
    local ok_bb, bb = pcall(function() return RenderImage:renderImageFile(path, false) end)
    -- BUG (root cause of every "did not decode" failure below): a successful
    -- decode returns a BlitBuffer, which KOReader builds via ffi.metatype --
    -- its Lua type() is "cdata", NEVER "table". The old `type(bb) ~= "table"`
    -- check therefore rejected every single valid decode, unconditionally,
    -- which is exactly what the content-type=image/jpeg + valid-JPEG-magic
    -- diagnostics above proved was happening: the bytes were fine the whole
    -- time. RenderImage:renderImageFile returns nil (falsy) on a genuine
    -- decode failure and a non-nil BlitBuffer on success, so `not bb` is the
    -- correct check -- same pattern used elsewhere in this codebase (e.g.
    -- bookshelf_image_source.lua just returns/uses the value directly).
    if not ok_bb or not bb then
        -- Downloaded fine but didn't decode as an image -- almost always
        -- means the bytes on disk aren't actually a JPEG (an HTML error
        -- page saved by a lenient sink, or a gzipped body a proxy sent
        -- without Accept-Encoding: identity being honoured). Log what we
        -- actually got -- Content-Type/Content-Encoding from the response
        -- (when this was a fresh download, i.e. dl_headers is set -- a
        -- cache-hit re-decode of a pre-existing bad file won't have these),
        -- the on-disk size, and the first bytes' magic number -- so the
        -- real cause (wrong content-type, still-gzipped body starting with
        -- 0x1F 0x8B, an HTML error page starting with "<", a 0-byte/
        -- truncated file, etc.) shows up in the log instead of a bare
        -- "did not decode". Then remove the bad file so the next attempt
        -- re-downloads instead of forever trying to decode the same broken
        -- bytes, and don't sit in _thumb_failed permanently -- a
        -- proxy/server fix should recover without a KOReader restart.
        local size, magic_hex, magic_ascii
        local fh = io.open(path, "rb")
        if fh then
            size = fh:seek("end")
            fh:seek("set", 0)
            local head = fh:read(16) or ""
            fh:close()
            magic_hex = head:gsub(".", function(c) return string.format("%02X ", c:byte()) end)
            magic_ascii = head:gsub("[^%g%s]", ".")
        end
        os.remove(path)
        local ct = dl_headers and (dl_headers["content-type"] or dl_headers["Content-Type"])
        local ce = dl_headers and (dl_headers["content-encoding"] or dl_headers["Content-Encoding"])
        local ok_log2, logger2 = pcall(require, "logger")
        if ok_log2 then
            logger2.info("[bookshelf][bookorbit] coverBB: downloaded file for book", key,
                "did not decode as an image (ok=", tostring(ok_bb), ")",
                "content-type=", tostring(ct), "content-encoding=", tostring(ce),
                "size=", tostring(size), "bytes",
                "magic=", tostring(magic_hex), "(", tostring(magic_ascii), ")",
                "-- removed cached file")
        end
        diag("coverBB: RenderImage failed to decode downloaded file for book", key,
             "(ok=", tostring(ok_bb), ") content-type=", tostring(ct),
             "size=", tostring(size), "magic=", tostring(magic_hex),
             "-- removed cached file")
        return nil
    end
    local w = bb.getWidth and bb:getWidth() or nil
    local h = bb.getHeight and bb:getHeight() or nil
    return bb, w, h
end

-- _downloadCoverWork(record, path) -- the actual network download step
-- only, NOT the decode that follows in coverBB below. Kept pure -- no
-- writes to _thumb_failed (module-level table) here -- so it can run
-- either inline or inside a Trapper:dismissableRunInSubprocess fork
-- without that write vanishing (a forked subprocess's writes to
-- module-level state never make it back to the parent process -- same
-- reasoning as _fetchBooksPage/_walkSectionPages elsewhere in this file).
--
-- The decode step (RenderImage:renderImageFile, inside decodeThumbnailFile)
-- deliberately stays OUTSIDE the fork, unlike this file's other
-- Trapper-protected leaves: it produces a BlitBuffer, a cdata object tied
-- to this process's own memory, which -- unlike a plain download result
-- (boolean + a headers table) -- has no safe way to cross back out of a
-- forked subprocess. So only the network download is protected; the
-- decode that follows is local-disk-only, no network, and stays cheap
-- and synchronous in the parent either way.
local function _downloadCoverWork(record, path)
    return BookOrbit.downloadCatalogThumbnail(record.remote_id, path)
end

--- coverBB(record) -> bb, w, h  (or nil). Caller owns the returned bb.
-- Blocking: downloads the thumbnail synchronously on a cache miss (and
-- decodes synchronously even on a cache hit). Kept for callers that
-- genuinely need a cover right now and can afford to wait for it (e.g.
-- the hero / rebuildRecord below, showing one book, not a whole page of
-- them); the grid's render path uses scheduleCoverFills instead (see
-- further down) so a page's worth of decodes/downloads never blocks
-- the page turn itself.
function M.coverBB(record)
    if not record or not record.remote_id or record.has_cover == false then return nil end
    local key = tostring(record.remote_id)
    if _thumb_failed[key] then return nil end
    local util = require("util")
    if not util.makePath(thumbDir()) then return nil end
    cleanLegacyThumbnails()
    local path = thumbDir() .. "/" .. key .. "_" .. coverToken(record) .. ".jpg"
    local dl_headers -- captured for diagnostics if the decode below fails
    local lfs = require("libs/libkoreader-lfs")
    if lfs.attributes(path, "mode") ~= "file" then
        local ok, err_or_headers
        local ok_t, Trapper = pcall(require, "ui/trapper")
        if ok_t and Trapper and Trapper.isWrapped and Trapper:isWrapped()
                and Trapper.dismissableRunInSubprocess then
            -- Already inside a Trapper coroutine (opened by whichever
            -- caller reached this -- e.g.
            -- BookshelfWidget:_showBookOrbitDetail's own Trapper:wrap, or
            -- any other future caller that opens one further up) -- run
            -- just the download in a dismissable subprocess so a slow/
            -- unresponsive server shows a cancellable spinner instead of
            -- freezing the reader. See _downloadCoverWork's doc comment
            -- for why the decode below stays outside the fork.
            local completed, result = Trapper:dismissableRunInSubprocess(function()
                local pok, dok, derr = pcall(_downloadCoverWork, record, path)
                if not pok then return { ok = false, err = tostring(dok) } end
                return { ok = dok, err = derr }
            end, _("Loading cover\xE2\x80\xA6"))
            if not completed then
                -- Cancelled -- same "nothing to show" shape a download/
                -- decode failure returns below; caller already handles a
                -- nil bb.
                return nil
            end
            result = result or {}
            ok, err_or_headers = result.ok, result.err
        else
            -- Not inside a Trapper coroutine (background/proactive caller
            -- -- e.g. rebuildRecord's own coverBB call when not reached
            -- from a wrapped render path -- or Trapper unavailable) --
            -- today's plain blocking call, unchanged.
            ok, err_or_headers = _downloadCoverWork(record, path)
        end
        if not ok then
            _thumb_failed[key] = true
            local ok_log, logger = pcall(require, "logger")
            if ok_log then
                logger.info("[bookshelf][bookorbit] coverBB: thumbnail download failed for book",
                    key, "->", tostring(err_or_headers))
            end
            diag("coverBB: download failed for book", key, "->", tostring(err_or_headers))
            return nil
        end
        dl_headers = err_or_headers
        pruneThumbnailCache()
    end
    return decodeThumbnailFile(path, key, dl_headers)
end

--- cachedCoverBB(record) -> bb, w, h (or nil). NON-blocking in the sense
-- that it never triggers a download -- but it does still decode
-- synchronously on a disk hit, which is why the grid's render path
-- doesn't call this directly any more (see scheduleCoverFills below,
-- which decodes off the render path for hits and misses alike).
-- Exported for any caller that wants a one-off "cover if it's already
-- cached, nothing otherwise" lookup without paying for a download.
function M.cachedCoverBB(record)
    if not record or not record.remote_id or record.has_cover == false then return nil end
    local key = tostring(record.remote_id)
    local lfs = require("libs/libkoreader-lfs")
    local path = thumbDir() .. "/" .. key .. "_" .. coverToken(record) .. ".jpg"
    if lfs.attributes(path, "mode") ~= "file" then return nil end
    return decodeThumbnailFile(path, key, nil)
end

-- ---------------------------------------------------------------------
-- Batched cover fills (async decode + download)
--
-- coverBB/cachedCoverBB above are both blocking in the way that matters
-- here: coverBB downloads AND decodes synchronously, cachedCoverBB at
-- least skips the download but still decodes synchronously. Calling
-- either once per record for a whole grid page means the page's render
-- (or a page turn) sits behind N JPEG decodes and however many HTTP
-- round-trips, back to back. This section is the async alternative --
-- mirrors the official plugin's bookorbit_catalog_thumbnails.lua
-- (scheduleThumbnailDownloads / prefetchThumbnails / thumbnail_
-- generation), adapted from its Menu-based pager to Bookshelf's grid,
-- and further widened here to cover disk hits as well as misses (see
-- scheduleCoverFills' own doc comment for why):
--   * getBySource (bookshelf_book_repository.lua) hands back a page's
--     records with NO cover attached at all, then calls
--     scheduleCoverFills() with the whole page.
--   * Each record is filled in place off the render path, in small
--     batches: a decode for a disk hit, a download-then-decode for a
--     miss. onCoversReady fires after each batch that landed something
--     so the grid can repaint with whatever just landed.
--   * prefetchNextPage (currently unused -- see its own call site
--     comment in bookshelf_book_repository.lua) warms the covers for a
--     page the user hasn't paged to yet, at a slower cadence and with
--     no repaint.
-- Every entry point here is generation-gated: each fresh
-- scheduleCoverFills call bumps the generation, so a superseded
-- page/chip's leftover queue just stops touching the network/disk or
-- firing repaints instead of piling up behind the new one.
-- ---------------------------------------------------------------------

-- Same value as the official bookorbit.koplugin's identical batching
-- pattern (bookorbit_catalog_thumbnails.lua) -- a larger batch here blocks
-- roughly proportionally longer before yielding back to the UI each tick.
local THUMBNAIL_BATCH_SIZE = 2

local _thumb_generation = 0

--- cancelThumbnailJobs() -- bumps the generation, turning every
-- in-flight scheduleCoverFills/prefetchNextPage queue into a no-op on
-- its next step. Called automatically by scheduleCoverFills (a fresh
-- page always supersedes the previous one); exposed here too for
-- callers like a manual "refresh library" action that want to drop
-- stale jobs immediately.
function M.cancelThumbnailJobs()
    _thumb_generation = _thumb_generation + 1
end

-- Registered once by the grid widget (see bookshelf_widget.lua's init),
-- fired after each downloaded batch lands so the caller can repaint.
-- A single slot is enough -- there's only ever one live grid instance.
--
-- source_id (optional) identifies which chip/source the batch that just
-- landed belongs to -- the same string bookshelf_widget.lua compares
-- against the currently VISIBLE chip's source before deciding whether a
-- repaint is actually warranted. This is what lets pre-warming a
-- BookOrbit chip the user hasn't tapped to yet fill its covers quietly
-- in the background: a batch landing for a chip that isn't on screen no
-- longer forces a full _rebuild() of whatever IS on screen. A nil
-- source_id (any caller that hasn't been updated to pass one) is
-- treated as "unknown -- repaint to be safe", matching the old
-- always-repaint behaviour.
local _covers_ready_cb
function M.onCoversReady(cb)
    _covers_ready_cb = cb
end

function fireCoversReady(source_id)
    if not _covers_ready_cb then return end
    local ok, err = pcall(_covers_ready_cb, source_id)
    if not ok then
        local ok_log, logger = pcall(require, "logger")
        if ok_log then logger.info("Bookshelf BookOrbit: onCoversReady callback failed", err) end
    end
end

--- True if `record` needs a cover download: has_cover isn't false, no
-- file already on disk at its (versioned) cache path, and it hasn't
-- already failed this session. Used by prefetchNextPage below, which
-- only wants to warm what's actually missing from disk.
local function needsThumbnail(record)
    if not (record and record.remote_id and record.has_cover ~= false) then return false end
    local key = tostring(record.remote_id)
    if _thumb_failed[key] then return false end
    local lfs = require("libs/libkoreader-lfs")
    local path = thumbDir() .. "/" .. key .. "_" .. coverToken(record) .. ".jpg"
    return lfs.attributes(path, "mode") ~= "file"
end

--- True if `record` is eligible for a cover fill at all: has_cover
-- isn't false and it hasn't already failed this session. Unlike
-- needsThumbnail above, this does NOT check disk first -- used by
-- scheduleCoverFills below, which handles disk hits and misses the
-- same way (see its doc comment for why).
local function wantsCover(record)
    if not (record and record.remote_id and record.has_cover ~= false) then return false end
    -- Already filled in (by a previous scheduleCoverFills pass over this
    -- SAME record table) -- must be excluded, not just has_cover==false.
    -- getBySource's listBooks() call can now return the identical
    -- (cached, mutated-in-place) record objects across repeated calls
    -- (see the page cache in listBooks above), and onCoversReady's
    -- _rebuild() calls scheduleCoverFills(page) again on the WHOLE page
    -- every time a batch lands. Without this check, an already-covered
    -- record decodes "successfully" again instantly (it's on disk),
    -- fireCoversReady() fires again, triggering another _rebuild(), which
    -- calls scheduleCoverFills(page) again -- forever, on a fast
    -- ~0.02s timer, since nothing ever shrinks the requeued set. This
    -- check is what makes the queue actually shrink call over call
    -- (fewer records still need a cover each time) so the cascade
    -- terminates once the whole page is filled, instead of freezing
    -- the UI in a tight synchronous rebuild loop.
    --
    -- Deliberately checks record._cover_filled, NOT record.cover_bb.
    -- cover_bb is a ONE-SHOT bb: SpineWidget frees it once a grid tile
    -- consumes it, and (as of the fix alongside this one) nils the field
    -- back out when it does, specifically so a later revisit of this same
    -- cached record doesn't pick up a dangling pointer. If this guard
    -- checked record.cover_bb directly, that nil-out would make an
    -- already-filled record look "never filled" and get silently
    -- re-downloaded/re-decoded every revisit -- harmless but wasteful.
    -- Worse, before cover_bb was ever nulled, a freed-but-still-set
    -- cover_bb made this return false forever, so a page revisited after
    -- its bb had been consumed never got queued again: the grid picked
    -- the stale/freed bb back up as effective_bb and either double-freed
    -- it or scaled it as source pixels -- the distorted-covers-after-
    -- paging-away-and-back bug. _cover_filled is a plain boolean set once
    -- in fillOneCover and never cleared, independent of the bb's runtime
    -- lifetime, so the anti-loop dedup here keeps working regardless of
    -- whether/when cover_bb itself gets freed and nulled.
    if record._cover_filled then return false end
    return not _thumb_failed[tostring(record.remote_id)]
end

local function downloadOneThumbnail(record, tag)
    local key = tostring(record.remote_id)
    local path = thumbDir() .. "/" .. key .. "_" .. coverToken(record) .. ".jpg"
    local ok, err = BookOrbit.downloadCatalogThumbnail(record.remote_id, path)
    if not ok then
        _thumb_failed[key] = true
        diag(tag, ": download failed for book", key, "->", tostring(err))
    end
    return ok
end

--- fillOneCover(record, tag) -- decodes record's cover if it's already
-- on disk, otherwise downloads it first (same HTTP call
-- downloadOneThumbnail makes) and then decodes -- and on success sets
-- record.cover_bb/cover_w/cover_h (and record.has_cover = true) on the
-- record in place. Returns true if it actually changed anything a
-- caller should repaint for.
local function fillOneCover(record, tag)
    local key = tostring(record.remote_id)
    local path = thumbDir() .. "/" .. key .. "_" .. coverToken(record) .. ".jpg"
    local lfs = require("libs/libkoreader-lfs")
    if lfs.attributes(path, "mode") ~= "file" then
        if not downloadOneThumbnail(record, tag) then return false end
    end
    local bb, w, h = decodeThumbnailFile(path, key, nil)
    if not bb then return false end
    record.cover_bb, record.cover_w, record.cover_h = bb, w, h
    record.has_cover = true
    -- Persistent "we've filled this at least once" marker, independent of
    -- cover_bb's own lifetime -- see wantsCover's comment above for why
    -- this can't just be `record.cover_bb`.
    record._cover_filled = true
    return true
end

--- scheduleCoverFills(records) -- fills EVERY eligible record's cover in
-- place (decoding a disk hit, or downloading-then-decoding a miss),
-- off the render path, in small batches -- getBySource hands back
-- `records` with no cover attached at all, and this fills them in
-- shortly after, firing onCoversReady() after each batch that landed
-- something so the caller can repaint.
--
-- This deliberately includes disk HITS too, not just misses: even
-- decoding an already-downloaded JPEG is real synchronous CPU work
-- (RenderImage), and doing a whole page's worth of that inline in the
-- render path (the old behaviour) was exactly the "device feels busy
-- right as you turn the page" stall this exists to avoid -- covers
-- being ready doesn't help if reaching them still means decoding
-- a dozen-plus JPEGs before the page can paint. The trade-off: a page
-- turn now always paints covers-blank-then-fills-in a beat later, even
-- for a page that's 100% disk-cached, rather than occasionally
-- painting fully populated on the first frame.
--
-- Safe to call on every render (e.g. once per _rebuild): a no-op when
-- nothing's eligible, and any leftover queue from a previous call is
-- superseded (see cancelThumbnailJobs above) rather than running
-- alongside the new one.
--
-- `source_id` (optional) is passed straight through to onCoversReady so
-- the caller can tell a background-warmed chip's batch apart from the
-- currently-visible chip's -- see onCoversReady's doc comment above.
function M.scheduleCoverFills(records, source_id)
    local queue = {}
    for _, record in ipairs(records or {}) do
        if wantsCover(record) then queue[#queue + 1] = record end
    end
    if #queue == 0 then return end

    local util = require("util")
    if not util.makePath(thumbDir()) then return end

    M.cancelThumbnailJobs()
    local generation = _thumb_generation
    local ok_ui, UIManager = pcall(require, "ui/uimanager")
    if not (ok_ui and UIManager) then return end

    local function step()
        if generation ~= _thumb_generation then return end
        local landed_any = false
        for _ = 1, THUMBNAIL_BATCH_SIZE do
            local record = table.remove(queue, 1)
            if not record then break end
            if fillOneCover(record, "scheduleCoverFills") then
                landed_any = true
            end
        end
        if generation ~= _thumb_generation then return end
        if landed_any then fireCoversReady(source_id) end
        if #queue > 0 then
            -- Short tick either way -- decode-only batches are cheap
            -- enough that this cadence barely matters for them; download
            -- batches are still gated by the HTTP round-trip itself, not
            -- by this delay.
            UIManager:scheduleIn(0.02, step)
        else
            pruneThumbnailCache()
        end
    end
    UIManager:scheduleIn(0.02, step)
end

--- prefetchNextPage(source_id, offset, limit) -- off the render path,
-- fetches the book list for the given page (and caches it -- see
-- cacheNextPage/consumeNextPageCache above -- so the actual page turn,
-- when it happens, is served from that cache instead of paying for the
-- same catalogBooks() request a second time) and warms (downloads,
-- doesn't decode/repaint) whatever covers it's missing, at a slower
-- cadence than scheduleCoverFills since nothing's waiting on it. Purely a nice-to-have: silent on any failure (offline, server
-- error, superseded generation, etc.) since there's no visible page
-- depending on this succeeding yet. Callers pass the offset/limit of
-- the page one step past what's currently on screen.
function M.prefetchNextPage(source_id, offset, limit)
    local generation = _thumb_generation
    local ok_ui, UIManager = pcall(require, "ui/uimanager")
    if not (ok_ui and UIManager) then return end
    UIManager:scheduleIn(1.0, function()
        if generation ~= _thumb_generation then return end
        local ok_net, NetworkMgr = pcall(require, "ui/network/manager")
        if not (ok_net and NetworkMgr and NetworkMgr.isOnline and NetworkMgr:isOnline()) then return end
        -- listBooks does its own blocking HTTP call, same as everywhere
        -- else in this module -- fine here since this whole function
        -- already runs on a deferred tick, off the caller's render path.
        local records, total = M.listBooks(source_id, offset, limit)
        if generation ~= _thumb_generation then return end
        -- Cache the list itself (not just the covers below) -- this is
        -- the fix for page turns feeling slow even once covers were
        -- already warmed: without this, the actual book-list fetch for
        -- the page you turn to was always a fresh network round-trip,
        -- identical to the one this function just made.
        cacheNextPage(source_id, offset, limit, records, total)
        -- Warm the next page's synopses too (disk cache only, no repaint
        -- -- see prefetchDescriptions' doc comment below) alongside its
        -- covers, so paging forward and then opening a book's hero view
        -- doesn't pay for the description round trip either.
        M.prefetchDescriptions(records)
        local queue = {}
        for _, record in ipairs(records or {}) do
            if needsThumbnail(record) then queue[#queue + 1] = record end
        end
        if #queue == 0 then return end
        local util = require("util")
        if not util.makePath(thumbDir()) then return end
        local function step()
            if generation ~= _thumb_generation then return end
            local record = table.remove(queue, 1)
            if not record then
                pruneThumbnailCache()
                return
            end
            downloadOneThumbnail(record, "prefetchNextPage")
            UIManager:scheduleIn(0.08, step)
        end
        UIManager:scheduleIn(0.08, step)
    end)
end

-- ---------------------------------------------------------------------
-- Description cache (hero synopsis)
--
-- The grid's listBooks() records come from catalogBooks(), which never
-- returns a description (only the per-book detail endpoint does) -- so a
-- plain toRecord() has no synopsis for the hero to show, and rebuildRecord
-- below has always fetched it fresh from /catalog/books/<id>. Until now
-- that fetch was UNCACHED: every single tap that promotes a BookOrbit
-- book into the hero paid a full blocking HTTP round trip for the
-- synopsis, even for a book whose detail was already fetched and shown
-- a minute (or one tap) ago -- e.g. tap A, tap B, tap A again re-fetched
-- A's description from the server a second time. Local library books
-- never pay this: their description already lives in KOReader's own
-- on-disk BIM cache from the last library scan (Repo.buildBook just
-- reads it), which is why they show a synopsis noticeably faster than
-- a BookOrbit book on the same tap.
--
-- Cached to disk (survives a KOReader restart, unlike an in-memory
-- table) and versioned by the book's updated_at -- same field, same
-- reasoning as coverToken above: a real server-side edit to the book
-- still invalidates the cached synopsis instead of serving it stale
-- forever. A record with no updated_at at all (older/partial data)
-- degrades to "never self-invalidates", same fallback behaviour
-- coverToken already has -- the manual "Refresh library" action drops
-- this cache too (see bookshelf_widget.lua) as a backstop.
-- ---------------------------------------------------------------------
local _desc_cache_settings

local function descCacheSettings()
    if not _desc_cache_settings then
        local LuaSettings = require("luasettings")
        local DataStorage = require("datastorage")
        _desc_cache_settings = LuaSettings:open(
            DataStorage:getSettingsDir() .. "/bookshelf_bookorbit_descriptions.lua")
    end
    return _desc_cache_settings
end

--- cachedDescription(remote_id, updated_at) -> description string, or
-- nil on a cold cache OR a version mismatch (the cached entry's
-- updated_at disagrees with the caller's) -- either way the caller
-- should treat this as a miss and re-fetch.
local function cachedDescription(remote_id, updated_at)
    local ok, entry = pcall(function()
        return descCacheSettings():readSetting(tostring(remote_id))
    end)
    if not ok or not entry then return nil end
    if entry.updated_at and updated_at and entry.updated_at ~= updated_at then
        return nil
    end
    return entry.description
end

--- cachedCommunityRatings(remote_id, updated_at) -> array of
-- { provider, rating, ratingCount, updatedAt }, or nil on a cold cache /
-- version mismatch. Piggybacks on the SAME on-disk entry cachedDescription
-- reads (see cacheDescription below) rather than a separate settings
-- file/round trip, since both come from the one per-book detail fetch --
-- so a cache HIT for the description (the common repaint/refocus case)
-- also hands back whatever community ratings were saved alongside it,
-- instead of the hero's community-rating row silently going blank again
-- on every render after the first.
local function cachedCommunityRatings(remote_id, updated_at)
    local ok, entry = pcall(function()
        return descCacheSettings():readSetting(tostring(remote_id))
    end)
    if not ok or not entry then return nil end
    if entry.updated_at and updated_at and entry.updated_at ~= updated_at then
        return nil
    end
    return entry.community_ratings
end

--- cachedGenres(remote_id, updated_at) -> array of genre/tag strings, or
-- nil on a cold cache / version mismatch. Same piggyback as
-- cachedCommunityRatings above -- one detail fetch, one cache entry.
local function cachedGenres(remote_id, updated_at)
    local ok, entry = pcall(function()
        return descCacheSettings():readSetting(tostring(remote_id))
    end)
    if not ok or not entry then return nil end
    if entry.updated_at and updated_at and entry.updated_at ~= updated_at then
        return nil
    end
    return entry.genres
end

--- extractGenres(detail) -> array of strings, or nil.
--
-- The BookOrbit server's book-detail response (GET
-- .../catalog/books/<id>) carries genre-ish data under TWO separate
-- fields -- `genres` and `tags` -- confirmed straight off the official
-- KOReader plugin (bookorbit_catalog_detail.lua's detailPillItems,
-- which reads both and merges them for its own "Genres & Tags" pill
-- row). Mirrored here the same way: concatenate both arrays in order
-- (genres first, tags after) and hand the combined list to
-- bookshelf_widget.lua's existing pill-spec builder, which already
-- case-insensitively dedupes book.genres itself -- so a title present
-- in both `genres` and `tags` still renders as one pill, not two.
-- Neither field is guaranteed present on every server version; either
-- or both being absent/empty just yields nil, same silent-no-pill
-- fallback the hero already has for a book with no genres at all.
local function extractGenres(detail)
    if type(detail) ~= "table" then return nil end
    local out = {}
    local function collect(field)
        if type(field) ~= "table" then return end
        for _i, v in ipairs(field) do
            if type(v) == "string" and v ~= "" then
                out[#out + 1] = v
            end
        end
    end
    collect(detail.genres)
    collect(detail.tags)
    if #out == 0 then return nil end
    return out
end

-- community_ratings: optional array of { provider, rating, ratingCount,
-- updatedAt } from the same detail response's communityRatings field
-- (requires a BookOrbit server patched to expose it -- see
-- BOOKORBIT_HERO_COMMUNITY_RATING.md -- older/unpatched servers simply
-- never send this field, so it's nil here and the hero falls back to
-- whatever it already falls back to).
-- genres: optional array of strings -- see extractGenres above for where
-- this comes from and why it's a merge of two response fields.
local function cacheDescription(remote_id, updated_at, description, community_ratings, genres)
    if not remote_id then return end
    if (not description or description == "") and community_ratings == nil and genres == nil then return end
    pcall(function()
        local settings = descCacheSettings()
        settings:saveSetting(tostring(remote_id), {
            description       = description,
            updated_at        = updated_at,
            community_ratings = community_ratings,
            genres            = genres,
        })
        settings:flush()
    end)
end

--- invalidateDescriptionCache(remote_id) -- drops one book's cached
-- synopsis, or -- with no argument -- every cached synopsis, so the next
-- hero view re-fetches it. Mirrors invalidateDiscoverCache/
-- invalidateGroupCache above. The shelf's manual refresh passes just the
-- currently-previewed book's remote_id (the only synopsis actually on
-- screen right now) as a backstop for the "no updated_at to compare"
-- case noted above, rather than purging every OTHER book's cached
-- synopsis along with it.
function M.invalidateDescriptionCache(remote_id)
    pcall(function()
        local settings = descCacheSettings()
        if remote_id then
            settings:delSetting(tostring(remote_id))
            settings:flush()
        else
            settings:purge()
        end
    end)
end

-- Per-session "already tried, gave up" set for description fetches --
-- same role _thumb_failed plays for covers above: a book whose detail
-- request failed once (offline, 401, deleted server-side, ...) isn't
-- retried on every subsequent pre-warm/prefetch pass this session. Reset
-- implicitly on plugin reload; a manual retry always happens the next
-- time the book is actually opened to the hero view (rebuildRecord
-- doesn't consult this set).
local _desc_failed = {}

--- needsDescription(record) -> true if `record` is a BookOrbit book
-- whose synopsis isn't already cached on disk (see cachedDescription
-- above) and hasn't already failed to fetch this session. Mirrors
-- needsThumbnail's shape for covers.
local function needsDescription(record)
    if not (record and record.remote_id) then return false end
    if _desc_failed[tostring(record.remote_id)] then return false end
    return cachedDescription(record.remote_id, record.updated_at) == nil
end

--- prefetchDescriptions(records) -- for each record in `records` that's
-- missing a cached synopsis (needsDescription above), fetches the
-- per-book detail endpoint and caches the description to disk via the
-- same cachedDescription/cacheDescription pair rebuildRecord uses for an
-- on-demand hero-view open. By the time a warmed book is actually
-- opened, rebuildRecord's cachedDescription() call is a cache hit and
-- skips the network round trip entirely -- the same win prefetched
-- covers already give a page turn, just for the synopsis instead of the
-- thumbnail.
--
-- Deliberately does NOT mutate the records passed in (no
-- record.description, no cover work) -- unlike rebuildRecord, this never
-- feeds a live render, so there's nothing to repaint and covers already
-- have their own warm path (scheduleCoverFills / the thumbnail queue in
-- prefetchNextPage below). This function's only job is populating the
-- on-disk description cache ahead of time.
--
-- Throttled one book at a time -- a blocking HTTP request per book, same
-- cost class as a single cover download -- and generation-gated against
-- the SAME _thumb_generation counter cover jobs use (see
-- cancelThumbnailJobs's doc comment): a chip switch or manual refresh
-- should drop all of a superseded chip's background BookOrbit work
-- uniformly, not just its cover queue.
function M.prefetchDescriptions(records)
    local generation = _thumb_generation
    local ok_ui, UIManager = pcall(require, "ui/uimanager")
    if not (ok_ui and UIManager) then return end
    local queue = {}
    local seen = {}
    for _, record in ipairs(records or {}) do
        local key = record and record.remote_id and tostring(record.remote_id)
        if key and not seen[key] and needsDescription(record) then
            seen[key] = true
            queue[#queue + 1] = record
        end
    end
    if #queue == 0 then return end
    local function step()
        if generation ~= _thumb_generation then return end
        local record = table.remove(queue, 1)
        if not record then return end
        local detail, err = BookOrbit.catalogBook(record.remote_id)
        if detail then
            cacheDescription(record.remote_id, detail.updatedAt or record.updated_at,
                detail.description, detail.communityRatings)
        else
            _desc_failed[tostring(record.remote_id)] = true
            diag("prefetchDescriptions: detail fetch failed for book",
                record.remote_id, "->", tostring(err))
        end
        if #queue > 0 then UIManager:scheduleIn(0.08, step) end
    end
    UIManager:scheduleIn(0.08, step)
end

-- ---------------------------------------------------------------------
-- Full-record rebuild (hero / preview)
--
-- Separately from the description above, the cover_bb the grid attached
-- to a record is a ONE-SHOT bb: the grid tile already painted (and
-- freed) it by the time a tap promotes that same record into the hero,
-- so reusing it there paints nothing. Repo.buildBook can't fix either of
-- these for a "bookorbit://" filepath (there's no real file/DocSettings
-- for it), so callers that promote a tapped/selected BookOrbit book into
-- the hero should call this instead of relying on the generic
-- Repo.buildBook -- see Repo.buildPreviewBook.
-- ---------------------------------------------------------------------

--- rebuildRecord(fallback) -> record or nil
-- fallback is the existing list record for this book (must carry
-- remote_id). Resolves the book's description -- from the on-disk cache
-- above on a hit, otherwise the per-book detail endpoint (which also
-- populates the cache for next time) -- and a fresh cover thumbnail;
-- every other field is carried over from fallback unchanged. Returns nil
-- if a required detail request fails (offline, 401, server error, etc.)
-- so the caller falls back to reusing fallback as-is -- same
-- nil-means-"use the old record" contract Repo.buildBookMeta uses.
function M.rebuildRecord(fallback)
    if not fallback or not fallback.remote_id then return nil end
    if not M.isAvailable() then return nil end

    local record = {}
    for k, v in pairs(fallback) do
        -- Never carry the old cover_bb forward -- it may already be freed
        -- (see above); coverBB below gets a fresh one.
        if k ~= "cover_bb" then record[k] = v end
    end

    -- Re-apply the local rating override here too, not just in toRecord.
    -- Without this, a rating just set (or just pulled from the server
    -- below) survives a chip *refresh* -- which rebuilds every record via
    -- toRecord(), and toRecord DOES check the override -- but not a plain
    -- focus switch: that only re-runs THIS function, and fallback here is
    -- the shelf grid's original record, built before the override existed,
    -- so its .rating is stale (often nil). Priming record.rating from the
    -- override before the cache-hit/fetch branch below means the cache-hit
    -- path (no detail re-fetch) still reflects the latest known rating
    -- instead of silently reverting to that stale fallback value.
    local override = localRatingOverride(fallback.remote_id)
    if override ~= nil then
        record.rating = override
    end

    local cached_desc = cachedDescription(fallback.remote_id, fallback.updated_at)
    if cached_desc ~= nil then
        record.description = cached_desc
        record.community_ratings = cachedCommunityRatings(fallback.remote_id, fallback.updated_at)
        record.genres = cachedGenres(fallback.remote_id, fallback.updated_at)
    else
        -- Trapper-protect the blocking detail fetch when this call happens
        -- to be running inside a coroutine already opened further up the
        -- stack (Repo.buildPreviewBook's callers -- see the widget-side
        -- entry points touched for Step E). Kept as a single-call fork,
        -- same shape as fetchDiscover's _fetchDiscoverWork above: the
        -- helper is pure (just the network call), so it's safe to run
        -- either inline or forked without a write silently vanishing.
        local detail, err
        local ok_t, Trapper = pcall(require, "ui/trapper")
        if ok_t and Trapper and Trapper.isWrapped and Trapper:isWrapped()
                and Trapper.dismissableRunInSubprocess then
            local completed, result = Trapper:dismissableRunInSubprocess(function()
                local ok, d, werr = pcall(BookOrbit.catalogBook, fallback.remote_id)
                if not ok then return { err = tostring(d) } end
                if not d then return { err = werr } end
                return { detail = d }
            end, _("Loading\xE2\x80\xA6"))
            if not completed then
                -- Cancelled -- same "use the old record" fallback a failed
                -- fetch gets below; nothing to clean up since nothing was
                -- written yet.
                return nil
            end
            result = result or {}
            detail, err = result.detail, result.err
        else
            -- Not inside a Trapper coroutine (background/proactive caller,
            -- or Trapper unavailable) -- today's plain blocking call,
            -- unchanged.
            detail, err = BookOrbit.catalogBook(fallback.remote_id)
        end
        if not detail then
            local ok_log, logger = pcall(require, "logger")
            if ok_log then logger.info("Bookshelf BookOrbit: rebuildRecord failed", err) end
            return nil
        end
        record.description = detail.description
        if detail.updatedAt then record.updated_at = detail.updatedAt end
        -- communityRatings: present only against a BookOrbit server patched
        -- to expose it on this endpoint (see BOOKORBIT_HERO_COMMUNITY_RATING.md)
        -- -- an unpatched server simply omits the field, so this is nil there
        -- and the hero's community-rating row has nothing to show, same as
        -- before this existed.
        record.community_ratings = detail.communityRatings
        -- genres: merge of the detail response's `genres` and `tags`
        -- fields -- see extractGenres's comment above for why both are
        -- read. Absent on an unpatched/older server, same as
        -- communityRatings above -- the hero's genre pills simply don't
        -- appear, matching today's behaviour.
        record.genres = extractGenres(detail)
        cacheDescription(fallback.remote_id, record.updated_at, record.description,
            record.community_ratings, record.genres)
        -- Pull down whatever rating the server has for this book while
        -- we already have its detail response in hand -- this is what
        -- lets a rating set purely server-side (web UI, another device)
        -- actually show up here instead of the star row staying empty
        -- forever. Overwrites the local override cache too (not just
        -- reads it) so a rating cleared on the server also clears here,
        -- rather than a stale local value shadowing it indefinitely.
        record.rating = tonumber(detail.rating)
        M.setLocalRatingOverride(fallback.remote_id, record.rating)
    end

    local bb, cw, ch = M.coverBB(record)
    if bb then
        record.cover_bb, record.cover_w, record.cover_h = bb, cw, ch
        record.has_cover = true
    end
    return record
end

-- ---------------------------------------------------------------------
-- Opening: download the book's primary file on first open, then remember
-- where it landed so a later tap just opens the local copy.
-- ---------------------------------------------------------------------

local LuaSettings = require("luasettings")
local DataStorage = require("datastorage")
local _dl_settings

local function dlSettings()
    if not _dl_settings then
        _dl_settings = LuaSettings:open(DataStorage:getSettingsDir() .. "/bookshelf_bookorbit_downloads.lua")
    end
    return _dl_settings
end

--- True if `filepath` is one of this module's synthetic placeholders.
function M.isBookOrbitPath(filepath)
    return type(filepath) == "string" and filepath:sub(1, 12) == "bookorbit://"
end

--- resolveOpenPath(record, callback, hooks) -- callback(path) on success,
-- callback(nil, err) on failure. Non-blocking from the caller's point of
-- view: does its own network calls, then invokes callback once it knows
-- the answer. If a previous download for this book is still on disk, the
-- callback fires with that path immediately and no network is touched.
--
-- `hooks` (optional) lets the caller give progress feedback without having
-- to guess up front whether this call will need the network at all:
--   * hooks.on_download_start() -- fired right before bytes are actually
--     requested from the server, i.e. only when the dedupe check against
--     the expected on-disk path misses. Not fired for the instant
--     settings-cache hit, nor when that dedupe check finds an existing file
--     to open instead -- the catalog-detail lookup itself stays silent.
--     Only used by the no-Trapper fallback below -- when Trapper is
--     available its own dismissable spinner (see _resolveWork's caller)
--     already tells the user something is happening and lets them cancel,
--     so this hook's plain, non-dismissable InfoMessage would be redundant
--     (and can't fire from inside the subprocess the Trapper path runs in
--     anyway -- see the comment on that below).

--- _resolveWork(record, announce) -- the actual network body: catalog-
-- detail lookup, the on-disk dedupe check, and (on a miss) the file
-- download. Returns path, err the same way callback would have been
-- called before this was split out of resolveOpenPath -- factored out
-- so it can run either inline (today's behaviour, no Trapper available)
-- or inside a Trapper:dismissableRunInSubprocess fork (see
-- resolveOpenPath below), without duplicating this logic for both.
--
-- `announce`, if given, is called right before bytes are actually
-- requested from the server -- same "only on a genuine miss" timing
-- hooks.on_download_start documents above. Only ever passed a real
-- function by the no-Trapper fallback: a forked subprocess can't safely
-- call back into the parent's UI (it's a different process), so the
-- Trapper path always passes nil here and relies on Trapper's own
-- spinner for feedback instead.
local function _resolveWork(record, announce)
    local lfs = require("libs/libkoreader-lfs")
    local detail, err = BookOrbit.catalogBook(record.remote_id)
    if not detail then return nil, err end
    local files = detail.files or {}
    if #files == 0 then return nil, "no_file" end
    local file = files[1]
    for _, f in ipairs(files) do
        if f.role == "primary" then file = f; break end
    end
    local dir  = BookOrbit.downloadDestDir(BookOrbit.downloadDir(), detail)
    local base = BookOrbit.buildFilenameBase(detail, record.title)
    local ext  = file.format or "epub"
    local canonical_path = dir .. "/" .. base .. "." .. ext
    -- If the exact file we'd otherwise download to already exists --
    -- placed there by other means, left over from a previous install,
    -- downloaded outside this plugin, etc. -- treat it as this book
    -- and open it directly instead of downloading a second copy and
    -- suffixing it "(1)". This is a filename match, not a content
    -- verification: the server doesn't expose a comparable hash for
    -- the remote file before downloading it (BookOrbit.getBookHash is
    -- a LOCAL partial-MD5 of bytes already on disk, used for progress
    -- sync -- there's nothing to compare it against here without
    -- downloading first, which defeats the point). In practice a
    -- false match needs two different books landing at the exact same
    -- sanitized title AND the exact same Author[/Series] subfolder,
    -- which is unlikely but not impossible -- if that ever bites,
    -- deleting the wrongly-matched local file forces a real
    -- (uniquely-suffixed) download next time.
    if lfs.attributes(canonical_path, "mode") == "file" then
        local ok_log, logger = pcall(require, "logger")
        if ok_log then
            logger.info("BookOrbit: resolveOpenPath found an existing file at the expected " ..
                "download path, opening it instead of re-downloading:", canonical_path)
        end
        return canonical_path
    end
    local path = BookOrbit.uniqueDownloadPath(dir, base, ext)
    if announce then announce() end
    local ok, derr = BookOrbit.downloadCatalogFile(file.id, path)
    if not ok then return nil, derr end
    return path
end

function M.resolveOpenPath(record, callback, hooks)
    hooks = hooks or {}
    if not record or not record.remote_id then
        callback(nil, "bad_record")
        return
    end
    local lfs = require("libs/libkoreader-lfs")
    local s = dlSettings()
    local key = tostring(record.remote_id)
    local cached = s:readSetting(key)
    if cached and lfs.attributes(cached, "mode") == "file" then
        -- Already downloaded -- opening it needs no network at all, so this
        -- path stays fully offline-safe (no Wi-Fi auto-connect below). No
        -- hook fires: the caller should treat this exactly like opening any
        -- other on-device book, with no "talking to BookOrbit" message.
        callback(cached)
        return
    end
    -- Everything past this point (fetch detail, download the file) is a
    -- network call. Auto-connect first -- turns Wi-Fi on / reconnects a
    -- saved network, prompting only if none is saved -- instead of the
    -- old behaviour of failing immediately with "offline" while the radio
    -- is simply off.
    local ok_net, NetworkMgr = pcall(require, "ui/network/manager")
    local runWhenOnline = (ok_net and NetworkMgr and NetworkMgr.runWhenOnline)
        and function(fn) NetworkMgr:runWhenOnline(fn) end
        or function(fn) fn() end  -- NetworkMgr unavailable -- fall back to trying directly
    runWhenOnline(function()
        -- finish(path, err): the one place that turns _resolveWork's
        -- result into the caller's callback, common to both the Trapper
        -- and fallback branches below -- persists the download-location
        -- cache entry (this runs in the coroutine/parent process either
        -- way, never inside a forked subprocess, so _dl_settings' cached
        -- table stays consistent -- see dlSettings above) and reports
        -- back.
        local function finish(path, err)
            if not path then
                callback(nil, err)
                return
            end
            s:saveSetting(key, path)
            s:flush()
            callback(path)
        end

        local ok_t, Trapper = pcall(require, "ui/trapper")
        if ok_t and Trapper and Trapper.wrap and Trapper.dismissableRunInSubprocess then
            -- Trapper available: the catalog-detail lookup and (on a
            -- miss) the file download both run inside one dismissable
            -- subprocess -- a slow/unresponsive server on EITHER call no
            -- longer freezes the reader; the user gets a spinner with a
            -- cancel option the whole time instead. This does mean the
            -- spinner now flashes briefly even for an instant dedupe hit
            -- (previously silent) -- a reasonable trade for a hang on
            -- that same "quick" lookup no longer being silent-and-stuck
            -- too. Guarded with isWrapped() so this nests safely if a
            -- future caller already opened its own Trapper:wrap coroutine
            -- around this call, instead of opening a redundant second one.
            local function runProtected()
                local completed, result = Trapper:dismissableRunInSubprocess(function()
                    local ok, path, werr = pcall(_resolveWork, record, nil)
                    if not ok then return { err = tostring(path) } end
                    return { path = path, err = werr }
                end, _("Opening from BookOrbit\xE2\x80\xA6"))
                if not completed then
                    finish(nil, "cancelled")
                    return
                end
                result = result or {}
                finish(result.path, result.err)
            end
            if Trapper:isWrapped() then
                runProtected()
            else
                Trapper:wrap(runProtected)
            end
        else
            -- No Trapper (shouldn't happen inside KOReader, but this
            -- module is require()able standalone too) -- today's plain
            -- blocking behaviour, hooks.on_download_start and all, since
            -- there's no dismissable indicator to lean on instead.
            local path, err = _resolveWork(record, hooks.on_download_start)
            finish(path, err)
        end
    end)
end

return M
