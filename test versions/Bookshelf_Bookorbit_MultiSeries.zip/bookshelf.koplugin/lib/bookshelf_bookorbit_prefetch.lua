--[[--
Non-blocking next-page prefetch for BookOrbit (pure logic, no KOReader dependency).

Problem (see HANDOFF_prefetch_next_page): "Prefetch next page" ran a blocking
list request, one blocking detail request per book and one blocking cover
download per missing cover on the UI thread, 1 s after every page turn, so
page turning felt sluggish. This object only DECIDES WHEN to start the work and
hands it to the machinery that already runs off the UI thread: the forked,
non-urgent page fetcher for the next list, and a forked, download-only cover
pool for its covers. It never decodes a cover and never repaints.

Everything it touches is passed in, so it can be tested off-device with a fake
clock (tools/bo_tests/test_bo_prefetch.lua). NOT wired into the source yet (P2).

  local P = Prefetch.new{
    now = function() return seconds end,                 -- optional
    schedule = function(delay, fn) return handle end,    -- handle must be non-nil
    unschedule = function(handle) end,
    online = function() return bool end,
    settled = function() return bool end,   -- visible list cached AND its covers finished
                                            -- AND no urgent page job (decided by the caller)
    cached = function(id, offset, limit) return bool end,
    records = function(id, offset, limit) return records | nil end,
    request_list = function(id, offset, limit) return
        "queued" | "joined" | "busy" | "failed" | "unavailable" end,   -- NON-urgent
    needs_cover = function(record) return bool end,
    enqueue_covers = function(records, source_id) end,   -- download-only pool
    cancel_covers = function() end,                      -- pending only
    settle_delay = 1.0, step_delay = 0.05, done_max = 64, logger = optional (needs :dbg)
  }

  P:request(id, offset, limit) -> "armed" | "active" | "done" | "invalid"
  P:notify()                   -- something that affects settled() changed
  P:onListReady(key, ok, why)  -- the page fetcher finished a job (any key; others ignored)
  P:supersede()                -- visible page changed / main cover chain started
  P:reset()                    -- shutdown or manual refresh: drop everything, forget done keys
  P:forgetDone(keep_key)       -- forget the done keys ONLY (optionally except one); -> n forgotten
  P:status()                   -- for tests and logs
  Prefetch.keyOf(id, offset, limit)

Rules (decisions D-P1..D-P6):
  * One intent at a time. request() for the intent's own key, or for a key that
    is already done, changes nothing (the widget calls it again on every rebuild).
    A different key REPLACES the intent (the user moved on, even if the new key
    turns out to be done) and cancels the pending prefetch covers of another page. A key whose page is already cached with no cover
    left to fetch is marked done at once.
  * Nothing runs until `settle_delay` after the last arm/notify, and the check is
    re-evaluated when the timer fires: offline drops the intent (no retry);
    not settled waits for the next notify() (no polling loop); settled starts
    step A.
  * Step A: page not cached -> request_list (non-urgent). queued/joined wait
    for onListReady; busy waits for the next notify/request (no job exists);
    failed/unavailable/anything else drops the intent and marks the key done (no
    retry storm). Page cached -> step B.
  * Step B: only records that still need a cover go to enqueue_covers, then the
    key is done. Nothing is decoded or attached to a record by this module.
  * onListReady(ok) schedules step B after `step_delay`, which re-checks online
    and settled() first. A failed list marks the key done; an offline report
    drops the intent without marking it.
  * supersede() drops the pending timer and cancels pending prefetch covers; the
    intent survives (a list request already in the fetcher may finish: it only
    fills the cache) and runs again after the next notify() or request().
  * Callbacks into the deps happen only from timers, except cancel_covers (pending
    work only) and the cheap cached/records look-ups made by request(). request,
    notify, supersede and reset never start a list request or a download.
  * Every dep call is pcall-wrapped; garbage input never throws.
]]

local Prefetch = {}
Prefetch.__index = Prefetch

Prefetch.DEFAULT_SETTLE_DELAY = 1.0
Prefetch.DEFAULT_STEP_DELAY = 0.05
Prefetch.DEFAULT_DONE_MAX = 64

function Prefetch.keyOf(id, offset, limit)
    return tostring(id) .. ":" .. tostring(offset) .. ":" .. tostring(limit)
end

function Prefetch.new(deps)
    deps = deps or {}
    local self = setmetatable({}, Prefetch)
    self.d = deps
    local sd = tonumber(deps.settle_delay)
    self.settle_delay = (sd and sd >= 0) and sd or Prefetch.DEFAULT_SETTLE_DELAY
    local st = tonumber(deps.step_delay)
    self.step_delay = (st and st >= 0) and st or Prefetch.DEFAULT_STEP_DELAY
    self.done_max = math.max(1, math.floor(tonumber(deps.done_max) or Prefetch.DEFAULT_DONE_MAX))
    self.intent = nil          -- { id=, offset=, limit=, key= }
    self.timer = nil           -- handle of the single pending timer
    self.done = {}             -- key -> true
    self.done_order = {}       -- FIFO of done keys
    self.covers_key = nil      -- key whose covers were handed to the download pool
    return self
end

-- Safe call into a dep: never throws. Returns ok, a.
local function call(self, name, ...)
    local fn = self.d[name]
    if type(fn) ~= "function" then return false end
    return pcall(fn, ...)
end

local function dbg(self, ...)
    local lg = self.d.logger
    if lg and lg.dbg then pcall(lg.dbg, ...) end
end

-- Timer (one at a time) ----------------------------------------------------------

function Prefetch:_unsched()
    local h = self.timer
    self.timer = nil
    if h ~= nil then call(self, "unschedule", h) end
end

-- (Re)start the single timer: the last arm/notify wins.
function Prefetch:_sched(delay, fn)
    self:_unsched()
    local intent = self.intent
    local ok, h = call(self, "schedule", delay, function()
        self.timer = nil
        -- A timer that outlived its intent does nothing.
        if self.intent ~= intent or not intent then return end
        fn(self)
    end)
    if ok and h ~= nil then self.timer = h end
end

-- Done set (FIFO) --------------------------------------------------------------------

function Prefetch:_markDone(key)
    if self.done[key] then return end
    self.done[key] = true
    self.done_order[#self.done_order + 1] = key
    while #self.done_order > self.done_max do
        local old = table.remove(self.done_order, 1)
        self.done[old] = nil
    end
end

function Prefetch:_drop(why, markDone)
    local intent = self.intent
    self.intent = nil
    self:_unsched()
    if intent then
        if markDone then self:_markDone(intent.key) end
        dbg(self, "[bookshelf perf] bo prefetch: dropped reason=" .. tostring(why), intent.key)
    end
end

-- Public ---------------------------------------------------------------------------------

function Prefetch:request(id, offset, limit)
    local off, lim = tonumber(offset), tonumber(limit)
    if id == nil or id == "" or not off or not lim or off < 0 or lim <= 0 then return "invalid" end
    local key = Prefetch.keyOf(id, off, lim)

    local intent = self.intent
    if intent and intent.key == key then
        -- Idempotent. A waiting intent (no timer) gets one fresh check, so a
        -- missed notify cannot strand it; a pending timer is left alone.
        if self.timer == nil and not intent.listing then
            self:_sched(self.settle_delay, Prefetch._check)
        end
        return "active"
    end
    -- A different key: the user moved on. The old intent is stale, and so are
    -- the pending covers of another page (this page's own are left alone).
    if intent then
        self.intent = nil
        self:_unsched()
    end
    if self.covers_key and self.covers_key ~= key then
        self.covers_key = nil
        call(self, "cancel_covers")
    end

    if self.done[key] then return "done" end

    -- Already cached and nothing left to download: nothing to do, ever.
    local okc, cached = call(self, "cached", id, off, lim)
    if okc and cached then
        local okr, recs = call(self, "records", id, off, lim)
        if okr and type(recs) == "table" and #self:_wanting(recs) == 0 then
            self:_markDone(key)
            return "done"
        end
    end

    self.intent = { id = id, offset = off, limit = lim, key = key }
    dbg(self, "[bookshelf perf] bo prefetch: armed key=" .. key)
    self:_sched(self.settle_delay, Prefetch._check)
    return "armed"
end

function Prefetch:notify()
    if not self.intent then return end
    self:_sched(self.settle_delay, Prefetch._check)
end

function Prefetch:onListReady(key, ok, why)
    local intent = self.intent
    if not intent or intent.key ~= key then return end   -- not our page
    intent.listing = false
    if not ok then
        -- Offline is not a failure of the page and is not sticky.
        self:_drop(why or "failed", tostring(why) ~= "offline")
        return
    end
    dbg(self, "[bookshelf perf] bo prefetch: list landed ok=true", key)
    self:_sched(self.step_delay, Prefetch._check)
end

function Prefetch:supersede()
    local had = self.timer ~= nil or self.covers_key ~= nil
    self:_unsched()
    if self.covers_key then
        self.covers_key = nil
        call(self, "cancel_covers")
    end
    if had and self.intent then
        dbg(self, "[bookshelf perf] bo prefetch: superseded", self.intent.key)
    end
end

function Prefetch:reset()
    self:_unsched()
    local had_covers = self.covers_key ~= nil
    self.intent = nil
    self.done, self.done_order = {}, {}
    self.covers_key = nil
    if had_covers then call(self, "cancel_covers") end
end

-- Forget the done keys and nothing else (S4b). reset() also drops the intent, the
-- timer and cancels pending covers; this does none of that, so a prefetch that is
-- armed, listing or downloading is untouched. The next request() for a forgotten
-- key looks at its page again: records that want a cover arm it, a page with
-- nothing left to do is marked done at once. `keep_key` (optional) stays done:
-- the caller passes the key whose covers are being downloaded right now, so a
-- rebuild cannot enqueue that page a second time. Returns how many were forgotten.
function Prefetch:forgetDone(keep_key)
    local kept, n = {}, 0
    for _, key in ipairs(self.done_order) do
        if keep_key ~= nil and key == keep_key then
            kept[#kept + 1] = key
        else
            self.done[key] = nil
            n = n + 1
        end
    end
    self.done_order = kept
    return n
end

function Prefetch:status()
    local intent = self.intent
    return {
        armed = intent ~= nil,
        key = intent and intent.key or nil,
        listing = intent ~= nil and intent.listing == true,
        timer = self.timer ~= nil,
        done = #self.done_order,
        covers_key = self.covers_key,
    }
end

-- Steps -------------------------------------------------------------------------------------

-- Records of `recs` that still need a cover (a throwing needs_cover = not wanted).
function Prefetch:_wanting(recs)
    local out = {}
    for _, rec in ipairs(recs) do
        local ok, need = call(self, "needs_cover", rec)
        if ok and need then out[#out + 1] = rec end
    end
    return out
end

-- Timer body: re-evaluate everything at fire time.
function Prefetch:_check()
    local intent = self.intent
    if not intent then return end

    local okn, on = call(self, "online")
    if not (okn and on) then
        self:_drop("offline", false)
        return
    end
    local oks, settled = call(self, "settled")
    if not (oks and settled) then
        -- Wait for the next notify(); no polling loop.
        dbg(self, "[bookshelf perf] bo prefetch: not settled, waiting", intent.key)
        return
    end

    local okc, cached = call(self, "cached", intent.id, intent.offset, intent.limit)
    if okc and cached then
        self:_stepB(intent)
        return
    end

    -- Step A: ask the forked, non-urgent page fetcher for the next list.
    local okr, res = call(self, "request_list", intent.id, intent.offset, intent.limit)
    if not okr then res = "unavailable" end
    dbg(self, "[bookshelf perf] bo prefetch: list requested ->" .. tostring(res), intent.key)
    if res == "queued" or res == "joined" then
        intent.listing = true      -- onListReady (or a later notify) moves on
    elseif res == "busy" then
        intent.listing = false     -- no job exists: the next notify/request tries again
    else
        self:_drop("failed", true)
    end
end

function Prefetch:_stepB(intent)
    local okr, recs = call(self, "records", intent.id, intent.offset, intent.limit)
    self.intent = nil
    self:_unsched()
    self:_markDone(intent.key)
    if not (okr and type(recs) == "table") then
        dbg(self, "[bookshelf perf] bo prefetch: page gone from the cache", intent.key)
        return
    end
    local want = self:_wanting(recs)
    if #want == 0 then
        dbg(self, "[bookshelf perf] bo prefetch: nothing to download", intent.key)
        return
    end
    self.covers_key = intent.key
    dbg(self, "[bookshelf perf] bo prefetch: covers queued n=" .. #want, intent.key)
    call(self, "enqueue_covers", want, intent.id)
end

return Prefetch
