-- bookshelf_bookorbit_cache.lua
--
-- Shared, size-budgeted RAM cache for every BookOrbit browsing section.
--
-- Before this module existed, each section cached differently:
--   * Discover  -- an unbounded table, held forever until an explicit
--                  invalidate/reroll (bookshelf_bookorbit_source.lua's old
--                  _discover_cache).
--   * Book pages (All books/Recently added/Continue reading/Libraries/
--     Collections/Smart scopes/Authors/Series, drilled into a single
--     entry) -- a single TTL'd slot, so only the very last page fetched
--     stayed warm and it expired on its own after 60s.
--   * Author/Series group-tile lists -- one bucket per section, also
--     TTL'd (5 minutes).
--
-- Every one of those now gets Discover's original behaviour instead: held
-- in RAM until explicitly invalidated (a manual refresh, a Discover
-- reroll, etc.), with no time-based expiry -- bounded only by a total
-- byte budget (Settings > BookOrbit > Cache size, default 64MB, 8MB
-- increments) enforced by evicting the LEAST RECENTLY USED entries first.
-- A page or list you keep revisiting stays resident; ones you've moved on
-- from get reclaimed first once the budget is hit.
--
-- "RAM" here means exactly what it meant for the old _discover_cache:
-- plain Lua tables kept alive as this module's upvalues, never written to
-- disk.

local BookshelfSettings = require("lib/bookshelf_settings_store")

local M = {}

local DEFAULT_MB    = 64
local BYTES_PER_MB  = 1024 * 1024

--- maxBytes() -> the current byte budget, read live from Settings > BookOrbit
-- > Cache size every time -- so a change takes effect on the very next
-- set() with no separate "apply" step, the same way _performanceSubItems'
-- cover-cache spinner needs bookshelf_scaled_cover_cache:setByteBudget()
-- called explicitly, except here there's nothing to call.
function M.maxBytes()
    local mb = tonumber(BookshelfSettings.read("bookorbit_cache_mb")) or DEFAULT_MB
    if mb < 0 then mb = 0 end
    return mb * BYTES_PER_MB
end

-- key -> { value = <cached payload>, bytes = <approx size> }
local _entries = {}
-- Ordered list of keys, OLDEST (least recently used) first. A key appears
-- at most once -- touch() below removes any existing occurrence before
-- re-appending, so the tail is always the most-recently-used key.
local _order = {}
local _used_bytes = 0

local function removeFromOrder(key)
    for i = #_order, 1, -1 do
        if _order[i] == key then
            table.remove(_order, i)
            break
        end
    end
end

local function touch(key)
    removeFromOrder(key)
    _order[#_order + 1] = key
end

--- approxSize(value) -> rough byte estimate for `value`, good enough to
-- budget against without the cost (or complexity) of exact accounting.
-- Walks strings/numbers/booleans directly and recurses into nested
-- tables (a record's own sub-tables, e.g. `authors`), with cycle
-- protection. Deliberately never sees a cover_bb: nothing this cache
-- stores carries one -- listBooks()/fetchDiscover()'s records are built
-- by M.toRecord (metadata only), and listGroups() explicitly keeps
-- resolved cover bbs OUT of the cached bucket (see that function's own
-- comment on why a cached bb would go stale/dangling) -- so this never
-- has to reason about blitbuffer memory at all.
local function approxSize(value, seen)
    local t = type(value)
    if t == "string" then return #value + 16 end -- +field/string overhead
    if t == "number" or t == "boolean" or t == "nil" then return 8 end
    if t ~= "table" then return 8 end
    seen = seen or {}
    if seen[value] then return 0 end
    seen[value] = true
    local total = 40 -- table header overhead
    for k, v in pairs(value) do
        total = total + approxSize(k, seen) + approxSize(v, seen)
    end
    return total
end
M.approxSize = approxSize

--- evict() -- drops least-recently-used entries until usage fits the
-- current budget. Called after every set(), so a shrunk Cache size
-- setting takes effect on the very next write.
local function evict()
    local budget = M.maxBytes()
    while _used_bytes > budget and #_order > 0 do
        local oldest = table.remove(_order, 1)
        local e = _entries[oldest]
        if e then
            _used_bytes = _used_bytes - e.bytes
            _entries[oldest] = nil
        end
    end
end

--- get(key) -> value or nil. A hit counts as a use for LRU purposes.
function M.get(key)
    local e = _entries[key]
    if not e then return nil end
    touch(key)
    return e.value
end

--- set(key, value) -- stores `value` under `key`, sized via approxSize.
-- Overwrites any existing entry for the same key (its old size is
-- discarded first, so re-setting a growing bucket -- e.g. the Author/
-- Series walk extending its entries list -- accounts correctly rather
-- than double-counting).
function M.set(key, value)
    local prev = _entries[key]
    if prev then _used_bytes = _used_bytes - prev.bytes end
    local bytes = approxSize(value)
    _entries[key] = { value = value, bytes = bytes }
    _used_bytes = _used_bytes + bytes
    touch(key)
    evict()
end

--- invalidate(key) -- drops one entry, if present.
function M.invalidate(key)
    local e = _entries[key]
    if not e then return end
    _used_bytes = _used_bytes - e.bytes
    _entries[key] = nil
    removeFromOrder(key)
end

--- invalidatePrefix(prefix) -- drops every entry whose key starts with
-- `prefix` (e.g. "discover:", "page:", "group:"), for callers that
-- invalidate a whole family of entries at once (a manual refresh) rather
-- than one specific key.
function M.invalidatePrefix(prefix)
    local doomed = {}
    for key in pairs(_entries) do
        if key:sub(1, #prefix) == prefix then doomed[#doomed + 1] = key end
    end
    for _, key in ipairs(doomed) do M.invalidate(key) end
end

--- invalidateAll() -- drops everything. Not currently wired to a menu
-- action, but available for a future "Clear BookOrbit cache" button --
-- same role bookshelf_scaled_cover_cache:clear() plays for covers.
function M.invalidateAll()
    _entries = {}
    _order = {}
    _used_bytes = 0
end

--- usedBytes() -> current total resident size, for a settings row's
-- status text.
function M.usedBytes()
    return _used_bytes
end

return M
