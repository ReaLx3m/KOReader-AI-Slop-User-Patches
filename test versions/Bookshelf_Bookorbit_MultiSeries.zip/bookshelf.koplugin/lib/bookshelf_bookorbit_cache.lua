-- bookshelf_bookorbit_cache.lua
--
-- Shared, size-budgeted cache for every BookOrbit browsing section.
--
-- Before this module existed, each section cached differently:
--   * Discover  -- an unbounded table, held forever until an explicit
--                  invalidate/reroll (bookshelf_bookorbit_source.lua's old
--                  _discover_cache).
--   * Book pages (All books/Recently added/Continue reading/Libraries/
--     Collections/Smart scopes/Authors/Series, drilled into a single
--     entry) -- a single TTL'd slot, so only the very last page fetched
--     stayed warm and it expired on its own after 60s.
--   * Author/Series group-tile lists -- one bucket per section, also
--     TTL'd (5 minutes).
--
-- Every one of those now gets Discover's original behaviour instead: held
-- in memory until explicitly invalidated, with no time-based expiry --
-- bounded only by a total byte budget (Settings > BookOrbit > Cache size,
-- default 64MB, 8MB increments) enforced by evicting the LEAST RECENTLY
-- USED entries first. A page or list you keep revisiting stays resident;
-- ones you've moved on from get reclaimed first once the budget is hit.
--
-- DISK PERSISTENCE: entries now survive a KOReader restart, in their own
-- settings file (bookshelf_bookorbit_catalog_cache.lua, via
-- lib/bookshelf_file_store.lua -- same mechanism already used for the
-- Hardcover link cache, kept out of the main bookshelf.lua so an ordinary
-- preference save doesn't rewrite a potentially-large blob). Everything
-- (_entries/_order/_used_bytes/_version) is written as ONE key, not one
-- key per cache entry -- a single LuaSettings file is serialised whole on
-- every flush, so one blob is one rewrite instead of N.
--
-- That rewrite is NOT free on e-ink hardware, so it's debounced: normal
-- mutations (set/invalidate) mark the in-memory state dirty and only
-- actually hit disk after FLUSH_MIN_INTERVAL_SECONDS have passed since
-- the last write (checked opportunistically inside evict(), which already
-- runs after every set()). invalidateAll() and a version-mismatch
-- invalidation (see checkVersionAndInvalidate below) flush immediately
-- instead of waiting for the debounce window, since both are rare,
-- deliberate-enough events that losing them to an unclean shutdown before
-- the next debounced flush would be a worse outcome than one extra write.
--
-- VERSION GATING: a cached page's freshness can be checked against
-- BookOrbit's own libraryVersion/manifestVersion token (see
-- BookOrbit.getLibraryVersion() in bookshelf_bookorbit.lua for what that
-- token actually is and where it comes from), but a mismatch no longer
-- wipes anything on its own -- see checkVersionAndInvalidate()'s own doc
-- comment for why. In short: that token is LIBRARY-WIDE, not per-section
-- -- there is no server-side signal for "did THIS chip's contents
-- change", only "did anything accessible to this user change" -- so the
-- only invalidation granularity it could ever drive is "wipe literally
-- everything", which meant one book added anywhere nuked every chip's
-- cache, including chips the user never touched. checkVersionAndInvalidate
-- now just tracks the baseline for diagnostics; actual invalidation is
-- purely manual (bookshelf_widget.lua's swipe-down/swipe-up-while-
-- expanded refresh -- see M.invalidateAll() below) or natural (paging
-- into an offset/section that was never cached always hits the network,
-- version token or not). Cover thumbnails are unaffected either way:
-- they're already versioned individually by each book's own updated_at
-- (see bookshelf_bookorbit_source.lua's coverToken), which is a real
-- per-book signal, so a cover DOES still self-invalidate on its own
-- book's edit regardless of anything in this file.

local BookshelfSettings = require("lib/bookshelf_settings_store")
local FileStore = require("lib/bookshelf_file_store")

local M = {}

local DEFAULT_MB    = 64
local BYTES_PER_MB  = 1024 * 1024

-- Own settings file, same pattern as the Hardcover link cache
-- (bookshelf_settings_store.lua's hc()) -- large/frequently-changing
-- data kept out of the main bookshelf.lua preferences file.
local _store = FileStore.new("bookshelf_bookorbit_catalog_cache.lua")
local STATE_KEY = "cache_state"

-- Debounce window for disk writes triggered by ordinary set()/invalidate()
-- traffic. A chip-open version check or invalidateAll() always flushes
-- immediately regardless of this window (see header comment).
local FLUSH_MIN_INTERVAL_SECONDS = 30

--- maxBytes() -> the current byte budget, read live from Settings > BookOrbit
-- > Cache size every time -- so a change takes effect on the very next
-- set() with no separate "apply" step, the same way _performanceSubItems'
-- cover-cache spinner needs bookshelf_scaled_cover_cache:setByteBudget()
-- called explicitly, except here there's nothing to call.
function M.maxBytes()
    local mb = tonumber(BookshelfSettings.read("bookorbit_cache_mb")) or DEFAULT_MB
    if mb < 0 then mb = 0 end
    return mb * BYTES_PER_MB
end

-- key -> { value = <cached payload>, bytes = <approx size> }
local _entries = {}
-- Ordered list of keys, OLDEST (least recently used) first. A key appears
-- at most once -- touch() below removes any existing occurrence before
-- re-appending, so the tail is always the most-recently-used key.
local _order = {}
local _used_bytes = 0
-- The manifestVersion this cache's contents were last validated against.
-- nil until the first successful checkVersionAndInvalidate() call (or a
-- restored disk state carries one forward from a prior session).
local _version = nil

-- Lazy: the disk file isn't touched until something actually needs it,
-- same "require costs nothing until a key is touched" property
-- bookshelf_file_store.lua already documents for itself.
local _loaded = false
local _last_flush_time = nil

local function osTime()
    local ok, t = pcall(os.time)
    return ok and t or 0
end

--- load() -- restores persisted state on first use. Defensive: any shape
-- mismatch (corrupt file, a future format change, first run ever) just
-- leaves the cache empty rather than erroring -- a cold cache is always a
-- safe fallback, unlike trusting a malformed one.
local function load()
    if _loaded then return end
    _loaded = true
    local ok, state = pcall(function() return _store.read(STATE_KEY, nil) end)
    if not ok or type(state) ~= "table" then return end
    if type(state.entries) == "table" then _entries = state.entries end
    if type(state.order) == "table" then _order = state.order end
    if type(state.used_bytes) == "number" then _used_bytes = state.used_bytes end
    if type(state.version) == "string" then _version = state.version end
end

--- sanitizeForDisk(value, seen) -> a deep copy of `value` safe to hand to
-- LuaSettings for serialisation, with anything that can't survive a
-- Lua-source round trip dropped: userdata/cdata/function/thread (e.g. a
-- book record's decoded cover_bb -- a blitbuffer, C-backed cdata --
-- which bookshelf_bookorbit_source.lua's scheduleCoverFills attaches IN
-- PLACE to the very same record objects a page/group entry was cached
-- with; Lua tables are references, so that mutation reaches this cache's
-- _entries too even though nothing here ever asked for a cover_bb -- see
-- that module's cacheNextPage doc comment for the full chain).
--
-- Also strips each table's own "_cover_filled" key alongside cover_bb/
-- cover_w/cover_h: those four are only ever set together, by the same
-- fillOneCover call, as a unit describing "this record's cover has been
-- decoded into cover_bb". Keeping _cover_filled = true on a disk copy
-- that just had cover_bb (the thing it's a marker FOR) stripped out from
-- under it would restore a record that permanently claims "already
-- filled" with nothing to show for it -- wantsCover()'s anti-loop dedup
-- checks exactly that flag, so scheduleCoverFills would skip queuing it
-- forever, leaving a blank tile no revisit or repaint can self-heal.
-- Dropping all four together instead restores an honest "not decoded
-- yet" record; scheduleCoverFills naturally re-queues it next render,
-- and since the underlying JPEG is still on disk from before, that's a
-- free re-decode (no network) rather than a real re-fetch.
--
-- Has cycle protection (`seen`) for safety, though nothing this cache
-- currently stores is self-referential.
local function sanitizeForDisk(value, seen)
    local t = type(value)
    if t == "string" or t == "number" or t == "boolean" then return value end
    if t ~= "table" then return nil end -- userdata/cdata/function/thread
    seen = seen or {}
    if seen[value] then return nil end
    seen[value] = true
    local out = {}
    for k, v in pairs(value) do
        if k ~= "cover_bb" and k ~= "cover_w" and k ~= "cover_h" and k ~= "_cover_filled" then
            local kt = type(k)
            if kt == "string" or kt == "number" or kt == "boolean" then
                local sv = sanitizeForDisk(v, seen)
                if sv ~= nil then out[k] = sv end
            end
        end
    end
    return out
end

--- persist(force) -- writes current state to disk. Debounced unless
-- force is true (invalidateAll / version-mismatch invalidation / an
-- explicit M.flush() call). Wrapped in pcall: a failed write (full disk,
-- read-only mount) degrades to "cache just doesn't survive a restart
-- this time", not a crash on the render path that called set()/evict().
--
-- Writes a sanitizeForDisk() copy of _entries, NOT _entries itself --
-- the live in-RAM table keeps whatever got aliased into it (cover_bb
-- included) so the in-session reuse cacheNextPage's own doc comment
-- describes (repeated cover-fill-triggered rebuilds served from RAM
-- instead of re-fetching) is completely unaffected; only what actually
-- reaches disk is stripped.
local function persist(force)
    local now = osTime()
    if not force and _last_flush_time and (now - _last_flush_time) < FLUSH_MIN_INTERVAL_SECONDS then
        return
    end
    _last_flush_time = now
    pcall(function()
        _store.save(STATE_KEY, {
            entries    = sanitizeForDisk(_entries),
            order      = _order,
            used_bytes = _used_bytes,
            version    = _version,
        })
    end)
end

--- flush() -- force an immediate disk write regardless of the debounce
-- window. Exposed for a caller that knows a natural session boundary is
-- happening (e.g. leaving a BookOrbit chip, or KOReader suspending) and
-- wants to make sure the latest state survives it. Not required for
-- correctness -- the debounce in persist() means a crash can only lose
-- at most FLUSH_MIN_INTERVAL_SECONDS of cache mutations, never corrupt
-- anything -- so callers are free to not bother with this.
function M.flush()
    load()
    persist(true)
end

local function removeFromOrder(key)
    for i = #_order, 1, -1 do
        if _order[i] == key then
            table.remove(_order, i)
            break
        end
    end
end

local function touch(key)
    removeFromOrder(key)
    _order[#_order + 1] = key
end

--- approxSize(value) -> rough byte estimate for `value`, good enough to
-- budget against without the cost (or complexity) of exact accounting.
-- Walks strings/numbers/booleans directly and recurses into nested
-- tables (a record's own sub-tables, e.g. `authors`), with cycle
-- protection. Deliberately never sees a cover_bb: nothing this cache
-- stores carries one -- listBooks()/fetchDiscover()'s records are built
-- by M.toRecord (metadata only), and listGroups() explicitly keeps
-- resolved cover bbs OUT of the cached bucket (see that function's own
-- comment on why a cached bb would go stale/dangling) -- so this never
-- has to reason about blitbuffer memory at all. The same "plain data
-- only, no functions/userdata/cycles" property is also what makes every
-- cached value safe to hand to LuaSettings for disk serialisation.
local function approxSize(value, seen)
    local t = type(value)
    if t == "string" then return #value + 16 end -- +field/string overhead
    if t == "number" or t == "boolean" or t == "nil" then return 8 end
    if t ~= "table" then return 8 end
    seen = seen or {}
    if seen[value] then return 0 end
    seen[value] = true
    local total = 40 -- table header overhead
    for k, v in pairs(value) do
        total = total + approxSize(k, seen) + approxSize(v, seen)
    end
    return total
end
M.approxSize = approxSize

--- evict() -- drops least-recently-used entries until usage fits the
-- current budget. Called after every set(), so a shrunk Cache size
-- setting takes effect on the very next write. Also where the debounced
-- disk flush is opportunistically attempted, since evict() already runs
-- on every mutation.
local function evict()
    local budget = M.maxBytes()
    while _used_bytes > budget and #_order > 0 do
        local oldest = table.remove(_order, 1)
        local e = _entries[oldest]
        if e then
            _used_bytes = _used_bytes - e.bytes
            _entries[oldest] = nil
        end
    end
    persist(false)
end

--- get(key) -> value or nil. A hit counts as a use for LRU purposes.
function M.get(key)
    load()
    local e = _entries[key]
    if not e then return nil end
    touch(key)
    return e.value
end

--- set(key, value) -- stores `value` under `key`, sized via approxSize.
-- Overwrites any existing entry for the same key (its old size is
-- discarded first, so re-setting a growing bucket -- e.g. the Author/
-- Series walk extending its entries list -- accounts correctly rather
-- than double-counting).
function M.set(key, value)
    load()
    local prev = _entries[key]
    if prev then _used_bytes = _used_bytes - prev.bytes end
    local bytes = approxSize(value)
    _entries[key] = { value = value, bytes = bytes }
    _used_bytes = _used_bytes + bytes
    touch(key)
    evict()
end

--- invalidate(key) -- drops one entry, if present.
function M.invalidate(key)
    load()
    local e = _entries[key]
    if not e then return end
    _used_bytes = _used_bytes - e.bytes
    _entries[key] = nil
    removeFromOrder(key)
    persist(false)
end

--- invalidatePrefix(prefix) -- drops every entry whose key starts with
-- `prefix` (e.g. "discover:", "page:", "group:"), for callers that
-- invalidate a whole family of entries at once (a manual refresh) rather
-- than one specific key.
function M.invalidatePrefix(prefix)
    load()
    local doomed = {}
    for key in pairs(_entries) do
        if key:sub(1, #prefix) == prefix then doomed[#doomed + 1] = key end
    end
    for _, key in ipairs(doomed) do M.invalidate(key) end
end

--- invalidateAll() -- drops everything. Available for a future "Clear
-- BookOrbit cache" button (same role bookshelf_scaled_cover_cache:clear()
-- plays for covers) and used internally by checkVersionAndInvalidate()
-- on a version mismatch. Flushes immediately (force=true): a deliberate
-- "start clean" moment is exactly the case where losing the clear to an
-- unclean shutdown before the debounce window elapses would be
-- surprising (a stale page could reappear after a crash right after the
-- user asked to clear the cache).
function M.invalidateAll()
    load()
    _entries = {}
    _order = {}
    _used_bytes = 0
    persist(true)
end

--- usedBytes() -> current total resident size, for a settings row's
-- status text.
function M.usedBytes()
    load()
    return _used_bytes
end

--- checkVersionAndInvalidate(new_version) -> "kept" | "changed" | "skipped"
--
-- Call this once per chip-open (see bookshelf_bookorbit_source.lua),
-- passing the result of BookOrbit.getLibraryVersion(). Three outcomes:
--
--   * new_version is nil (the version-check call itself failed --
--     offline, timeout, server error): FAIL OPEN. Do nothing, keep
--     whatever's cached, return "skipped". A network hiccup on the
--     version-check must never be treated as "the cache is stale" --
--     that would throw away perfectly good cached pages (and force a
--     full re-fetch that's *also* going to fail, being offline) for no
--     reason connected to whether anything actually changed.
--   * new_version equals the stored _version: nothing changed since last
--     validated. Return "kept" (no disk write needed -- nothing moved).
--   * new_version differs from a previously-stored _version (including
--     _version being nil, i.e. this is the first successful check this
--     session/install has ever done): something changed somewhere in the
--     user's accessible libraries (the token carries no detail about
--     what/where -- see header comment). Store the new baseline and
--     return "changed" -- but do NOT wipe anything.
--
-- Deliberately does not invalidate on a detected change. The token is a
-- single library-wide "something changed" flag with no detail about
-- WHAT or WHERE (no per-book/per-section delta is available -- see the
-- header comment), so there's no way to merge in "just the new book" or
-- selectively drop only the affected page -- the only two options are
-- "wipe literally everything" or "wipe nothing and let it settle
-- naturally." Wiping everything on every detected change (the original
-- design) meant one added book anywhere nuked every chip's cache
-- indiscriminately -- Authors, Series, chips you never touched -- turning
-- a single addition into a full cold-start across the whole shelf. This
-- keeps serving what's cached instead: a chip's own natural pagination
-- (browsing to an offset that was never fetched) still hits the network
-- and returns genuinely current data as always, since that was never
-- gated on the version token to begin with -- only a page/section you'd
-- ALREADY cached keeps showing what it showed before, until:
--   (a) it's evicted for space or aged out by a future TTL, or
--   (b) the user manually refreshes (bookshelf_widget.lua's swipe-down/
--       swipe-up-while-expanded refresh, which calls invalidateAll() /
--       the per-family invalidate*Cache() calls directly, unconditional
--       and independent of this version token).
-- The new baseline is still adopted either way (see below) so a later
-- check against a THIRD version can tell "changed again" from "back to
-- what changeset the last check saw" -- this function's role is now
-- purely "track whether server state has moved," not "decide when to
-- forget things."
function M.checkVersionAndInvalidate(new_version)
    load()
    if new_version == nil then
        return "skipped"
    end
    if new_version == _version then
        return "kept"
    end
    local changed = _version ~= nil
    -- Adopt the new baseline regardless of whether this is the very
    -- first check (_version was nil) or a real change from a prior one --
    -- either way nothing gets wiped, so there's no "first check" special
    -- case left to reason about the way there used to be.
    _version = new_version
    persist(true)
    return changed and "changed" or "kept"
end

--- currentVersion() -> the manifestVersion this cache's contents are
-- currently validated against, or nil if never checked. For diagnostics
-- (e.g. a future "Sync status" row) -- not required for normal operation.
function M.currentVersion()
    load()
    return _version
end

return M
