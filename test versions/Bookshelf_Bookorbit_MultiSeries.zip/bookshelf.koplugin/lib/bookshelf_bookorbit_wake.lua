--[[--
Pull on wake (Batch 6B): when the device wakes with a book open and "Pull progress
on wake" (an Auto Wi-Fi option) is on, bring Wi-Fi up quietly, ask BookOrbit for its place and, if another
device has written one we have not weighed, offer it through the same
notice/prompt pull-on-open uses ("jump to newer place?").

Decisions (HANDOFF section 2a):
  D17  second step after the pull-before-push guard; quiet connect through
       the controller (restoreWifiAsync path), then pull + compare.
  D18  NO minimum-sleep rule. Every wake with a book open pulls, however
       short the sleep (battery cost is documented). The only de-duplication
       is for the SAME wake: KOReader can broadcast both Resume and
       LeaveStandby, so an in-flight flag plus a few seconds of cooldown
       after the pull resolves make one wake pull once.
  D19  only when "Pull progress on wake" is on (an Auto Wi-Fi sub-setting,
       so Auto Wi-Fi is on too), BookOrbit is configured and auto-sync is
       on. With "Disconnect Wi-Fi when book is opened" the radio goes off
       again as soon as the pull resolves (lease release); without it Wi-Fi
       stays on, as it does in a book today.
  D20  a wake with a book open is an explicit trigger: it clears a manual
       Wi-Fi off (and the controller's "sleeping" state).
  D21  a failed pull (out of range, timeout, error) is quiet: no notice, the
       local place is kept. The guard (6A) protects the next push.

Compare: the shared pull-before-push guard (`checkServerBeforePush`), NOT a
second definition of "ahead". It already knows "same install", "same place",
"unchanged since weighed" and the user's "stay" strategy. On "ahead" the
place is handed to `offer` (Bookshelf:_boOfferRemote), which also records it
as weighed, whatever the user answers (D23).

Ordering rules:
  * Never starts while a gesture-unlock lock screen is waiting
    (Device.screen_saver_lock): a prompt painted over it can leave the device
    stuck (issue #84). It polls every RETRY_SECS (max MAX_TRIES) and runs
    after unlock.
  * Never starts while a sleep-sync lease is still held (controller reports
    `sleeping` with leases > 0): a wake right after pressing sleep must not
    race the sleep push or leave Wi-Fi on behind it. Same polling.
  * Never starts while the reader is still opening: the place is not weighed
    yet (`target()` returns nil until it is), pull-on-open owns that pull.

Everything is injected so the logic runs off-device (test_bo_wake.lua).
Not run on a device.
]]

local Wake = {}
Wake.__index = Wake

Wake.COOLDOWN  = 3    -- seconds after a pull resolved in which a second wake event is the same wake
Wake.RETRY_SECS = 2   -- poll interval while locked / sleep sync still running
Wake.MAX_TRIES = 15   -- 30 s, then give up quietly

--- deps = {
---   bookorbit = BookOrbit-like (isConfigured, autoSyncEnabled, autoWifiPullOnWake,
---               getBookHash, checkServerBeforePush, submitSyncJob),
---   wifi      = controller (trigger, status, acquire, release),
---   ui        = scheduler (scheduleIn, unschedule, nextTick),
---   device    = Device-like (screen_saver_lock), optional,
---   now       = function() -> seconds (default os.time),
---   target    = function() -> fp, pct, pos   (the open, WEIGHED book; nil otherwise),
---   offer     = function(fp, remote, done)   (Bookshelf:_boOfferRemote),
---   same_book = function(fp) -> bool         (the same book is still open),
---   logger    = optional,
--- }
function Wake.new(deps)
    local self = setmetatable({}, Wake)
    self.d = deps
    self.pending = false      -- a wake pull is waiting or running
    self.done_at = nil        -- time the last pull resolved
    self.task = nil           -- scheduled poll
    self.stats = { started = 0, offered = 0, failed = 0, skipped = 0 }
    return self
end

function Wake:_log(level, ...)
    local lg = self.d.logger
    if lg and lg[level] then pcall(lg[level], ...) end
end

function Wake:_now()
    return (self.d.now or os.time)()
end

-- Settings gate (D19). Returns true when a wake pull makes sense at all.
function Wake:_enabled()
    local bo = self.d.bookorbit
    -- autoWifiPullOnWake() is already "Auto Wi-Fi on AND the wake switch on".
    return (bo.autoWifiPullOnWake and bo.autoWifiPullOnWake())
        and (bo.isConfigured and bo.isConfigured())
        and (bo.autoSyncEnabled and bo.autoSyncEnabled()) and true or false
end

function Wake:_finish()
    self.pending = false
    self.done_at = self:_now()
    self.task = nil
end

--- Drop any waiting poll (Suspend: the device is going to sleep again).
function Wake:cancel()
    if self.task then pcall(self.d.ui.unschedule, self.d.ui, self.task) end
    self.task = nil
    self.pending = false
end

--- A wake event arrived (Resume or LeaveStandby). Returns a status string:
--- "disabled" | "no_book" | "duplicate" | "started".
function Wake:onWake()
    if self.pending then return "duplicate" end
    if self.done_at and (self:_now() - self.done_at) < Wake.COOLDOWN then
        return "duplicate"          -- the other wake event of the same wake
    end
    if not self:_enabled() then return "disabled" end
    if not self.d.target() then return "no_book" end
    self.pending = true
    self.stats.started = self.stats.started + 1
    -- Let the wake handler return first (repaint etc.); the work starts on
    -- the next tick.
    self.d.ui:nextTick(function() self:_step(0) end)
    return "started"
end

-- One attempt to start; re-polls while locked or while a sleep sync runs.
function Wake:_step(tries)
    self.task = nil
    if not self.pending then return end          -- cancelled
    local d = self.d
    -- Settings or book may have changed while we waited.
    local fp, pct, pos = d.target()
    if not (fp and self:_enabled()) then return self:_finish() end

    local locked = d.device and d.device.screen_saver_lock
    local st = d.wifi:status()
    local sleep_busy = st and st.sleeping and (st.leases or 0) > 0
    if locked or sleep_busy then
        if tries >= Wake.MAX_TRIES then
            self.stats.skipped = self.stats.skipped + 1
            self:_log("dbg", "[bookshelf] wake pull: gave up waiting (locked/sleep sync)")
            return self:_finish()
        end
        self.task = function() self:_step(tries + 1) end
        d.ui:scheduleIn(Wake.RETRY_SECS, self.task)
        return
    end

    -- D20: explicit trigger (clears a manual off and the sleeping state).
    -- With "Disconnect Wi-Fi when book is opened" this only reconciles (the
    -- target stays off); the lease below brings the radio up for the pull.
    pcall(d.wifi.trigger, d.wifi, "wake_book")

    local bo = d.bookorbit
    local hash = bo.getBookHash and bo.getBookHash(fp)
    local lease
    local released = false
    -- Idempotent; also the job's cleanup so the lease cannot leak when the
    -- coordinator drops the job or it throws (batch 3 rule).
    local function afterDone()
        if released then return end
        released = true
        if lease then d.wifi:release(lease) end
    end
    local function resolved()
        afterDone()
        self:_finish()
    end

    lease = d.wifi:acquire("pull_on_wake",
        function()
            local job = {
                family  = "progress:" .. (hash or fp),
                label   = "pull progress (on wake)",
                cleanup = resolved,
                run = function()
                    -- BLOCKING (inside the sync job). Same decision as the
                    -- push guard: "ahead" = another device wrote a place we
                    -- have not weighed (and the user's strategy does not say
                    -- "stay").
                    local ok, verdict, remote = pcall(bo.checkServerBeforePush, fp, pct, pos)
                    -- Radio can go back off before any prompt is shown.
                    afterDone()
                    if ok and verdict == "ahead" and remote then
                        self.stats.offered = self.stats.offered + 1
                        d.ui:nextTick(function()
                            if d.same_book(fp) then
                                d.offer(fp, remote, function() self:_finish() end)
                            else
                                self:_finish()
                            end
                        end)
                    else
                        if not (ok and verdict ~= "unknown") then
                            self.stats.failed = self.stats.failed + 1   -- D21: quiet
                        end
                        self:_finish()
                    end
                end,
            }
            local ok_s, err = pcall(bo.submitSyncJob, job)
            if not ok_s then
                self:_log("warn", "[bookshelf] wake pull: submit failed:", err)
                resolved()
            end
        end,
        function(err)
            -- D21: out of range / timeout / manual off: quiet.
            self.stats.failed = self.stats.failed + 1
            self:_log("dbg", "[bookshelf] wake pull: Wi-Fi did not come up (" .. tostring(err) .. ")")
            self:_finish()
        end,
        { timeout = Wake.CONNECT_TIMEOUT, trigger = true })

    -- on_ready may already have run and finished before acquire returned.
    if released and lease then d.wifi:release(lease) end
end

Wake.CONNECT_TIMEOUT = 25   -- seconds: one steady-state attempt window

return Wake
