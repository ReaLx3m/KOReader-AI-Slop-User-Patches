-- bookshelf_sort_engine.lua
-- Pure-function multi-key sort over a list of book records.
-- A "priority" is an ordered list of { key = <string>, reverse = <bool> } entries.
-- The first key compares; if equal, the next key compares; and so on.

local _ok = pcall(require, "lib/bookshelf_i18n")  -- soft: tests stub-load without it
local i18n = package.loaded["lib/bookshelf_i18n"]
-- A require that FAILED under LuaJIT (which is what KOReader runs) leaves a
-- sentinel value -- a garbage number, not nil -- in package.loaded. Reading it
-- as a module then crashes tr() on its first call, which is the opposite of the
-- soft degrade intended above.
if type(i18n) ~= "table" then i18n = nil end
local function tr(s) if i18n and i18n.gettext then return i18n.gettext(s) end; return s end

local ok, AuthorName = pcall(require, "lib/bookshelf_author_name")
if not ok then AuthorName = nil end

-- Optional pinyin collation (issue #43). When the "cjk_pinyin_sort"
-- setting is on, every cached sort key passes through Pinyin.key(), which
-- rewrites Han characters to their toneless Mandarin syllables so CJK
-- titles and authors interleave with Latin ones ("liu" files under L).
-- Off (the default), CJK strings keep raw codepoint order, which is
-- approximately radical/stroke order. Both requires are soft: the
-- standalone test harness preloads stubs, and a missing module just
-- means the feature stays off.
local ok_store, Store = pcall(require, "lib/bookshelf_settings_store")
if not ok_store then Store = nil end
local ok_pinyin, Pinyin = pcall(require, "lib/bookshelf_pinyin")
if not ok_pinyin then Pinyin = nil end

local SortEngine = {}

-- Sort keys are memoized on the records themselves (see cachedSurname
-- etc.), so flipping the pinyin toggle must invalidate every record's
-- cached keys -- including records the settings UI can't reach. Epoch
-- counter: refreshPinyinFlag() bumps _key_epoch when the effective flag
-- changes, and ensureEpoch(b) lazily wipes a record's caches the first
-- time it's touched under a new epoch. The settings read itself is
-- memoized against Store.generation() so the per-sort cost is one
-- integer compare, not a settings lookup per comparison.
local _pinyin_on  = false
local _pinyin_gen = -1
local _key_epoch  = 0
-- "Ignore The, A, An when sorting" (issue 428). On by default, which is how
-- titles and series have sorted since 120960a / issue 412; off sorts by the
-- title and series name exactly as written, calibre's title_sort included.
-- Rides the same epoch as the pinyin flag, for the same reason: the keys it
-- changes are memoised on every record.
local _articles_on = true

local function refreshPinyinFlag()
    if not Store then return end
    local gen = Store.generation()
    if gen == _pinyin_gen then return end
    _pinyin_gen = gen
    local on = Pinyin ~= nil and Store.read("cjk_pinyin_sort") == true
    local articles = Store.read("sort_ignore_articles") ~= false
    if on ~= _pinyin_on or articles ~= _articles_on then
        _pinyin_on = on
        _articles_on = articles
        _key_epoch = _key_epoch + 1
    end
end

-- keySignature() -> a short string naming every setting that changes how a
-- sort KEY is derived (pinyin, the leading-article rule). Sort LEVELS are
-- the caller's own and already in its cache keys; these are not, so a cache
-- of sorted results that left them out went on serving the old order after
-- the setting changed -- until something else invalidated it.
function SortEngine.keySignature()
    refreshPinyinFlag()
    return (_pinyin_on and "P" or "") .. (_articles_on and "" or "W")
end

local function ensureEpoch(b)
    if b._key_epoch ~= _key_epoch then
        b._key_epoch          = _key_epoch
        b._surname_cache      = nil
        b._given_cache        = nil
        b._title_key_cache    = nil
        b._filename_key_cache = nil
        b._series_key_cache   = nil
    end
end

-- Applied at cache-store time, so the conversion runs once per record,
-- not once per comparison. The \1 check makes a double application a
-- no-op (keys already carry the \1 tie-break separator).
local function pinyinise(s)
    if not _pinyin_on then return s end
    if type(s) ~= "string" or s == "" then return s end
    if s:find("\1", 1, true) then return s end
    if not Pinyin.hasHan(s) then return s end
    return Pinyin.key(s)
end

-- Order ranks used by the two read_status comparators.
--   _PROGRESS: natural progression -- TBR first, finished last.
--   _ACTIVE:   what-am-I-reading-now first; unread next; finished last.
-- on_hold sits third in both -- shelved books are below active reading but
-- above already-read.
--
-- Both vocabularies are present: bookshelf's normalised names (unread,
-- on_hold, finished) AND KOReader's raw values that may leak through from
-- DocSettings without normalisation ("new", "abandoned", "complete"), so a
-- comparator called against either shape resolves to the right rank.
-- Issue #41: with only the bookshelf names, raw "complete"/"abandoned"
-- values mapped to nil and dropped to the catch-all 99 ("no metadata"),
-- placing finished/on-hold books at the END of the read_status sort.
local STATUS_RANK_PROGRESS = {
    unread = 1, ["new"] = 1,
    reading = 2,
    on_hold = 3, abandoned = 3,
    finished = 4, complete = 4,
}
local STATUS_RANK_ACTIVE   = {
    reading = 1,
    unread = 2, ["new"] = 2,
    on_hold = 3, abandoned = 3,
    finished = 4, complete = 4,
}

-- isFavourite(item) -> the book is in KOReader's default "favorites"
-- collection. A plain table lookup on ReadCollection.coll (the same check the
-- spine shelf and the favourite token make), so it is cheap enough to run on
-- every one of the comparator's ~n*log(n) calls. Without ReadCollection (the
-- standalone test harness) nothing is a favourite.
local function isFavourite(item)
    local fp = type(item) == "table" and item.filepath
    if not fp then return false end
    local ok, rc = pcall(require, "readcollection")
    return ok and type(rc) == "table" and type(rc.coll) == "table"
        and type(rc.coll.favorites) == "table"
        and rc.coll.favorites[fp] ~= nil or false
end
SortEngine.isFavourite = isFavourite

-- nil-safe comparator helper. Returns -1, 0, +1 so it composes cleanly.
-- nil always sorts to the end (higher sort order).
-- Sentinel return values for nil-handling. The chainedComparator detects
-- these and short-circuits BEFORE applying level.reverse, so missing
-- values always sort to the end regardless of ascending / descending
-- direction. Without this, reverse-sort puts nils at the start, which
-- gives users a confusing first page of "no metadata" entries.
local SORT_TO_END   = "__sort_to_end__"   -- a (or both sides) missing -> a after b
local SORT_TO_START = "__sort_to_start__" -- only b missing            -> a before b

local function isMissing(v)
    return v == nil or v == ""
end

-- pageCountOf(item) -> the count the Pages sort orders by.
--
-- Reddit report: "I'd like to have a chip that sorts books by length, but it
-- doesn't appear that it works with the extracted numbers." Most sort paths
-- hand the comparator light records, which carry no count for a reflowable
-- book, and the one that backfills skips books with no sidecar -- exactly the
-- never-opened books "Extract page counts" is for. So a record with no count
-- of its own asks the repository's resolver (installed by
-- bookshelf_book_repository, which this module must not require), once per
-- record: the comparator runs n log n times. clearPageCountMemo() drops the
-- answers when the counts change.
local _page_memo = setmetatable({}, { __mode = "k" })
local _page_resolver = nil

function SortEngine.setPageCountResolver(fn) _page_resolver = fn end
function SortEngine.clearPageCountMemo() _page_memo = setmetatable({}, { __mode = "k" }) end

function SortEngine.pageCountOf(item)
    if type(item) ~= "table" then return nil end
    local v = item.page_count or item.total_pages
    if v ~= nil or not _page_resolver or not item.filepath then return v end
    local m = _page_memo[item]
    if m == nil then
        local ok, n = pcall(_page_resolver, item.filepath)
        m = (ok and tonumber(n)) or false
        _page_memo[item] = m
    end
    return m or nil
end

local function cmp(a, b)
    local am, bm = isMissing(a), isMissing(b)
    if am and bm then return 0              end
    if am          then return SORT_TO_END   end
    if bm          then return SORT_TO_START end
    if a == b      then return 0             end
    if a < b       then return -1            end
    return 1
end

-- Natural ("Vol 2" before "Vol 10") less-than. Reuses KOReader's own
-- sort.natsort_cmp so name/title ordering matches the native file browser
-- (issue #104). The comparator is built ONCE, module-level, with a
-- persistent conversion cache: natsort_cmp massages each distinct string
-- once and memoizes it, where the old per-comparison fallback re-converted
-- both sides on every one of the ~n*log(n) table.sort calls. (KOReader
-- removed the bare `sort.natsort` in PR #10023, so the previous
-- `_KSort.natsort` guard never fired and EVERY sort silently ran the
-- expensive uncached fallback. The fallback now exists only for the
-- standalone test harness, where the runtime module isn't on package.path.)
-- natsort is case-sensitive, so callers lowercase first to keep sorting
-- case-insensitive (same as the plain cmp path did).
local _ok_natsort, _KSort = pcall(require, "sort")
local _natsort
if _ok_natsort and type(_KSort) == "table" then
    if type(_KSort.natsort_cmp) == "function" then
        _natsort = _KSort.natsort_cmp()       -- comparator + persistent cache
    elseif type(_KSort.natsort) == "function" then
        _natsort = _KSort.natsort             -- pre-2023.02 KOReader
    end
end
local function natLess(a, b)
    if _natsort then return _natsort(a, b) end
    local function pad(d)
        local dec, n = d:match("(%.?)0*(.+)")
        return #dec > 0 and ("%.12f"):format(d) or ("%s%03d%s"):format(dec, #n, n)
    end
    return (a:gsub("%.?%d+", pad)) .. ("%3d"):format(#b)
         < (b:gsub("%.?%d+", pad)) .. ("%3d"):format(#a)
end

-- Natural-order variant of cmp: identical nil/missing handling (so it
-- composes in chainedComparator), but digit runs compare numerically.
local function natCmp(a, b)
    local am, bm = isMissing(a), isMissing(b)
    if am and bm then return 0              end
    if am          then return SORT_TO_END   end
    if bm          then return SORT_TO_START end
    if a == b      then return 0             end
    return natLess(a, b) and -1 or 1
end

-- effective_percent(book): treat "finished" as 1.0 regardless of stored value.
-- Fixes the issue where books marked finished but at 99% still show as < 100%.
-- Also handles lfs-entry shape: _pct / _status instead of percent_finished / read_status.
--
-- Unread books (no sidecar -> nil status, nil pct OR "new" status) get 0.0
-- explicitly. Without this they returned nil and the chained cmp's
-- SORT_TO_END sentinel pushed them to the end regardless of direction,
-- so the "Unread first" sort put them last. (Issue #41.)
local function effective_percent(b)
    local status = b.read_status or b._status
    if status == "finished" or status == "complete" then return 1.0 end
    if status == nil or status == "new" or status == "unread" then return 0 end
    return b.percent_finished or b._pct
end

-- Exported because a surface that SHOWS a reading percentage has to show the
-- number this sort orders by. Rendering 99% next to a "finished" book the sort
-- has already promoted to the top of the page is its own bug, and a second
-- copy of the rule elsewhere is how that would happen. A caller normalises its
-- record onto the two field names read above before calling in.
SortEngine.effectivePercent = effective_percent

-- The author a GROUP sorts under, taken from its MEMBERS.
--
-- A series stack carries its books but no author of its own, so the fallback
-- chain below used to reach b.series_name -- the SERIES TITLE -- and hand it
-- to surnameSortKey, which duly parsed the last word of the title as a
-- person's surname. "Sort by author surname" on a series shelf therefore
-- ordered by the last word of each series name (issue #351).
--
-- The MODAL author, not the first. A series with a guest collaborator on one
-- volume should still sort under whoever wrote the rest, and taking books[1]
-- would make the answer depend on the order the members happen to be in.
-- First-seen wins a tie, so the result is stable rather than pairs()-dependent.
--
-- Author cards do NOT take this path: a member's `author` field is the
-- book's FIRST author, so on a co-authored book the modal member author is
-- the wrong person for every card but the first author's (the second
-- author's card sorted under the first author's surname, right beside it).
-- Author shapes therefore carry the card's own name as `author`, which the
-- fallback chain prefers over this function. Genre and collection cards
-- change from "the genre name parsed as a surname" to "the modal author of
-- its books", which is a different arbitrary answer to a question that has
-- no meaningful one; neither orders genres usefully.
local function groupAuthor(b)
    -- BOTH member field names. A live group carries `books`; the SERIES shape
    -- that is cached and handed to the comparator carries `books_meta`, which
    -- is a different rebuild of the same list. Reading only `books` meant this
    -- returned nil for exactly the shelf the issue was about.
    local books = b.books or b.books_meta
    if type(books) ~= "table" or #books == 0 then return nil end
    local counts, order = {}, {}
    for i = 1, #books do
        local m = books[i]
        -- One field per member, in the same preference order the record-level
        -- chain uses, so a library that carries author_sort everywhere does not
        -- split one author across two spellings of the same name.
        local a = type(m) == "table"
                  and (m.author_sort or m.author or m.authors) or nil
        if type(a) == "string" and a ~= "" then
            if counts[a] == nil then
                counts[a] = 0
                order[#order + 1] = a
            end
            counts[a] = counts[a] + 1
        end
    end
    local best, best_n = nil, 0
    for i = 1, #order do
        local a = order[i]
        if counts[a] > best_n then best, best_n = a, counts[a] end
    end
    return best
end

-- Memoized surname / given lookup. Caches on the record so a sort over
-- 3000 books does 3000 parses, not ~35000 (one per comparison pair).
--
-- Source order:
--   1. b.author_sort           -- Calibre-curated sort form. "Surname,
--                                 Forename" (single) or "Surname1, F1 &
--                                 Surname2, F2" (multi). Honours user
--                                 edits to particles ("St. Crowe", "van
--                                 der"), suffixes, inverted-naming
--                                 cultures, etc. Strictly the right
--                                 answer when present.
--   2. b.author / b.authors    -- BIM or Calibre author metadata --
--                                 surnameOf parses the last token as the
--                                 surname; falls down on the cases
--                                 author_sort covers, but it's all we
--                                 have for non-Calibre libraries.
--   3. b.author_surname        -- pre-parsed surname (rarely set)
--   4. groupAuthor(b)          -- a GROUP's modal member author. Above
--                                 series_name because a series stack's name
--                                 is a TITLE, not a person (issue #351).
--   5. b.series_name           -- group shape (Authors / Genres tab)
--   6. b.name                  -- lfs entry (Home folder cards, where the
--                                 folder name IS the author identifier)
--
-- Parent-folder name is NOT a fallback for book files: the flat library
-- view should respect BIM/Calibre author metadata only, not synthesise
-- author from folder structure. Books without metadata tie at "" which
-- is the honest signal.
local function cachedSurname(b)
    ensureEpoch(b)
    if b._surname_cache ~= nil then return b._surname_cache end
    -- Prefer Calibre's curated author_sort over derived surname.
    if type(b.author_sort) == "string" and b.author_sort ~= "" then
        -- "Surname1, F1 & Surname2, F2" -> first author -> surname.
        local first = b.author_sort:match("^([^&]+)") or b.author_sort
        local surname = first:match("^([^,]+)") or first
        surname = surname:gsub("^%s+", ""):gsub("%s+$", "")
        if surname ~= "" then
            b._surname_cache = pinyinise(surname:lower())
            return b._surname_cache
        end
    end
    local raw = b.author or b.authors or b.author_surname
             or groupAuthor(b)
             or b.series_name or b.name or ""
    if type(raw) ~= "string" then raw = "" end
    -- surnameSortKey strips leading particles ("de Maupassant" sorts
    -- under M, not D) so the alphabetical position matches the user's
    -- mental model of where the surname lives. surnameOf KEEPS the
    -- particle for display.
    local s
    if AuthorName and AuthorName.surnameSortKey then
        s = AuthorName.surnameSortKey(raw)
    elseif AuthorName then
        s = AuthorName.surnameOf(raw):lower()
    else
        s = raw:lower()
    end
    b._surname_cache = pinyinise(s)
    return b._surname_cache
end

-- See cachedSurname for the rationale on each fallback rung. Same chain
-- here so the two comparators stay consistent.
local function cachedGiven(b)
    ensureEpoch(b)
    if b._given_cache ~= nil then return b._given_cache end
    local raw = b.author or b.authors or b.author_name
             or groupAuthor(b)
             or b.series_name or b.name or ""
    if type(raw) ~= "string" then raw = "" end
    local s = AuthorName and AuthorName.givenOf(raw) or raw
    b._given_cache = pinyinise(s:lower())
    return b._given_cache
end

-- Memoized lowercased sort keys, cached on the record like _surname_cache.
-- table.sort runs a comparator ~n*log(n) times; without these the title /
-- filename / series comparators allocated two fresh lowered strings on
-- every call (~2500 at 300 books, ~35000 at 3000). `false` marks "derived,
-- and missing" so absent values are also only derived once; callers turn it
-- back into nil with `or nil` for cmp/natCmp's missing-value sentinels.
-- Safe to cache on the record: hydration (including Hardcover
-- applyMetadata's title/series overrides) finishes before any sort runs,
-- and records are rebuilt whenever metadata changes.
-- Prefer calibre's curated title_sort over the raw title, exactly as
-- cachedSurname prefers author_sort over a derived surname. If calibre wrote
-- one, the reader has already said how this book should file, and with
-- calibre's own language-aware rules rather than our guess (issue 401).
--
-- Failing that, drop a leading English article. The author key's fallback is a
-- heuristic too -- it parses a surname out of a name -- so this is the same
-- bargain: curated data when there is some, a sensible guess when there is
-- not, and ONE ordering either way. Without it a mixed library files "Locked
-- Tomb, The" under L and "The Locked Tomb" under T on the same shelf, which is
-- worse than either rule alone.
--
-- Three articles, whole word, leading only, never when the article is the
-- whole title. Neutral rather than helpful for other languages -- "Der Herr
-- der Ringe" files under D either way -- so it costs them nothing.
local ARTICLES = { ["the"] = true, ["a"] = true, ["an"] = true }

-- Never when the article is the whole string: stripping that leaves an empty
-- key, an empty key is a missing one, and a missing one sinks to the end of
-- the shelf. Lifted out of cachedTitleKey when the series key needed the same
-- rule (issue 412) -- two copies of a heuristic drift.
local function stripLeadingArticle(v)
    if type(v) ~= "string" or v == "" then return v end
    local first, rest = v:match("^(%a+)%s+(.+)$")
    if first and ARTICLES[first:lower()] then return rest end
    return v
end

local function cachedTitleKey(b)
    ensureEpoch(b)
    local v = b._title_key_cache
    if v == nil then
        local raw = b.title or (b.doc_props and b.doc_props.display_title) or b.name
        if _articles_on then
            v = b.title_sort
            if v == nil or v == "" then v = stripLeadingArticle(raw) end
        else
            -- As written: calibre's title_sort IS the article rule, so it
            -- goes too.
            v = raw
        end
        v = (v ~= nil and v ~= "") and pinyinise(tostring(v):lower()) or false
        b._title_key_cache = v
    end
    return v or nil
end

local function cachedFilenameKey(b)
    ensureEpoch(b)
    local v = b._filename_key_cache
    if v == nil then
        v = b.filename or b.file
        -- Group-shape meta (_cacheGroupShapes) carries no `filename` field, so a
        -- "Filename" within-group sort used to fall through to series_name --
        -- which clustered series members and pushed standalones to the end
        -- (issue #235). Derive the name from the filepath (every book record has
        -- one), stripping the extension to match buildBookMeta's own derivation.
        -- series_name stays as the last resort for group cards, which have no
        -- filepath and legitimately sort a "Filename" key by their label.
        if (v == nil or v == "") and b.filepath then
            v = (b.filepath:match("([^/]+)$") or b.filepath):gsub("%.[^.]+$", "")
        end
        v = v or b.name or b.series_name
        v = (v ~= nil and v ~= "") and pinyinise(tostring(v):lower()) or false
        b._filename_key_cache = v
    end
    return v or nil
end

local function cachedSeriesKey(b)
    ensureEpoch(b)
    local v = b._series_key_cache
    if v == nil then
        v = b.series_name or b.series
        -- A STANDALONE shape in a mixed group list has neither, and with no key
        -- cmp's isMissing sends it to the end -- so a Series source showing
        -- "standalone and books in series", sorted by Name (which on a group
        -- chip IS the series_name key), came out partitioned: every series
        -- group first, every loose book after, each run alphabetical
        -- (issue 400). The standalone shape already carries title and filename
        -- for exactly this reason; its own comment says they are there "so
        -- _groupShapeCmp interleaves the mixed list for free".
        --
        -- Scoped to shapes flagged `standalone` so real Book records are
        -- untouched. The author / library / genre / folder_flat chains sort
        -- author_surname then series_name, and there a seriesless book belongs
        -- AFTER that author's series runs rather than interleaved among them.
        --
        -- Mirror of the filename key's own fallback above (issue 235), which
        -- repaired the same partitioning the other way round.
        if (v == nil or v == "") and b.standalone then
            v = b.title or b.filename
        end
        -- ISSUE 412. "books and series that start with the, a, an, etc. sort
        -- based on that vs. the second word in the title/name." The Title key
        -- has ignored a leading article since 120960a; a Series shelf sorts on
        -- THIS key, so it had to learn the same rule.
        --
        -- Not by offering Title on that shelf, which is what the reporter
        -- asked for: a series GROUP shape carries no title at all, so that key
        -- would return nothing for every group and send the lot to the end of
        -- the shelf -- issue 400 in reverse. One strip here instead reaches
        -- all three shapes a Series shelf can hold: the group, the loose book
        -- through the standalone fallback above, and the one-book series shown
        -- as a card, which has a series_name and no title.
        --
        -- Calibre offers nothing to prefer here the way title_sort is
        -- preferred for a book. It has no stored series sort field: it runs
        -- its own title-sort algorithm over the series name when asked and
        -- never persists the result, so the heuristic is all there is.
        if _articles_on then v = stripLeadingArticle(v) end
        v = (v ~= nil and v ~= "") and pinyinise(tostring(v):lower()) or false
        b._series_key_cache = v
    end
    return v or nil
end

-- sortKeyValue(item, key): the canonical lowercased string the given sort
-- key orders by -- the SAME derivation the KEYS comparators use. Callers
-- like the home screen's "go to letter" jump match against this so the
-- letter landed on is exactly where the visible sort placed it, rather than
-- a re-derived approximation that can diverge (e.g. matching the forename
-- initial when the chip is sorted by surname). author_surname / author_name
-- reuse the memoised cachedSurname / cachedGiven, which honour Calibre
-- author_sort and particle stripping. Keys with no string identity (dates,
-- progress, counts) fall back to a title-ish value so a letter jump still
-- lands somewhere recognisable.
function SortEngine.sortKeyValue(item, key)
    if not item then return nil end
    refreshPinyinFlag()
    -- THROUGH THE COMPARATORS' OWN MEMOS, never a second derivation of the
    -- same idea. This function re-read item.title / item.series_name itself,
    -- and so missed every refinement the keys gained afterwards: calibre's
    -- title_sort (120960a), the leading-article strip (120960a, and 412 for
    -- series), the standalone fallback (400) and the filepath-derived
    -- filename (235). The visible order used those and the letter jump did
    -- not, so a shelf sorted by title filed "The Locked Tomb" under L while
    -- the jump looked for it under T.
    local v
    if key == "author_surname" then
        v = cachedSurname(item)
    elseif key == "author_name" then
        v = cachedGiven(item)
    elseif key == "title" then
        v = cachedTitleKey(item)
    elseif key == "filename" then
        v = cachedFilenameKey(item)
    elseif key == "series_name" or key == "series_combined" then
        v = cachedSeriesKey(item)
    elseif key == "series_or_title" then
        v = cachedSeriesKey(item) or cachedTitleKey(item)
    end
    -- Every branch above hands back a key its memo has already lowercased and
    -- pinyinised, so it is returned untouched.
    if type(v) == "string" and v ~= "" then return v end
    -- Keys with no string identity (dates, progress, counts) land here, and
    -- so does a record the branch above found nothing for.
    v = item.title or (item.doc_props and item.doc_props.display_title)
        or item.name or item.filename or item.file or item.series_name
        -- BookOrbit "All authors"/"All series" group tiles (kind ==
        -- "bookorbit_group") carry none of the above -- their only string
        -- identity is .label (see listGroups in bookshelf_bookorbit_source.lua).
        -- Without this fallback sortKeyValue returns nil for every tile on a
        -- grouped BookOrbit chip, so _jumpToLetterPrefix can never match
        -- anything there and "Go to letter" always reports "No items start
        -- with X" regardless of the letter typed.
        or item.label
    if type(v) ~= "string" or v == "" then return nil end
    return pinyinise(v:lower())
end

SortEngine.KEYS = {
    -- Book record: a.title
    -- lfs entry:   a.doc_props.display_title (when needs_titles prefetch ran) or a.name
    title           = { label = tr("Title"), short = tr("Title"),
                        comparator = function(a, b)
                            return natCmp(cachedTitleKey(a), cachedTitleKey(b))
                        end },
    -- Book record: a.filename / a.file
    -- lfs entry:   a.name
    -- group shape: a.series_name (series/author/genre/tag groups have no filename)
    filename        = { label = tr("Filename"), short = tr("Filename"),
                        comparator = function(a, b)
                            return natCmp(cachedFilenameKey(a), cachedFilenameKey(b))
                        end },
    author_name     = { label = tr("Author (given name)"), short = tr("Author"),
                        comparator = function(a, b) return cmp(cachedGiven(a), cachedGiven(b)) end },
    author_surname  = { label = tr("Author surname"), short = tr("Surname"),
                        comparator = function(a, b) return cmp(cachedSurname(a), cachedSurname(b)) end },
    series_name     = { label = tr("Series name"), short = tr("Series"),
                        comparator = function(a, b)
                            return cmp(cachedSeriesKey(a), cachedSeriesKey(b))
                        end },
    series_index    = { label = tr("Series index"), short = tr("Series #"),
                        comparator = function(a, b) return cmp(tonumber(a.series_index or a.series_num),
                                                                tonumber(b.series_index or b.series_num)) end },
    -- One sort slot that orders by series NAME first, then by INDEX within each
    -- series. Lets users keep "Series, then within-series numbering" without
    -- spending two priority levels on it -- so author + series-combined + title
    -- fits naturally for a typical "by author, by series order, then title"
    -- whole-library sort (issue #72).
    series_combined = { label = tr("Series + index"), short = tr("Series + #"),
                        comparator = function(a, b)
                            local s = cmp(cachedSeriesKey(a), cachedSeriesKey(b))
                            if s ~= 0 then return s end
                            return cmp(tonumber(a.series_index or a.series_num),
                                       tonumber(b.series_index or b.series_num))
                        end },
    -- Issue 437: one alphabet for series and standalones. A book in a series
    -- files under its SERIES name, one without under its title, so "Adventure"
    -- (a standalone) comes before the "Court" series instead of after every
    -- series on the shelf, which is where series_name's missing-key rule sends
    -- it. Within a series, index order, then title. The keys are the same
    -- memoised, article-stripped forms series_name and title sort by.
    series_or_title = { label = tr("Series, else title"), short = tr("Series or title"),
                        comparator = function(a, b)
                            local ka = cachedSeriesKey(a) or cachedTitleKey(a)
                            local kb = cachedSeriesKey(b) or cachedTitleKey(b)
                            -- Natural order, as titles sort: "Book 2" before "Book 10".
                            local s = natCmp(ka, kb)
                            if s ~= 0 then return s end
                            s = cmp(tonumber(a.series_index or a.series_num),
                                    tonumber(b.series_index or b.series_num))
                            if s ~= 0 then return s end
                            return natCmp(cachedTitleKey(a), cachedTitleKey(b))
                        end },
    -- Book record: a.last_opened
    -- lfs entry:   a._last_read (when last_read prefetch ran)
    -- group shape: a.latest (most-recent last_opened among member books)
    last_opened     = { label = tr("Last opened"), short = tr("Opened"),
                        comparator = function(a, b)
                            return cmp(a.last_opened or a._last_read or a.latest,
                                       b.last_opened or b._last_read or b.latest)
                        end },
    -- effective_percent handles both shapes: percent_finished/_pct + read_status/_status
    percent_read    = { label = tr("Percent read"), short = tr("Progress"),
                        comparator = function(a, b) return cmp(effective_percent(a), effective_percent(b)) end },
    -- Two status sorts: same set, different ordering.
    -- "read_status" keeps the legacy key for back-compat with any tabs whose
    -- sort_priority was set before the split.
    read_status         = { label = tr("Unread/Reading/Finished"),
                            short = tr("Unread 1st"),
                            comparator = function(a, b)
                                -- nil status == unread (no sidecar); look up
                                -- "unread" rather than falling through to 99
                                -- so unread books sort first as the label
                                -- promises. (Issue #41.)
                                return cmp(STATUS_RANK_PROGRESS[a.read_status or a._status or "unread"] or 99,
                                           STATUS_RANK_PROGRESS[b.read_status or b._status or "unread"] or 99)
                            end },
    read_status_active  = { label = tr("Reading/Unread/Finished"),
                            short = tr("Reading 1st"),
                            comparator = function(a, b)
                                return cmp(STATUS_RANK_ACTIVE[a.read_status or a._status or "unread"] or 99,
                                           STATUS_RANK_ACTIVE[b.read_status or b._status or "unread"] or 99)
                            end },
    -- Favourites (KOReader's default "favorites" collection) ahead of the
    -- rest; ties fall to the next level, e.g. Reading 1st then Last opened.
    favorites_first = { label = tr("Favorites first"), short = tr("Favorite 1st"),
                        comparator = function(a, b)
                            return cmp(isFavourite(a) and 1 or 2, isFavourite(b) and 1 or 2)
                        end },
    -- Book record: a.date_added
    -- lfs entry:   a.attr.modification
    -- group shape: a.latest_added (max member mtime; set in _buildGroups so
    --              a "Sort by date added" on Authors / Genres / Series /
    --              Tags / Formats tabs surfaces groups containing recently-
    --              added books first)
    date_added      = { label = tr("Date added"), short = tr("Added"),
                        comparator = function(a, b)
                            local av = a.date_added or a.latest_added
                                    or (a.attr and a.attr.modification)
                            local bv = b.date_added or b.latest_added
                                    or (b.attr and b.attr.modification)
                            return cmp(av, bv)
                        end },
    -- The later of the two above (issue 519), the way a Kindle's home orders
    -- its books: a new book goes to the front, and so does one just opened,
    -- until the next new book pushes it back. Same fields as last_opened and
    -- date_added, every shape; a missing side counts as never.
    added_or_opened = { label = tr("Added or opened"), short = tr("Added/opened"),
                        comparator = function(a, b)
                            local function at(x)
                                local o = tonumber(x.last_opened or x._last_read or x.latest) or 0
                                local d = tonumber(x.date_added or x.latest_added
                                    or (x.attr and x.attr.modification)) or 0
                                local v = math.max(o, d)
                                if v > 0 then return v end
                            end
                            return cmp(at(a), at(b))
                        end },
    -- Book record: a.size
    -- lfs entry:   a.attr.size
    -- short is "File size" (not "Size"): on its own next to "Pages" a bare
    -- "Size" reads as page count, which is how book length is usually judged.
    size            = { label = tr("File size"), short = tr("File size"),
                        comparator = function(a, b)
                            return cmp(a.size or (a.attr and a.attr.size),
                                       b.size or (b.attr and b.attr.size))
                        end },
    -- Book record: a.book_count (explicit integer field)
    -- group shape: #a.filepaths (group carries a filepaths array, no book_count field)
    book_count      = { label = tr("Book count"), short = tr("Books"),
                        comparator = function(a, b)
                            local av = a.book_count or (a.filepaths and #a.filepaths)
                            local bv = b.book_count or (b.filepaths and #b.filepaths)
                            return cmp(av, bv)
                        end },
    -- Book record: a.rating (1-5 stars, from DocSettings summary.rating; nil = unrated)
    -- Group shape: a.avg_rating (mean rating across rated members; nil if none)
    rating          = { label = tr("Rating"), short = tr("Rating"),
                        comparator = function(a, b)
                            return cmp(a.rating or a.avg_rating,
                                       b.rating or b.avg_rating)
                        end },
    -- Book record: a.page_count (from BIM / DocSettings stats.pages)
    -- group shape: a.total_pages (sum of member page counts)
    -- A record with neither asks the repository (SortEngine.pageCountOf).
    page_count      = { label = tr("Page count"), short = tr("Pages"),
                        comparator = function(a, b)
                            return cmp(SortEngine.pageCountOf(a),
                                       SortEngine.pageCountOf(b))
                        end },
    -- Book record: a.collection_order (the `order` KOReader stores per item in
    -- a collection; the repository's collection source copies it onto the
    -- record). Meaningful only on a collection source -- everywhere else every
    -- book is missing it, which cmp ties, so the level costs nothing and the
    -- next one decides.
    --
    -- KOReader writes `order` only for a MANUALLY collated collection (see
    -- ReadCollection:writeCollection); one carrying a collate of its own saves
    -- nil for every item, and then this key ties across the board by the same
    -- route. That is the intended behaviour, not a gap: it is what lets the
    -- default pair this key with a real second level.
    -- short repeats the label rather than a bare "Order": on its own in a
    -- catalogue that msgid could be an instruction, a sequence or a purchase,
    -- and "Name" already meant three different things here once.
    collection_order = { label = tr("Collection order"), short = tr("Collection order"),
                        comparator = function(a, b)
                            return cmp(a.collection_order, b.collection_order)
                        end },
}

-- ORDER used to surface keys in the picker UI later. Sorted by perceived
-- usefulness on a typical library view, not alphabetically.
SortEngine.ORDER = {
    "title", "filename", "author_surname", "author_name",
    "series_name", "series_index", "series_combined", "series_or_title",
    "last_opened", "date_added", "added_or_opened",
    "percent_read", "rating",
    "read_status", "read_status_active", "favorites_first",
    "size", "page_count", "book_count",
}

-- chainedComparator(priority): builds a single Lua-table-sort comparator from
-- a priority list. Each entry is { key, reverse }. The first entry whose
-- comparator returns non-zero decides ordering; ties cascade to the next key.
-- Levels are resolved against KEYS once here, not on every one of the
-- ~n*log(n) comparator calls; unknown keys drop out up front.
function SortEngine.chainedComparator(priority)
    refreshPinyinFlag()
    local levels = {}
    local used   = {}
    for _i, level in ipairs(priority) do
        local k = SortEngine.KEYS[level.key]
        if k then
            levels[#levels + 1] = { comparator = k.comparator, reverse = level.reverse }
            used[level.key] = true
        end
    end
    -- Deterministic tie-break: when every requested level ties, fall back to
    -- title then filename so equal books never fall into arbitrary order.
    -- table.sort isn't stable, and some sources arrive in non-deterministic
    -- pairs() order (e.g. collections), so without this the leftover order can
    -- even shuffle between renders (#205/#208). filename is the book's path, so
    -- it's unique -> a total order. Skipped if the user already sorts by it.
    if not used.title then
        levels[#levels + 1] = { comparator = SortEngine.KEYS.title.comparator, reverse = false }
    end
    if not used.filename then
        levels[#levels + 1] = { comparator = SortEngine.KEYS.filename.comparator, reverse = false }
    end
    return function(a, b)
        for _i, lv in ipairs(levels) do
            local r = lv.comparator(a, b)
            -- Missing values sort to the end regardless of reverse
            -- direction, so the user never sees "no metadata" books
            -- on the first page when sorting either way.
            if r == SORT_TO_END   then return false end
            if r == SORT_TO_START then return true  end
            if lv.reverse then r = -r end
            if r ~= 0 then return r < 0 end
        end
        return false
    end
end

-- sort(books, priority): in-place sort. `priority` is a list of { key, reverse }.
-- An empty priority is a no-op (stable order preserved).
function SortEngine.sort(books, priority)
    if not priority or #priority == 0 then return books end
    table.sort(books, SortEngine.chainedComparator(priority))
    return books
end

return SortEngine
