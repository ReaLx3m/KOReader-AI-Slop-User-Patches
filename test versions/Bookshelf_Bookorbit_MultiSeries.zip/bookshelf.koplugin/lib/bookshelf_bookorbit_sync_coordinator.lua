--[[--
Small sync job coordinator for Bookshelf's BookOrbit integration.

BookOrbit progress sync has three independent triggers -- the automatic
push on book close, the automatic pull-and-notify on book open, and the
manual "Sync now" push from the settings menu -- and all three make plain
blocking socket calls (see bookshelf_bookorbit.lua). Firing more than one
of those at once is how you get races: a pull reading progress out from
under a push that hasn't landed yet, or two overlapping requests on the
same connection confusing KOReader's http client. This coordinator is the
fix -- it runs at most one BookOrbit sync job at a time and queues the
rest.

Deliberately has NO KOReader dependencies (no UIManager, no Trapper, no
require("device") etc.) -- it doesn't know or care what a "job" actually
does over the network, only how to schedule jobs. That keeps it plain,
synchronous, unit-testable Lua; a thin KOReader-aware wrapper (see
bookshelf_bookorbit_sync_job_runner.lua) is what actually invokes it from
inside Trapper:wrap. Mirrors the split the official BookOrbit plugin uses
between bookorbit_sync_coordinator.lua and bookorbit_sync_job_runner.lua.

Job shape (same contract as the official plugin's coordinator):
  {
    family   = "progress:<book_hash>",  -- required; same-family pending
                                         -- jobs coalesce (last one wins)
    label    = "push progress",         -- optional, for status()
    priority = SyncCoordinator.PRIORITY.manual, -- optional, defaults to auto
    async    = false,                   -- true if run() calls done() itself
                                         -- later rather than returning
    run      = function(done, job) ... end, -- required
    on_error = function(err) ... end,   -- optional
  }

For synchronous jobs (async = false / omitted), run() is called and then
done() is invoked automatically -- run() doesn't need to call it. For
async jobs, run() must arrange to call done() itself once the work
finishes (typically from inside a coroutine/callback), and should return
true once the async work has actually been kicked off.
]]

local SyncCoordinator = {}
SyncCoordinator.__index = SyncCoordinator

SyncCoordinator.PRIORITY = {
    auto   = 100, -- background push-on-close / pull-on-open
    manual = 200, -- user tapped "Sync now"
}

function SyncCoordinator.new(opts)
    opts = opts or {}
    return setmetatable({
        now           = opts.now or os.time,
        current       = nil,
        pending       = {},
        pending_count = 0,
        next_seq      = 0,
    }, SyncCoordinator)
end

local function copyJobStatus(job, now)
    if not job then return nil end
    local started_at = job.started_at
    local status = {
        family      = job.family,
        label       = job.label or job.family,
        priority    = job.priority,
        created_at  = job.created_at,
        started_at  = started_at,
    }
    if started_at then
        status.age = math.max(0, now - started_at)
    end
    return status
end

--- True while a job is actively running.
function SyncCoordinator:isBusy()
    return self.current ~= nil
end

--- Number of distinct families currently queued (not counting the job
-- that's actively running).
function SyncCoordinator:queuedCount()
    return self.pending_count
end

-- Same-family pending jobs coalesce: a second push for the same book
-- queued behind an in-flight job replaces the first pending one instead
-- of stacking up, UNLESS the job already queued has strictly higher
-- priority (a queued manual "Sync now" survives a later automatic push
-- for the same book landing behind it).
function SyncCoordinator:coalesce(job)
    local existing = self.pending[job.family]
    if existing and existing.priority > job.priority then
        return "kept", existing
    end
    if not existing then
        self.pending_count = self.pending_count + 1
    end
    self.pending[job.family] = job
    return "queued", job
end

-- Highest priority wins; ties broken by submission order (lower seq
-- first), so same-priority jobs run in the order they were queued.
function SyncCoordinator:nextPending()
    local best_family, best_job
    for family, job in pairs(self.pending) do
        if not best_job
                or job.priority > best_job.priority
                or (job.priority == best_job.priority and job.seq < best_job.seq) then
            best_family = family
            best_job = job
        end
    end
    return best_family, best_job
end

function SyncCoordinator:startNext()
    local family, job = self:nextPending()
    if not job then return end
    self.pending[family] = nil
    self.pending_count = self.pending_count - 1
    self:start(job)
end

function SyncCoordinator:start(job)
    self.current = job
    job.started_at = self.now()

    local finished = false
    local function done()
        if finished then return end
        finished = true
        if self.current == job then
            self.current = nil
            self:startNext()
        end
    end

    local ok, started = pcall(job.run, done, job)
    if not ok then
        if job.on_error then
            pcall(job.on_error, started)
        end
        done()
        return
    end
    -- Synchronous jobs (the common case: everything here is a blocking
    -- socket call already wrapped in Trapper by the caller) are done the
    -- instant run() returns. Async jobs are only "done" once they call
    -- done() themselves -- unless run() reports it never actually got the
    -- async work started (started == false), in which case there's
    -- nothing left to wait on.
    if job.async and started == false then
        done()
    elseif not job.async then
        done()
    end
end

--- Submit a job. Runs immediately if the coordinator is idle; otherwise
-- queues it (coalescing with any pending job in the same family).
-- Returns "started", "queued", or "kept" plus the job that ended up
-- representing that slot.
function SyncCoordinator:submit(job)
    assert(type(job) == "table", "sync job must be a table")
    assert(type(job.family) == "string" and job.family ~= "", "sync job family required")
    assert(type(job.run) == "function", "sync job run function required")

    self.next_seq = self.next_seq + 1
    job.seq = self.next_seq
    job.created_at = self.now()
    job.priority = job.priority or SyncCoordinator.PRIORITY.auto
    job.label = job.label or job.family

    if self.current then
        return self:coalesce(job)
    end

    self:start(job)
    return "started", job
end

--- Compact snapshot for diagnostics / a "Sync status" menu row.
function SyncCoordinator:status()
    local now = self.now()
    local _, next_job = self:nextPending()
    return {
        current       = copyJobStatus(self.current, now),
        pending_count = self.pending_count,
        next          = copyJobStatus(next_job, now),
    }
end

return SyncCoordinator
