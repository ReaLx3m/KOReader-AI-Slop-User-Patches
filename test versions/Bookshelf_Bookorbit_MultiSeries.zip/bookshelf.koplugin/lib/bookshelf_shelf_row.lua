-- bookshelf_shelf_row.lua
-- A single shelf: 4 horizontally-arranged spine slots + dotted base rule.
-- Each slot can be a SpineWidget (single book) or a SeriesStack (series group).
-- Empty slots render as blank spacers so the row always has a fixed width.
--
-- The dotted base rule is a custom-painted Widget subclass. Its paintTo method
-- walks pixel columns 3dp apart and draws a 1×thickness fillRect at each stop.
-- Pattern reference: bookends_overlay_widget.lua lines 176–185 (MultiLineWidget).

local CenterContainer = require("ui/widget/container/centercontainer")
local FrameContainer  = require("ui/widget/container/framecontainer")
local InputContainer  = require("ui/widget/container/inputcontainer")
local VerticalGroup   = require("ui/widget/verticalgroup")
local VerticalSpan    = require("ui/widget/verticalspan")
local HorizontalGroup = require("ui/widget/horizontalgroup")
local HorizontalSpan  = require("ui/widget/horizontalspan")
local TextBoxWidget   = require("ui/widget/textboxwidget")
local TextWidget      = require("lib/bookshelf_colour_text")
local Widget          = require("ui/widget/widget")
local GestureRange    = require("ui/gesturerange")
local Geom            = require("ui/geometry")
local Screen          = require("device").screen
local Size            = require("ui/size")
local Font            = require("ui/font")
local BFont           = require("lib/bookshelf_fonts")
local Blitbuffer      = require("ffi/blitbuffer")
local SpineWidget     = require("lib/bookshelf_spine_widget")
local SeriesStack     = require("lib/bookshelf_series_stack")
local FolderStack     = require("lib/bookshelf_folder_stack")
local Repo            = require("lib/bookshelf_book_repository")
local BookshelfSettings = require("lib/bookshelf_settings_store")
local Space           = require("lib/bookshelf_space")
local StackDisplay      = require("lib/bookshelf_stack_display")
local _               = require("lib/bookshelf_i18n").gettext
local logger          = require("logger")

-- Shared wall-clock for [bookshelf perf] timestamps (and elapsed-time
-- bookkeeping); see lib/bookshelf_gettime.lua for the fallback contract.
local _gettime = require("lib/bookshelf_gettime")

local ShelfRow = {}

-- True-aspect covers (opt-in "true_cover_aspect" setting). Normally covers are
-- forced to a uniform 2:3 (1.5) box. When the setting is on, the collapsed grid
-- reserves the 1.65 cap per row and each cover renders at its OWN aspect
-- (fixed width, variable height), bottom-anchored so covers sit on the shelf
-- line. Aspect + cap live on SpineWidget (SpineWidget.bookAspect /
-- COVER_ASPECT_CAP / trueAspectBoxHeight) so the grid and hero agree.

-- Row-height ratio used for slot sizing. 1.5 normally; the 1.65 cap when
-- true-aspect is on (so the tallest untrimmed cover still fits its row).
local function _natAspect()
    return BookshelfSettings.isTrue("true_cover_aspect")
        and SpineWidget.coverAspectCap() or 1.5
end

-- ShelfRow.new(opts)
-- opts: {
--   width         number   total row width in pixels
--   height        number   slot height in pixels
--   items         table    list of up to 4 Book or SeriesGroup records (nil = empty slot)
--   gap           number   (optional) pixel gap between slots (default Size.padding.default)
--   on_book_tap   function (book) callback
--   on_book_open  function (book) callback (double_tap = open directly, #271)
--   on_book_hold  function (book) callback
--   on_series_tap function (series) callback
--   on_series_hold function (series) callback
--   selected_filepath string|nil  filepath of the spine that should
--                                 render with the selected (thicker)
--                                 border. Typically the previewed book.
--   label_mode    string   "title" / "author" / "series" / "custom" / "none"
--   label_line    table    the Custom label ({ template, bold, uppercase });
--                          read only when label_mode is "custom"
-- }
function ShelfRow.new(opts)
    local n_slots = opts.n_slots or 4
    -- Generous gap between covers so the shelf doesn't read as cramped.
    -- Size.padding.fullscreen × 2 ≈ 30dp at native scaling.
    local gap     = opts.gap or Space.padding.fullscreen * 2
    local slot_w  = math.floor((opts.width - gap * (n_slots - 1)) / n_slots)
    -- Standard 2:3 book-cover aspect (slot_w * 1.5) so covers look like books.
    -- With true-aspect covers on, NAT_ASPECT is the 1.65 cap: the row box is
    -- reserved at the cap and individual covers render shorter within it.
    local NAT_ASPECT = _natAspect()
    local slot_h  = math.floor(slot_w * NAT_ASPECT)
    -- Honour the parent's budgeted row height (opts.height) when supplied.
    --   - If budget is SMALLER than natural: shrink the slot to fit AND
    --     recompute slot_w so the cover stays 2:3. (Tight layouts like
    --     expanded mode + small screens.)
    --   - If budget is LARGER than natural: GROW slot_h to fill the budget
    --     while keeping slot_w at natural — the row still spans content_w
    --     and the extra slot height goes to the cover (slightly fatter than
    --     natural aspect, but no horizontal whitespace and the row doesn't
    --     leave slack that would push pagination off its fixed y position).
    -- Aspect bounds so covers don't get extreme either way:
    --   * Shrink floor: stop shrinking once slot_w drops below 70% of
    --     natural (covers become hard to read). Below that, the row
    --     simply leaves vertical slack instead.
    --   * Stretch cap: allow at most 5% vertical overshoot (slot_h grows
    --     past natural, making covers slightly taller than 2:3). Beyond
    --     that the row keeps natural slot_h and leaves vertical slack.
    -- True-aspect layout applies to both modes. ta_grid is the COLLAPSED
    -- treatment (variable-height spines bottom-anchored via the row's
    -- align="bottom" + a cap-height spacer). Expanded mode (ta_grid false but
    -- true_aspect true) keeps fixed slot_h boxes -- so the row stays uniform
    -- and taps still cover cover+title -- and bottom-anchors the cover WITHIN
    -- each slot by top-padding its stack, so cover bottoms (and the titles
    -- below them) align across the row.
    local true_aspect = BookshelfSettings.isTrue("true_cover_aspect")
    local ta_grid     = true_aspect and not (opts.show_titles or false)
    local SHRINK_FLOOR  = 0.70
    local STRETCH_CAP   = 1.05
    local natural_slot_h = slot_h
    if true_aspect then
        -- slot_w is FIXED (fixed-width covers are the whole point), so the
        -- shrink/stretch dance below -- which recomputes slot_w -- must not
        -- run. The row box simply takes the parent's budgeted height (already
        -- sized to the aspect cap); each cover renders at its own aspect
        -- within it, bottom-anchored.
        if opts.height then slot_h = opts.height end
        -- ...but the box must never be WIDER than a standard cover. When the
        -- budgeted height is less than slot_w would naturally need -- few
        -- columns, so slot_w is large, and few rows to divide the height
        -- between, which is exactly a 2x2 expanded shelf -- the box comes out
        -- squat, and covers filling it look stretched wide. (Reported on
        -- device: 2 columns, true aspect on, covers visibly too wide; off,
        -- normal, because that path recomputes slot_w to keep 2:3.)
        --
        -- So narrow the slot to keep at least 2:3, exactly as the non-true-
        -- aspect branch does. Covers stay their own shape and the row simply
        -- leaves horizontal slack, which is the same trade the shrink floor
        -- below makes.
        local min_h = math.floor(slot_w * 1.5)
        if slot_h < min_h then
            slot_w = math.floor(slot_h / 1.5)
        end
    elseif opts.height then
        if slot_h > opts.height then
            -- Budget tighter than natural: shrink both axes to preserve
            -- 2:3, but not below the shrink floor.
            local target_h = math.max(opts.height,
                math.floor(natural_slot_h * SHRINK_FLOOR))
            slot_h = target_h
            slot_w = math.floor(slot_h / NAT_ASPECT)
        elseif slot_h < opts.height then
            -- Budget looser than natural: stretch slot_h vertically up to
            -- the cap. Beyond that, hold at the cap and let the row's
            -- height-vs-content delta become vertical slack.
            slot_h = math.min(opts.height,
                math.floor(natural_slot_h * STRETCH_CAP))
        end
    end

    -- If the covers got narrower than their natural slot (the shrink branch
    -- above), widen the inter-cover gap so the n covers still span opts.width
    -- evenly -- spreading the slack between covers rather than leaving it as a
    -- clumped margin at the sides (which the centring fallback used to do).
    if opts.width and n_slots > 1 then
        local row_w_now = n_slots * slot_w + (n_slots - 1) * gap
        if opts.width > row_w_now then
            gap = math.max(gap, math.floor((opts.width - n_slots * slot_w) / (n_slots - 1)))
        end
    end

    -- Titles-under-cover mode (used in expanded shelf): reserve a thin
    -- strip below each cover for the book title. Cover shrinks vertically
    -- only — slot_w stays the same so the row still fills content_w like
    -- the chip strip / pagination above and below. (Per "scale height,
    -- not width".)
    --
    -- Single line at 14pt — short titles fit, longer ones truncate with
    -- ellipsis at the right edge of the slot. Two-line wrap was tried and
    -- read as crowded; truncation keeps the grid scannable.
    -- Expanded shelf label-below-cover mode. Default "none" lets covers
    -- claim the full slot height. "title" / "author" / "series" reserve
    -- a strip below each cover for the corresponding metadata; missing
    -- data falls back to title (or the literal "None" for series).
    -- The caller may pass an explicit label_mode (the widget resolves the
    -- regular grid's Title-default vs the expanded shelf's raw setting); fall
    -- back to the shared setting for any caller that doesn't.
    local label_mode = opts.label_mode
                       or BookshelfSettings.read("expanded_shelf_label") or "none"
    if label_mode ~= "title" and label_mode ~= "author" and label_mode ~= "series"
            and label_mode ~= "custom" then
        label_mode = "none"
    end
    -- Custom: the reader's token template, expanded per book through a cache
    -- (lib/bookshelf_cover_label.lua) so a page turn back to a page already
    -- seen re-expands nothing. The resolver is made once per row: it reads
    -- the cache's context (template, data generation, ...) once, not per cover.
    local custom_label, CoverLabel
    local label_ms = 0     -- this row's time in the resolver, for the perf line
    if label_mode == "custom" then
        CoverLabel = require("lib/bookshelf_cover_label")
        local t0 = _gettime()
        -- The saved line when the caller passed none (it resolved the mode
        -- from the setting itself, above).
        local resolve = CoverLabel.resolver(opts.label_line or CoverLabel.line())
        label_ms = (_gettime() - t0) * 1000
        custom_label = function(item)
            local t1 = _gettime()
            local text = resolve(item)
            label_ms = label_ms + (_gettime() - t1) * 1000
            return text
        end
    end
    -- Author below series (issue 486): a series stack's author on the line
    -- below its tile, independent of the books' text ("title under covers
    -- and author under series groups"). "author", or nil when off. The
    -- caller passes it (false = off); any caller that doesn't gets the saved
    -- choice.
    local group_text = opts.group_label_mode
    if group_text == nil then
        group_text = require("lib/bookshelf_cover_label").groupMode()
    end
    if group_text ~= "author" then group_text = nil end
    -- Two flags driven by the same `opts.show_titles` input — kept
    -- separate so the geometry stays consistent while the rendering
    -- adapts:
    --   show_titles    — alias kept for back-compat with downstream
    --                    SpineWidget / slot-tap code paths.
    --   draw_label     — actually paint a TextWidget in the strip.
    local show_titles = opts.show_titles or false
    local draw_label  = show_titles and label_mode ~= "none"
    -- The groups' text needs the strip as much as a book's label does: with
    -- books on None and groups on Author, the strip is there for the groups.
    local draw_group_label = show_titles and group_text ~= nil

    -- Gap between cover bottom and the label text. Bumped from
    -- padding.small to padding.default so the dangling bookmark
    -- indicator at the cover's bottom-left doesn't sit on top of
    -- the title text. Cover height shrinks by the same delta so
    -- inter-row spacing is unchanged.
    -- ── Label plate ────────────────────────────────────────────────
    --
    -- A title under a cover is bare text on whatever the shelf is standing on.
    -- Over a picture that is the least legible thing on the screen -- the
    -- covers bring their own opaque card, the text brings nothing.
    --
    -- Same construction as the spine shelf's section badge (rounded rect,
    -- 5dp/2dp padding, 2dp radius) so the two read as one family, but filled
    -- with panel_bg rather than the ribbon colour: this is chrome making text
    -- legible, not a coloured label naming a section.
    --
    -- nil on a plain page, deliberately: there the text already sits on its
    -- ground, and a plate would put a box around every title in the grid.
    local PLATE_PAD_X = Space.px(5)
    local PLATE_PAD_Y = Space.px(2)
    local plate_fill, plate_wp, plate_strength
    do
        local ok_wp, Wallpaper = pcall(require, "lib/bookshelf_wallpaper")
        plate_wp = ok_wp and Wallpaper or nil
        -- A plate whenever the ground is painted: a picture, or a background
        -- colour (the shelf tells Wallpaper about that ground before the rows
        -- are built; the dark theme paints one too, and its plate is the page
        -- colour and shows as nothing). Bare text on a coloured page loses
        -- contrast, which is what the plate is for.
        --
        -- type(), not `~= nil`: the ground is a Blitbuffer colour, which is
        -- cdata with an __eq metamethod, and LuaJIT calls that metamethod for
        -- a comparison against nil too; it then indexes the nil operand and
        -- the shelf dies on show.
        local painted = ok_wp and ((Wallpaper.isShowing and Wallpaper.isShowing())
                                   or (Wallpaper.ground and type(Wallpaper.ground()) ~= "nil"))
        if painted then
            local ok_cp, CoverProgress = pcall(require, "lib/bookshelf_cover_progress")
            if ok_cp and CoverProgress and CoverProgress.resolvedColors then
                local ok_c, colors = pcall(CoverProgress.resolvedColors)
                if ok_c and colors then plate_fill = colors.panel_bg end
            end
        end
    end
    -- Ink for the labels. TextWidget defaults to black, which has always been
    -- right: a night frame inverts it to white. Under the shelf's own dark
    -- theme nothing inverts, so black text on a dark plate is invisible --
    -- which is exactly how the first dark screenshot came out.
    local label_ink
    do
        local ok_cp, CoverProgress = pcall(require, "lib/bookshelf_cover_progress")
        if ok_cp and CoverProgress and CoverProgress.resolvedColors then
            local ok_c, colors = pcall(CoverProgress.resolvedColors)
            if ok_c and colors then label_ink = colors.ink end
        end
    end
    -- Width the TEXT may take: the plate's padding has to come out of the
    -- slot, or a full-width title pushes its plate past the slot edge and into
    -- its neighbour.
    local function plateTextWidth(w)
        return plate_fill and math.max(8, w - 2 * PLATE_PAD_X) or w
    end
    -- How hard the plate tints, from the same "Panel shading" setting the top
    -- panel and the footer use. It was an opaque fill, which read as a solid
    -- box under every cover and ignored a reader who had turned the shading
    -- down (or off) everywhere else. Same colour, same geometry, same rounding
    -- -- painted as a scrim so the picture shows through it by as much as the
    -- rest of the chrome does.
    if plate_fill and plate_wp and plate_wp.shading then
        -- The shading level itself (Wallpaper.shading), NOT
        -- Wallpaper.scrimStrength(): that one also returns 0 for "transparent
        -- buttons", which is a choice about the CHROME. A label under a cover
        -- is one of the surfaces that has no legible alternative -- the same
        -- reason the shelf planks, the list rows and the hero text are not
        -- gated on it either. As the theme on screen sets it (part of the
        -- theme since 2026-10-09), through the seam.
        plate_strength = plate_wp.shading()
        -- Shading turned off: no plate at all, which is what the setting
        -- asks for. The label keeps its themed ink and sits on the ground,
        -- exactly as it does on a plain page.
        if type(plate_strength) == "number" and plate_strength <= 0 then
            plate_fill = nil
        end
        -- The shelf's own panel runs behind the covers (the theme's
        -- Wallpaper > Panel behind Covers shelves, issue 483): no plate on top.
        if plate_wp.coversPanel and plate_wp.coversPanel() then
            plate_fill = nil
        end
    end
    local PLATE_RADIUS = Space.px(2)
    local function plated(widget)
        if not plate_fill then return widget end
        local frame = FrameContainer:new{
            -- No background: the fill below is a scrim, and a FrameContainer
            -- that also filled would paint the colour twice -- opaque first,
            -- tint on top -- and the shading setting would do nothing.
            bordersize     = 0,
            margin         = 0,
            radius         = PLATE_RADIUS,
            padding_top    = PLATE_PAD_Y,
            padding_bottom = PLATE_PAD_Y,
            padding_left   = PLATE_PAD_X,
            padding_right  = PLATE_PAD_X,
            widget,
        }
        if not (plate_wp and plate_wp.scrim) then return frame end
        local inner_paint = frame.paintTo
        frame.paintTo = function(slf, bb, x, y)
            local ok_sz, sz = pcall(slf.getSize, slf)
            if ok_sz and sz and sz.w and sz.h then
                pcall(plate_wp.scrim, bb, x, y, sz.w, sz.h,
                      plate_fill, plate_strength, PLATE_RADIUS)
            end
            return inner_paint(slf, bb, x, y)
        end
        return frame
    end
    -- Size, not Space: the gap has to clear the reading ribbon that hangs
    -- below a cover, and the ribbon grows with the DPI setting, so a capped
    -- gap let it sit on the label at 480dpi. Copied in bookshelf_widget.lua
    -- (title_block_h, grid_title_block_h): all three must agree.
    local label_gap = Size.padding.default
    -- Expanded-shelf font scale: applied to the label face below
    -- covers (Title / Author / Series). 100% preserves prior
    -- behaviour. The reserved strip height scales with the font so
    -- larger scales push the cover height down accordingly.
    local label_scale = BookshelfSettings.read("expanded_shelf_font_scale") or 100
    local title_block_h = 0
    local title_face
    local title_bold
    -- The groups' text has its own face: Bold is the one style its Custom
    -- line carries, as the books' line carries theirs.
    local group_face, group_bold
    -- Only reserve the strip when a label will actually be drawn. With
    -- label_mode = "none" the cover claims the full slot height — the
    -- stretch cap below keeps it from growing past ~5% of natural.
    if draw_label or draw_group_label then
        local face_size = math.floor(14 * label_scale / 100 + 0.5)
        -- Bold is the one style a Custom label carries: the strip's own face,
        -- asked for its bold (a real bold file when there is one, else the
        -- regular face drawn bold).
        title_face, title_bold = BFont:getFace("infofont", face_size,
            (custom_label and opts.label_line and opts.label_line.bold)
                and { bold = true } or nil)
        if draw_group_label then
            group_face, group_bold = BFont:getFace("infofont", face_size, nil)
        end
        title_block_h = label_gap + math.floor(face_size * 1.3)
        -- The plate is taller than the text it wraps, and title_block_h is
        -- what the cover height is derived FROM (cover_h = slot_h - this), so
        -- the padding has to be reserved here. Left out, every label in the
        -- grid overflows its slot -- on the bottom row, over the footer.
        if plate_fill then title_block_h = title_block_h + 2 * PLATE_PAD_Y end
    end
    -- Honour the "Author name formatting" setting so the expanded-shelf
    -- author label matches the form used on the hero, the long-press menu,
    -- and the Authors chip. Shared by a book's label and a series stack's.
    local function _authorLabel(a)
        local fmt = BookshelfSettings.read("author_format") or "auto"
        if fmt ~= "auto" then
            local ok_a, _AN = pcall(require, "lib/bookshelf_author_name")
            if ok_a and _AN and _AN.formatted then
                return _AN.formatted(a, fmt)
            end
        end
        return a
    end
    local function _labelFor(item)
        if custom_label then return custom_label(item) end
        local title_fallback = item.title or
            ((item.filepath or ""):match("([^/]+)$") or ""):gsub("%.[^.]+$", "")
        if label_mode == "author" then
            local a = item.author or item.authors
            if a and a ~= "" then
                return _authorLabel(a)
            end
        elseif label_mode == "series" then
            -- label carries the article-flipped form; series_name is raw.
            local sname = item.label or item.series_name
            if sname and sname ~= "" then
                local idx = item.series_num or item.series_index
                if idx then
                    return sname .. " #" .. tostring(idx)
                end
                return sname
            end
            -- Standalone book: render "None" so the row reads as a
            -- consistent series column rather than falling back to a
            -- mixed title-here / series-there grid.
            return _("None")
        end
        return title_fallback
    end
    local cover_h = slot_h - title_block_h
    -- Collapsed true-aspect: bottom-align so variable-height covers sit on a
    -- common shelf line, and pin the row to the full cap height with a
    -- zero-width spacer so the row (hence pagination) stays put no matter which
    -- covers land in it. Expanded mode keeps uniform fixed-height slot boxes
    -- (bottom-anchoring happens inside each slot), so it stays centre-aligned.
    -- Off = the historical centre-aligned uniform-box row.
    local row     = HorizontalGroup:new{ align = ta_grid and "bottom" or "center" }
    if ta_grid then
        row[#row + 1] = Widget:new{ dimen = Geom:new{ w = 0, h = slot_h } }
    end

    -- Wrap on_book_tap so the SpineWidget direct-bind path (line ~210) also
    -- stamps a tap timestamp and forwards it as the second arg, matching the
    -- expanded-mode slot:onTap wrapper below. _previewBook on the widget side
    -- uses it to compute tap_gap (gesture → handler latency).
    local raw_on_book_tap = opts.on_book_tap
    local on_book_tap_stamped = raw_on_book_tap and function(b)
        local _t = _gettime()
        logger.dbg(string.format(
            "[bookshelf perf] spine onTap fired t=%.3f fp=%s",
            _t, tostring(b and b.filepath or "?")))
        raw_on_book_tap(b, _t)
    end or nil

    -- Raw selection count for a stack: number of its books currently
    -- in the selection set. Returns 0 when selection mode is off or no
    -- books overlap, so call sites can derive:
    --   * is_bulk_selected = (k > 0)              -> highlight + flag
    --   * selected_count   = (0 < k < #books)     -> "K/N" badge
    -- One sweep, two consumers — beats a separate early-exit "any
    -- selected?" probe for a stack that may already need a full walk.
    local function stack_sel_count(books)
        if not opts.selection or not opts.selection.isActive then return 0 end
        if not opts.selection:isActive() then return 0 end
        if not books or #books == 0 then return 0 end
        local k = 0
        for _i = 1, #books do
            local fp = books[_i].filepath
            if fp and opts.selection:contains(fp) then k = k + 1 end
        end
        return k
    end
    local function partial_count(k, total)
        if k > 0 and k < total then return k end
        return nil
    end

    -- stack_count_badge_mode: off / folders / groups / all. Default
    -- "groups" preserves pre-v2.2.2 behaviour. Resolved once per row
    -- build so the per-slot rendering reads from a local boolean
    -- instead of re-reading the setting per slot.
    local badge_mode = BookshelfSettings.read("stack_count_badge_mode")
    if not (badge_mode == "off" or badge_mode == "folders"
         or badge_mode == "groups" or badge_mode == "all") then
        badge_mode = "groups"
    end
    local show_folder_badge = (badge_mode == "folders" or badge_mode == "all")
    local show_group_badge  = (badge_mode == "groups"  or badge_mode == "all")

    -- stack_count_badge_format: when the badge is shown, "total" →
    -- "×N", "finished_total" → "F/N". Selection-partial "K/N" still
    -- wins above this. Finished is skipped entirely in selection mode
    -- (user-requested: F/N is an out-of-selection format) and when not
    -- needed so the cheap path stays cheap.
    local badge_format = BookshelfSettings.read("stack_count_badge_format")
    if badge_format ~= "finished_total" then badge_format = "total" end
    -- How every GROUP tile in this row draws itself. Resolved ONCE, here,
    -- from the active chip's override (opts.group_display) falling back to the
    -- library default -- rather than by each tile asking a global setting,
    -- which is what it used to do and which is why an OPDS catalog's folders
    -- were stuck with whatever the filesystem's folders were set to. A caller
    -- with no chip in play (search results) passes nothing and gets the
    -- default.
    local group_mode = StackDisplay.resolve(opts.group_display)
    local sel_active_global = opts.selection and opts.selection.isActive
                              and opts.selection:isActive() or false
    local show_finished = (badge_format == "finished_total")
                          and not sel_active_global

    -- finished_count(books_or_paths, items_have_filepath): scans the
    -- list calling Repo.readProgress on each filepath and counts
    -- those whose status is "finished". Returns nil when show_finished
    -- is off so callers can pass the value straight to the widget
    -- without an extra guard. `is_paths` is true when each entry is a
    -- bare filepath string (folder case), false when each entry is a
    -- book record with .filepath (group case). Repo.readProgress is
    -- cached per filepath, so only the first paint pays the sidecar
    -- reads; repaints are table lookups.
    local function finished_count(list, is_paths)
        if not show_finished or not list then return nil end
        local f = 0
        for _i = 1, #list do
            local fp = is_paths and list[_i] or list[_i].filepath
            if fp then
                local _pct, status = Repo.readProgress(fp)
                if status == "finished" then f = f + 1 end
            end
        end
        return f
    end

    -- group_finished(item): F and stack-wide N for a group's F/N badge.
    -- Honors pre-computed item.finished_count_total / item.book_count
    -- when a hydration path attaches them. NOTE: no repo path attaches
    -- finished_count_total today (verified 2026-06), so this is the
    -- documented contract for a future attachment, not a live fast
    -- path; in practice the live sweep below always runs. The sweep
    -- counts the FILTERED member list, so under an active status
    -- filter F/N reflects the filtered stack (N defaults to #books
    -- downstream in CountBadge.render).
    local function group_finished(item)
        if not show_finished or not show_group_badge then return nil, nil end
        local pre = item and tonumber(item.finished_count_total)
        if pre then
            return pre, tonumber(item.book_count)
        end
        return finished_count(item and item.books, false), nil
    end

    -- _groupLabel(item, name) -> text, is_group_text: the line below a group
    -- tile, its name or the groups' text (StackDisplay.groupLabel).
    local function _groupLabel(item, name)
        return StackDisplay.groupLabel(group_mode, item, name, group_text,
                                       _authorLabel)
    end

    for i = 1, n_slots do
        -- Insert a gap spacer before every slot after the first.
        if i > 1 then
            row[#row + 1] = HorizontalSpan:new{ width = gap }
        end

        local item = opts.items and opts.items[i]
        -- Helper: when titles are shown (expanded mode), wrap a non-book
        -- widget so its visual occupies cover_h and a VerticalSpan below
        -- claims the title_block_h slot. Without this, group/folder
        -- widgets render at the full slot_h while books render at cover_h
        -- + title; the cover bottoms then misalign within a row that
        -- mixes types.
        -- group_name: printed in the strip below the tile, the way a book's
        -- title is, when the tile's display mode leaves the group unnamed.
        -- A divider card carries its name in its own band and a Text tile IS
        -- its name, so both pass nil and keep the empty span; stack, collage
        -- and none would otherwise be anonymous artwork. StackDisplay decides
        -- which is which (externalLabel returns nil when the name is already
        -- visible), so the rule is not re-derived at each of these branches.
        --
        -- Still gated on draw_label, i.e. on the reader's own "Show text below
        -- covers" preference: a group name is a label like any other and does
        -- not get to opt itself in.
        local function wrap_for_title_alignment(widget, group_name, is_group_text)
            if not show_titles then return widget end
            -- Deliberately the BOOK path's geometry, element for element:
            -- cover, then a label_gap span, then the TextWidget, all inside a
            -- container pinned to the slot dimen. Two earlier attempts drifted
            -- from it and both showed on device -- a bare VerticalGroup took
            -- its natural height and printed the bottom row's labels over the
            -- footer, and a CenterContainer centred the text in the strip,
            -- which floated every group label ~10px above the book labels
            -- beside it (the text is taller than the floor(face_size * 1.3)
            -- the strip is sized at, so centring pulls it up). Matching the
            -- book path exactly is the only version that cannot drift from it.
            local stack = VerticalGroup:new{ align = "center", widget }
            if (draw_label or draw_group_label)
                    and type(group_name) == "string" and group_name ~= "" then
                stack[#stack + 1] = VerticalSpan:new{ width = label_gap }
                -- Single-line TextWidget for the same reason the book labels
                -- use one: it ellipsises at max_width, where TextBoxWidget
                -- would wrap to two lines and crowd the grid.
                stack[#stack + 1] = plated(TextWidget:new{
                    text      = group_name,
                    face      = is_group_text and group_face or title_face,
                    bold      = is_group_text and group_bold or title_bold,
                    fgcolor   = label_ink,
                    max_width = plateTextWidth(slot_w),
                })
            else
                stack[#stack + 1] = VerticalSpan:new{ width = title_block_h }
            end
            -- Pinned to the slot, exactly as the book path pins its stack:
            -- whatever the font metrics do, a group tile is the same height as
            -- a book tile and cannot overflow the row.
            return InputContainer:new{
                dimen = Geom:new{ w = slot_w, h = slot_h },
                stack,
            }
        end

        local non_book_h = show_titles and cover_h or slot_h

        if item and item.add_subshelf then
            -- A shelf of shelves' "+ Add shelf": a dashed-outline button,
            -- not a folder card (bookshelf_add_tile). No label underneath:
            -- the button carries its own.
            row[#row + 1] = wrap_for_title_alignment(require("lib/bookshelf_add_tile"):new{
                width   = slot_w,
                height  = non_book_h,
                label   = item.label,
                item    = item,
                on_tap  = opts.on_folder_tap,
                on_hold = opts.on_folder_hold,
            }, nil)
        elseif item and item.kind == "folder" then
            -- Folder record (carries path / label / first_book).
            -- Three pieces of derived data: total recursive book count
            -- (for the optional badge), how many of those are in the
            -- current selection (for highlight + partial badge form),
            -- and a path → "should I look this up?" guard so plain
            -- browsing doesn't pay for the recursive walk lookup
            -- unless something needs it.
            local folder_fp = item.first_book and item.first_book.filepath
            local sel_active = opts.selection and opts.selection.isActive
                               and opts.selection:isActive() or false
            -- Collage needs the folder's member paths to build its grid, so
            -- the lookup has to run for it as well as for the badge and
            -- selection. Same walk, already cached by the repo.
            local folder_collage = group_mode == StackDisplay.COLLAGE
            local need_lookup = item.path and
                                (show_folder_badge or sel_active or folder_collage)
            local folder_fpaths
            if need_lookup then
                folder_fpaths = Repo.getFolderBookPaths(item.path) or {}
            elseif item.member_fps then
                -- A shelf of shelves' tile: no path to walk, so it brings
                -- its shelf's books with it (_subShelfItems, issue 527).
                folder_fpaths = item.member_fps
            end
            local folder_book_count
            if show_folder_badge and folder_fpaths then
                folder_book_count = #folder_fpaths
            end
            local folder_k = 0
            if sel_active and folder_fpaths then
                for _i = 1, #folder_fpaths do
                    if opts.selection:contains(folder_fpaths[_i]) then
                        folder_k = folder_k + 1
                    end
                end
            end
            local folder_bulk = folder_k > 0
            local folder_cur  = opts.selected_filepath and folder_fp
                                and folder_fp == opts.selected_filepath or false
            local folder_finished
            if show_finished and show_folder_badge and folder_fpaths then
                folder_finished = finished_count(folder_fpaths, true)
            end
            row[#row + 1] = wrap_for_title_alignment(FolderStack:new{
                display_mode = group_mode,
                folder           = item,
                -- Member paths for the collage grid. cover_fps is the set
                -- the fetch already ordered the way this folder would show
                -- its books (#409), so the collage's four are the four you
                -- meet on opening it. folder_fpaths -- disk order, any depth
                -- -- remains the fallback, and is still what the count and
                -- the selection checks above use, where order is irrelevant.
                book_paths       = item.cover_fps or folder_fpaths,
                width            = slot_w,
                height           = non_book_h,
                on_tap           = opts.on_folder_tap,
                on_hold          = opts.on_folder_hold,
                is_selected      = folder_bulk or folder_cur,
                is_bulk_selected = folder_bulk,
                book_count       = folder_book_count,
                selected_count   = folder_book_count
                                   and partial_count(folder_k, folder_book_count)
                                   or nil,
                finished_count   = folder_finished,
            }, _groupLabel(item, item.label))
        elseif item and item.kind == "bookorbit_group" then
            -- BookOrbit author/series group tile (Authors/Series "All ..."
            -- root -- see BOSource.listGroups). Folder-like, not a
            -- SeriesStack: unlike a local author/genre/tag group this
            -- carries only ONE hydrated sample book (fetching 3 would
            -- triple the per-tile network cost for a purely cosmetic
            -- peek-behind effect), and .count comes straight from the
            -- server's section entry, so -- unlike the real "folder" kind
            -- above -- there's no local Repo.getFolderBookPaths lookup to
            -- do; item.path is intentionally left unset so FolderStack's
            -- custom-folder-image lookup (which assumes a real on-disk
            -- path) is skipped entirely.
            row[#row + 1] = wrap_for_title_alignment(FolderStack:new{
                folder           = item,
                width            = slot_w,
                height           = non_book_h,
                on_tap           = opts.on_bookorbit_group_tap,
                on_hold          = opts.on_bookorbit_group_hold,
                is_selected      = false,
                is_bulk_selected = false,
                book_count       = item.count,
            })
        elseif item and item.kind == "opds_nav" then
            -- OPDS navigation entry (a subcatalog link, e.g. "Next page" or
            -- a browsable category): rendered as a folder-style tile via
            -- FolderStack, the same widget a real filesystem folder uses.
            -- The record carries no .path (nothing on disk to auto-detect a
            -- folder.jpg from) -- already nil-safe in FolderStack, so no
            -- widget-level change was needed there. No book-count concept
            -- for a remote nav link, so the badge fields are all left nil
            -- (suppresses the badge). on_tap hands the whole record back so
            -- the drill-in (Task 4) can read item.opds.
            --
            -- Cover: the repo (getBySource's opds branch) may have attached
            -- item.cover_image_path -- either the nav entry's own feed image
            -- or, failing that, a cover borrowed from the first cached child
            -- entry. FolderStack reads its book stand-in off folder.first_book
            -- (not a separate constructor field), and folder IS item here, so
            -- the nav record doubles as its own first_book: SpineWidget
            -- renders any record with cover_image_path via its external-cover
            -- path regardless of filepath, and that path never touches
            -- book_widget/has_cover and never reads .author or .series_num,
            -- so a nav record's sparse shape is safe there. The self-
            -- reference is render-only -- item is a fresh per-slice copy
            -- from OpdsWindow.slice(), never written back to the persisted
            -- window. No cover -> first_book stays nil and FolderStack's own
            -- empty-folder fallback renders the label-only placeholder
            -- exactly as before.
            item.first_book = item.cover_image_path and item or nil
            local nav_cur = opts.selected_filepath and item.filepath
                            and item.filepath == opts.selected_filepath or false
            -- A REGISTERED SOURCE's folder (bookshelf_sources, a Komga series)
            -- is a real folder with artwork of its own, unlike an OPDS
            -- catalogue link: with a cover it takes the shelf's folder style
            -- the way a local folder does, and its badge numbers come from the
            -- record, since there are no files on disk to count (issue 452).
            local src_folder = item.source_nav and true or false
            local nav_mode = (src_folder and item.cover_image_path) and group_mode
                             or StackDisplay.TEXT
            row[#row + 1] = wrap_for_title_alignment(FolderStack:new{
                -- ALWAYS text for a remote subcatalog, whatever the chip's
                -- folder style says. A catalog folder has no artwork of its
                -- own, so every image mode ends up showing a borrowed cover
                -- from whatever happened to be cached inside it - which is
                -- usually the wrong picture for the category, and reads as a
                -- bug rather than a choice. The label IS the tile.
                display_mode = nav_mode,
                folder      = item,
                width       = slot_w,
                height      = non_book_h,
                on_tap      = opts.on_opds_nav_tap,
                -- Under the reader's own badge settings, as a local folder's.
                book_count     = (src_folder and show_folder_badge) and tonumber(item.book_count) or nil,
                finished_count = (src_folder and show_folder_badge and show_finished)
                                 and tonumber(item.finished_count) or nil,
                finished_total = (src_folder and show_folder_badge and show_finished)
                                 and tonumber(item.finished_total) or nil,
                -- Was a bare `return true` -- the gesture was swallowed and
                -- did nothing. It opens the start-folder menu now, and the
                -- swallow stays as the fallback so a long-press still cannot
                -- fall through to whatever is behind the tile.
                on_hold     = opts.on_opds_nav_hold
                              or function() return true end,
                is_selected = nav_cur,
                -- Coverless OPDS nav tiles resolve on a tap, so the folder tab
                -- + repeated label are redundant over the label-placeholder;
                -- render the bare card instead.
                plain_if_placeholder = not (src_folder and item.cover_image_path),
            -- NEVER an external label. The tile is always the text style now
            -- (above), and a text card IS the name - printing it underneath
            -- says everything twice. Asking group_mode here was the bug: the
            -- tile was forced to text while the LABEL still followed the
            -- chip's style, so a catalog whose chip was set to any other mode
            -- got a text card with its own name repeated below it.
            }, StackDisplay.externalLabel(nav_mode, item.label))
        elseif item and item.kind == "author" then
            -- Author group (SeriesStack visual, author name on the band)
            local author_fp = item.books and item.books[1] and item.books[1].filepath
            local author_k    = stack_sel_count(item.books)
            local author_bulk = author_k > 0
            local author_cur  = opts.selected_filepath and author_fp
                                and author_fp == opts.selected_filepath or false
            local author_finished, author_finished_total = group_finished(item)
            row[#row + 1] = wrap_for_title_alignment(SeriesStack:new{
                display_mode = group_mode,
                series           = item,
                width            = slot_w,
                height           = non_book_h,
                on_tap           = opts.on_author_tap,
                on_hold          = opts.on_author_hold,
                is_selected      = author_bulk or author_cur,
                is_bulk_selected = author_bulk,
                selected_count   = partial_count(author_k, item.books and #item.books or 0),
                finished_count   = author_finished,
                finished_total   = author_finished_total,
                show_count_badge = show_group_badge,
            }, _groupLabel(item, item.series_name))
        elseif item and item.kind == "genre" then
            -- Genre group (SeriesStack visual, genre name on the band)
            local genre_fp = item.books and item.books[1] and item.books[1].filepath
            local genre_k    = stack_sel_count(item.books)
            local genre_bulk = genre_k > 0
            local genre_cur  = opts.selected_filepath and genre_fp
                               and genre_fp == opts.selected_filepath or false
            local genre_finished, genre_finished_total = group_finished(item)
            row[#row + 1] = wrap_for_title_alignment(SeriesStack:new{
                display_mode = group_mode,
                series           = item,
                width            = slot_w,
                height           = non_book_h,
                on_tap           = opts.on_genre_tap,
                on_hold          = opts.on_genre_hold,
                is_selected      = genre_bulk or genre_cur,
                is_bulk_selected = genre_bulk,
                selected_count   = partial_count(genre_k, item.books and #item.books or 0),
                finished_count   = genre_finished,
                finished_total   = genre_finished_total,
                show_count_badge = show_group_badge,
            }, _groupLabel(item, item.series_name))
        elseif item and item.kind == "tag" then
            -- Tag / collection group (SeriesStack visual, collection
            -- name on the band)
            local tag_fp = item.books and item.books[1] and item.books[1].filepath
            local tag_k    = stack_sel_count(item.books)
            local tag_bulk = tag_k > 0
            local tag_cur  = opts.selected_filepath and tag_fp
                             and tag_fp == opts.selected_filepath or false
            local tag_finished, tag_finished_total = group_finished(item)
            row[#row + 1] = wrap_for_title_alignment(SeriesStack:new{
                display_mode = group_mode,
                series           = item,
                width            = slot_w,
                height           = non_book_h,
                on_tap           = opts.on_tag_tap,
                on_hold          = opts.on_tag_hold,
                is_selected      = tag_bulk or tag_cur,
                is_bulk_selected = tag_bulk,
                selected_count   = partial_count(tag_k, item.books and #item.books or 0),
                finished_count   = tag_finished,
                finished_total   = tag_finished_total,
                show_count_badge = show_group_badge,
            }, _groupLabel(item, item.series_name))
        elseif item and item.kind == "language" then
            local lang_fp = item.books and item.books[1] and item.books[1].filepath
            local lang_k    = stack_sel_count(item.books)
            local lang_bulk = lang_k > 0
            local lang_cur  = opts.selected_filepath and lang_fp
                              and lang_fp == opts.selected_filepath or false
            local lang_finished, lang_finished_total = group_finished(item)
            row[#row + 1] = wrap_for_title_alignment(SeriesStack:new{
                display_mode = group_mode,
                series           = item,
                width            = slot_w,
                height           = non_book_h,
                on_tap           = opts.on_language_tap,
                on_hold          = opts.on_language_hold,
                is_selected      = lang_bulk or lang_cur,
                is_bulk_selected = lang_bulk,
                selected_count   = partial_count(lang_k, item.books and #item.books or 0),
                finished_count   = lang_finished,
                finished_total   = lang_finished_total,
                show_count_badge = show_group_badge,
            }, _groupLabel(item, item.series_name))
        elseif item and item.books then
            -- SeriesGroup (has a .books array; legacy detection — kind
            -- not always set on series records).
            local series_fp = item.books and item.books[1] and item.books[1].filepath
            local series_k    = stack_sel_count(item.books)
            local series_bulk = series_k > 0
            local series_cur  = opts.selected_filepath and series_fp
                                and series_fp == opts.selected_filepath or false
            local series_finished, series_finished_total = group_finished(item)
            row[#row + 1] = wrap_for_title_alignment(SeriesStack:new{
                display_mode = group_mode,
                series           = item,
                width            = slot_w,
                height           = non_book_h,
                on_tap           = opts.on_series_tap,
                on_hold          = opts.on_series_hold,
                is_selected      = series_bulk or series_cur,
                is_bulk_selected = series_bulk,
                selected_count   = partial_count(series_k, item.books and #item.books or 0),
                finished_count   = series_finished,
                finished_total   = series_finished_total,
                show_count_badge = show_group_badge,
            }, _groupLabel(item, item.series_name))
        elseif item then
            -- Single book record
            local book_bulk = opts.selection and item.filepath
                              and opts.selection:contains(item.filepath) or false
            local book_cur  = opts.selected_filepath and item.filepath
                              and item.filepath == opts.selected_filepath or false
            -- True-aspect: size THIS cover's box so its inner image lands at
            -- the book's own aspect ratio, capped at the cover area height.
            -- Collapsed: the row's align="bottom" drops it onto the shelf line.
            -- Expanded: a top-pad span inside the slot stack (below) does the
            -- same, so cover bottoms -- and the titles under them -- align.
            local spine_h = cover_h
            if true_aspect then
                spine_h = SpineWidget.trueAspectBoxHeight(slot_w, item, cover_h)
            end
            local spine = SpineWidget:new{
                book             = item,
                width            = slot_w,
                height           = spine_h,
                -- When titles are visible, the InputContainer wrapper below
                -- handles taps for the whole slot (cover + title) so the
                -- title area is also tappable; pass nil here so SpineWidget
                -- doesn't double-fire.
                on_tap           = (not show_titles) and on_book_tap_stamped or nil,
                on_hold          = (not show_titles) and opts.on_book_hold or nil,
                -- Double tap opens directly (#271); same collapsed-only
                -- gating as on_tap (the titled slot below handles it in
                -- expanded mode).
                on_double_tap    = (not show_titles) and opts.on_book_open or nil,
                is_selected      = book_bulk or book_cur,
                is_bulk_selected = book_bulk,
                -- Grid covers are the only surface that gets progress
                -- indicators (top-edge bar + bottom-left bookmark glyph).
                -- Hero card, folder stacks, and series stacks reuse
                -- SpineWidget for the underlying cover but opt out.
                show_progress = true,
                -- Plumb expanded-mode flag so SpineWidget can lift the
                -- bookmark glyph fully inside the cover (avoiding clash
                -- with the title text below). Regular mode lets it dangle.
                show_titles   = show_titles,
                -- Pass through the single-series context so SpineWidget
                -- can apply the user's "Show series #" preference -- the
                -- "Within series folder" option only renders the badge
                -- when in_series is true.
                in_series     = opts.in_series == true,
            }
            if show_titles then
                -- Strip layout. When draw_label is true we add the
                -- usual gap + TextWidget. When false (label_mode =
                -- "none") we reserve the same total height with a
                -- single VerticalSpan, so covers don't grow when the
                -- user toggles into None.
                local slot_dimen = Geom:new{ w = slot_w, h = slot_h }
                local stack = VerticalGroup:new{ align = "center" }
                -- True-aspect: push a shorter cover DOWN within the cover area
                -- so its bottom meets the common shelf line (and its title,
                -- appended below, aligns with the others). The three parts
                -- (headroom + cover + title strip) still sum to slot_h.
                if true_aspect and spine_h < cover_h then
                    stack[#stack + 1] = VerticalSpan:new{ width = cover_h - spine_h }
                end
                stack[#stack + 1] = spine
                -- Never a label under a PLACEHOLDER cover: the fallback card
                -- already shows the title (and author) larger and centred, so a
                -- line below would just repeat it. Reserve the strip height
                -- anyway (the else branch) so cover bottoms stay aligned with
                -- the labelled covers in the same row.
                -- An empty label (a Custom template that expanded to nothing for
                -- this book) is no label: no plate, just the reserved strip.
                local title_text = (draw_label and not spine.is_fallback)
                    and _labelFor(item) or ""
                if title_text ~= "" then
                    -- TextWidget (single-line) auto-truncates with ellipsis at
                    -- max_width — exactly what we want here. TextBoxWidget would
                    -- wrap to two lines for longer titles which crowds the grid.
                    local title_widget = plated(TextWidget:new{
                        text      = title_text,
                        face      = title_face,
                        bold      = title_bold,
                        fgcolor   = label_ink,
                        max_width = plateTextWidth(slot_w),
                    })
                    stack[#stack + 1] = VerticalSpan:new{ width = label_gap }
                    stack[#stack + 1] = title_widget
                else
                    stack[#stack + 1] = VerticalSpan:new{ width = title_block_h }
                end
                local slot = InputContainer:new{ dimen = slot_dimen, stack }
                -- The ribbon and the tick hang half their height below the
                -- cover, into the label strip. The label used to be bare text
                -- and the dangle showed through it; a filled plate is painted
                -- after the cover and cropped the glyphs. The plate stays where
                -- it is and the glyphs go back on top of it, the overlap the
                -- maintainer chose ("the dangle can appear over the plate").
                if plate_fill and title_text ~= "" then
                    local base_paint = slot.paintTo
                    slot.paintTo = function(s, bb, x, y)
                        base_paint(s, bb, x, y)
                        SpineWidget.repaintOverhangGlyphs(spine, bb)
                    end
                end
                slot.ges_events = {
                    Tap  = { GestureRange:new{ ges = "tap",  range = slot_dimen } },
                    Hold = { GestureRange:new{ ges = "hold", range = slot_dimen } },
                    -- Double tap opens directly (#271). Inert unless the user
                    -- enabled KOReader's global double tap.
                    DoubleTap = { GestureRange:new{ ges = "double_tap", range = slot_dimen } },
                }
                local on_tap_cb  = on_book_tap_stamped
                local on_open_cb = opts.on_book_open
                local on_hold_cb = opts.on_book_hold
                local slot_spine = spine
                function slot:onTap()
                    -- Expanded mode: the SpineWidget carries no on_tap, so its
                    -- own onTap (which records the tapped cover for the opening
                    -- effect) never fires. Record it here so the squeeze
                    -- targets this cover, exactly as the collapsed path does.
                    SpineWidget.last_tapped = slot_spine
                    if on_tap_cb then on_tap_cb(item) end
                    return true
                end
                function slot:onDoubleTap()
                    SpineWidget.last_tapped = slot_spine
                    if on_open_cb then on_open_cb(item) end
                    return true
                end
                function slot:onHold()
                    if on_hold_cb then on_hold_cb(item) end
                    return true
                end
                row[#row + 1] = slot
            else
                row[#row + 1] = spine
            end
        else
            -- Empty slot — a bare Widget with a sized dimen. FrameContainer
            -- crashes on getSize() when its self[1] child is nil, so we use
            -- the lighter-weight Widget directly. Widget:getSize() returns
            -- self.dimen, which gives the row a stable slot footprint.
            row[#row + 1] = Widget:new{
                dimen = Geom:new{ w = slot_w, h = slot_h },
            }
        end
    end

    -- Shelf base rule removed (read as visual noise rather than support).
    -- When slot_w was shrunk to preserve 2:3 under a tight height budget, the
    -- covers no longer span opts.width. Centring left clumped "empty space
    -- either side"; instead the row was rebuilt above with a WIDENED gap (see
    -- the gap recompute near slot_w finalisation) so the covers spread evenly
    -- across the full width. The CenterContainer is now only a safety net for
    -- the single-column case where there's no inter-cover gap to widen.
    if custom_label then
        local st = require("lib/bookshelf_cover_label").takeStats()
        logger.dbg(string.format(
            "[bookshelf perf] cover labels: %.2fms hit=%d miss=%d",
            label_ms, st.hits, st.misses))
    end

    local row_w = n_slots * slot_w + (n_slots - 1) * gap
    local result = row
    if opts.width and opts.width > row_w and n_slots <= 1 then
        result = CenterContainer:new{
            dimen = Geom:new{ w = opts.width, h = slot_h },
            row,
        }
    end
    -- Report the ACTUAL cover-area dimensions this row rendered into, so the
    -- preload can warm next-page covers at exactly the size the shelf uses --
    -- correct across DPI, expanded/collapsed, stretch/shrink, and label
    -- settings -- instead of re-deriving (and drifting from) this math. cover_h
    -- already accounts for the title strip and any stretch/shrink; warming at
    -- the cover AREA (which is >= the bordered cover image SpineWidget paints)
    -- guarantees ScaledCoverCache's "cached >= requested" check passes.
    result.cover_w = slot_w
    result.cover_h = cover_h
    return result
end

return ShelfRow
