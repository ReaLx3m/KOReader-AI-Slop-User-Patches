-- bookshelf_hold_gate.lua -- the pure decision behind "hold the previous
-- screen until the BookOrbit book list lands" (HANDOFF_hold_page).
--
-- No KOReader requires, no globals, no clock: everything the widget knows is
-- handed in, so the decision can be tested without a device.
--
--   Hold.stamp(t)         -> normalised layout stamp, or nil when t is not a
--                            complete stamp
--   Hold.sameLayout(a, b) -> true only when both are complete stamps and every
--                            field is equal
--   Hold.decide(ctx)      -> "hold" | "paint", reason
--   Hold.eligible(ctx)    -> true | false, reason   (decide() minus the page)
--
-- WHAT A STAMP IS. The layout inputs that decide how a frame looks, read at
-- the moment a frame is painted and again at the moment a hold is considered.
-- If they differ, the frame on screen is not what a normal paint would
-- produce now, so holding it would show something wrong: paint instead.
--
-- WHAT A STAMP CANNOT SEE. The settings store's generation counter is not in
-- it: every chip switch and page turn bumps it (saveDeferred), so it would
-- veto every hold. A setting that changes the look without touching one of
-- the fields below (a font scale, the chip-bar height) is therefore NOT
-- detected; if its rebuild happens to hit an uncached page, the change shows
-- when the list lands. Accepted and documented (handoff R-H4).
--
-- WHY nested/draft/want_all ARE INPUTS. They name rebuilds that are not "the
-- user asked for a screen": the label-strip and cursor-clamp retries, the
-- draft regrid of a pinch, a whole-view fetch. None of them may hold.

local M = {}

local function isNum(v) return type(v) == "number" and v == v end

-- stamp(t) -> table | nil
-- Copies only the known fields, so a caller's extra bookkeeping can never leak
-- into the comparison, and normalises the optional ones.
function M.stamp(t)
    if type(t) ~= "table" then return nil end
    if not (isNum(t.w) and isNum(t.h) and isNum(t.n_shelves)
            and isNum(t.n_cols) and type(t.view_mode) == "string") then
        return nil
    end
    return {
        w         = t.w,
        h         = t.h,
        n_shelves = t.n_shelves,
        n_cols    = t.n_cols,
        view_mode = t.view_mode,
        night     = t.night and true or false,
        expanded  = t.expanded and true or false,
        hero_mode = type(t.hero_mode) == "string" and t.hero_mode or "",
        aspect    = isNum(t.aspect) and t.aspect or 0,
    }
end

local COMPARED = { "w", "h", "n_shelves", "n_cols", "view_mode",
                   "night", "expanded", "hero_mode", "aspect" }

-- sameLayout(a, b) -> bool
-- Raw tables are accepted and normalised, so a caller may pass either a
-- stamp() result or the table it would have passed to stamp().
function M.sameLayout(a, b)
    local sa, sb = M.stamp(a), M.stamp(b)
    if not (sa and sb) then return false end
    for _i, k in ipairs(COMPARED) do
        if sa[k] ~= sb[k] then return false end
    end
    return true
end

-- decide(ctx) -> "hold"|"paint", reason
--
-- ctx = { enabled, painted, grid_mode, draft_regrid, nested, want_all,
--         stamp_now, stamp_last, pending, failed }
--
-- Reason priority is fixed (first match wins):
--   disabled > no_frame > not_grid > draft > nested > want_all
--   > layout_changed > not_pending > failed > hold
--
-- `pending` is the page table of a pending BookOrbit page (anything but a
-- table means the page is not pending); `failed` is true when the source
-- answered "failed" for it. A garbage ctx never throws: it answers "paint".
function M.decide(ctx)
    if type(ctx) ~= "table"        then return "paint", "disabled" end
    if not ctx.enabled             then return "paint", "disabled" end
    if not ctx.painted             then return "paint", "no_frame" end
    if not ctx.grid_mode           then return "paint", "not_grid" end
    if ctx.draft_regrid            then return "paint", "draft" end
    if ctx.nested                  then return "paint", "nested" end
    if ctx.want_all                then return "paint", "want_all" end
    if not M.sameLayout(ctx.stamp_now, ctx.stamp_last) then
        return "paint", "layout_changed"
    end
    if type(ctx.pending) ~= "table" then return "paint", "not_pending" end
    if ctx.failed                  then return "paint", "failed" end
    return "hold", "hold"
end

-- eligible(ctx) -> bool, reason
-- Everything decide() asks EXCEPT the page itself: true when a hold would be
-- allowed if the page turned out to be pending. The render path asks this
-- BEFORE it fetches, so it never pays for a pre-flight fetch it cannot use.
-- The reason is decide()'s, or "eligible" when it passes.
function M.eligible(ctx)
    if type(ctx) ~= "table" then return false, "disabled" end
    local probe = {}
    for k, v in pairs(ctx) do probe[k] = v end
    probe.pending, probe.failed = {}, false
    local verdict, reason = M.decide(probe)
    if verdict == "hold" then return true, "eligible" end
    return false, reason
end

return M
