--[[--
Glue between the freshness controller (lib/bookshelf_bookorbit_fresh.lua) and
the real plugin: settings, network state, the Auto Wi-Fi gate, the sync
coordinator, the shelf widget. Everything is reached through the `env` table
given to Glue.build, so the decisions made here (what counts as "the chip on
screen", when a redraw is allowed, what a tap does) are unit tested off-device
with fakes (tools/bo_tests/test_bo_fresh.lua). Glue.get() builds the one real
instance lazily from the real modules.

Rules (HANDOFF_section_freshness, sections 1 and 4):
  * Only the chip ON SCREEN is ever checked, and only Continue reading and
    Want to read. No background checks of other chips.
  * Never turns Wi-Fi on by itself and never prompts for it. The wait for an
    Auto Wi-Fi reconnect (wake on home, book closed) goes through
    BookOrbit.withAutoWifi WITHOUT `trigger`, so a manual off stays respected.
  * Nothing here may break showing the shelf: every entry point is pcall'd.
]]

local Fresh = require("lib/bookshelf_bookorbit_fresh")

local Glue = {}

-- A tapped chip shows its cached books at once; the check starts a moment
-- later so it never competes with the repaint.
Glue.TAP_DELAY = 0.5

local SETTING_KEY = "bookorbit_section_refresh"   -- default on; menu row "Refresh sections automatically" in lib/bookshelf_settings.lua

--- Glue.build(env) -> service
-- env:
--   BookOrbit        lib/bookshelf_bookorbit (isConfigured, withAutoWifi, submitSyncJob)
--   BOSource         lib/bookshelf_bookorbit_source (fresh* hooks)
--   settings         { nilOrTrue(key) }
--   UIManager        { scheduleIn, nextTick, setDirty, isWidgetShown }
--   online()         -> bool, the radio is really online (fail closed)
--   widget()         -> the live BookshelfWidget or nil
--   book_open()      -> bool
--   now()            -> seconds
--   logger           optional
-- service: { fc, checkActive(opts), checkWhenOnline(opts), scheduleTapCheck(opts), cancel() }
function Glue.build(env)
    local BookOrbit, BOSource, UIManager = env.BookOrbit, env.BOSource, env.UIManager

    local function safeCall(fn, ...)
        local ok, a, b = pcall(fn, ...)
        if not ok then
            if env.logger and env.logger.warn then
                pcall(env.logger.warn, "Bookshelf BookOrbit fresh glue:", a)
            end
            return nil
        end
        return a, b
    end

    -- The BookOrbit chip id of the chip the user is looking at, or nil. nil
    -- whenever the shelf is not what is on screen: not shown, a book open
    -- underneath, drilled into something, or a chip that is not Continue
    -- reading / Want to read.
    local function currentChip()
        local w = env.widget()
        if not w then return nil end
        if not UIManager:isWidgetShown(w) then return nil end
        if env.book_open() then return nil end
        if not w._activeFreshChipId then return nil end
        return w:_activeFreshChipId()
    end

    -- D6: redraw only when the chip is STILL the one on screen. Otherwise the
    -- cache is just left invalidated and the next visit loads fresh.
    local function onChanged(kind, id)
        local w = env.widget()
        if not w then return end
        if not UIManager:isWidgetShown(w) or env.book_open() then
            -- Shelf parked under a reader: make the next show repaint it
            -- (same flag _refreshBookOrbitChipAfterReconnect sets).
            w._metadata_dirty_force_full_refresh = true
            return
        end
        if currentChip() ~= id then return end
        -- Next tick, and re-checked there: the user may have tapped on in
        -- between. No redraw at all when nothing changed (never reaches here).
        UIManager:nextTick(function()
            safeCall(function()
                if env.widget() ~= w or currentChip() ~= id then return end
                w:_rebuild()
                UIManager:setDirty(w, "ui")
            end)
        end)
    end

    local deps = {
        now     = env.now,
        enabled = function()
            if env.settings and env.settings.nilOrTrue
                    and not env.settings.nilOrTrue(SETTING_KEY) then
                return false
            end
            return BookOrbit.isConfigured() and true or false
        end,
        connected = function() return env.online() and true or false end,
        -- Auto Wi-Fi on: a lease; schedule runs when online, on_fail("timeout" |
        -- "manual_off") otherwise. Auto Wi-Fi off: schedule runs at once, online
        -- or not (the controller re-tests connected() and then skips).
        -- No `trigger`: that would clear a manual off.
        wait_for_network = function(_reason, on_ready, on_fail)
            BookOrbit.withAutoWifi(function(afterDone) on_ready(afterDone) end, {
                reason  = "section_refresh",
                on_fail = on_fail,
            })
        end,
        current_chip  = currentChip,
        kind_of       = function(id) return BOSource.freshKind(id) end,
        probe         = function(kind, id) return BOSource.freshProbe(kind, id) end,
        get_sig       = function(id) return BOSource.freshGetSig(id) end,
        set_sig       = function(id, sig) return BOSource.freshSetSig(id, sig) end,
        store_records = function(kind, id, recs) return BOSource.freshStoreRecords(kind, id, recs) end,
        invalidate    = function(kind, id) return BOSource.freshInvalidate(kind, id) end,
        submit        = function(job) return BookOrbit.submitSyncJob(job) end,
        on_changed    = onChanged,
        logger        = env.logger,
    }
    local fc = Fresh.new(deps)

    local svc = { fc = fc, currentChip = currentChip }

    --- Check the chip on screen right now (tap, swipe). Resolves the chip at
    -- call time, so a delayed call checks whatever is on screen then.
    function svc.checkActive(opts)
        return safeCall(function()
            local id = currentChip()
            if not id then return "no_chip" end
            local kind = BOSource.freshKind(id)
            if not kind then return "no_chip" end
            return fc:check(kind, id, opts)
        end)
    end

    --- Wake on home / book closed: wait for Wi-Fi (Auto Wi-Fi), then check.
    function svc.checkWhenOnline(opts)
        return safeCall(function() return fc:checkWhenOnline(opts) end)
    end

    --- A chip was tapped / swiped to: its cached books are already painted.
    -- Check it shortly after (no waiting for Wi-Fi: a tap is not worth holding
    -- the radio for; offline simply skips).
    function svc.scheduleTapCheck(opts)
        opts = opts or { reason = "tap" }
        safeCall(function()
            if not currentChip() then return end   -- cheap pre-filter: other chips cost nothing
            UIManager:scheduleIn(Glue.TAP_DELAY, function() svc.checkActive(opts) end)
        end)
    end

    function svc.cancel() safeCall(function() fc:cancel() end) end

    return svc
end

local _instance

--- Glue.get() -> the one real service (built lazily). Returns nil if it
-- cannot be built, so callers just do nothing.
function Glue.get()
    if _instance then return _instance end
    local ok, svc = pcall(function()
        local UIManager = require("ui/uimanager")
        local logger = require("logger")
        return Glue.build{
            BookOrbit = require("lib/bookshelf_bookorbit"),
            BOSource  = require("lib/bookshelf_bookorbit_source"),
            settings  = require("lib/bookshelf_settings_store"),
            UIManager = UIManager,
            logger    = logger,
            now       = os.time,
            online    = function()
                local ok_n, NetworkMgr = pcall(require, "ui/network/manager")
                if not (ok_n and NetworkMgr) then return false end
                local ok_o, online = pcall(function() return NetworkMgr:isOnline() end)
                return ok_o and online == true
            end,
            widget    = function()
                local ok_w, W = pcall(require, "lib/bookshelf_widget")
                return ok_w and W and W.live or nil
            end,
            -- Same test main.lua's _bookIsOpen uses.
            book_open = function()
                local ok_r, ReaderUI = pcall(require, "apps/reader/readerui")
                local ui = ok_r and ReaderUI and ReaderUI.instance
                return (ui and ui.document and true) or false
            end,
        }
    end)
    if not ok then
        pcall(function() require("logger").warn("Bookshelf BookOrbit fresh glue: build failed", svc) end)
        return nil
    end
    _instance = svc
    return _instance
end

return Glue
