--[[
Data for the BookOrbit micro-modules (the widgets ported from the BookOrbit
plugin's dashboard board).

Every BookOrbit widget reads one table, `d`. The original builds it in one go
(bookorbit_board_data.lua, vendored as lib/bookorbit_board/data.lua) from the
server dashboard plus KOReader's own statistics. This file feeds that builder
and keeps it off the render path:

  Data.get{ preview, refresh, needs }  ->  d

CONTRACT (never relax it):
  * get() NEVER blocks and NEVER touches the network. It builds `d` from what
    is known right now: the cached dashboard (memory, then the shared disk
    cache), a snapshot of the local statistics, covers already on disk.
  * Anything slow happens later, behind a TTL, in a scheduled task, and ends in
    the card's `refresh()` so it repaints once:
      - server: ONE shared background job (BookOrbit sync coordinator, so it
        never races a progress sync) fetches the dashboard, plus every shelf /
        name list a rendered widget asked for (`needs`);
      - local: statistics.sqlite3 / vocabulary / disk scans run one per tick
        from a queue, only for the values a widget actually drew;
      - covers: downloaded one per tick, a few repaints for the whole batch.
  * get{ preview = true } (the Add picker) is sample-safe: built-in sample data,
    no fetch, no queue, no disk or sqlite read.
  * Not configured / offline / old server never raise: `d.not_configured`,
    `d.unavailable` and `d.stale` say which, and the adapter shows a hint.

How the vendored builder is kept off the render path without editing it: its
slow helpers (localDaily, hours, records, pageTurns, wordOfTheDay, storage,
forecast, unopened) are replaced, once, by versions that answer from a
snapshot and queue the real helper for later. The builder's own call sites
(`BoardData.hours(now)` etc.) go through that table, so nothing else changes.
]]
local logger = require("logger")

local Data = {}

-- ----------------------------------------------------------------- tunables
local DASH_TTL = 300          -- seconds a server answer counts as fresh
local BACKOFF_MIN = 120       -- after a failed fetch, wait at least this long
local BACKOFF_MAX = 900
local UNSUPPORTED_BACKOFF = 1800
local MAX_COVER_QUEUE = 24    -- covers waiting for download at once
local COVER_BATCH = 3         -- covers per repaint while downloading
local EXISTS_TTL = 60         -- seconds a "this downloaded file exists" answer lives

local SECTION_CAPABILITY = "catalogDashboardSections"
-- Shelf sources served by the dashboard-section endpoint (not catalog/books).
local SECTION_SOURCES = { ["want-to-read"] = true, ["up-next-in-series"] = true }
-- Shelf sources that carry a catalog filter (one library, author, ...).
local SELECTOR_SOURCES = {
    libraries = true, authors = true, series = true, collections = true, ["smart-scopes"] = true,
}
-- Sources the dashboard body already holds: never fetched on their own.
local BODY_SOURCES = { ["in-progress"] = true, finished = true }
local NAME_SECTIONS = { collections = "collections", scopes = "smart-scopes" }
local SHELF_PAGE_SIZE = 12

-- ------------------------------------------------------------------- state
-- The seams on the vendored builder are installed once per process; they live
-- outside S so resetting state never re-wraps an already wrapped function.
local patched = false
local orig = {}

local S
local function freshState()
    return {
        acct = nil,
        dash = nil,                 -- { at, body }
        shelves = {},               -- shelf key -> { at, books }
        names = {},                 -- name key -> { at, list }
        want_shelves = {},          -- shelf key -> { source, params }
        want_names = {},            -- name key -> true
        listeners = {},             -- refresh fn -> true
        fetch_pending = false,
        backoff_until = 0,
        fail_count = 0,
        unsupported = false,        -- server has no dashboard endpoint
        section_unsupported = false,
        snap = {},                  -- local snapshot: key -> { at, v }
        lq = {}, lq_keys = {}, lq_scheduled = false,
        covers = {}, cover_keys = {}, cover_running = false, cover_batch = 0,
        exists = {},                -- path -> { at, v }
        md5 = {},                   -- path -> md5 | false
        preview = false,            -- true only while a preview `d` is built
        fetch_started = 0,
    }
end
S = freshState()

-- Lazy requires: every one of these may be a stub in tests, and none may be
-- loaded just because this file is.
local function UIManager() return require("ui/uimanager") end
local function BookOrbit() return require("lib/bookshelf_bookorbit") end
local function Cache() return require("lib/bookshelf_bookorbit_cache") end
local function Source() return require("lib/bookshelf_bookorbit_source") end

local function isConnected()
    local ok, NetworkMgr = pcall(require, "ui/network/manager")
    if not ok or not NetworkMgr then return false end
    local ok2, v = pcall(function() return NetworkMgr:isConnected() end)
    return ok2 and v == true
end

local function configured()
    local ok, v = pcall(function() return BookOrbit().isConfigured() end)
    return ok and v == true
end

local function acctKey()
    local ok, cfg = pcall(function() return BookOrbit().getConfig() end)
    if not ok or type(cfg) ~= "table" then return "none" end
    return tostring(cfg.server_url) .. "|" .. tostring(cfg.username)
end

local function cacheKey(...)
    return "bo_board:" .. S.acct .. ":" .. table.concat({ ... }, ":")
end

local function cacheGet(key)
    local ok, v = pcall(function() return Cache().get(key) end)
    if ok and type(v) == "table" and type(v.at) == "number" then return v end
    return nil
end

local function cacheSet(key, value)
    local ok, err = pcall(function() Cache().set(key, value) end)
    if not ok then logger.warn("[bookshelf] BookOrbit widgets: cache write failed:", err) end
end

-- Drop everything held for another account (sign-out, server change) and
-- re-read the dashboard of this one from the shared disk cache.
local function hydrate()
    local acct = acctKey()
    if S.acct == acct then return end
    S = freshState()
    S.acct = acct
    S.dash = cacheGet(cacheKey("dash"))
end

local function shelfKeyOf(props)
    local Store = require("lib/bookorbit_board/store")
    return Store.shelfKey(props)
end

local function shelfEntry(skey)
    local e = S.shelves[skey]
    if e then return e end
    e = cacheGet(cacheKey("shelf", skey))
    if e then S.shelves[skey] = e end
    return e
end

local function nameEntry(key)
    local e = S.names[key]
    if e then return e end
    e = cacheGet(cacheKey("names", key))
    if e then S.names[key] = e end
    return e
end

-- ------------------------------------------------------------- refreshing
-- Listeners are the cards' own ctx.refresh callbacks. They are called once,
-- after a batch of background work, and dropped: a card that renders again
-- registers again. Called on the next tick so a job's coroutine is never the
-- one repainting.
local function fire()
    local list = {}
    for fn in pairs(S.listeners) do list[#list + 1] = fn end
    S.listeners = {}
    if #list == 0 then return end
    UIManager():nextTick(function()
        for _i, fn in ipairs(list) do
            local ok, err = pcall(fn)
            if not ok then logger.dbg("[bookshelf] BookOrbit widgets: refresh failed:", err) end
        end
    end)
end

local function listen(fn)
    if type(fn) == "function" then S.listeners[fn] = true end
end

-- ------------------------------------------------------------ local queue
-- One job per tick, so e-ink repaints and input stay responsive between them.
local runLocal
local function kickLocal()
    if S.lq_scheduled or #S.lq == 0 then return end
    S.lq_scheduled = true
    UIManager():scheduleIn(0.25, function() runLocal() end)
end

runLocal = function()
    S.lq_scheduled = false
    local job = table.remove(S.lq, 1)
    if job then
        S.lq_keys[job.key] = nil
        local ok, v = pcall(job.fn)
        if ok then
            S.snap[job.key] = { at = os.time(), v = v or false }
        else
            logger.warn("[bookshelf] BookOrbit widgets: local read", job.key, "failed:", v)
            -- Keep any older value; try again after the TTL, not every render.
            local old = S.snap[job.key]
            S.snap[job.key] = { at = os.time(), v = old and old.v or false }
        end
    end
    if #S.lq > 0 then
        kickLocal()
    else
        fire()
    end
end

local function wantLocal(key, fn)
    if S.lq_keys[key] then return end
    S.lq_keys[key] = true
    S.lq[#S.lq + 1] = { key = key, fn = fn }
    kickLocal()
end

-- Snapshot read: the stored value (false = "read, nothing there"), or nil when
-- never read. Queues a (re)read when missing or older than ttl.
local function snapRead(key, ttl, compute)
    local e = S.snap[key]
    if not e or os.time() - e.at > ttl then wantLocal(key, compute) end
    if e then return e.v end
    return nil
end

-- --------------------------------------------------------------- samples
-- What the Add picker's thumbnails show: believable, fixed, no I/O.
local function sampleBook(id, title, author, pct)
    return { id = id, title = title, authors = { author }, progressPercentage = pct,
        readStatus = pct and pct > 0 and "reading" or "unread", hasCover = false }
end

local function sampleBody(now)
    local minutes = {}
    for i = 1, 364 do
        minutes[i] = ((i * 7) % 11 < 5) and 0 or ((i * 13) % 40 + 5)
    end
    local books = {
        sampleBook(9001, "The Lighthouse Year", "A. Marlowe", 42),
        sampleBook(9002, "Salt and Iron", "J. Okafor", 17),
        sampleBook(9003, "Quiet Machines", "R. Lindqvist", 71),
        sampleBook(9004, "A Map of Small Hours", "T. Vance", 5),
    }
    return {
        displayName = "Reader",
        generatedAt = os.date("!%Y-%m-%dT%H:%M:%SZ", now - 1800),
        continueReading = { books[1], books[2], books[3] },
        discover = { books[4], books[3], books[2], books[1] },
        finishedThisYear = { books[4], books[3] },
        boardShelves = {},
        boardNames = { collections = { "Favourites", "Sci-fi", "To lend" }, scopes = { "Unread, short", "Long reads" } },
        browseCounts = { series = 48, authors = 212, collections = 9, smartScopes = 4, libraries = 2, inProgress = 3 },
        totalBooks = 640,
        readingGoal = { goalBooks = 24, completedBooks = 9, year = tonumber(os.date("%Y", now)) },
        readingStreak = { currentStreak = 6, longestStreak = 21,
            lastSevenDays = { true, true, false, true, true, true, true } },
        readingYear = { startDate = os.date("%Y-%m-%d", now - 363 * 86400), minutes = minutes },
        highlightOfTheDay = { text = "A reader lives a thousand lives before he dies.",
            bookTitle = "The Lighthouse Year", chapterTitle = "Chapter 7" },
        achievements = { earned = 14, total = 60,
            next = { key = "hours_read_50", groupKey = "hours_read", name = "Fifty Hours",
                description = "Read for fifty hours in all.", rarity = "common", iconName = "clock",
                threshold = 50, currentProgress = 38 },
            latest = { key = "streak_7", groupKey = "streak", name = "One Week",
                description = "Read seven days in a row.", rarity = "rare", iconName = "flame",
                awardedAt = os.date("!%Y-%m-%dT%H:%M:%SZ", now - 3 * 86400) } },
    }
end

local SAMPLE_LOCAL = {
    hours = function()
        local h = {}
        for i = 1, 24 do
            local x = i - 1
            h[i] = (x >= 6 and x <= 8) and 18 or (x >= 20 and x <= 23) and 40 or (x == 12 or x == 13) and 12 or 2
        end
        return h
    end,
    records = function() return { sessions = 112, longest_min = 94, avg_min = 27, pages_per_hour = 41 } end,
    pages = function() return { total = 48210, today = 37, since = "Mar 2024" } end,
    word = function() return { word = "petrichor", before = "the smell of ", after = " after rain", book = "The Lighthouse Year" } end,
    storage = function() return { free_gb = 12.4, total_gb = 32 } end,
}

-- Chapter line and Gathering dust need a book on this device (a chapter map /
-- an unopened file), which the Add picker never has, so their thumbnails use
-- a made-up map and a made-up dusty book.
local SAMPLE_STOPS = {
    { pct = 0, title = "Prologue" }, { pct = 8, title = "The Harbour" }, { pct = 19, title = "Salt" },
    { pct = 33, title = "The Long Night" }, { pct = 47, title = "Low Tide" }, { pct = 61, title = "The Lamp" },
    { pct = 78, title = "Storm Warning" }, { pct = 92, title = "Epilogue" },
}
local function sampleChapterLine(book)
    if not book then return nil end
    local pos = tonumber(book.progressPercentage) or 0
    local cur = 1
    for i, stop in ipairs(SAMPLE_STOPS) do if stop.pct <= pos then cur = i end end
    local per_pct = 5.4                       -- minutes per percent
    local stops = SAMPLE_STOPS
    return { book = book, stops = stops, pos = pos, cur = cur, next = math.min(cur + 1, #stops),
        per_pct = per_pct, end_min = math.floor((100 - pos) * per_pct),
        minutes = function(i) return math.max(1, math.floor((stops[i].pct - pos) * per_pct + 0.5)) end }
end
local function sampleDust()
    return { count = 7, book = sampleBook(9004, "A Map of Small Hours", "T. Vance", nil), days = 74, months = 2, total_mb = 48 }
end

-- --------------------------------------------------------- on-device shim
local function fileExists(path)
    if type(path) ~= "string" then return false end
    local e = S.exists[path]
    local now = os.time()
    if e and now - e.at < EXISTS_TTL then return e.v end
    local ok, lfs = pcall(require, "libs/libkoreader-lfs")
    local v = ok and lfs.attributes(path, "mode") == "file" or false
    S.exists[path] = { at = now, v = v }
    return v
end

local function downloadedMap()
    local ok, m = pcall(function() return Source().downloadedMap() end)
    return ok and m or {}
end

local function onDeviceMap()
    local out = {}
    for id, path in pairs(downloadedMap()) do
        if type(path) == "string" and fileExists(path) then out[tonumber(id) or id] = path end
    end
    return out
end

local function queueCover(book)
    if S.preview or not configured() then return end
    local id = tostring(book.id)
    if S.cover_keys[id] or #S.covers >= MAX_COVER_QUEUE then return end
    S.cover_keys[id] = true
    S.covers[#S.covers + 1] = book
    if S.cover_running then return end
    S.cover_running = true
    local function step()
        if not isConnected() then
            S.covers, S.cover_keys, S.cover_running = {}, {}, false
            S.cover_batch = 0
            return
        end
        local b = table.remove(S.covers, 1)
        if b then
            S.cover_keys[tostring(b.id)] = nil
            local ok, got = pcall(function() return Source().fetchBoardCover(b) end)
            if ok and got then S.cover_batch = S.cover_batch + 1 end
        end
        if #S.covers == 0 or S.cover_batch >= COVER_BATCH then
            if S.cover_batch > 0 then fire() end
            S.cover_batch = 0
        end
        if #S.covers > 0 then
            UIManager():scheduleIn(0.2, step)
        else
            S.cover_running = false
        end
    end
    UIManager():scheduleIn(0.4, step)
end

-- The object BoardData.build calls into (the original passes its catalog
-- browser). Only the pieces build() and its lazy fields use.
local function makeShim(preview, username)
    local shim = {
        settings = { username = username, catalog_recent_searches = {} },
    }
    if preview then
        shim.settings.last_sync = { at = os.time() - 3600, event = "sync" }
        shim.settings.catalog_recent_searches = { "Dune", "Le Guin" }
    else
        -- Both are small in-memory settings reads (BookOrbit.recordSync /
        -- addRecentSearch keep them), so they are safe on the render path.
        local ok, BO = pcall(BookOrbit)
        if ok and BO then
            local ok1, ls = pcall(function() return BO.lastSync and BO.lastSync() end)
            if ok1 and type(ls) == "table" then shim.settings.last_sync = ls end
            local ok2, rs = pcall(function() return BO.recentSearches and BO.recentSearches() end)
            if ok2 and type(rs) == "table" then shim.settings.catalog_recent_searches = rs end
            -- Live and persisted: the Gathering dust "next" button changes it,
            -- and build() runs again on every render, so the new value is read.
            local ok3, ds = pcall(function() return BO.dustState and BO.dustState() end)
            if ok3 and type(ds) == "table" then shim.settings.catalog_board_dust = ds end
        end
    end
    if preview then
        function shim:isOnDevice() return false end
        function shim:thumbnailDisplay() return nil, "missing" end
        function shim:onDeviceCount() return 24 end
        function shim:getCurrentDownloadDir() return nil end
        shim.on_device = {}
        shim.on_device_generation = "preview"
        return shim
    end
    function shim:isOnDevice(book)
        return self:onDeviceBookPath(book) ~= nil
    end
    function shim:onDeviceBookPath(book)
        local path = book and book.id ~= nil and downloadedMap()[tostring(book.id)]
        if type(path) == "string" and fileExists(path) then return path end
        return nil
    end
    function shim:thumbnailDisplay(book)
        local ok, path, state = pcall(function() return Source().boardCover(book) end)
        if not ok then return nil, "failed" end
        if state == "loading" then queueCover(book) end
        return path, state
    end
    function shim:onDeviceCount()
        local n = 0
        for _k in pairs(onDeviceMap()) do n = n + 1 end
        return n
    end
    function shim:getCurrentDownloadDir()
        local ok, dir = pcall(function() return BookOrbit().getDownloadDir() end)
        return ok and dir or nil
    end
    -- md5 of an on-device book, as KOReader's statistics keys it. The partial
    -- md5 reads a few KB, so it is remembered per path.
    function shim:boardBookMd5(book)
        local path = self:onDeviceBookPath(book)
        if not path then return nil end
        local v = S.md5[path]
        if v == nil then
            local ok, util = pcall(require, "util")
            local ok2, md5 = pcall(function() return ok and util.partialMD5 and util.partialMD5(path) end)
            v = ok2 and md5 or false
            S.md5[path] = v
        end
        return v or nil
    end
    -- Read lazily: only the Gathering dust widget asks for these, and the
    -- on-device map costs one stat per downloaded book.
    return setmetatable(shim, { __index = function(t, k)
        if k == "on_device" then
            local m = onDeviceMap()
            rawset(t, k, m)
            return m
        elseif k == "on_device_generation" then
            local n = 0
            for _k in pairs(downloadedMap()) do n = n + 1 end
            return tostring(n)
        end
    end })
end

-- ----------------------------------------------- vendored builder, patched
local function installSeams(BoardData, Reader)
    if patched then return end
    patched = true
    for _i, name in ipairs({ "localDaily", "hours", "records", "pageTurns", "wordOfTheDay",
            "storage", "forecast", "unopened", "chapterLine", "dust" }) do
        orig[name] = BoardData[name]
    end
    local real_pace = Reader.getBookPace

    -- Minutes per day for the year: the heatmap and everything derived.
    BoardData.localDaily = function(now)
        if S.preview then return {} end
        local v = snapRead("daily", 120, function()
            BoardData.invalidateLocal()
            return orig.localDaily(os.time())
        end)
        return v or {}
    end
    BoardData.hours = function(now)
        if S.preview then return SAMPLE_LOCAL.hours() end
        return snapRead("hours", 900, function()
            BoardData.invalidateHabits()
            return orig.hours(os.time())
        end) or nil
    end
    BoardData.records = function(now)
        if S.preview then return SAMPLE_LOCAL.records() end
        return snapRead("records", 900, function()
            BoardData.invalidateHabits()
            return orig.records(os.time())
        end) or nil
    end
    BoardData.pageTurns = function(now)
        if S.preview then return SAMPLE_LOCAL.pages() end
        return snapRead("pages", 120, function() return orig.pageTurns(os.time()) end) or nil
    end
    BoardData.wordOfTheDay = function(now)
        if S.preview then return SAMPLE_LOCAL.word() end
        return snapRead("word", 3600, function() return orig.wordOfTheDay(os.time()) end) or nil
    end
    BoardData.storage = function(dir, now)
        if S.preview then return SAMPLE_LOCAL.storage() end
        if not dir then return nil end
        return snapRead("storage:" .. dir, 300, function() return orig.storage(dir, os.time()) end) or nil
    end
    -- The finish forecast needs the book's pace from the statistics database.
    -- The pace is the slow part: read it off the render path, then let the
    -- original forecast maths run on it. A "no pace" answer is NOT handed to
    -- the original (it would remember it for the whole day).
    BoardData.forecast = function(book, md5, now)
        if S.preview or not book or not md5 then return nil end
        local pace = snapRead("pace:" .. md5, 600, function()
            return real_pace(md5, 14)
        end)
        if not pace then return nil end
        Reader.getBookPace = function() return pace end
        local ok, r = pcall(orig.forecast, book, md5, now)
        Reader.getBookPace = real_pace
        return ok and r or nil
    end
    -- Gathering dust: a scan over the downloaded books' files and sidecars.
    BoardData.unopened = function(catalog, now)
        if S.preview then return {} end
        local gen = tostring(catalog and catalog.on_device_generation)
        return snapRead("unopened:" .. gen, 3600, function()
            return orig.unopened(catalog, os.time())
        end) or {}
    end
    -- Preview only: samples (see above). Real data goes straight through; the
    -- chapter map is one small file read and dust is built from the
    -- `unopened` snapshot, so neither is slow.
    BoardData.chapterLine = function(book, md5)
        if S.preview then return sampleChapterLine(book) end
        return orig.chapterLine(book, md5)
    end
    BoardData.dust = function(catalog, books, now, skip)
        if S.preview then return sampleDust() end
        return orig.dust(catalog, books, now, skip)
    end
end

local function boardData()
    local BoardData = require("lib/bookorbit_board/data")
    local Reader = require("lib/bookorbit_board/stats_reader")
    installSeams(BoardData, Reader)
    return BoardData
end

-- ---------------------------------------------------------- server fetch
local function now_()
    return os.time()
end

local function isStale(entry, ttl)
    return not entry or now_() - entry.at > ttl
end

-- The shelves a widget asked for that the dashboard body does not already
-- hold (those come straight out of the body in BoardData.build).
local function shelfNeedsFetch(props)
    local source = props.source or "random"
    if BODY_SOURCES[source] then return false end
    return true
end

local function anythingStale()
    if not S.dash or isStale(S.dash, DASH_TTL) then return true end
    for skey, w in pairs(S.want_shelves) do
        local source = w.source or "random"
        if source == "random" and type(S.dash.body.discover) == "table" and not w.params then
            -- the dashboard body carries Discover
        elseif shelfNeedsFetch(w) and isStale(shelfEntry(skey), DASH_TTL) then
            return true
        end
    end
    for key in pairs(S.want_names) do
        if isStale(nameEntry(key), DASH_TTL) then return true end
    end
    return false
end

-- One shelf's books, fetched with the same calls the BookOrbit plugin's
-- dashboard makes (bookorbit_catalog_dashboard.lua fetchSection). Returns
-- books, err.
local function fetchShelf(source, params, body)
    local BO = BookOrbit()
    if source == "unopened" then
        boardData()   -- makes sure the seams (and `orig`) exist
        local list = orig.unopened(makeShim(false, nil), os.time())
        if #list == 0 then return {} end
        local ids = {}
        for _i, entry in ipairs(list) do ids[#ids + 1] = entry.id end
        local resp, err = BO.catalogBooks({ ids = table.concat(ids, ","), sort = "title", page = 1, size = #ids })
        if type(resp) ~= "table" then return nil, err or "invalid response" end
        return resp.items or {}
    end
    if source == "random" then
        if type(body.discover) == "table" then return body.discover end
        local resp, err = BO.catalogDiscover()
        if type(resp) ~= "table" then return nil, err or "invalid response" end
        return resp.discover or {}
    end
    if SECTION_SOURCES[source] then
        if S.section_unsupported then return {} end
        if BO.serverSupports(SECTION_CAPABILITY) == false then
            S.section_unsupported = true
            return {}
        end
        local resp, err = BO.catalogDashboardSection(source)
        if err == 404 or err == 405 then
            S.section_unsupported = true
            return {}
        end
        if type(resp) ~= "table" then return nil, err or "invalid response" end
        local section = type(resp.section) == "table" and resp.section or {}
        return section.books or {}
    end
    local q = { page = 1, size = SHELF_PAGE_SIZE }
    if source == "recently-added" then
        q.sort = "recently_added"
    elseif source == "pick-back-up" then
        q.sort, q.order, q.readStatus = "recently_read", "asc", "reading"
    elseif SELECTOR_SOURCES[source] then
        for k, v in pairs(params or {}) do q[k] = v end
    else
        return nil, "unknown shelf source"
    end
    local resp, err = BO.catalogBooks(q)
    if type(resp) ~= "table" then return nil, err or "invalid response" end
    return resp.items or {}
end

-- The whole background refresh. Runs inside a Trapper-wrapped sync job: plain
-- blocking calls are fine here, and nothing in it touches a widget.
local function runFetch()
    local BO = BookOrbit()
    local acct = S.acct
    local body, err = BO.catalogDashboard()
    if S.acct ~= acct then return end        -- signed out / switched meanwhile
    if type(body) == "table" and body.continueReading then
        S.dash = { at = now_(), body = body }
        S.unsupported = false
        S.fail_count = 0
        S.backoff_until = 0
        cacheSet(cacheKey("dash"), S.dash)
    elseif err == 404 or err == 405 then
        S.unsupported = true
        S.backoff_until = now_() + UNSUPPORTED_BACKOFF
        return
    else
        S.fail_count = S.fail_count + 1
        S.backoff_until = now_() + math.min(BACKOFF_MAX, BACKOFF_MIN * S.fail_count)
        logger.info("[bookshelf] BookOrbit widgets: dashboard fetch failed:", tostring(err))
        return                                 -- keep serving the cache; skip shelves
    end

    local dash_body = S.dash.body
    local shelves = {}
    for skey, w in pairs(S.want_shelves) do shelves[skey] = w end
    for skey, w in pairs(shelves) do
        local source = w.source or "random"
        if shelfNeedsFetch(w) and not (source == "random" and not w.params and type(dash_body.discover) == "table") then
            if isStale(shelfEntry(skey), DASH_TTL) then
                local books, serr = fetchShelf(source, w.params, dash_body)
                if S.acct ~= acct then return end
                local entry = { at = now_(), books = books or (shelfEntry(skey) and shelfEntry(skey).books) or {} }
                if books or not serr then
                    S.shelves[skey] = entry
                    cacheSet(cacheKey("shelf", skey), entry)
                else
                    -- A failed shelf is remembered briefly so it is not retried
                    -- on every render; it keeps whatever it had.
                    entry.at = now_() - DASH_TTL + BACKOFF_MIN
                    S.shelves[skey] = entry
                end
            end
        end
    end
    for key in pairs(S.want_names) do
        if isStale(nameEntry(key), DASH_TTL) then
            local resp = BO.catalogSection(NAME_SECTIONS[key], { page = 1, size = 4 })
            if S.acct ~= acct then return end
            local list = {}
            for _i, entry in ipairs(type(resp) == "table" and resp.items or {}) do
                if type(entry.title) == "string" then list[#list + 1] = entry.title end
            end
            local e = { at = now_(), list = list }
            S.names[key] = e
            cacheSet(cacheKey("names", key), e)
        end
    end
end

local function scheduleFetch()
    if S.fetch_pending then return end
    S.fetch_pending = true
    S.fetch_started = now_()
    UIManager():scheduleIn(0.5, function()
        local finished = false
        local function done(ok_run, err)
            if finished then return end
            finished = true
            S.fetch_pending = false
            if not ok_run then
                logger.warn("[bookshelf] BookOrbit widgets: refresh failed:", err)
                S.fail_count = S.fail_count + 1
                S.backoff_until = now_() + math.min(BACKOFF_MAX, BACKOFF_MIN * S.fail_count)
            end
            fire()
        end
        local ok, res = pcall(function()
            return BookOrbit().submitSyncJob{
                family = "bo_board:dashboard",
                label = "BookOrbit widgets: dashboard",
                run = function()
                    local ok_run, err = xpcall(runFetch, debug.traceback)
                    done(ok_run, err)
                end,
                on_error = function(err) done(false, err) end,
            }
        end)
        if not ok then done(false, res) end
    end)
end

-- Called from get(): decides whether a background refresh is worth starting.
local function maybeFetch()
    -- A job the coordinator dropped without running would leave this flag set
    -- for good; a fetch is never legitimately pending for minutes.
    if S.fetch_pending and now_() - S.fetch_started > 300 then S.fetch_pending = false end
    if S.fetch_pending or not anythingStale() then return end
    if now_() < S.backoff_until then return end
    if not isConnected() then return end     -- never prompts for Wi-Fi from a render
    scheduleFetch()
end

-- ------------------------------------------------------------------ get
local function normalizeNeeds(needs)
    if type(needs) ~= "table" then return end
    for _i, w in ipairs(needs.shelves or {}) do
        if type(w) == "table" then
            local skey = shelfKeyOf(w)
            if not S.want_shelves[skey] then S.want_shelves[skey] = { source = w.source or "random", params = w.params } end
        end
    end
    for _i, key in ipairs(needs.names or {}) do
        if NAME_SECTIONS[key] then S.want_names[key] = true end
    end
end

local function clockFallback(d, now)
    local T = require("ffi/util").template
    local ok, datetime = pcall(require, "datetime")
    local gs = rawget(_G, "G_reader_settings")
    d.clock = ok and datetime.secondsToHour(now, gs ~= nil and gs:isTrue("twelve_hour_clock")) or os.date("%H:%M", now)
    d.weekday = os.date("%A", now)
    d.date_long = os.date("%A, %d %B", now)
    d.day_month = T("%1 %2", tonumber(os.date("%d", now)), os.date("%B", now))
    d.day_of_year = tonumber(os.date("%j", now)) or 1
end

-- Everything BoardData computes lazily; touched while building a preview so no
-- lazy field is first evaluated after the preview flag is down.
local LAZY_FIELDS = { "hours", "records", "pages", "months", "moon", "glyph", "chapters",
    "badges", "dust", "finished_today" }

--- The `d` table for one render.
-- opts.preview  true in the Add picker (sample data, no fetch, no I/O)
-- opts.refresh  the card's ctx.refresh: called once when background work lands
-- opts.needs    { shelves = { {source=, params=}, ... }, names = { "collections", ... } }
function Data.get(opts)
    opts = opts or {}
    local now = os.time()
    local preview = opts.preview == true

    local ok_b, BoardData = pcall(boardData)
    if not ok_b then
        -- The vendored builder could not load (missing module / stub): the
        -- clock fields still work, so the clock-like widgets keep drawing.
        logger.warn("[bookshelf] BookOrbit widgets: data builder unavailable:", BoardData)
        local d = { now = now, loading = false, unavailable = true, stale = false, online = isConnected(),
            preview = preview, fingerprint = "fallback" }
        clockFallback(d, now)
        return d
    end

    local context, shim
    if preview then
        S.preview = true
        context = { dashboard = sampleBody(now), loading = false, unavailable = false, stale = false }
        shim = makeShim(true, "Reader")
    else
        hydrate()
        local is_configured = configured()
        normalizeNeeds(opts.needs)
        listen(opts.refresh)
        local body
        if S.dash then
            -- A shallow copy, not the cached table itself: the shelves are
            -- layered on top without touching what the cache holds.
            body = {}
            for k, v in pairs(S.dash.body) do body[k] = v end
            body.boardShelves, body.boardNames = {}, {}
            for skey in pairs(S.want_shelves) do
                local e = shelfEntry(skey)
                if e then body.boardShelves[skey] = e.books end
            end
            -- Anything cached from a previous session is usable too, even if
            -- no widget has asked for it yet in this one.
            for key in pairs(NAME_SECTIONS) do
                local e = nameEntry(key)
                if e then body.boardNames[key] = e.list end
            end
        end
        if is_configured then maybeFetch() end
        local online = isConnected()
        context = { dashboard = body, loading = false, unavailable = false, stale = false }
        if not is_configured then
            context.unavailable = true
        elseif body then
            context.stale = isStale(S.dash, DASH_TTL) or not online
        elseif S.fetch_pending or (online and now_() >= S.backoff_until and not S.unsupported) then
            context.loading = true            -- the first fetch is on its way
        else
            context.unavailable = true        -- offline, backing off, or an old server
        end
        local cfg_ok, cfg = pcall(function() return BookOrbit().getConfig() end)
        shim = makeShim(false, cfg_ok and type(cfg) == "table" and cfg.username or nil)
    end

    local ok, d = pcall(BoardData.build, shim, context, now)
    if not ok then
        S.preview = false
        logger.warn("[bookshelf] BookOrbit widgets: building data failed:", d)
        d = { now = now, loading = false, unavailable = true, stale = false, online = isConnected(),
            fingerprint = "error" }
        clockFallback(d, now)
        d.preview = preview
        return d
    end
    d.preview = preview
    d.not_configured = (not preview) and not configured() or false
    d.server_too_old = (not preview) and S.unsupported or false
    if preview then
        for _i, k in ipairs(LAZY_FIELDS) do local _ = d[k] end
        S.preview = false
    end
    return d
end

--- Mark everything stale so the next render refreshes it (a "refresh widgets"
-- action, or after a library change). Cached data stays on screen meanwhile.
function Data.invalidate()
    if S.dash then S.dash.at = 0 end
    for _k, e in pairs(S.shelves) do e.at = 0 end
    for _k, e in pairs(S.names) do e.at = 0 end
    S.snap = {}
    S.backoff_until = 0
end

--- Mark one shelf stale (e.g. the Discover shuffle button) so the next render
-- re-fetches just that shelf. `props` = the widget's props ({source=,params=}).
-- The old books stay on screen until the new ones land.
function Data.invalidateShelf(props)
    local e = S.shelves[shelfKeyOf(props or {})]
    if e then e.at = 0 end
    S.snap = {}
    S.backoff_until = 0
end

--- A downloaded book's file was just deleted (Gathering dust's trash button).
-- Forget what was remembered about it, and the unopened list built from the
-- files on disk, so the next render looks again. Does NOT touch the server
-- cache: nothing about the library changed.
function Data.fileRemoved(path)
    if type(path) == "string" then
        S.exists[path] = nil
        S.md5[path] = nil
    end
    for key in pairs(S.snap) do
        if type(key) == "string" and key:sub(1, 9) == "unopened:" then S.snap[key] = nil end
    end
    local ok, BoardData = pcall(require, "lib/bookorbit_board/data")
    if ok and BoardData and BoardData.invalidateUnopened then BoardData.invalidateUnopened() end
end

--- Forget all in-memory state (tests, sign-out).
function Data.reset()
    S = freshState()
end

--- Diagnostics: what the layer currently holds.
function Data.status()
    local nshelves, nnames = 0, 0
    for _k in pairs(S.shelves) do nshelves = nshelves + 1 end
    for _k in pairs(S.names) do nnames = nnames + 1 end
    return {
        acct = S.acct, has_dashboard = S.dash ~= nil, dashboard_age = S.dash and (now_() - S.dash.at) or nil,
        shelves = nshelves, names = nnames, fetch_pending = S.fetch_pending,
        backoff = math.max(0, S.backoff_until - now_()), unsupported = S.unsupported,
        local_queue = #S.lq, cover_queue = #S.covers,
    }
end

return Data
