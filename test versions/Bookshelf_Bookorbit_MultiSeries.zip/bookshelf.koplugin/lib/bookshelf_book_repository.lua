-- bookshelf_book_repository.lua
-- Unified Book record source over KOReader's ReadHistory, ReadCollection,
-- BookInfoManager, DocSettings, and (optionally) statistics.koplugin.
--
-- Design contract: this module produces Book records only — no widget code,
-- no UI imports. All external KOReader modules are reached through getter
-- functions so that pure-Lua tests can stub them via package.loaded before
-- require() is called.

local Repo = {}

local logger = require("logger")
local Filter = require("lib/bookshelf_filter")
local BookshelfSettings = require("lib/bookshelf_settings_store")
local CalibreMeta = require("lib/calibre_metadata")
local _ok = pcall(require, "lib/bookshelf_i18n")  -- soft: tests stub-load without it
local i18n = package.loaded["lib/bookshelf_i18n"]
local function tr(s) if i18n and i18n.gettext then return i18n.gettext(s) end; return s end

-- Shared wall-clock for [bookshelf perf] timestamps (and elapsed-time
-- bookkeeping); see lib/bookshelf_gettime.lua for the fallback contract.
local _gettime = require("lib/bookshelf_gettime")
local HomeDir = require("lib/bookshelf_home_dir")

-- ─── Module-local helpers ────────────────────────────────────────────────────

-- True for FictionBook files (.fb2 / .fb2.zip), whose author strings need
-- the comma treatment below.
local function _isFb2(fp)
    if type(fp) ~= "string" then return false end
    local lower = fp:lower()
    return lower:match("%.fb2$") ~= nil or lower:match("%.fb2%.zip$") ~= nil
end

-- Split a newline-separated author string into a trimmed array, or
-- return nil. KOReader's BIM joins multiple <dc:creator> entries with
-- "\n"; for most formats that's the only separator we should split on.
-- Splitting on comma corrupts library-format names like
-- "Clarke, Arthur C." into ["Clarke", "Arthur C."] and creates phantom
-- author entries on the Authors tab (issue #74 follow-up).
--
-- fb2 is the exception (#242): crengine composes each fb2 author from the
-- format's structured first/middle/last fields and joins multiple authors
-- with ", " -- so there a comma can only be the join, never part of a
-- "Surname, Forename" name, and without the extra split a co-authored
-- fb2 becomes one bogus merged author. The empty middle-name slot also
-- leaves "Alpha  Tester"-style double spaces, collapsed below so fb2 and
-- EPUB copies of the same author match exactly.
--
-- Calibre's own metadata bypasses this helper entirely -- it arrives
-- pre-split as cb.authors (table).
local function splitAuthors(s, fp)
    if not s or s == "" then return nil end
    local pat = _isFb2(fp) and "[^\n,]+" or "[^\n]+"
    local t = {}
    for part in s:gmatch(pat) do
        local cleaned = part:match("^%s*(.-)%s*$")  -- trim whitespace
            :gsub("%s+", " ")                       -- collapse internal runs
        if cleaned ~= "" then t[#t + 1] = cleaned end
    end
    return #t > 0 and t or nil
end

-- Secondary-series tag convention (#multi-series): a genre/tag of the form
-- "series:<name>" (case-insensitive prefix, optional trailing " #<n>" using
-- the same convention as the primary series field) marks additional series
-- membership for a book. Metadata managers like BookOrbit/Calibre don't
-- write a book's secondary series into the file itself -- only a single
-- primary series makes it into the EPUB's OPF -- but tags/genres DO round
-- trip through the file (dc:subject), so this is the one place multi-series
-- data can actually reach Bookshelf. Pulled out of the genre list before
-- it's shown as a Tag/Genre chip; used by getSeriesGroups to bucket the
-- book into extra Series stacks alongside its primary series.
-- Returns extra (array of { name=, num= }) or nil, and the genres list with
-- those entries removed (or the original list, untouched, when none found).
local function _extractExtraSeries(genres)
    if not genres then return nil, genres end
    local extra, kept
    for _i, g in ipairs(genres) do
        local name = g:match("^[Ss][Ee][Rr][Ii][Ee][Ss]%s*:%s*(.+)$")
        if name then
            local snum = name:match(" #(%d+)$")
            if snum then name = name:gsub(" #%d+$", "") end
            name = name:match("^%s*(.-)%s*$")  -- trim
            if name ~= "" then
                extra = extra or {}
                extra[#extra + 1] = { name = name, num = snum }
            end
        else
            kept = kept or {}
            kept[#kept + 1] = g
        end
    end
    if not extra then return nil, genres end
    return extra, kept
end

local function shallowCopyRecord(record)
    local copy = {}
    for k, v in pairs(record or {}) do
        copy[k] = v
    end
    return copy
end

-- Split a genre/tag string (or array of strings) on common EPUB delimiters
-- (comma, semicolon, pipe, newline) and return a trimmed array, or nil.
-- Slash is handled specially: only a SPACED slash ("Fiction / Fantasy",
-- BISAC-style subject hierarchies) separates genres. A bare slash is part
-- of the tag itself ("hurt/comfort" -- issue #240), so it must NOT split.
-- Normalise the spaced form to the newline delimiter up front, then split
-- on the remaining separators with bare "/" no longer among them.
-- _flipTrailingArticle(name) -> the name with a calibre-style trailing
-- article flipped to the front: "Locked Tomb, The" reads as "The Locked
-- Tomb" (issue 341). Used for folder labels and, since it is the same
-- convention, series card labels.
--
-- DISPLAY ONLY - sort still keys off the raw name, which is exactly the
-- article-insensitive ordering that naming convention exists to buy: the
-- book belongs under L, and flipping in place would put it back under T
-- and throw that away. Hence a separate label field at each call site
-- rather than rewriting the value. Only the three English articles, in
-- the capitalised form calibre writes; a lowercase ", the" or an
-- initial with a dot ("Smith, A.") is left alone. A bare "Smith, A"
-- author folder is the one known collision and judged rarer than the
-- title folders this exists for.
local function _flipTrailingArticle(name)
    if type(name) ~= "string" then return name end
    local stem, article = name:match("^(.-),%s+(The)$")
    if not stem then stem, article = name:match("^(.-),%s+(An)$") end
    if not stem then stem, article = name:match("^(.-),%s+(A)$") end
    if stem and stem ~= "" then return article .. " " .. stem end
    return name
end

local function splitGenreTags(src)
    local t = {}
    local inputs = type(src) == "table" and src or { src }
    for _i, s in ipairs(inputs) do
        local norm = s:gsub("%s+/%s+", "\n")
        for part in norm:gmatch("[^,;|\n]+") do
            local trimmed = part:match("^%s*(.-)%s*$")
            if trimmed and trimmed ~= "" then t[#t + 1] = trimmed end
        end
    end
    return #t > 0 and t or nil
end

-- Custom-metadata fast gate (issue #262). DocSettings:findCustomMetadataFile
-- stats each sidecar location per book; on a large library on slow storage
-- (Boox/Android SD, ~1200 books) those per-book stats dominated the light-meta
-- build (~15s, even with the DB read snapshotted). A custom_metadata.lua can
-- only live INSIDE a book's ".sdr" sidecar dir, so if no such dir exists in the
-- name-resolvable locations there is nothing to find. List each relevant PARENT
-- directory ONCE (cached) and check for the sibling ".sdr" by name -- turning
-- thousands of per-book stats into a handful of directory reads. The hash
-- location isn't name-derivable (it needs the file's partialMD5), so when it's
-- in play we fall back to the exact per-book probe (rare: only if a hash
-- sidecar tree exists or it's the preferred location).
local _dir_entry_cache = {}
-- See _sidecarIsOnlyLocation. Declared up here so the invalidation below
-- reaches it: declared where it is used, it was invisible to this function,
-- which cleared a global of the same name instead.
local _only_location
local function _invalidateCustomMetaGate()
    _dir_entry_cache = {}
    _only_location   = nil
end
-- Fill the per-directory cache from listings a walk already produced. The walk
-- reads every one of these directories anyway, so the gate re-reading them was
-- 29 duplicate directory listings on the reference library (~104ms of a
-- ~660ms light-meta build).
--
-- _siblingSidecarDir asks with the book's parent directory INCLUDING its
-- trailing slash, while the walk names directories without one, so normalise
-- or this silently never matches. An entry already present wins: it was read
-- directly, or seeded by a walk no older than this one.
local function _seedDirEntryCache(listings)
    if type(listings) ~= "table" then return end
    for dir, set in pairs(listings) do
        local key = dir:gsub("/*$", "") .. "/"
        if _dir_entry_cache[key] == nil then _dir_entry_cache[key] = set end
    end
end

local function _dirHasEntry(dir, name)
    local set = _dir_entry_cache[dir]
    if not set then
        set = {}
        local ok_lfs, lfs = pcall(require, "libs/libkoreader-lfs")
        if ok_lfs and lfs and lfs.attributes(dir, "mode") == "directory" then
            pcall(function()
                for entry in lfs.dir(dir) do set[entry] = true end
            end)
        end
        _dir_entry_cache[dir] = set
    end
    return set[name] == true
end
-- True when a custom_metadata.lua COULD exist for `filepath` in a location we
-- can resolve by name (doc sibling / dir mirror). Conservative: any
-- uncertainty (hash location active, unparseable path) returns true so the
-- caller does the exact probe.
-- Sibling ".sdr" for a book, but only when the cached directory listing says
-- it is really there; nil otherwise (including a hash-located sidecar, whose
-- name is not derivable from the path).
local function _siblingSidecarDir(filepath)
    local base = filepath:match("^(.*)%.") or filepath
    local parent, stem = base:match("^(.*/)([^/]+)$")
    if not (parent and stem) then return nil end
    local sdr = stem .. ".sdr"
    if _dirHasEntry(parent, sdr) then return parent .. sdr end
    return nil
end

-- True when the sibling ".sdr" is the ONLY place a custom_metadata.lua could
-- live, so finding nothing there is a definitive no rather than a reason to go
-- looking elsewhere. None of it varies per book, so it is resolved once and
-- dropped with the rest of the gate state (_only_location is declared above
-- _invalidateCustomMetaGate).
local function _sidecarIsOnlyLocation()
    if _only_location ~= nil then return _only_location end
    local only = true
    local ok_ds, DocSettings = pcall(require, "docsettings")
    if not ok_ds or not DocSettings then
        only = false
    else
        local pref = G_reader_settings
            and G_reader_settings:readSetting("document_metadata_folder", "doc") or "doc"
        if pref ~= "doc" then only = false end
        if DocSettings.isHashLocationEnabled and DocSettings.isHashLocationEnabled() then
            only = false
        end
        local ok_dst, DataStorage = pcall(require, "datastorage")
        local ok_lfs, lfs = pcall(require, "libs/libkoreader-lfs")
        if ok_dst and ok_lfs and DataStorage and lfs
                and DataStorage.getDocSettingsDir then
            local root = DataStorage:getDocSettingsDir()
            if root and lfs.attributes(root, "mode") == "directory" then
                only = false   -- a mirrored sidecar tree exists; it must be probed too
            end
        end
    end
    _only_location = only
    return only
end

local function _customMetaPossible(filepath)
    -- No lfs (e.g. the standalone test harness) -> can't list dirs; be safe
    -- and let the caller do the exact probe.
    local ok_lfs, lfs = pcall(require, "libs/libkoreader-lfs")
    if not (ok_lfs and lfs) then return true end
    local ok_ds, DocSettings = pcall(require, "docsettings")
    if not ok_ds or not DocSettings then return true end
    local pref = G_reader_settings
        and G_reader_settings:readSetting("document_metadata_folder", "doc") or "doc"
    if pref == "hash" then return true end
    if DocSettings.isHashLocationEnabled and DocSettings.isHashLocationEnabled() then
        return true
    end
    -- .sdr dir name mirrors getSidecarDir: path minus the last suffix + ".sdr".
    local base = filepath:match("^(.*)%.") or filepath
    local parent, stem = base:match("^(.*/)([^/]+)$")
    if not (parent and stem) then return true end
    local sdr = stem .. ".sdr"
    if _dirHasEntry(parent, sdr) then return true end          -- doc (sibling)
    local ok_dst, DataStorage = pcall(require, "datastorage")
    if ok_dst and DataStorage and DataStorage.getDocSettingsDir then
        local root = DataStorage:getDocSettingsDir()
        if root and _dirHasEntry(root .. parent, sdr) then return true end  -- dir (mirror)
    end
    return false
end

-- KOReader's custom metadata for a book (.sdr custom_metadata.lua's
-- custom_props table), or nil when the book has none.
--
-- KOReader lets any of title / authors / series / series_index / language /
-- keywords / description be overwritten per book from Book information, and
-- marks each overwritten field with a pencil. Every stock view shows those
-- values: extendProps merges custom_props over the document's own props, and
-- BIM stores the merged result at extraction time. Plugins that import
-- metadata KOReader cannot read itself (a ComicInfo importer for CBZ files,
-- issue #381) write here too, which is the whole reason the mechanism exists.
--
-- This is the most explicit statement of what a book is that we have, so it
-- outranks both Calibre and BIM in _resolveTextMeta below. Only `keywords`
-- was read before, which left the shelf as the one place in KOReader still
-- showing a title the user had already corrected everywhere else.
--
-- Values are non-empty strings: KOReader's editor refuses an empty one and
-- removes the key instead. `keywords` is the exception -- our own genre
-- editor writes "" to mean "cleared" -- so that field keeps nil-vs-empty
-- semantics and the others test for a non-empty string.
local function _customPropsFor(filepath)
    if not filepath then return nil end
    local ok, DocSettings = pcall(require, "docsettings")
    if not (ok and DocSettings and DocSettings.findCustomMetadataFile) then return nil end
    -- Gate and probe in one derivation. When the sibling .sdr is the only
    -- place a custom_metadata.lua can live, finding that directory in the
    -- cached listing IS the gate -- no directory, no custom metadata -- and
    -- the same path then answers the probe with a single stat.
    --
    -- The old shape derived the sidecar name twice: once in
    -- _customMetaPossible to decide whether to probe, then again inside
    -- findCustomMetadataFile, which stats every candidate location. Measured
    -- on a PW5 (243 books, 82% with a sidecar, 11 with custom metadata) the
    -- probe alone was ~190ms of a ~1000ms cold light-meta build; asking one
    -- known path instead took it to ~130ms.
    --
    -- Anything the sibling cannot answer for -- a hash-located sidecar, a
    -- mirrored sidecar tree, a path with no parent -- still goes the long way.
    local cmf
    local only_sibling = _sidecarIsOnlyLocation()
    local sdr = only_sibling and _siblingSidecarDir(filepath) or nil
    if only_sibling then
        if not sdr then return nil end
        local candidate = sdr .. "/custom_metadata.lua"
        local ok_lfs, lfs = pcall(require, "libs/libkoreader-lfs")
        if ok_lfs and lfs and lfs.attributes(candidate, "mode") == "file" then
            cmf = candidate
        end
    else
        if not _customMetaPossible(filepath) then return nil end
        cmf = DocSettings:findCustomMetadataFile(filepath)
    end
    if not cmf then return nil end
    local ok2, cp = pcall(function()
        return DocSettings.openSettingsFile(cmf):readSetting("custom_props")
    end)
    if ok2 and type(cp) == "table" then return cp end
    return nil
end

-- A custom prop that is worth using: KOReader stores non-empty strings only.
local function _cpText(cp, key)
    local v = cp and cp[key]
    return (type(v) == "string" and v ~= "") and v or nil
end

-- Per-source genre lists (each nil when that source has none for this book).
local function _calibreGenres(cb)
    if cb and type(cb.tags) == "table" and #cb.tags > 0 then return splitGenreTags(cb.tags) end
    return nil
end
local function _embeddedGenres(filepath, info, cp)
    -- nil vs "" matters here (see _customPropsFor): "" is the user clearing
    -- the keywords, which must read as "no genres" rather than falling back
    -- to the file's own.
    local kw = cp and cp.keywords
    if kw == nil then kw = info and info.keywords end
    if kw and kw ~= "" then return splitGenreTags(kw) end
    return nil
end

-- Resolve a book's genres honouring the per-book source preference, AND return
-- the per-source lists (for the source chip bar). Calibre and embedded are
-- resolved here; "hardcover" leaves the base (calibre > embedded), which
-- Hardcover.enrichBook then overrides (and stamps sources.hardcover). No
-- preference = auto priority calibre > embedded (the previous behaviour).
-- Returns: resolved_list, sources_table { calibre=, embedded= }.
local function genreData(filepath, cb, info, cp)
    local calibre  = _calibreGenres(cb)
    local embedded = _embeddedGenres(filepath, info, cp)
    local pref = BookshelfSettings.genreSource and BookshelfSettings.genreSource(filepath)
    local resolved
    if pref == "calibre"  and calibre  then resolved = calibre
    elseif pref == "embedded" and embedded then resolved = embedded
    else resolved = calibre or embedded end
    return resolved, { calibre = calibre, embedded = embedded }
end

-- ─── textual metadata resolution ─────────────────────────────────────────────
-- One place where a book's title / authors / series / language are decided,
-- for BOTH record builders (buildBookMeta and _buildLightMetaFromInfo). They
-- carried a copy of this chain each, and a copy that drifts is exactly how the
-- shelf and the chips built from it end up disagreeing about the same book.
--
-- Priority: KOReader custom metadata > Calibre > BIM > filename.
--
--   * custom metadata is the user (or a plugin acting for them) saying what
--     this book IS -- the only source here that is a statement rather than an
--     extraction, and the one every other KOReader view already shows.
--   * Calibre next, when the beta is on: a curated library beats what
--     crengine could scrape out of the file.
--   * BIM, then the filename, unchanged.
--
-- Returns a table so callers can pick what they need; every field may be nil
-- except title, which always resolves (filename last).
local function _resolveTextMeta(filepath, cb, info, cp)
    info = info or {}
    local out = {}

    -- Series. BIM stores it as "<name> #<n>" with series_index alongside;
    -- Calibre and KOReader's editor both store a bare name plus an index.
    local cp_series = _cpText(cp, "series")
    local cb_series = cb and type(cb.series) == "string" and cb.series ~= "" and cb.series
    if cp_series then
        out.series_name = cp_series
    elseif cb_series then
        out.series_name = cb_series
    elseif info.series then
        -- Guard empty / whitespace / name-less ("#3") embedded series: the
        -- Calibre branch above already drops cb.series == "", so mirror it
        -- here. Without this an empty series_name bucketed the book into a
        -- junk single-book series stack even though KOReader's book info
        -- shows the series as N/A (issue #127, non-Calibre libraries).
        local sname = info.series:gsub(" #%d+$", "")
        sname = sname:match("^%s*(.-)%s*$")  -- trim
        if sname ~= "" then out.series_name = sname end
        out.series_num = info.series:match(" #(%d+)$")
    end
    -- The number is resolved independently of the name: a custom or Calibre
    -- name with BIM still holding the only index is a real combination.
    local cp_index = _cpText(cp, "series_index")
    if cp_index then
        out.series_num = cp_index
    elseif cb and type(cb.series_index) == "number" then
        out.series_num = tostring(cb.series_index)
    elseif info.series_index then
        out.series_num = tostring(info.series_index)
    elseif info.series and not out.series_num then
        out.series_num = info.series:match(" #(%d+)$")
    end

    -- Authors. Custom and BIM store one string (newline-separated for
    -- several); Calibre stores an array.
    local cp_authors = _cpText(cp, "authors")
    if cp_authors then
        out.authors = splitAuthors(cp_authors, filepath)
    elseif cb and type(cb.authors) == "table" and #cb.authors > 0 then
        out.authors = {}
        for _i, name in ipairs(cb.authors) do
            out.authors[#out.authors + 1] = name
        end
    else
        out.authors = splitAuthors(info.authors, filepath)
    end

    out.filename = (filepath:match("([^/]+)$") or filepath):gsub("%.[^.]+$", "")
    out.title = _cpText(cp, "title")
                 or (cb and type(cb.title) == "string" and cb.title ~= "" and cb.title)
                 or (info.title and info.title ~= "" and info.title)
                 or out.filename

    out.lang = _cpText(cp, "language")
                or (cb and type(cb.languages) == "table" and cb.languages[1])
                or info.language

    return out
end

-- Write an edit of the embedded genres to KOReader's custom Keywords override
-- (the same field Show info edits), shared both ways. `genres` is the full
-- replacement list; an empty list clears the keywords (shows as no genres).
-- Creates the custom-metadata file with a copy of the original doc_props (as
-- KOReader expects) when none exists, flushes it, and broadcasts so KOReader's
-- own book-info UIs refresh. Invalidates the book cache so genres re-resolve.
function Repo.setEmbeddedGenres(filepath, genres)
    if not filepath then return end
    local DocSettings = require("docsettings")
    local keywords = (type(genres) == "table" and #genres > 0)
        and table.concat(genres, ", ") or ""
    local cmf = DocSettings:findCustomMetadataFile(filepath)
    local cds
    if cmf then
        cds = DocSettings.openSettingsFile(cmf)
    else
        cds = DocSettings.openSettingsFile()
        -- KOReader's own setCustomMetadata stashes a copy of the ORIGINAL
        -- doc_props here (title/authors/keywords/...) so a never-opened book
        -- still resolves its metadata when CoverBrowser is off. A never-opened
        -- book has no regular sidecar, so DocSettings:open() yields nothing;
        -- fall back to BIM's extracted props (originals, no custom file exists
        -- yet to overlay) so the copy isn't empty.
        local props
        local ok, sds = pcall(function() return DocSettings:open(filepath) end)
        if ok and sds then props = sds:readSetting("doc_props") end
        if not props or next(props) == nil then
            local ok_bim, BookInfoManager = pcall(require, "bookinfomanager")
            if ok_bim and BookInfoManager and BookInfoManager.getDocProps then
                local bim_props = BookInfoManager:getDocProps(filepath)
                if bim_props and next(bim_props) ~= nil then props = bim_props end
            end
        end
        cds:saveSetting("doc_props", props or {})  -- originals, for restore/“customized”
    end
    local custom_props = cds:readSetting("custom_props", {})
    custom_props.keywords = keywords
    cds:flushCustomMetadata(filepath)
    -- The file's effective keywords changed: drop the grouping caches AND the
    -- light-meta records (invalidateBookCache keeps the latter warm) so genres
    -- re-resolve from the new override on the next read.
    Repo.invalidateBookCache("embedded-genres")
    Repo.invalidateLightMeta()
    local ok_ev, Event = pcall(require, "ui/event")
    local ok_um, UIManager = pcall(require, "ui/uimanager")
    if ok_ev and ok_um then
        -- InvalidateMetadataCache deletes BIM's cached row so its next
        -- getDocProps re-extracts and overlays the new keywords; without it
        -- KOReader's Show-info keeps showing the pre-edit keywords (it reads
        -- the stale cached row). BookMetadataChanged then refreshes the UIs.
        UIManager:broadcastEvent(Event:new("InvalidateMetadataCache", filepath))
        UIManager:broadcastEvent(Event:new("BookMetadataChanged", { filepath = filepath }))
    end
end

-- Supported e-book extensions (used in getCurrent and walkBooks via
-- _supportedExt). Mirrors the document formats KOReader itself registers
-- (frontend/document/*), minus pure images and code/scripts -- those are
-- openable but aren't shelf books and would surface cover/sidecar files.
-- Compound ".zip" forms (fb2.zip etc.) are handled by _supportedExt; a bare
-- ".zip"/".tar" archive is intentionally NOT a book.
local SUPPORTED_EXT = {
    -- ebooks
    epub=true, epub3=true, fb2=true, fb3=true, mobi=true, azw=true,
    azw3=true, prc=true, pdb=true, tcr=true, ["fb2.zip"]=true,
    -- documents
    pdf=true, djvu=true, djv=true, xps=true, chm=true, doc=true, docx=true,
    docm=true, rtf=true, odt=true,
    -- text / markup (and their zipped forms)
    txt=true, md=true, html=true, htm=true, xhtml=true, htmlz=true,
    ["html.zip"]=true, ["htm.zip"]=true, ["txt.zip"]=true,
    ["md.zip"]=true, ["rtf.zip"]=true,
    -- comics
    cbz=true, cbr=true, cbt=true,
}

-- Formats other plugins register document providers for
-- See lib/bookshelf_plugin_formats for the rules.
local _plugin_formats
local function _pluginFormats()
    if _plugin_formats == nil then
        local ok, PF = pcall(require, "lib/bookshelf_plugin_formats")
        _plugin_formats = ok and PF or false
    end
    return _plugin_formats or nil
end
local function _isPluginFormat(ext)
    local PF = _pluginFormats()
    return PF and PF.isPluginFormat(ext) or false
end

-- The plugin format set as a string, for the walk cache's validity check (see
-- cachedWalk). "" when no plugin adds a format, or the module is unavailable.
local function _pluginFormatsFingerprint()
    local PF = _pluginFormats()
    return PF and PF.fingerprint() or ""
end

-- _supportedExt(name): the supported book extension for a filename (lowercased,
-- e.g. "epub" or the compound "fb2.zip"), or nil if not a book. Handles the
-- ".zip" book forms KOReader registers (fb2.zip, html.zip, ...) without
-- treating a bare/unknown ".zip" archive as a book. Formats a plugin registers
-- a document provider for count too.
local function _supportedExt(name)
    if not name then return nil end
    local last = name:match("%.([^.]+)$")
    if not last then return nil end
    last = last:lower()
    if last == "zip" then
        local compound = name:match("%.([^.]+%.[Zz][Ii][Pp])$")
        compound = compound and compound:lower()
        if not compound then return nil end
        return (SUPPORTED_EXT[compound] or _isPluginFormat(compound)) and compound or nil
    end
    return (SUPPORTED_EXT[last] or _isPluginFormat(last)) and last or nil
end

-- Public wrapper so other modules (file-ops' unbounded folder walk) can ask
-- "is this a shelf book?" without duplicating SUPPORTED_EXT and drifting
-- from it.
function Repo.isBookFile(name)
    return _supportedExt(name) ~= nil
end

-- Repo.isPluginFormatFile(path): true when the file is a book only because a
-- plugin registered its format -- not one of SUPPORTED_EXT's, even if a plugin
-- also provides for that (Meguru registers .cbz as well as .meguru; a .cbz
-- stays an ordinary book). Such a book's cover can be anything the plugin
-- decides to do -- Meguru's is an HTTP request -- so the shelf never asks for
-- one on its own (see the extraction kickoff in bookshelf_widget).
function Repo.isPluginFormatFile(path)
    local ext = _supportedExt(path)
    return ext ~= nil and not SUPPORTED_EXT[ext]
end

-- _formatLabel(fp): uppercase format label for display/grouping. Collapses a
-- compound ".zip" book to its inner kind ("book.fb2.zip" -> "FB2") so zipped
-- and plain books share one format card. Falls back to the last extension.
local function _formatLabel(fp)
    if not fp then return nil end
    local ext = _supportedExt(fp) or fp:match("%.([^.]+)$")
    if not ext or ext == "" then return nil end
    return (ext:gsub("%.[Zz][Ii][Pp]$", "")):upper()
end

-- ─── Lazy module accessors ───────────────────────────────────────────────────
-- Never require() at module top-level; tests stub via package.loaded.

local function getReadHistory()  return require("readhistory") end
local function getCollections()  return require("readcollection") end
-- BookInfoManager comes from CoverBrowser. When CoverBrowser is disabled
-- (Settings > More plugins), the module isn't on the lua path and the
-- raw require() throws. pcall it instead, cache the result, return nil
-- gracefully. Callers check for nil and bail. Without BIM Bookshelf
-- can't function meaningfully (no covers, no metadata extraction), so
-- main.lua also shows a one-time notification explaining the dependency.
local _bim_cache

-- Last-good Book records keyed by filepath, used by buildBookMeta to
-- mask BIM's transient "in_progress=1" wipe of metadata fields during
-- a re-extraction. Persists across renders AND across invalidateBookCache
-- on purpose: "refresh-metadata" and "scanAllMetadata" invalidate the book
-- cache at the very moment BIM is re-extracting, and this record is what
-- keeps the spine from flickering to fallback rendering in that window.
-- Cleared only with the walk cache (the library's files changed), which
-- bounds it to the files of one library scan rather than the life of the
-- process; a few hundred visited records at ~500 bytes is well under 1 MB.
local _meta_record_cache = {}

local function getBookInfoMgr()
    if _bim_cache ~= nil then
        return _bim_cache or nil
    end
    local ok, mod = pcall(require, "bookinfomanager")
    _bim_cache = (ok and mod) or false
    return _bim_cache or nil
end

-- ─── BIM handle recovery ─────────────────────────────────────────────────────
-- BookInfoManager:openDbConnection() is not atomic: it assigns self.db_conn
-- and only THEN prepares the three statements it caches. When one of those
-- prepares throws -- SQLite cannot grow its WAL on a full volume, and a PW5
-- with 0 bytes free on /mnt/us raises "disk I/O error" right there -- db_conn
-- is left SET while get_stmt still points at the previous connection's
-- (already closed) statement. Every getBookInfo after that takes the early
-- return in openDbConnection and binds the dead statement:
-- "ljsqlite3[misuse] object is closed", once per book, for the rest of the
-- session. Measured on a device: one transient I/O error, then 247 failures.
--
-- What the user sees is not an error but missing art: covers already in our
-- own cache keep painting, so the shelf looks healthy, and only the paths
-- that need a FRESH decode come back empty -- the hero above all. That is
-- the "books with covers on the shelf that show no cover in the hero"
-- report this exists for.
--
-- closeDbConnection() nils db_conn, so the next call re-opens and re-prepares
-- from scratch. One reset per cooldown window: when the volume really is
-- full the reopen fails again, and resetting per book would turn a broken
-- database into a reset storm on the slowest devices we run on.
local BIM_RESET_COOLDOWN_S = 5
local _bim_reset_at
local _bim_fail_logged_at

local function _resetBimConnection(bim)
    if not bim or type(bim.closeDbConnection) ~= "function" then return false end
    local now = os.time()
    if _bim_reset_at and (now - _bim_reset_at) < BIM_RESET_COOLDOWN_S then
        return false
    end
    _bim_reset_at = now
    local ok = pcall(function() bim:closeDbConnection() end)
    if not ok then
        -- ljsqlite3's close() raises on an already-closed handle, and
        -- closeDbConnection only nils db_conn once close() has returned.
        -- Clear it here too, or openDbConnection keeps taking its early
        -- return and the session never recovers. The three cached statements
        -- are deliberately left alone: openDbConnection overwrites all of
        -- them, and a nil there would crash BIM's own unguarded call sites.
        bim.db_conn = nil
    end
    return true
end

-- One warn per cooldown window, then debug. A poisoned handle fails once per
-- book, and 247 warnings with tracebacks is both unreadable and a stream of
-- writes to a volume that, in the case this recovers from, has no room left.
local function _logBimFailure(what, filepath, err)
    local now = os.time()
    if not _bim_fail_logged_at or (now - _bim_fail_logged_at) >= BIM_RESET_COOLDOWN_S then
        _bim_fail_logged_at = now
        logger.warn("[bookshelf] BIM", what, "failed for", tostring(filepath),
                    ":", tostring(err))
    else
        logger.dbg("[bookshelf] BIM", what, "failed for", tostring(filepath),
                   ":", tostring(err))
    end
end

-- getBookInfo with that recovery around it. Returns the info table (nil when
-- BIM has no row) and, on failure, the error message. Never raises.
local function _bimGetBookInfo(bim, filepath, want_cover, what)
    if not bim or type(bim.getBookInfo) ~= "function" then return nil end
    local ok, res = pcall(bim.getBookInfo, bim, filepath, want_cover)
    if ok then return res end
    if _resetBimConnection(bim) then
        local ok2, res2 = pcall(bim.getBookInfo, bim, filepath, want_cover)
        if ok2 then
            logger.info("[bookshelf] BIM connection reset; read recovered")
            return res2
        end
        res = res2
    end
    _logBimFailure(what or "getBookInfo", filepath, res)
    return nil, res
end

-- ─── Covers supplied by a getBookInfo wrapper (issue 500) ───────────────────
-- A user patch can wrap BIM:getBookInfo and hand back a cover the database
-- does not have -- 2-fallbackcover.lua draws one for every book without an
-- embedded cover, but only when the caller asks with get_cover=true. Most of
-- our record builds ask with get_cover=false (the cover is already in the
-- scaled cover cache, or comes from the batched rows), so they saw the
-- database's "no cover", SpineWidget drew the placeholder, and a fallback
-- cover only survived until its first draw had cached it.
--
-- So a book whose row is complete and coverless gets ONE get_cover=true read
-- per session to ask the wrapper, remembered per file. Only when getBookInfo
-- really is wrapped: an unpatched BIM pays nothing, and a library whose
-- books all have covers pays nothing either.
local _hook_cover_memo = {}
local _hook_fn, _hook_fn_wrapped
-- Set when a coverless book was built while getBookInfo was NOT wrapped. The
-- fallback patch wraps it on KOReader's first UI tick, after our startup
-- build, so the first screen after a launch would otherwise keep its
-- placeholders until something rebuilt it. See Repo.coverHookArrived.
local _hook_missed = false
local function _getBookInfoIsWrapped(bim)
    local fn = bim.getBookInfo
    if fn ~= _hook_fn then
        _hook_fn = fn
        local ok, di = pcall(debug.getinfo, fn, "S")
        local src = ok and di and di.source or ""
        _hook_fn_wrapped = not src:find("bookinfomanager%.lua$")
    end
    return _hook_fn_wrapped
end

local function _hookedCoverFor(bim, filepath, info)
    -- The fallback patch's own preconditions, so a "no" is final for the
    -- session: anything that could change it changes these fields too.
    if info.has_meta ~= "Y" or info.cover_fetched ~= "Y" or info.ignore_cover then
        return false
    end
    if not _getBookInfoIsWrapped(bim) then
        _hook_missed = true
        return false
    end
    local memo = _hook_cover_memo[filepath]
    if memo ~= nil then return memo end
    local probe = _bimGetBookInfo(bim, filepath, true, "getBookInfo (cover hook probe)")
    local yes = (probe and probe.has_cover == "Y" and probe.cover_bb ~= nil
                 and not probe.ignore_cover) and true or false
    -- Ours to free: the wrapper (or BIM) allocated it for this call alone.
    if probe and probe.cover_bb then pcall(function() probe.cover_bb:free() end) end
    _hook_cover_memo[filepath] = yes
    return yes
end

-- Repo.coverHookArrived() -> true ONCE when coverless books were built before
-- getBookInfo was wrapped and it is wrapped now: the caller should rebuild so
-- they ask the wrapper. A function-identity compare when nothing is pending.
function Repo.coverHookArrived()
    if not _hook_missed then return false end
    local bim = getBookInfoMgr()
    if not (bim and _getBookInfoIsWrapped(bim)) then return false end
    _hook_missed = false
    return true
end

local _hardcover_cache
local function getHardcover()
    if _hardcover_cache ~= nil then
        return _hardcover_cache or nil
    end
    local ok, mod = pcall(require, "lib/bookshelf_hardcover")
    _hardcover_cache = (ok and mod) or false
    return _hardcover_cache or nil
end

-- getKindleSource(): the Kindle source module IF it has already been loaded.
--
-- Deliberately a bare package.loaded read rather than a require: the caller runs
-- once per book inside buildBookMeta, so a pcall+require there is paid per book
-- on every shelf render, on every library, Kindle or not. Measured on a PW5 over
-- 3000 books: 6.45ms that way, 0.10ms this way.
--
-- Reading package.loaded is also the more correct question, not just the cheaper
-- one. Nothing can need re-attaching unless the source has actually been used:
-- its record cache is filled only by listBooks(), which only runs through the
-- kindle branch of getBySource, which is what loads the module. Not loaded means
-- no records exist, so there is nothing to do.
--
-- A memo was the obvious alternative and is worse: it pins whichever state it
-- saw first, so a module that becomes available later stays invisible, and it
-- needs a test-only invalidation hook. This has no cache to go stale.
--
-- type() rather than truthiness because a require that FAILED leaves a sentinel
-- number in package.loaded under LuaJIT, not nil -- the same trap as
-- bookshelf_sort_engine's i18n guard.
-- _isRemotePath(fp): not a file on the device -- an OPDS entry, or a record of
-- a registered source that declared a remote_prefix (lib/bookshelf_sources).
-- The OPDS prefix is tested first and inline, so the common case never leaves
-- this function; the registry is only consulted once it has been loaded, which
-- is also the only way a remote source can exist.
local function _isRemotePath(fp)
    if type(fp) ~= "string" then return false end
    if fp:find("^OPDS://") then return true end
    local Sources = package.loaded["lib/bookshelf_sources"]
    return type(Sources) == "table" and Sources.isRemotePath(fp) or false
end

local function getKindleSource()
    local mod = package.loaded["lib/bookshelf_kindle_source"]
    return type(mod) == "table" and mod or nil
end

-- Public: true if BookInfoManager is available (CoverBrowser enabled).
-- main.lua queries this at init to decide whether to take over the home
-- screen or bail with a "Bookshelf requires CoverBrowser" notification.
function Repo.hasBookInfoManager()
    return getBookInfoMgr() ~= nil
end
local function getDocSettings()  return require("docsettings") end

-- The shelf render already prefers book.cover_image_path over the embedded
-- cover, but that field is only ever set by Hardcover today. The Cover picker
-- (bookshelf_cover_apply) writes a native custom cover for ANY book, so point
-- cover_image_path at it here too. Gated on the tiny "cover_choices" map so the
-- findCustomCoverFile disk probe is paid only for books this feature actually
-- customised -- not on every book on every render. Runs just before
-- Hardcover.enrichBook, which may still override for a linked, use_cover book.
local function _applyCustomCoverIfCustomized(book)
    if type(book) ~= "table" or not book.filepath then return end
    local choices = BookshelfSettings.read("cover_choices")
    if type(choices) ~= "table" or choices[book.filepath] == nil then return end
    local ds = getDocSettings()
    local ok, custom = pcall(ds.findCustomCoverFile, ds, book.filepath)
    if ok and type(custom) == "string" and custom ~= "" then
        book.cover_image_path = custom
    end
end

-- _applyCoverOverrides(book): the two things allowed to replace a record's cover,
-- in order -- a cover the user picked, then Hardcover's for a linked use_cover
-- book. Both assign unconditionally, so whichever runs last wins.
--
-- Extracted because buildBookMeta is no longer the only caller: records that come
-- from a synthetic source (the Kindle catalogue bridge, issue #355) never pass
-- through it, and without these the shelf kept Amazon's thumbnail while the hero
-- -- which does go through buildBookMeta -- showed the Hardcover art. Two copies
-- of this ordering is how those two surfaces drift apart.
local function _applyCoverOverrides(book)
    _applyCustomCoverIfCustomized(book)
    local Hardcover = getHardcover()
    if Hardcover and Hardcover.enrichBook then
        pcall(Hardcover.enrichBook, book)
    end
end
Repo._applyCoverOverrides = _applyCoverOverrides

-- _hasSidecar(filepath): does KOReader hold DocSettings (a metadata sidecar)
-- for this book? Used as the cheap "has it ever been opened?" gate before the
-- much heavier Repo.readProgress (DocSettings:open) on status/rating filters
-- and sort prefetches.
--
-- KOReader's "Book metadata location" setting stores the .sdr alongside the
-- book ("doc", the default), in a central folder ("dir"), or by partial-hash
-- ("hash"). The old gate statted only the sibling "<book>.sdr" dir, so for
-- "dir"/"hash" users no sidecar was ever found and every book read as unread /
-- unrated in filters and sorts while covers showed the real status (issue
-- #117). DocSettings:hasSidecarFile checks the correct location(s) and only
-- stats (no Lua parse), so it preserves the "don't open every sidecar"
-- optimisation from #113 -- it just looks in the right place.
-- Memoized per filepath: status/rating filter sweeps call this for every
-- candidate on every evaluation, and the books that benefit from the
-- cheap gate (never opened, no sidecar) are exactly the ones that never
-- enter _progress_cache - so without a memo they re-stat each sweep.
-- Invalidation mirrors the progress cache (Repo.invalidateProgressCache):
-- closing a book is the only in-app way a sidecar appears.
local _sidecar_memo = {}
local function _hasSidecar(filepath)
    if not filepath then return false end
    local memo = _sidecar_memo[filepath]
    if memo ~= nil then return memo end
    local res = false
    local ds = getDocSettings()
    if ds and ds.hasSidecarFile then
        local ok, r = pcall(ds.hasSidecarFile, ds, filepath)
        if ok then res = r and true or false end
    end
    _sidecar_memo[filepath] = res
    return res
end

-- Hard ceiling on how many items a single fetch will HYDRATE (build a Book
-- record + decompress a cover for). Real pagination shows a screenful; a limit
-- anywhere near this means a caller pointed a hydrating fetcher at "everything"
-- instead of enumerating via the light getGroupChoices path. We clamp rather
-- than honour it, so the mistake degrades to an incomplete page + a logged
-- warning instead of an out-of-memory SIGKILL (which Lua cannot catch).
local MAX_HYDRATE = 512
-- light_only: when the caller wants only light metadata (one batched SELECT,
-- no full Book records, no cover decompress) the hydration ceiling doesn't
-- apply -- it exists solely to stop a runaway HYDRATING fetch from OOM-killing
-- the app. Clamping a light fetch silently truncated full-list consumers like
-- the "Go to letter" jump at exactly 512 items (#229).
local function _hydrationStop(offset, limit, total, default_limit, who, light_only)
    offset = offset or 0
    local want = limit or default_limit or 8
    if not light_only and want > MAX_HYDRATE then
        logger.warn(string.format(
            "[bookshelf] %s asked to hydrate %s items; clamping to %d "
            .. "(use getGroupChoices / a light path for full lists)",
            tostring(who), tostring(want), MAX_HYDRATE))
        want = MAX_HYDRATE
    end
    return math.min(offset + want, total)
end

-- Resolve the user's library root. Returns the configured home_dir, else
-- the device's own library folder as KOReader uses it (HomeDir.get), or nil
-- when there is neither (desktop with no home set). "/" is allowed:
-- some users (rooted devices, manual layouts) legitimately point home_dir
-- at filesystem root. The pseudo-filesystem denylist below keeps walks
-- under "/" off /proc and /sys so the legitimate case doesn't OOM-kill
-- KOReader. Walk-based callers must still treat nil as "no library
-- configured" and short-circuit to an empty result.
local function _resolveLibraryRoot()
    return HomeDir.get()
end

-- Path-join that doesn't emit "//child" when parent is filesystem root.
-- Walks rooted at "/" (legitimate config on rooted devices) would otherwise
-- produce "//proc", "//mnt", etc. — Linux normalises those at the syscall
-- layer but our walk-cache keys, BIM lookups, and equality comparisons
-- don't, so internal state ends up double-slashed and inconsistent.
local function _joinPath(parent, child)
    if parent == "/" then return "/" .. child end
    return parent .. "/" .. child
end

-- Basename denylist: directory names that walks must never descend into.
-- These are Linux pseudo-filesystems (/proc, /sys, /dev, /run) plus
-- transient OS scratch (/tmp) and fsck artefacts (lost+found). All have
-- enormous breadth at depth 1-2 and contain zero books, so even a depth-
-- bounded walk turns into thousands of stat() calls and stalls the UI.
-- Match is on basename so it bites whether home_dir is "/" or a parent
-- happens to contain a same-named folder. False-positive risk: a user
-- library folder literally named "proc" / "tmp" etc. would be hidden.
-- That's not a book-collection convention so the trade is acceptable.
local SYSTEM_DIR_NAMES = {
    proc        = true,
    sys         = true,
    dev         = true,
    run         = true,
    tmp         = true,
    ["lost+found"] = true,
}

-- pcall wrapper around Repo.buildBookMeta. A single malformed file's
-- metadata extraction (parser blow-up, corrupt BIM row, unexpected
-- charset) must not kill the entire shelf rebuild — Recent dodges this
-- because its book set is restricted to ones the user has successfully
-- opened, but Home iterates every file under home_dir and so is exposed.
-- Returns the book on success; nil + warn on failure.
local function _safeBuildBookMeta(fp, opts)
    local ok, b = pcall(Repo.buildBookMeta, fp, opts)
    if ok then return b end
    logger.warn("[bookshelf] buildBookMeta failed for", fp, ":", b)
    return nil
end

-- ─── Calibre metadata.calibre loader ─────────────────────────────────────────
-- The reader itself now lives in lib/calibre_metadata.lua, vendored
-- byte-identically into bookends so both plugins write the SAME
-- calibre.bookshelf.json harvest (#348). Bookends needs only a subset of the
-- fields, and a subset writer would clobber the author_sort and extra_series
-- this harvest exists to defend.
--
-- Bookshelf's calibre read stays behind its beta setting: unlike bookends,
-- calibre data here overrides title, authors, series, language and description
-- library-wide and drives author-sort ordering, so opting in is meaningful.
-- Truthy check via read (rather than isTrue) so the G_reader_settings test stub
-- does not need to grow another method.
local function _calibreMetadataFor(filepath)
    return CalibreMeta.entryFor(filepath,
                                BookshelfSettings.read("calibre_metadata"))
end

-- ─── buildBook ────────────────────────────────────────────────────────────────
-- Constructs a Book record for a given filepath.
-- Fields follow spec §5.1. Metadata from BookInfoManager; position from
-- DocSettings. Enrichment (stats) is a separate step (see enrichStats).
--
-- Series number strategy: BookInfoManager may return both info.series
-- (formatted as "<name> #<n>") and info.series_index (bare number). We prefer
-- series_index when present to avoid fragile string parsing; fall back to
-- parsing the formatted series string for compatibility with older caches.

-- buildBookMeta(filepath) — BookInfoManager-only Book record (no DocSettings).
-- Used by every shelf-rendering path (getRecent / getLatest / getFavorites /
-- getSeriesGroups), all of which only need cover/title/author/series fields.
-- Skipping the DocSettings sidecar read is the dominant per-rebuild saving on
-- libraries >100 books — DocSettings:open() does a Lua-parse from disk per
-- file. Use buildBook (below) when DocSettings fields (page_num, book_pct,
-- last_xp) are actually needed (i.e. the hero card and the previewed book).
-- ─── per-chip sort settings ──────────────────────────────────────────────────
-- Each chip remembers its own sort dimension via "bookshelf_sort_<chip>".
-- Missing/unknown values fall back to the chip default below. The widget
-- writes via the tab editor (bookshelf_chip_editor); each chip getter
-- reads via Repo.getSortKey(chip).
local _SORT_DEFAULT = {
    all        = "title",
    recent     = "recently_read",  -- not user-changeable; menu shows single row
    latest     = "mtime",
    favorites  = "updated",        -- newly favourited / unfavourited books float
    series     = "latest_read",
    authors    = "latest_read",
    genres     = "latest_read",
    tags       = "latest_read",
    formats    = "name",
    languages  = "book_count",
}

local _SORT_VALID = {
    all        = {
        title = true, natural = true, date_added = true,
        size  = true, format  = true, last_read  = true,
        percent_unopened_first = true, percent_unopened_last = true,
        percent_natural        = true,
    },
    latest     = { mtime = true },
    favorites  = { updated = true, date_added = true, title = true,
                   recently_read = true },
    series     = { name = true, latest_read = true, book_count = true },
    authors    = { name = true, latest_read = true, book_count = true },
    genres     = { name = true, latest_read = true, book_count = true },
    tags       = { name = true, latest_read = true, book_count = true },
    formats    = { name = true, latest_read = true, book_count = true },
    languages  = { name = true, latest_read = true, book_count = true },
}

-- getSortPriority(tab_id): returns the priority list for a tab, falling back
-- to the legacy single-key sort if no tab schema is present. This is the
-- bridge function during the v1.2 transition -- once Phase 2's editor lands,
-- the schema will always carry sort_priority and the legacy fallback can
-- be deleted.
local TabModel   = require("lib/bookshelf_tab_model")
local SortEngine = require("lib/bookshelf_sort_engine")
local BookshelfLang = require("lib/bookshelf_lang")

function Repo.getSortPriority(tab_id)
    local tab = TabModel.getById(tab_id)
    if tab and tab.sort_priority and #tab.sort_priority > 0 then
        return tab.sort_priority
    end
    -- Legacy fallback: translate the v1.1 single-string sort key into a
    -- one-level priority. Used only if a user's settings file has a stale
    -- shape (e.g., they downgraded and re-upgraded).
    local legacy = Repo.getSortKey(tab_id)
    local map = {
        title                  = { key = "filename",     reverse = false },
        natural                = { key = "filename",     reverse = false },
        date_added             = { key = "date_added",   reverse = true  },
        last_read              = { key = "last_opened",  reverse = true  },
        recently_read          = { key = "last_opened",  reverse = true  },
        latest_read            = { key = "last_opened",  reverse = true  },
        size                   = { key = "size",         reverse = false },
        percent_unopened_first = { key = "percent_read", reverse = false },
        percent_unopened_last  = { key = "percent_read", reverse = true  },
        percent_natural        = { key = "percent_read", reverse = true  },
        name                   = { key = "filename",     reverse = false },
        book_count             = { key = "book_count",   reverse = true  },
    }
    return { map[legacy] or { key = "title", reverse = false } }
end

function Repo.getSortKey(chip)
    local k = BookshelfSettings.read("sort_" .. chip)
    local valid = _SORT_VALID[chip]
    if k and valid and valid[k] then return k end
    return _SORT_DEFAULT[chip]
end

-- Forward declaration: the raw batched-row accessor lives with the light
-- meta cache further down, but buildBookMeta (below) reads it, and Lua
-- upvalue scoping needs the local to exist before that body is compiled.
local _batchInfoFor

-- buildBookMeta(filepath [, opts])
-- opts.want_cover: when false, ask BIM with get_cover=false so the zstd
-- decompression + Blitbuffer allocation are skipped entirely (see
-- bookinfomanager.lua line 376-379). Callers who already know the
-- scaled cover is cached elsewhere (ScaledCoverCache) pass false to
-- avoid the wasted decode-then-immediately-free dance on warm-cache
-- pagination. Cover-needing callers (hero, series stack, folder card)
-- omit opts and get the default true.
--
-- The returned record's cover_bb is nil when want_cover=false. SpineWidget
-- handles a nil cover_bb by checking ScaledCoverCache first, then falling
-- back to Repo.getCoverBB(filepath) for a synchronous lazy decode.
-- Description the OPDS download flow persisted for an on-disk file (keyed by
-- path). The key lives in the download module so widget-writer and
-- repo-reader can't drift; resolved once. Returns a non-empty string or nil.
local _opds_desc_key
local function _opdsDownloadDescription(filepath)
    if type(filepath) ~= "string" then return nil end
    if _opds_desc_key == nil then
        local ok, D = pcall(require, "lib/bookshelf_opds_download")
        _opds_desc_key = (ok and D and D.DESC_STORE_KEY) or "opds_descriptions"
    end
    local map = BookshelfSettings.read(_opds_desc_key)
    if type(map) ~= "table" then return nil end
    local v = map[filepath]
    -- Cleaned as it is read, so a book saved before the Calibre-Web header
    -- was dropped at download (issue 490) loses it too.
    if type(v) == "string" then
        local ok_f, Feed = pcall(require, "lib/bookshelf_opds_feed")
        if ok_f and Feed and Feed.summaryText then v = Feed.summaryText(v) end
    end
    return (type(v) == "string" and v ~= "") and v or nil
end

-- _reattachKindleIdentity(book, filepath) — put back what rebuilding from a
-- path alone cannot know (issue #355).
--
-- A Kindle-library record is synthetic: its data comes from Amazon's catalogue,
-- not from BIM or a sidecar. But records get rebuilt from a bare filepath all
-- over the place, and three of those sites (the per-book spine swaps in
-- bookshelf_widget) write the result straight back into _page_items. A rebuilt
-- Kindle record that has lost its fields therefore does lasting damage: the
-- cover reverts to a placeholder, the title to the raw filename, and -- worst --
-- without is_kindle the open path hands ReaderUI a .kfx it cannot read, so the
-- book stops opening at all.
--
-- This sits at the END of buildBookMeta deliberately: that is the single funnel
-- every rebuild passes through (buildBook calls it too), so one placement covers
-- every caller, present and future, instead of guarding each site.
--
-- Identity is always restored. Presentation fields only fill a gap, so a
-- converted book's own EPUB metadata still wins -- with one exception: title.
-- buildBookMeta falls back to the FILENAME when it has nothing better, which is
-- a non-nil value that would otherwise beat the catalogue. A filename is never
-- the better title, so the catalogue takes it back.
local function _reattachKindleIdentity(book, filepath)
    local KindleSource = getKindleSource()
    if not (KindleSource and KindleSource.recordFor) then return end
    local ok_rec, rec = pcall(KindleSource.recordFor, filepath)
    if not ok_rec or type(rec) ~= "table" then return end
    -- Everything the OPEN path reads, not just what is visible on a card: a tap
    -- rehydrates the record before opening it, so a field missing from this list
    -- is a field the open path silently does without. kindle_needs_prepare
    -- drives the "this takes a few minutes" confirm, and kindle_block_reason
    -- decides WHICH refusal message a blocked book gets.
    book.is_kindle            = true
    book.kindle_book_id       = rec.kindle_book_id
    book.kindle_source_path   = rec.kindle_source_path
    book.kindle_blocked       = rec.kindle_blocked
    book.kindle_block_reason  = rec.kindle_block_reason
    book.kindle_needs_prepare = rec.kindle_needs_prepare
    for _i, field in ipairs({
        "title", "display_title", "author", "authors", "cover_image_path",
        "lang", "format", "book_pct", "percent_finished", "status", "_status",
        "read_status", "last_opened", "last_read_time",
    }) do
        if book[field] == nil or book[field] == "" then book[field] = rec[field] end
    end
    -- The filename fallback (see the title resolution above: `title = filename`
    -- when neither Calibre nor BIM had one) is not a real title.
    if rec.title and rec.title ~= "" and book.title == book.filename then
        book.title = rec.title
        book.display_title = rec.display_title or rec.title
    end
end

function Repo.buildBookMeta(filepath, opts)
    local _bm_t0 = _gettime()
    if not filepath then return nil end
    -- BookOrbit catalog records use a "bookorbit://<id>" placeholder
    -- filepath (see bookshelf_bookorbit_source.lua) -- there's no real file
    -- for BIM to look up, so the generic path below would fall through to
    -- its filename-derived title fallback and show the raw numeric id
    -- instead of the book's actual title (surfaced via the tap-time
    -- selection-highlight repaint, which calls this and falls back to the
    -- existing record on nil -- exactly what we want here).
    if filepath:sub(1, 12) == "bookorbit://" then return nil end
    -- OPDS://server/id is a pseudo-path for a remote catalog entry -- there
    -- is no file behind it. BIM/Calibre/filename fallbacks below would
    -- happily build a stripped stand-in for it anyway: no is_remote, no
    -- opds, no cover_image_path, title falling back to the pseudo-path's
    -- basename (the raw feed id, e.g. "urn:gutenberg:1727:2"). That
    -- stand-in reaching the UI was a device-confirmed bug -- tapping an
    -- OPDS book for preview lost its cover and showed the feed id as the
    -- title. The feed record (built by the repo's OPDS branch, see
    -- getBySource kind=="opds") is the only truthful source for a remote
    -- entry, so bow out here instead of faking one up; callers fall back
    -- to whatever record they already hold (see BookshelfWidget:_hydrateBook
    -- and the "or <original record>" idiom at every buildBook/buildBookMeta
    -- call site).
    if _isRemotePath(filepath) then
        return nil
    end
    local want_cover = not opts or opts.want_cover ~= false
    -- Repo.suppress_covers: a fetch-scoped override the spine shelf sets
    -- around its page fetches -- a spine paints no cover, so attaching one
    -- to every record on the page is pure disk I/O (measured: ~200 cover
    -- reads per page turn on a 192-book chip).
    if want_cover and Repo.suppress_covers then want_cover = false end
    -- Last-chance cover gate. Callers that know better already pass
    -- want_cover=false when ScaledCoverCache holds the book (opts.lazy_cover
    -- on the paged fetchers), but not every route into buildBookMeta does,
    -- and the ones that miss it pay the most expensive call this function
    -- makes for nothing: BIM's SELECT drags the compressed cover off disk and
    -- zstd-decompresses it into a blitbuffer that SpineWidget then frees
    -- unread, because it paints from the cache instead.
    --
    -- Measured on a PW5, series chip: 7 of 25 buildBookMeta calls asked for a
    -- cover while all 25 covers on screen came from the cache -- 125ms of the
    -- 216ms this function spent in BIM, decoding images nothing looked at.
    -- Asking the cache here rather than at each call site means a route that
    -- forgets cannot reintroduce it.
    --
    -- Safe because it is the same downgrade the existing gates perform, and
    -- SpineWidget already handles a record with no cover_bb: it takes the lazy
    -- path, finds the cached bb, and only falls back to Repo.getCoverBB when
    -- the cached one is too small for the slot.
    if want_cover then
        local ok_scc, SCC = pcall(require, "lib/bookshelf_scaled_cover_cache")
        if ok_scc and SCC and SCC.has and SCC:has(filepath) then
            want_cover = false
        end
    end
    local bim  = getBookInfoMgr()
    if not bim then return nil end  -- CoverBrowser disabled (#49)
    -- BIM opens / queries its own SQLite database here. The DB can be
    -- transiently inaccessible during a fresh USB import (BIM itself
    -- is mid-write, file-locked, or the database is being recreated
    -- entirely). Without pcall, the SQLite error bubbles all the way
    -- up to UIManager and crashes KOReader — reported by issue #63
    -- where importing books over USB triggered "Uh oh, something went
    -- awry" on the next paginate-and-rehydrate. Catch the error,
    -- continue with empty BIM info so file-based metadata fallbacks
    -- (Calibre JSON, filename-derived title) still populate the
    -- record; a later rebuild after BIM finishes will fill in the
    -- gaps.
    -- Batched-row fast path: when no cover decode is wanted, take the text
    -- columns from the light map's raw row cache (one blob-free SELECT for
    -- the whole library, snapshot-backed) instead of a per-book SELECT --
    -- whose row drags the compressed cover blob off disk even with
    -- get_cover=false, ~20ms/record on device flash and the bulk of a
    -- cover/list page turn's fetch. Misses (new imports, books outside the
    -- batch, BIM mid-write) fall back to the live query below; metadata
    -- edits clear the batch wholesale (invalidateLightMeta), the same
    -- freshness the shelf's light records already have.
    local info
    if not want_cover and _batchInfoFor then
        info = _batchInfoFor(filepath)
        -- The batched rows are a snapshot, and once the session's background
        -- refresh has run they stay as they were for the rest of it. A row
        -- captured before the book's cover was extracted says "no cover"
        -- (a text-only "Scan library metadata" leaves exactly that row), and
        -- a record built from it gets has_cover = nil, which SpineWidget
        -- draws as the placeholder. It surfaced as covers that come back on
        -- Refresh metadata and vanish on the next page (issue 451): the first
        -- draw is a live read, which fills the cover cache, and a cached
        -- cover is what sends every later draw here. A cached cover is proof
        -- the row is out of date, so ask BIM itself. Books that really have
        -- no cover have nothing cached and stay on the fast path.
        if info and info.has_cover ~= "Y" then
            local ok_scc, SCC = pcall(require, "lib/bookshelf_scaled_cover_cache")
            if ok_scc and SCC and SCC.has and SCC:has(filepath) then info = nil end
        end
    end
    if not info then
        info = _bimGetBookInfo(bim, filepath, want_cover) or {}
    end
    -- Sticky-record cache. BIM's getBookInfo SELECT has a "WHERE
    -- in_progress=0" guard, so a row that's mid-extraction returns
    -- nil. Without this fallback, every cover-only re-extraction
    -- nulls the row briefly while BIM writes its "in_progress"
    -- placeholder, this function returns a minimal record, and the
    -- spine widget downgrades to fallback (filename) rendering --
    -- the user sees title/author/series flicker out and back in
    -- around the moment the cover finishes loading. Return the last
    -- good record we built for this file when BIM doesn't currently
    -- have usable metadata for it.
    if not info.has_meta and _meta_record_cache[filepath] then
        local cached = shallowCopyRecord(_meta_record_cache[filepath])
        _applyCustomCoverIfCustomized(cached)
        local Hardcover = getHardcover()
        if Hardcover and Hardcover.enrichBook then
            pcall(Hardcover.enrichBook, cached)
        end
        return cached
    end
    -- A cover only a getBookInfo wrapper knows about (issue 500): see
    -- _hookedCoverFor. A want_cover read already went through the wrapper.
    local has_cover = info.has_cover
    if has_cover ~= "Y" and not want_cover and _hookedCoverFor(bim, filepath, info) then
        has_cover = "Y"
    end
    -- Calibre is the PRIMARY source for textual metadata when a
    -- metadata.calibre file is available — it already has clean,
    -- user-curated title / authors / series / tags / description that
    -- often come from richer sources (Goodreads, Amazon, manual edits)
    -- than crengine's per-file extractor. BIM stays primary for the
    -- fields Calibre doesn't track: cover_bb (binary), has_cover,
    -- page_count. Where Calibre has no entry for a book (non-Calibre
    -- libraries, or new books not yet imported), we fall back to BIM.
    local cb = _calibreMetadataFor(filepath)
    -- One read of the book's custom metadata, shared by the text resolution
    -- and the genre source below (the genre path used to make this read on
    -- its own, so this is the same I/O, not more).
    local cp = _customPropsFor(filepath)

    -- Title / authors / series / language: custom metadata > Calibre > BIM >
    -- filename, resolved in _resolveTextMeta so the light-meta builder cannot
    -- disagree with this one.
    local text = _resolveTextMeta(filepath, cb, info, cp)
    local series_name, series_num = text.series_name, text.series_num
    local authors  = text.authors
    local filename = text.filename
    local title    = text.title

    -- Genres honour the per-book source preference (calibre / embedded /
    -- hardcover); with none set, auto priority Calibre > embedded. The Hardcover
    -- override (when chosen, or auto + sync) is applied later by enrichBook.
    local genres, genre_sources = genreData(filepath, cb, info, cp)
    local extra_series
    extra_series, genres = _extractExtraSeries(genres)
    -- Calibre's series name, for rebuilding the raw "Name #n" string below.
    -- It was read there without ever being defined in this function (the
    -- light-meta builder has its own), so a Calibre-only series never got one.
    local cb_series = cb and type(cb.series) == "string" and cb.series ~= ""
                      and cb.series or nil

    local book = {
        filepath    = filepath,
        filename    = filename,
        format      = _formatLabel(filepath) or "",
        title       = title,
        author      = authors and authors[1] or nil,
        authors     = authors,
        -- Calibre-curated sort form ("Surname, Forename" or
        -- "Surname1, F1 & Surname2, F2"). The sort engine prefers this
        -- over a derived surname so user-edited author_sort values
        -- (compound surnames "St. Crowe", particles "van der", suffix
        -- handling, inverted naming) are honoured. nil for non-Calibre
        -- libraries; cachedSurname falls back to parsing `author` then.
        author_sort = cb and type(cb.author_sort) == "string"
                       and cb.author_sort ~= "" and cb.author_sort or nil,
        -- Calibre's own sort title ("Locked Tomb, The"), computed with its
        -- language-aware rules. Powers the "Title (sort)" order, so a shelf
        -- that ignores leading articles uses the reader's metadata instead of
        -- us guessing at English grammar (issue 401). nil for non-Calibre
        -- libraries; cachedTitleSortKey falls back to the plain title there.
        title_sort  = cb and type(cb.title_sort) == "string"
                       and cb.title_sort ~= "" and cb.title_sort or nil,
        -- Field map behind the %calibre{name} token (built in slim(), so
        -- nil on the >8MB load_calibre fallback path and for non-Calibre
        -- libraries -- the token answers empty there).
        calibre     = cb and type(cb.calibre) == "table" and cb.calibre or nil,
        genres      = genres,
        -- Per-source genre lists for the book-detail Tags tab's source chip bar
        -- (Hardcover added by enrichBook). Cheap by-products of genre resolution.
        genre_sources = genre_sources,
        -- `series` is the raw "Foundation #1" string used by some
        -- consumers; reconstruct it from Calibre fields when needed.
        series      = info.series
                       or (cb_series and series_num and (cb_series .. " #" .. series_num))
                       or cb_series,
        series_name = series_name,
        series_num  = series_num,
        extra_series = extra_series,
        -- BIM-only: covers and page count are not in metadata.calibre.
        cover_bb    = info.cover_bb,
        has_cover   = has_cover and not info.ignore_cover,
        -- Original (pre-thumbnail) cover dimensions BIM records as "WxH",
        -- e.g. "1072x1448". Used by the Hardcover enricher to decide whether
        -- the embedded cover is lower resolution than Hardcover's.
        cover_sizetag = info.cover_sizetag,
        lang        = text.lang,
        -- A description the user wrote themselves wins outright. Then the one
        -- the OPDS download flow saved for this file: the catalog's blurb is
        -- why the user can see one at all for a Gutenberg book (its embedded
        -- EPUB description is usually empty). Falls through to Calibre
        -- comments, then BIM's extracted description.
        description = _cpText(cp, "description")
                       or _opdsDownloadDescription(filepath)
                       or ((cb and type(cb.comments) == "string" and cb.comments ~= "")
                           and cb.comments)
                       or (info.description and info.description ~= ""
                           and info.description)
                       or nil,
        page_count  = info.pages,
    }
    -- Cache fresh records whose text metadata is present, with the
    -- cover_bb stripped. ImageWidget marks the cover_bb's
    -- image_disposable=true after first paint -- it's a one-shot
    -- BlitBuffer. Caching the bb pointer and returning it on the
    -- next call (when BIM's in_progress=1 wipe makes this function
    -- fall back to the cache) reads freed C memory and corrupts the
    -- render -- visible as folder cover garbage on the home screen.
    -- Strip the bb here; the cache serves only text fields, and a
    -- nil cover_bb on the cached path makes the spine fall back to
    -- the paper-tone "no cover" state for that brief in-progress
    -- window. That's a far smaller visual change than the previous
    -- text-disappears flicker, and BIM's next successful commit
    -- restores the full record (with a fresh bb) on the very next
    -- poll.
    if info.has_meta == "Y" then
        local cached = {}
        for k, v in pairs(book) do
            if k ~= "cover_bb" then cached[k] = v end
        end
        _meta_record_cache[filepath] = cached
    end
    _applyCoverOverrides(book)
    _reattachKindleIdentity(book, filepath)
    -- Per-turn accounting for the shelf turn summary: how many full record
    -- builds a fetch cost, their total time, and how many decoded a cover
    -- (the expensive half). Drained by Repo.drainBuildStats.
    Repo._turn_builds   = (Repo._turn_builds or 0) + 1
    Repo._turn_build_ms = (Repo._turn_build_ms or 0)
                          + (_gettime() - _bm_t0) * 1000
    if want_cover then
        Repo._turn_covers = (Repo._turn_covers or 0) + 1
    end
    return book
end

-- drainBuildStats() -> n, ms, covers since the last drain. Feeds the
-- cover/list "shelf turn" INFO line so a slow fetch is attributable from
-- a stock crash.log: n full builds, their total cost, and how many paid
-- the BIM cover decode (vs served metadata-only).
function Repo.drainBuildStats()
    local n  = Repo._turn_builds or 0
    local ms = Repo._turn_build_ms or 0
    local c  = Repo._turn_covers or 0
    Repo._turn_builds, Repo._turn_build_ms, Repo._turn_covers = 0, 0, 0
    return n, ms, c
end

-- Repo.getCoverBB(filepath) — lazy cover accessor for callers that
-- skipped the cover decode in buildBookMeta(opts.want_cover=false). Hands
-- back BIM's freshly-decoded BlitBuffer (or nil if BIM has no cover row
-- or its row is mid-extraction). The caller OWNS the returned bb; pass
-- it to ImageWidget with image_disposable=true or free() it explicitly
-- after use. Same pcall guard as buildBookMeta for the import-window
-- crash path.
function Repo.getCoverBB(filepath)
    if not filepath then return nil end
    -- "bookorbit://<id>" is a synthetic placeholder (see
    -- bookshelf_bookorbit_source.lua) -- there's no real file for BIM to
    -- read, so this call would always fail. Short-circuit instead of
    -- paying a doomed getBookInfo lookup every time a BookOrbit grid
    -- tile whose thumbnail download failed gets repainted.
    if filepath:sub(1, 12) == "bookorbit://" then return nil end
    -- Remote catalog records have no local file and no BIM row: their cover is
    -- a cached image file the OPDS branch attaches as cover_image_path, which
    -- SpineWidget's external-cover branch renders before this lazy path is
    -- reached. A COVERLESS remote cell does fall through to here, though
    -- (bookshelf_spine_widget.lua's `bb = fp and _getRepo().getCoverBB(fp)`),
    -- so without this guard every such cell costs a BIM/SQLite lookup per
    -- rebuild for a row that cannot exist. Same guard buildBookMeta carries.
    -- nil is the answer every caller already handles (_renderFallback / a
    -- failed-count bump in the prewarm loop).
    if _isRemotePath(filepath) then return nil end
    local bim = getBookInfoMgr()
    if not bim then return nil end
    local info = _bimGetBookInfo(bim, filepath, true, "getBookInfo (cover only)")
    if not info then return nil end
    if info.ignore_cover then return nil end
    return info.cover_bb
end

-- Exported so the widget's own BIM reads (extraction queueing, the
-- post-extraction poll) share this recovery and its throttled log rather
-- than each carrying a bare pcall. Returns info, err -- err is set only when
-- the read genuinely failed, which callers use to tell "BIM has no row for
-- this book" from "BIM is not answering right now".
function Repo.bimGetBookInfo(bim, filepath, want_cover, what)
    return _bimGetBookInfo(bim, filepath, want_cover, what)
end

-- Text-only metadata for the library walk phases of getSeriesGroups /
-- getAuthors / getGenres. On large libraries (2000+ books), calling
-- buildBookMeta for every candidate and keeping the result in a group
-- table means all BIM cover BlitBuffers stay live simultaneously; for
-- 2000 books at ~60 KB each that peaks at ~120 MB and OOM-kills KOReader.
-- LuaJIT does not track FFI-allocated C memory for GC pressure, so the
-- collector doesn't know to step more aggressively.
-- get_cover=false sidesteps the zstd decompression + Blitbuffer allocation
-- entirely (see bookinfomanager line 376-379). The original implementation
-- passed true and let the bb fall out of scope after the function
-- returned — but the bb was still allocated in C memory for the duration
-- of the loop iteration, and on a Kindle Color the calloc inside
-- zstd_uncompress_ctx could fail (zstd.lua:75 assert).
--
-- Light metadata is also fetched in BATCH via _getLightMetaCache for
-- callers that walk the whole library: a single SELECT replaces ~2000
-- prepared-statement executions, dropping cold-walk cost from ~20s to
-- ~1-2s on a 2000-book Calibre library. _buildBookMetaLight stays the
-- per-book entry point (used when a caller doesn't want to materialize
-- the whole map, and as the fallback path inside the cache builder).
local function _buildLightMetaFromInfo(fp, info)
    info = info or {}
    local cb = _calibreMetadataFor(fp)
    local cp = _customPropsFor(fp)

    -- Same resolution as buildBookMeta, from the same function: the chips are
    -- built from these records and the shelf from those, so a book that is
    -- "Kelly Thompson" in one has to be "Kelly Thompson" in the other.
    local text = _resolveTextMeta(fp, cb, info, cp)
    local series_name, series_num = text.series_name, text.series_num
    local authors  = text.authors
    local filename = text.filename
    local title    = text.title

    local genres, genre_sources = genreData(fp, cb, info, cp)
    local extra_series
    extra_series, genres = _extractExtraSeries(genres)

    -- filename is also returned so callers like searchBooks can include
    -- it in their search haystack without paying for the heavy
    -- buildBookMeta path.
    -- Secondary series (issue 299): a Calibre custom column of datatype
    -- "series" ("The Forever War" is also #83 in "SF Masterworks"). The only
    -- practical source is metadata.calibre -- EPUB metadata and BIM both
    -- carry ONE series -- and the loader has already reduced the columns to
    -- name/number pairs (see the full-parse note in _calibreMetadataFor; on
    -- an oversized file the slimming parser wins and there are no extras).
    -- series_name/series_num stay the PRIMARY series untouched: tokens, the
    -- hero and sorting all read those, and a book's number differs per
    -- series, so each extra carries its own. Deduped case-insensitively
    -- against the primary and each other.
    if cb and type(cb.extra_series) == "table" then
        for _i, es in ipairs(cb.extra_series) do
            if type(es.name) == "string" and es.name ~= ""
                    and (not series_name
                         or es.name:lower() ~= series_name:lower()) then
                local dup = false
                for _j, have in ipairs(extra_series or {}) do
                    if have.name:lower() == es.name:lower() then dup = true break end
                end
                if not dup then
                    extra_series = extra_series or {}
                    extra_series[#extra_series + 1] = { name = es.name, num = es.num }
                end
            end
        end
    end

    local rec = {
        filepath    = fp,
        filename    = filename,
        series_name = series_name,
        series_num  = series_num,
        extra_series = extra_series,
        author      = authors and authors[1] or nil,
        authors     = authors,
        -- See buildBookMeta: Calibre-curated sort form, consumed by
        -- cachedSurname in the sort engine. Light meta carries it too
        -- so the predicate-walk path (loadCandidatesByPredicate) gets
        -- correct surname ordering on custom chips, not just the heavy
        -- buildBookMeta path.
        author_sort = cb and type(cb.author_sort) == "string"
                       and cb.author_sort ~= "" and cb.author_sort or nil,
        -- Calibre's own sort title ("Locked Tomb, The"), computed with its
        -- language-aware rules. Powers the "Title (sort)" order, so a shelf
        -- that ignores leading articles uses the reader's metadata instead of
        -- us guessing at English grammar (issue 401). nil for non-Calibre
        -- libraries; cachedTitleSortKey falls back to the plain title there.
        title_sort  = cb and type(cb.title_sort) == "string"
                       and cb.title_sort ~= "" and cb.title_sort or nil,
        calibre     = cb and type(cb.calibre) == "table" and cb.calibre or nil,
        genres      = genres,
        genre_sources = genre_sources,
        title       = title,
        lang        = text.lang,
    }
    -- Apply the global "Use Hardcover metadata" override here too, so the
    -- genre / author / series chips (built from these light records) switch
    -- over with the per-book tag pills. Cheap (memoized link + cache reads,
    -- no file I/O) and a no-op when the toggle is off / book isn't linked.
    local Hardcover = getHardcover()
    if Hardcover and Hardcover.applyMetadata then
        pcall(Hardcover.applyMetadata, rec)
    end
    return rec
end

local function _buildBookMetaLight(fp)
    if not fp then return nil end
    local bim  = getBookInfoMgr()
    if not bim then return nil end  -- CoverBrowser disabled (#49)
    -- Guarded; see buildBookMeta for rationale (#63/#71).
    local info = _bimGetBookInfo(bim, fp, false, "getBookInfo (light)") or {}
    return _buildLightMetaFromInfo(fp, info)
end

-- Forward declarations: the per-file progress cache lives with the other
-- caches further down, but buildBook (below) seeds it from the
-- DocSettings handle it opens, and Lua upvalue scoping needs the local
-- to exist before that function body is compiled.
-- When each book was marked finished (its sidecar's summary.modified), or
-- false for none: the reading goal counts a book in the year it was finished.
-- readProgress fills it from the sidecar it already has open.
local _finished_on = {}
local _progress_cache, PROGRESS_CACHE_TTL

-- _writeProgressCache(filepath, pct, status, rating, page_count, page_num)
--
-- ONE writer for the progress cache, because there are two callers and they
-- must agree on the whole field set: readProgress fills it from the sidecar,
-- and buildBook seeds it from the handle it already has open so a readProgress
-- that follows is a table lookup rather than a second parse.
--
-- They diverged the moment page_num was added to one of them (it went into
-- readProgress only). Every reader takes the cached entry wholesale, so a tap
-- -- which builds the hero's book through buildBook -- overwrote a complete
-- entry with one missing that field, and %page_num vanished from the shelf row
-- it had just been working on. The comment above buildBook's seed already
-- demanded the two mirror each other; this makes it structural rather than a
-- promise.
local function _writeProgressCache(filepath, pct, status, rating, page_count, page_num, page_src)
    _progress_cache[filepath] = {
        pct        = pct,
        status     = status,
        rating     = rating,
        page_count = page_count,
        page_num   = page_num,
        page_src   = page_src,
        expires_at = os.time() + PROGRESS_CACHE_TTL,
    }
end

-- #159: a "p(<n>)" token in a filename (e.g. "Caliban's War - p(624).epub")
-- gives a publisher/preferred page count for books KOReader can't page-count
-- until they're rendered — unopened reflowable formats, which have no BIM,
-- pagemap or stats count. Used ONLY as a last resort (a real rendered/stable
-- count always wins) and inert for filenames without the token, so it costs
-- nothing unless the user opts in by adopting the naming convention. Matched
-- case-insensitively on the basename only; the book's display title comes from
-- metadata, not the filename, so this never changes the shown name.
local function pageCountFromFilename(filepath)
    if type(filepath) ~= "string" then return nil end
    local base = filepath:match("([^/]+)$") or filepath
    local n = base:match("[Pp]%((%d+)%)")
    return n and tonumber(n) or nil
end
-- Public alias: the page-count scanner classifies filename-counted books
-- as their own (free) category before probing anything heavier.
Repo.pageCountFromFilename = pageCountFromFilename

-- Repo.printedPageCount(fp) -> a count that does not depend on how the book
-- is laid out for reading, or nil: the book's own stable page numbers, then
-- what Extract page counts found from a publisher page list, a Hardcover
-- edition or the Calibre column, then a p(N) in the file name. What the cover
-- badge shows under Page count > Printed page counts first.
local PRINTED_TAGS = { print = true, calibre = true, filename = true }
function Repo.printedPageCount(fp)
    if type(fp) ~= "string" then return nil end
    local _p, _s, _r, pages, _n, src = Repo.readProgress(fp)
    if src == "stable" and pages then return pages end
    local ok, SS = pcall(require, "lib/bookshelf_spine_shelf")
    if ok and SS and SS.cachedProgress then
        local pp, _s2, _k, psrc = SS.cachedProgress(fp)
        if pp and PRINTED_TAGS[psrc] then return tonumber(pp) end
    end
    return pageCountFromFilename(fp)
end

-- Issue 405: a page count from a Calibre custom column, for the page-count
-- scan. The Count Pages plugin for Calibre fills one in (usually #pages), and
-- a reader who already keeps it may prefer it to the scan's own render.
--
-- calibrePageColumn() -> the column's lookup name (lowercased, no '#') and how
-- many books carry a number in it, or nil when there is none -- including when
-- the Calibre metadata setting is off, since nothing is read then. "pages" wins
-- when present; otherwise the column whose name has "page" in it that the most
-- books fill. Map lookups only: the Calibre file is already parsed and cached.
function Repo.calibrePageColumn()
    if BookshelfSettings.read("calibre_metadata") ~= true then return nil end
    local counts = {}
    for _i, fp in ipairs(Repo.getAllFilepaths()) do
        local fields = CalibreMeta.fieldsFor(fp, true)
        if fields then
            for key, v in pairs(fields) do
                if key:find("page", 1, true) and tonumber(v) and tonumber(v) > 0 then
                    counts[key] = (counts[key] or 0) + 1
                end
            end
        end
    end
    if counts.pages then return "pages", counts.pages end
    local best, n = nil, 0
    for key, c in pairs(counts) do
        if c > n or (c == n and best and key < best) then best, n = key, c end
    end
    if best then return best, n end
    return nil
end

-- calibrePagesFor(filepath, column) -> that book's count in the column, or nil.
function Repo.calibrePagesFor(filepath, column)
    if type(column) ~= "string" then return nil end
    local fields = CalibreMeta.fieldsFor(filepath, BookshelfSettings.read("calibre_metadata"))
    local n = fields and tonumber(fields[column])
    if n and n > 0 then return math.floor(n + 0.5) end
    return nil
end

-- _scannedPageCount(filepath) -> the count the "Extract page counts" scan
-- found for this book, or nil.
--
-- The scan persists into the shelf's own page-count store rather than into the
-- book's sidecar, deliberately: a count for a never-opened book must not be
-- the reason a sidecar appears, since stock KOReader reads one as "this has
-- been read". (The publisher-list case is the exception -- it also writes
-- pagemap_doc_pages, the key ReaderPageMap owns.) So for most books that store
-- is the ONLY place a scanned count lives, and anything answering "how many
-- pages" has to look there. Without this the scan showed up in the spine
-- widths, which read the store directly, and nowhere else -- device report:
-- "our page count scan worked for book spine width but doesn't populate the
-- page_count token". Only the counts fit to show, though: a layout render is
-- a spine-width scale, not the book's length (SpineShelf.shownPages).
--
-- Required lazily: the shelf module requires this one back, and a load-time
-- pair would be a cycle. By the time anything asks for a page count both are
-- loaded. Costs a table lookup; the store only stats a sidecar to validate
-- entries that came FROM one, which a scanned count did not.
local function _scannedPageCount(filepath)
    if not filepath then return nil end
    local ok, SpineShelf = pcall(require, "lib/bookshelf_spine_shelf")
    if not ok or type(SpineShelf) ~= "table"
            or type(SpineShelf.shownPages) ~= "function" then
        return nil
    end
    local ok2, pages = pcall(SpineShelf.shownPages, filepath)
    return ok2 and tonumber(pages) or nil
end

-- Repo.pageCountFor(filepath, known) -> a page count, or nil.
--
-- The TAIL of the page-count ladder, in one place. `known` is whatever the
-- caller already has -- BookInfoManager's count, or the sidecar's -- and wins
-- when it is a real number. After it come the two sources that need no file
-- open and no database read:
--
--   1. the "Extract page counts" scan's store (see _scannedPageCount)
--   2. a p(<n>) marker in the filename (#159), free
--
-- The store comes first: a scan's count is one the reader chose to have,
-- from sources they picked -- and a marker is often Calibre's estimate, which
-- a reader who ran the scan with "file names" unticked meant to replace
-- (maintainer: "for someone who has that in their filenames, they might want
-- to override it"). A scan that does use file names stores the marker's own
-- number, so nothing changes for those who keep it.
--
-- Every consumer asks the same question and each had grown its own ending:
-- the hero's had both rungs, the lazy resolver's sidecar branch had only the
-- second, and the two got patched separately twice in two days. Owning the
-- order here is the point -- callers supply what they know and stop deciding.
function Repo.pageCountFor(filepath, known)
    known = tonumber(known)
    if known and known > 0 then return known end
    return _scannedPageCount(filepath) or pageCountFromFilename(filepath)
end


-- _stablePagesOn(ds) -> false when the reader turned KOReader's Use stable
-- page numbers off for this book, true otherwise.
--
-- KOReader writes pagemap_doc_pages (and the current label) whenever a book
-- has a publisher page list, used or not; whether the reader USES those
-- numbers is pagemap_use_page_labels, which it saves on every open of such a
-- book. Issue 539: with it off the reader counted 718 pages while the top
-- panel said 21 / 569. Unset (a book not opened since) keeps the stable
-- numbers, as before.
local function _stablePagesOn(ds)
    local ok, use = pcall(ds.readSetting, ds, "pagemap_use_page_labels")
    return not (ok and use == false)
end

-- opts is forwarded verbatim to buildBookMeta; opts.want_cover=false skips
-- BIM's zstd decode and Blitbuffer allocation for callers that never look at
-- the cover. The in-reader status line rebuilds this record far more often
-- than the grid does, so paying for a cover it discards was the whole cost.
function Repo.buildBook(filepath, opts)
    local book = Repo.buildBookMeta(filepath, opts)
    if not book then return nil end
    local ds = getDocSettings():open(filepath)
    -- HELD, not assigned: the pagemap label outranks it. See the precedence
    -- block further down, which is the one place that decides.
    local ds_last_page = ds:readSetting("last_page")
    book.book_pct = ds:readSetting("percent_finished")
    book.last_xp  = ds:readSetting("last_xpointer")
    -- summary.status feeds the cover-progress indicators in
    -- bookshelf_cover_progress.decide(); read here so the DocSettings
    -- handle is reused. nil is fine -- decide() treats absent status
    -- as "new" and renders nothing.
    local _summary = ds:readSetting("summary")
    book.status = _summary and _summary.status or nil
    -- Same normalisation as Repo.readProgress -- 'complete' -> 'finished',
    -- 'abandoned' -> 'on_hold' -- so every consumer sees one vocabulary.
    if     book.status == "complete"  then book.status = "finished"
    elseif book.status == "abandoned" then book.status = "on_hold"
    end
    -- Progress but no status: reading, as in Repo.readProgress (issue 524).
    if book.status == nil and book.book_pct then book.status = "reading" end
    -- 1-5 stars (or nil for unrated). Stored under summary.rating by KOReader's
    -- Reader Status dialog. Exposed for the hero card's rating region and for
    -- the rating sort key.
    book.rating = _summary and tonumber(_summary.rating) or nil
    -- Annotation counts (#348) for %highlights / %notes / %bookmarks /
    -- %annotations on the hero. Read from the sidecar handle already open
    -- above, so the hero pays nothing extra. List rows get the same numbers
    -- through bookshelf_token_record's resolver, which has no hero record to
    -- borrow from. Both go through the vendored counter, which is KOReader's
    -- own rule, so a noted highlight counts the same everywhere.
    local ok_ann, _annotations = pcall(ds.readSetting, ds, "annotations")
    if ok_ann and type(_annotations) == "table" then
        local ok_sem, Semantics = pcall(require, "lib/token_semantics")
        if ok_sem and Semantics then
            local counts = Semantics.annotationCounts(_annotations)
            book.highlights = counts.highlights
            book.notes      = counts.notes
            book.bookmarks  = counts.bookmarks
        end
    end
    -- BIM skips page count for crengine docs (the unrendered getPageCount()
    -- returns 2-3x the rendered count), so EPUB books have nil page_count
    -- after buildBookMeta. Two sdr-side sources to fall back on, in order:
    --
    --   1. pagemap_doc_pages — set whenever the user has KOReader's stable
    --      page numbers enabled (either publisher page labels ℗, or the
    --      synthetic chars-per-page mode). Stable across font/render
    --      changes — what most users mean by "page count" for an EPUB.
    --
    --   2. stats.pages — the count at the time the doc was last rendered.
    --      Font-dependent, but populated for any opened EPUB.
    --
    -- Preferring pagemap_doc_pages means users with stable page numbers
    -- enabled see the SAME count we'd show in the book-info dialog and
    -- the reader footer, regardless of their current font scaling.
    --
    -- ds_page_count is derived unconditionally (not just when BIM left
    -- page_count nil) because it doubles as the progress-cache seed
    -- below, which must match what readProgress would compute for this
    -- file - readProgress never sees BIM's count.
    local ds_page_count, ds_page_src
    local stable_on = _stablePagesOn(ds)
    do
        local stable_pages = stable_on and ds:readSetting("pagemap_doc_pages")
        if stable_pages then
            ds_page_count = tonumber(stable_pages)
            if ds_page_count then ds_page_src = "stable" end
        end
        if not ds_page_count then
            local stats = ds:readSetting("stats")
            if type(stats) == "table" and stats.pages then
                ds_page_count = tonumber(stats.pages)
                if ds_page_count then ds_page_src = "render" end
            end
        end
    end
    -- The rest of the ladder -- the filename marker, then the scan's store --
    -- belongs to Repo.pageCountFor. This value also seeds the progress cache
    -- below, so it must match what readProgress would compute for this file,
    -- which is why it starts from the SIDECAR count and not from BIM's.
    local fallback_page_count = Repo.pageCountFor(filepath, ds_page_count)
    if not book.page_count then
        book.page_count = fallback_page_count
    end
    -- page_num precedence mirrors page_count:
    --   1. pagemap_current_page_label — the stable label at the user's
    --      current position. May be non-numeric for front-matter (Roman
    --      numerals "i", "ii"); tonumber-guarded so those fall through.
    --   2. last_page — set for PDF/CBZ (read above, applied here).
    --   3. round(percent_finished * page_count) — synthesised approximation
    --      so the hero's "page N of M" template works for EPUBs the reader
    --      hasn't given us a stable label for.
    --
    -- The label OUTRANKS last_page, and that order is load-bearing rather than
    -- arbitrary. page_count prefers pagemap_doc_pages, the stable publisher
    -- pagination; last_page is crengine's rendered page index at the reader's
    -- current font size. They are DIFFERENT SCALES for the same book -- the
    -- hazard this file already documents for pages-left (#38, "231 publisher
    -- labels" against "317 internal pages"). Taking last_page first put the
    -- hero one scale and the count another, and a finished book reported page
    -- 568 OF 567.
    --
    -- last_page was assigned unconditionally before this block, so it silently
    -- won; readProgress had always preferred the label, so the shelf row and
    -- the hero disagreed about the same book the moment %page_num started
    -- rendering on rows.
    if not book.page_num and stable_on then
        local label = ds:readSetting("pagemap_current_page_label")
        if label then
            local n = tonumber(label)
            if n then book.page_num = n end
        end
    end
    if not book.page_num then
        book.page_num = tonumber(ds_last_page)
    end
    if not book.page_num and book.book_pct and book.page_count then
        book.page_num = math.floor(book.book_pct * book.page_count + 0.5)
        if book.page_num < 1 then book.page_num = 1 end
    end
    -- Seed the progress cache from the DocSettings handle we already
    -- paid to open, so a readProgress(fp) that follows (status badges,
    -- filters, sort keys) is a table lookup instead of a second sidecar
    -- parse. Field values mirror readProgress exactly: same status
    -- normalisation (applied above), and ds_page_count rather than
    -- book.page_count, which may carry BIM's count that readProgress
    -- never sees.
    -- page_num is book.page_num, derived just above. The two functions now
    -- share an order -- label, then last_page, then the rounded fraction --
    -- which they did NOT before: buildBook took last_page first, and that is
    -- what made a finished book read 568 of 567. Its third rung still divides
    -- by book.page_count rather than fallback_page_count, and those differ
    -- only for a book BIM counted, which is fixed-layout and reaches an exact
    -- rung long before the division.
    -- And the same page_src readProgress would report for it.
    if not ds_page_src and fallback_page_count then
        ds_page_src = _scannedPageCount(filepath) and "store" or "filename"
    end
    _writeProgressCache(filepath, tonumber(book.book_pct), book.status,
                        book.rating, fallback_page_count, book.page_num, ds_page_src)
    return book
end

-- buildPreviewBook(filepath, fallback_book) -- like Repo.buildBook, but
-- routes a "bookorbit://<id>" placeholder to
-- bookshelf_bookorbit_source.rebuildRecord instead of the real-file
-- BIM/DocSettings path buildBook/buildBookMeta use, which can't do
-- anything useful with a fake filepath and always returns nil for one.
--
-- Without this, callers promoting a tapped/selected BookOrbit book into
-- the hero fell back to reusing the tapped grid record completely as-is:
-- its cover_bb is a ONE-SHOT bb the grid tile already painted (and freed)
-- by the time the hero tries to reuse it, so the hero cover came up
-- blank, and the record never had a description field to begin with,
-- since the catalog list endpoint doesn't return one (only the per-book
-- detail endpoint does). rebuildRecord fetches both.
--
-- fallback_book must be the caller's existing record for this exact
-- filepath (not some other book) -- checked here so a mismatched fallback
-- safely no-ops (returns nil) instead of rebuilding the wrong book.
function Repo.buildPreviewBook(filepath, fallback_book)
    if type(filepath) == "string" and filepath:sub(1, 12) == "bookorbit://" then
        if not fallback_book or fallback_book.filepath ~= filepath then return nil end
        local ok_bo, BOSource = pcall(require, "lib/bookshelf_bookorbit_source")
        if ok_bo and BOSource and BOSource.rebuildRecord then
            return BOSource.rebuildRecord(fallback_book)
        end
        return nil
    end
    return Repo.buildBook(filepath)
end

-- ─── getCurrent ──────────────────────────────────────────────────────────────
-- Returns the Book record for the last opened file, or nil if none.

-- Kobo books open via a decrypted /tmp copy, so KOReader's lastfile is that
-- temp path (no extension), not the virtual book -- the hero would never tie it
-- back. _openBook calls noteKoboOpen so getCurrent/currentFilepath can map that
-- temp path to the virtual Kobo record (#203). In-memory only (lost on restart,
-- as is the temp file). [[project_kobo_virtual_library_integration]]
local _last_kobo_open = nil
function Repo.noteKoboOpen(decrypted_path, record)
    if decrypted_path and record then
        _last_kobo_open = { path = decrypted_path, record = record, virtual = record.filepath }
    end
end

function Repo.getCurrent()
    local lastfile = G_reader_settings:readSetting("lastfile")
    if _last_kobo_open and lastfile == _last_kobo_open.path then
        -- Recently-opened Kobo book: return a fresh shallow copy of the virtual
        -- record with a fresh cover, so the hero shows it as current.
        local r = {}
        for k, v in pairs(_last_kobo_open.record) do r[k] = v end
        local ok_k, KoboSource = pcall(require, "lib/bookshelf_kobo_source")
        if ok_k and KoboSource and r.filepath then
            local bb, cw, ch = KoboSource.coverBB(r.filepath)
            if bb then r.cover_bb, r.cover_w, r.cover_h, r.has_cover = bb, cw, ch, true end
        end
        return r
    end
    local fp = Repo.currentFilepath()
    if not fp then return nil end
    return Repo.buildBook(fp)
end

-- Repo.currentFilepath() — the filepath getCurrent() would build, or nil,
-- WITHOUT touching BIM / DocSettings. Lets callers (the hero memo) key on
-- the current book without paying the lockable getBookInfo read just to
-- learn its path. Applies the same supported-format gate as getCurrent so
-- stale PNGs / config files / opened-once non-books don't claim the hero.
function Repo.currentFilepath()
    local lastfile = G_reader_settings:readSetting("lastfile")
    if not lastfile then return nil end
    -- A just-opened Kobo book: report the virtual path (which ends .epub, so it
    -- passes the format gate) instead of the extensionless /tmp decrypted copy.
    if _last_kobo_open and lastfile == _last_kobo_open.path then
        return _last_kobo_open.virtual
    end
    if not _supportedExt(lastfile) then return nil end
    return lastfile
end

-- ─── getRecent ───────────────────────────────────────────────────────────────
-- Returns up to `limit` Book records from ReadHistory.hist, in order
-- (ReadHistory keeps hist sorted newest-first already). No exclusion —
-- the active book stays visible in the shelf, and the BookshelfWidget
-- highlights the previewed spine instead so the user can tell which one
-- the hero is currently displaying. Earlier iterations excluded lastfile
-- to avoid hero+slot-1 duplication; that exchange wasn't worth the
-- shelves jumping around as the user browsed previews.

-- opts.lazy_cover: when true, per-book ScaledCoverCache probe; on
-- cache hit, pass want_cover=false to buildBookMeta to skip the BIM
-- zstd decompress.
function Repo.getRecent(limit, offset, opts)
    local rh   = getReadHistory()
    offset     = offset or 0
    limit      = limit or 8
    if not (opts and opts.light_only) and limit > MAX_HYDRATE then
        logger.warn(string.format("[bookshelf] getRecent asked to hydrate %s; clamping to %d",
            tostring(limit), MAX_HYDRATE))
        limit = MAX_HYDRATE
    end
    local out  = {}
    local ScaledCoverCache
    if opts and opts.lazy_cover then
        ScaledCoverCache = require("lib/bookshelf_scaled_cover_cache")
    end
    -- entry.dim is ReadHistory's marker for files deleted via the
    -- KOReader file manager when autoremove_deleted_items_from_history
    -- is off (the default). Stock History dims them; bookshelf treats
    -- them as gone -- if KOReader notices the file is back, the flag
    -- clears and the entry reappears here naturally.
    --
    -- Single pass: count non-dim entries (= total) while fetching
    -- buildBookMeta only for the visible slice [offset+1, offset+limit].
    -- `total` counts entries that would actually RENDER. Counting before
    -- the metadata build meant an entry whose build returns nil (an OPDS
    -- pseudo-path, a file gone since the dim flag was last reconciled)
    -- inflated the total without adding a row - the chip's pagination then
    -- claimed pages it could not fill. Entries beyond the visible slice
    -- are counted without building (the build is the expensive part and
    -- nil-builds are rare); the slice itself only counts what it emits.
    local total = 0
    for i = 1, #rh.hist do
        local entry = rh.hist[i]
        if not entry.dim then
            if total >= offset and #out < limit then
                local meta_opts
                if ScaledCoverCache and ScaledCoverCache:has(entry.file) then
                    meta_opts = { want_cover = false }
                end
                local book = Repo.buildBookMeta(entry.file, meta_opts)
                if book then
                    book.last_read_time = entry.time
                    out[#out + 1] = book
                    total = total + 1
                end
            else
                total = total + 1
            end
        end
    end
    return out, total
end

-- ─── getLatest ───────────────────────────────────────────────────────────────
-- Returns up to `limit` Book records, sorted newest-by-mtime first, from a
-- recursive filesystem walk rooted at G_reader_settings `home_dir`.
-- Walk depth is capped by `bookshelf_latest_walk_depth` setting (default 3).
-- Lifting the cap on desktop runs (home_dir = $HOME) walks the entire
-- user tree at unbounded depth and locks up the UI — keep the
-- conservative default and let users opt into a deeper walk via the
-- settings spinner if their library lives more than three levels deep.
-- Results are NOT memoised here — caching is a BookshelfWidget-level concern.

-- KOReader ships LFS as `libs/libkoreader-lfs` and that's the only path that
-- works inside the plugin loader. The unprefixed `require("lfs")` resolves
-- only in the test harness (where we stub package.loaded.lfs) and fails at
-- runtime — which is what crashed the chip switch on first use.
-- ─── Walk cache ──────────────────────────────────────────────────────────────
-- walkBooks is the dominant cost in BookshelfWidget:_rebuild for any
-- non-trivial library: a recursive lfs scan plus per-file mtime stats. Both
-- getLatest and getSeriesGroups call it, and both fire on every chip switch
-- and page flip. We memoise the candidate list keyed by (home, depth) with a
-- short TTL so back-to-back rebuilds reuse the work.
--
-- Invalidation (now purely event-driven, 2026-05-28): NONE of the metadata
-- caches consult `expires_at` any more. The TTL constants are kept defined
-- for documentation / cache-struct shape stability, but every HIT path
-- treats any cached entry as fresh. Freshness comes from three explicit
-- signals:
--   * cachedWalk's dir-mtime check picks up filesystem-level changes
--     (sideloaded books, deletions, renames) on every walk.
--   * BookMetadataChanged (KOReader event) -> Bookshelf:onBookMetadataChanged
--     calls Repo.invalidateBookCache, which clears _progress_cache,
--     _light_meta_cache, _bySource_cache and the per-group caches.
--   * Swipe-down on the home screen calls Repo.invalidateWalkCache() to
--     wipe everything (the user's manual escape hatch for external app
--     changes that don't fire BookMetadataChanged).
-- Cover bitmaps remain bounded by ScaledCoverCache's LRU; everything else
-- stays warm until something explicitly invalidates it.
--
-- This replaces the previous belt-and-braces TTL fallback (24 h on group
-- / shape caches, 120 s on _progress_cache, 30 s on _stats_cache). In
-- practice the TTLs were never the load-bearing invalidation -- the event
-- hooks already cover the cases that matter -- and within a single
-- session the TTLs only ever cost work without preventing staleness that
-- the events hadn't already cleared.
local WALK_CACHE_TTL = 24 * 3600  -- vestigial; HIT paths no longer consult expires_at
local _walk_cache = {}      -- { [key] = { list = {...}, expires_at = number } }

-- Series-groups cache. The walk-cache covers the lfs.dir + per-file mtime
-- sweep, but getSeriesGroups also iterates EVERY candidate calling
-- buildBookMeta — that's a BookInfoManager (SQLite) lookup per book, the
-- dominant cost on the Series chip for libraries above ~1k books.
-- Memoise the post-iteration result (full pre-slice list) keyed on the
-- same (home, depth) the walk uses, with a matching TTL. Invalidation
-- piggy-backs on invalidateWalkCache so onCloseDocument naturally
-- refreshes both — a just-read book's read-time bubble-up still lands
-- on the next chip rebuild.
local SERIES_CACHE_TTL = WALK_CACHE_TTL
local _series_cache    = {}  -- { [key] = { groups = {...}, standalones = {...}, expires_at = number } }
-- Authors and Genres group caches. Same TTL + invalidation pattern as
-- the series cache: filepaths-only "shape" so the cover_bb lifetime
-- hazard from caching Book records doesn't apply.
local _authors_cache   = {}
local _genres_cache    = {}
local _formats_cache   = {}
local _ratings_cache   = {}
local _languages_cache = {}
-- SHAPE_CACHE_MAX: LRU cap for the two per-folder x per-sort "shape" caches
-- below. Left unbounded, one entry accumulates per folder visited times each
-- sort/filter combination for the life of the process; entries are cheap
-- (filepath lists + folder labels), so 48 is generous headroom rather than a
-- tight budget. Oldest-inserted key is evicted first.
local SHAPE_CACHE_MAX = 48
-- getAll result cache. FileChooser:genItemTableFromPath is expensive (2–5s
-- on large home dirs); caches the shape (filepaths + folder labels) with the
-- same TTL and invalidation path as the walk cache.
local _all_cache       = {}  -- { [key] = { shapes = {...}, expires_at = number } }
local _all_cache_order = {}  -- insertion order backing the SHAPE_CACHE_MAX eviction
-- getBySource result cache. For custom-kind tabs (genre, folder, collection,
-- etc.) the predicate walk + per-book _safeBuildBookMeta is expensive (full
-- library sweep on every pagination tap). Cache the post-filter, post-sort
-- candidate list keyed on (source, filter, sort_priority) so pagination
-- within a tab is a cheap slice of the cached list. Invalidated by
-- invalidateBookCache (editor Save) and invalidateWalkCache (onCloseDocument).
local _bySource_cache  = {}  -- { [key] = candidates }
local _bySource_cache_order = {}  -- insertion order backing the SHAPE_CACHE_MAX eviction

-- _capInsert(cache, order, key, value): assign `value` at `cache[key]` and
-- record the insertion in `order`, the eviction queue backing the
-- SHAPE_CACHE_MAX cap. Any existing occurrence of `key` in `order` is
-- removed first, so refilling an already-cached key moves it to the newest
-- position instead of duplicating it (which would let it dodge eviction out
-- of turn); the oldest keys are then dropped from both `cache` and `order`
-- while `order` holds more than SHAPE_CACHE_MAX entries. Returns true when
-- `key` was not already in `cache` (a fresh insert) and false for a refill --
-- the test seams below use this to probe membership without a mutating
-- second write.
local function _capInsert(cache, order, key, value)
    local existed = cache[key] ~= nil
    cache[key] = value
    for i = #order, 1, -1 do
        if order[i] == key then
            table.remove(order, i)
            break
        end
    end
    order[#order + 1] = key
    while #order > SHAPE_CACHE_MAX do
        local oldest = table.remove(order, 1)
        cache[oldest] = nil
    end
    return not existed
end

-- Test seam: live-entry counts for the three session-long caches flagged by
-- the 2026-09-16 memory inventory as having no size bound (_all_cache,
-- _bySource_cache, _meta_record_cache). Lets tests assert the LRU cap holds
-- and that invalidation actually empties the meta-record cache, without
-- reaching into this file's local state directly.
function Repo._shapeCacheCounts()
    local function _count(t)
        local n = 0
        for _k in pairs(t) do n = n + 1 end
        return n
    end
    return {
        all       = _count(_all_cache),
        by_source = _count(_bySource_cache),
        meta      = _count(_meta_record_cache),
    }
end

-- Test seam: drive the same capped-insert helper the production fill sites
-- use (Repo.getAll's MISS branch for "all", Repo.getBySource's MISS branch
-- for "by_source"), so a test can fill 48+ distinct keys without contriving
-- that many real folder/sort combinations through the public API. `which`
-- is "all" or "by_source". Returns the same true/false _capInsert does.
function Repo._shapeCachePut(which, key, value)
    if which == "all" then
        return _capInsert(_all_cache, _all_cache_order, key, value)
    elseif which == "by_source" then
        return _capInsert(_bySource_cache, _bySource_cache_order, key, value)
    end
    return nil
end

-- Test seam: non-mutating read of a cached shape entry (companion to
-- Repo._shapeCachePut), so a test can confirm exactly which keys survived
-- an eviction round without the side effect of touching insertion order.
function Repo._shapeCacheGet(which, key)
    if which == "all" then return _all_cache[key] end
    if which == "by_source" then return _bySource_cache[key] end
    return nil
end
-- Light-meta cache: filepath → light record (output of _buildLightMetaFromInfo).
-- Populated once per (home, depth) by a single batch BIM SELECT that replaces
-- the per-book prepared-statement loop. Three walk consumers — getSeriesGroups
-- MISS, _buildGroups (authors/genres), and searchBooks — all walk the SAME
-- candidate list and need the SAME per-book metadata, so paying SQLite once
-- and letting all three readers hit the result is the dominant speedup
-- (Lutesong's Kindle Color: 20s per chip → ~1-2s, 2000-book library).
local _light_meta_cache = {}  -- { [key] = { map = {[fp]=record}, expires_at = number } }
-- Folder→bookpaths cache. Used by selection-mode plumbing to answer
-- "which book filepaths live (recursively) under this folder?" without
-- redoing an lfs scan per query. The cached walk-list already knows the
-- answer; we just prefix-filter it once per (folder, walk-generation)
-- and memoise. Invalidated alongside the walk cache and inside
-- cachedWalk's files-changed branch.
local _folder_book_paths_cache = {}  -- { [path] = { paths = {...} } }
-- Ordered tile books per folder, keyed by folder + the sort that produced the
-- order (see Repo.folderCoverPaths). The ordering costs a light metadata
-- record per book IN the folder, so without this it ran again on every fetch
-- that put the same tile on screen: every page turn, every chip pre-warm,
-- every rebuild. The member list is the input, so this shares its lifetime
-- and is cleared wherever _folder_book_paths_cache is; the key's `s:<key>:`
-- segments let invalidateReadStateCache drop just the orders a read moves.
local _folder_cover_cache = {}
local _folder_cover_cache_order = {}  -- insertion order backing the SHAPE_CACHE_MAX eviction
-- Per-file progress cache. DocSettings:open() does a Lua-parse from disk
-- per call, which dominates loops that read percent / summary.status for
-- many books in a row (getAll's prefetch on the Home chip is the obvious
-- one). Caching the parsed result for a short window cuts repeat scans
-- to memory reads.
--
-- Invalidation: onCloseDocument explicitly drops the just-closed file via
-- invalidateProgressCache(fp); invalidateWalkCache wipes the whole map as
-- a belt-and-braces refresh for any sideloaded / metadata-edited cases.
--
-- NOTE: declared (as locals) above Repo.buildBook, which seeds this
-- cache; assigned here so they live with the rest of the cache block.
PROGRESS_CACHE_TTL = 120  -- seconds
_progress_cache    = {}   -- filepath → { pct, status, expires_at }

-- Repo.dataGeneration() -> a number that changes whenever something a book's
-- fields read as may have changed under a cache that is not this file's own:
-- a progress / status / metadata edit (invalidateProgressCache), a library
-- refresh (invalidateWalkCache), a metadata-source toggle (invalidateLightMeta)
-- and a closed book's statistics (invalidateStatsCache).
--
-- For the cover labels (lib/bookshelf_cover_label.lua), which keep each book's
-- expanded text between rebuilds and must not outlive the data it was expanded
-- from. A counter rather than a hook list: the consumer compares one number,
-- and a bump that over-invalidates (one book closed, every label re-expanded)
-- costs one expansion per visible cover, once.
local _data_generation = 0
function Repo.dataGeneration() return _data_generation end
local function _bumpDataGeneration() _data_generation = _data_generation + 1 end

-- Forward declarations so invalidateWalkCache below resolves these to the
-- module-local tables created later (Repo.folderHasBooks's memo at
-- ~line 1206 and _normalizeGenre's memo at ~line 1994). Without these
-- forward decls, the assignments inside invalidateWalkCache would write
-- to globals (not the locals the readers consult), so the invalidation
-- would silently no-op.
-- Forward-declared for the same reason as the caches below: invalidateWalkCache
-- and invalidateProgressCache both drop the persisted finished count, and both
-- run ABOVE the definition. Without the declaration those calls would resolve
-- to a global that is never assigned.
local _dropFinishedCount
-- Same reason again: invalidateWalkCache drops the persisted walk, and runs
-- above the definition.
local _dropWalkSnapshot
local _folderHasBooks_cache
-- Repo.fileSizeFor's memo (created just below progressFor). Forward-declared
-- for the same reason as the line above: invalidateWalkCache clears it, and
-- without the decl that assignment would write a global the reader never sees.
local _size_memo
local _normalize_genre_cache
local _normalize_author_cache
local _normalize_lang_cache
-- Filter helpers used by group fetchers / hydrators / getAll. Their
-- definitions live further down (near _buildGroups for readability)
-- but several call sites — getTags, getAll's folder-filter pass,
-- hydrateSeriesShape, getSeriesGroups — appear earlier in the file.
-- Without forward decls, Lua treats those references as globals and
-- the chip rebuild crashes at runtime with "attempt to call global
-- '_shapeHasFilteredBook' (a nil value)".
local _normalizeGenre
local _normalizeLang
local _normalizeStatus
local _statusForFp
local _filterIsActive
local _shapeHasFilteredBook
local _shapeVisible
local _applyFilter
local _recordMatches
-- Source-scoped filter pickers, defined further down beside _formatKey (their
-- format keying needs it). Declared here because both public entry points sit
-- above that.
local _sourceFilterChoices, _sourceFilterCounts

-- State for Repo.countFinishedBooks, which is DEFINED after cachedWalk --
-- the walk is a later local and Lua does not hoist. The state lives here
-- so invalidateWalkCache below can clear it.
local _finished_count = { value = nil, expires_at = 0 }

-- Repo.countStartedBooks() -> how many books the statistics plugin has ANY
-- reading time for, or nil when its database is unavailable.
--
-- The other half of "books read" (the %books_read/%books_started pair):
-- Finished is a sidecar fact and needs the sweep above; STARTED is exactly
-- what KOReader's statistics.sqlite3 records, so this uses the same method
-- as the reading-stats micro-module -- read-only open, busy timeout, one
-- query, short TTL -- rather than a second sweep. total_read_time > 0 rather
-- than a bare count: the plugin inserts a row on open, and a book looked at
-- for zero seconds is not started by anyone's definition.
local _started_count = { value = nil, expires_at = 0 }
function Repo.countStartedBooks()
    local now = os.time()
    if _started_count.value ~= nil and now < _started_count.expires_at then
        return _started_count.value or nil
    end
    local n
    local ok = pcall(function()
        local DataStorage = require("datastorage")
        local path = DataStorage:getSettingsDir() .. "/statistics.sqlite3"
        local lfs = require("libs/libkoreader-lfs")
        if lfs.attributes(path, "mode") ~= "file" then return end
        local SQ3 = require("lua-ljsqlite3/init")
        local conn = SQ3.open(path, "ro")
        local ok_q, err = pcall(function()
            conn:exec("PRAGMA busy_timeout=200;")
            local stmt = conn:prepare(
                "SELECT COUNT(*) FROM book WHERE total_read_time > 0")
            local row = stmt:step()
            stmt:close()
            n = tonumber(row and row[1])
        end)
        conn:close()
        if not ok_q then error(err) end
    end)
    if not ok then n = nil end
    _started_count.value = n or false
    _started_count.expires_at = now + 60
    return n
end

-- Lifetime reading time across every book, for %total_read_time (#348).
-- One sum over the roll-up column ReaderStatistics maintains, so no page_stat
-- scan. Same read-only connection and TTL discipline as the other counters.
local _total_time = { value = nil, expires_at = 0 }

function Repo.totalReadTimeSeconds()
    local now = os.time()
    if _total_time.value ~= nil and now < _total_time.expires_at then
        return _total_time.value or nil
    end
    local n
    local ok = pcall(function()
        local DataStorage = require("datastorage")
        local path = DataStorage:getSettingsDir() .. "/statistics.sqlite3"
        local lfs = require("libs/libkoreader-lfs")
        if lfs.attributes(path, "mode") ~= "file" then return end
        local SQ3 = require("lua-ljsqlite3/init")
        local conn = SQ3.open(path, "ro")
        local ok_q, err = pcall(function()
            conn:exec("PRAGMA busy_timeout=200;")
            local stmt = conn:prepare("SELECT sum(total_read_time) FROM book")
            local row = stmt:step()
            stmt:close()
            n = tonumber(row and row[1])
        end)
        conn:close()
        if not ok_q then error(err) end
    end)
    if not ok then n = nil end
    _total_time.value = n or false
    _total_time.expires_at = now + 60
    return n
end

-- ── Today's reading, across every book (#348) ──────────────────────────────
--
-- Backs %pages_today and %time_today, which were CONSUMERS with no producer
-- (the expanders read state fields nothing ever set, so both answered empty
-- forever). Global rather than per-book, matching bookends, where the same two
-- tokens report the day's total and the *_book variants report one title.
--
-- Read-only connection with a short busy_timeout, like countStartedBooks: the
-- statistics plugin may be mid-write, and a shelf render must never block on
-- it or take the paint down.
--
-- Per-page duration is CAPPED the same way ReaderStatistics caps it, because
-- the day a reader falls asleep with the book open would otherwise read as
-- eight hours. Distinct (book, page) pairs are counted, so re-reading a page
-- does not inflate the count.
local _today_stats = { value = nil, expires_at = 0 }

function Repo.todayStats()
    local now = os.time()
    if _today_stats.value ~= nil and now < _today_stats.expires_at then
        return _today_stats.value or nil
    end
    local result
    local ok = pcall(function()
        local DataStorage = require("datastorage")
        local path = DataStorage:getSettingsDir() .. "/statistics.sqlite3"
        local lfs = require("libs/libkoreader-lfs")
        if lfs.attributes(path, "mode") ~= "file" then return end
        local t = os.date("*t", now)
        local day_start = os.time({
            year = t.year, month = t.month, day = t.day,
            hour = 0, min = 0, sec = 0,
        })
        local stats = G_reader_settings:readSetting("statistics")
        local max_sec = (stats and stats.max_sec) or 120
        local SQ3 = require("lua-ljsqlite3/init")
        local conn = SQ3.open(path, "ro")
        local ok_q, err = pcall(function()
            conn:exec("PRAGMA busy_timeout=200;")
            local stmt = conn:prepare(
                "SELECT count(*), sum(d) FROM ("
                .. "  SELECT min(sum(duration), ?) AS d FROM page_stat "
                .. "  WHERE start_time >= ? GROUP BY id_book, page)")
            local row = stmt:reset():bind(max_sec, day_start):step()
            stmt:close()
            if row then
                result = {
                    pages   = tonumber(row[1]) or 0,
                    minutes = math.floor((tonumber(row[2]) or 0) / 60 + 0.5),
                }
            end
        end)
        conn:close()
        if not ok_q then error(err) end
    end)
    if not ok then result = nil end
    -- false rather than nil so a genuine failure is remembered for the TTL
    -- instead of retrying the query on every token expansion.
    _today_stats.value = result or false
    _today_stats.expires_at = now + 60
    return result
end

-- Drop the metadata.calibre memo: forces a re-stat on the next read, so a
-- freshly synced file is noticed immediately instead of after the 60s TTL.
-- The mtime guard still reuses the parsed map when the file has not changed,
-- so calling this liberally costs one lfs stat.
function Repo.invalidateCalibreCache()
    CalibreMeta.invalidate()
end

function Repo.invalidateWalkCache()
    _bumpDataGeneration()
    Repo.invalidateCalibreCache()
    _finished_count.value = nil
    _dropFinishedCount()
    _dropWalkSnapshot()
    _walk_cache       = {}
    _series_cache     = {}
    _authors_cache    = {}
    _genres_cache     = {}
    _formats_cache    = {}
    _ratings_cache    = {}
    _languages_cache  = {}
    _all_cache        = {}
    _all_cache_order  = {}
    _bySource_cache   = {}
    _bySource_cache_order = {}
    _light_meta_cache = {}
    _folder_book_paths_cache = {}
    _folder_cover_cache = {}
    _folder_cover_cache_order = {}
    _progress_cache   = {}
    -- Sticky last-good Book records (see the declaration above) have no
    -- other invalidation path; a walk invalidation is the broadest signal
    -- this repository has, so clear them here rather than let them grow
    -- for the life of the process.
    _meta_record_cache = {}
    _hook_cover_memo   = {}
    -- Sidecar dirs may have appeared/vanished (sideload, new books), so the
    -- custom-metadata fast gate must re-list on the next derive.
    _invalidateCustomMetaGate()
    -- _sidecar_memo travels with _progress_cache everywhere: a walk
    -- invalidation can mean sideloaded sidecars (Syncthing, USB), so the
    -- "has it ever been opened?" answers may have changed too.
    _sidecar_memo     = {}
    -- Same reasoning for file sizes: a walk invalidation is the signal that
    -- files may have been added, removed or replaced under us.
    _size_memo        = {}
    -- _folderHasBooks_cache: memoizes whether a folder contains a book at
    -- any depth. Previously preserved across invalidations so the negative-
    -- result-for-an-empty-folder didn't have to re-walk. Trouble: when a
    -- book is *added* to a folder that previously had none, the cache
    -- returns the stale "false" and the folder is hidden from Home until
    -- the session restarts. Wiping here costs a re-walk on the next render
    -- but keeps Home in sync with the user's actual library.
    _folderHasBooks_cache = {}
    -- _normalize_genre_cache: production it's harmless to keep (genre
    -- strings don't change), but per-test state pollution breaks isolation
    -- if a test injects different genre keys under the same input shape.
    -- Negligible production cost to rebuild.
    _normalize_genre_cache = {}
    _normalize_author_cache = {}
    _normalize_lang_cache  = {}
    -- Force getBookInfoMgr to re-resolve via require on its next call. In
    -- production this is a no-op cost (require's own cache returns the same
    -- module instantly), but it lets tests that swap the bookinfomanager
    -- stub between cases actually see the new stub -- previously the first
    -- test's BIM was sticky for the whole suite.
    _bim_cache = nil
end

function Repo.invalidateSeriesCache()
    _series_cache     = {}
    _authors_cache    = {}
    _genres_cache     = {}
    _formats_cache    = {}
    _ratings_cache    = {}
    _languages_cache  = {}
    _light_meta_cache = {}
end

-- invalidateAllCache(): drop just the getAll shape cache. Used when a
-- setting that controls All/Folder sort or partition (e.g. KOReader's
-- collate_mixed) changes — those settings are part of the cache key,
-- but pre-existing keyed entries shouldn't linger as warm slots the
-- user no longer wants to fall back into. Walk cache and group shape
-- caches are untouched (their data isn't affected by these settings).
function Repo.invalidateAllCache()
    _all_cache = {}
    _all_cache_order = {}
end

-- invalidateFavoritesCache(): drop only _bySource_cache entries keyed on
-- the favourites chip. Called when bookshelf knows the favourites set
-- has just been mutated (★ toggle in the book menu, bulk add/remove,
-- etc.) so the next visit to the Favourites view reflects the change
-- without forcing the user to swipe-down for a full library refresh.
--
-- Targets only favourites because the broader caches (walk, group
-- shape, all) are unaffected by collection membership and shouldn't
-- be invalidated for this kind of edit -- doing so would force an
-- expensive re-walk when the user next switches to Authors / Series /
-- etc., which is wasteful.
--
-- Two cache-key shapes can hold favourites lists:
--   * "favorites|..."             — the built-in tab (source.kind="favorites")
--   * "collection|favorites|..."  — a user-built chip pointing at the
--                                   default ReadCollection ("favorites")
-- Strip both so a ★ toggle invalidates whichever shape the user has on
-- their favourites chip(s).
-- A chip sorted by "Favorites first" is reordered by the same edit,
-- whatever its source, so its entries go too.
function Repo.invalidateFavoritesCache()
    for k in pairs(_bySource_cache) do
        if k:sub(1, 10) == "favorites|"
                or k:sub(1, 21) == "collection|favorites|"
                or k:find("s:favorites_first:", 1, true) then
            _bySource_cache[k] = nil
        end
    end
end

-- invalidateReadStateCache(): drop only the _bySource_cache entries whose
-- SORT depends on read state — last-opened time, reading progress, or
-- read status. Called from onCloseDocument: the just-closed book's read
-- state changed (it jumped to the top of ReadHistory, its progress moved),
-- so any chip ordered by one of those keys has a stale cached filepath
-- order. The classic symptom (issue 85): in the Recent chip — whose tab
-- carries sort_priority {last_opened, reverse} and therefore routes through
-- the predicate/cache path, NOT the getRecent fast-path — a freshly-closed
-- book didn't move to the top until a manual swipe-down refresh.
--
-- Deliberately narrow: the cache key encodes each sort level as
-- "s:<key>:<r|f>" (see _bySourceCacheKey), so we match on the read-state
-- sort tokens only. Chips ordered by stable metadata (title, filename,
-- date_added, series_name, author_surname, book_count) can't have reordered
-- and keep their cache. We also leave the walk cache + light-meta cache
-- warm — read state isn't a filesystem change — so the next fetch just
-- re-sorts the cached candidates rather than re-walking the library. This
-- is the targeted alternative to invalidateWalkCache, which the swipe-down
-- refresh uses (full wipe) and which onCloseDocument intentionally avoids.
--
-- "s:read_status" (no trailing colon) intentionally matches both
-- read_status and read_status_active. rating is included because a star
-- rating set while reading lands in the sdr sidecar and can reorder a
-- rating-sorted chip; date_added (file mtime) and the metadata keys
-- (title / filename / series_name / author_surname / book_count) are NOT
-- touched by reading, so chips sorted on them keep their cache.
local READ_STATE_SORT_TOKENS = {
    "s:last_opened:", "s:percent_read:", "s:read_status", "s:rating:",
    "s:added_or_opened:",
}
-- The same sorts by key, for caches that spell the priority differently.
local READ_STATE_SORT_KEYS = {
    last_opened = true, percent_read = true, read_status = true,
    read_status_active = true, rating = true, added_or_opened = true,
    percent_natural = true,
}
function Repo.invalidateReadStateCache()
    for k in pairs(_bySource_cache) do
        for _i, tok in ipairs(READ_STATE_SORT_TOKENS) do
            if k:find(tok, 1, true) then
                _bySource_cache[k] = nil
                break
            end
        end
    end
    -- And getAll's own listings, the Home (folders) and folder shelves (issue
    -- 519): their cache key spells the priority as "<key>[R]" joined by
    -- commas, not the "s:<key>:" tokens above, so it is matched by sort key.
    -- Missed before, a Home shelf sorted by Added or opened kept the book just
    -- closed where it was until a refresh, the file poll or a restart.
    for k in pairs(_all_cache) do
        local a = k:find("\0", 1, true)
        local b = a and k:find("\0", a + 1, true)
        local prio = (a and b) and k:sub(a + 1, b - 1) or ""
        for part in prio:gmatch("[^,]+") do
            if READ_STATE_SORT_KEYS[(part:gsub("R$", ""))] then
                _all_cache[k] = nil
                break
            end
        end
    end
    -- Same rule for the folder tiles: "the book this folder opens with" can
    -- only move when read state does, and only for a sort that reads it, so a
    -- title or filename order survives a book being closed.
    for k in pairs(_folder_cover_cache) do
        for _i, tok in ipairs(READ_STATE_SORT_TOKENS) do
            if k:find(tok, 1, true) then
                _folder_cover_cache[k] = nil
                break
            end
        end
    end
end

-- _resetLightMetaProgress(filepath)  -- nil-internal helper. The
-- predicate path in getBySource mutates _progress_fetched / _status /
-- _pct / rating ON the cached light-meta records (it caches the
-- "did we already read DocSettings for this candidate" flag so a
-- subsequent sort-needs pass doesn't repeat the work). Those
-- mutations persist for the cache's lifetime; the predicate then
-- reuses the stale snapshot on the next run.
--
-- Pre-v2.0.4 the bug was masked because _light_meta_cache had
-- WALK_CACHE_TTL=0 and was effectively always-MISS, so every fetch
-- rebuilt fresh records. Bumping the TTL exposed the mutation as a
-- stale-data regression: a book whose status had been changed via
-- the long-press menu (or from anywhere else) stayed in the
-- previous status-filtered chip until KOReader restart, because the
-- cached record's _progress_fetched=true short-circuited the
-- re-read. Fix: when invalidateProgressCache fires (which happens
-- on every status change and metadata edit), strip the
-- per-DocSettings mutations from any cached light-meta record for
-- the same filepath so the next predicate run reads fresh state.
-- Targets issue #40.
local function _resetLightMetaProgress(rec)
    rec._progress_fetched = nil
    rec._status           = nil
    rec._pct              = nil
    rec.rating            = nil
    rec.read_status       = nil
    -- The spine plan bakes the sidecar's status onto the record (and flags
    -- it checked) so paints skip DocSettings; these are the same cached
    -- objects, so a status edit must strip that too or the plan's
    -- `if src.status == nil` guard keeps serving the old status.
    rec.status                = nil
    rec._spine_status_checked = nil
end

function Repo.invalidateProgressCache(filepath)
    _bumpDataGeneration()
    -- The Pages sort remembers the counts it looked up.
    if SortEngine.clearPageCountMemo then SortEngine.clearPageCountMemo() end
    -- A status change is exactly what makes the stored finished count wrong.
    _finished_count.value = nil
    _dropFinishedCount()
    -- The Kindle catalogue bakes each record's status in when it builds, and
    -- keeps that build for a minute. Marking a Kindle book finished and then
    -- rebuilding the shelf inside that window brings the OLD status back, so
    -- the Finished tick lands on one book and not the next purely on timing.
    -- Confirmed on a PW5: three books marked finished, identical sidecars, one
    -- tick on screen; all three appeared after a restart forced a fresh read.
    --
    -- Every registered source hears about it (lib/bookshelf_sources); the
    -- Kindle one drops its catalogue cache when the file is one of its books.
    -- package.loaded rather than require: with the registry never loaded, no
    -- source has listed anything, so there is no cache to drop. The Kindle
    -- spec answers from its existing cache only, so an invalidation never
    -- turns into a catalogue scan.
    local Sources = package.loaded["lib/bookshelf_sources"]
    if type(Sources) == "table" and Sources.invalidate then
        pcall(Sources.invalidate, filepath)
    end
    if filepath then
        _progress_cache[filepath] = nil
        _sidecar_memo[filepath] = nil
        _finished_on[filepath] = nil
        for _key, entry in pairs(_light_meta_cache) do
            if entry and entry.map then
                local rec = entry.map[filepath]
                if rec then _resetLightMetaProgress(rec) end
            end
        end
        -- Downstream caches (the spine shelf persists status and rendered
        -- pixels per book) register here; without this a status edit left
        -- the old reading glyph on the spine.
        if Repo.on_book_invalidated then
            pcall(Repo.on_book_invalidated, filepath)
        end
    else
        _progress_cache = {}
        _sidecar_memo = {}
        _finished_on = {}
        for _key, entry in pairs(_light_meta_cache) do
            if entry and entry.map then
                for _fp, rec in pairs(entry.map) do
                    _resetLightMetaProgress(rec)
                end
            end
        end
    end
end

-- invalidateBookCache -- nil all per-chip result caches so the next chip
-- rebuild fetches + sorts fresh data. Does NOT touch the walk cache (file
-- system scan), the light-meta cache (SQLite batch), the BIM cover cache,
-- or the _folderHasBooks_cache -- those are heavier to rebuild and are
-- not affected by sort / filter / source changes on tabs.
-- Call this before firing on_change after an editor Save.
function Repo.invalidateBookCache(reason)
    local logger = require("logger")
    _series_cache     = {}
    _authors_cache    = {}
    _genres_cache     = {}
    _formats_cache    = {}
    _ratings_cache    = {}
    _languages_cache  = {}
    _all_cache        = {}
    _all_cache_order  = {}
    _bySource_cache   = {}
    _bySource_cache_order = {}
    -- _meta_record_cache deliberately survives this: see its declaration.
    if logger and logger.dbg then
        logger.dbg("[bookshelf] cache invalidated: " .. tostring(reason))
    end
end

-- Drop the light-meta cache (the per-file records the genre/author/series
-- chips are grouped from). invalidateBookCache deliberately keeps this warm
-- (it's a BIM batch query to rebuild), but a change to the *content* of those
-- records -- e.g. toggling "Use Hardcover metadata", which rewrites
-- title/author/series/genres -- must force a rebuild or the chips stay stale.
-- The walk cache (file list) is untouched; only the per-file metadata refetches.
function Repo.invalidateLightMeta()
    _bumpDataGeneration()
    _light_meta_cache = {}
    -- Re-read sidecar directories on the next derive so a freshly-written
    -- custom_metadata.lua (e.g. a genre edit) is seen by the fast gate.
    _invalidateCustomMetaGate()
end

-- Repo.effectiveRating(fp, own) -> the rating a book counts as, or nil.
-- The reader's own rating (own, whole stars; 0 means none), else, with the
-- Hardcover "Use Hardcover rating if no user rating" switch on, the
-- Hardcover average already cached for a linked book (fractional). Covers,
-- the Rating sort, the Ratings shelf and its filter all ask here, so one
-- book cannot show four stars on its cover and sort as unrated (issue 538).
-- Never the book menu's own stars: those are the reader's rating to set.
-- Nothing is fetched; a book without a cached Hardcover rating is unrated.
function Repo.effectiveRating(fp, own)
    own = tonumber(own)
    if own and own > 0 then return own end
    if not (fp and BookshelfSettings.isTrue("hardcover_rating_fallback")) then return nil end
    local ok, HC = pcall(require, "lib/bookshelf_hardcover")
    if not (ok and HC and HC.isAvailable and HC.getLink and HC.getCachedRating) then return nil end
    local ok_a, avail = pcall(HC.isAvailable)
    if not (ok_a and avail) then return nil end
    local ok_l, link = pcall(HC.getLink, fp)
    if not (ok_l and link and link.book_id) then return nil end
    local ok_r, hr = pcall(HC.getCachedRating, link.book_id)
    hr = ok_r and tonumber(hr) or nil
    if hr and hr > 0 then return hr end
    return nil
end

-- Repo.effectiveRatingStars(fp, own) -> 1..5, or nil: effectiveRating to
-- the nearest whole star, for the Ratings shelf's buckets and its filter.
function Repo.effectiveRatingStars(fp, own)
    local r = Repo.effectiveRating(fp, own)
    if not r then return nil end
    local n = math.floor(r + 0.5)
    if n < 1 then n = 1 elseif n > 5 then n = 5 end
    return n
end

-- Cached read of a file's percent_finished + summary.status + summary.rating
-- + page count. Returns (pct, status, rating, page_count). Any field may
-- be nil. A pcall guards a corrupt sdr sidecar so the caller's loop
-- survives single-file faults.
--
-- page_count fallback chain (same as buildBook): pagemap_doc_pages first
-- (stable count from KOReader's pagemap), then stats.pages (statistics
-- plugin's view), then a p(<n>) token in the filename (#159). Lets the
-- cover-progress page-count indicator work for EPUBs, which have no
-- BIM-reported page count — including unopened ones via the filename token.
function Repo.readProgress(filepath)
    if not filepath then return nil, nil, nil, nil end
    local now = os.time()
    local cached = _progress_cache[filepath]
    if cached then
        return cached.pct, cached.status, cached.rating, cached.page_count,
               cached.page_num, cached.page_src
    end
    -- page_src: which rung answered the page count -- "stable", "render",
    -- "store" or "filename". The sixth return; the spine's thickness needs
    -- to know (issue 387, SpineShelf.thicknessPages).
    local pct, status, rating, page_count, page_num, page_src
    local ok_ds, ds = pcall(function() return getDocSettings():open(filepath) end)
    if ok_ds and ds then
        local ok_pct, p = pcall(ds.readSetting, ds, "percent_finished")
        if ok_pct then pct = tonumber(p) end
        local ok_sum, summary = pcall(ds.readSetting, ds, "summary")
        if ok_sum and type(summary) == "table" then
            status = summary.status
            rating = tonumber(summary.rating)
            _finished_on[filepath] = summary.modified or false
        end
        local stable_on = _stablePagesOn(ds)
        local ok_pm, stable_pages = pcall(ds.readSetting, ds, "pagemap_doc_pages")
        if stable_on and ok_pm and stable_pages then
            page_count = tonumber(stable_pages)
            if page_count then page_src = "stable" end
        end
        if not page_count then
            local ok_st, stats = pcall(ds.readSetting, ds, "stats")
            if ok_st and type(stats) == "table" and stats.pages then
                page_count = tonumber(stats.pages)
                if page_count then page_src = "render" end
            end
        end
        -- CURRENT page, in buildBook's own precedence, so a shelf row and the
        -- hero never disagree about where the reader is in the same book: the
        -- stable pagemap label first, then last_page (set for PDF / CBZ). The
        -- percentage-derived third rung is applied below, once page_count is
        -- settled. Read from the handle already open here -- %page_num had no
        -- resolver at all before, so it rendered empty everywhere except the
        -- hero, which builds its one book the expensive way.
        local ok_lbl, label = pcall(ds.readSetting, ds, "pagemap_current_page_label")
        if stable_on and ok_lbl and label then page_num = tonumber(label) end
        if not page_num then
            local ok_lp, last_page = pcall(ds.readSetting, ds, "last_page")
            if ok_lp then page_num = tonumber(last_page) end
        end
    end
    -- Bookshelf's own persisted page-count store: the bulk scanner's
    -- answers for never-opened books (publisher page lists and Hardcover
    -- links; never its headless renders, which only set spine widths --
    -- see SpineShelf.shownPages), kept OUT of sidecars because creating one
    -- marks a book as opened in stock KOReader. Served here so EVERY
    -- consumer of readProgress -- %pages, %bar{rel}, list lines, sort
    -- keys -- sees them, not just spine widths. Above the filename guess:
    -- a scanned count is real, the filename one is folklore.
    if not page_count then
        local ok_ss, SS = pcall(require, "lib/bookshelf_spine_shelf")
        if ok_ss and SS and SS.shownPages then
            local pp = SS.shownPages(filepath)
            if pp then
                page_count = tonumber(pp)
                if page_count then page_src = "store" end
            end
        end
    end
    -- #159: last-resort filename fallback (see pageCountFromFilename), matching
    -- buildBook's progress-cache seed so the sort key / badge agree.
    if not page_count then
        page_count = pageCountFromFilename(filepath)
        if page_count then page_src = "filename" end
    end
    -- Normalise to bookshelf canonical status values. KOReader's End-of-book
    -- dialog and Book Status widget store 'complete' / 'abandoned' in
    -- summary.status; bookshelf's filter UI / sort engine refer to the
    -- same states as 'finished' / 'on_hold'. Translate once at the
    -- source so every downstream consumer reads the same vocabulary.
    if     status == "complete"  then status = "finished"
    elseif status == "abandoned" then status = "on_hold"
    end
    -- A sidecar with progress but no status is a book being read, as KOReader
    -- counts it (BookList.setBookInfoCache: opened, no valid status ->
    -- "reading"). Such a sidecar comes from elsewhere -- KOReader writes the
    -- status on every open -- and the shelf drew it as unread, with no bar
    -- (issue 524). Not "new": that is bookshelf's own Mark as unread, which
    -- also clears the percentage.
    if status == nil and pct then status = "reading" end
    -- Third rung, mirroring buildBook: synthesise the page from how far in the
    -- reader is. Approximate for a reflowable book, and the honest answer when
    -- neither exact source exists -- an EPUB without stable page numbers has no
    -- "current page" of its own to report.
    if not page_num and pct and page_count then
        -- Rounded, not truncated, matching buildBook: a book 99.9% read is on
        -- its last page, not the one before it. The two must agree to the page
        -- or the shelf and the hero differ by one on the same book.
        local n = math.floor(pct * page_count + 0.5)
        if n < 1 then n = 1 end
        page_num = n
    end
    _writeProgressCache(filepath, pct, status, rating, page_count, page_num, page_src)
    return pct, status, rating, page_count, page_num, page_src
end

-- Repo.finishedOn(filepath) -> the sidecar's summary.modified (the date its
-- status was last set, "YYYY-MM-DD"), or nil. Remembered until the book's
-- progress cache is dropped; readProgress usually answers it on the way.
function Repo.finishedOn(filepath)
    if not filepath then return nil end
    local c = _finished_on[filepath]
    if c == nil then
        c = false
        local ok_ds, ds = pcall(function() return getDocSettings():open(filepath) end)
        if ok_ds and ds then
            local ok_sum, summary = pcall(ds.readSetting, ds, "summary")
            if ok_sum and type(summary) == "table" and summary.modified ~= nil then
                c = summary.modified
            end
        end
        _finished_on[filepath] = c
    end
    return c or nil
end

-- Repo.progressFor(filepath) -> pct, status, rating, page_count, opened, page_num
--
-- readProgress with the cheap gate in front of it, given a name so the render
-- side does not have to reproduce the pairing.
--
-- `opened` is the gate's own answer, handed back rather than thrown away: a
-- DocSettings sidecar exists if and only if KOReader has opened the file, so
-- it is the one honest signal for "this book has reading history" -- which is
-- what tells a never-opened book (nothing to show) apart from one opened and
-- still at 0% (which really is 0%). Returning it here rather
-- than exposing a second entry point keeps that to ONE call per row: asking
-- twice would be memoized and cheap, but it would also be two things that
-- could disagree.
--
-- Every rendering path builds its records with buildBookMeta, which is
-- BookInfoManager-only by design (see its header ~line 586) -- so none of
-- these four fields is on a record the shelf draws, and the sort prefetches
-- that DO compute them (the getAll block near "needs.percent or needs.status"
-- and the getBySource "sort-needs progress" block) write them onto the LIGHT
-- candidate records they sort, both of which are discarded before the visible
-- slice is rehydrated. A renderer that wants progress therefore has to ask,
-- and asking is what bookshelf_cover_progress.decide already does per visible
-- cover today.
--
-- The gate is the whole point of the wrapper: readProgress alone opens a
-- DocSettings for every never-opened book just to learn it has nothing, where
-- _hasSidecar answers that with a memoized stat in the right metadata
-- location (#113/#117). Same pairing _recordMatches and the getBySource
-- prefetch already use; routing new callers through here means they share the
-- one _sidecar_memo instead of re-statting alongside it.
--
-- Deliberately NOT wired into any fetch path. This is a lazy per-rendered-item
-- lookup, bounded by PROGRESS_CACHE_TTL, not a fifth field for buildBookMeta
-- to populate across the whole library.
function Repo.progressFor(filepath)
    if not filepath then return nil, nil, nil, nil, false end
    if _hasSidecar(filepath) then
        local pct, status, rating, pages, page_num = Repo.readProgress(filepath)
        -- An opened book usually knows its own count. When it does not -- a
        -- reflowable opened but never paged far enough for KOReader to commit
        -- a total -- it takes the same ending as an unopened one, which this
        -- branch used to skip half of.
        return pct, status, rating, Repo.pageCountFor(filepath, pages),
               true, page_num
    end
    -- No sidecar means never opened: no percentage, status or rating exists to
    -- read. A page count still can -- pageCountFromFilename (#159) is a match
    -- on the name with no file touched, and readProgress would have returned
    -- it -- so hand it back, and the Pages column agrees with the page_count
    -- sort key instead of going blank exactly where the sort has a value.
    -- No sidecar means never opened, so there is no current page either --
    -- page_num stays nil rather than being synthesised as page 1.
    return nil, nil, nil, Repo.pageCountFor(filepath), false, nil
end

-- Repo.fileSizeFor(filepath) -> bytes, or nil.
--
-- One lfs stat, memoized for the session. Same shape and same purpose as
-- progressFor -- a lazy per-rendered-item lookup for a value the record the
-- shelf draws does not carry -- but far cheaper: buildBookMeta is
-- BookInfoManager-only and BIM stores no file size at all, while the size is a
-- field of the stat every other walker in this file already takes.
--
-- Not folded into buildBookMeta on purpose. That would stat every book on
-- every rebuild, in cover mode too, for a column almost nobody has switched
-- on; here the cost is bounded by the rows on screen and by whether the File
-- size column is active at all.
--
-- Invalidated with the walk cache rather than on a TTL: a file's size changes
-- only when the file itself is replaced, which is a sideload, which is what
-- invalidateWalkCache exists for.
_size_memo = {}
function Repo.fileSizeFor(filepath)
    if type(filepath) ~= "string" or filepath == "" then return nil end
    local memo = _size_memo[filepath]
    if memo ~= nil then
        if memo == false then return nil end
        return memo
    end
    local ok_lfs, lfs = pcall(require, "libs/libkoreader-lfs")
    if not ok_lfs or not lfs or not lfs.attributes then return nil end
    local ok, bytes = pcall(lfs.attributes, filepath, "size")
    if not ok or type(bytes) ~= "number" then
        -- Remember the miss too: a path with no file behind it (a stale
        -- history entry, a card that has been ejected) would otherwise re-stat
        -- on every page turn for as long as it stays on screen.
        _size_memo[filepath] = false
        return nil
    end
    _size_memo[filepath] = bytes
    return bytes
end

-- `dirs` (optional out-param): when present, walkBooks records every visited
-- subdirectory's mtime in it (keyed by absolute path). cachedWalk uses this
-- to detect "did anything in the library change since we cached?" with a
-- single stat() per dir on subsequent reads, far cheaper than re-walking
-- the entire tree on each chip tap.
local function walkBooks(root, depth, out, current_depth, dirs, listings)
    current_depth = current_depth or 0
    if current_depth > depth then return end
    -- Refuse to walk an unset/empty root. "/" is permitted (some users set
    -- home_dir to root deliberately) — SYSTEM_DIR_NAMES below filters out
    -- the pseudo-filesystems that would otherwise OOM the walk.
    if current_depth == 0 and (not root or root == "") then
        logger.warn("[bookshelf] walkBooks: home_dir not configured; skipping walk")
        return
    end
    local ok_lfs, lfs = pcall(require, "libs/libkoreader-lfs")
    if not ok_lfs or not lfs or not lfs.dir then return end

    -- Guard against permission errors / missing dirs raised by lfs.dir(root).
    -- lfs.dir returns (iterator, dir_obj); both must be passed to the for
    -- loop or lfs raises "directory metatable expected, got nil" on the first
    -- step. pcall returns (ok, ret1, ret2, …) — capture both real returns.
    local ok, iter, dir_obj = pcall(lfs.dir, root)
    if not ok or type(iter) ~= "function" then return end

    -- The custom-metadata gate below needs to know whether a book's sibling
    -- ".sdr" exists, and answers that from a per-directory listing it builds
    -- itself. This walk is already reading every one of those directories, so
    -- hand the names over rather than have them read a second time. Recorded
    -- BEFORE the hidden/system filter, so the set is the directory's real
    -- contents and not this walk's view of it.
    local listing = listings and {} or nil
    -- An UNPACKED EPUB (Reddit report: dozens of "books" titled c01, c05...
    -- in a section called OEBPS) is a folder holding a "mimetype" file and a
    -- META-INF folder, with its chapters as .xhtml/.html files that pass the
    -- book test one by one. Nothing inside it is a book. That is only known
    -- once the whole listing has been read, so this directory's files and
    -- subfolders wait in `found` / `subdirs` until then -- no extra stat.
    local seen_mimetype, seen_meta_inf = false, false
    local found, subdirs = {}, {}
    for entry in iter, dir_obj do
        if listing then listing[entry] = true end
        if entry == "mimetype" then seen_mimetype = true
        elseif entry == "META-INF" then seen_meta_inf = true end
        -- Skip "." / ".." and any hidden file or directory (entries
        -- starting with "."). The hidden-file filter catches AppleDouble
        -- metadata companions macOS spits out when copying to FAT32
        -- (`._<filename>`, same extension as the original so the
        -- extension-only filter below lets them through as "books"),
        -- plus the usual .DS_Store / .git / .calibre-cache / etc. that
        -- never contain real books. The other walkers in this file
        -- (around lines 1222, 1269, 1406) already do this; walkBooks
        -- was the odd one out.
        if entry:sub(1, 1) ~= "." and not SYSTEM_DIR_NAMES[entry] then
            local fp = _joinPath(root, entry)
            -- One stat call instead of two on real lfs (which returns a
            -- table from attributes(fp) with no key). Falls back to two
            -- keyed calls for test stubs that don't implement the no-key
            -- form. The fast path halves the syscall count over the
            -- recursive walk on actual hardware.
            local attr = lfs.attributes(fp)
            if type(attr) ~= "table" then
                attr = {
                    mode = lfs.attributes(fp, "mode"),
                    modification = lfs.attributes(fp, "modification"),
                }
            end
            local mode = attr.mode
            if mode == "directory" then
                -- Skip .sdr sidecar dirs. They contain KOReader's per-book
                -- metadata (cover, progress, etc.) and no actual books -- so
                -- descending into them is wasted work. More importantly:
                -- their mtime bumps every time a book is closed (metadata
                -- rewrite), which would falsely invalidate the walk cache
                -- on every read session if we recorded them in `dirs`.
                if entry:sub(-4) ~= ".sdr" then
                    subdirs[#subdirs + 1] = { fp = fp, mtime = attr.modification or 0 }
                end
            elseif mode == "file" then
                if _supportedExt(entry) then
                    -- size kept alongside mtime so sort-by-File-size on
                    -- custom-source tabs has data without re-statting.
                    -- attr.size is already in hand from the same lfs call.
                    found[#found + 1] = {
                        fp    = fp,
                        mtime = attr.modification or 0,
                        size  = attr.size or 0,
                    }
                end
            end
        end
    end
    if listings and listing then listings[root] = listing end
    if seen_mimetype and seen_meta_inf then return end
    for i = 1, #found do out[#out + 1] = found[i] end
    for i = 1, #subdirs do
        local d = subdirs[i]
        if dirs then dirs[d.fp] = d.mtime end
        walkBooks(d.fp, depth, out, current_depth + 1, dirs, listings)
    end
end

-- _dirsChanged(dirs): true if any recorded directory's current mtime differs
-- from what we saved (or the directory is gone). On Kindle's user partition
-- a stat() takes ~50us and a typical library has ~100-500 dirs, so the
-- whole check is single-digit ms even on a cold filesystem cache. Cheaper
-- than the 1-3s a re-walk would cost.
local function _dirsChanged(dirs)
    if not dirs then return true end
    local ok_lfs, lfs = pcall(require, "libs/libkoreader-lfs")
    if not ok_lfs or not lfs or not lfs.attributes then return true end
    for path, recorded in pairs(dirs) do
        local now_mtime = lfs.attributes(path, "modification")
        if not now_mtime or now_mtime ~= recorded then return true end
    end
    return false
end

-- ─── walk disk snapshot ──────────────────────────────────────────────────────
-- _walk_cache is memory-only, so the recursive directory walk ran on every
-- cold start: 135ms for 247 files across 29 directories on a PW5, and it
-- scales with the size of the library rather than with what is on screen.
--
-- Nothing about that walk is time-sensitive. Validity here has never been a
-- TTL: it is _dirsChanged, which re-stats every directory the walk recorded
-- and rejects the cache if any mtime moved (WALK_CACHE_TTL is vestigial, see
-- its declaration). That check works exactly as well against a walk from the
-- previous launch as against one from earlier this session -- ~29 stats at
-- ~50us against a 135ms walk -- so the snapshot is the same decision the
-- in-memory cache already makes, just with a baseline that survives a restart.
--
-- The directory LISTINGS ride along. They are what the custom-metadata gate
-- would otherwise rebuild one directory at a time, and they are valid under
-- exactly the same condition as the walk itself: if every recorded directory
-- has an unchanged mtime, its contents are unchanged too.
local WALK_SNAPSHOT_VERSION = 1

-- ── Where our cache files live ─────────────────────────────────────────────
--
-- In a SUBDIRECTORY of koreader/cache/, never in its root.
--
-- KOReader's DocCache treats every regular file in that root as part of its own
-- disk cache: Cache:_getDiskCache snapshots anything with mode == "file", the
-- total counts against DocCache's budget, and once that budget is exceeded
-- DocCache:serialize deletes entries oldest-first until it fits again.
--
-- On a Kindle that is not the LRU it appears to be. /mnt/us is mounted noatime
-- and FAT records an access DATE with no time, so reading a file never moves
-- its atime -- it stays at creation. Measured on a PW5: bookshelf.lightmeta,
-- read on every shelf open and rewritten the day before, still carried a
-- ten-day-old atime and sorted AHEAD of a doccache entry KOReader had touched
-- more recently. Our files drift to the front of the eviction queue however
-- heavily they are used, and cannot climb back.
--
-- Nothing corrupts if one is evicted -- we rebuild -- but lightmeta's rebuild
-- is a full metadata walk, so the symptom is a slow shelf open with no
-- explanation, repeatedly. A subdirectory leaves the pool entirely, which is
-- why bookshelf_covers/, cr3cache/ and calibre/ have never been at risk.
local CACHE_FILES = { "bookshelf.walk", "bookshelf.finishedcount",
                      "bookshelf.lightmeta" }
local _cache_migrated = false
local function _cachePath(name)
    local ok, DataStorage = pcall(require, "datastorage")
    if not (ok and DataStorage) then return nil end
    -- getDataDir guarded as well as the require: callers treat a nil path as
    -- "no cache available" and carry on, so a half-present datastorage must
    -- degrade the same way rather than throw from inside a shelf build.
    local ok_dir, data_dir = pcall(function() return DataStorage:getDataDir() end)
    if not (ok_dir and type(data_dir) == "string") then return nil end
    local root = data_dir .. "/cache/"
    local dir  = root .. "bookshelf/"
    local ok_lfs, lfs = pcall(require, "libs/libkoreader-lfs")
    if ok_lfs and lfs then
        pcall(lfs.mkdir, dir)
        -- One-time move of the files v5.0.4 and earlier wrote to the root. A
        -- rename within the same filesystem, so cheap; if it fails the file is
        -- simply rebuilt in the new place. Guarded so the shelf's repeated
        -- cache reads do not re-stat the root every time.
        if not _cache_migrated then
            _cache_migrated = true
            for i = 1, #CACHE_FILES do
                local old = root .. CACHE_FILES[i]
                if lfs.attributes(old, "mode") == "file" then
                    pcall(os.rename, old, dir .. CACHE_FILES[i])
                end
            end
        end
    end
    return dir .. name
end

local function _walkPersist()
    local ok_p, Persist = pcall(require, "persist")
    local path = _cachePath("bookshelf.walk")
    if not (ok_p and Persist and path) then return nil end
    local ok_new, p = pcall(Persist.new, Persist, {
        path  = path,
        codec = "zstd",
    })
    return ok_new and p or nil
end

local function _loadWalkSnapshot(key)
    local p = _walkPersist()
    if not p then return nil end
    local ok, t = pcall(p.load, p)
    if not (ok and type(t) == "table") then return nil end
    if t.version ~= WALK_SNAPSHOT_VERSION or t.key ~= key then return nil end
    if type(t.list) ~= "table" or type(t.dirs) ~= "table" then return nil end
    return t
end

-- `formats` is the plugin format set the walk was taken with (see cachedWalk).
-- A snapshot written before it existed has none, which reads as "" -- no plugin
-- formats -- exactly what that version walked with, so no version bump.
local function _saveWalkSnapshot(key, list, dirs, listings, formats)
    local p = _walkPersist()
    if not p then return end
    pcall(p.save, p, {
        version  = WALK_SNAPSHOT_VERSION,
        key      = key,
        list     = list,
        dirs     = dirs,
        listings = listings,
        formats  = formats,
    })
end

_dropWalkSnapshot = function()
    local p = _walkPersist()
    if p then pcall(p.delete, p) end
end

-- Returns a shallow copy of the cached candidate list for (home, depth).
-- Walks fresh on miss/expiry/dir-mtime-change. The copy is so callers
-- (e.g. getLatest) can sort in place without mutating the cached order.
local function cachedWalk(home, depth)
    local key = (home or "/") .. ":" .. tostring(depth or 0)
    local now = os.time()
    local formats = _pluginFormatsFingerprint()
    local formats_changed = false
    local entry = _walk_cache[key]
    if entry and (entry.formats or "") ~= formats then
        Repo.invalidateWalkCache()
        entry, formats_changed = nil, true
    end
    local from_snapshot = false
    if not entry then
        -- Nothing in memory: try the previous launch's walk. It is adopted
        -- only as a CANDIDATE -- _dirsChanged below is what accepts or
        -- rejects it, exactly as it does for an in-session entry.
        local snap = _loadWalkSnapshot(key)
        if snap and (snap.formats or "") ~= formats then
            -- Walked with another plugin format set: not a candidate, and
            -- anything else persisted from that library (the finished count)
            -- goes with it.
            Repo.invalidateWalkCache()
            snap, formats_changed = nil, true
        end
        if snap then
            entry = { list = snap.list, dirs = snap.dirs,
                      listings = snap.listings, formats = formats,
                      expires_at = now + WALK_CACHE_TTL }
            from_snapshot = true
        end
    end
    local stale_reason
    if not entry then
        stale_reason = formats_changed and "formats" or "miss"
    elseif _dirsChanged(entry.dirs) then
        stale_reason = from_snapshot and "snapshot-dir-mtime" or "dir-mtime"
    end
    if stale_reason then
        local _t0 = _gettime()
        local fresh, dirs = {}, {}
        -- Record the root's own mtime too -- a new top-level book or folder
        -- bumps the home_dir's mtime, and without this entry the dir-mtime
        -- check would miss those adds.
        local ok_lfs, lfs = pcall(require, "libs/libkoreader-lfs")
        if ok_lfs and lfs and lfs.attributes then
            local root_m = lfs.attributes(home, "modification")
            if root_m then dirs[home] = root_m end
        end
        local listings = {}
        walkBooks(home, depth, fresh, 0, dirs, listings)
        -- Seed the custom-metadata gate from this walk. Only ever from a FRESH
        -- walk: a cached one could describe a library that has since changed,
        -- and this cache decides whether a book's sidecar directory exists.
        -- The listings are exactly what the gate would otherwise read for
        -- itself, one directory at a time, a moment later.
        _seedDirEntryCache(listings)
        local _dt = (_gettime() - _t0) * 1000
        -- Compare the new book set to the previous one (filepath set
        -- equality). The most common dir-mtime change is a user opening
        -- a new-to-them book for the first time: KOReader creates the
        -- book's .sdr sidecar, which adds an entry to the parent
        -- directory and bumps its mtime -- triggering this rebuild --
        -- but the underlying set of book files is unchanged. In that
        -- case we keep the downstream caches valid and just refresh
        -- the dirs map. Only an actual add/remove cascades.
        local files_changed = true
        if entry and entry.list and stale_reason ~= "miss" then
            files_changed = false
            if #entry.list ~= #fresh then
                files_changed = true
            else
                local old_set = {}
                for i = 1, #entry.list do old_set[entry.list[i].fp] = true end
                for i = 1, #fresh do
                    if not old_set[fresh[i].fp] then files_changed = true; break end
                end
            end
        end
        entry = { list = fresh, dirs = dirs, listings = listings,
                  formats = formats, expires_at = now + WALK_CACHE_TTL }
        _walk_cache[key] = entry
        _saveWalkSnapshot(key, fresh, dirs, listings, formats)
        if files_changed and stale_reason ~= "miss" then
            -- Downstream caches were built against the previous book set
            -- and won't include newly-added (or still-include removed)
            -- books. Drop them so the next query rebuilds against the
            -- fresh walk. Skipped when the book set is unchanged --
            -- saves rebuilding 13+ author/genre group caches just
            -- because a .sdr was created.
            _series_cache    = {}
            _authors_cache   = {}
            _genres_cache    = {}
            _formats_cache   = {}
            _ratings_cache   = {}
            _all_cache       = {}
            _all_cache_order = {}
            _bySource_cache  = {}
            _bySource_cache_order = {}
            _light_meta_cache = {}
            _folder_book_paths_cache = {}
            _folder_cover_cache = {}
            _folder_cover_cache_order = {}
        end
        local dir_count = 0
        for _k in pairs(dirs) do dir_count = dir_count + 1 end
        logger.dbg(string.format("[bookshelf perf] cachedWalk: MISS(%s) walk=%.0fms files=%d dirs=%d depth=%s",
            stale_reason, _dt, #fresh, dir_count, tostring(depth)))
    else
        if from_snapshot then
            -- Accepted: every directory the previous launch recorded still has
            -- the mtime it had then, so both the book list and the listings
            -- describe the library as it is now. Install it as this session's
            -- entry so the next call does not re-read the file.
            _walk_cache[key] = entry
            _seedDirEntryCache(entry.listings)
        end
        logger.dbg(string.format("[bookshelf perf] cachedWalk: HIT(%s) files=%d ttl_left=%ds",
            from_snapshot and "snapshot" or "memory",
            #entry.list, entry.expires_at - now))
    end
    local copy = {}
    for i = 1, #entry.list do copy[i] = entry.list[i] end
    return copy
end

-- Repo.countFinishedBooks() -> how many books in the library are Finished.
--
-- For the %books_read token (a Reddit request: "a 'books read: NNNN' line in
-- the hero status area"). "Read" means what KOReader's own Reader Status
-- means: summary.status Finished, which is the only lifetime the reader has
-- actually declared -- the statistics plugin counts opened books, which is a
-- different and less flattering number.
--
-- Costed like the status FILTER sweep, through the same primitives:
-- progressFor is sidecar-gated (books never opened cost one memoised stat)
-- and per-file memoised, so the first count after a cold start pays one
-- DocSettings read per opened book and every later count inside the TTL is a
-- table lookup. 60s TTL rather than event-driven: a lifetime total being up
-- to a minute stale is invisible, and the walk invalidation below clears it
-- on any library change anyway.
-- (_finished_count is declared above, beside the other caches, so the
-- walk invalidation can clear it without a forward reference.)
-- The finished-book count survives a restart. Its cold walk stats every
-- sidecar in the library (~650ms for 243 books on a PW5) and lands on the
-- hero's critical path the moment a status line names %books_read, so paying
-- it again on every launch is the whole cost of the token.
--
-- Correctness rests on the invalidation, not on a short TTL: any status change
-- or metadata edit goes through invalidateProgressCache, and any library change
-- through invalidateWalkCache, and both drop the stored value. The 24h TTL is
-- only a backstop for a status changed behind our back (a sync from another
-- device), which the old 60s in-memory TTL used to catch.
-- Assigned further down, next to search, which shares this gate.
local _librarySourceBooks

-- _librarySourceStatusCounts(): status tally over the Kindle catalogue, plus the
-- number of books it holds. nil when there is no Kindle chip or the catalogue
-- is unreadable, so a library without one is left exactly as it was.
--
-- Cache-only: listBooks serves from its own TTL cache, so this is neither a
-- disk walk nor a network call. Kindle books cannot collide with walked ones --
-- a .kfx is not in SUPPORTED_EXT and they live outside home_dir -- so these
-- tallies are additive, the same assumption searchBooks makes.
local function _librarySourceStatusCounts()
    local books = _librarySourceBooks()
    if not books then return nil end
    local counts = { unread = 0, reading = 0, on_hold = 0, finished = 0 }
    for _i, b in ipairs(books) do
        -- Both spellings, as countFinishedBooks does: normalisation lives
        -- elsewhere and must not be able to silently drop a book here.
        local st = b._status or "unread"
        if st == "complete" then st = "finished" end
        counts[st] = (counts[st] or 0) + 1
    end
    return counts, #books
end

local FINISHED_COUNT_TTL = 24 * 60 * 60
local function _finishedCountPersist()
    local ok_p, Persist = pcall(require, "persist")
    local path = _cachePath("bookshelf.finishedcount")
    if not (ok_p and Persist and path) then return nil end
    local ok_new, p = pcall(Persist.new, Persist, {
        path  = path,
        codec = "zstd",
    })
    return ok_new and p or nil
end

local function _loadFinishedCount()
    local p = _finishedCountPersist()
    if not p then return nil end
    local ok, t = pcall(p.load, p)
    if ok and type(t) == "table" and type(t.value) == "number"
            and type(t.saved_at) == "number"
            and os.time() - t.saved_at < FINISHED_COUNT_TTL then
        return t.value
    end
    return nil
end

local function _saveFinishedCount(n)
    local p = _finishedCountPersist()
    if not p then return end
    pcall(p.save, p, { value = n, saved_at = os.time() })
end

_dropFinishedCount = function()
    local p = _finishedCountPersist()
    if not p then return end
    pcall(p.save, p, {})
end

local function _finishedCountWalked()
    local now = os.time()
    if _finished_count.value and now < _finished_count.expires_at then
        return _finished_count.value
    end
    -- Adopt the stored count rather than re-walking on the first access after
    -- a restart. Anything that could have changed it dropped it (see the note
    -- on FINISHED_COUNT_TTL).
    local stored = _loadFinishedCount()
    if stored then
        _finished_count.value      = stored
        _finished_count.expires_at = now + 60
        return stored
    end
    local home  = HomeDir.get() or "/"
    local depth = BookshelfSettings.read("latest_walk_depth") or 3
    local n = 0
    for _i, c in ipairs(cachedWalk(home, depth) or {}) do
        local _pct, status = Repo.progressFor(c.fp)
        -- Both spellings: readProgress normalises complete -> finished, but
        -- accept the raw value too so this cannot break if that mapping moves.
        if status == "finished" or status == "complete" then n = n + 1 end
    end
    _finished_count.value = n
    _finished_count.expires_at = now + 60
    _saveFinishedCount(n)
    return n
end

-- A book finished on the Kindle is a book the user finished, so it belongs in
-- this count as much as a walked one.
--
-- The Kindle share is added at READ time and never persisted. The stored count
-- is correct only because every local mutation drops it (see FINISHED_COUNT_TTL
-- above), and nothing drops it when a Kindle status changes -- so persisting a
-- Kindle contribution would keep a stale number for up to 24h. Recomputing it
-- per call is free: it is a tally over an in-memory catalogue.
function Repo.countFinishedBooks()
    local n = _finishedCountWalked()
    local k = _librarySourceStatusCounts()
    if k then n = n + k.finished end
    return n
end


-- ─── Batch BIM loader + light-meta cache ─────────────────────────────────────
-- Pull every text-only bookinfo row from BIM in one SQLite call. Returns a
-- (directory||filename) → info-table map, or nil on failure (caller falls back
-- to per-book bim:getBookInfo via _buildBookMetaLight).
--
-- BIM's public API only exposes a single-row prepared statement
-- (BOOKINFO_SELECT_SQL), so we reach into bim.db_conn directly. The risk is a
-- future BIM schema change; mitigated by pcall + nil return + per-book
-- fallback, so a schema break degrades to "old slow path" rather than a crash.
local function _loadBatchBookInfoFromBim()
    local bim = getBookInfoMgr()
    if not bim or type(bim.openDbConnection) ~= "function" then return nil end
    local ok_open = pcall(function() bim:openDbConnection() end)
    if not ok_open then return nil end
    local conn = bim.db_conn
    if not conn or type(conn.exec) ~= "function" then return nil end

    -- Every TEXT/INTEGER column buildBookMeta reads, so a batched row can
    -- stand in for a live getBookInfo(fp, false) row (the fast path in
    -- buildBookMeta). Still no cover_* blob columns: their inline pages are
    -- what makes the per-book SELECT expensive in the first place.
    local sql = "SELECT directory, filename, title, authors, series, series_index, keywords, language, " ..
                "pages, description, has_meta, has_cover, ignore_cover, ignore_meta, cover_sizetag, " ..
                "cover_fetched " ..
                "FROM bookinfo WHERE in_progress=0;"
    local rows
    local ok, err = pcall(function() rows = conn:exec(sql) end)
    if not ok then
        logger.warn("[bookshelf] batch BIM read failed:", err)
        return nil
    end
    if not rows then return {} end  -- empty DB

    -- ljsqlite3:exec returns column-major arrays: rows[col_index][row_index].
    -- col() tolerates a result with fewer columns than the SELECT names
    -- (a stubbed exec, or an exec that ignores the SQL): missing columns
    -- read as nil fields, which every consumer already handles.
    local function col(c, i)
        local a = rows[c]
        return a and a[i] or nil
    end
    local n = (rows[1] and #rows[1]) or 0
    local map = {}
    for i = 1, n do
        local fp = (col(1, i) or "") .. (col(2, i) or "")
        map[fp] = {
            title        = col(3, i),
            authors      = col(4, i),
            series       = col(5, i),
            series_index = col(6, i),
            keywords     = col(7, i),
            language     = col(8, i),
            -- tonumber: INTEGER comes back as cdata<int64_t>, which the
            -- snapshot codec can't round-trip and callers can't compare.
            pages        = tonumber(col(9, i)),
            description  = col(10, i),
            has_meta     = col(11, i),
            has_cover    = col(12, i),
            ignore_cover = col(13, i),
            ignore_meta  = col(14, i),
            cover_sizetag = col(15, i),
            -- Absent from rows a snapshot saved before it was selected (same
            -- format version on purpose: a bump re-reads the whole table on the
            -- launch path for everyone). nil reads as "not fetched", which only
            -- skips the cover-hook probe, the behaviour before it existed.
            cover_fetched = col(16, i),
        }
    end
    return map
end

-- ─── light-meta disk snapshot ────────────────────────────────────────────────
-- The batch SELECT above is I/O-bound on the WHOLE bookinfo table: cover
-- blobs live inline in the rows, so SQLite drags every cover's pages off
-- disk even though we only read text columns. On a PW5 that's ~740ms of
-- the cold boot; on slow Android SD storage it plausibly scales to tens of
-- seconds (issue 262). Snapshot the raw row map to a small zstd file,
-- fingerprinted by the BIM db's (size, mtime): any BIM write (extraction,
-- metadata edit, prune) changes the fingerprint and falls back to the live
-- SELECT, which re-saves. Only the RAW rows are persisted — the derived
-- light records fold in Calibre metadata at derive time, which must stay
-- fresh independently of BIM.
-- v2: rows gained pages/description/has_meta/has_cover/ignore_cover/
-- ignore_meta/cover_sizetag (the buildBookMeta batch fast path needs the
-- full text row). The version is baked into the fingerprint, so a v1
-- snapshot from before the upgrade fails the match and regenerates.
local LIGHTMETA_SNAPSHOT_VERSION = 2

local function _bimDbFingerprint()
    local ok, DataStorage = pcall(require, "datastorage")
    local ok_lfs, lfs = pcall(require, "libs/libkoreader-lfs")
    if not (ok and ok_lfs and DataStorage and lfs) then return nil end
    local db_path = DataStorage:getSettingsDir() .. "/bookinfo_cache.sqlite3"
    local size = lfs.attributes(db_path, "size")
    if not size then return nil end
    local mtime = lfs.attributes(db_path, "modification") or 0
    -- In WAL mode (every device but Kobo) a write lands in the -wal file and
    -- leaves the main file's size and mtime alone until a checkpoint, so the
    -- main file by itself called a snapshot fresh after BIM had moved on.
    -- Seen on the desktop rig: a cover extraction, and the snapshot from
    -- before it still matched.
    local wal = db_path .. "-wal"
    local wal_size = lfs.attributes(wal, "size")
    if wal_size then
        return string.format("v%d:%d:%d:%d:%d", LIGHTMETA_SNAPSHOT_VERSION, size, mtime,
                             wal_size, lfs.attributes(wal, "modification") or 0)
    end
    return string.format("v%d:%d:%d", LIGHTMETA_SNAPSHOT_VERSION, size, mtime)
end

local function _lightMetaPersist()
    local ok_p, Persist = pcall(require, "persist")
    local path = _cachePath("bookshelf.lightmeta")
    if not (ok_p and Persist and path) then return nil end
    local ok_new, p = pcall(Persist.new, Persist, {
        path  = path,
        codec = "zstd",
    })
    return ok_new and p or nil
end

-- Returns the persisted raw row map and whether it is FRESH (the BIM db is
-- unchanged since it was saved). A snapshot of the same FORMAT version whose
-- db fingerprint has moved comes back too, flagged stale: the caller serves
-- it at once and refreshes in the background (see _scheduleLightMetaRefresh).
-- Stale rows are right for every book that didn't change, and a book the
-- rows don't know falls back to the per-book path anyway; what they must
-- never be is an OLDER FORMAT -- those rows lack columns the fast paths
-- read -- so a version-prefix mismatch is nil, not stale.
local function _loadRowSnapshot()
    local fingerprint = _bimDbFingerprint()
    if not fingerprint then return nil end
    local p = _lightMetaPersist()
    if not p then return nil end
    local ok, t = pcall(p.load, p)
    if not (ok and type(t) == "table" and type(t.rows) == "table"
            and type(t.fingerprint) == "string") then
        return nil
    end
    if t.fingerprint == fingerprint then return t.rows, true end
    local want_v = fingerprint:match("^(v%d+):")
    local have_v = t.fingerprint:match("^(v%d+):")
    if want_v and have_v and want_v == have_v then return t.rows, false end
    return nil
end

local function _saveRowSnapshot(rows)
    if type(rows) ~= "table" then return end
    local fingerprint = _bimDbFingerprint()
    if not fingerprint then return end
    local p = _lightMetaPersist()
    if not p then return end
    pcall(p.save, p, { fingerprint = fingerprint, rows = rows })
end

-- Background refresh of a stale snapshot. The batch SELECT over a big
-- bookinfo table is the one launch cost we have seen reach 15 seconds (slow
-- SD / colour panels' larger cover blobs, issue 262), and the snapshot only
-- dodges it while the db is untouched -- any cover extraction between boots
-- brought it straight back onto the launch path. Now the shelf opens on the
-- stale rows and this runs a little later on the UI loop: it still blocks
-- for the read's duration when it runs, but after the first paint and the
-- first taps, not before them. One refresh in flight at a time; the fresh
-- rows are saved and the derived map dropped, so the next reader loads the
-- fresh snapshot (a zstd load, not a table scan).
local LIGHTMETA_REFRESH_DELAY_S = 2
local _lightmeta_refresh_pending = false
-- The rows a completed refresh produced, this session. _getLightMetaCache
-- prefers them over anything on disk, so the fresh map does NOT depend on
-- the snapshot save succeeding -- a read-only data dir or a full disk would
-- otherwise leave the stale snapshot in place and re-arm a full table read
-- every two seconds for the whole session. Set once: a session refreshes
-- at most once.
local _lightmeta_fresh_rows = nil
local function _scheduleLightMetaRefresh()
    if _lightmeta_refresh_pending or _lightmeta_fresh_rows then return end
    local ok_um, UIManager = pcall(require, "ui/uimanager")
    if not (ok_um and type(UIManager) == "table" and UIManager.scheduleIn) then
        return   -- no event loop (standalone/tests): the stale rows stand
    end
    _lightmeta_refresh_pending = true
    UIManager:scheduleIn(LIGHTMETA_REFRESH_DELAY_S, function()
        _lightmeta_refresh_pending = false
        local _t0 = _gettime()
        local ok, rows = pcall(_loadBatchBookInfoFromBim)
        if ok and rows then
            _lightmeta_fresh_rows = rows
            pcall(_saveRowSnapshot, rows)   -- best effort; memory is authoritative now
            Repo.invalidateLightMeta()
            logger.dbg(string.format(
                "[bookshelf perf] light_meta: background refresh %.0fms rows=%d",
                (_gettime() - _t0) * 1000, (function() local n = 0 for _ in pairs(rows) do n = n + 1 end return n end)()))
        end
    end)
end

-- _getLightMetaCache(home, depth) — returns a fp → light-record map for every
-- candidate in the cached walk. Built once per (home, depth) using a single
-- batch BIM SELECT; subsequent walks for the same (home, depth) are O(1)
-- lookups per book. Falls back to per-book _buildBookMetaLight if the batch
-- query fails (rare; BIM unavailable or schema mismatch).
local function _getLightMetaCache(home, depth)
    local key = (home or "/") .. ":" .. tostring(depth or 0)
    local now = os.time()
    local entry = _light_meta_cache[key]
    if entry then
        logger.dbg(string.format("[bookshelf perf] light_meta: HIT entries=%d ttl_left=%ds",
            entry.count or 0, entry.expires_at - now))
        return entry.map
    end

    -- Build the map directly from the batch BIM result. Earlier the cache
    -- was filtered through cachedWalk to drop entries for files BIM still
    -- knows about but that have been deleted from disk; callers handle
    -- those with a per-book fallback on lookup miss anyway, so the filter
    -- wasn't load-bearing. Skipping cachedWalk here removes ~2s from
    -- Home's cold path on a 1500-book library — the Home (all-chip) path
    -- has its own single-level lfs.dir scan and never needed the
    -- recursive walk that this cache was forcing.
    local _t0 = _gettime()
    -- Disk snapshot first: skips the blob-page-heavy SELECT entirely when
    -- the BIM db is unchanged since last save (the common cold boot).
    -- Rows a completed background refresh left in memory outrank the disk
    -- snapshot (see _lightmeta_fresh_rows); then the snapshot; then the live
    -- batch, saved for next time.
    local snapshot, fresh
    if _lightmeta_fresh_rows then
        snapshot, fresh = _lightmeta_fresh_rows, true
    else
        snapshot, fresh = _loadRowSnapshot()
    end
    local _t_load = _gettime()
    local row_map = snapshot or _loadBatchBookInfoFromBim()
    if row_map and not snapshot then
        _saveRowSnapshot(row_map)
    end
    local stale = (snapshot ~= nil) and not fresh
    local meta_map
    local count = 0
    local skipped = 0
    if row_map then
        -- BIM's table covers every book KOReader has ever opened, not just the
        -- ones under home_dir. Every consumer of this map looks entries up by a
        -- filepath that came from the home-scoped walk, so a record for a book
        -- outside home is built and then never read -- and each one drags in a
        -- directory listing for wherever it lives (/mnt/us/documents,
        -- /mnt/us/mrpackages, the USB root...), which is the expensive half.
        -- A prefix test is nearly free, unlike the recursive-walk filter that
        -- used to be here and cost ~2s. Anything outside still resolves through
        -- the per-book fallback on lookup miss, exactly as a stale row does.
        local prefix = home
        if prefix and prefix ~= "" and prefix ~= "/" then
            prefix = prefix:gsub("/+$", "") .. "/"
        else
            prefix = nil
        end
        -- One query for every cached Hardcover enrichment, instead of the one
        -- per book that _buildLightMetaFromInfo would otherwise trigger from
        -- applyMetadata. Measured on a PW5 with 229 of 321 books linked, those
        -- per-book reads were 231ms of a 663ms map build. Cheap and inert when
        -- the plugin is absent or the metadata override is off: preloadMetadata
        -- checks both before touching the table.
        local _hc = getHardcover()
        if _hc and _hc.preloadMetadata then pcall(_hc.preloadMetadata) end
        -- Count the eligible rows now (a string compare each), but BUILD the
        -- records on demand.
        --
        -- Deriving a light record is not free: it resolves Calibre metadata,
        -- splits authors, and stats for a custom_metadata.lua sidecar. At
        -- ~1.2ms a book that is ~390ms for a 321-book library on a PW5, paid
        -- on every cold start, and it scales with the SIZE OF THE LIBRARY
        -- rather than with what is on screen -- so a 2000-book library pays
        -- seconds of it before anything is drawn.
        --
        -- Most chips never touch most of those records. The default chip shows
        -- recently-read books; Favourites shows a handful. Only the grouping
        -- chips (Series / Authors / Genres) genuinely walk every book, and
        -- they get the same records, just built as they are asked for.
        --
        -- Safe to make lazy because nothing iterates this map: every consumer
        -- goes through _lightMetaForFp, which is a keyed lookup. A book with
        -- no BIM row still returns nil here and still falls back to the
        -- per-book path, exactly as before.
        for fp in pairs(row_map) do
            if prefix and fp:sub(1, #prefix) ~= prefix then
                skipped = skipped + 1
            else
                count = count + 1
            end
        end
        meta_map = setmetatable({}, {
            __index = function(t, fp)
                if type(fp) ~= "string" then return nil end
                if prefix and fp:sub(1, #prefix) ~= prefix then return nil end
                local info = row_map[fp]
                if not info then return nil end
                local rec = _buildLightMetaFromInfo(fp, info)
                -- Memoise, so the second consumer of a book pays nothing and
                -- the map behaves like the eager one it replaced.
                rawset(t, fp, rec)
                return rec
            end,
        })
    end
    meta_map = meta_map or {}
    if skipped > 0 then
        logger.dbg(string.format(
            "[bookshelf perf] light_meta: skipped %d row(s) outside home", skipped))
    end
    -- Cache even an empty/partial map: callers fall back to per-book on miss,
    -- so an incomplete cache doesn't break correctness — and we avoid hammering
    -- BIM for the same failed query on every chip switch.
    _light_meta_cache[key] = {
        map = meta_map,
        -- RAW batched rows, unscoped by home prefix: buildBookMeta's batch
        -- fast path serves any book BIM knows from here (same data a live
        -- getBookInfo would return, minus the cover blob).
        rows = row_map,
        count = count,
        expires_at = now + WALK_CACHE_TTL,
    }
    logger.dbg(string.format(
        "[bookshelf perf] light_meta: MISS build=%.0fms (read=%.0f map=%.0f) cached=%d source=%s",
        (_gettime() - _t0) * 1000, (_t_load - _t0) * 1000,
        (_gettime() - _t_load) * 1000, count,
        snapshot and (fresh and "snapshot" or "stale-snapshot")
                 or (row_map and "batch" or "fallback")))
    if stale then _scheduleLightMetaRefresh() end
    return meta_map
end

-- _batchInfoFor(fp) — the RAW batched BIM row for a book: the same text
-- columns a live getBookInfo(fp, false) returns, from the one blob-free
-- SELECT (snapshot-backed) the light map is derived from. Serves
-- buildBookMeta's no-cover path so a full record build costs a table
-- lookup instead of a per-book SQLite SELECT, whose row drags the
-- compressed cover blob off disk even when no cover was asked for
-- (~20ms/record on device flash). nil on a miss (new import, BIM
-- mid-write, batch unavailable); the caller falls back to live BIM.
-- Freshness matches the light records the shelf already renders from:
-- metadata edits clear the whole cache (invalidateLightMeta).
_batchInfoFor = function(fp)
    if type(fp) ~= "string" then return nil end
    local home  = HomeDir.get() or "/"
    local depth = BookshelfSettings.read("latest_walk_depth") or 3
    local key   = (home or "/") .. ":" .. tostring(depth or 0)
    local entry = _light_meta_cache[key]
    if not entry then
        _getLightMetaCache(home, depth)
        entry = _light_meta_cache[key]
    end
    return entry and entry.rows and entry.rows[fp] or nil
end

-- Walk-time helper: prefer the cache, fall back to per-book on miss. Walk
-- consumers (getSeriesGroups MISS / _buildGroups / searchBooks) call this
-- per candidate instead of _buildBookMetaLight directly.
local function _lightMetaForFp(cache, fp)
    if cache then
        local hit = cache[fp]
        if hit then return hit end
    end
    return _buildBookMetaLight(fp)
end

-- Public light-record lookup for consumers holding only a filepath (the
-- spine shelf's stack-member stubs): one memoised map hit once the batch
-- SELECT has run, nil when the batch doesn't know the file -- the caller
-- falls back to a full build. Returns the SHARED cached record: read from
-- it, never mutate it (see _resetLightMetaProgress for why).
function Repo.lightMetaFor(filepath)
    if type(filepath) ~= "string" then return nil end
    local home  = HomeDir.get() or "/"
    local depth = BookshelfSettings.read("latest_walk_depth") or 3
    local cache = _getLightMetaCache(home, depth)
    return cache and cache[filepath] or nil
end

-- Flat list of every book filepath in the library: the same depth-capped
-- recursive walk getLatest / the series + author groups use (honours the
-- bookshelf_latest_walk_depth setting). For bulk operations that need only
-- paths, not per-book metadata. Returns a shallow copy (safe to mutate).
function Repo.getAllFilepaths()
    local home  = HomeDir.get() or "/"
    local depth = BookshelfSettings.read("latest_walk_depth") or 3
    -- cachedWalk yields candidate RECORDS ({ fp = "...", mtime = ... }), not
    -- bare paths (getLatest reads candidates[i].fp) -- pull the path strings.
    local paths = {}
    for _i, c in ipairs(cachedWalk(home, depth)) do
        if type(c) == "table" and type(c.fp) == "string" then
            paths[#paths + 1] = c.fp
        elseif type(c) == "string" then
            paths[#paths + 1] = c
        end
    end
    return paths
end

--- Filepaths of every registered source whose books count as library books
--- (the Kindle catalogue today), or {} where there is none.
---
--- getAllFilepaths is the filesystem WALK, and a .kfx is neither in
--- SUPPORTED_EXT nor under home_dir, so Kindle books are absent from it. A
--- caller that means "every book the user can see" has to add these; a caller
--- that means "the walked library" -- countByStatus, and so the Shelf size
--- module's tally -- deliberately must not, which is why this is separate
--- rather than folded into getAllFilepaths.
---
--- Catalogue cache only: no disk walk, no network.
function Repo.librarySourceFilepaths()
    local Sources = require("lib/bookshelf_sources")
    local out = {}
    for _i, id in ipairs(Sources.ids()) do
        local spec = Sources.get(id)
        if spec.library then
            for _j, b in ipairs(Sources.list(id) or {}) do
                if type(b.filepath) == "string" and b.filepath ~= "" then
                    out[#out + 1] = b.filepath
                end
            end
        end
    end
    return out
end

function Repo.getLatest(limit, offset, opts)
    local _t0 = _gettime()
    local home       = HomeDir.get() or "/"
    local depth      = BookshelfSettings.read("latest_walk_depth") or 3
    local candidates = cachedWalk(home, depth)
    -- "latest" chip is mtime-only by design (_SORT_VALID restricts it).
    -- Newest first.
    table.sort(candidates, function(a, b) return a.mtime > b.mtime end)
    offset      = offset or 0
    local total = #candidates
    local out   = {}
    local stop  = _hydrationStop(offset, limit, total, 8, "getLatest", opts and opts.light_only)
    local ScaledCoverCache
    if opts and opts.lazy_cover then
        ScaledCoverCache = require("lib/bookshelf_scaled_cover_cache")
    end
    for i = offset + 1, stop do
        local fp = candidates[i].fp
        local meta_opts
        if ScaledCoverCache and ScaledCoverCache:has(fp) then
            meta_opts = { want_cover = false }
        end
        local book = Repo.buildBookMeta(fp, meta_opts)
        if book then
            book.added_time = candidates[i].mtime
            out[#out + 1] = book
        end
    end
    logger.dbg(string.format("[bookshelf perf] getLatest: %.0fms cands=%d items=%d/%d",
        (_gettime() - _t0) * 1000, #candidates, #out, total))
    return out, total
end

-- ─── getAll / findFirstBookIn ────────────────────────────────────────────────
-- Folder-aware listing for the "All" chip. Delegates to KOReader's
-- FileChooser:genItemTableFromPath so the user's collate, reverse_collate,
-- collate_mixed and book status filter are honoured for free — no need to
-- maintain a parallel sort/filter pipeline. Output is converted into our
-- internal item shape: bare Book records for files, folder records for
-- directories. Folder records carry { kind = "folder", path, label,
-- first_book } where first_book is the first usable book found by walking
-- the directory tree (bounded depth) so the FolderStack widget has a cover
-- to display on the spine.

-- Returns the filepath (string) of the first supported book file at or
-- below `path`, depth-limited. Returns nil if no book is found.
--
-- Used by getAll's shape-builder to pick a representative cover for each
-- folder card. Only the filepath is needed at shape-build time — per-page
-- hydration loads the actual Book record with cover. Previously this
-- returned a full Book record built via _safeBuildBookMeta, meaning a
-- zstd cover decompression per subfolder during cold shape construction:
-- the dominant cost on Home for libraries with many subfolders.
-- (We previously also did two stat passes per entry — one looking for
-- files, then a second looking for directories; merged into one pass.)
function Repo.findFirstBookIn(path, max_depth)
    max_depth = max_depth or 3
    if max_depth < 0 then return nil end
    local lfs = require("libs/libkoreader-lfs")
    local ok, iter, dir_obj = pcall(lfs.dir, path)
    if not ok then return nil end
    local files, dirs = {}, {}
    local has_mimetype, has_meta_inf = false, false
    for f in iter, dir_obj do
        -- An unpacked EPUB holds chapter files, not books: see walkBooks.
        if f == "mimetype" then has_mimetype = true
        elseif f == "META-INF" then has_meta_inf = true end
        if f ~= "." and f ~= ".." and not f:match("^%.") then
            local fp = _joinPath(path, f)
            local attr = lfs.attributes(fp)
            local mode = type(attr) == "table" and attr.mode
                          or lfs.attributes(fp, "mode")
            if mode == "file" then
                if _supportedExt(f) then
                    files[#files + 1] = { name = f, fp = fp }
                end
            elseif mode == "directory" then
                dirs[#dirs + 1] = { name = f, fp = fp }
            end
        end
    end
    if has_mimetype and has_meta_inf then return nil end
    -- Files at this level take precedence over deeper subdirectories.
    table.sort(files, function(a, b) return a.name < b.name end)
    if files[1] then return files[1].fp end
    table.sort(dirs, function(a, b) return a.name < b.name end)
    for _i, e in ipairs(dirs) do
        local found = Repo.findFirstBookIn(e.fp, max_depth - 1)
        if found then return found end
    end
    return nil
end

-- folderHasBooks(path): true if `path` (recursively) contains at least one
-- supported book file. Short-circuits on first hit; memoized per-session.
-- Used by getAll to suppress empty folder cards before the user sees them.
-- Re-assignment (not `local`) so invalidateWalkCache's forward-declared
-- name at the top of the file resolves to this same upvalue.
_folderHasBooks_cache = {}

function Repo.folderHasBooks(path)
    if not path or path == "" then return false end
    if _folderHasBooks_cache[path] ~= nil then return _folderHasBooks_cache[path] end
    local ok_lfs, lfs = pcall(require, "libs/libkoreader-lfs")
    if not ok_lfs or not lfs then
        _folderHasBooks_cache[path] = true  -- assume non-empty on lfs failure
        return true
    end
    local stack = { path }
    while #stack > 0 do
        local dir = table.remove(stack)
        local ok_dir, iter, dir_obj = pcall(lfs.dir, dir)
        if ok_dir and type(iter) == "function" then
            -- The whole listing first: an unpacked EPUB (a "mimetype" file
            -- beside a META-INF folder) holds chapter files that pass the book
            -- test but are not books, and that is only known at the end of
            -- the listing. Same rule as walkBooks.
            local names = {}
            local has_mimetype, has_meta_inf = false, false
            for entry in iter, dir_obj do
                if entry == "mimetype" then has_mimetype = true
                elseif entry == "META-INF" then has_meta_inf = true end
                if entry ~= "." and entry ~= ".." and entry:sub(1, 1) ~= "." then
                    names[#names + 1] = entry
                end
            end
            if not (has_mimetype and has_meta_inf) then
                for _i, entry in ipairs(names) do
                    local fp   = _joinPath(dir, entry)
                    local attr = lfs.attributes(fp)
                    if attr then
                        if attr.mode == "file" then
                            if _supportedExt(entry) then
                                _folderHasBooks_cache[path] = true
                                return true
                            end
                        elseif attr.mode == "directory" and entry ~= ".sdr"
                                and not SYSTEM_DIR_NAMES[entry] then
                            stack[#stack + 1] = fp
                        end
                    end
                end
            end
        end
    end
    _folderHasBooks_cache[path] = false
    return false
end

-- folderCoverPaths(path, sort_priority, limit, opts) -> filepaths
--
-- The books a folder TILE should show, in the order the folder itself would
-- show them: the cover is the first book you meet on opening the folder, and
-- a collage is the first four (maintainer, on #409).
--
-- It was the first path the library walk happened to return, which is disk
-- order and spans every depth under the folder, so a book buried three levels
-- down could front a folder whose first page shows something else entirely.
-- The reporter read that as "sorted by filename" because disk order usually
-- looks like it.
--
-- Two rules, in this order:
--   * a book sitting IN the folder beats one in a subfolder, because that is
--     what opening the folder puts in front of you;
--   * within each of those, the chip's own sort decides, so the tile and the
--     folder agree about what comes first.
-- Deeper books are still the fallback: a folder holding nothing but
-- subfolders has to show something, and before this it showed one of those.
--
-- Cost is per folder on the VISIBLE page, not per folder in the chip: the
-- immediate children are sorted (a handful, normally) and the deeper list is
-- only touched when the immediate one cannot fill the limit.
--
-- opts.match(fp) -> boolean filters candidates, so a filtered chip fronts its
-- folders with a book that actually matches the filter, as it did before.
-- opts.light_cache is the shared light-metadata map when the caller has one.
function Repo.folderCoverPaths(path, sort_priority, limit, opts)
    limit = limit or 4
    if not path or path == "" or limit <= 0 then return {} end
    opts = opts or {}
    -- Memo key: the folder, the sort that produced the order, and the limit.
    -- A FILTERED call is never memoised -- opts.match is a compiled closure,
    -- so nothing about it can go in a key, and serving a filtered tile from an
    -- unfiltered order would front a folder with a book the filter excludes.
    -- The `s:<key>:` segments match READ_STATE_SORT_TOKENS on purpose, so
    -- invalidateReadStateCache drops exactly the orders that a book being read
    -- can reorder and leaves title/filename ones standing.
    local ckey
    if not opts.match then
        local parts = {}
        for _i = 1, #(sort_priority or {}) do
            local lv = sort_priority[_i]
            parts[#parts + 1] = "s:" .. (lv.key or "")
                .. ":" .. (lv.reverse and "r" or "f")
        end
        ckey = path .. "\0" .. table.concat(parts, ";") .. ";l:" .. limit
        local hit = _folder_cover_cache[ckey]
        if hit then
            local out = {}
            for _i = 1, #hit do out[_i] = hit[_i] end
            return out
        end
    end
    local all = Repo.getFolderBookPaths(path) or {}
    if #all == 0 then return {} end

    local prefix = path
    if prefix:sub(-1) ~= "/" then prefix = prefix .. "/" end
    local match = opts.match
    local here, below = {}, {}
    for i = 1, #all do
        local fp = all[i]
        if not match or match(fp) then
            local rest = fp:sub(#prefix + 1)
            if rest:find("/", 1, true) then below[#below + 1] = fp
            else here[#here + 1] = fp end
        end
    end

    -- The sort needs a record per candidate, and building one per book is a
    -- BookInfoManager lookup each. opts.light_cache_fn hands over the shared
    -- batched light-metadata map instead -- one build for the whole library,
    -- already warm on the paths that matter (the shelf's own fetch builds it),
    -- and a table lookup per book after that. Resolved at most once per call
    -- and only for a folder big enough to earn it: a page of two-book folders
    -- must not be what triggers a library-wide batch.
    local LIGHT_CACHE_WORTH_IT = 8
    local _light, _light_asked
    local function lightCache()
        if opts.light_cache then return opts.light_cache end
        if not _light_asked then
            _light_asked = true
            if opts.light_cache_fn then _light = opts.light_cache_fn() end
        end
        return _light
    end
    local function record(fp, cache)
        local rec = cache and _lightMetaForFp(cache, fp)
                    or _buildBookMetaLight(fp)
        return rec or { filepath = fp }
    end
    local function ordered(list)
        if #list < 2 or not sort_priority or #sort_priority == 0 then return list end
        local cache = (#list >= LIGHT_CACHE_WORTH_IT) and lightCache() or opts.light_cache
        local recs = {}
        for i = 1, #list do recs[i] = record(list[i], cache) end
        table.sort(recs, SortEngine.chainedComparator(sort_priority))
        local out = {}
        for i = 1, #recs do out[i] = recs[i].filepath end
        return out
    end

    local out = {}
    for _i, fp in ipairs(ordered(here)) do
        if #out >= limit then break end
        out[#out + 1] = fp
    end
    if #out < limit then
        for _i, fp in ipairs(ordered(below)) do
            if #out >= limit then break end
            out[#out + 1] = fp
        end
    end
    if ckey then
        local keep = {}
        for _i = 1, #out do keep[_i] = out[_i] end
        _capInsert(_folder_cover_cache, _folder_cover_cache_order, ckey, keep)
    end
    return out
end

-- getFolderBookPaths(path): list of every book filepath under `path` at
-- any depth (subject to the latest_walk_depth setting that bounds the
-- underlying cachedWalk). Used by selection-mode plumbing — both the
-- long-press dialog's add/remove actions and the per-paint "is this
-- folder card partially selected?" check.
--
-- Rides the existing cachedWalk: first call per folder filters the
-- cached global walk-list by path prefix and memoises. Subsequent calls
-- are an O(1) map lookup until the walk cache invalidates (which clears
-- this cache in lockstep), at which point the next call re-filters
-- against the fresh walk.
--
-- Returns a fresh array each call so callers can sort / mutate safely.
function Repo.getFolderBookPaths(path)
    if not path or path == "" then return {} end
    local cached = _folder_book_paths_cache[path]
    if cached then
        local out = {}
        for i = 1, #cached.paths do out[i] = cached.paths[i] end
        return out
    end
    local home  = HomeDir.get() or "/"
    local depth = BookshelfSettings.read("latest_walk_depth") or 3
    local cands = cachedWalk(home, depth)
    -- Prefix match: a book at `<path>/...` is "under" path. Append "/"
    -- so we don't match sibling folders that share a name prefix (e.g.
    -- "/Foo" must not match "/FooBar/book.epub"). Path itself may or
    -- may not end with "/" — normalise both sides.
    local prefix = path
    if prefix:sub(-1) ~= "/" then prefix = prefix .. "/" end
    local paths = {}
    for i = 1, #cands do
        local fp = cands[i].fp
        if fp and fp:sub(1, #prefix) == prefix then
            paths[#paths + 1] = fp
        end
    end
    -- Deep-nesting fallback (#202): the home-rooted walk is bounded by
    -- latest_walk_depth, so a folder whose books all sit deeper than that
    -- prefix-matches nothing -- even though drilling into it shows books
    -- (browsing scans one level per drill). When the prefix filter comes
    -- up empty, walk the asked-about folder ITSELF with the same depth
    -- budget: cost scales with that subtree only, each drill level
    -- re-anchors the budget (matching what browsing reveals), and a truly
    -- empty folder confirms cheaply. Memoised below either way; the cache
    -- clears in lockstep with the walk cache.
    if #paths == 0 then
        local found = {}
        walkBooks(path, depth, found)
        for i = 1, #found do paths[#paths + 1] = found[i].fp end
    end
    _folder_book_paths_cache[path] = { paths = paths }
    -- Return a copy so caller mutations don't poison the cache.
    local out = {}
    for i = 1, #paths do out[i] = paths[i] end
    return out
end

-- getAll(path, limit, offset, sort_priority) → (items, total)
-- limit/offset let callers fetch a single page slice without hydrating the
-- full list. total is always the full item count (from cache or fresh scan)
-- so callers can compute total_pages without a second trip.
--
-- sort_priority (optional) is an array of { key, reverse } levels handed in
-- by callers that want their chip's sort to drive the order -- e.g. a
-- Specific-folder chip with sort_priority = {filename, series_index, title}.
-- When nil/empty, falls back to the "all" tab's stored sort_priority for
-- backward compatibility (Home folders unchanged). The legacy reverse +
-- mixed settings apply only on the fallback path; when sort_priority is
-- provided, each level carries its own direction and reverse is redundant.
-- _filterAllShapes(shapes, filter, light_cache): produce a filter-aware
-- shape list for getAll. Books are kept iff they pass the full compiled
-- filter; folders are kept iff any book under them matches, with
-- first_book_fp swapped to the first matching book under that path.
-- Returns {shapes, total}. Returns the input shapes unchanged when
-- filter is inactive — every call site can hand its full shape list to
-- this helper unconditionally.
-- light_cache (optional): fp -> light-record map shared with the
-- caller's prefetch pass; used to avoid re-reading BIM for each fp.
-- Falls back to _buildBookMetaLight(fp) when absent.
local function _filterAllShapes(shapes, filter, light_cache)
    if not _filterIsActive(filter) then return shapes, #shapes end
    local compiled = Filter.compile(filter, Repo.filterOpts())
    -- Build a light record for a filepath: shared cache when available,
    -- per-book fallback otherwise. Always returns a table (bare filepath
    -- record on total miss) so _recordMatches has something to test.
    local function _recordForFp(fp)
        local rec = light_cache and _lightMetaForFp(light_cache, fp) or _buildBookMetaLight(fp)
        return rec or { filepath = fp }
    end
    local out = {}
    for _i, shape in ipairs(shapes) do
        if shape.kind == "book" then
            if _recordMatches(_recordForFp(shape.fp), compiled) then
                out[#out + 1] = shape
            end
        elseif shape.kind == "folder" then
            local fpaths = Repo.getFolderBookPaths(shape.path) or {}
            local first_fp
            for i = 1, #fpaths do
                if _recordMatches(_recordForFp(fpaths[i]), compiled) then
                    first_fp = fpaths[i]
                    break
                end
            end
            if first_fp then
                -- Annotated copy: replace first_book_fp with the
                -- filter-aware leader so the folder card cover shows a
                -- book that actually matches the filter. Other fields
                -- pass through unchanged. The original shape stays
                -- intact in the cache.
                out[#out + 1] = {
                    kind          = "folder",
                    path          = shape.path,
                    label         = shape.label,
                    first_book_fp = first_fp,
                }
            end
        end
    end
    return out, #out
end

-- Repo.getAll(path, limit, offset, sort_priority, filter, opts)
--
-- opts.lazy_cover — when true, the HIT hydration path probes
-- ScaledCoverCache by filepath for each book in the slice and passes
-- want_cover=false to buildBookMeta for books whose cover is already
-- cached. Avoids the wasted BIM zstd decompress on warm-cache
-- pagination. Ignored on the MISS path (full library walk) because
-- the cache hasn't seen those shapes yet.
-- allHasBooks(path) -> true | false | nil
-- Whether the all/folder set at `path` (the library root when nil) holds a
-- BOOK anywhere in it, read off the shape list getAll cached when it last
-- served that path; nil when it never has. The shelf asks this after a
-- windowed fetch whose page showed folders only, so the label strip is
-- decided for the whole set rather than for the page (see
-- BookshelfWidget:_noteGridLabels). The cache is keyed on path AND sort, but
-- every sort order's entry holds the same shapes, so the first one will do.
function Repo.allHasBooks(path)
    path = path or _resolveLibraryRoot()
    if not path then return nil end
    local prefix = path .. "\0"
    for key, entry in pairs(_all_cache) do
        if key:sub(1, #prefix) == prefix and type(entry.shapes) == "table" then
            for _i, shape in ipairs(entry.shapes) do
                if shape.kind == "book" then return true end
            end
            return false
        end
    end
    return nil
end

function Repo.getAll(path, limit, offset, sort_priority, filter, opts)
    local _t0 = _gettime()
    offset = offset or 0
    -- Explicit `path` (folder drilldown) wins; fallback resolves the
    -- user's library root and bails when it's unconfigured rather than
    -- walking "/".
    if not path then
        path = _resolveLibraryRoot()
        if not path then
            logger.warn("[bookshelf] getAll: home_dir not configured; refusing to walk")
            return {}, 0
        end
    end
    -- Effective priority: caller's wins; otherwise the "all" tab settings.
    local has_caller_priority = sort_priority and #sort_priority > 0
    local priority = has_caller_priority and sort_priority
                                          or Repo.getSortPriority("all")
    -- Legacy single-key view of the priority -- kept for the existing
    -- "needs" prefetch logic and the cache-key path; the actual sort goes
    -- through SortEngine.chainedComparator(priority) below.
    local sort_key = (priority and priority[1] and priority[1].key)
                  or Repo.getSortKey("all")
    -- The tile books for one folder, ordered as that folder would show them
    -- (#409). Built here so it captures this fetch's own sort and filter, and
    -- called only from the page-slice loops below, so the work is per folder
    -- ON SCREEN rather than per folder in the chip. The filter predicate is
    -- compiled at most once per fetch, and only when one is active: a
    -- filtered chip must front its folders with a book that matches, which is
    -- what the shape-level leader did before.
    local _cover_match_built, _cover_match
    -- Lazy, once per fetch: the batched light-metadata map the folder ordering
    -- can sort from. Not built up front -- most pages never need it, and the
    -- shelf's own paths usually have it cached already (light_meta: HIT).
    local _cover_light, _cover_light_asked
    local function _coverLightCache()
        if not _cover_light_asked then
            _cover_light_asked = true
            local home_cl  = HomeDir.get() or "/"
            local depth_cl = BookshelfSettings.read("latest_walk_depth") or 3
            local ok_cl, map = pcall(_getLightMetaCache, home_cl, depth_cl)
            _cover_light = ok_cl and map or nil
        end
        return _cover_light
    end
    local function _folderCoverFps(folder_path)
        if not _cover_match_built then
            _cover_match_built = true
            if Filter.isActive(filter) then
                local compiled = Filter.compile(filter, Repo.filterOpts())
                _cover_match = function(fp)
                    local rec = _buildBookMetaLight(fp) or { filepath = fp }
                    return _recordMatches(rec, compiled)
                end
            end
        end
        local ok, fps = pcall(Repo.folderCoverPaths, folder_path, priority, 4,
                              { match = _cover_match,
                                light_cache_fn = _coverLightCache })
        return (ok and fps) or {}
    end
    -- reverse only applies on the fallback path; chip sort_priority
    -- encodes per-level reverse internally. `mixed` (folders interleaved
    -- with files, instead of partitioned folders-first) follows
    -- KOReader's global "Folders and files mixed" setting and applies
    -- regardless of chip priority — the user's library-wide preference
    -- should win over a per-chip partition choice.
    local reverse  = (not has_caller_priority) and BookshelfSettings.read("sort_all_reverse") == true
    local mixed    = G_reader_settings and G_reader_settings:isTrue("collate_mixed") or false
    -- Cache key includes a stable serialization of the priority so chips
    -- with different sort_priority don't collide on cached shapes.
    local prio_parts = {}
    if priority then
        for _i, lv in ipairs(priority) do
            prio_parts[#prio_parts + 1] = (lv.key or "") .. (lv.reverse and "R" or "")
        end
    end
    local cache_key = table.concat({
        path, table.concat(prio_parts, ","),
        reverse and "R" or "", mixed and "M" or "",
        -- How the keys themselves are derived (pinyin, leading articles).
        SortEngine.keySignature(),
    }, "\0")
    local now   = os.time()
    local entry = _all_cache[cache_key]
    if entry then
        -- HIT: hydrate only the requested slice — skips BIM lookups for
        -- every item outside the current page. When filter is active,
        -- collapse the shape list to filter-passing entries first so
        -- the slice maths against the visible total.
        local home_lc  = HomeDir.get() or "/"
        local depth_lc = BookshelfSettings.read("latest_walk_depth") or 3
        local hit_light_cache = Filter.isActive(filter) and _getLightMetaCache(home_lc, depth_lc) or nil
        local shapes_for_slice, total = _filterAllShapes(entry.shapes, filter, hit_light_cache)
        local out   = {}
        local light = (opts and opts.light_only) or Repo.spine_light
        local stop  = _hydrationStop(offset, limit, total, total, "getAll", light)
        -- Light path, two callers: the letter-jump (opts.light_only, never
        -- rendered) and the SPINE shelf (Repo.spine_light -- it renders
        -- colour + text, never a cover; looks sample lazily by filepath).
        -- Book shapes only carry .fp, so a batched light-meta lookup
        -- supplies the display/sort fields (title / author / series);
        -- folder shapes already carry their label, plus a LIGHT first_book
        -- so a wrapper folder can still stand as its book on the spine
        -- shelf. Before this branch honoured spine_light, an all/folder
        -- chip shown as spines paid a full _safeBuildBookMeta per record
        -- AND the 512 hydrate clamp broke its pagination.
        if light then
            local light_cache = hit_light_cache or _getLightMetaCache(home_lc, depth_lc)
            for i = offset + 1, stop do
                local shape = shapes_for_slice[i]
                if shape.kind == "folder" then
                    out[#out + 1] = { kind = "folder", path = shape.path,
                                      label = shape.label, name = shape.label,
                                      first_book = shape.first_book_fp
                                          and _lightMetaForFp(light_cache,
                                                              shape.first_book_fp)
                                          or nil }
                else
                    local b = _lightMetaForFp(light_cache, shape.fp)
                    out[#out + 1] = b or { fp = shape.fp, filepath = shape.fp }
                end
            end
            return out, total
        end
        -- Lazy-cover probe: per-book ScaledCoverCache check, skip the
        -- BIM zstd decode when a cover is already cached for the
        -- filepath. SpineWidget reads from the cache directly.
        local ScaledCoverCache
        if opts and opts.lazy_cover then
            ScaledCoverCache = require("lib/bookshelf_scaled_cover_cache")
        end
        for i = offset + 1, stop do
            local shape = shapes_for_slice[i]
            if shape.kind == "folder" then
                -- The tile's books, in the order the folder would show them
                -- (Repo.folderCoverPaths): the lead one is the cover, and a
                -- collage takes the set. shape.first_book_fp -- disk order,
                -- any depth -- is the fallback for a folder that yields none.
                local cover_fps = _folderCoverFps(shape.path)
                local lead = cover_fps[1] or shape.first_book_fp
                local fb_opts
                if ScaledCoverCache and lead and ScaledCoverCache:has(lead) then
                    fb_opts = { want_cover = false }
                end
                local fb = lead and _safeBuildBookMeta(lead, fb_opts)
                out[#out + 1] = {
                    kind       = "folder",
                    path       = shape.path,
                    label      = shape.label,
                    first_book = fb,
                    cover_fps  = cover_fps,
                }
            else
                local meta_opts
                if ScaledCoverCache and ScaledCoverCache:has(shape.fp) then
                    meta_opts = { want_cover = false }
                end
                local b = _safeBuildBookMeta(shape.fp, meta_opts)
                if b then out[#out + 1] = b end
            end
        end
        logger.dbg(string.format("[bookshelf perf] getAll: HIT hydrate=%.0fms items=%d/%d ttl_left=%ds",
            (_gettime() - _t0) * 1000, #out, total, entry.expires_at - now))
        return out, total
    end

    -- MISS: list with lfs directly. FileChooser:genItemTableFromPath called as
    -- a class method (no instance, self.ui==nil) silently fails for any collate
    -- whose item_func needs ui (title, authors, series, keywords), and also
    -- throws on Kindle for the access collate where attr.access is nil.
    local ok_lfs, lfs = pcall(require, "libs/libkoreader-lfs")
    if not ok_lfs or not lfs or not lfs.dir then
        logger.dbg("[bookshelf perf] getAll: MISS no lfs")
        return {}, 0
    end
    local ok_dir, iter, dir_obj = pcall(lfs.dir, path)
    if not ok_dir or type(iter) ~= "function" then
        logger.dbg("[bookshelf perf] getAll: MISS lfs.dir failed " .. tostring(path))
        return {}, 0
    end

    -- Gather entries with full attributes in one lfs call per entry.
    -- SYSTEM_DIR_NAMES filter keeps a `home_dir = "/"` setup off /proc,
    -- /sys, /dev so the user-visible folder list and per-folder
    -- findFirstBookIn calls stay sane.
    local entries = {}
    for entry in iter, dir_obj do
        if entry ~= "." and entry ~= ".." and entry:sub(1, 1) ~= "."
                and not SYSTEM_DIR_NAMES[entry] then
            local fp   = _joinPath(path, entry)
            local attr = lfs.attributes(fp)
            if attr and entry:sub(-4) ~= ".sdr" then
                entries[#entries + 1] = { name = entry, fp = fp, attr = attr }
            end
        end
    end

    -- Pre-fetch data required by the comparator before sorting so each
    -- comparison stays O(1). Derive needs from the effective priority
    -- (caller's or the "all" fallback, set up at the top of getAll) so
    -- multi-key sorts (e.g. author_surname, series_index) get the right
    -- metadata swept in.
    local needs = {}
    for _i, level in ipairs(priority) do
        local k = level.key
        if k == "title" or k == "filename" then needs.title   = true end
        if k == "author_name" or k == "author_surname" then needs.authors = true end
        if k == "series_name" or k == "series_index"
                or k == "series_combined"              then needs.series  = true end
        if k == "series_or_title" then needs.series = true; needs.title = true end
        if k == "percent_read" then needs.percent  = true end
        if k == "read_status" or k == "read_status_active" then needs.status = true end
        if k == "last_opened" or k == "added_or_opened" then needs.last_opened = true end
        -- rating / page_count are NOT on the light shelf record (rating is
        -- never set by buildBookMeta; page_count is nil for EPUBs), so a sort
        -- by either is a no-op unless we hydrate them from the sidecar here.
        if k == "rating"       then needs.rating     = true end
        if k == "page_count"   then needs.page_count = true end
        -- Folder cards carry no book_count until we count their contents
        -- (issue 90: "sort folders by number of files").
        if k == "book_count"   then needs.book_count = true end
    end
    -- Preserve legacy behaviour: the percent_natural sort_key needed titles
    -- in the old code; map it forward so a stale settings file still works.
    if sort_key == "percent_natural" then needs.percent = true end

    if needs.title or needs.authors or needs.series then
        local _pf_t0 = _gettime and _gettime() or 0
        -- Try the shared light-meta cache first: one batch SELECT covers
        -- all of home_dir's recursive walk, so metadata for entries within
        -- the cached range come back as O(1) lookups. Falls back to the
        -- per-book getBookInfo path for entries outside the cache (e.g.
        -- a folder drilldown into a path beyond bookshelf_latest_walk_depth).
        local home_dir = HomeDir.get() or "/"
        local depth    = BookshelfSettings.read("latest_walk_depth") or 3
        local light_cache = _getLightMetaCache(home_dir, depth)
        local _pf_t_cache = _gettime and _gettime() or 0
        local _pf_hits, _pf_misses = 0, 0
        local bim = getBookInfoMgr()
        for _i, e in ipairs(entries) do
            if e.attr and e.attr.mode == "file" then
                local info
                if light_cache then
                    local lc = light_cache[e.fp]
                    if lc then
                        -- Check whether the cached entry has everything we need;
                        -- if authors or series are required but absent in the
                        -- light-meta record, fall through to a fresh BIM call.
                        if (not needs.authors or lc.authors ~= nil)
                                and (not needs.series or lc.series ~= nil) then
                            info = lc
                            _pf_hits = _pf_hits + 1
                        end
                    end
                end
                if not info then
                    _pf_misses = _pf_misses + 1
                    -- pcall: a single corrupt BIM row must not abort the
                    -- whole prefetch sweep -- fall back to filename for the
                    -- failing entry and keep going. get_cover=false skips
                    -- the zstd decompression + Blitbuffer allocation.
                    info = _bimGetBookInfo(bim, e.fp, false) or info
                end
                if info then
                    if needs.title and not e.doc_props then
                        e.doc_props = { display_title = info.title or e.name }
                    end
                    if needs.authors then
                        -- Light-cache records store authors as a table (post
                        -- splitAuthors) while direct BIM rows give the raw
                        -- string. Normalize so the surname parser always
                        -- sees a string. Join tables with "; " because
                        -- AuthorName.surnameOf's pickFirstAuthor splits on
                        -- ";" to pick the leading author.
                        local raw = info.authors
                        if type(raw) == "table" then
                            e.authors = table.concat(raw, "; ")
                        elseif type(raw) == "string" then
                            e.authors = raw
                        end
                    end
                    if needs.series then
                        -- Same shape mismatch between sources: light cache
                        -- uses series_name / series_num; raw BIM uses
                        -- series / series_index. Read either.
                        e.series       = info.series_name or info.series
                        e.series_index = tonumber(info.series_num or info.series_index)
                    end
                else
                    if needs.title and not e.doc_props then
                        e.doc_props = { display_title = e.name }
                    end
                end
            else
                if needs.title and not e.doc_props then
                    e.doc_props = { display_title = e.name }
                end
            end
        end
        local _pf_t1 = _gettime and _gettime() or 0
        logger.dbg(string.format(
            "[bookshelf perf] getAll prefetch: total=%.0fms (cache_load=%.0fms loop=%.0fms) entries=%d hits=%d misses=%d needs={title=%s,authors=%s,series=%s}",
            (_pf_t1 - _pf_t0) * 1000,
            (_pf_t_cache - _pf_t0) * 1000,
            (_pf_t1 - _pf_t_cache) * 1000,
            #entries, _pf_hits, _pf_misses,
            tostring(needs.title), tostring(needs.authors), tostring(needs.series)))
    end
    if needs.last_opened then
        local ReadHistory = require("readhistory")
        local rh = {}
        for _i, item in ipairs(ReadHistory.hist) do
            rh[item.file] = item.time
        end
        for _i, e in ipairs(entries) do
            e._last_read = rh[e.fp] or 0
        end
        -- Folder rows inherit the max read-time from any book somewhere
        -- below them, so 'most recently opened' sorts a folder near its
        -- contents instead of pinning every folder to the never-opened
        -- tier. We could compute this by statting every .sdr underneath,
        -- but ReadHistory already knows which books were opened recently
        -- and where they live — a much smaller list to walk.
        --
        -- For each ReadHistory entry, walk its parent chain upward and
        -- bump the first folder in our current listing that's an
        -- ancestor of that file. Bounded by ReadHistory.hist size (~50)
        -- times average path depth.
        local folder_by_fp = {}
        for _i, e in ipairs(entries) do
            if e.attr and e.attr.mode == "directory" then
                folder_by_fp[e.fp] = e
            end
        end
        for _i, item in ipairs(ReadHistory.hist) do
            local fp, t = item.file, item.time
            if fp and t then
                local parent = fp:match("^(.*)/[^/]+$")
                while parent and parent ~= "" do
                    local folder = folder_by_fp[parent]
                    if folder then
                        if (folder._last_read or 0) < t then
                            folder._last_read = t
                        end
                        break
                    end
                    parent = parent:match("^(.*)/[^/]+$")
                end
            end
        end
    end
    if needs.percent or needs.status or needs.rating or needs.page_count then
        -- Route through Repo.readProgress so steady-state re-runs of this
        -- prefetch (cache TTL expired, but progress cache still warm) skip
        -- the per-file DocSettings:open() cost. readProgress also handles
        -- the pcall guard for corrupt .sdr sidecars -- a nil _pct sorts
        -- as "never opened", matching the previous behaviour.
        --
        -- summary.status is read so percent_natural can put user-marked-
        -- complete books in the finished tier even when percent_finished
        -- < 1 (e.g. user marked complete at 99% read). Without this,
        -- finished books would sort AHEAD of in-progress books because the
        -- comparator only looked at percent (issue #17).
        --
        -- rating / page_count: set on the record (the comparator reads
        -- a.rating / a.page_count, no underscore) so a sort by either
        -- actually reorders. Only written when that key is in the priority.
        for _i, e in ipairs(entries) do
            if e.attr and e.attr.mode == "file" then
                local pct, status, rating, page_count = Repo.readProgress(e.fp)
                e._pct    = pct
                e._status = status
                if needs.rating     then e.rating     = Repo.effectiveRating(e.fp, rating) end
                if needs.page_count then e.page_count = page_count end
            end
        end
    end

    if needs.book_count then
        -- Folder cards on the home/folder view have no book_count of their
        -- own; count their contents so "sort by Book count" orders folders
        -- by how many books they hold (issue 90).
        --
        -- The obvious implementation -- getFolderBookPaths(e.fp) per folder
        -- -- is O(folders x files): each call linear-scans the whole cached
        -- walk-list with a fresh substring alloc per candidate. On a large
        -- library (#113: ~hundreds of folders x ~1.6k files on a 1GHz Kobo)
        -- that cost ~5.5s and froze the launch. Instead, walk every book's
        -- parent chain upward ONCE and bump the first listed folder that's
        -- an ancestor -- O(files x depth), the same attribution shape as the
        -- last_opened block above. The count is identical to
        -- getFolderBookPaths' prefix match (entries are siblings, so a book
        -- under e.fp hits e.fp as its first listed ancestor), so the sort
        -- value still matches the badge the card shows. Plain book entries
        -- have no folder-count concept: they're left nil and the comparator
        -- (a.book_count or #a.filepaths) sorts them to the end of their
        -- partition.
        local folder_by_fp = {}
        for _i, e in ipairs(entries) do
            if e.attr and e.attr.mode == "directory" then
                e.book_count = 0
                folder_by_fp[e.fp] = e
            end
        end
        local home  = HomeDir.get() or "/"
        local depth = BookshelfSettings.read("latest_walk_depth") or 3
        local cands = cachedWalk(home, depth)
        for i = 1, #cands do
            local fp = cands[i].fp
            local parent = fp and fp:match("^(.*)/[^/]+$")
            while parent and parent ~= "" do
                local folder = folder_by_fp[parent]
                if folder then
                    folder.book_count = folder.book_count + 1
                    break
                end
                parent = parent:match("^(.*)/[^/]+$")
            end
        end
    end

    -- Sort with the effective priority. SortEngine handles per-level
    -- reverse internally, so the legacy whole-list reverse only fires on
    -- the fallback path (no caller-supplied priority).
    table.sort(entries, SortEngine.chainedComparator(priority))
    if reverse then
        local n = #entries
        for i = 1, math.floor(n / 2) do
            entries[i], entries[n - i + 1] = entries[n - i + 1], entries[i]
        end
    end

    -- MISS: build the full list, cache all shapes, return just the slice.
    -- When mixed=false, partition so all folders precede all files (each
    -- partition keeps its sort order from the entries pass).
    local ordered_entries = entries
    if not mixed then
        local folders, files = {}, {}
        for _i, e in ipairs(entries) do
            if e.attr.mode == "directory" then folders[#folders + 1] = e
            elseif e.attr.mode == "file" then  files[#files + 1] = e
            end
        end
        ordered_entries = {}
        for _i, e in ipairs(folders) do ordered_entries[#ordered_entries + 1] = e end
        for _i, e in ipairs(files)   do ordered_entries[#ordered_entries + 1] = e end
    end

    -- Build shapes only — no BIM lookups here. Skipping buildBookMeta for
    -- every book in the library is the key perf win: a 200-book library was
    -- doing 200 SQLite round-trips just to build the sort cache. Now only the
    -- current page slice (PAGE_SIZE items) triggers BIM lookups, via the
    -- hydration pass below (same code path as the HIT branch).
    local shapes = {}
    for _i, e in ipairs(ordered_entries) do
        if e.attr.mode == "file" then
            if _supportedExt(e.name) then
                shapes[#shapes + 1] = { kind = "book", fp = e.fp }
            end
        elseif e.attr.mode == "directory" then
            -- Omit folders that contain no supported book files at any depth.
            -- One walk answers both questions in the common case: finding the
            -- folder's representative cover also proves it's non-empty, so
            -- seed folderHasBooks' memo from it (later callers -- selection
            -- mode, repeat builds -- then hit the memo). Only when no book
            -- sits within findFirstBookIn's depth bound do we pay the
            -- second, unbounded folderHasBooks walk to decide whether the
            -- folder is truly empty; books deeper than the bound keep their
            -- folder card, just without a cover (same as before).
            local first_fp = Repo.findFirstBookIn(e.fp, 3)
            if first_fp then
                _folderHasBooks_cache[e.fp] = true
            end
            if first_fp or Repo.folderHasBooks(e.fp) then
                -- findFirstBookIn returns just the filepath; per-page
                -- hydration below builds the actual Book record with cover.
                shapes[#shapes + 1] = {
                    kind          = "folder",
                    path          = e.fp,
                    label         = _flipTrailingArticle(e.name),
                    first_book_fp = first_fp,
                }
            end
        end
    end
    _capInsert(_all_cache, _all_cache_order, cache_key,
               { shapes = shapes, expires_at = now + WALK_CACHE_TTL })
    -- Hydrate the requested page slice exactly as the HIT path does.
    -- Filter-aware: collapse to visible shapes first when active.
    local miss_lc_home  = HomeDir.get() or "/"
    local miss_lc_depth = BookshelfSettings.read("latest_walk_depth") or 3
    local miss_light_cache = Filter.isActive(filter) and _getLightMetaCache(miss_lc_home, miss_lc_depth) or nil
    local shapes_for_slice, total = _filterAllShapes(shapes, filter, miss_light_cache)
    local out  = {}
    local miss_light = (opts and opts.light_only) or Repo.spine_light
    local stop = _hydrationStop(offset, limit, total, total, "getAll", miss_light)
    -- Light path, same as the HIT branch above (letter-jump AND the spine
    -- shelf). It has to be here too: a light caller passes limit = 10000
    -- and _hydrationStop deliberately lifts the MAX_HYDRATE ceiling for it,
    -- so falling through to the full build below would decode a cover
    -- BlitBuffer for every book in the folder and free none of them -- the
    -- OOM shape light_only exists to avoid, reached whenever the walk cache
    -- is cold for this path (first visit, or the TTL lapsed).
    if miss_light then
        local light_cache = miss_light_cache
                            or _getLightMetaCache(miss_lc_home, miss_lc_depth)
        for i = offset + 1, stop do
            local shape = shapes_for_slice[i]
            if shape.kind == "folder" then
                out[#out + 1] = { kind = "folder", path = shape.path,
                                  label = shape.label, name = shape.label,
                                  first_book = shape.first_book_fp
                                      and _lightMetaForFp(light_cache,
                                                          shape.first_book_fp)
                                      or nil }
            else
                local b = _lightMetaForFp(light_cache, shape.fp)
                out[#out + 1] = b or { fp = shape.fp, filepath = shape.fp }
            end
        end
        logger.dbg(string.format(
            "[bookshelf perf] getAll: MISS light=%.0fms items=%d/%d",
            (_gettime() - _t0) * 1000, #out, total))
        return out, total
    end
    for i = offset + 1, stop do
        local shape = shapes_for_slice[i]
        if shape.kind == "folder" then
            -- Same ordering as the slice above; see _folderCoverFps.
            local cover_fps = _folderCoverFps(shape.path)
            local lead = cover_fps[1] or shape.first_book_fp
            local fb = lead and _safeBuildBookMeta(lead)
            out[#out + 1] = {
                kind       = "folder",
                path       = shape.path,
                label      = shape.label,
                first_book = fb,
                cover_fps  = cover_fps,
            }
        else
            local b = _safeBuildBookMeta(shape.fp)
            if b then out[#out + 1] = b end
        end
    end
    logger.dbg(string.format("[bookshelf perf] getAll: MISS build=%.0fms items=%d/%d sort=%s rev=%s mixed=%s",
        (_gettime() - _t0) * 1000, #out, total, sort_key,
        tostring(reverse), tostring(mixed)))
    return out, total
end

-- ─── getFavorites ────────────────────────────────────────────────────────────
-- Returns up to `limit` Book records from ReadCollection favorites collection,
-- sorted by access time descending (most recently accessed first).

function Repo.getFavorites(limit, offset, opts)
    local rc    = getCollections()
    local items = {}
    for _file, item in pairs(rc.coll and rc.coll.favorites or {}) do
        items[#items + 1] = item
    end
    local key = Repo.getSortKey("favorites")
    if key == "title" then
        -- Title-sort prefetch, cheapest source first: the light-meta
        -- batch cache (one library-wide SQLite SELECT, usually already
        -- warm from the group chips) covers favourites under home_dir;
        -- favourites outside the walk fall back per-file inside
        -- _lightMetaForFp, which still skips covers. Replaces the old
        -- per-favourite BIM row read on every fetch. When CoverBrowser
        -- is disabled (issue #49) records come back nil and every title
        -- falls back to the filename basename, so the sort still runs
        -- deterministically rather than nil-derefing.
        local home  = HomeDir.get() or "/"
        local depth = BookshelfSettings.read("latest_walk_depth") or 3
        local light_cache = _getLightMetaCache(home, depth)
        local titles = {}
        for _i, item in ipairs(items) do
            local fp  = item.file
            local rec = _lightMetaForFp(light_cache, fp)
            local title = rec and rec.title
            titles[fp] = (title or (fp and fp:match("([^/]+)$")) or ""):lower()
        end
        table.sort(items, function(a, b) return titles[a.file] < titles[b.file] end)
    elseif key == "recently_read" then
        -- ReadHistory time per filepath; fall back to attr.access (collection
        -- access time) so unread favourites still sort deterministically.
        local rh        = getReadHistory()
        local read_time = {}
        for _i, e in ipairs(rh.hist or {}) do
            if e.file and e.time then read_time[e.file] = e.time end
        end
        table.sort(items, function(a, b)
            local ta = read_time[a.file] or (a.attr and a.attr.access) or 0
            local tb = read_time[b.file] or (b.attr and b.attr.access) or 0
            return ta > tb
        end)
    elseif key == "updated" then
        -- ReadCollection assigns a monotonically increasing `order` value
        -- as items are added (via getCollectionNextOrder = max + 1). Sort
        -- DESC so newly favourited books float to the top — the use case
        -- "I just starred this, where did it go?" lands at slot 1.
        table.sort(items, function(a, b)
            return (a.order or 0) > (b.order or 0)
        end)
    elseif key == "date_added" then
        -- Legacy default before "updated": collection access time, newest
        -- first. Kept as an opt-in for users who preferred this ordering.
        table.sort(items, function(a, b)
            return (a.attr and a.attr.access or 0) > (b.attr and b.attr.access or 0)
        end)
    else
        -- Unknown key: fall through to "updated" — matches _SORT_DEFAULT.
        table.sort(items, function(a, b)
            return (a.order or 0) > (b.order or 0)
        end)
    end
    -- Build Book records only for the visible page; total returned so the
    -- caller's _total_hint path can compute total_pages.
    local total = #items
    offset      = offset or 0
    local stop  = _hydrationStop(offset, limit, total, 8, "getFavorites", opts and opts.light_only)
    local out   = {}
    local ScaledCoverCache
    if opts and opts.lazy_cover then
        ScaledCoverCache = require("lib/bookshelf_scaled_cover_cache")
    end
    for i = offset + 1, stop do
        local fp = items[i].file
        local meta_opts
        if ScaledCoverCache and ScaledCoverCache:has(fp) then
            meta_opts = { want_cover = false }
        end
        local book = Repo.buildBookMeta(fp, meta_opts)
        if book then
            book.in_favorites = true
            out[#out + 1] = book
        end
    end
    return out, total
end

-- ─── getTags ─────────────────────────────────────────────────────────────────
-- Returns up to `limit` tag groups derived from KOReader's ReadCollection.
-- Skips the built-in "favorites" collection (it has its own chip). Groups
-- are { kind = "tag", series_name = collection_name, books = [...],
-- latest = max(item.attr.access) } so they flow through the same
-- SeriesStack widget + drill-down path as Series / Authors / Genres.
--
-- No shape cache here (unlike getSeriesGroups / getAuthors / getGenres):
-- ReadCollection state changes via user actions (Add to collection /
-- Remove) don't fire our walk-cache invalidation, so a TTL'd cache could
-- show stale collection contents. Per-collection book counts are usually
-- small, so the per-render rebuild cost is dominated by buildBookMeta
-- (a SQLite lookup per book) — acceptable.

-- ─── searchBooks ─────────────────────────────────────────────────────────────
-- Library-wide substring search. Walks the same cached library list used
-- by getLatest / getSeriesGroups / getAuthors etc., builds BIM-meta for
-- each candidate, and matches against a haystack of title + author(s) +
-- series_name + filename + genres. Splits the query on whitespace; every
-- word must appear somewhere in the haystack (AND match) — case-insensitive.
--
-- This is the BIM-cache-backed equivalent of "Calibre Search" in
-- KOReader-stock terms: results return instantly because the metadata is
-- pre-indexed. (KOReader's File Search walks the filesystem freshly per
-- query, which gets unusable past a few hundred books.)
-- _searchMatches(b, words): every query word must appear somewhere in the
-- record's searchable text. Build a single haystack so the match is one find()
-- per word rather than one per field.
--
-- Shared by the filesystem walk and the Kindle library below: two copies of the
-- match rule is how one source quietly starts answering a different question
-- from the other.
-- Genres and tags take part in search unless the reader has switched them
-- off (issue 371: someone who searches by title or author finds the tag
-- matches clutter). Folder names are the other way round -- see searchAll.
local function _searchIncludesGenres()
    return BookshelfSettings.read("search_include_genres") ~= false
end

local function _searchMatches(b, words, skip_genres)
    local parts = {
        (b.title       or ""):lower(),
        (b.author      or ""):lower(),
        (b.series_name or ""):lower(),
        (b.filename    or ""):lower(),
    }
    if b.authors then
        for _i, a in ipairs(b.authors) do parts[#parts + 1] = a:lower() end
    end
    if b.genres and not skip_genres then
        for _i, g in ipairs(b.genres) do parts[#parts + 1] = g:lower() end
    end
    local hay = table.concat(parts, " ")
    for _i, w in ipairs(words) do
        if not hay:find(w, 1, true) then return false end
    end
    return true
end

-- _librarySourceBooks() -> records or nil: the books of every registered source
-- that counts as part of the user's shelf for whole-library questions -- search
-- (issue #355), and the shelf-wide tallies. The Kindle library today.
--
-- These cover the sources the user has actually put on their shelf, so having
-- made a shelf of the source is the opt-in (lib/bookshelf_sources libraryIds).
-- Having the plugin installed is not enough on its own: someone may use its own
-- Kindle Library view and not want Bookshelf reaching into their Kindle books.
--
-- Forward-declared above, because the tallies are defined earlier in the file.
_librarySourceBooks = function()
    local ok_tabs, tabs = pcall(TabModel.load)
    if not (ok_tabs and type(tabs) == "table") then return nil end
    local Sources = require("lib/bookshelf_sources")
    local ids = Sources.libraryIds(tabs)
    if #ids == 0 then return nil end
    local out = {}
    for _i, id in ipairs(ids) do
        for _j, b in ipairs(Sources.list(id) or {}) do out[#out + 1] = b end
    end
    return out
end

function Repo.searchBooks(query, limit)
    if not query or query == "" then return {} end
    local home  = HomeDir.get() or "/"
    local depth = BookshelfSettings.read("latest_walk_depth") or 3
    local cands = cachedWalk(home, depth)
    local words = {}
    for w in query:gmatch("%S+") do
        words[#words + 1] = w:lower()
    end
    if #words == 0 then return {} end
    local light_cache = _getLightMetaCache(home, depth)
    local skip_genres = not _searchIncludesGenres()
    local out = {}
    for _i, c in ipairs(cands) do
        -- _buildBookMetaLight rather than buildBookMeta: search compares
        -- text fields only, no covers required. Shared light_cache means
        -- search reuses the same BIM batch read warmed by a previous
        -- Series / Authors / Genres tab visit.
        local b = _lightMetaForFp(light_cache, c.fp)
        if b and _searchMatches(b, words, skip_genres) then
            out[#out + 1] = b
            if limit and #out >= limit then break end
        end
    end
    -- The Kindle library. Its books are NOT on the filesystem walk -- a .kfx is
    -- not in SUPPORTED_EXT and they live outside home_dir -- so without this,
    -- search answers "no" for books the user owns and can see on their own
    -- Kindle chip. Listed from the catalogue cache, so no disk walk and no
    -- network. Local results come first: the user's own files before the
    -- Kindle's.
    if not (limit and #out >= limit) then
        for _i, b in ipairs(_librarySourceBooks() or {}) do
            if _searchMatches(b, words, skip_genres) then
                out[#out + 1] = b
                if limit and #out >= limit then break end
            end
        end
    end
    return out
end

-- _isTitleCase(s): true when every word starts with an uppercase letter and
-- the string isn't entirely uppercase -- "Southern Reach" yes; "southern
-- reach", "Southern reach", "SOUTHERN REACH" no. Used when case-insensitive
-- grouping merges spelling variants ("southern reach" / "Southern Reach"):
-- prefer a Title Case variant for the displayed stack label, else first-seen.
local function _isTitleCase(s)
    if not s or s == "" then return false end
    if s == s:upper() then return false end          -- all-caps
    for word in s:gmatch("%S+") do
        local c = word:match("^(%a)")                 -- first alpha char of the word
        if c and c ~= c:upper() then return false end
    end
    return true
end

-- _groupShapeCmp(priority_or_key): used by series / authors / genres / tags
-- group sorters. Accepts either a v1.1 single key string OR a v1.2 priority
-- list. When a string is passed, lifts it via the legacy map.
local function _groupShapeCmp(priority_or_key)
    local priority
    if type(priority_or_key) == "string" then
        local map = {
            name        = { { key = "filename",    reverse = false } },
            latest_read = { { key = "last_opened", reverse = true  } },
            book_count  = { { key = "book_count",  reverse = true  } },
        }
        priority = map[priority_or_key] or { { key = "filename", reverse = false } }
    else
        priority = priority_or_key
    end
    return SortEngine.chainedComparator(priority)
end

-- _attachFlattenedCounts(out, sorted, offset) -- spine mode flattens stacks,
-- so its footer counts BOOKS; every group window carries the flattened
-- totals as fields on the page table (the opds_open_ended pattern).
-- books_before is relative to the window's offset, which is the shelf
-- cursor at fetch time. Group shapes carry filepaths (cached shapes) or
-- books (freshly built, e.g. getTags); standalones count as one.
local function _attachFlattenedCounts(out, sorted, offset)
    local total, before = 0, 0
    for i = 1, #sorted do
        local s = sorted[i]
        local n = 1
        if s and not s.standalone then
            if s.filepaths and #s.filepaths > 0 then
                n = #s.filepaths
            elseif s.books and #s.books > 0 then
                n = #s.books
            end
        end
        total = total + n
        if i <= (offset or 0) then before = before + n end
    end
    out.spine_books_total  = total
    out.spine_books_before = before
end

function Repo.getTags(limit, offset, sort_priority_override, filter, opts)
    local rc = getCollections()
    if not rc.coll then return {}, 0 end
    local active = _filterIsActive(filter)
    -- ALL members hydrate with light metadata (one batched SELECT, no cover
    -- decode): the stack visual only renders books[1]'s cover, the within-
    -- group title sort and status filter read light fields, and drilldown /
    -- preload consumers re-hydrate by filepath themselves. The visible page
    -- slice upgrades each group's front book to a full record below --
    -- previously EVERY member of EVERY collection paid a full buildBookMeta
    -- (cover zstd decode included) on each Collections render.
    -- light_only (letter-jump index): same hydration, skips the front-book
    -- upgrade since the caller never renders these records.
    local light_only = opts and opts.light_only
    local light_cache
    local home  = HomeDir.get() or "/"
    local depth = BookshelfSettings.read("latest_walk_depth") or 3
    -- Compile once before the loop (not per book) when filter is active,
    -- so every per-book test is an O(1) lookup on the compiled result.
    local compiled = active and Filter.compile(filter, Repo.filterOpts()) or nil
    local groups = {}
    for coll_name, files in pairs(rc.coll) do
        if coll_name ~= "favorites" then
            local books  = {}
            local latest = 0
            for _file, item in pairs(files) do
                local fp = item.file or _file
                light_cache = light_cache or _getLightMetaCache(home, depth)
                local book = _lightMetaForFp(light_cache, fp)
                if book then
                    -- When filter is active, only include books that pass
                    -- the full filter (status + genre + langs + formats +
                    -- collections). Filter-inactive path pays nothing extra.
                    local include = true
                    if compiled then
                        include = _recordMatches(book, compiled)
                    end
                    if include then
                        books[#books + 1] = book
                        local t = (item.attr and item.attr.access) or 0
                        if t > latest then latest = t end
                    end
                end
            end
            if #books > 0 then
                table.sort(books, function(a, b)
                    return (a.title or "") < (b.title or "")
                end)
                groups[#groups + 1] = {
                    kind        = "tag",
                    series_name = coll_name,
                    books       = books,
                    latest      = latest,
                }
            end
        end
    end
    table.sort(groups, _groupShapeCmp(sort_priority_override or Repo.getSortPriority("tags")))
    -- Window the sorted list with offset + limit (cursor-driven pagination,
    -- mirroring getRatings / getAuthors / etc.) and return the unwindowed
    -- total so the caller can compute the page count. Without `total`, the
    -- chip strip's pagination falls back to #out, capping the Collections
    -- view at one page of `limit` items even when more collections exist.
    local total = #groups
    offset      = offset or 0
    local stop  = _hydrationStop(offset, limit, total, total, "getTags", opts and opts.light_only)
    local out   = {}
    _attachFlattenedCounts(out, groups, offset)
    -- Upgrade each visible group's FRONT book (the one whose cover the
    -- SeriesStack renders) to a full record. Covers already in
    -- ScaledCoverCache skip the BIM zstd decode; SpineWidget repaints
    -- them from the cache by filepath key.
    local ScaledCoverCache
    if not light_only and opts and opts.lazy_cover then
        ScaledCoverCache = require("lib/bookshelf_scaled_cover_cache")
    end
    for i = offset + 1, stop do
        local g = groups[i]
        -- Spine shelf (Repo.spine_light): collections flatten into member
        -- spines, so the front cover is never rendered -- skip the full
        -- build like the _hydrateGroupShape spine branch does.
        if not light_only and not Repo.spine_light
                and g.books[1] and g.books[1].filepath then
            local fp = g.books[1].filepath
            local meta_opts
            if ScaledCoverCache and ScaledCoverCache:has(fp) then
                meta_opts = { want_cover = false }
            end
            local full = Repo.buildBookMeta(fp, meta_opts)
            if full then g.books[1] = full end
        end
        out[#out + 1] = g
    end
    return out, total
end

-- ─── getSeriesGroups ─────────────────────────────────────────────────────────
-- Returns up to `limit` series groups derived from a filesystem walk of the
-- user's library (so unread books in a series still show up, not only ones
-- in ReadHistory). Each group is { series_name, books, latest } where books
-- are sorted by series_num ascending. Groups are sorted by most recent
-- activity descending — read-time from ReadHistory when available, else the
-- file's mtime as a fallback so newly-added unread series still surface.
-- Books without a series_name are excluded.

-- Hydrate a cached series shape into a renderable group: rebuild every
-- Book record fresh via buildBookMeta. A previous version of the cache
-- stashed Book objects directly, but their cover_bb fields are owned by
-- ImageWidget and freed after each paint — reusing cached Books segv'd
-- on subsequent renders ("cover image corruption / crash going back out
-- of a series"). Caching the shape (filepath list + sort metadata) and
-- rebuilding Books on read keeps the cover_bb lifetime safe while still
-- skipping the lfs walk + the sort/group pass.
-- The author a series stack is shown under ("Show text below covers: Author",
-- issue 486): the MODAL member author, first-seen winning a tie. Same rule the
-- sort engine files the stack under (groupAuthor, issue 351), so the name
-- under the tile is the one the shelf is ordered by, and a guest collaborator
-- on one volume does not relabel the series. No "A & B": a member's `author` is
-- already the book's FIRST author, which is what a book's own label shows.
--
-- From the cached members (books_meta), which carry the author for every
-- member: the hydrated books[2..n] are bare filepath stubs. No per-tile read.
local function _modalAuthor(members)
    if type(members) ~= "table" then return nil end
    local counts, order = {}, {}
    for i = 1, #members do
        local a = members[i] and members[i].author
        if type(a) == "string" and a ~= "" then
            if not counts[a] then counts[a] = 0; order[#order + 1] = a end
            counts[a] = counts[a] + 1
        end
    end
    local best, best_n = nil, 0
    for i = 1, #order do
        if counts[order[i]] > best_n then best, best_n = order[i], counts[order[i]] end
    end
    return best
end

local function hydrateSeriesShape(shape, filter, light_only)
    -- Filter the series's book list when a status filter is active.
    -- An empty result → caller drops this series from the visible list.
    local order = shape.filepaths
    local meta  = shape.books_meta
    -- The members the stack shows, for its author: the filtered ones when a
    -- filter is active, so the name matches the books behind the tile.
    local shown = meta
    if _filterIsActive(filter) and meta then
        local filtered = _applyFilter(meta, filter)
        if #filtered == 0 then return nil end
        shown = filtered
        order = {}
        for i = 1, #filtered do order[i] = filtered[i].filepath end
    end
    -- fp -> this group's series_num. A book's OWN metadata (what
    -- buildBookMeta returns below) only ever knows its PRIMARY series
    -- number. For a secondary/tag-derived series (#multi-series) that
    -- number is wrong here -- e.g. a book at position 53 in "SF
    -- Masterworks" but position 10 in its primary series "Eternal
    -- Champion" -- so we look the group-correct number up from
    -- books_meta (set per-group by getSeriesGroups) and stamp it back
    -- on afterwards rather than trusting buildBookMeta's series_num.
    local num_for_fp
    if meta then
        num_for_fp = {}
        for _i, m in ipairs(meta) do num_for_fp[m.filepath] = m.series_num end
    end
    -- light_only (letter-jump index): caller reads only series_name and
    -- never renders the stack, so skip the front-cover buildBookMeta decode.
    local books = {}
    if light_only then
        for i = 1, #order do books[i] = { filepath = order[i] } end
    elseif Repo.spine_light then
        -- Spine shelf: series flatten into member spines, so the front cover
        -- below is never rendered -- yet every series-chip fetch paid a full
        -- buildBookMeta per series up to the 512 clamp (the clamp WARN on
        -- every series open). Same cure as _hydrateGroupShape: COPIES of the
        -- cached light meta (copies, because the spine plan bakes status onto
        -- the records it renders and the shape cache has no strip protection).
        local by_fp = {}
        if meta then for _i, m in ipairs(meta) do by_fp[m.filepath] = m end end
        for i = 1, #order do
            local src = by_fp[order[i]]
            if src then
                local b = {}
                for k, v in pairs(src) do b[k] = v end
                books[i] = b
            else
                books[i] = { filepath = order[i] }
            end
        end
    else
        for i, fp in ipairs(order) do
            if i <= 1 then
                -- Full BIM hydration: cover_bb for the single front cover rendered
                -- by SeriesStack. Only one cover is visible per group on the shelf.
                local b = Repo.buildBookMeta(fp)
                if b then
                    if num_for_fp then b.series_num = num_for_fp[fp] end
                    books[#books + 1] = b
                end
            else
                -- Filepath stub: drilldown via _fetchChipItems calls buildBookMeta
                -- per-book anyway, so the stub is sufficient for that path. Carry
                -- series_num along so _fetchChipItems can restamp it after that
                -- re-hydration (see note above -- buildBookMeta alone would give
                -- back the book's primary series number, not this group's).
                books[#books + 1] = {
                    filepath   = fp,
                    series_num = num_for_fp and num_for_fp[fp] or nil,
                }
            end
        end
    end
    return {
        series_name  = shape.series_name,
        -- Display only; series_name above stays raw so the sort keeps the
        -- article-insensitive order. Same split folders use (label vs name).
        label        = _flipTrailingArticle(shape.series_name),
        books        = books,
        -- Display only, and deliberately NOT `author`: the sort engine and
        -- the "is this a book" checks read that field on a record.
        stack_author = (not light_only) and _modalAuthor(shown) or nil,
        latest       = shape.latest,
        latest_added = shape.latest_added or 0,
    }
end

-- Distinct value list for a filter dimension, shaped for the picker UI:
-- { {value=string, label=string, count=number}, ... }. Reuses the existing
-- group enumerators (each group card carries series_name = the value and a
-- filepaths array for the count). Collections come from ReadCollection.
function Repo.distinctFilterValues(dim, source)
    -- A chip backed by its own catalogue offers the values ITS books have.
    local scoped = _sourceFilterChoices(dim, source)
    if scoped then return scoped end
    local out = {}
    if dim == "collections" then
        local rc = getCollections()
        if rc and rc.coll then
            for name, coll in pairs(rc.coll) do
                if name ~= "favorites" then
                    local n = 0
                    for _fp in pairs(coll) do n = n + 1 end
                    out[#out + 1] = { value = name, label = name, count = n }
                end
            end
        end
        table.sort(out, function(a, b) return a.label < b.label end)
        return out
    end
    -- Ratings: the value set is fixed ("1".."5"/"unrated") and does NOT match
    -- what getGroupChoices("rating") returns (its values are star-glyph strings
    -- and "Unrated", not the numeric keys the filter uses). Return the fixed list
    -- from Filter.ratingValues() with count=0; real counts are deferred to the
    -- faceted-count task. The fixed list is always complete (all 6 buckets) so
    -- the picker shows every option even when the user's library has no 5-star
    -- books yet.
    if dim == "ratings" then
        local rv = Filter.ratingValues()
        for _i, v in ipairs(rv) do
            out[#out + 1] = { value = v.value, label = v.label, count = 0 }
        end
        return out
    end
    -- Delegate to the lightweight choice list (getGroupChoices builds the group
    -- cache with limit=0, so it skips per-group hydration: no buildBookMeta and
    -- no cover decompression, which the old getGenres(100000, ...) path paid for
    -- every group only to discard it -- ~1-2s on a large library, the cause of
    -- the slow genre-filter open). Same `value` (series_name) the pickers store,
    -- so the language/genre canonicalisation round-trip is unchanged.
    local kind_for = { genres = "genre", langs = "language", formats = "format" }
    local kind = kind_for[dim]
    if not kind then return out end
    out = Repo.getGroupChoices(kind)
    table.sort(out, function(a, b) return a.label < b.label end)
    return out
end

-- Filepath membership set for one collection (default collection resolver
-- handed to Filter.compile).
function Repo.collectionFilepaths(name)
    local rc = getCollections()
    if not rc or not rc.coll then return {} end
    local coll = rc.coll[name]
    if type(coll) ~= "table" then return {} end
    local set = {}
    for filepath in pairs(coll) do set[filepath] = true end
    return set
end

-- Standard options handed to Filter.compile so the language/genre dimensions
-- canonicalise the same way the chip-source paths and the value enumerators do
-- (else a picked "English"/Title-Case genre would never match raw book.lang /
-- book.genres). collection_resolver supplies per-collection filepath sets.
function Repo.filterOpts()
    return {
        collection_resolver = Repo.collectionFilepaths,
        lang_canonical = function(v)
            if v == nil then return nil end
            return BookshelfLang.canonical(v) or _normalizeLang(v)
        end,
        genre_normalize = _normalizeGenre,
        -- Formats are a short canonical token ("EPUB", "KFX"), so upper-casing
        -- is the whole normalisation. Guarded for a non-string because a filter
        -- read back from settings is whatever was written there.
        format_normalize = function(v)
            return type(v) == "string" and v:upper() or v
        end,
    }
end

-- Read-time assembly for the Series source: choose which cached shapes
-- participate, filter, sort and hydrate one combined, paginated list.
-- Shared by getSeriesGroups' cache HIT and MISS paths so they can't drift.
--
-- The chip's RAW series_membership filter value drives participation (#160):
--   nil / "in_series" -> stacks only (the historical behaviour)
--   "both"            -> stacks + standalone books as plain singles
--   "standalone"      -> standalone books only
-- ("both" never compiles into the per-book filter, so the other dimensions
-- keep working; "standalone"/"in_series" compile as before and stay
-- consistent with what this participation choice emits.)
--
-- hide_single (#127) interaction: in the mixed "both" view a one-book series
-- isn't noise, it's just a book -- so instead of being dropped it DEGRADES to
-- a plain single. Elsewhere the drop behaviour is unchanged.
local function _seriesReadout(group_shapes, standalone_shapes, filter,
                              hide_single, sk, limit, offset, light_only)
    local mode = filter and filter.series_membership
    local want_groups  = mode ~= "standalone"
    local want_singles = mode == "both" or mode == "standalone"
    local degrade      = hide_single and mode == "both"
    local sorted = {}
    if want_groups then
        for _i, s in ipairs(group_shapes or {}) do
            -- Degraded 1-book stacks are re-added as singles below.
            if not (degrade and s.filepaths and #s.filepaths == 1)
                    and _shapeVisible(s, filter, hide_single) then
                sorted[#sorted + 1] = s
            end
        end
    end
    if want_singles then
        local compiled = _filterIsActive(filter)
            and Filter.compile(filter, Repo.filterOpts()) or nil
        local function addSingle(std)
            if not compiled or _recordMatches(std, compiled) then
                sorted[#sorted + 1] = std
            end
        end
        for _i, std in ipairs(standalone_shapes or {}) do addSingle(std) end
        if degrade then
            for _i, s in ipairs(group_shapes or {}) do
                if s.filepaths and #s.filepaths == 1 then
                    local m = (s.books_meta and s.books_meta[1]) or {}
                    addSingle({
                        standalone  = true,
                        filepath    = s.filepaths[1],
                        -- Sort/display fallbacks: a 1-book series is named
                        -- after its series for ordering purposes.
                        series_name = s.series_name,
                        series_num  = m.series_num,
                        genres      = m.genres,
                        lang        = m.lang,
                        author      = m.author,
                        author_sort = m.author_sort,
                        latest      = s.latest,
                        -- Date added has to come across too, and separately
                        -- from `latest`: that one folds in read time, so
                        -- sourcing it here would make opening an old
                        -- single-volume book look like adding it. Without this
                        -- a 1-book series -- which never travels as a group,
                        -- being degraded back to a single right here -- reaches
                        -- the date_added comparator with nothing to compare,
                        -- and cmp's isMissing sends it to the END of the shelf.
                        latest_added = s.latest_added,
                        book_count  = 1,
                    })
                end
            end
        end
    end
    table.sort(sorted, _groupShapeCmp(sk))
    local total = #sorted
    local out   = {}
    offset      = offset or 0
    _attachFlattenedCounts(out, sorted, offset)
    local stop  = _hydrationStop(offset, limit, total, 8, "getSeriesGroups",
                                 light_only or Repo.spine_light)
    for i = offset + 1, stop do
        local s = sorted[i]
        if s.standalone then
            if light_only then
                -- Letter-jump index: sort-key fields only, never rendered.
                out[#out + 1] = { filepath = s.filepath, title = s.title,
                                  filename = s.filename, series_name = s.series_name }
            else
                -- Plain Book record: shelf_row renders it as a single cover
                -- and taps open the book, same as any book-list chip. The
                -- spine shelf renders no cover, so a copy of the light record
                -- serves it (full build as the fallback for a book the batch
                -- doesn't know).
                local b
                if Repo.spine_light then
                    local light = Repo.lightMetaFor(s.filepath)
                    if light then
                        b = {}
                        for k, v in pairs(light) do b[k] = v end
                    end
                end
                b = b or Repo.buildBookMeta(s.filepath)
                if b then out[#out + 1] = b end
            end
        else
            out[#out + 1] = hydrateSeriesShape(s, filter, light_only)
        end
    end
    return out, total
end

function Repo.getSeriesGroups(limit, offset, sort_priority_override, filter, opts)
    local home  = HomeDir.get() or "/"
    local depth = BookshelfSettings.read("latest_walk_depth") or 3
    local key   = (home or "/") .. ":" .. tostring(depth or 0)
    local now   = os.time()
    -- Read at the top so both the cache HIT and MISS paths apply the same
    -- single-book-stack rule (issue #127). Filtered at read time, not bake
    -- time, so toggling the setting takes effect on the next render with no
    -- cache invalidation.
    local hide_single = BookshelfSettings.isTrue("hide_single_book_stacks")

    -- Cache fast path: filepaths + sort metadata are stable across renders;
    -- Books get rehydrated each read so cover_bbs are fresh. Sort runs at
    -- hydrate time so changing bookshelf_sort_series doesn't invalidate the
    -- cache.
    local cached = _series_cache[key]
    if cached then
        local _t0 = _gettime()
        local sk  = sort_priority_override or Repo.getSortPriority("series")
        local out, total = _seriesReadout(cached.groups, cached.standalones,
            filter, hide_single, sk, limit, offset, opts and opts.light_only)
        logger.dbg(string.format("[bookshelf perf] getSeriesGroups: HIT hydrate=%.0fms groups=%d/%d",
            (_gettime() - _t0) * 1000, #out, total))
        return out, total
    end

    local _t0 = _gettime()
    -- Build a filepath → read-time map so the series sort still favours
    -- series you've actually been reading lately.
    local rh        = getReadHistory()
    local read_time = {}
    for _i, entry in ipairs(rh.hist) do
        local t = entry.time or 0
        if t > (read_time[entry.file] or 0) then
            read_time[entry.file] = t
        end
    end

    local candidates = cachedWalk(home, depth)
    local light_cache = _getLightMetaCache(home, depth)

    local groups      = {}  -- keyed by series_name
    local order       = {}  -- preserves insertion order for deterministic tie-break
    local standalones = {}  -- books with no series (#160), in walk order
    for _i, c in ipairs(candidates) do
        -- Lightweight walk: only text fields needed for grouping/sorting.
        -- Using buildBookMeta here kept all cover BlitBuffers live for the
        -- entire 2000-book walk (~120 MB peak on Calibre libraries → OOM).
        -- The shared light_cache turns ~2000 BIM prepared-statement runs into
        -- one batch SELECT for the first chip; subsequent chips (Authors,
        -- Genres) hit the same cache.
        local book = _lightMetaForFp(light_cache, c.fp)
        -- Every series this book belongs to (issue 299): the primary, plus
        -- any Calibre custom series columns. Each membership carries its OWN
        -- number -- The Forever War is #1 in its series and #83 in SF
        -- Masterworks -- and the per-entry series_num below is what the
        -- within-group sort reads, so both stacks order correctly.
        local memberships
        if book and book.series_name then
            memberships = { { name = book.series_name,
                              num  = book.series_num } }
        end
        if book and type(book.extra_series) == "table" then
            memberships = memberships or {}
            for _j, es in ipairs(book.extra_series) do
                memberships[#memberships + 1] = { name = es.name, num = es.num }
            end
        end
        if memberships then
            for _j, m in ipairs(memberships) do
            local sname = m.name
            -- Bucket case-insensitively so "Southern Reach" and "southern
            -- reach" merge into one stack. Display the first-seen spelling,
            -- but upgrade to a Title Case variant if one shows up.
            local skey = sname:lower()
            local g = groups[skey]
            if not g then
                g = { series_name = sname, books = {}, latest = 0,
                      latest_added = 0, _seen = {} }
                groups[skey] = g
                order[#order + 1] = skey
            elseif _isTitleCase(sname) and not _isTitleCase(g.series_name) then
                g.series_name = sname
            end
            if not g._seen[book.filepath] then
                g._seen[book.filepath] = true
                g.books[#g.books + 1] = {
                    filepath   = book.filepath,
                    series_num = m.num,
                    genres     = book.genres,
                    lang       = book.lang,
                    -- The author, so the stack can be SORTED by it (#351).
                    -- The group itself has no author of its own -- a series is
                    -- not a person -- so the sort engine takes the modal
                    -- author of the members. Without these two the group fell
                    -- back to parsing its own series_name as a name, and
                    -- "sort by author surname" ordered a shelf of series by
                    -- the last word of each TITLE.
                    --
                    -- Both spellings, matching the record-level preference
                    -- order, so a Calibre library carrying the curated form
                    -- everywhere does not split one author across two
                    -- spellings of the same name. References to strings the
                    -- light record already holds, so this costs no allocation
                    -- beyond the two slots.
                    author      = book.author,
                    author_sort = book.author_sort,
                }
            end
            -- latest: the most recent READ TIME among the members, as on the
            -- author, genre and rating shelves. Adding a book doesn't count
            -- as reading it: only "Most recently added" (latest_added below)
            -- brings a series forward for a new book (maintainer,
            -- 2026-10-10). It took member file dates too, so a series read
            -- months ago jumped to the front of "Most recently read" when a
            -- new unread book joined it, and the list view's "last opened"
            -- for the series showed that date.
            local t = read_time[book.filepath] or 0
            if t > g.latest then g.latest = t end
            -- latest_added is the max member MTIME, kept separate from
            -- `latest` above: that one is read time only, so reusing it here
            -- would make merely opening an old book look like adding it. The sort engine's date_added
            -- comparator reads this field on a group shape, and without it
            -- cmp's isMissing sends every series group to the END of a "Sort
            -- by date added" -- a freshly synced book in a series vanished off
            -- the bottom of the shelf the moment BIM found its series.
            -- _buildGroups already does this for Authors / Genres / Tags.
            local added = c.mtime or 0
            if added > (g.latest_added or 0) then g.latest_added = added end
            end
        elseif book then
            -- No series: a standalone shape (#160), cached alongside the
            -- group shapes. Carries the same sort-key fields the comparator
            -- reads on group shapes (filename fallbacks, latest, book_count)
            -- so _groupShapeCmp interleaves the mixed list for free, plus
            -- genres/lang/filepath so the per-book filter dimensions work.
            standalones[#standalones + 1] = {
                standalone   = true,
                filepath     = book.filepath,
                filename     = book.filename,
                title        = book.title,
                genres       = book.genres,
                lang         = book.lang,
                -- The author, so a surname sort files the book among the
                -- series (351). Without it the key was empty and every
                -- standalone went to the end of the shelf.
                author       = book.author,
                author_sort  = book.author_sort,
                -- Read time only, as on the author and genre shelves: a book
                -- never opened has none, so under "Most recently read" it
                -- sorts after the read ones, by the next sort key. Its file
                -- date put a newly added unread book first, ahead of
                -- everything read (reported on Reddit, 2026-10-10).
                latest       = read_time[book.filepath] or 0,
                latest_added = c.mtime or 0,
                -- Sort-only field (hydration replaces this shape with a real
                -- Book record). 0, not 1: under a book-count sort a standalone
                -- isn't a series at all, so it ranks below a 1-book series
                -- rather than tying with it in arbitrary order. Degraded
                -- 1-book stacks (hide_single + "both") keep count 1 -- they
                -- ARE a series, just rendered as a single.
                book_count   = 0,
            }
        end
    end
    -- Flatten to list. Sort runs at hydrate time on the cached shapes (see
    -- HIT branch / MISS hydrate below), so a sort menu change re-renders
    -- without a re-walk.
    local list = {}
    for _i, k in ipairs(order) do list[#list + 1] = groups[k] end
    -- Within each group, sort books by series_num ascending. Also remove _seen helper.
    for _i, g in ipairs(list) do
        g._seen = nil
        table.sort(g.books, function(a, b)
            return (tonumber(a.series_num) or 0) < (tonumber(b.series_num) or 0)
        end)
    end

    -- Stash the SHAPE (filepaths + sort metadata) — never the Book
    -- records themselves. That avoids the use-after-free on the
    -- ImageWidget-owned cover_bbs that books carry.
    local shapes = {}
    for _i, group in ipairs(list) do
        local fps = {}
        local books_meta = {}
        for _i, b in ipairs(group.books) do
            fps[#fps + 1] = b.filepath
            -- Carry filepath + series_num so hydrate-time filter checks
            -- (live readProgress, cached) can run against the same
            -- structure as the other group kinds. genres/lang are carried
            -- so genre and language filters work on group chips.
            -- series_name too: without it the compiled series_membership
            -- check saw every member as standalone, so an explicit "Only
            -- books in series" filter emptied the Series chip (#160).
            books_meta[#books_meta + 1] = {
                filepath    = b.filepath,
                series_num  = b.series_num,
                series_name = group.series_name,
                genres      = b.genres,
                lang        = b.lang,
                -- The author, so a shelf of series can be SORTED by it
                -- (#351). THIS is the structure the comparator sees: the
                -- shape cached here is what _groupShapeCmp sorts, not the
                -- group.books it was built from. Adding the author to that
                -- one alone left this rebuild dropping it again, and the
                -- sort went on reading the series TITLE as a person's name.
                author      = b.author,
                author_sort = b.author_sort,
            }
        end
        shapes[#shapes + 1] = {
            series_name  = group.series_name,
            filepaths    = fps,
            books_meta   = books_meta,
            latest       = group.latest,
            -- Carried through the cache so a HIT sorts identically to a MISS;
            -- dropping it here would resurrect the bug only once the TTL
            -- warmed, which is much harder to spot than a constant failure.
            latest_added = group.latest_added or 0,
        }
    end
    _series_cache[key] = { groups = shapes, standalones = standalones,
                           expires_at = now + SERIES_CACHE_TTL }

    -- MISS path: same readout as the HIT path (sort + hydrate one combined,
    -- paginated list), so cover_bb lifetime and the series_membership
    -- participation rules are identical regardless of cache state.
    local sk = sort_priority_override or Repo.getSortPriority("series")
    local out, total = _seriesReadout(shapes, standalones, filter,
        hide_single, sk, limit, offset, opts and opts.light_only)
    logger.dbg(string.format("[bookshelf perf] getSeriesGroups: MISS build=%.0fms cands=%d groups=%d/%d",
        (_gettime() - _t0) * 1000, #candidates, #out, total))
    return out, total
end

-- ─── getAuthors / getGenres ──────────────────────────────────────────────────
-- Both return GroupGroup records shaped like the series-group records, so
-- they can flow through the same SeriesStack widget on the shelf and the
-- same drill-down path. Differences encoded via group.kind ("author" /
-- "genre"); the band-text field stays `series_name` so SeriesStack
-- doesn't need a bespoke parameter for each kind.
--
-- Authors: keyed on book.author (single primary author). Books with no
-- author are skipped — the Author tab is implicitly "named authors only".
-- Genres: keyed on each entry of book.genres (multi-tag — a book with
-- "Sci-Fi, Fantasy" appears under both groups).
--
-- Both share the same caching pattern as getSeriesGroups: cache the SHAPE
-- (filepaths + sort metadata), rehydrate Books on read.

-- _filterIsActive(filter): true when filter.statuses has at least one
-- key set. nil filter / nil statuses / empty statuses → "no filter".
_filterIsActive = function(filter)
    return Filter.isActive(filter)
end

-- _shapeHasFilteredBook(shape, filter): cheap "is this group visible
-- under the active filter?" predicate. Short-circuits on first match.
-- Returns true when filter is inactive (no-op). Used to drop empty
-- groups before pagination so page counts stay sane.
_shapeHasFilteredBook = function(shape, filter)
    if not Filter.isActive(filter) then return true end
    local meta = shape.books_meta
    if not meta then return true end  -- transition-compat: nothing to test against
    local compiled = Filter.compile(filter, Repo.filterOpts())
    for i = 1, #meta do
        if _recordMatches(meta[i], compiled) then return true end
    end
    return false
end

-- _shapeVisible(shape, filter, hide_single): _shapeHasFilteredBook plus the
-- optional "hide single-book stacks" rule (issue #127). A series or genre
-- stack with a single book is usually noise -- a one-off poorly-tagged book,
-- a title duplicated into the series field (the empty-series case is dropped
-- upstream now), or an incomplete series. When the user opts in, drop it.
-- Only the series + genre fetchers use this; authors / formats / languages
-- keep the plain predicate, since a one-book group there is normal.
_shapeVisible = function(shape, filter, hide_single)
    if hide_single and shape.filepaths and #shape.filepaths <= 1 then
        return false
    end
    return _shapeHasFilteredBook(shape, filter)
end

-- _recordMatches(b, compiled): test a book/light record against a compiled
-- filter, resolving per-book data lazily -- only the dimensions the compiled
-- filter actually constrains. Status and rating are the expensive ones (a
-- DocSettings open): resolved only when compiled.statuses / compiled.ratings
-- are set, using the _hasSidecar fast-path so unopened books cost a stat, not
-- an open (issue #113/#117). `format` is path-derivable; filled in for light
-- records (which omit it) so the format dimension works everywhere.
_recordMatches = function(b, compiled)
    if b.format == nil and b.filepath then b.format = _formatLabel(b.filepath) end
    local need_status = compiled.statuses ~= nil
    local need_rating = compiled.ratings  ~= nil
    if (need_status and b._status == nil) or (need_rating and b.rating == nil) then
        if b.filepath and _hasSidecar(b.filepath) then
            -- Keep everything this read returns: it sets _progress_fetched,
            -- and the sort's prefetch skips a record so marked. Dropping the
            -- percentage here is how a filtered shelf sorted by Progress came
            -- out in title order (issue 463).
            local pct, status, rating, page_count = Repo.readProgress(b.filepath)
            if b._status == nil then b._status = _normalizeStatus(status) end
            if b.rating  == nil then b.rating  = rating end
            if b._pct    == nil then b._pct    = pct end
            if b.page_count == nil then b.page_count = page_count end
        else
            if b._status == nil then b._status = "unread" end
            -- no sidecar => never opened => unrated; leave b.rating nil
        end
        b._progress_fetched = true
    end
    return Filter.matches(b, compiled)
end

-- _applyFilter(meta_list, filter): returns a new list containing only meta
-- entries that pass the full compiled filter. Compiles once per call;
-- resolves status lazily via _recordMatches (sidecar-gated, issue #113).
-- Callers should check _filterIsActive(filter) before invoking.
_applyFilter = function(meta_list, filter)
    if not meta_list then return {} end
    if not Filter.isActive(filter) then return meta_list end
    local compiled = Filter.compile(filter, Repo.filterOpts())
    local out = {}
    for i = 1, #meta_list do
        local m = meta_list[i]
        if _recordMatches(m, compiled) then out[#out + 1] = m end
    end
    return out
end

-- Repo.applyFilter(books, filter) -> the books that pass a chip's filter, as
-- the group hydrators apply it; the list itself is unchanged. For a group
-- drill the widget has to re-filter: a return from a book can rebuild its
-- payload from the group's full membership (GitHub issue 479).
function Repo.applyFilter(books, filter) return _applyFilter(books, filter) end

-- Repo.filterMembers(books, filter) -> a group's members that pass a chip's
-- filter, tested on their real records. A stack's members are { filepath }
-- stubs apart from its lead book, and the filter reads genres, languages and
-- the rest off the record: on the stubs every member but the lead failed, so
-- a series opened on a genre-filtered shelf showed one book (GitHub issue
-- 485). Each stub is looked up the way the group hydrators do (the shared
-- light cache, else a per-book light build); the members themselves are
-- what is returned.
function Repo.filterMembers(books, filter)
    if not books then return {} end
    if not Filter.isActive(filter) then return books end
    local compiled = Filter.compile(filter, Repo.filterOpts())
    local function recordFor(b)
        if type(b) ~= "table" or b.title ~= nil or type(b.filepath) ~= "string" then return b end
        return Repo.lightMetaFor(b.filepath) or _buildBookMetaLight(b.filepath) or b
    end
    return Filter.keepMatching(books, recordFor, function(r) return _recordMatches(r, compiled) end)
end

-- _withinPriority(sk): returns the level-2+ slice of a sort_priority,
-- or nil when the chip only has a single level (no within-group rule).
-- Used by every group hydrator to pick the cover that reflects the
-- chip's secondary sort.
local function _withinPriority(sk)
    if not sk or #sk < 2 then return nil end
    local out = {}
    for i = 2, #sk do out[#out + 1] = sk[i] end
    return out
end

-- within_priority (optional): the chip's sort_priority levels 2+. When
-- supplied, books_meta is re-sorted by it so the leader's filepath
-- becomes books[1] (the visible cover on the stack widget). The build-
-- time order (series_name → series_index → title) is the fallback the
-- shape was cached in; without this, a "Genres / book count then added"
-- chip would still show the alphabetically-first cover, not the most-
-- recently-added one.
--
-- Sorting is done on a copy so the cached shape's books_meta isn't
-- mutated (the cache must stay stable across chips that share the same
-- shape but differ in within-priority).
local function _hydrateGroupShape(shape, within_priority, filter, light_only)
    local meta = shape.books_meta
    -- Filter (status-only today). Empty result → caller drops this group.
    if _filterIsActive(filter) and meta then
        meta = _applyFilter(meta, filter)
        if #meta == 0 then return nil end
    end
    -- When filter is inactive, fall back to the cached shape filepaths
    -- (no need to materialise meta for the unfiltered cover).
    local order
    if meta ~= shape.books_meta then
        order = {}
        for i = 1, #meta do order[i] = meta[i].filepath end
    else
        order = shape.filepaths
    end
    -- light_only (letter-jump index): the caller reads only the group's
    -- series_name to locate a page boundary and never renders the card, so
    -- skip the within-group re-sort (it only decides WHICH book's cover
    -- shows) and the per-group buildBookMeta cover decode. The cover decode
    -- is what made a full-list group fetch (e.g. 292 authors) take ~7s.
    if not light_only
            and within_priority and #within_priority > 0 and meta and #meta > 1 then
        local SortEngine = require("lib/bookshelf_sort_engine")
        local meta_copy = {}
        for i = 1, #meta do meta_copy[i] = meta[i] end
        SortEngine.sort(meta_copy, within_priority)
        meta = meta_copy
        local sorted_fps = {}
        for i = 1, #meta_copy do sorted_fps[i] = meta_copy[i].filepath end
        order = sorted_fps
    end
    local books = {}
    if light_only then
        for i = 1, #order do books[i] = { filepath = order[i] } end
    elseif Repo.spine_light then
        -- Spine shelf: groups FLATTEN into member spines, so the front-book
        -- cover the branch below decodes is never rendered -- yet every page
        -- turn on an authors/genres chip paid a full buildBookMeta (BIM read
        -- + cover decode) per group, up to the 512 clamp (device report:
        -- paging the author shelf felt slow; the same disease getBySource's
        -- spine_light branch cured for library chips). Serve COPIES of the
        -- cached light meta instead: title/author/series fields are all the
        -- spine plan reads, and it BAKES status onto the records it renders,
        -- so handing out the cached shape's own books_meta references would
        -- smear one render's baked status into the next fetch (the stale-
        -- glyph lesson, e7559e6).
        for i = 1, #order do
            local src = meta and meta[i]
            if src and src.filepath == order[i] then
                local b = {}
                for k, v in pairs(src) do b[k] = v end
                books[i] = b
            else
                books[i] = { filepath = order[i] }
            end
        end
    else
        for i, fp in ipairs(order) do
            if i <= 1 then
                -- Full BIM hydration: cover_bb for the single front cover rendered
                -- by SeriesStack. Only one cover is visible per group on the shelf.
                local b = Repo.buildBookMeta(fp)
                if b then books[#books + 1] = b end
            else
                -- Stub: drilldown re-hydrates via _fetchChipItems anyway.
                books[#books + 1] = { filepath = fp }
            end
        end
    end
    return {
        kind         = shape.kind,
        series_name  = shape.series_name,
        books        = books,
        books_meta   = meta,  -- carried for drill-time re-sort
        latest       = shape.latest,
        latest_added = shape.latest_added,
    }
end

-- _buildGroups(group_kind, key_fn, multi, records)
-- Walks the library, groups books by key_fn(book), returns sorted groups.
-- key_fn: (book) -> string | nil  for single-key (multi=false)
-- key_fn: (book) -> table[string] | nil  for multi-key (multi=true)
-- _normalizeGenre(s): case-insensitive + simple-plural-aware key used to
-- group genre strings. "Social Sciences" and "Social Science" collapse
-- into one group; "Mystery" and "mystery" likewise. Strips trailing 's'
-- for words longer than 3 chars (covers most English plurals); rare
-- irregular cases like "series" -> "serie" are acceptable since those
-- aren't typical genre tags.
--
-- Memoized: _buildGroups can call this 12k+ times on a 3k-book library
-- (each book has ~4 genres). With a per-string cache, repeated genre
-- strings (which dominate -- ~50 unique genres in a typical library)
-- cost one lookup after the first parse.
--
-- Only applied for group_kind == "genre" in _buildGroups. Authors keep
-- their case-sensitive identity (case is part of an author's identity
-- on some libraries with stylized spellings). Re-assignment (not
-- `local`) so the forward decl above resolves here.
_normalize_genre_cache = {}
_normalizeGenre = function(s)
    if not s or s == "" then return "" end
    local cached = _normalize_genre_cache[s]
    if cached ~= nil then return cached end
    local lower = s:lower():gsub("^%s+", ""):gsub("%s+$", "")
    if #lower > 3 and lower:sub(-1) == "s" then
        lower = lower:sub(1, -2)
    end
    _normalize_genre_cache[s] = lower
    return lower
end

-- _normalizeAuthor(s): canonical key so "Richard Osman" and
-- "Osman, Richard" group together. AuthorName.surnameOf + .givenOf
-- parse both Calibre conventions; we then concatenate lowercased
-- "given surname". Two variants of the same name produce the same
-- output, so _buildGroups collapses them into one author card. The
-- first-seen variant still drives the displayed series_name, so a
-- user with mostly "Forename Surname" books sees that form on the
-- card even when one of the books is "Surname, Forename".
_normalize_author_cache = {}
local _AuthorName_mod
local function _normalizeAuthor(s)
    if not s or s == "" then return "" end
    local cached = _normalize_author_cache[s]
    if cached ~= nil then return cached end
    if not _AuthorName_mod then
        local ok, mod = pcall(require, "lib/bookshelf_author_name")
        if ok then _AuthorName_mod = mod end
    end
    local key
    if _AuthorName_mod then
        local surname = _AuthorName_mod.surnameOf(s) or ""
        local given   = _AuthorName_mod.givenOf(s)   or ""
        key = (given .. " " .. surname):lower()
                  :gsub("%s+", " ")
                  :gsub("^%s+", ""):gsub("%s+$", "")
        if key == "" then key = s:lower() end
    else
        key = s:lower()
    end
    _normalize_author_cache[s] = key
    return key
end

local _LANG_UNKNOWN_KEY = "__bookshelf_unknown_lang__"

-- _normalizeLang(s): canonical key for grouping by language. Trims and
-- lowercases the input, then drops any region/script suffix ("en-US",
-- "zh_Hans") so library entries that vary only in region collapse into
-- one card. Full-name forms ("English", "français") stay distinct from
-- their codes.
_normalize_lang_cache = {}
_normalizeLang = function(s)
    if not s or s == "" then return "" end
    local cached = _normalize_lang_cache[s]
    if cached ~= nil then return cached end
    local lower = s:lower():gsub("^%s+", ""):gsub("%s+$", "")
    -- "en-US" / "en_US" -> "en". Keep names like "english" untouched.
    local primary = lower:match("^([^-_]+)")
    if primary and #primary >= 2 and #primary <= 3
            and primary:match("^[a-z]+$") then
        lower = primary
    end
    _normalize_lang_cache[s] = lower
    return lower
end

-- _normalizeStatus(s): map any raw KOReader status to the bookshelf
-- vocabulary used by the chip-editor filter UI and the SortEngine.
-- Repo.readProgress already maps "complete" → "finished" and
-- "abandoned" → "on_hold"; here we additionally collapse the
-- nil/"new" cases into "unread" so the filter set can key on a single
-- canonical token per state.
_normalizeStatus = function(s)
    if s == nil or s == "new" then return "unread" end
    return s
end

-- _statusForFp(fp): canonical bookshelf status for a single filepath.
-- Cheap-path checks whether a DocSettings sidecar exists at all — a book
-- without one has never been opened, so its status is "unread" without paying
-- a DocSettings parse. _hasSidecar consults the configured metadata location
-- (#117), so this is correct regardless of where the sidecar lives.
_statusForFp = function(fp)
    if not fp then return "unread" end
    if not _hasSidecar(fp) then return "unread" end
    local _pct, status = Repo.readProgress(fp)
    return _normalizeStatus(status)
end

-- Public tally for the whole walked library, used by the "Shelf size" module.
-- Returns: total book count, and a per-status table keyed by the canonical
-- bookshelf states. Built on _statusForFp, so unopened books (no sidecar)
-- cost nothing beyond the walk, and opened ones hit the progress cache.
function Repo.countByStatus()
    local _done, total, counts = Repo.countByStatusStepper()(nil)
    return total, counts
end

-- Repo.countByStatusStepper() -> step(n) -> done, total, counts
-- The same tally in pieces: each step(n) classifies up to n more books (nil:
-- all of them) and returns done=false until the last, then true with the
-- totals. A cold tally reads every opened book's sidecar, which froze the
-- first full-screen micro-modules open for 3 seconds on a PW5; the Shelf
-- size module runs these steps between UI ticks instead. No UIManager here:
-- the caller owns the scheduling. A finished stepper keeps returning its
-- answer.
function Repo.countByStatusStepper()
    local counts = { unread = 0, reading = 0, on_hold = 0, finished = 0 }
    local paths = Repo.getAllFilepaths()
    local i, total = 0, nil
    return function(n)
        if total then return true, total, counts end
        local stop = n and math.min(#paths, i + n) or #paths
        for j = i + 1, stop do
            local s = _statusForFp(paths[j])
            counts[s] = (counts[s] or 0) + 1
        end
        i = stop
        if i < #paths then return false end
        total = #paths
        -- getAllFilepaths is the WALKED library, which is not the whole shelf:
        -- the Kindle library is on it too, and a user with a Kindle chip was
        -- shown a "shelf size" that left out roughly a third of the books
        -- they can see.
        local k_counts, k_total = _librarySourceStatusCounts()
        if k_counts then
            for status, c in pairs(k_counts) do
                counts[status] = (counts[status] or 0) + c
            end
            total = total + k_total
        end
        return true, total, counts
    end
end

local function _buildGroups(group_kind, key_fn, multi, records)
    local _t0 = _gettime()
    local home  = HomeDir.get() or "/"
    local depth = BookshelfSettings.read("latest_walk_depth") or 3
    -- Read history → filepath read-time map so groups sort by recently-read.
    local rh        = getReadHistory()
    local read_time = {}
    for _i, entry in ipairs(rh.hist) do
        local t = entry.time or 0
        if t > (read_time[entry.file] or 0) then read_time[entry.file] = t end
    end
    -- `records` builds the groups from a source's own catalogue instead of
    -- the filesystem walk, so a Kindle / Kobo chip's filter picker can offer
    -- the values ITS books actually have. Same keying and the same display
    -- names, which is what keeps a value stored by the picker matching what
    -- Filter.matches later compares against.
    local light_cache
    local cands = records
    if not cands then
        cands = cachedWalk(home, depth)
        light_cache = _getLightMetaCache(home, depth)
    end
    local groups = {}
    local order  = {}
    for _i, c in ipairs(cands) do
        -- Lightweight walk: text fields only, no cover_bb.
        -- See _buildBookMetaLight for the memory rationale; shared
        -- light_cache means the second + third group chip (Authors after
        -- Series, Genres after Authors) reuse the same BIM batch read.
        -- A catalogue record IS the book; a walk candidate has to be read.
        local book = records and c or _lightMetaForFp(light_cache, c.fp)
        if book then
            local keys = key_fn(book)
            if keys then
                if not multi then keys = { keys } end
                for _i, raw_k in ipairs(keys) do
                    if raw_k and raw_k ~= "" then
                        -- For language, resolve the canonical key + friendly
                        -- label once (carried into the display block below).
                        local lang_label

                        -- Key on the normalised form per group kind:
                        --   genre  → lowercase + simple plural collapse
                        --            ("Mystery" / "mystery" / "Mysteries")
                        --   author → canonical "given surname" so the
                        --            same person stored as "Forename
                        --            Surname" and "Surname, Forename"
                        --            collapses into one card.
                        --   other  → raw string is the identity.
                        local lookup_k
                        if group_kind == "genre" then
                            lookup_k = _normalizeGenre(raw_k)
                        elseif group_kind == "author" then
                            lookup_k = _normalizeAuthor(raw_k)
                        elseif group_kind == "language" then
                            if raw_k == _LANG_UNKNOWN_KEY then
                                lookup_k = _LANG_UNKNOWN_KEY
                            else
                                local ck, cl = BookshelfLang.canonical(raw_k)
                                lookup_k   = ck or _normalizeLang(raw_k)
                                lang_label = cl
                            end
                        else
                            lookup_k = raw_k
                        end
                        local g = groups[lookup_k]
                        if not g then
                            -- Author group display respects the user's
                            -- "Author name formatting" setting (auto /
                            -- first_last / last_first). "auto" leaves the
                            -- first-seen variant alone; the others force
                            -- a consistent form regardless of how each
                            -- book stored its author.
                            local display_name = raw_k
                            if group_kind == "author" and _AuthorName_mod then
                                local fmt = BookshelfSettings.read("author_format") or "auto"
                                if fmt ~= "auto" then
                                    display_name = _AuthorName_mod.formatted(raw_k, fmt)
                                end
                            elseif group_kind == "language" then
                                if raw_k == _LANG_UNKNOWN_KEY then
                                    display_name = tr("Unknown")
                                else
                                    -- Friendly, localised name from
                                    -- bookshelf_lang (e.g. "English" for any of
                                    -- en / eng / en-GB / English). Falls back to
                                    -- the canonical key if no name resolved.
                                    display_name = lang_label or lookup_k
                                end
                            end
                            g = {
                                kind        = group_kind,
                                series_name = display_name,
                                books       = {},
                                latest      = 0,
                                _seen       = {},
                            }
                            groups[lookup_k] = g
                            order[#order + 1] = lookup_k
                        elseif group_kind ~= "author"
                                and _isTitleCase(raw_k)
                                and not _isTitleCase(g.series_name) then
                            -- Case-insensitive kinds (e.g. genre) merge
                            -- spelling variants; upgrade the displayed label
                            -- to a Title Case spelling when one appears.
                            -- Authors keep their format-driven display.
                            g.series_name = raw_k
                        end
                        if not g._seen[book.filepath] then
                            g._seen[book.filepath] = true
                            -- Enrich the within-group book record with the
                            -- sort-relevant fields available from light meta
                            -- + walk. Enables sort_priority levels 2+ on
                            -- group tabs to order books within each group
                            -- without an extra BIM read at drill time.
                            local rt = read_time[book.filepath] or 0
                            g.books[#g.books + 1] = {
                                filepath     = book.filepath,
                                title        = book.title,
                                series_name  = book.series_name,
                                series_index = tonumber(book.series_num),
                                -- The number as written, for the spine's
                                -- foot (issue 444: members of an author
                                -- group showed no number).
                                series_num   = book.series_num,
                                author       = book.author,
                                authors      = book.authors,
                                genres       = book.genres,
                                lang         = book.lang,
                                _last_read   = rt,
                                -- Walk candidates carry mtime; catalogue
                                -- records carry date_added.
                                date_added   = c.mtime or c.date_added or 0,
                                size         = c.size or 0,
                            }
                        end
                        -- group.latest: strict max READ TIME across
                        -- members (powers "Most recently read"). Books
                        -- that have never been opened (no ReadHistory
                        -- entry) don't contribute -- a genre with zero
                        -- read books ends up at latest=0 and sorts to
                        -- the end via SORT_TO_END. Adding a book to the
                        -- device doesn't count as reading it.
                        local rt = read_time[book.filepath]
                        if rt and rt > g.latest then g.latest = rt end
                        -- group.latest_added: max file mtime across
                        -- members. Powers "Most recently added" --
                        -- changes when files land in your library,
                        -- regardless of read state.
                        local m = c.mtime or c.date_added or 0
                        if m > (g.latest_added or 0) then g.latest_added = m end
                    end
                end
            end
        end
    end
    local list = {}
    for _i, k in ipairs(order) do list[#list + 1] = groups[k] end
    -- Insertion order; getAuthors/getGenres/getTags sort at hydrate time
    -- via _groupShapeCmp on the cached shapes.
    --
    -- Within-group default: series_name -> series_index -> title. Books in
    -- a series cluster together in series order; standalones (no series)
    -- fall to the end via SORT_TO_END and tie-break on title. This is the
    -- baseline that Authors / Genres / Series / Tags / Formats tabs use
    -- until the user overrides via sort_priority levels 2+.
    local default_within = {
        { key = "series_name",  reverse = false },
        { key = "series_index", reverse = false },
        { key = "title",        reverse = false },
    }
    local within_cmp = SortEngine.chainedComparator(default_within)
    for _i, g in ipairs(list) do
        g._seen = nil
        table.sort(g.books, within_cmp)
    end
    logger.dbg(string.format("[bookshelf perf] _buildGroups(%s): %.0fms cands=%d groups=%d",
        group_kind, (_gettime() - _t0) * 1000, #cands, #list))
    return list
end

local function _cacheGroupShapes(list, kind)
    local shapes = {}
    for _i, group in ipairs(list) do
        local fps        = {}
        local books_meta = {}
        for _i, b in ipairs(group.books) do
            fps[#fps + 1] = b.filepath
            -- Copy the sort-relevant fields. Carried in the shape so a
            -- per-tab within-group re-sort (drill-time, sort_priority[2+])
            -- has data without going back to the BIM/light cache.
            -- genres/lang are carried so genre and language filters work
            -- on group chips (authors/genres/tags/formats/languages).
            books_meta[#books_meta + 1] = {
                filepath     = b.filepath,
                title        = b.title,
                series_name  = b.series_name,
                series_index = b.series_index,
                series_num   = b.series_num,
                author       = b.author,
                authors      = b.authors,
                genres       = b.genres,
                lang         = b.lang,
                _last_read   = b._last_read,
                date_added   = b.date_added,
                size         = b.size,
            }
        end
        shapes[#shapes + 1] = {
            kind         = kind,
            series_name  = group.series_name,
            -- An AUTHOR card sorts under the author it is NAMED AFTER, so
            -- carry that name as the shape's own author. Without it the
            -- comparator falls back to the modal MEMBER author -- and a
            -- member's `author` field is the book's FIRST author, so a
            -- co-authored book filed the second author's card under the
            -- first author's surname, right next to it on the shelf
            -- (device report: "Halper, Phil" sorted between the A's,
            -- glued to "Afshordi").
            author       = kind == "author" and group.series_name or nil,
            filepaths    = fps,
            books_meta   = books_meta,
            latest       = group.latest,
            latest_added = group.latest_added or 0,
        }
    end
    return shapes
end

function Repo.getAuthors(limit, offset, sort_priority_override, filter, opts)
    local _t0 = _gettime()
    local home  = HomeDir.get() or "/"
    local depth = BookshelfSettings.read("latest_walk_depth") or 3
    local key   = (home or "/") .. ":" .. tostring(depth or 0)
    local now   = os.time()
    local cached = _authors_cache[key]
    local _hit = cached
    if not _hit then
        -- Multi-author indexing: a book co-authored by A & B & C appears
        -- under each of A, B, and C in the Authors view. Pre-#74 the key
        -- was b.author (= authors[1]) with multi=false, so co-authors were
        -- silently dropped from the Authors tab. Matches the existing
        -- Genres pattern (multi=true) and Calibre's Authors browser.
        local list = _buildGroups("author", function(b) return b.authors end, true)
        _authors_cache[key] = {
            groups     = _cacheGroupShapes(list, "author"),
            expires_at = now + SERIES_CACHE_TTL,
        }
        cached = _authors_cache[key]
    end
    -- Always hydrate (even right after a build): _buildGroups can reuse
    -- the same Book record across groups when a book has multiple keys,
    -- and the resulting shared cover_bb segfaults when one SeriesStack
    -- frees it while another still holds the reference. Hydrating from
    -- shapes calls buildBookMeta per group → independent cover_bbs.
    --
    -- sort_priority_override: when a CUSTOM tab uses kind="authors" as its
    -- source (the user repurposed e.g. the Home tab to show the Authors
    -- view), getBySource passes that tab's sort_priority through here so
    -- the user's sort applies. Without it we'd hardcode the lookup to
    -- tab_id="authors" and miss any tab whose id is different.
    local sk = sort_priority_override or Repo.getSortPriority("authors")
    local within = _withinPriority(sk)
    local sorted = {}
    for _i, s in ipairs(cached.groups) do
        if _shapeHasFilteredBook(s, filter) then sorted[#sorted + 1] = s end
    end
    table.sort(sorted, _groupShapeCmp(sk))
    local total = #sorted
    local out   = {}
    offset      = offset or 0
    _attachFlattenedCounts(out, sorted, offset)
    local stop  = _hydrationStop(offset, limit, total, 8, "getAuthors",
                                 (opts and opts.light_only) or Repo.spine_light)
    for i = offset + 1, stop do
        out[#out + 1] = _hydrateGroupShape(sorted[i], within, filter, opts and opts.light_only)
    end
    logger.dbg(string.format("[bookshelf perf] getAuthors: %s %.0fms groups=%d/%d",
        _hit and "HIT" or "MISS", (_gettime() - _t0) * 1000, #out, total))
    return out, total
end

-- _prefetchSortProgress(recs, sort_priority, tag)
--
-- Light records carry no sidecar facts, so a sort on status, percent, rating
-- or page count compares nil with nil and keeps the arrival order. Reads them
-- here, only when the sort actually asks. Shared by getBySource and
-- getFolderSections; the second lacked it and its spine shelves ignored
-- "Reading 1st" (#534).
--
-- Fast path: check .sdr existence with a single lfs.attributes() call BEFORE
-- the much-heavier DocSettings:open(). Unread books have no sidecar, and
-- would otherwise pay ~50ms per book to learn that. On a typical library
-- where ~70% of books are unread, this gives a 3-10x speedup over an
-- unconditional readProgress per candidate. Even when the sdr exists,
-- Repo.readProgress hits its _progress_cache (120s TTL) so re-sorts within
-- the same session are cheap.
local function _prefetchSortProgress(recs, sort_priority, tag)
    local needs_progress = false
    if sort_priority then
        for _i, lv in ipairs(sort_priority) do
            local k = lv.key
            if k == "percent_read"
                    or k == "read_status"
                    or k == "read_status_active"
                    or k == "rating"
                    or k == "page_count" then
                -- 'rating' and 'page_count' both come back from
                -- Repo.readProgress (summary.rating + the sidecar page
                -- map), so they piggyback on the same prefetch.
                needs_progress = true
                break
            end
        end
    end
    if not needs_progress then return end
    local _t0 = _gettime()
    local fast_skipped, full_read = 0, 0
    for _i, b in ipairs(recs) do
        if not b._progress_fetched and b.filepath then
            local has_sdr = _hasSidecar(b.filepath)
            if has_sdr then
                local pct, status, rating, page_count = Repo.readProgress(b.filepath)
                b._pct       = pct
                b._status    = status
                b.rating     = b.rating or Repo.effectiveRating(b.filepath, rating)
                b.page_count = b.page_count or page_count
                full_read    = full_read + 1
            else
                b._pct      = nil
                b._status   = nil
                -- No sidecar: no rating of the reader's own and no page map.
                -- A Hardcover rating can still stand in (effectiveRating).
                b.rating     = b.rating or Repo.effectiveRating(b.filepath, nil)
                fast_skipped = fast_skipped + 1
            end
            b._progress_fetched = true
        end
    end
    logger.dbg(string.format(
        "[bookshelf perf] %s sort-needs progress: %.0fms full=%d skipped=%d/%d",
        tag or "", (_gettime() - _t0) * 1000, full_read, fast_skipped, #recs))
end

-- ─── Home folders, as shelf sections ────────────────────────────────────────
--
-- The Home-folders source arranged the way the SPINE shelf reads a library:
-- the books in tree order, each TAGGED with the folder it lives in, so the
-- plan can badge each run of consecutive books that share a tag with the
-- folder's name. lib/bookshelf_folder_sections.lua holds the grouping rules
-- (tree order, the wrapper-folder fold) and is tested headless.
--
-- Books rather than sections are deliberately the items. The spine cursor
-- counts ITEMS and a page shows whole ones, so making a folder an item ties
-- pagination to section size: a folder with more books than fit a page could
-- never be shown past its first page, and the cursor would step over the
-- remainder (the "a group larger than a page can be advanced past" rule in
-- SpineShelf.plan, which series and authors survive only because a group that
-- big is rare). One item per book has no such ceiling, and a section running
-- across a page break simply repeats its badge on the next shelf.
--
-- This is NOT what getAll returns. getAll produces the tree view -- a folder
-- card you tap to descend -- which is right for the cover and list shelves,
-- where folder styles and drill-in live. Edge-on there is nothing to tap
-- into: the books already stand on the shelf, so a folder is a section label
-- rather than a destination.
--
-- Costs nothing the Home chip was not already paying: the walk is the cached
-- one every fetcher shares, and records come from the batched blob-free light
-- map, so a whole shelf costs no cover decode at all.
-- opts.root: the folder whose contents to section, when it is not the whole
-- library -- a folder drilled into, or a shelf sourced to one. Its books
-- spill out as labelled runs exactly as Home's do, never as a folder standing
-- on the shelf edge-on like a book (maintainer: "we can't show folders as
-- books"). Under the library root it reuses the library's own walk and
-- light-meta cache, so opening a folder costs no second pass over the disk;
-- a folder outside it is walked on its own.
function Repo.getFolderSections(limit, offset, sort_priority_override, filter, opts)
    local _t0 = _gettime()
    local lib_root = _resolveLibraryRoot()
    local root = (opts and opts.root) or lib_root
    if not root then
        logger.warn("[bookshelf] getFolderSections: home_dir not configured; refusing to walk")
        return {}, 0
    end
    while #root > 1 and root:sub(-1) == "/" do root = root:sub(1, -2) end
    local depth = BookshelfSettings.read("latest_walk_depth") or 3
    local walk_root = root
    if lib_root and root ~= lib_root then
        local lr = lib_root
        while #lr > 1 and lr:sub(-1) == "/" do lr = lr:sub(1, -2) end
        if root:sub(1, #lr + 1) == lr .. "/" then walk_root = lr end
    end
    local walk = cachedWalk(walk_root, depth)
    if walk_root ~= root then
        local prefix, inside = root .. "/", {}
        for i = 1, #walk do
            local c = walk[i]
            local fp = c and (c.fp or c)
            if type(fp) == "string" and fp:sub(1, #prefix) == prefix then
                inside[#inside + 1] = c
            end
        end
        walk = inside
    end
    local FolderSections = require("lib/bookshelf_folder_sections")
    local sections = FolderSections.group(walk, root)
    -- KOReader's "folders and files mixed", which getAll honours for the
    -- tree view by putting every folder before every file. The spine shelf
    -- reads the same library through this producer instead, and it never
    -- asked: sections come out in TREE order, which puts the root's own
    -- loose books first because the walk starts there. With the setting off
    -- and the chip sorted by date added, that showed the newest root book
    -- ahead of everything and the first folder pages later -- the opposite
    -- of what cover and list mode showed from the same settings (reported
    -- on a Home shelf).
    --
    -- The sections ARE the folders here and the label-less one is the root's
    -- loose files, so the partition is a single move: everything else keeps
    -- its tree order, and a folder still stands with its own books.
    local mixed = G_reader_settings
                  and G_reader_settings:isTrue("collate_mixed") or false
    if not mixed then
        local folders, loose = {}, {}
        for i = 1, #sections do
            local s = sections[i]
            if s.label then folders[#folders + 1] = s
            else             loose[#loose + 1] = s end
        end
        if #loose > 0 and #folders > 0 then
            sections = folders
            for i = 1, #loose do sections[#sections + 1] = loose[i] end
        end
    end
    -- The walk already statted every file, so carry mtime and size across:
    -- a chip sorted by "Added" or by file size has something to compare on
    -- without a second pass over the filesystem.
    local stat = {}
    for i = 1, #walk do
        local c = walk[i]
        if c and c.fp then stat[c.fp] = c end
    end

    -- The chip's own sort orders the books WITHIN a section. It deliberately
    -- does not reorder the sections themselves: those stand in tree order so
    -- a folder and everything under it stay together on the shelf, which is
    -- the point of showing the structure at all.
    local sp = sort_priority_override
    if not sp or #sp == 0 then sp = Repo.getSortPriority("all") end
    local light_cache = _getLightMetaCache(walk_root, depth)
    -- History times for "Opened" / "Added or opened", the same enrichment
    -- the predicate path gives its light records. Built only when asked.
    local read_time
    if sp then
        for _i, lv in ipairs(sp) do
            if lv.key == "last_opened" or lv.key == "added_or_opened" then
                read_time = {}
                for _j, entry in ipairs(getReadHistory().hist) do
                    local t = entry.time or 0
                    if t > (read_time[entry.file] or 0) then read_time[entry.file] = t end
                end
                break
            end
        end
    end
    local ordered = {}
    for si = 1, #sections do
        local s = sections[si]
        local recs = {}
        for i = 1, #s.fps do
            local fp  = s.fps[i]
            local rec = _lightMetaForFp(light_cache, fp) or { fp = fp, filepath = fp }
            -- Immutable file facts, filled in where the light row has none.
            -- Safe to write onto a shared record -- unlike render state,
            -- which is why the window below hands out copies.
            local c = stat[fp]
            if c then
                if not rec.date_added then rec.date_added = c.mtime or 0 end
                if not rec.size then rec.size = c.size or 0 end
            end
            if read_time then rec._last_read = read_time[fp] or 0 end
            recs[#recs + 1] = rec
        end
        if _filterIsActive(filter) then recs = _applyFilter(recs, filter) end
        if #recs > 1 and sp and #sp > 0 then
            _prefetchSortProgress(recs, sp, "getFolderSections")
            local SortEngine = require("lib/bookshelf_sort_engine")
            SortEngine.sort(recs, sp)
        end
        for i = 1, #recs do
            ordered[#ordered + 1] = { rec = recs[i], section = s }
        end
    end

    local total = #ordered
    offset = offset or 0
    local stop = _hydrationStop(offset, limit, total, 8, "getFolderSections",
                                (opts and opts.light_only) or Repo.spine_light)
    local out = {}
    for i = offset + 1, stop do
        local e = ordered[i]
        -- A COPY per fetch. The spine plan BAKES status onto the records it
        -- renders, and the light map is shared and memoised, so handing out
        -- its own records smears one render's baked status into the next
        -- fetch (the stale reading-glyph lesson, e7559e6).
        local b = {}
        for k, v in pairs(e.rec) do b[k] = v end
        b.shelf_section      = e.section.label
        b.shelf_section_path = e.section.path
        out[#out + 1] = b
    end
    logger.dbg(string.format(
        "[bookshelf perf] getFolderSections: %.0fms books=%d/%d sections=%d",
        (_gettime() - _t0) * 1000, #out, total, #sections))
    return out, total
end

function Repo.getGenres(limit, offset, sort_priority_override, filter, opts)
    local _t0 = _gettime()
    local home  = HomeDir.get() or "/"
    local depth = BookshelfSettings.read("latest_walk_depth") or 3
    local key   = (home or "/") .. ":" .. tostring(depth or 0)
    local now   = os.time()
    local cached = _genres_cache[key]
    local _hit = cached
    if not _hit then
        local list = _buildGroups("genre", function(b) return b.genres end, true)
        _genres_cache[key] = {
            groups     = _cacheGroupShapes(list, "genre"),
            expires_at = now + SERIES_CACHE_TTL,
        }
        cached = _genres_cache[key]
    end
    -- Always hydrate from shapes — see getAuthors above. For genres
    -- (multi=true), a single book in "Sci-Fi, Fantasy" appears in both
    -- groups; without fresh Book records per group both SeriesStacks
    -- share the same cover_bb and the first to free it segfaults the
    -- second. This was the cause of the genres-tab crash on first tap.
    local sk = sort_priority_override or Repo.getSortPriority("genres")
    local within = _withinPriority(sk)
    -- Same single-book-stack rule as series (issue #127), applied here so a
    -- genre with one poorly-tagged book can be hidden too.
    local hide_single = BookshelfSettings.isTrue("hide_single_book_stacks")
    local sorted = {}
    for _i, s in ipairs(cached.groups) do
        if _shapeVisible(s, filter, hide_single) then sorted[#sorted + 1] = s end
    end
    table.sort(sorted, _groupShapeCmp(sk))
    local total = #sorted
    local out   = {}
    offset      = offset or 0
    _attachFlattenedCounts(out, sorted, offset)
    local stop  = _hydrationStop(offset, limit, total, 8, "getGenres",
                                 (opts and opts.light_only) or Repo.spine_light)
    for i = offset + 1, stop do
        out[#out + 1] = _hydrateGroupShape(sorted[i], within, filter, opts and opts.light_only)
    end
    logger.dbg(string.format("[bookshelf perf] getGenres: %s %.0fms groups=%d/%d",
        _hit and "HIT" or "MISS", (_gettime() - _t0) * 1000, #out, total))
    return out, total
end

-- Lightweight choice list for the "Specific Series / Author / Genre / Format"
-- picker. Returns [{value, label, count}, ...] without hydrating book records
-- or loading cover_bbs. Reads directly from the cached shapes so calling
-- this is a single table iteration on cached data once the underlying cache
-- is warm. For a 200-author library this is ~ms vs ~1-2s for the previous
-- path that ran _hydrateGroupShape on every group (one buildBookMeta +
-- cover decompression per group, ALL of it discarded by the picker).
function Repo.getGroupChoices(kind)
    local home  = HomeDir.get() or "/"
    local depth = BookshelfSettings.read("latest_walk_depth") or 3
    local key   = (home or "/") .. ":" .. tostring(depth or 0)

    local cache_for_kind = {
        series   = _series_cache,
        author   = _authors_cache,
        genre    = _genres_cache,
        format   = _formats_cache,
        rating   = _ratings_cache,
        language = _languages_cache,
    }
    local store = cache_for_kind[kind]
    if not store then return {} end

    -- Ensure the underlying cache is built. limit=0 makes the fetcher's
    -- hydration loop skip while still running the cache-build + sort.
    if not store[key] then
        if     kind == "series"   then Repo.getSeriesGroups(0, 0)
        elseif kind == "author"   then Repo.getAuthors(0, 0)
        elseif kind == "genre"    then Repo.getGenres(0, 0)
        elseif kind == "format"   then Repo.getFormats(0, 0)
        elseif kind == "rating"   then Repo.getRatings(0, 0)
        elseif kind == "language" then Repo.getLanguages(0, 0)
        end
    end

    local cache = store[key]
    if not cache or not cache.groups then return {} end

    local out = {}
    for _i, s in ipairs(cache.groups) do
        out[#out + 1] = {
            value = s.series_name or "",
            label = s.series_name or "",
            count = s.filepaths and #s.filepaths or 0,
        }
    end
    return out
end

-- getGroupFilepaths(kind): mirrors getGroupChoices but returns { [value] =
-- { filepath, ... }, ... } from the cached shapes. value = the series_name the
-- group cache uses (same key distinctFilterValues emits) so callers can cross-
-- reference with filter selections. No hydration, no cover decompression.
function Repo.getGroupFilepaths(kind)
    local home  = HomeDir.get() or "/"
    local depth = BookshelfSettings.read("latest_walk_depth") or 3
    local key   = (home or "/") .. ":" .. tostring(depth or 0)

    local cache_for_kind = {
        series   = _series_cache,
        author   = _authors_cache,
        genre    = _genres_cache,
        format   = _formats_cache,
        rating   = _ratings_cache,
        language = _languages_cache,
    }
    local store = cache_for_kind[kind]
    if not store then return {} end

    -- Ensure the underlying cache is built (same pattern as getGroupChoices).
    if not store[key] then
        if     kind == "series"   then Repo.getSeriesGroups(0, 0)
        elseif kind == "author"   then Repo.getAuthors(0, 0)
        elseif kind == "genre"    then Repo.getGenres(0, 0)
        elseif kind == "format"   then Repo.getFormats(0, 0)
        elseif kind == "rating"   then Repo.getRatings(0, 0)
        elseif kind == "language" then Repo.getLanguages(0, 0)
        end
    end

    local cache = store[key]
    if not cache or not cache.groups then return {} end

    local out = {}
    for _i, s in ipairs(cache.groups) do
        out[s.series_name or ""] = s.filepaths or {}
    end
    return out
end

-- filterValueCounts(dim, filter): faceted counts for dimension `dim` under
-- `filter`. For each value in dim, returns how many books pass (filter minus
-- dim) AND have that value. Returns nil when no OTHER dimension is active
-- (caller uses static totals). nil for statuses/folders (out of scope).
--
-- Light records are built once per call via the batch BIM cache; no covers
-- are decompressed. Status/rating resolution is sidecar-gated (_hasSidecar)
-- via _recordMatches. Rating is special-cased: the cache keys by star glyphs
-- but distinctFilterValues("ratings") keys by "1".."5"/"unrated", so we
-- re-bucket explicitly.
function Repo.filterValueCounts(dim, filter, source)
    if dim == "statuses" or dim == "folders" then return nil end
    -- reduced = filter minus `dim`
    local reduced = {}
    for k, v in pairs(filter or {}) do if k ~= dim then reduced[k] = v end end
    if not Filter.isActive(reduced) then return nil end  -- fast path: no other dim
    local compiled = Filter.compile(reduced, Repo.filterOpts())

    local scoped = _sourceFilterCounts(dim, compiled, source)
    if scoped then return scoped end

    local home  = HomeDir.get() or "/"
    local depth = BookshelfSettings.read("latest_walk_depth") or 3

    if dim == "collections" then
        local rc = getCollections()
        if not rc or not rc.coll then return {} end
        local light_cache = _getLightMetaCache(home, depth)
        local counts = {}
        for name, coll in pairs(rc.coll) do
            if name ~= "favorites" then
                local n = 0
                for filepath in pairs(coll) do
                    local rec = _lightMetaForFp(light_cache, filepath)
                    if rec and _recordMatches(rec, compiled) then n = n + 1 end
                end
                counts[name] = n
            end
        end
        return counts
    end

    -- Ratings: the group cache uses star-glyph series_names; distinctFilterValues
    -- uses "1".."5"/"unrated". Re-walk the library and bucket by numeric key.
    if dim == "ratings" then
        local light_cache = _getLightMetaCache(home, depth)
        local cands = cachedWalk(home, depth)
        local counts = { unrated = 0 }
        for i = 1, 5 do counts[tostring(i)] = 0 end
        for _i, c in ipairs(cands) do
            local rec = _lightMetaForFp(light_cache, c.fp)
            if rec and _recordMatches(rec, compiled) then
                -- Explicitly resolve rating (always needed here to bucket).
                local rating_val
                if _hasSidecar(c.fp) then
                    local _p, _s, r = Repo.readProgress(c.fp)
                    rating_val = r
                end
                local bucket = (rating_val and rating_val > 0)
                    and tostring(math.floor(rating_val)) or "unrated"
                counts[bucket] = (counts[bucket] or 0) + 1
            end
        end
        return counts
    end

    local kind = ({ genres = "genre", langs = "language",
                    formats = "format" })[dim]
    if not kind then return nil end
    local groups = Repo.getGroupFilepaths(kind)
    local light_cache = _getLightMetaCache(home, depth)
    local counts = {}
    for value, fps in pairs(groups) do
        local n = 0
        for _i, fp in ipairs(fps) do
            local rec = _lightMetaForFp(light_cache, fp)
            if rec and _recordMatches(rec, compiled) then n = n + 1 end
        end
        counts[value] = n
    end
    return counts
end

-- getFolderChoices: every directory under home_dir that contains a book at any
-- depth, surfaced as picker choices for the "Specific folder…" chip source.
-- Walks the cached library file list (no fresh lfs scan) and collects every
-- ancestor of every book between home_dir (exclusive) and the book's filename.
-- Stored without a trailing slash so the path matches what Repo.getAll(path)
-- expects (its _joinPath would otherwise double-slash) and what the Home-
-- folders drilldown writes (shape.path = raw lfs entry, no trailing slash).
-- Sorted by lowercased full path so siblings naturally group under parents.
function Repo.getFolderChoices()
    local home  = HomeDir.get() or "/"
    local depth = BookshelfSettings.read("latest_walk_depth") or 3
    local cands = cachedWalk(home, depth)
    -- home == "/" is kept as literal so the loop's parent ~= home_norm check
    -- terminates at root; for any other home we strip trailing slashes so the
    -- equality compares cleanly.
    local home_norm = home == "/" and "/" or home:gsub("/+$", "")

    local seen = {}
    for _i, c in ipairs(cands) do
        local fp = c.fp or ""
        local parent = fp:match("^(.*)/[^/]+$")
        while parent and parent ~= "" and parent ~= home_norm do
            seen[parent] = true
            parent = parent:match("^(.*)/[^/]+$")
        end
    end

    local out = {}
    for path in pairs(seen) do
        local basename = path:match("([^/]+)$") or path
        out[#out + 1] = { value = path, label = _flipTrailingArticle(basename), subtitle = path }
    end
    table.sort(out, function(a, b) return a.value:lower() < b.value:lower() end)
    return out
end

-- getAllFolderChoices: every directory under home_dir within the walk
-- depth, INCLUDING empty ones -- unlike getFolderChoices (book-bearing
-- only, derived from the cached book walk). Move destinations
-- legitimately include folders holding no books yet. Directory-only
-- lfs walk, no per-file stats, so cheap even on large libraries.
-- Depth arithmetic matches walkBooks: level-N dirs (N <= depth) can
-- hold shelf-visible books.
function Repo.getAllFolderChoices()
    local home  = HomeDir.get() or "/"
    local depth = BookshelfSettings.read("latest_walk_depth") or 3
    local home_norm = home == "/" and "/" or home:gsub("/+$", "")
    local ok_lfs, lfs = pcall(require, "libs/libkoreader-lfs")
    if not (ok_lfs and lfs and lfs.dir) then return {} end
    local out = {}
    local function walk(root, level)
        if level > depth then return end
        local ok, iter, dir_obj = pcall(lfs.dir, root)
        if not ok or type(iter) ~= "function" then return end
        for entry in iter, dir_obj do
            if entry:sub(1, 1) ~= "." and not SYSTEM_DIR_NAMES[entry]
                    and entry:sub(-4) ~= ".sdr" then
                local fp = _joinPath(root, entry)
                if lfs.attributes(fp, "mode") == "directory" then
                    out[#out + 1] = { value = fp, label = entry, subtitle = fp }
                    walk(fp, level + 1)
                end
            end
        end
    end
    walk(home_norm, 1)
    table.sort(out, function(a, b) return a.value:lower() < b.value:lower() end)
    return out
end

-- Build a normalized format string from a filepath. UPPERCASE because that's
-- how the rest of bookshelf (book detail, etc.) presents formats. Returns nil
-- for files with no extension so _buildGroups skips them.
local function _formatKey(fp)
    return _formatLabel(fp)
end

-- ─── Source-scoped filter pickers ───────────────────────────────────────────
-- A chip's filter picker describes THAT chip's source. Both halves of it -- the
-- value list and the faceted counts -- used to come from the walked library, so
-- editing a Kindle or Kobo chip's filter offered the local library's genres and
-- counted local books against them: values that match nothing on the chip they
-- belong to. Harmless while those chips ignored their filters; misleading from
-- the moment they started applying them.
--
-- Only catalogue-backed sources are redirected. They are flat, local and
-- already in memory. OPDS is deliberately NOT included: answering "which
-- genres are there?" for a remote catalogue means a network fetch, and opening
-- a filter picker must never reach the network. Walk-backed chips keep the
-- group-cache path, which is faster than anything rebuilt per record here.
--
-- _sourceRecordsFor(source): the records a picker should describe, or nil to
-- leave the caller on its existing path.
--
-- The gate is availability ALONE, deliberately not _librarySourceBooks():
-- the user is editing a chip of this kind, which is a stronger opt-in than
-- having one saved -- and a chip being created for the first time is not in
-- TabModel yet, so the saved-chip gate would fail exactly when the picker is
-- first opened.
local function _sourceRecordsFor(source)
    local kind = (type(source) == "table") and source.kind or nil
    if not kind then return nil end
    local Sources = require("lib/bookshelf_sources")
    if not Sources.get(kind) then return nil end
    return Sources.list(kind, source)
end

-- The group kind and key function each filter dimension corresponds to, so a
-- picker built from a catalogue keys and labels its values EXACTLY as the walk
-- would. Mirrors the getGenres / getLanguages / getFormats callers below.
local _DIM_GROUP = {
    genres  = { kind = "genre",    multi = true,
                key_fn = function(b) return b.genres end },
    langs   = { kind = "language", multi = false,
                key_fn = function(b)
                    local v = b.lang
                    if v == nil or v == "" then return _LANG_UNKNOWN_KEY end
                    return v
                end },
    -- A record that states its own format wins: that field is exactly what
    -- Filter.matches compares, so keying on anything else lets the picker offer
    -- a value that cannot match the book it came from. Walked books carry no
    -- format at group-build time and keep the path-derived key, unchanged.
    formats = { kind = "format",   multi = false,
                key_fn = function(b) return b.format or _formatKey(b.filepath) end },
}

-- Genres on catalogue records come from Hardcover, and that enrichment is
-- normally applied to the visible slice only -- so a picker asking "which
-- genres are here?" would see none of them. Same fix as the filter path, and
-- cache-only: no network.
local function _enrichRecordGenres(records)
    local Hardcover = getHardcover()
    if not (Hardcover and Hardcover.applyMetadata) then return end
    for i = 1, #records do pcall(Hardcover.applyMetadata, records[i]) end
end

-- Group `records` for `dim` and return { value, label, count } entries, or nil
-- when the dimension is not one the group cache models.
local function _recordChoices(records, dim)
    local spec = _DIM_GROUP[dim]
    if not spec then return nil end
    local list = _buildGroups(spec.kind, spec.key_fn, spec.multi, records)
    local out = {}
    for _i, g in ipairs(list) do
        out[#out + 1] = {
            value = g.series_name or "",
            label = g.series_name or "",
            count = g.books and #g.books or 0,
        }
    end
    table.sort(out, function(a, b) return a.label < b.label end)
    return out
end

-- The filepaths a record set covers, for intersecting with collections.
local function _recordPathSet(records)
    local set = {}
    for i = 1, #records do
        local fp = records[i].filepath
        if fp then set[fp] = true end
    end
    return set
end

_sourceFilterChoices = function(dim, source)
    local records = _sourceRecordsFor(source)
    if not records then return nil end
    -- Ratings are a fixed six-bucket list and identical for every source, so
    -- there is nothing to scope: let the caller's own list stand.
    if dim == "ratings" then return nil end
    if dim == "collections" then
        local rc = getCollections()
        if not (rc and rc.coll) then return {} end
        local in_source = _recordPathSet(records)
        local out = {}
        for name, coll in pairs(rc.coll) do
            if name ~= "favorites" then
                local n = 0
                for fp in pairs(coll) do if in_source[fp] then n = n + 1 end end
                -- A collection holding none of this source's books is not a
                -- value this chip can filter by, so it is not offered -- the
                -- same reason a genre no book has never appears.
                if n > 0 then
                    out[#out + 1] = { value = name, label = name, count = n }
                end
            end
        end
        table.sort(out, function(a, b) return a.label < b.label end)
        return out
    end
    if dim == "genres" then _enrichRecordGenres(records) end
    return _recordChoices(records, dim)
end

_sourceFilterCounts = function(dim, compiled, source)
    local records = _sourceRecordsFor(source)
    if not records then return nil end
    -- Genres have to be on the records before either the filter or the tally
    -- can see them.
    if dim == "genres" or compiled.genres then _enrichRecordGenres(records) end
    local kept = {}
    for i = 1, #records do
        if _recordMatches(records[i], compiled) then kept[#kept + 1] = records[i] end
    end
    if dim == "collections" then
        local rc = getCollections()
        if not (rc and rc.coll) then return {} end
        local in_kept = _recordPathSet(kept)
        local counts = {}
        for name, coll in pairs(rc.coll) do
            if name ~= "favorites" then
                local n = 0
                for fp in pairs(coll) do if in_kept[fp] then n = n + 1 end end
                counts[name] = n
            end
        end
        return counts
    end
    if dim == "ratings" then
        local counts = { unrated = 0 }
        for i = 1, 5 do counts[tostring(i)] = 0 end
        for i = 1, #kept do
            local rec = kept[i]
            -- _recordMatches only resolves the rating when the filter asks for
            -- one, and the reduced filter never does -- it is this dimension.
            local r = rec.rating
            if r == nil and rec.filepath and _hasSidecar(rec.filepath) then
                local _p, _s, rr = Repo.readProgress(rec.filepath)
                r = rr
            end
            local bucket = (r and r > 0) and tostring(math.floor(r)) or "unrated"
            counts[bucket] = (counts[bucket] or 0) + 1
        end
        return counts
    end
    local list = _recordChoices(kept, dim)
    if not list then return nil end
    local counts = {}
    for _i, c in ipairs(list) do counts[c.value] = c.count end
    return counts
end

function Repo.getFormats(limit, offset, sort_priority_override, filter, opts)
    local _t0 = _gettime()
    local home  = HomeDir.get() or "/"
    local depth = BookshelfSettings.read("latest_walk_depth") or 3
    local key   = (home or "/") .. ":" .. tostring(depth or 0)
    local now   = os.time()
    local cached = _formats_cache[key]
    local _hit = cached
    if not _hit then
        local list = _buildGroups("format", function(b) return _formatKey(b.filepath) end, false)
        _formats_cache[key] = {
            groups     = _cacheGroupShapes(list, "format"),
            expires_at = now + SERIES_CACHE_TTL,
        }
        cached = _formats_cache[key]
    end
    -- Hydrate from shapes for the same reason as authors/genres -- _buildGroups
    -- reuses Book records across groups, and shared cover_bb would segfault on
    -- the second free.
    local sk = sort_priority_override or Repo.getSortPriority("formats")
    local within = _withinPriority(sk)
    local sorted = {}
    for _i, s in ipairs(cached.groups) do
        if _shapeHasFilteredBook(s, filter) then sorted[#sorted + 1] = s end
    end
    table.sort(sorted, _groupShapeCmp(sk))
    local total = #sorted
    local out   = {}
    offset      = offset or 0
    local stop  = _hydrationStop(offset, limit, total, 8, "getFormats",
                                 (opts and opts.light_only) or Repo.spine_light)
    for i = offset + 1, stop do
        out[#out + 1] = _hydrateGroupShape(sorted[i], within, filter, opts and opts.light_only)
    end
    logger.dbg(string.format("[bookshelf perf] getFormats: %s %.0fms groups=%d/%d",
        _hit and "HIT" or "MISS", (_gettime() - _t0) * 1000, #out, total))
    return out, total
end

-- getLanguages: group books by their ebook language metadata. Single-key
-- per book (a book is filed under exactly one language card).
-- Books without a language are filed as 'Unknown'
function Repo.getLanguages(limit, offset, sort_priority_override, filter, opts)
    local _t0 = _gettime()
    local home  = HomeDir.get() or "/"
    local depth = BookshelfSettings.read("latest_walk_depth") or 3
    local key   = (home or "/") .. ":" .. tostring(depth or 0)
    local now   = os.time()
    local cached = _languages_cache[key]
    local _hit = cached
    if not _hit then
        local list = _buildGroups("language",
            function(b)
                local v = b.lang
                if v == nil or v == "" then return _LANG_UNKNOWN_KEY end
                return v
            end, false)
        _languages_cache[key] = {
            groups     = _cacheGroupShapes(list, "language"),
            expires_at = now + SERIES_CACHE_TTL,
        }
        cached = _languages_cache[key]
    end
    local sk = sort_priority_override or Repo.getSortPriority("languages")
    local within = _withinPriority(sk)
    local sorted = {}
    for _i, s in ipairs(cached.groups) do
        if _shapeHasFilteredBook(s, filter) then sorted[#sorted + 1] = s end
    end
    table.sort(sorted, _groupShapeCmp(sk))
    local total = #sorted
    local out   = {}
    offset      = offset or 0
    _attachFlattenedCounts(out, sorted, offset)
    local stop  = _hydrationStop(offset, limit, total, 8, "getLanguages",
                                 (opts and opts.light_only) or Repo.spine_light)
    for i = offset + 1, stop do
        out[#out + 1] = _hydrateGroupShape(sorted[i], within, filter, opts and opts.light_only)
    end
    logger.dbg(string.format("[bookshelf perf] getLanguages: %s %.0fms groups=%d/%d",
        _hit and "HIT" or "MISS", (_gettime() - _t0) * 1000, #out, total))
    return out, total
end

-- UTF-8 star characters for the rating group display labels. Used as
-- the group's series_name so chip + breadcrumb render '★★★★★' etc.
local _STAR_REPEAT = {
    [1] = "\xE2\x98\x85",
    [2] = "\xE2\x98\x85\xE2\x98\x85",
    [3] = "\xE2\x98\x85\xE2\x98\x85\xE2\x98\x85",
    [4] = "\xE2\x98\x85\xE2\x98\x85\xE2\x98\x85\xE2\x98\x85",
    [5] = "\xE2\x98\x85\xE2\x98\x85\xE2\x98\x85\xE2\x98\x85\xE2\x98\x85",
}

-- Build the rating groups: walk the library, look up each book's
-- rating via Repo.readProgress (cached + .sdr fast-path), bucket by
-- rating value or 'Unrated'. Books without a .sdr are treated as
-- Unrated without a DocSettings open.
local function _buildRatingGroups()
    local home  = HomeDir.get() or "/"
    local depth = BookshelfSettings.read("latest_walk_depth") or 3
    local cands = cachedWalk(home, depth)
    local light_cache = _getLightMetaCache(home, depth)
    local rh         = getReadHistory()
    local read_time  = {}
    for _i, entry in ipairs(rh.hist) do
        local t = entry.time or 0
        if t > (read_time[entry.file] or 0) then read_time[entry.file] = t end
    end
    local buckets = { [1]={}, [2]={}, [3]={}, [4]={}, [5]={}, unrated={} }
    for _i, c in ipairs(cands) do
        local book = _lightMetaForFp(light_cache, c.fp)
        if book then
            local rating
            if _hasSidecar(c.fp) then
                local _p, _s, r = Repo.readProgress(c.fp)
                rating = r
            end
            -- To whole stars for the buckets, with the Hardcover stand-in.
            rating = Repo.effectiveRatingStars(c.fp, rating)
            -- Bucket key: only an integer 1..5 is a star bucket; everything
            -- else (nil, 0 = KOReader's "no rating", a float, out of range)
            -- is Unrated. NB 0 is TRUTHY in Lua, so `rating or "unrated"`
            -- would key buckets[0] (nil) and crash on #bucket below.
            local bk = "unrated"
            if type(rating) == "number" then
                local r = math.floor(rating)
                if r >= 1 and r <= 5 then bk = r end
            end
            local b_meta = {
                filepath     = c.fp,
                title        = book.title,
                series_name  = book.series_name,
                series_index = tonumber(book.series_num),
                series_num   = book.series_num,
                author       = book.author,
                authors      = book.authors,
                genres       = book.genres,
                lang         = book.lang,
                _last_read   = read_time[c.fp] or 0,
                date_added   = c.mtime or 0,
                size         = c.size or 0,
                rating       = rating,
            }
            local bucket = buckets[bk]
            bucket[#bucket + 1] = b_meta
        end
    end
    -- Sort books within each bucket via the standard within-group order.
    local SortEngine = require("lib/bookshelf_sort_engine")
    local within_cmp = SortEngine.chainedComparator{
        { key = "series_name",  reverse = false },
        { key = "series_index", reverse = false },
        { key = "title",        reverse = false },
    }
    local groups = {}
    for _i, key in ipairs({5, 4, 3, 2, 1, "unrated"}) do
        local books_meta = buckets[key]
        if #books_meta > 0 then
            table.sort(books_meta, within_cmp)
            local g = {
                kind        = "rating",
                series_name = key == "unrated" and tr("Unrated") or _STAR_REPEAT[key],
                books       = {},
                latest      = 0,
                avg_rating  = key == "unrated" and 0 or key,
            }
            for _i, b in ipairs(books_meta) do
                g.books[#g.books + 1] = b
                local t = b._last_read or 0
                if t > g.latest then g.latest = t end
            end
            groups[#groups + 1] = g
        end
    end
    return groups
end

function Repo.getRatings(limit, offset, sort_priority_override, filter, opts)
    local _t0 = _gettime()
    local home  = HomeDir.get() or "/"
    local depth = BookshelfSettings.read("latest_walk_depth") or 3
    local key   = (home or "/") .. ":" .. tostring(depth or 0)
    local now   = os.time()
    local cached = _ratings_cache[key]
    local _hit = cached
    if not _hit then
        local list = _buildRatingGroups()
        _ratings_cache[key] = {
            groups     = _cacheGroupShapes(list, "rating"),
            expires_at = now + SERIES_CACHE_TTL,
        }
        cached = _ratings_cache[key]
    end
    local sk = sort_priority_override or Repo.getSortPriority("ratings")
    local within = _withinPriority(sk)
    local sorted = {}
    for _i, s in ipairs(cached.groups) do
        if _shapeHasFilteredBook(s, filter) then sorted[#sorted + 1] = s end
    end
    table.sort(sorted, _groupShapeCmp(sk))
    local total = #sorted
    local out   = {}
    offset      = offset or 0
    local stop  = _hydrationStop(offset, limit, total, 8, "getRatings",
                                 (opts and opts.light_only) or Repo.spine_light)
    for i = offset + 1, stop do
        out[#out + 1] = _hydrateGroupShape(sorted[i], within, filter, opts and opts.light_only)
    end
    logger.dbg(string.format("[bookshelf perf] getRatings: %s %.0fms groups=%d/%d",
        _hit and "HIT" or "MISS", (_gettime() - _t0) * 1000, #out, total))
    return out, total
end

-- ─── searchAll ───────────────────────────────────────────────────────────────
-- Returns { folders, authors, series, genres, books } for a query string.
-- All matching is case-insensitive substring. Returns empty lists immediately
-- for a blank query.
function Repo.searchAll(query)
    local empty = { folders = {}, authors = {}, series = {}, genres = {}, books = {} }
    if not query or query == "" then return empty end
    local q = query:lower()

    local home  = HomeDir.get() or "/"
    local depth = BookshelfSettings.read("latest_walk_depth") or 3
    local key   = (home or "/") .. ":" .. tostring(depth or 0)

    -- ── folders ──
    -- Folder names are excluded from search by default (issue #190): most
    -- libraries file books into author / series / genre folders, so a folder
    -- whose name matches the query just duplicates the metadata group of the
    -- same name (often with a slightly different count when a book is filed
    -- there without matching metadata). Opt in via the "Include folder names
    -- in search results" advanced setting for folder-led navigation.
    -- Derive from the already-cached walk: unique parent directories whose
    -- basename matches the query. No disk I/O: cachedWalk returns { fp, mtime }.
    local folders = {}
    if BookshelfSettings.read("search_include_folders") == true then
        local cands = cachedWalk(home, depth)
        local seen_dirs = {}
        for _i, c in ipairs(cands) do
            local dir = c.fp:match("^(.*)/[^/]+$") or "/"
            if not seen_dirs[dir] then
                seen_dirs[dir] = true
                local basename = dir:match("([^/]+)$") or dir
                if basename:lower():find(q, 1, true) then
                    local first_book = Repo.buildBookMeta(c.fp)
                    folders[#folders + 1] = {
                        kind       = "folder",
                        path       = dir,
                        label      = _flipTrailingArticle(basename),
                        first_book = first_book,
                    }
                end
            end
        end
    end

    -- ── author / series / genre groups ──
    -- Warm each shape cache with limit=0 (populates the cache without
    -- hydrating any groups — in Lua, 0 is truthy so `0 or 8` = 0, giving
    -- an empty loop but still running the _buildGroups fill). Then iterate
    -- shapes directly and hydrate only matching entries, avoiding the cost
    -- of hydrating the full collection just to filter it.
    local function matchGroups(cache_table)
        if not cache_table[key] then return {} end
        local out = {}
        for _i, shape in ipairs(cache_table[key].groups) do
            if (shape.series_name or ""):lower():find(q, 1, true) then
                out[#out + 1] = _hydrateGroupShape(shape)
            end
        end
        return out
    end
    Repo.getAuthors(0, 0)
    Repo.getSeriesGroups(0, 0)
    if _searchIncludesGenres() then Repo.getGenres(0, 0) end

    local authors = matchGroups(_authors_cache)
    local series  = matchGroups(_series_cache)
    local genres  = _searchIncludesGenres() and matchGroups(_genres_cache) or {}

    -- ── books ──
    local books = Repo.searchBooks(query, 200) or {}

    return { folders = folders, authors = authors, series = series, genres = genres, books = books }
end

-- ─── findGroup ───────────────────────────────────────────────────────────────
-- Searches the in-memory shape cache for a group whose series_name matches
-- `name` (case-insensitive exact match) and hydrates just that one group.
-- When the relevant cache is cold (e.g. the user long-presses a book on the
-- Recent tab without ever having visited the Authors tab this session),
-- warms it via the matching getter so the lookup actually finds the full
-- group instead of falling back to a single-book stub. Returns nil when:
-- kind is unrecognised, or no group matches the name even after warming.
function Repo.findGroup(kind, name)
    if not name or name == "" then return nil end
    local home  = HomeDir.get() or "/"
    local depth = BookshelfSettings.read("latest_walk_depth") or 3
    local key   = (home or "/") .. ":" .. tostring(depth or 0)
    local cache
    if     kind == "author"   then cache = _authors_cache[key]
    elseif kind == "series"   then cache = _series_cache[key]
    elseif kind == "genre"    then cache = _genres_cache[key]
    elseif kind == "format"   then cache = _formats_cache[key]
    elseif kind == "rating"   then cache = _ratings_cache[key]
    elseif kind == "language" then cache = _languages_cache[key]
    else return nil end
    if not cache then
        if     kind == "author"   then Repo.getAuthors(0, 0);      cache = _authors_cache[key]
        elseif kind == "series"   then Repo.getSeriesGroups(0, 0); cache = _series_cache[key]
        elseif kind == "genre"    then Repo.getGenres(0, 0);       cache = _genres_cache[key]
        elseif kind == "format"   then Repo.getFormats(0, 0);      cache = _formats_cache[key]
        elseif kind == "rating"   then Repo.getRatings(0, 0);      cache = _ratings_cache[key]
        elseif kind == "language" then Repo.getLanguages(0, 0);    cache = _languages_cache[key]
        end
        if not cache then return nil end
    end
    local lname = name:lower()
    for _i, shape in ipairs(cache.groups) do
        if (shape.series_name or ""):lower() == lname then
            return _hydrateGroupShape(shape)
        end
    end
    return nil
end

-- ─── enrichStats ─────────────────────────────────────────────────────────────
-- Mutates `book` in-place with statistics fields from readerstatistics.
-- Graceful no-op when the statistics plugin is absent or its API method is nil.
--
-- CONTRACT: ReaderStatistics:getBookStat(filepath) is the intended public API
-- boundary for v0.1. As of 2026-05, upstream KOReader does not expose this
-- exact method — getBookStat() does not exist in the KOReader codebase.
-- The pcall + nil-guard means we fall through silently and all stat-based
-- tokens auto-hide via Tokens.isEmpty. When the upstream API stabilises,
-- update this single function — that's why the boundary is isolated here.

-- enrichStats — fill the book record with reading-statistics fields.
-- Queries the statistics plugin's SQLite DB directly: ReaderStatistics
-- doesn't expose a clean filepath-keyed API, only an integer id_book and
-- KeyValuePage-shaped output for its Reader-context UI. We compute the
-- file's partial MD5 (the same key the stats plugin uses) and read the
-- rolled-up fields from the `book` table plus a couple of derived stats
-- from `page_stat_data` for days-reading / pages-per-day / speed.
--
-- Per-filepath cache with TTL: fires on every hero rebuild + every preview
-- tap, and the SQLite open + 3 prepared queries adds up across an
-- interactive session. Cached fields are mutated into the passed-in book
-- on subsequent calls within TTL. Invalidate via Repo.invalidateStatsCache()
-- (called from onCloseDocument so freshly-read pages surface immediately).
local STATS_CACHE_TTL = 30  -- seconds
local _stats_cache = {}     -- filepath → { fields = {...}, expires_at = number }
local STATS_FIELDS = {
    "book_read_time_seconds", "book_pages_read", "days_reading_book",
    "pages_per_day", "speed_pph", "book_time_left_minutes",
    "avg_page_time_seconds", "book_pct_read",
}

function Repo.invalidateStatsCache(filepath)
    _bumpDataGeneration()
    if filepath then _stats_cache[filepath] = nil
    else _stats_cache = {} end
end

function Repo.enrichStats(book)
    if not book or not book.filepath then return end
    local now = os.time()
    local cached = _stats_cache[book.filepath]
    if cached then
        for _i, k in ipairs(STATS_FIELDS) do book[k] = cached.fields[k] end
        return
    end
    -- ReaderStatistics keys books by `partial_md5_checksum` stored in the
    -- DocSettings sidecar (statistics/main.lua:2740). Read from there
    -- first; fall back to recomputing only if the sidecar is missing.
    local md5
    local ok_ds, ds = pcall(function() return getDocSettings():open(book.filepath) end)
    if ok_ds and ds and ds.readSetting then
        md5 = ds:readSetting("partial_md5_checksum")
    end
    if not md5 then
        local ok_util, util = pcall(require, "util")
        if ok_util and util and util.partialMD5 then
            md5 = util.partialMD5(book.filepath)
        end
    end
    if not md5 then return end

    local ok_ds, DataStorage = pcall(require, "datastorage")
    local ok_sq, SQ3         = pcall(require, "lua-ljsqlite3/init")
    if not (ok_ds and DataStorage and ok_sq and SQ3) then return end
    local db_path = DataStorage:getSettingsDir() .. "/statistics.sqlite3"

    local ok_conn, conn = pcall(SQ3.open, db_path)
    if not ok_conn or not conn then return end

    -- Roll-ups from the book table (kept in sync by ReaderStatistics).
    -- KOReader keys a row by title + authors + md5 and starts a NEW row when
    -- the title or authors change outside its own editor (a Calibre resend,
    -- say), so one md5 can have two rows. The one it opened last is the one it
    -- is reading into; an arbitrary one showed 27 minutes left in a book
    -- KOReader put at 19 hours (Reddit report).
    local id_book, total_read_time, total_read_pages, pages_total
    local ok_q, err = pcall(function()
        local stmt = conn:prepare(
            "SELECT id, total_read_time, total_read_pages, pages "
            .. "FROM book WHERE md5 = ? ORDER BY last_open DESC LIMIT 1")
        local row = stmt:reset():bind(md5):step()
        stmt:close()
        if row then
            id_book          = tonumber(row[1])
            total_read_time  = tonumber(row[2]) or 0
            total_read_pages = tonumber(row[3]) or 0
            pages_total      = tonumber(row[4]) or 0
        end
    end)
    if not ok_q or not id_book then conn:close(); return end

    -- Days-reading + first-open + last-page from page_stat_data, same query
    -- shape as ReaderStatistics:getBookStat.
    local total_days, first_open
    pcall(function()
        local stmt = conn:prepare(
            "SELECT count(*) FROM ("
            .. "  SELECT strftime('%Y-%m-%d', start_time, 'unixepoch', 'localtime') AS d "
            .. "  FROM page_stat_data WHERE id_book = ? GROUP BY d)")
        local row = stmt:reset():bind(id_book):step()
        stmt:close()
        total_days = row and tonumber(row[1]) or 0
    end)
    pcall(function()
        local stmt = conn:prepare(
            "SELECT min(start_time) FROM page_stat_data WHERE id_book = ?")
        local row = stmt:reset():bind(id_book):step()
        stmt:close()
        first_open = row and tonumber(row[1]) or nil
    end)
    -- Capped per-page totals for avg_time: mirrors ReaderStatistics's
    -- self.avg_time (statistics.koplugin/main.lua:41 + 999). Per-page
    -- duration is capped at max_sec so outlier sessions don't inflate
    -- the average. page_stat is a VIEW that rescales pages to handle
    -- font-size changes. (#38.)
    local stats = G_reader_settings:readSetting("statistics")
    local max_sec = (stats and stats.max_sec) or 120
    local capped_pages, capped_time
    pcall(function()
        local stmt = conn:prepare(
            "SELECT count(*), sum(d) FROM (SELECT min(sum(duration), ?) AS d "
            .. "FROM page_stat WHERE id_book = ? GROUP BY page)")
        local row = stmt:reset():bind(max_sec, id_book):step()
        stmt:close()
        if row then
            capped_pages, capped_time = tonumber(row[1]), tonumber(row[2])
        end
    end)
    conn:close()

    -- Roll-up derived fields. Defensive math: pages_total/total_read_pages
    -- can be 0 on a freshly-tracked book; guard divisions.
    book.book_read_time_seconds = total_read_time
    book.book_pages_read        = total_read_pages
    book.days_reading_book      = total_days
    if total_days > 0 then
        book.pages_per_day = math.floor(total_read_pages / total_days + 0.5)
    end
    if total_read_time > 0 then
        -- Speed in pages per hour.
        book.speed_pph = math.floor(total_read_pages * 3600 / total_read_time + 0.5)
    end
    -- %avg_page_time (#348): seconds per page, from the SAME capped totals the
    -- time-left estimate uses, so the two agree. Capping matters here as much
    -- as there: an uncapped average is dominated by the session the reader left
    -- the book open overnight.
    if capped_pages and capped_pages > 0 and capped_time then
        book.avg_page_time_seconds = math.floor(capped_time / capped_pages + 0.5)
    end
    -- %book_pct_read (#348) is NOT %book_pct. book_pct is where the reader IS
    -- in the book; this is how much of it they have actually READ, which
    -- differs whenever pages were skipped or revisited. Both numbers already
    -- sit in this query's results, so the distinction costs nothing.
    if pages_total and pages_total > 0 and total_read_pages then
        book.book_pct_read = math.min(100,
            math.floor(total_read_pages / pages_total * 100))
    end
    -- Time-left = pages_remaining × capped_avg_per_page. pages_remaining
    -- must be in the SAME UNITS as pages_total. The stats DB's book.pages
    -- is the document's internal page count (self.document:getPageCount(),
    -- typically 317 for an EPUB rendered at the user's font size). The
    -- DocSettings book.page_num we'd otherwise use is often in pagemap
    -- LABEL units (231 publisher labels) — same book, different scale.
    -- Mixing those gives a pages_left that's wildly wrong (#38).
    --
    -- Derive current_page from book_pct (a unit-agnostic 0..1 fraction)
    -- × pages_total. This matches KOReader's stats calculation exactly,
    -- which uses self.ui:getCurrentPage() (internal units) against
    -- self.document:getPageCount() (same internal units).
    if capped_pages and capped_pages > 0 and capped_time
            and pages_total > 0 and book.book_pct then
        local current_page = math.floor(book.book_pct * pages_total + 0.5)
        local pages_left = math.max(0, pages_total - current_page)
        book.book_time_left_minutes = math.floor(
            pages_left * capped_time / capped_pages / 60 + 0.5)
    end

    -- Snapshot computed fields into the cache.
    local snapshot = {}
    for _i, k in ipairs(STATS_FIELDS) do snapshot[k] = book[k] end
    _stats_cache[book.filepath] = { fields = snapshot, expires_at = now + STATS_CACHE_TTL }
end

-- _bySourceCacheKey: stable string key for the _bySource_cache table. Encodes
-- source kind + id, the active filter statuses (sorted for stability), and the
-- sort priority levels in order. Cheap: just table.concat over scalar fields.
local function _bySourceCacheKey(source, filter, sort_priority)
    local parts = { (source and source.kind) or "?", (source and source.id) or "" }
    local fsig = Filter.signature(filter)
    if fsig ~= "" then
        parts[#parts + 1] = "f:" .. fsig
    end
    if sort_priority then
        for _i, level in ipairs(sort_priority) do
            parts[#parts + 1] = "s:" .. level.key .. ":" .. (level.reverse and "r" or "f")
        end
    end
    -- How the keys themselves are derived (pinyin, leading articles): not a
    -- sort level, but it changes the order all the same.
    parts[#parts + 1] = "k:" .. SortEngine.keySignature()
    return table.concat(parts, "|")
end

-- Nav-tile cover borrow (see the opds branch of getBySource below): how many
-- of a not-yet-drilled subcatalog's cached child entries to STAT (via
-- OpdsCovers.cachedPath) while scanning for the first one with an
-- already-cached cover. This bounds disk-stat cost, not raw index: a child
-- entry with no cover URL at all (OpdsCovers.cachePath returns nil for it --
-- nav entries riding the same window, per bookshelf_opds_window's nav-first
-- ordering) costs nothing to rule out and does not consume the budget, so a
-- page of 12+ cover-less nav children can't starve the scan before it ever
-- reaches an entry that actually has a cover. The borrow is purely cosmetic
-- (a placeholder tile is a perfectly valid render), so this caps rather than
-- pays for an exhaustive scan.
local NAV_COVER_BORROW_SCAN = 12
-- ...and a bound on the RAW iterations, since the stat budget above only
-- counts entries actually statted: a child window may hold up to
-- OpdsWindow.MAX_ENTRIES (1000) records and start with a long run of
-- cover-less ones, which would then be walked in full per nav tile per
-- rebuild. Microseconds each, but the shape scales with the window and the
-- borrow is cosmetic -- if the first 200 entries have nothing cached, a
-- placeholder is the right answer.
local NAV_COVER_BORROW_ITER = 200

-- "Folder of one" (see the opds branch of getBySource below): given a nav
-- tile's CHILD window, return the single book record it holds, or nil when it
-- is anything else. A catalog like Project Gutenberg's popular lists models
-- every work as a subcatalog whose feed carries exactly one acquisition entry,
-- so the shelf shows a page of folders that each hold one book and the user
-- must drill in to reach it.
--
-- Deliberately strict: exactly one book record and ZERO nav records. A second
-- book, or any subfolder, means the folder still has something of its own to
-- show and is left alone. Naturally bounded regardless of window size -- the
-- walk returns on the first nav record or the second book, so it reads at most
-- two entries before deciding.
--
-- A window with next_url still set is refused outright. That is a PARTIALLY
-- fetched feed -- a drill the user cancelled, or one whose second page failed --
-- and page 1 of a subcatalog can perfectly well hold one book with more behind
-- it. Flattening that would hide the rest permanently: nothing re-fetches a
-- child feed except drilling into it, which the flattened tile no longer
-- offers. appendPage clears next_url exactly when the feed is exhausted, so
-- this is the available "is that all of it?" signal; a server that emits
-- rel=next on every page simply keeps its folders, which is the pre-existing
-- behaviour and no loss.
--
-- The lone entry must also have something to download. A record with no
-- acquisitions is not a book the user can act on (a malformed entry, or one
-- whose formats were all unsupported), and promoting it would swap a working
-- folder for a dead tile.
local function opdsLoneChildBook(win)
    if type(win) ~= "table" then return nil end
    if win.next_url then return nil end
    -- Two rows is all this needs: a second entry of any kind disqualifies the
    -- window, so there is no reason to materialise a whole child feed to find
    -- that out. (The window no longer carries its records - they stay in the
    -- database until something asks for a page.)
    local OpdsWindow = require("lib/bookshelf_opds_window")
    local entries = OpdsWindow.slice(win, 0, 2)
    if type(entries) ~= "table" then return nil end
    local book
    for _i = 1, #entries do
        local e = entries[_i]
        if type(e) == "table" then
            if e.is_opds_nav then return nil end
            if book then return nil end
            book = e
        end
    end
    local o = book and book.opds
    if not (o and ((type(o.acquisitions) == "table" and #o.acquisitions > 0)
            or type(o.stream) == "table")) then
        return nil
    end
    return book
end

-- opdsDecorate(records, light_only) - the render-time decoration every OPDS
-- record gets before it is handed out. Two callers: the page path (the opds
-- branch of getBySource) and the single-record path (Repo.opdsLoneChildBook,
-- which must hand the widget a record indistinguishable from the same book on
-- the shelf, or the modal a nav tap opens would show no cover, no blurb and no
-- "already downloaded" state).
--
-- Everything set here is RENDER state, re-derived on every call from disk and
-- the download map, and must never reach a stored window entry -- the callers
-- pass copies, and OpdsWindow's save-time scrub lists these fields as belt and
-- braces.
--
-- The nav-tile cover BORROW is deliberately NOT here: it needs the caller's
-- child-window memo and applies only to a page of nav tiles.
--
-- light_only ("Go to letter") wants sort keys, not tiles, and must not pay a
-- disk stat per record; it skips the passes that cost one.
local function opdsDecorate(records, light_only)
    -- Feed summaries ARE the book's blurb. A remote record keeps its copy
    -- under opds.summary (what the download modal's preview and its
    -- Description row read), but every GENERIC consumer -- the hero's
    -- %description token (lib/bookshelf_tokens.lua), the description viewer --
    -- reads the `description` field a local book carries, so a previewed
    -- remote book showed a blank blurb where a local one showed its own.
    -- Mirror one into the other here.
    --
    -- At the DECORATION boundary, not at parse time: the persisted window
    -- already stores the summary exactly once, and a second copy in the dump
    -- would double every cached feed's footprint for a field nothing reads off
    -- the stored entry.
    --
    -- Never overwrites: `rec.description or ...` means a record that already
    -- has one keeps it.
    --
    -- No new sanitisation. A local EPUB's description is HTML-ish too, and
    -- both consumers already clean it at render (Tokens.cleanDescription for
    -- the hero, _descriptionArgs' sanitiser for the viewer) -- which is exactly
    -- why _showRemoteBookInfo could already hand opds.summary straight to those
    -- helpers.
    --
    -- Nav records are skipped: a subcatalog is not a book, and mapEntries gives
    -- a nav record no summary in the first place.
    if not light_only then
        for _i = 1, #records do
            local rec = records[_i]
            if not rec.is_opds_nav then
                rec.description = rec.description or (rec.opds and rec.opds.summary) or nil
            end
        end
    end
    -- Attach covers already on disk, via cover_image_path rather than a decoded
    -- cover_bb. Missing ones stay placeholders; the widget fetches them async.
    --
    -- This must NEVER set cover_bb/has_cover here. A record's cover_bb is, by
    -- BIM convention, a ONE-SHOT bb: whichever SpineWidget paints it frees it
    -- (see lib/bookshelf_spine_widget.lua's ownership doc above
    -- _renderCoverAlignTop, and feedback_image_disposable_shared_book). That
    -- convention holds for a local file because exactly one widget ever paints
    -- a given Book instance. It does NOT hold here: the same page record is
    -- painted by the grid cell AND, unchanged, by the hero preview
    -- (_hydrateBook passes remote records through untouched), and a later
    -- network-driven repaint (a cover landing, a page rebuild) paints it again.
    -- Two painters freeing the same bb is a use-after-free; on a real device
    -- this corrupted the hero and made grid covers vanish. cover_image_path is
    -- a plain string, not a handle to anything freeable -- every painter
    -- independently resolves it through ImageSource's cache-owned bb
    -- (image_disposable=false, never freed), the same mechanism Hardcover's
    -- external covers use.
    local ok_c, OpdsCovers = pcall(require, "lib/bookshelf_opds_covers")
    if ok_c and OpdsCovers and not light_only then
        local ok_is, ImageSource = pcall(require, "lib/bookshelf_image_source")
        for _i, rec in ipairs(records) do
            local cp = OpdsCovers.cachedPath(rec)
            rec.cover_image_path = cp
            -- Remote records carry no BIM cover_sizetag, so the true-aspect
            -- grid would size every OPDS cover to the 2:3 default. Read the
            -- cached cover's real dimensions (cheap header parse, memoised) so
            -- each cover's box takes its own shape. Only once a cover is on
            -- disk; before that the record keeps the default and settles to
            -- true aspect on the cover-landing rebuild, like the covers do.
            if cp and not rec.cover_sizetag and ok_is and ImageSource.imageSizeTag then
                rec.cover_sizetag = ImageSource.imageSizeTag(cp)
            end
        end
    end
    -- Downloaded decoration. The OPDS download flow (the book modal in
    -- lib/bookshelf_widget.lua) records opds_downloads[<OPDS pseudo-path>]
    -- = <on-disk path> in the main settings store; a record whose mapping
    -- still resolves to a file is one the user already has.
    --
    -- Read-side truth, deliberately: the flag comes from a stat, not from
    -- the mapping alone, so deleting the book in the file manager retires
    -- it with no bookkeeping pass to keep in sync. Cost is nothing at all
    -- for a user who has downloaded nothing (the key is absent), then one
    -- stat per VISIBLE record that has a mapping -- not one per download.
    --
    -- MOVING the book has the same effect, and that is deliberate too.
    -- FileOps.relocateFolder rekeys eight other stores on a move and this
    -- one is pointedly not among them: the mapping is KEYED by the OPDS
    -- pseudo-path (which never moves) and VALUED by the on-disk path (which
    -- does), so a stale value degrades to a false NEGATIVE -- no tick, no
    -- Open row, Download still offered -- and never to an Open row that
    -- launches the wrong book. It self-heals on the action that exposes it
    -- (the user taps Download and the mapping is rewritten), and rekeying
    -- would mean a value-rewrite pass on the single-file move path, the
    -- folder relocate path and bulk actions, all for a decoration.
    --
    -- Render state, never persisted: OpdsWindow.slice hands out copies and
    -- its save-time scrub lists `downloaded` alongside the cover keys, so a
    -- stale true can't survive into the cached window and outlive the file.
    --
    -- Store key from the download module rather than a literal: the widget
    -- writes this table and reads it back, and two spellings are two things
    -- to keep in step for no reason.
    local ok_dlk, OpdsDownload = pcall(require, "lib/bookshelf_opds_download")
    local dl_key = ok_dlk and OpdsDownload.STORE_KEY or "opds_downloads"
    local dl_map = BookshelfSettings.read(dl_key)
    if type(dl_map) == "table" and next(dl_map) ~= nil then
        local ok_l, lfs = pcall(require, "libs/libkoreader-lfs")
        if ok_l and lfs then
            for _i, rec in ipairs(records) do
                local dest = dl_map[rec.filepath]
                if type(dest) == "string" and dest ~= "" then
                    local ok_a, mode = pcall(lfs.attributes, dest, "mode")
                    if ok_a and mode == "file" then rec.downloaded = true end
                end
            end
        end
    end
    return records
end

-- Repo.opdsLoneChildBook(server_key, feed_url) -> record | nil
-- The public face of the "folder of one" predicate above, for the widget's nav
-- TAP: is this subcatalog's cached window just the one book? Returns a
-- decorated copy of it -- the same cover / blurb / downloaded state the shelf's
-- own records carry -- or nil for anything else: a window that was never
-- fetched, one still holding a rel=next, more than one book, or any subfolder.
--
-- Single-sourced deliberately. The tile FLATTENING (the opds branch of
-- getBySource) and the tap DECISION have to agree, or a tile rendered as a book
-- would drill in like a folder. Both go through opdsLoneChildBook, so the two
-- can only ever answer the same way.
--
-- Cache-only, like everything else in this branch: OpdsWindow.load reads the
-- persisted window and never touches the network. The widget is what decides
-- whether an uncached child is worth a fetch.
function Repo.opdsLoneChildBook(server_key, feed_url)
    if not (server_key and feed_url) then return nil end
    local ok_w, OpdsWindow = pcall(require, "lib/bookshelf_opds_window")
    if not (ok_w and OpdsWindow) then return nil end
    local lone = opdsLoneChildBook(OpdsWindow.load(server_key, feed_url))
    if not lone then return nil end
    -- Copied for the reason OpdsWindow.slice copies: what comes back gets
    -- decorated, and the stored window entry must stay clean or the decoration
    -- is serialised into the OPDS cache on the next save.
    local copy = {}
    for k, v in pairs(lone) do copy[k] = v end
    opdsDecorate({ copy }, false)
    return copy
end

-- ─── getBySource ─────────────────────────────────────────────────────────────
-- getBySource(source, filter, sort_priority, offset, limit)
-- Generic resolver for the v1.4 custom-tab feature. `source` is a table
-- describing what to load:
--   { kind = "all" }
--   { kind = "recent" }                — delegates to Repo.getRecent
--   { kind = "latest" }                — delegates to Repo.getLatest
--   { kind = "series" }                — delegates to Repo.getSeriesGroups
--   { kind = "authors" | "genres" | "tags" } — delegates to existing group fetchers
--   { kind = "favorites" }             — delegates to Repo.getFavorites
--   { kind = "folder",     id = "/absolute/path" }
--   { kind = "collection", id = "collection_name" }
--   { kind = "tag",        id = "tag_name" }
--   { kind = "genre",      id = "genre_name" }
--   { kind = "author",     id = "Author Name" }
--   { kind = "status",     id = "unread"|"reading"|"on_hold"|"finished" }
--
-- For built-in kinds, this is a thin alias over the existing per-chip
-- functions (they already apply sort + filter internally). For the new
-- kinds, the resolver walks the BIM via a predicate filter, then applies
-- sort_priority via SortEngine and a per-tab status filter.
-- Repo.getBySource(source, filter, sort_priority, offset, limit, opts)
-- opts is forwarded to Repo.getAll for the "all" / "folder" dispatches
-- (lazy_cover_w / lazy_cover_h). Other kinds ignore opts today.
function Repo.getBySource(source, filter, sort_priority, offset, limit, opts)
    if not source or not source.kind then return {}, 0 end
    local kind = source.kind
    -- light_only (the "Go to letter" jump, #229) asks for records to SCAN, not
    -- to paint: it passes limit = max(_total_items, 10000) and throws the list
    -- away after reading sort keys off it. Both branches below attach covers
    -- EAGERLY -- a freshly decoded BlitBuffer per record, freed by the grid
    -- cell after paint -- so honouring such a call literally would decode one
    -- bb per cached cover in the whole window and free none of them. That is
    -- the out-of-memory shape MAX_HYDRATE / _hydrationStop exist to prevent,
    -- and a SIGKILL Lua cannot catch. Nothing on the light_only path reads a
    -- cover, so skip the attachment entirely.
    local light_only = (opts and opts.light_only) or false
    -- A registered source (lib/bookshelf_sources): the Kindle's own library,
    -- the Kobo store's, or another plugin's (issue 452). Its records come from
    -- the source, not the walk or BIM. Filter, sort and page the full set here,
    -- the same way for every source, so a source only has to say what books it
    -- holds. Empty and cheap when the source is unavailable.
    local Sources = require("lib/bookshelf_sources")
    local src_spec = Sources.get(kind)
    if src_spec and src_spec.fetch then
        -- Fetch mode: the source pages and orders itself (a server's catalogue),
        -- so its order is kept and the shelf's filter and sort are not applied.
        -- source.drill is the folder the reader has drilled into, if any.
        local page, total = Sources.fetch(kind, source, source.drill, offset or 0, limit)
        if not page then return {}, 0 end
        -- A total the source does not know yet reads as "this page and one more
        -- item", so the footer offers a next page until a page comes back short.
        if not total then
            total = (offset or 0) + #page + ((limit and #page >= limit) and 1 or 0)
        end
        return page, total
    end
    -- BookOrbit catalog chip (source.id encodes which server section/entry
    -- to browse -- see bookshelf_bookorbit_source.lua). Unlike Kobo this is
    -- a REMOTE, paged source: offset/limit map directly onto one
    -- catalogBooks() page instead of a full in-memory list, and each
    -- visible book's cover is downloaded (and disk-cached) on first
    -- request. Empty + cheap when BookOrbit isn't configured or the device
    -- is offline, so this is inert until the user sets it up.
    if kind == "bookorbit" then
        local ok_bo, BOSource = pcall(require, "lib/bookshelf_bookorbit_source")
        if not (ok_bo and BOSource and BOSource.isAvailable()) then
            local ok_log, logger = pcall(require, "logger")
            if ok_log then
                logger.info("[bookshelf][bookorbit] getBySource: source unavailable (require ok=",
                    tostring(ok_bo), ", isAvailable=",
                    tostring(ok_bo and BOSource and BOSource.isAvailable and BOSource.isAvailable()),
                    ") -- returning empty page")
            end
            return {}, 0
        end
        local off, lim = offset or 0, limit or 24
        -- The Authors/Series "All ..." root (id "authors:" / "series:",
        -- no specific entry, or a Libraries/Collections/SmartScopes
        -- "browse as folders" id) browses as folder tiles instead of one
        -- flat unfiltered book list -- see BOSource.listGroups /
        -- BookshelfWidget:_expandBookOrbitGroup. Each tile already
        -- carries its own hydrated + covered preview book, so this skips
        -- the flat-book cover-attach loop below entirely for this branch.
        if BOSource.isGroupRoot and BOSource.isGroupRoot(source.id) then
            local section = BOSource.groupSection and BOSource.groupSection(source.id)
                or BOSource.decodeId(source.id)
            -- BUGFIX (30+ second "Go to letter" with group covers
            -- enabled): forward opts (specifically light_only) the same
            -- way the flat listBooks path below effectively already
            -- gets to honor via scheduleCoverFills' own gating -- this
            -- branch used to drop them on the floor entirely, so a
            -- metadata-only bulk caller (BookshelfWidget:
            -- _jumpToLetterPrefix, scanning up to ~10000 entries just
            -- for their sort-key value) still paid for listGroups'
            -- normal per-tile sample-book/cover resolution when the
            -- "Show covers on Author/Series tiles" setting was on --
            -- one blocking catalogBooks() round trip per author, across
            -- the whole requested window, before the letter search
            -- could even start. See listGroups' own doc comment for the
            -- full story.
            -- Per-chip server-side sort/filter (Authors / Series only;
            -- listGroups ignores them elsewhere or on older servers).
            local o = {}
            for k, v in pairs(opts or {}) do o[k] = v end
            o.sort = source.bo_sort
            o.filter = source.bo_filter
            return BOSource.listGroups(section, off, lim, o)
        end
        local page, total = BOSource.listBooks(source.id, off, lim)
        -- No synchronous cover work at all now, disk-cached or not --
        -- even decoding an already-downloaded JPEG is real CPU work
        -- (RenderImage), and doing a page's worth of that inline here
        -- was still enough to make a page turn feel like it was
        -- fighting the device for attention, independent of the
        -- network entirely. scheduleCoverFills below fills every
        -- eligible record's cover in place off the render path (decode
        -- for a disk hit, download-then-decode for a miss) and fires
        -- onCoversReady so the grid widget can repaint once a batch
        -- lands -- see its doc comment in bookshelf_bookorbit_source.lua.
        -- source.id tags the batch so onCoversReady can tell "this is
        -- the chip on screen" apart from "this was a background
        -- pre-warm for some other chip" and skip the repaint for the
        -- latter (see bookshelf_widget.lua's onCoversReady registration).
        if BOSource.scheduleCoverFills then
            BOSource.scheduleCoverFills(page, source.id)
        end
        -- Next-page prefetching (warming the page AHEAD of the one on
        -- screen) is opt-in via Settings > BookOrbit > "Prefetch next page"
        -- (bookorbit_prefetch_next_page, default off): it costs a deferred
        -- HTTP round-trip plus a burst of cover downloads shortly after
        -- each page turn, competing with the turn itself for bandwidth/CPU
        -- right around the moment it happens, which could make the turn
        -- feel like it's fighting the device for attention even though
        -- covers ended up ready by the time it landed. scheduleCoverFills
        -- above (current-page covers, async, non-blocking) is unaffected
        -- by this toggle either way.
        --
        -- The single-slot page cache prefetchNextPage feeds is NOT gated
        -- by this toggle, though: listBooks() also populates it right
        -- after fetching the CURRENT page (see that cache's doc comment
        -- in bookshelf_bookorbit_source.lua), which is what keeps the
        -- cascade of _rebuild() calls scheduleCoverFills' onCoversReady
        -- triggers (one per landed cover batch) from each re-issuing a
        -- fresh catalogBooks() request for the exact page just rendered.
        if BookshelfSettings.read("bookorbit_prefetch_next_page") == true
                and BOSource.prefetchNextPage and total and (off + lim) < total then
            BOSource.prefetchNextPage(source.id, off + lim, lim)
        end
        return page, total
    end
    if src_spec then
        local books = Sources.list(kind, source)
        if not books then return {}, 0 end
        -- Filtered BEFORE the sort and slice so `total` is the filtered count
        -- and pagination matches what is on screen. (These branches used to
        -- skip the filter entirely, so a filter set on a Kindle or Kobo shelf
        -- did nothing.)
        --
        -- _recordMatches rather than Filter.matches directly: it resolves
        -- status and rating from the sidecar only when the filter constrains
        -- them, and derives `format` from the filepath when a record lacks it.
        if Filter.isActive(filter) then
            local compiled = Filter.compile(filter, Repo.filterOpts())
            -- Genres on these records come from Hardcover, and that enrichment
            -- is normally applied to the VISIBLE SLICE only (below). A genre
            -- filter has to see them BEFORE the slice exists, so enrich the
            -- whole list first -- but only when the filter actually constrains
            -- genres, so an unfiltered or rating-only shelf still pays for one
            -- page. applyMetadata because it is what the light record path uses
            -- for exactly this; cache-only, and gated on the plugin and setting.
            if compiled.genres then
                local Hardcover = getHardcover()
                if Hardcover and Hardcover.applyMetadata then
                    for i = 1, #books do pcall(Hardcover.applyMetadata, books[i]) end
                end
            end
            local kept = {}
            for i = 1, #books do
                if _recordMatches(books[i], compiled) then kept[#kept + 1] = books[i] end
            end
            books = kept
        end
        if sort_priority and #sort_priority > 0 then
            local ok_sort = pcall(table.sort, books, SortEngine.chainedComparator(sort_priority))
            if not ok_sort then table.sort(books, function(a, b)
                return (a.title or "") < (b.title or "") end) end
        end
        local total = #books
        local off, lim = offset or 0, limit or total
        local page = {}
        for i = off + 1, math.min(off + lim, total) do
            local rec = books[i]
            if not light_only then
                if src_spec.cover then
                    -- The source hands back a fresh blitbuffer the grid frees
                    -- after paint (Kobo: BIM cannot read a DRM'd kepub). Asked
                    -- again every rebuild, so a freed bb is never reused. nil
                    -- leaves the placeholder.
                    local ok_c, bb, cw, ch = Sources.call(src_spec, "cover", rec)
                    if ok_c and bb then
                        rec.cover_bb, rec.cover_w, rec.cover_h = bb, cw, ch
                        rec.has_cover = true
                    end
                else
                    -- A record with a cover file (Kindle: Amazon's thumbnail)
                    -- carries cover_image_path, a plain string every painter
                    -- resolves itself, and gets the same cover overrides every
                    -- other shelf record gets from buildBookMeta.
                    pcall(_applyCoverOverrides, rec)
                end
            end
            page[#page + 1] = rec
        end
        return page, total
    end
    -- OPDS chip (bookshelf_opds_source / _window): cache-only - network is the
    -- widget layer's job (user-initiated), this must stay fast and offline-safe.
    -- Feed order is preserved: NO SortEngine pass (server order is semantic:
    -- "newest", search relevance). sort_priority is deliberately ignored.
    if kind == "opds" then
        local ok_w, OpdsWindow = pcall(require, "lib/bookshelf_opds_window")
        if not ok_w then return {}, 0 end
        local feed_url = source.feed_url
        if not feed_url then
            local ok_s, OpdsSource = pcall(require, "lib/bookshelf_opds_source")
            local server = ok_s and OpdsSource.getServer(source.id) or nil
            if not server then return {}, 0 end
            feed_url = server.url
        end
        local win = OpdsWindow.load(source.id, feed_url)
        local page, total, open_ended = OpdsWindow.slice(win, offset, limit)
        page.opds_open_ended = open_ended
        page.opds_needs_fetch = OpdsWindow.needsFetch(win, offset or 0, limit or 0)
                                or ((win.count or 0) == 0 and win.fetched_at == 0)
        -- Child windows loaded while decorating this page, keyed by feed url.
        -- The flattening pass and the cover borrow below both want a nav
        -- record's child window and neither may pay for it twice, so the load
        -- is memoised here (false memoises "load returned nothing", so a miss
        -- is not retried either).
        local child_windows = {}
        local function childWindow(url)
            local w = child_windows[url]
            if w == nil then
                w = OpdsWindow.load(source.id, url) or false
                child_windows[url] = w
            end
            return w or nil
        end
        -- Folder of one: a nav tile whose child feed holds exactly one book and
        -- no subfolders IS that book, so render it as the book rather than as a
        -- folder the user has to open to find a single thing inside (Project
        -- Gutenberg's popular lists are entirely this shape).
        --
        -- Cache-only, zero network -- the same discipline as the cover borrow
        -- below: OpdsWindow.load reads the persisted window and never fetches.
        -- A child that has never been drilled into has no cached window and so
        -- stays a folder; drilling into it once caches the window and the tile
        -- flattens on the next visit. That is the whole degradation: a folder,
        -- exactly as before this pass existed.
        --
        -- Runs BEFORE the cover and downloaded passes below so the substituted
        -- record is decorated like any other book on the page -- its own cached
        -- cover, its own downloaded tick -- rather than needing a second copy
        -- of that logic. Everything downstream then treats it as the ordinary
        -- remote book it is: tap opens the book modal, download works, the
        -- already-have tick shows.
        --
        -- Shallow copy for the same reason OpdsWindow.slice copies: page
        -- records get decorated, and a decorated record that is still the
        -- STORED window entry would be serialised into the OPDS cache on the
        -- next save. slice() copied what it handed back; win.entries read here
        -- is the stored table, so copy it before it enters the page.
        if not light_only then
            for _i = 1, #page do
                local rec = page[_i]
                if rec.is_opds_nav and rec.opds and rec.opds.feed_url then
                    local lone = opdsLoneChildBook(childWindow(rec.opds.feed_url))
                    if lone then
                        local copy = {}
                        for k, v in pairs(lone) do copy[k] = v end
                        page[_i] = copy
                    end
                end
            end
        end
        -- Render-time decoration: the description mirror, the record's own
        -- cached cover, the downloaded tick. Factored out because
        -- Repo.opdsLoneChildBook has to apply exactly the same set to the one
        -- record it hands the widget for a nav tap -- see the helper.
        opdsDecorate(page, light_only)
        local ok_c, OpdsCovers = pcall(require, "lib/bookshelf_opds_covers")
        if ok_c and OpdsCovers and not light_only then
            -- Fallback for a nav tile with no cover of its own: borrow the
            -- first cached cover out of the CHILD feed's own window, if that
            -- subcatalog has ever been drilled into and fetched. Purely a
            -- disk/in-memory read -- OpdsWindow.load reads the persisted
            -- window (no fetch), and OpdsCovers.cachedPath only stats the
            -- cache dir -- so a never-drilled folder that has no cached
            -- window simply stays a placeholder, exactly as before.
            --
            -- cover_borrowed marks the result as NOT the tile's own artwork.
            -- _opdsEnsureCovers (lib/bookshelf_widget.lua) reads that flag to
            -- keep fetching the tile's own cover even though cover_image_path
            -- is already non-nil -- without it a borrowed cover looked
            -- indistinguishable from a resolved one and permanently blocked
            -- the tile's own download from ever being selected as missing.
            -- The own-cover loop above always runs first and this loop's
            -- `not rec.cover_image_path` guard means it never overwrites that
            -- result: once the tile's own cover lands on disk, a later
            -- rebuild's cachedPath call fills cover_image_path in before this
            -- loop even looks, so the borrow (and the flag) are simply never
            -- applied -- the tile's own cover wins for good, no unborrowing
            -- step needed.
            --
            -- Stays HERE rather than moving into opdsDecorate with the rest:
            -- it needs this page's child-window memo, and it only ever applies
            -- to a page of nav tiles.
            for _i, rec in ipairs(page) do
                if rec.is_opds_nav and not rec.cover_image_path
                        and rec.opds and rec.opds.feed_url then
                    local child_win = childWindow(rec.opds.feed_url)
                    -- Only the first few rows are ever scanned for a cover to
                    -- borrow, so ask for exactly those rather than the feed.
                    local entries = child_win
                        and OpdsWindow.slice(child_win, 0, NAV_COVER_BORROW_ITER) or {}
                    local scanned = 0
                    for _j = 1, math.min(#entries, NAV_COVER_BORROW_ITER) do
                        if scanned >= NAV_COVER_BORROW_SCAN then break end
                        local child = entries[_j]
                        -- cachePath alone doesn't stat -- it just says whether
                        -- the child has a cover URL at all. A child with none
                        -- (a nav entry riding the same window) is ruled out for
                        -- free and must not spend the scan budget.
                        if OpdsCovers.cachePath(child) then
                            scanned = scanned + 1
                            local borrowed = OpdsCovers.cachedPath(child)
                            if borrowed then
                                rec.cover_image_path = borrowed
                                rec.cover_borrowed = true
                                break
                            end
                        end
                    end
                end
            end
        end
        return page, total
    end
    -- Diag: wrap getBySource so chip-switch / pagination logs can be
    -- correlated with fetch cost. The repo's existing per-fetcher logs
    -- show the *internal* breakdown; this outer log shows the
    -- end-to-end cost the caller pays, including the dispatch overhead
    -- and any predicate-path detour.
    local _diag_t0 = _gettime()
    local _diag_id = (source.id and (": id=" .. tostring(source.id):sub(1, 32)))
                     or ""

    -- Built-in kinds: delegate to existing functions; they already use
    -- Repo.getSortPriority(kind) internally, so callers should not pass
    -- a custom sort_priority for these (use the editor's sort UI instead,
    -- which writes back to the tab schema). filter on built-ins is also a
    -- no-op in v1.4 -- the existing functions do not yet honour it.
    -- Pass the calling tab's sort_priority through to the group fetchers.
    -- Without this they'd hardcode Repo.getSortPriority(<fixed tab id>) and
    -- miss any custom tab whose id is different from the source kind --
    -- e.g. a tab with id="all" and source.kind="authors" (user repurposed
    -- the Home chip to show the Authors view): without the pass-through,
    -- getAuthors would look up tab_id="authors" which doesn't exist in
    -- that user's schema and fall back to the legacy default sort.
    -- When a reading-status filter is active on a book-list built-in
    -- (all / recent / latest / favorites), don't take the early-return
    -- path -- the built-in fetchers don't honour the filter. Fall
    -- through to the predicate-based path below which applies it
    -- uniformly.
    --
    -- Group kinds (series/authors/genres/tags/formats/ratings) now
    -- accept a `filter` argument and apply it natively (Phase 1 of the
    -- filter-applies-to-groups feature). Empty groups are elided pre-
    -- pagination; covers and per-stack stats reflect the filtered set
    -- where appropriate. Folder cards through Repo.getAll do the same.
    --
    -- sort_priority gate for the legacy book-list fetchers: they use a
    -- single-key sort_<chip> setting with a small whitelist (date_added /
    -- title / recently_read on favorites, etc), and the v2 chip editor
    -- writes only to tab.sort_priority -- never to the legacy key. So a
    -- chip with sort_priority = [series_name, series_index, title]
    -- silently fell back to the fetcher's default ordering. Route through
    -- the predicate path whenever sort_priority is non-empty so the full
    -- SortEngine drives the order. Reported by user feedback on v2.0.1.
    --
    -- kind == "all" and kind == "folder" dispatch to Repo.getAll because
    -- that path produces FOLDER cards in addition to books (the tree view
    -- the user expects for a folder-organised library). The predicate path
    -- below returns books only and runs only when a status filter is active
    -- (books-only degradation). The caller's sort_priority is threaded into
    -- getAll so chip-configured sort applies to both partitions.
    local has_status_filter = Filter.isActive(filter)
    local has_custom_sort   = sort_priority and #sort_priority > 0
    -- Spine shelf, Home-folders source: sections instead of folder cards.
    -- Edge-on there is nothing to tap into -- the books already stand on the
    -- shelf -- so a folder becomes a badged run of its own books rather than
    -- a single drillable spine. Cover and list keep getAll's tree view, where
    -- folder styles and drill-in live. See Repo.getFolderSections.
    --
    -- A FOLDER source too (a folder drilled into from the cover view, or a
    -- shelf pinned to one): it went to getAll, so its subfolders stood on the
    -- spine shelf as book-like spines, which is what issue 420 reported.
    -- Sectioned from that folder down instead.
    if (kind == "all" or kind == "folder") and Repo.spine_light then
        local sopts = opts
        if kind == "folder" and source.id then
            sopts = {}
            for k, v in pairs(opts or {}) do sopts[k] = v end
            sopts.root = source.id
        end
        return Repo.getFolderSections(limit, offset, sort_priority, filter, sopts)
    end
    if not has_status_filter then
        if kind == "all"       then return Repo.getAll(nil, limit, offset, sort_priority, nil, opts)       end
        if kind == "folder"    then return Repo.getAll(source.id, limit, offset, sort_priority, nil, opts) end
        if not has_custom_sort then
            if kind == "recent"    then return Repo.getRecent(limit, offset, opts)       end
            if kind == "latest"    then return Repo.getLatest(limit, offset, opts)       end
            if kind == "favorites" then return Repo.getFavorites(limit, offset, opts)    end
        end
    else
        -- Folder views with an active status filter still produce folder
        -- cards, but only those with at least one matching book. getAll
        -- handles the filter natively below (see Phase 1 work).
        if kind == "all"    then return Repo.getAll(nil, limit, offset, sort_priority, filter, opts)       end
        if kind == "folder" then return Repo.getAll(source.id, limit, offset, sort_priority, filter, opts) end
    end
    if kind == "series"    then return Repo.getSeriesGroups(limit, offset, sort_priority, filter, opts) end
    if kind == "authors"   then return Repo.getAuthors(limit, offset, sort_priority, filter, opts) end
    if kind == "genres"    then return Repo.getGenres(limit, offset, sort_priority, filter, opts)  end
    if kind == "tags"      then return Repo.getTags(limit, offset, sort_priority, filter, opts)    end
    if kind == "formats"   then return Repo.getFormats(limit, offset, sort_priority, filter, opts) end
    if kind == "ratings"   then return Repo.getRatings(limit, offset, sort_priority, filter, opts) end
    if kind == "languages" then return Repo.getLanguages(limit, offset, sort_priority, filter, opts) end

    -- Custom kinds: walk the library and apply a predicate filter.
    -- Results are cached by (source, filter, sort_priority) so pagination
    -- within a tab reuses the full sorted candidate list rather than doing
    -- a fresh library walk + per-book BIM sweep on every page flip.
    --
    -- IMPORTANT: the cache stores FILEPATHS only, not full Book records.
    -- ImageWidget frees cover_bb after each paint, so reusing a Book record
    -- across rebuilds returns the SAME Book whose cover_bb has been freed
    -- (memory feedback_image_disposable_shared_book). We hydrate fresh on
    -- every page request by calling _safeBuildBookMeta for the visible slice.
    local cache_key = _bySourceCacheKey(source, filter, sort_priority)
    local cached_paths = _bySource_cache[cache_key]

    if cached_paths then
        -- Cache hit: slice the path list (already in sorted, post-filter
        -- order) and rehydrate just the visible page.
        local total = #cached_paths
        local from  = (offset or 0) + 1
        local to    = _hydrationStop(offset or 0, limit, total, total, "getBySource",
                                     (opts and opts.light_only) or Repo.spine_light)
        local page  = {}
        -- Repo.spine_light: the spine shelf renders colour + text, never a
        -- cover, so its pages hydrate from the batched light metadata (one
        -- SELECT) instead of a full _safeBuildBookMeta per record -- which
        -- measured ~20ms/record on device flash, i.e. the whole of a slow
        -- page turn on a 'library' chip.
        if (opts and opts.light_only) or Repo.spine_light then
            -- Letter-jump path: the caller only reads sort-key fields
            -- (title / author / series) to locate a page boundary and never
            -- renders these records, so skip the heavy _safeBuildBookMeta
            -- and serve light metadata. On a big chip this is the difference
            -- between thousands of DocSettings reads and one batched SELECT.
            local home  = HomeDir.get() or "/"
            local depth = BookshelfSettings.read("latest_walk_depth") or 3
            local light_cache = _getLightMetaCache(home, depth)
            for i = from, to do
                local b = _lightMetaForFp(light_cache, cached_paths[i])
                if b then page[#page + 1] = b end
            end
            return page, total
        end
        -- opts.lazy_cover: covers already in ScaledCoverCache skip the
        -- BIM zstd decode (want_cover=false); SpineWidget repaints them
        -- from the cache by filepath key. Same probe as getRecent/getAll.
        local ScaledCoverCache
        if opts and opts.lazy_cover then
            ScaledCoverCache = require("lib/bookshelf_scaled_cover_cache")
        end
        for i = from, to do
            local meta_opts
            if ScaledCoverCache and ScaledCoverCache:has(cached_paths[i]) then
                meta_opts = { want_cover = false }
            end
            local b = _safeBuildBookMeta(cached_paths[i], meta_opts)
            if b then page[#page + 1] = b end
        end
        return page, total
    end

    -- Cache miss: build the full candidate list with fresh records, sort,
    -- then cache the resulting filepath order. The miss-path callers get
    -- the freshly-built records (covers fresh by definition).
    local candidates
    do
        -- cachedWalk returns the full recursive file list. We hydrate each
        -- candidate with the LIGHT metadata builder (no cover_bb) so the
        -- predicate / filter / sort pass doesn't pull ~50KB of cover data
        -- per book into memory just to throw most of it away. The visible
        -- page slice is rebuilt with full _safeBuildBookMeta below, so
        -- covers are still rendered correctly -- just for 8 books instead
        -- of 3000.
        -- path_only: the predicate answers from the FILEPATH alone, so it can
        -- be asked before the light record exists. Membership tests are the
        -- common shape here -- "is it in the history", "is it in this
        -- collection", "is it under this folder" -- and building a record for
        -- every book in the library just to reject most of them is the
        -- dominant cost of opening such a chip. Predicates that read real
        -- fields (genre, author, tag) leave it unset and are unaffected.
        local _path_probe = {}
        local function loadCandidatesByPredicate(pred, walk_root, path_only)
            local home  = HomeDir.get() or "/"
            local depth = BookshelfSettings.read("latest_walk_depth") or 3
            -- walk_root lets a folder-scoped source (folder_flat, #76) walk
            -- its own subtree directly instead of the whole home tree --
            -- correct for folders OUTSIDE home_dir (Browse device), where a
            -- home-rooted walk + prefix filter would find nothing. The light
            -- metadata batch stays keyed to home; entries outside it fall
            -- back to a per-file build in _lightMetaForFp.
            local cands = cachedWalk(walk_root or home, depth)
            -- Pull the whole library's light metadata in a single batch
            -- SELECT instead of one prepared-statement call per file. On a
            -- 2000-book Calibre library that's ~50ms (one SQLite roundtrip)
            -- vs ~2-5s (2000 roundtrips). _lightMetaForFp falls back to
            -- per-file build if a file isn't in the batch result.
            local light_cache = _getLightMetaCache(home, depth)
            -- Build a fp -> last-read-time map from ReadHistory once.
            -- Without this the sort_engine's last_opened comparator sees
            -- nil for every book and gives a stable-but-meaningless order
            -- (reversing just flips the same arbitrary order). Same
            -- mechanism getAll uses when its prefetch sees needs.last_opened.
            local rh        = getReadHistory()
            local read_time = {}
            for _i, entry in ipairs(rh.hist) do
                local t = entry.time or 0
                if t > (read_time[entry.file] or 0) then read_time[entry.file] = t end
            end
            local matched = {}
            for _i, c in ipairs(cands) do
                -- One reused probe table rather than one per candidate: the
                -- predicate only ever reads .filepath from it.
                local wanted = true
                if path_only then
                    _path_probe.filepath = c.fp
                    wanted = pred(_path_probe) and true or false
                end
                local b = wanted and _lightMetaForFp(light_cache, c.fp) or nil
                if b and (path_only or pred(b)) then
                    -- Enrich the light record so the sort engine has
                    -- something to compare on:
                    --   * _last_read  -> for sort by "Opened"
                    --   * date_added  -> for sort by "Added" (file mtime is
                    --     the natural proxy on every supported device; for
                    --     Calibre users it's the sync time, for direct
                    --     copies it's the copy time).
                    b._last_read = read_time[c.fp] or 0
                    if not b.date_added then b.date_added = c.mtime or 0 end
                    -- size comes straight from the walk's lfs.attributes
                    -- result -- no extra syscall. Sort-by-File-size on
                    -- custom-source tabs needs this.
                    if not b.size then b.size = c.size or 0 end
                    matched[#matched + 1] = b
                end
            end
            return matched
        end

        -- loadCandidatesFromPaths(set): the same records, for a source that
        -- is a LIST of books (history, favourites, a collection) rather than
        -- a slice of the library. Those went through the library walk and
        -- kept only its matches, so a book outside the home folder -- read,
        -- or collected, from elsewhere on the device -- dropped out of its
        -- chip the moment a filter or a sort was set on it, while the plain
        -- chip showed it (issue 305). The list is also far shorter than the
        -- library, so no walk at all. Sorted by path, as the walk was, so
        -- ties in the sort below keep a stable order.
        --
        -- Only BOOKS, by the walk's own test, and nothing inside KOReader's
        -- own folder. The default Recent chip carries a sort, so every reader
        -- comes through here, and KOReader's history holds more than books: an
        -- image opened from the file browser, and the quickstart guide
        -- (<koreader>/help/quickstart-*.html) that nearly everyone was shown
        -- on first launch. The walk never saw those, and neither should this.
        local function loadCandidatesFromPaths(set)
            local lfs = require("libs/libkoreader-lfs")
            local ko_dir
            local ok_ds, DataStorage = pcall(require, "datastorage")
            if ok_ds and type(DataStorage) == "table" and DataStorage.getDataDir then
                local ok_d, d = pcall(function() return DataStorage:getDataDir() end)
                if ok_d and type(d) == "string" and d ~= "" and d ~= "/" then
                    ko_dir = d:gsub("/+$", "") .. "/"
                end
            end
            local home  = HomeDir.get() or "/"
            local depth = BookshelfSettings.read("latest_walk_depth") or 3
            local light_cache = _getLightMetaCache(home, depth)
            local read_time = {}
            for _i, entry in ipairs(getReadHistory().hist) do
                local t = entry.time or 0
                if t > (read_time[entry.file] or 0) then read_time[entry.file] = t end
            end
            local paths = {}
            -- ...unless the home folder is in there too: some readers keep
            -- their books inside KOReader's folder (Android especially).
            local home_prefix = (HomeDir.get() or "/"):gsub("/+$", "") .. "/"
            -- A home of "/" (unset, or the filesystem root) contains
            -- everything, so it is no reason to keep KOReader's own files.
            local function kosOwn(fp)
                return ko_dir and fp:sub(1, #ko_dir) == ko_dir
                       and (home_prefix == "/" or fp:sub(1, #home_prefix) ~= home_prefix)
            end
            for fp in pairs(set) do
                if type(fp) == "string" and not _isRemotePath(fp)
                        and _supportedExt(fp:match("([^/]+)$")) and not kosOwn(fp) then
                    paths[#paths + 1] = fp
                end
            end
            table.sort(paths)
            local matched = {}
            for _i, fp in ipairs(paths) do
                local attr = lfs.attributes(fp)
                local b = attr and attr.mode == "file" and _lightMetaForFp(light_cache, fp) or nil
                if b then
                    b._last_read = read_time[fp] or 0
                    if not b.date_added then b.date_added = attr.modification or 0 end
                    if not b.size then b.size = attr.size or 0 end
                    matched[#matched + 1] = b
                end
            end
            return matched
        end

        if kind == "library" or kind == "all" or kind == "latest" then
            -- Library walk + tautological predicate. 'all' (Home folders)
            -- and 'latest' (Latest added) reach this branch only when a
            -- filter is active -- otherwise their early-returns above
            -- run their bespoke fetchers. With a filter, treating them
            -- as 'walk everything and filter' is semantically right;
            -- the sort_priority the caller supplies still drives order.
            candidates = loadCandidatesByPredicate(function(_b) return true end)
        elseif kind == "recent" then
            -- Recently read with filter: match against ReadHistory
            -- filepaths. ReadHistory is already ordered newest-first,
            -- but the sort_priority pass below decides final order
            -- (default is last_opened desc, which matches the legacy
            -- getRecent behaviour).
            local rh = getReadHistory()
            local in_history = {}
            for _i, entry in ipairs(rh.hist) do
                -- entry.dim: deleted through the file manager (see getRecent).
                if entry.file and not entry.dim then in_history[entry.file] = true end
            end
            candidates = loadCandidatesFromPaths(in_history)
        elseif kind == "favorites" then
            -- Favourites with filter: match against the favorites
            -- collection. Same flow as 'collection' but with a fixed
            -- collection name.
            local rc = require("readcollection")
            local set = {}
            local fav = rc.coll and rc.coll.favorites
            if type(fav) == "table" then
                for _file, item in pairs(fav) do
                    local fp = item.file or _file
                    if type(fp) == "string" then set[fp] = true end
                end
            end
            candidates = loadCandidatesFromPaths(set)
        elseif kind == "folder" then
            -- Reached only when a status filter is active (otherwise the
            -- early-return above sends folder chips to getAll for tree view).
            -- Books-only descent: prefix is source.id with exactly one
            -- trailing slash so "/lib/comics" doesn't false-match
            -- "/lib/comics-x/...". Accepts source.id stored either with or
            -- without a trailing slash.
            local prefix = (source.id or ""):gsub("/+$", "") .. "/"
            candidates = loadCandidatesByPredicate(function(b)
                return type(b.filepath) == "string" and b.filepath:sub(1, #prefix) == prefix
            end, nil, true)
        elseif kind == "folder_flat" then
            -- Flattened folder (#76): every book under source.id at any
            -- depth, no folder cards -- the folder equivalent of "library"
            -- (Home flattened). Walk the folder root directly so it works
            -- for folders both inside and outside home_dir; the walk is
            -- already scoped to the subtree, so the predicate is tautological.
            candidates = loadCandidatesByPredicate(function(_b) return true end,
                (source.id or ""):gsub("/+$", ""))
        elseif kind == "collection" then
            local rc  = require("readcollection")
            local set = {}
            -- The collection's OWN order, which is what KOReader files it by
            -- (ReadCollection:getOrderedCollection sorts on this field). Kept
            -- separate from `set` rather than stored in it: KOReader writes
            -- `order` only for a manually collated collection, so for any
            -- other one it is nil for every item, and a nil in the membership
            -- table would read as "not a member" and empty the shelf.
            local order = {}
            local coll = rc.coll and rc.coll[source.id]
            if type(coll) == "table" then
                for _i, item in pairs(coll) do
                    if type(item) == "table" and item.file then
                        set[item.file]   = true
                        order[item.file] = item.order
                    end
                end
            end
            candidates = loadCandidatesFromPaths(set)
            -- Stamped onto the record so the collection_order sort key can see
            -- it; the records come out of the library store, which knows
            -- nothing about collections (issue 441).
            for _i, b in ipairs(candidates) do
                b.collection_order = order[b.filepath]
            end
        elseif kind == "tag" then
            -- Book records carry BIM/Calibre tag data under b.genres (the
            -- field name is unified across the cb.tags + cb.keywords +
            -- BIM-keywords sources in buildBookMeta). The predicate read
            -- b.tags, which no record ever sets, so this dispatch was
            -- silently empty. No production UI creates source.kind="tag"
            -- today (the chip editor's "Specific tag…" writes
            -- kind="collection"), but the drilldown payload in
            -- bookshelf_widget.lua does use kind="tag" and a future
            -- migration / settings edit could route through this branch.
            local target = source.id
            candidates = loadCandidatesByPredicate(function(b)
                if type(b.genres) ~= "table" then return false end
                for _i, t in ipairs(b.genres) do if t == target then return true end end
                return false
            end)
        elseif kind == "genre" then
            -- Match on normalized form so case + plural variants of the
            -- same conceptual genre are picked up. Same normalization as
            -- _buildGroups -- keep both in sync if the normaliser changes.
            local target_norm = _normalizeGenre(source.id or "")
            candidates = loadCandidatesByPredicate(function(b)
                if type(b.genres) ~= "table" then return false end
                for _i, g in ipairs(b.genres) do
                    if _normalizeGenre(g) == target_norm then return true end
                end
                return false
            end)
        elseif kind == "author" then
            -- Pinned-author chips ("Create chip from this" on an author
            -- stack) match against the full authors list, not just the
            -- primary author -- otherwise a chip pinned to a co-author
            -- would miss the books they share with the primary author.
            -- Keeps this path consistent with the Authors tab drilldown,
            -- which uses _buildGroups("author", b.authors, multi=true).
            local target = source.id
            -- CANONICAL match, not raw string equality (issue 347): the
            -- chip's id was captured from the author CARD, whose display
            -- name follows the "Author name formatting" setting - under
            -- "Surname, First name" that is a form no book's metadata
            -- carries, so a raw compare matched nothing and the chip came
            -- up empty (while the editor's preview, which goes through the
            -- groups pipeline, showed the books fine). _normalizeAuthor is
            -- the same canonicaliser the Authors tab groups with, so the
            -- chip finds exactly the card's books in every format setting.
            local target_norm = _normalizeAuthor(target)
            candidates = loadCandidatesByPredicate(function(b)
                if b.author == target or b.author_name == target or b.author_surname == target then
                    return true
                end
                if b.author and _normalizeAuthor(b.author) == target_norm then
                    return true
                end
                if type(b.authors) == "table" then
                    for _i, a in ipairs(b.authors) do
                        if a == target or _normalizeAuthor(a) == target_norm then
                            return true
                        end
                    end
                end
                return false
            end)
        elseif kind == "single_series" then
            -- Books whose series_name matches the picked one. Light meta
            -- uses series_name; full Book records use both series_name and
            -- series. Check both for safety.
            local target = source.id
            candidates = loadCandidatesByPredicate(function(b)
                return b.series_name == target or b.series == target
            end)
        elseif kind == "status" then
            local target = source.id
            candidates = loadCandidatesByPredicate(function(b)
                return b.read_status == target
            end)
        elseif kind == "format" then
            -- Match by uppercase extension to align with _formatKey + the
            -- "Specific format..." picker. Light meta carries .filepath
            -- (filename in fallback shapes); the matcher only needs the
            -- extension, no BIM read required.
            local target = (source.id or ""):upper()
            candidates = loadCandidatesByPredicate(function(b)
                return _formatKey(b.filepath) == target
            end)
        elseif kind == "language" then
            -- The chip's id is the language card's display label (e.g.
            -- "English") or, for older paths, a code. Canonicalise it the same
            -- way book languages are canonicalised so every spelling matches
            -- (en / eng / en-GB / English -> one key). Mirrors _buildGroups.
            local raw_id     = source.id or ""
            local target_key = BookshelfLang.canonical(raw_id)
            local is_unknown = raw_id == "" or raw_id == _LANG_UNKNOWN_KEY
                or _normalizeLang(raw_id) == _normalizeLang(tr("Unknown"))
            if is_unknown or not target_key then
                candidates = loadCandidatesByPredicate(function(b)
                    return b.lang == nil or b.lang == ""
                end)
            else
                candidates = loadCandidatesByPredicate(function(b)
                    if b.lang == nil or b.lang == "" then return false end
                    return BookshelfLang.canonical(b.lang) == target_key
                end)
            end
        elseif kind == "rating" then
            -- source.id is "1".."5" for a star count, or "unrated" / "0".
            -- Predicate fetches the rating lazily via readProgress (with
            -- .sdr fast-path) and matches. Heavier than other predicates
            -- because rating lives in DocSettings, but books without a
            -- .sdr short-circuit -- on a typical library that's most of
            -- them.
            local raw = tostring(source.id or "")
            local target = tonumber(raw)
            if raw == "unrated" or target == 0 then target = nil end
            candidates = loadCandidatesByPredicate(function(b)
                if not b._progress_fetched and b.filepath then
                    local own
                    if _hasSidecar(b.filepath) then
                        local _p, _s, r = Repo.readProgress(b.filepath)
                        own = r
                    end
                    b.rating = Repo.effectiveRatingStars(b.filepath, own)
                    b._progress_fetched = true
                end
                return b.rating == target
            end)
        else
            return {}, 0
        end

        -- Filter candidates by any active filter dimension (status, genre,
        -- lang, format, collections, folders). Light metadata doesn't carry
        -- read_status, so status is resolved lazily via _recordMatches --
        -- only when the compiled filter constrains it -- so most users pay
        -- nothing extra. _recordMatches encapsulates the sidecar fast-path
        -- (_hasSidecar gates the heavier DocSettings:open, issue #113/#117)
        -- and sets _progress_fetched so the subsequent sort prefetch below
        -- doesn't re-open sidecars already read here.
        if Filter.isActive(filter) then
            local compiled_e = Filter.compile(filter, Repo.filterOpts())
            local kept = {}
            for _i, b in ipairs(candidates) do
                if _recordMatches(b, compiled_e) then kept[#kept + 1] = b end
            end
            candidates = kept
        end

        -- needs-introspection for the sort: only pay for DocSettings reads
        -- when the user's sort priority actually depends on progress data.
        _prefetchSortProgress(candidates, sort_priority, "getBySource")

        -- Sort.
        if sort_priority and #sort_priority > 0 then
            SortEngine.sort(candidates, sort_priority)
        end
    end

    -- Cache the FILEPATHS in sorted/filtered order. Next page request
    -- slices this list and rehydrates fresh Book records so cover_bb is
    -- always fresh.
    local paths = {}
    for _i, b in ipairs(candidates) do paths[#paths + 1] = b.filepath end
    _capInsert(_bySource_cache, _bySource_cache_order, cache_key, paths)

    -- candidates is light metadata (no covers). For the visible slice,
    -- rebuild with the full _safeBuildBookMeta path so covers render.
    -- Light records are released for GC after this function returns.
    local total = #paths
    local from  = (offset or 0) + 1
    local to    = _hydrationStop(offset or 0, limit, total, total, "getBySource",
                                 (opts and opts.light_only) or Repo.spine_light)
    local page  = {}
    -- See the HIT slice above: spine pages serve light records.
    if (opts and opts.light_only) or Repo.spine_light then
        -- Letter-jump path: the sorted light candidates already carry the
        -- sort-key fields the caller needs, so hand back that slice directly
        -- rather than re-hydrating full records (covers etc.) it won't use.
        for i = from, to do
            local b = candidates[i]
            if b then page[#page + 1] = b end
        end
        return page, total
    end
    -- opts.lazy_cover: same ScaledCoverCache probe as the HIT path above.
    local ScaledCoverCache
    if opts and opts.lazy_cover then
        ScaledCoverCache = require("lib/bookshelf_scaled_cover_cache")
    end
    for i = from, to do
        local meta_opts
        if ScaledCoverCache and ScaledCoverCache:has(paths[i]) then
            meta_opts = { want_cover = false }
        end
        local b = _safeBuildBookMeta(paths[i], meta_opts)
        if b then page[#page + 1] = b end
    end
    logger.dbg(string.format(
        "[bookshelf perf] getBySource: kind=%s%s path=predicate cached=%s total=%d elapsed=%.0fms",
        kind, _diag_id, cached_paths and "HIT" or "MISS", total,
        (_gettime() - _diag_t0) * 1000))
    return page, total
end

-- The Pages sort's resolver for a record that carries no count of its own
-- (SortEngine.pageCountOf). A book with a sidecar goes through readProgress,
-- the same ladder the badge and %page_count use (cached, 120s); one without
-- takes only the free rungs -- its filename marker and the page-count scan's
-- store -- so an unopened library sorts without a single sidecar open.
SortEngine.setPageCountResolver(function(fp)
    if _hasSidecar(fp) then
        return select(4, Repo.readProgress(fp))
    end
    return Repo.pageCountFor(fp)
end)

return Repo
