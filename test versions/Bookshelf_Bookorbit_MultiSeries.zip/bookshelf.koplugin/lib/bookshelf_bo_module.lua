--[[
Adapter: one BookOrbit dashboard widget -> one Bookshelf micro-module spec.

BookOrbit's widgets are functions `W[type](ctx, w, h, props, item)` that return
content of EXACTLY w x h pixels and lay themselves out for the box they get
(BoardUI.pick tries layouts from richest to most compact). Bookshelf's host
instead hands a module a width (and usually a height) and, in the hero grid,
re-renders it at other scales to fill the cell. The two fit together because a
widget that fills the whole cell is already "fitted": the host's grow/shrink
search stops at once. So this adapter ignores ctx.scale and renders the widget
at the cell's real size.

  * The host draws the card (grey surface, padding, hairline). The tile drawn
    here has NO outline of its own, so there is no card inside a card. A widget
    BookOrbit draws on a dark "ink" tile (clock, Continue reading...) keeps it:
    a black rounded panel filling the cell.
  * Height: the hero grid and full-screen view pass ctx.height. The start menu
    does not (cards take their natural height), so one is derived from the
    widget's BookOrbit shape (HEIGHT_RATIO of its first size code).
  * The Add picker passes ctx.preview = true: the data layer is told, and does
    no fetching (sample data instead).
  * Data (Batch 3): the adapter asks lib/bookshelf_bo_data for `d`, passing the
    card's ctx.refresh (so background fetches repaint it once) and what the
    widget needs beyond the dashboard body (shelves, name lists; derived from the
    widget type, see needsFor). A spec with `server = true` shows a hint instead
    of an empty tile while BookOrbit is not set up.

Use:  return Bo.specs{ { key = ..., type = ..., ... }, ... }   -- a list of specs
]]
local logger = require("logger")
local _ = require("lib/bookshelf_i18n").gettext

local Bo = {}

-- Height / width of a tile of each BookOrbit size code, from BoardLayout's
-- grid units (S 1x1, M 2x1, L 2x2, W cols x1, XL cols x2). W is floored to a
-- usable strip rather than the 4:1 a literal reading gives.
local HEIGHT_RATIO = { S = 1, M = 0.5, L = 1, W = 0.34, XL = 0.5 }

local function ratioFor(code)
    return HEIGHT_RATIO[code or "M"] or 0.5
end

-- Background + corner radius for a tile, by BookOrbit chrome. "ink" is the dark
-- tile; "fill" the light grey one; anything else sits straight on the host card.
-- DARK-THEME POLICY (Batch 4): BookOrbit draws its text in black/greys, so on a
-- dark host card an unframed widget would be black on dark. Such a widget is
-- instead drawn on a light rounded panel (a card inside the card), which keeps
-- every widget legible without recolouring the vendored toolkit.
local function isDark(color)
    if not color then return false end
    local ok, v = pcall(function() return color:getColor8().a end)
    return ok and type(v) == "number" and v < 128
end

local function chromeFor(chrome, INK, px, card_bg)
    if chrome == "ink" then return { bg = INK.black, radius = px(10) } end
    if chrome == "fill" then return { bg = INK.ge, radius = px(10) } end
    if isDark(card_bg) then return { bg = INK.white, radius = px(10) } end
    return { bg = card_bg or INK.white, radius = 0 }
end

-- Draw one widget at exactly w x h, or nil when BookOrbit has no such widget
-- (or it is not vendored yet). Errors from the widget propagate as `nil, err`.
local function drawTile(d, type_, props, w, h, chrome, cw, text_pct)
    local Widgets = require("lib/bookorbit_board/widgets")
    local BoardUI = require("lib/bookorbit_board/ui")
    local Metrics = require("lib/bookorbit_board/metrics")
    local INK, px = Metrics.INK, Metrics.px
    local ok_fn, fn = pcall(function() return Widgets.W[type_] end)
    if not ok_fn or not fn then return nil, "no widget " .. tostring(type_) end

    local Kit = require("lib/bookshelf_module_kit")
    local ch = chromeFor(chrome, INK, px, Kit.CARD_BG)
    local bo_ctx = { d = d, tiles = "outline", tap_resumes = true }
    props = props or {}
    BoardUI.debug_widget = type_ .. " " .. w .. "x" .. h
    -- Text size for this card (percent, 100 = BookOrbit's own). Part of the
    -- layout-pick scope below: a bigger font can make a richer layout stop
    -- fitting, so the remembered winner must not be shared across sizes.
    text_pct = text_pct or 100
    Metrics.setTextScale(text_pct / 100)
    BoardUI.pickScope(type_ .. ":" .. tostring(props.source or props.link or props.animal or "")
        .. ":" .. w .. "x" .. h .. ":" .. tostring(ch.bg) .. ":t" .. text_pct, d.fingerprint)
    local surface = BoardUI.surface
    BoardUI.surface = ch.bg
    -- collectHits records every BoardUI.hit(...) made while the widget builds:
    -- those are the widget's own tappable parts (Resume button, a book row...).
    local ok, content, hits = pcall(function()
        local c, sink = BoardUI.collectHits(function() return fn(bo_ctx, w, h, props, { type = type_, props = props, cw = cw }) end)
        return c, sink
    end)
    BoardUI.surface = surface
    BoardUI.pickScope(nil, d.fingerprint)
    Metrics.setTextScale(1)
    if not ok then return nil, content end
    return BoardUI.overlay(w, h, {
        { widget = BoardUI.box({ w = w, h = h, radius = ch.radius, bg = ch.bg }) },
        { widget = content },
    }), hits
end

-- Where each hit area landed, in the returned tile's own coordinates. A hit
-- area only learns its position when painted, so the tile is painted once into
-- a throw-away buffer at (0,0); the host then does the screen translation.
-- Regions are listed topmost-first (the last hit built is on top), matching
-- BookOrbit's own "last area wins" rule against the host's "first wins".
local function regionsFor(tile, hits, w, h)
    if not hits or #hits == 0 then return nil end
    local ok_bb, BB = pcall(require, "ffi/blitbuffer")
    if not ok_bb or not BB then return nil end
    local ok_new, bb = pcall(BB.new, w, h, BB.TYPE_BB8)
    if not ok_new or not bb then return nil end
    pcall(function() bb:fill(BB.COLOR_WHITE) end)
    pcall(function() tile:paintTo(bb, 0, 0) end)
    pcall(function() bb:free() end)
    local regions, actions = {}, {}
    for i = #hits, 1, -1 do
        local a = hits[i]
        local r = a.dimen
        if r and r.w and r.w > 0 and r.h and r.h > 0 and a.action then
            local id = "h" .. #regions + 1
            regions[#regions + 1] = { id = id, x = r.x, y = r.y, w = r.w, h = r.h }
            actions[id] = a.action
        end
    end
    if #regions == 0 then return nil end
    return regions, actions
end

-- What a widget needs fetched beyond the dashboard body, derived from its type
-- and props so category files stay declarative. `link` tiles preview books from
-- other shelves (see W.link in the vendored widgets); `dust` reads the
-- never-opened books. An explicit o.needs is merged in.
local LINK_SHELVES = {
    series = { "up-next-in-series" },
    authors = { "recently-added", "random" },
    library = { "recently-added", "random" },
}
local function needsFor(o)
    local props = o.props or {}
    local needs = { shelves = {}, names = {} }
    local function shelf(source, params) needs.shelves[#needs.shelves + 1] = { source = source, params = params } end
    if o.type == "shelf" then
        shelf(props.source or "random", props.params)
    elseif o.type == "link" then
        for _i, source in ipairs(LINK_SHELVES[props.link] or {}) do shelf(source) end
        if props.link == "collections" or props.link == "scopes" then needs.names[#needs.names + 1] = props.link end
    elseif o.type == "dust" then
        shelf("unopened")
    end
    for _i, w in ipairs(o.needs and o.needs.shelves or {}) do shelf(w.source, w.params) end
    for _i, n in ipairs(o.needs and o.needs.names or {}) do needs.names[#needs.names + 1] = n end
    return needs
end
Bo.needsFor = needsFor

-- Per-spec memory shared by render (writes) and on_tap (reads): the data the
-- card was last drawn from, its props, and the actions of its tappable parts.
-- Actions are derived from data, so the last render's are the right ones for
-- an instance. A spec that can be added several times with different config
-- (Shelf from your library) keeps one slot PER CARD, keyed by the host's entry
-- table (ctx.entry); without an entry (the picker, an old host) there is one.
local SHARED = {}
local function makeState()
    return { slots = setmetatable({}, { __mode = "k" }) }
end

local function slotFor(state, ctx)
    local key = (ctx and ctx.entry) or SHARED
    local slot = state.slots[key]
    if not slot then
        slot = { d = nil, props = nil, actions = {}, region_key = nil, regions = nil }
        state.slots[key] = slot
    end
    return slot
end

-- The props a card draws with: the spec's fixed ones, or, for a configurable
-- spec, what its per-card config yields (falling back to the spec's defaults
-- before anything is configured).
local function propsFor(o, ctx)
    if o.props_from and ctx and ctx.config then
        local ok, p = pcall(o.props_from, ctx.config)
        if ok and type(p) == "table" then return p end
    end
    return o.props
end

-- Text size of a card as a percentage: the card's own font step
-- (entry.fscale, -3..+5, 10% each) times the global micro-module size setting
-- where that applies (the grids, not the start menu or the picker). The
-- BookOrbit widgets lay out from the box they are given and ignore ctx.scale,
-- so the host's generic font multiplier cannot reach them; this does.
function Bo.textPercent(ctx)
    local pct = 100
    if ctx and not ctx.preview and (ctx.surface == "hero" or ctx.surface == "fullscreen") then
        local ok, BS = pcall(require, "lib/bookshelf_settings_store")
        local g = ok and BS and tonumber(BS.read("hero_module_font_scale", 100)) or 100
        if g and g > 0 then pct = g end
    end
    local fs = tonumber(ctx and ctx.entry and ctx.entry.fscale) or 0
    if fs < -3 then fs = -3 elseif fs > 5 then fs = 5 end
    return math.max(30, math.floor(pct * (1 + 0.1 * fs) + 0.5))
end

local function makeRender(o, state)
    return function(ctx)
        local Data = require("lib/bookshelf_bo_data")
        local Kit = require("lib/bookshelf_module_kit")
        local slot = slotFor(state, ctx)
        local props = propsFor(o, ctx)
        local needs = needsFor{ type = o.type, props = props, needs = o.needs }
        local w = math.max(1, ctx.width or 1)
        local h = ctx.height
        if not h or h <= 0 then
            h = math.floor(w * ratioFor(o.sizes and o.sizes[1]) + 0.5)
        elseif ctx.preview then
            -- Picker thumbnail: the widget's own shape, never taller than the
            -- grey area it sits in.
            h = math.min(h, math.floor(w * ratioFor(o.sizes and o.sizes[1]) + 0.5))
        end
        if ctx.max_height and ctx.max_height > 0 then h = math.min(h, ctx.max_height) end
        h = math.max(1, h)

        local d = Data.get{ preview = ctx.preview == true, refresh = ctx.refresh, needs = needs }
        if not ctx.preview then slot.d, slot.props, slot.refresh = d, props, ctx.refresh end
        -- A server-backed widget with nothing to show yet and nowhere to get it
        -- from says so, rather than drawing an empty tile that looks broken.
        if o.server and (d.not_configured or d.server_too_old) then
            local msg = d.not_configured
                and _("Set up your BookOrbit server first (Bookshelf menu → BookOrbit → Connect).")
                or _("This widget needs a newer BookOrbit server.")
            return Kit.fitText{ text = msg, size = 13, scale_pct = 100,
                width = math.max(50, w), fgcolor = Kit.COLOR_MUTED }
        end
        -- BookOrbit sizes a shelf by grid columns: a 2-wide tile shows 3 covers,
        -- a wide one as many as fit. XL / W are the wide shapes.
        local first = o.sizes and o.sizes[1]
        local cw = (first == "XL" or first == "W") and 4 or 2
        local text_pct = Bo.textPercent(ctx)
        local tile, hits = drawTile(d, o.type, props, w, h, o.chrome, cw, text_pct)
        if not tile then
            logger.warn("[bookshelf] BookOrbit widget", o.key, "failed:", hits)
            return Kit.fitText{ text = _("Could not draw this widget."), size = 13,
                scale_pct = 100, width = math.max(50, w), fgcolor = Kit.COLOR_MUTED }
        end
        -- Tap regions: only for live cards of widgets that have taps. Cached by
        -- data fingerprint + size (+ which shelf) so the throw-away paint
        -- happens once, not on every minute tick or repaint.
        if o.taps and not ctx.preview and ctx.set_tap_regions then
            local key = tostring(d.fingerprint) .. ":" .. w .. "x" .. h .. ":t" .. text_pct .. ":" .. tostring(props and props.source)
                .. ":" .. tostring(props and props.params and props.params.libraryId or props and props.title or "")
            if slot.region_key ~= key then
                local regions, actions = regionsFor(tile, hits, w, h)
                slot.region_key, slot.regions, slot.actions = key, regions or {}, actions or {}
            end
            ctx.set_tap_regions(slot.regions)
        end
        return tile
    end
end

-- Taps that change something right here (the card repaints, the menu stays):
-- reshuffle, brightness steps, Wi-Fi, night mode, Sync now, Gathering dust's
-- "next book". Everything else
-- opens something else and lets the menu close first.
local IN_PLACE = { shuffle = true, light = true, wifi = true, night = true, sync = true, noop = true,
    ["dust-next"] = true }

--- One spec. o: key, type (BookOrbit widget type), title, summary, category,
--- is_new, sizes (BookOrbit size codes, first = default shape), props, chrome,
--- wants_minute_tick, on_tap, taps (true = the widget has taps: declares tap
--- regions and gets the default on_tap), keep_open, network, props_from
--- (function(config) -> props: per-card props from ctx.config, for a spec added
--- several times with different settings), on_add / show_settings (passed
--- through to the host), server (true when the widget
--- draws server data: shows a hint until BookOrbit is set up), needs (extra
--- { shelves = {{source=,params=}}, names = {...} } beyond what the type implies).
function Bo.spec(o)
    assert(o.key and o.type and o.title, "Bo.spec needs key, type and title")
    local state = makeState()
    local on_tap = o.on_tap
    if not on_tap and o.taps then
        -- Default tap: the part of the card under the finger (a region the
        -- render declared), else the whole-card action BookOrbit gives this
        -- widget type. Both come from lib/bookshelf_bo_actions.
        on_tap = function(ctx)
            local Actions = require("lib/bookshelf_bo_actions")
            local slot = slotFor(state, ctx)
            local action = ctx and ctx.tapped_region and slot.actions[ctx.tapped_region]
            if not action then action = Actions.defaultFor(o.type, slot.d, slot.props or o.props) end
            -- slot.refresh = the card's own repaint (from its last render): actions that
            -- finish later (Sync now, Wi-Fi) use it, since the tap ctx may have none.
            Actions.run(action, ctx, { props = slot.props or o.props, refresh = slot.refresh })
        end
    end
    local keep_open = o.keep_open
    if keep_open == nil and o.taps then
        keep_open = function(ctx)
            local slot = slotFor(state, ctx)
            local a = ctx and ctx.tapped_region and slot.actions[ctx.tapped_region]
            if a == nil then
                -- A whole-card tap: Sync status turns into Wi-Fi/Sync now.
                local Actions = require("lib/bookshelf_bo_actions")
                a = Actions.defaultFor(o.type, slot.d, slot.props or o.props)
            end
            return a ~= nil and IN_PLACE[a.kind] == true
        end
    end
    local spec = {
        key = o.key,
        title = o.title,
        summary = o.summary or _("BookOrbit. Works offline."),
        category = o.category,
        is_new = o.is_new,
        render = makeRender(o, state),
        on_tap = on_tap,
        keep_open = keep_open,
        wants_minute_tick = o.wants_minute_tick,
        network = o.network,
        on_add = o.on_add,
        show_settings = o.show_settings,
        -- The widget scales its own text (Bo.textPercent); the host's generic
        -- font multiplier would only re-render it to no effect.
        own_font_scale = true,
        -- A one-cell BookOrbit widget packs as a square in the hero grid.
        aspect = (o.sizes and o.sizes[1] == "S") and "square" or nil,
    }
    return spec
end

--- A list of specs, ready to be a micromodules/ file's return value.
function Bo.specs(list)
    local out = {}
    for _i, o in ipairs(list) do out[#out + 1] = Bo.spec(o) end
    return out
end

return Bo
