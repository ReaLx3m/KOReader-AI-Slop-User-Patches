--[[--
Prescale step for BookOrbit decode-ahead (pure logic, no KOReader dependency).

Problem (see HANDOFF_prefetch_prescale): with "Decode covers ahead" ON the
prefetch pool already decodes each cover of the NEXT page into a raw bitmap,
but the first paint of that page still has to scale every raw bitmap to the
tile size and put it into ScaledCoverCache, which writes it to the flash disk
cache synchronously. On a slow e-reader that is seconds on the UI thread. A
page that was visited before finds its covers already scaled in the cache and
only blits.

This object is the "scale it now, in the idle tick" step. For ONE record that
was just decoded it asks the injected deps:

  1. what size would the tile paint this cover at (dims),
  2. is the scaled cache already holding it at that size (has),
  3. else scale the raw bitmap to that size (scale),
  4. and put the result into the scaled cache (put, which writes the disk).

It decides nothing about WHEN (the source calls it from an idle tick) and
touches no widget: the widget builds the deps (S3). Everything is injected, so
it is testable off-device (tools/bo_tests/test_bo_prescale.lua).

  local P = Prescale.new{
    dims   = function(record) -> img_w, img_h | nil,   -- exact painted image size
    scale  = function(bb, w, h) -> bb | nil,           -- same scaler as SpineWidget
    has    = function(fp, w, h) -> bool,               -- cache holds it at >= w x h
    put    = function(fp, bb) -> bb | nil,             -- cache put (writes the disk)
    now    = function() -> seconds,                    -- optional; default os.clock
    logger = optional (needs :dbg),
  }
  P:run(record, bb) -> "scaled" | "already", stats
                    -> nil, reason

  stats  = { w =, h =, scale_ms =, put_ms = }   (both ms are 0 for "already")
  reason = "not_book" | "no_dims" | "no_bitmap" | "scale_failed" | "put_failed" | "error"

Contract the caller (the source, S2) relies on:
  * This object NEVER frees `bb` (the raw bitmap): the caller owns it. On
    "scaled" / "already" the caller frees it itself; on nil it attaches it to
    the record exactly as before (the raw decode-ahead path).
  * It never puts anything unless a scaled bitmap was really produced, and
    never scales when the cache already holds the cover (`has`).
  * Every dep call is under pcall: a throwing dep gives nil + reason, never an
    error to the caller (the caller then takes the raw path, no retry loop).
  * The scaled bitmap is not freed when `put` fails or throws: put may already
    have stored it before failing (cache insert, then disk), and freeing a
    bitmap the cache holds would corrupt it. A bitmap nobody holds is
    reclaimed by its ffi finalizer.
]]

local Prescale = {}
Prescale.__index = Prescale

--- Only a numeric BookOrbit book is prescaled: "bookorbit://<digits>".
-- Folder/author tiles and anything else the widget cannot size exactly stay on
-- the old path.
function Prescale.isBookRecord(record)
    if type(record) ~= "table" then return false end
    local fp = record.filepath
    return type(fp) == "string" and fp:match("^bookorbit://%d+$") ~= nil
end

function Prescale.new(deps)
    deps = deps or {}
    local self = setmetatable({}, Prescale)
    self.d = deps
    return self
end

local function log(self, ...)
    local lg = self.d.logger
    if lg and lg.dbg then pcall(lg.dbg, lg, ...) end
end

-- Call a dep under pcall. Returns ok, r1, r2 (ok false: the dep threw or is missing).
local function call(self, name, ...)
    local fn = self.d[name]
    if type(fn) ~= "function" then return false, "missing dep" end
    local ok, a, b = pcall(fn, ...)
    if not ok then
        log(self, "prescale: dep failed", name, tostring(a))
        return false, a
    end
    return true, a, b
end

local function clock(self)
    local fn = self.d.now or os.clock
    local ok, t = pcall(fn)
    if ok and type(t) == "number" then return t end
    return nil
end

local function elapsedMs(t0, t1)
    if t0 == nil or t1 == nil then return 0 end
    local ms = (t1 - t0) * 1000
    if ms < 0 then return 0 end
    return ms
end

function Prescale:run(record, bb)
    if not Prescale.isBookRecord(record) then return nil, "not_book" end
    local fp = record.filepath

    -- 1. the exact painted size
    local ok, w, h = call(self, "dims", record)
    if not ok then return nil, "error" end
    if type(w) ~= "number" or type(h) ~= "number" or w ~= w or h ~= h or w < 1 or h < 1 then
        return nil, "no_dims"
    end

    -- 2. already cached at that size: nothing to scale, nothing to write
    local hok, have = call(self, "has", fp, w, h)
    if not hok then return nil, "error" end
    if have then
        return "already", { w = w, h = h, scale_ms = 0, put_ms = 0 }
    end

    -- 3. scale the raw bitmap (the caller still owns it afterwards)
    if bb == nil then return nil, "no_bitmap" end
    local t0 = clock(self)
    local sok, scaled = call(self, "scale", bb, w, h)
    local t1 = clock(self)
    if not sok or scaled == nil or scaled == false then return nil, "scale_failed" end

    -- 4. cache it (this is the synchronous disk write)
    local pok, stored = call(self, "put", fp, scaled)
    local t2 = clock(self)
    if not pok or stored == nil or stored == false then return nil, "put_failed" end

    return "scaled", { w = w, h = h, scale_ms = elapsedMs(t0, t1), put_ms = elapsedMs(t1, t2) }
end

return Prescale
