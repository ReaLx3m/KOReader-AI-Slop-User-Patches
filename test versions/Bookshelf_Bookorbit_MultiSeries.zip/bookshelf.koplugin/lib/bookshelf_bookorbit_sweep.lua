--[[--
Full-library sweep for Bookshelf's BookOrbit integration: pushes progress
and status/rating for every local book to BookOrbit in one manual pass.

Day-to-day sync is already covered by the per-book push-on-close /
pull-on-open hooks in main.lua and the "Sync now" action in
bookshelf_settings.lua. The sweep exists for two cases those don't reach:

  1. A book with existing local progress/rating that hasn't been reopened
     since BookOrbit was configured -- nothing ever triggered a push for
     it.
  2. Forcing a full resync after fixing a server URL / credentials
     problem, without having to reopen every affected book by hand.

Runs as ONE job submitted to the shared sync coordinator (see
bookshelf_bookorbit_sync_coordinator.lua) -- not one job per book. That
means it can't start while a per-book push/pull is already in flight, and
once it does start, nothing else can jump in front of an individual
book's request until the whole sweep finishes -- the same one-job-at-a-time
guarantee the coordinator already gives every other BookOrbit call, just
applied to N books instead of 1. The Trapper protection every other
blocking BookOrbit call in this plugin needs comes for free the same way,
via bookshelf_bookorbit_sync_job_runner.lua -- this module never touches
Trapper directly.
]]

local UIManager = require("ui/uimanager")
local logger    = require("logger")
local T         = require("ffi/util").template
local _         = require("lib/bookshelf_i18n").gettext

local BookOrbitSweep = {
    running = false,
}

-- Matches the official plugin's own toast pacing for a long sweep: redraw
-- at most this often so an e-ink screen isn't fighting a text update on
-- every single book.
local PROGRESS_THROTTLE = 2

function BookOrbitSweep.isRunning()
    return BookOrbitSweep.running == true
end

local function showInfo(text, timeout)
    local InfoMessage = require("ui/widget/infomessage")
    UIManager:show(InfoMessage:new{ text = text, timeout = timeout })
end

local function showProgress(ctx, text)
    if not ctx.interactive then return end
    if text == ctx.shown_text then return end
    if ctx.shown_at and (os.time() - ctx.shown_at) < PROGRESS_THROTTLE then return end
    ctx.shown_text = text
    ctx.shown_at = os.time()
    local Notification = require("ui/widget/notification")
    UIManager:show(Notification:new{ text = text })
end

-- The actual synchronous walk. Runs inside the coordinator job's Trapper
-- wrap (see BookOrbitSweep.run below), so it's fine for this to block for
-- a while -- exactly the same shape as Bookshelf's own whole-library
-- BIM:extractBooksInDirectory pass (main.lua's scanAllMetadata), which
-- already does one big Trapper:wrap around a loop over every book rather
-- than step-chaining through UIManager:scheduleIn.
--
-- Progress-reading + push/state-push logic itself lives in
-- BookOrbit.pushBookFromDisk (bookshelf_bookorbit.lua) -- shared with
-- retryPendingSyncs, which needs exactly the same "push whatever's on
-- disk for a book that isn't currently open" behaviour. This walk just
-- drives it over every book and tallies the results.
local function walkLibrary(BookOrbit, ctx)
    local Repo = require("lib/bookshelf_book_repository")
    local paths = Repo.getAllFilepaths() or {}

    local stats = { library_total = #paths, matched = 0, synced = 0, skipped = 0, failed = 0 }
    for i, fp in ipairs(paths) do
        local hash = BookOrbit.getBookHash(fp)
        if not hash then
            stats.skipped = stats.skipped + 1
        else
            stats.matched = stats.matched + 1
            showProgress(ctx, T(_("BookOrbit sweep: %1/%2 books…"), i, #paths))

            local ok_call, ok = pcall(BookOrbit.pushBookFromDisk, fp)
            if ok_call and ok then
                stats.synced = stats.synced + 1
            else
                stats.failed = stats.failed + 1
            end
        end
    end
    return stats
end

--- Kick off a full-library sweep. opts:
--   interactive (bool, default true) -- show progress toasts and a final
--     summary InfoMessage. Pass false for a silent background sweep.
--   priority (BookOrbit.SYNC_PRIORITY.*, default .manual) -- a sweep
--     triggered from the settings menu is a deliberate user action, same
--     as "Sync now", so it defaults to the priority that lets it jump a
--     queued (not yet started) automatic job for the same book.
-- Returns ok(bool), err(string|nil). ok=false with no network call made
-- at all for: not configured, a sweep already running, or offline with
-- "Auto-connect Wi-Fi for sync" off (see BookOrbit.withAutoWifi) -- with
-- that setting on, an offline device still proceeds, bringing Wi-Fi up
-- first instead of bailing out.
function BookOrbitSweep.run(opts)
    opts = opts or {}
    local interactive = opts.interactive ~= false

    local ok_bo, BookOrbit = pcall(require, "lib/bookshelf_bookorbit")
    if not (ok_bo and BookOrbit) then return false, "bookorbit_unavailable" end

    if not (BookOrbit.isConfigured and BookOrbit.isConfigured()) then
        if interactive then
            showInfo(_("BookOrbit isn't configured yet -- add your server first."), 3)
        end
        return false, "not_configured"
    end
    if BookOrbitSweep.running then
        if interactive then
            showInfo(_("A BookOrbit sweep is already in progress."), 2)
        end
        return false, "already_running"
    end

    local ok_net, NetworkMgr = pcall(require, "ui/network/manager")
    local online = ok_net and NetworkMgr and NetworkMgr:isOnline()
    local auto_wifi = BookOrbit.autoWifiEnabled and BookOrbit.autoWifiEnabled()
    if not online and not auto_wifi then
        if interactive then
            showInfo(_("No network connection -- can't sweep."), 3)
        end
        return false, "offline"
    end

    BookOrbitSweep.running = true
    local ctx = { interactive = interactive }

    -- withAutoWifi is a no-op wrapper (immediate callback, no-op afterDone)
    -- when already online or the setting is off -- see
    -- bookshelf_bookorbit.lua -- so this reduces to the exact previous
    -- behavior in both of those cases.
    BookOrbit.withAutoWifi(function(afterDone)
        BookOrbit.submitSyncJob{
            family   = "sweep",
            label    = "sweep all books",
            priority = opts.priority or BookOrbit.SYNC_PRIORITY.manual,
            run      = function()
                local ok, stats = pcall(walkLibrary, BookOrbit, ctx)
                BookOrbitSweep.running = false
                if not ok then
                    logger.warn("BookOrbit: sweep failed:", stats)
                    if interactive then
                        showInfo(_("BookOrbit sweep failed -- check your connection."), 3)
                    end
                    afterDone()
                    return
                end
                -- BookOrbit.saveSweepStatus/getSweepStatus (and the "Sync
                -- status" diagnostics menu) key off stats.total -- the
                -- number of books actually matched/attempted, not the raw
                -- library size before hash filtering.
                stats.total = stats.matched
                pcall(BookOrbit.saveSweepStatus, stats)
                if interactive then
                    local text
                    if stats.failed > 0 then
                        text = T(_("BookOrbit sweep: synced %1, failed %2 (of %3 matched books)."),
                            stats.synced, stats.failed, stats.matched)
                    else
                        text = T(_("BookOrbit sweep complete: synced %1 books (%2 had no BookOrbit match)."),
                            stats.synced, stats.skipped)
                    end
                    showInfo(text, 4)
                end
                afterDone()
            end,
            on_error = function(err)
                BookOrbitSweep.running = false
                logger.warn("BookOrbit: sweep job errored:", err)
                if interactive then
                    showInfo(_("BookOrbit sweep failed -- check your connection."), 3)
                end
                afterDone()
            end,
        }
    end)
    return true
end

return BookOrbitSweep
