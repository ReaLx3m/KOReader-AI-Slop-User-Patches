--[[
Tap actions for BookOrbit micro-modules.

BookOrbit's board widgets describe a tap as a small table, `{ kind = "book",
book = ..., resume = true }`, built by `BoardUI.hit(...)` and dispatched by its
catalog screen (CatalogBoard:boardRun). Bookshelf has no such screen, so this
module is the dispatcher: it maps each action kind onto what the fork already
has (the shelf widget's _openBook, the BookOrbit catalog modal, the dictionary).

Kinds handled here:
  book, book-actions, detail  open / preview a dashboard book
  books                       open one book list in the BookOrbit catalog
  shelf                       a shelf's "See all" (its list, or the series list)
  link                        a Library / Series / Authors ... tile
  shuffle                     reshuffle the Discover shelf
  highlight                   show the highlight of the day
  lookup                      dictionary lookup of the word of the day
  light                       frontlight / warmth step (in place)
  wifi, night                 toggle Wi-Fi / night mode (in place)
  frontlight, rotate          KOReader's brightness dialog / rotation
  sync                        Sync now
  noop                        nothing
Batch 6 adds dust-next / dust-remove with the Gathering dust widget.

Every handler is defensive: a tap must never throw into the host.
]]
local logger = require("logger")
local _ = require("lib/bookshelf_i18n").gettext

local Actions = {}

local function toast(text, timeout)
    local ok, InfoMessage = pcall(require, "ui/widget/infomessage")
    local UIManager = require("ui/uimanager")
    if ok and InfoMessage then
        UIManager:show(InfoMessage:new{ text = text, timeout = timeout or 3 })
    end
end

-- Open a server book. With a Bookshelf widget (bw) the shelf's own open path
-- does everything (reuses a download, fetches one, shows progress); without
-- one, resolve the file ourselves and hand it to the reader.
local function openBook(book, ctx)
    if type(book) ~= "table" or book.id == nil then return end
    local Source = require("lib/bookshelf_bookorbit_source")
    local record = Source.toRecord(book)
    local bw = ctx and ctx.bw
    if bw and type(bw._openBook) == "function" then
        bw:_openBook(record)
        return
    end
    Source.resolveOpenPath(record, function(path, err)
        if path then
            require("apps/reader/readerui"):showReader(path)
        else
            toast(_("Couldn't open this BookOrbit book."))
            logger.warn("[bookshelf] BookOrbit open failed:", err)
        end
    end)
end

-- "Details": Bookshelf's preview (loads the book into the hero) where there is
-- one, else just open it.
local function previewBook(book, ctx)
    if type(book) ~= "table" or book.id == nil then return end
    local bw = ctx and ctx.bw
    if bw and type(bw._previewBook) == "function" then
        bw:_previewBook(require("lib/bookshelf_bookorbit_source").toRecord(book))
        return
    end
    openBook(book, ctx)
end

local function showHighlight(hl)
    if type(hl) ~= "table" or not hl.text then return end
    local TextViewer = require("ui/widget/textviewer")
    local UIManager = require("ui/uimanager")
    local parts = { tostring(hl.text) }
    local from = {}
    if hl.bookTitle and hl.bookTitle ~= "" then from[#from + 1] = hl.bookTitle end
    if hl.chapterTitle and hl.chapterTitle ~= "" then from[#from + 1] = hl.chapterTitle end
    if #from > 0 then parts[#parts + 1] = "\n— " .. table.concat(from, ", ") end
    UIManager:show(TextViewer:new{ title = _("Highlight of the day"), text = table.concat(parts, "\n") })
end

local function lookupWord(word)
    if type(word) ~= "string" or word == "" then return end
    local ok_fm, FM = pcall(require, "apps/filemanager/filemanager")
    local fm = ok_fm and FM and FM.instance
    if fm and fm.dictionary and fm.dictionary.onLookupWord then
        fm.dictionary:onLookupWord(word)
        return
    end
    -- No file manager (e.g. a book is open): show the word itself.
    toast(word)
end

local function catalog()
    local ok, Catalog = pcall(require, "lib/bookshelf_bookorbit_catalog")
    return ok and Catalog or nil
end

local function openCatalog()
    local Catalog = catalog()
    if Catalog and Catalog.show then Catalog.show() end
end

-- One book list. Falls back to the catalog root if the list entry point is
-- missing (an older catalog module).
local function openBooks(params, title)
    local Catalog = catalog()
    if Catalog and Catalog.showBooks then Catalog.showBooks(params, title) else openCatalog() end
end

-- A shelf's "See all": the list BookOrbit's own board opens for each source.
local SHELF_PARAMS = {
    ["recently-added"] = { sort = "recently_added" },
    ["pick-back-up"] = { readStatus = "reading", sort = "recently_read", order = "asc" },
    ["finished"] = { readStatus = "finished", sort = "recently_read" },
    ["in-progress"] = { sort = "recently_read", readStatus = "reading" },
    ["random"] = { sort = "title" },
}

local function openShelf(action)
    local Catalog = catalog()
    if not Catalog then return end
    if action.source == "up-next-in-series" and Catalog.showSection then
        return Catalog.showSection("series", _("Series"))
    end
    local props = action.props or {}
    local params = props.params or SHELF_PARAMS[action.source] or { sort = "title" }
    local title = props.title
    if not title then
        local ok, W = pcall(require, "lib/bookorbit_board/widgets")
        title = ok and W and W.shelfTitle and W.shelfTitle(props) or _("Books")
    end
    openBooks(params, title)
end

-- Library / Series / Authors / ... tiles open the matching catalog list.
local LINKS = {
    library = function(C) C.showBooks({ sort = "title" }, _("All books")) end,
    series = function(C) C.showSection("series", _("Series")) end,
    authors = function(C) C.showSection("authors", _("Authors")) end,
    collections = function(C) C.showSection("collections", _("Collections")) end,
    scopes = function(C) C.showSection("smart-scopes", _("SmartScopes")) end,
    device = function(C) C.showOnDevice() end,
    search = function(C) C.search() end,
}

local function openLink(link)
    local Catalog = catalog()
    local fn = LINKS[link]
    if not (Catalog and fn) then return end
    -- An older catalog module without the direct entry points: root list.
    if not (Catalog.showBooks and Catalog.showSection and Catalog.search and Catalog.showOnDevice) then
        return openCatalog()
    end
    fn(Catalog)
end

-- Repaint the card after an action that finished later (Wi-Fi coming up).
-- The host's own keep_open reload covers the synchronous ones.
local function reload(ctx, env)
    if env and type(env.refresh) == "function" then return env.refresh() end
    local fn = ctx and ctx.refresh
    if type(fn) == "function" then return fn() end
    local m = ctx and ctx.menu
    if m and type(m._reload) == "function" then m:_reload() end
end

local function adjustLight(what, delta)
    local ok, Device = pcall(require, "device")
    if not (ok and Device and Device.hasFrontlight and Device:hasFrontlight()) then return end
    local powerd = Device:getPowerDevice()
    delta = tonumber(delta) or 0
    if what == "warmth" and Device:hasNaturalLight() then
        powerd:setWarmth(math.max(0, math.min(100, (powerd:frontlightWarmth() or 0) + delta)))
    else
        powerd:setIntensity(math.max(0, math.min(100, (powerd:frontlightIntensity() or 0) + delta)))
    end
end

local function toggleWifi(ctx, env)
    local NetworkMgr = require("ui/network/manager")
    local done = function() reload(ctx, env) end
    if NetworkMgr:isWifiOn() then NetworkMgr:toggleWifiOff(done) else NetworkMgr:toggleWifiOn(done) end
end

-- Gathering dust, "next": show the following unopened book for the rest of
-- today. Only the persisted skip count changes: the data is rebuilt on every
-- render, so a repaint is all that is needed (no server refetch).
local function dustNext(ctx, env)
    local BO = require("lib/bookshelf_bookorbit")
    local today = os.date("%Y-%m-%d")
    local state = BO.dustState()
    local skip = (state.day == today and tonumber(state.skip)) or 0
    BO.setDustState({ day = today, skip = skip + 1 })
    if env and env.refresh then env.refresh() else reload(ctx) end
end

-- Gathering dust, "trash": delete the unopened book's FILE through KOReader's
-- own confirmation dialog (the book stays in the library). Needs the file
-- manager, which is not there while a book is open.
local function dustRemove(book, ctx, env)
    if type(book) ~= "table" or book.id == nil then return end
    local Data = require("lib/bookshelf_bo_data")
    local path = (require("lib/bookshelf_bookorbit_source").downloadedMap() or {})[tostring(book.id)]
    local lfs = require("libs/libkoreader-lfs")
    if type(path) ~= "string" or lfs.attributes(path, "mode") ~= "file" then
        Data.fileRemoved(path)
        toast(_("This book is no longer on the device."))
        if env and env.refresh then env.refresh() else reload(ctx) end
        return
    end
    local ok, FileManager = pcall(require, "apps/filemanager/filemanager")
    local fm = ok and FileManager and FileManager.instance
    if not (fm and fm.showDeleteFileDialog) then
        toast(_("Open the file browser to remove this book."))
        return
    end
    fm:showDeleteFileDialog(path, function()
        Data.fileRemoved(path)
        if env and env.refresh then env.refresh() else reload(ctx) end
    end)
end

local function broadcast(name)
    local UIManager = require("ui/uimanager")
    local Event = require("ui/event")
    UIManager:broadcastEvent(Event:new(name))
end

-- Sync now. With a book open that is the existing push of its progress. From
-- the home screen there is no open book, so push whatever the outbox is still
-- holding and note the time if the server answered. (The BookOrbit plugin's
-- full-library sweep has no counterpart in this fork.)
local function syncNow(ctx, env)
    local BO = require("lib/bookshelf_bookorbit")
    if not BO.isConfigured() then
        return toast(_("Set up your BookOrbit server first (Bookshelf menu → BookOrbit → Connect)."))
    end
    local ok_ui, ReaderUI = pcall(require, "apps/reader/readerui")
    local ui = ok_ui and ReaderUI and ReaderUI.instance
    if ui and ui.document and ui.document.file then
        BO.syncNow()
        return
    end
    toast(_("Syncing…"), 1)
    BO.withAutoWifi(function(afterDone)
        BO.submitSyncJob{
            family = "bo_board:sync",
            label = "sync now (micro-module)",
            priority = BO.SYNC_PRIORITY.manual,
            run = function()
                pcall(BO.retryPendingSyncs)
                local body = BO.catalogRoot()
                if body then
                    BO.recordSync("sync")
                    pcall(function() require("lib/bookshelf_bo_data").invalidate() end)
                    toast(_("Synced."))
                else
                    toast(_("Sync failed -- check your connection."))
                end
                reload(ctx, env)
                afterDone()
            end,
        }
    end)
end

--- Actions.run(action, ctx, env) -- run one BookOrbit action table.
--- ctx: the host's on_tap ctx (bw, menu, refresh...). env: { props = the
--- widget's props, refresh = fn } for actions that act on the widget's data.
function Actions.run(action, ctx, env)
    if type(action) ~= "table" or not action.kind then return end
    env = env or {}
    local kind = action.kind
    local ok, err = pcall(function()
        if kind == "noop" then return end
        if kind == "book" then
            if action.resume == false then previewBook(action.book, ctx) else openBook(action.book, ctx) end
        elseif kind == "book-actions" or kind == "detail" then
            -- Shelf covers carry only book_id; the full book is in the shelf list.
            local book = action.book
            if not book and action.book_id then
                for _i, b in ipairs(action.list and action.list.books or {}) do
                    if b.id == action.book_id then book = b break end
                end
                book = book or { id = action.book_id }
            end
            previewBook(book, ctx)
        elseif kind == "books" then
            openBooks(action.params, action.title)
        elseif kind == "shelf" then
            openShelf(action)
        elseif kind == "link" then
            openLink(action.link)
        elseif kind == "light" then
            adjustLight(action.what, action.delta)
        elseif kind == "wifi" then
            toggleWifi(ctx, env)
        elseif kind == "night" then
            broadcast("ToggleNightMode")
        elseif kind == "frontlight" then
            broadcast("ShowFlDialog")
        elseif kind == "rotate" then
            broadcast("IterateRotation")
        elseif kind == "sync" then
            syncNow(ctx, env)
        elseif kind == "shuffle" then
            -- A shelf widget reshuffles its own shelf; the Continue-reading card
            -- draws the dashboard's Discover list, so that is refreshed whole.
            local Data = require("lib/bookshelf_bo_data")
            if env.props and env.props.source then Data.invalidateShelf(env.props) else Data.invalidate() end
            if env.refresh then env.refresh() else reload(ctx) end
        elseif kind == "dust-next" then
            dustNext(ctx, env)
        elseif kind == "dust-remove" then
            dustRemove(action.book, ctx, env)
        elseif kind == "highlight" then
            showHighlight(action.highlight)
        elseif kind == "lookup" then
            lookupWord(action.word)
        else
            logger.dbg("[bookshelf] BookOrbit action not handled:", kind)
        end
    end)
    if not ok then logger.warn("[bookshelf] BookOrbit action", kind, "failed:", err) end
end

--- The action a whole-card tap performs (BookOrbit's boardItemAction). `d` is
--- the data table the card was drawn from. nil = the card is not tappable.
function Actions.defaultFor(widget_type, d, props)
    d = d or {}
    local lead = d.continue_reading and d.continue_reading[1]
    local list = { label = _("Continue reading"), books = d.continue_reading }
    if widget_type == "hero" or widget_type == "forecast" then
        if lead then return { kind = "book", book = lead, resume = true, list = list } end
        return { kind = "books", params = { sort = "title" }, title = _("All books") }
    elseif widget_type == "also" or widget_type == "goalpace" then
        return { kind = "books", params = { sort = "recently_read", readStatus = "reading" }, title = _("In progress") }
    elseif widget_type == "highlight" and d.highlight then
        return { kind = "highlight", highlight = d.highlight }
    elseif widget_type == "yearago" and d.year_ago and d.year_ago.book then
        return { kind = "detail", book_id = d.year_ago.book.id, book = d.year_ago.book }
    elseif widget_type == "shelf" and props and props.source == "finished" then
        return { kind = "books", params = { readStatus = "finished", sort = "recently_read" }, title = _("Finished this year") }
    elseif widget_type == "shelf" and props then
        -- Want to read has no list of its own unless a selector narrowed it.
        if props.source == "want-to-read" and not props.params then return nil end
        return { kind = "shelf", source = props.source, props = props }
    elseif widget_type == "link" and props then
        return { kind = "link", link = props.link }
    elseif widget_type == "sync" then
        return { kind = (d.online and "sync" or "wifi") }
    elseif widget_type == "dust" and d.dust and d.dust.book then
        return { kind = "detail", book_id = d.dust.book.id, book = d.dust.book }
    elseif widget_type == "word" and d.word then
        return { kind = "lookup", word = d.word.word }
    end
    return nil
end

return Actions
