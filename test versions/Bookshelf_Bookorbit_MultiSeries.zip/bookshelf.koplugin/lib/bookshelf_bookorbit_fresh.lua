--[[--
Section freshness for BookOrbit chips ("Want to read", "Continue reading").

Goal (see HANDOFF_section_freshness): refresh those chips only when the server
has something new. This file holds the logic. It has NO KOReader dependency and
no network access: everything it needs is passed in, so it can be tested
off-device (tools/bo_tests/test_bo_fresh.lua).

Pure helpers (Batch 1):
  Fresh.signature(records, k)          content signature of the first k records
  Fresh.sectionToRecords(body, toRec)  server section response -> shelf records
  Fresh.sectionLooksTruncated(sec, n)  does the section hint at more books?
  Fresh.mergeOrder(items, walked)      section order first, rest in walk order

Controller (Batch 2): `Fresh.new(deps)` -> object with :check, :checkWhenOnline,
:cancel. See the doc comment above Fresh.new. NOT wired into the UI yet (Batch 3).
]]

local Fresh = {}

-- Separators that cannot occur in a BookOrbit id / status / timestamp, so two
-- different record lists can never produce the same joined string.
local FIELD_SEP  = "\31"   -- ASCII unit separator
local RECORD_SEP = "\30"   -- ASCII record separator

local DEFAULT_SIGNATURE_RECORDS = 24

--- Progress rounded to the nearest 0.5 percent, as text. Rounding keeps tiny
-- float noise (0.4999 vs 0.5) from looking like a change; a real change of
-- half a percent or more still does. `pct` is the 0..1 `book_pct` that
-- toRecord produces.
local function roundedProgress(pct)
    local p = tonumber(pct) or 0
    local halves = math.floor(p * 100 * 2 + 0.5)   -- units of 0.5 %
    return tostring(halves)
end

--- Fresh.signature(records, k) -> string
-- Content signature over the first `k` records (default 24), in the order
-- given. Order-sensitive ON PURPOSE: a re-ordered shelf is a change. Uses only
-- stable fields: remote_id, bookorbit_read_status, updated_at, rounded
-- progress. Never nil: an empty/nil list gives "".
function Fresh.signature(records, k)
    if type(records) ~= "table" then return "" end
    local limit = tonumber(k) or DEFAULT_SIGNATURE_RECORDS
    local parts = {}
    for i = 1, math.min(#records, limit) do
        local r = records[i]
        if type(r) == "table" then
            parts[#parts + 1] = table.concat({
                tostring(r.remote_id or ""),
                tostring(r.bookorbit_read_status or ""),
                tostring(r.updated_at or ""),
                roundedProgress(r.book_pct),
            }, FIELD_SEP)
        else
            parts[#parts + 1] = ""
        end
    end
    return table.concat(parts, RECORD_SEP)
end

local function sortedKeys(t)
    local keys = {}
    if type(t) == "table" then
        for key in pairs(t) do keys[#keys + 1] = tostring(key) end
    end
    table.sort(keys)
    return keys
end

--- Fresh.sectionToRecords(body, toRecord) -> records, meta
-- `body` is the response of GET .../dashboard/sections/<type>
-- ({ section = { books = {...} } }). Each raw book goes through `toRecord`
-- (BOSource.toRecord) in SERVER ORDER (no sort here, decision U1).
-- A book with no `readStatus` gets "want_to_read": it is in this section by
-- definition, and without it the hero's "Want to Read" pill would show
-- unpressed. The caller's table is not modified (shallow copy).
-- meta: { count = <books>, keys = {sorted keys of body.section},
--         section = <the section table or nil> }
-- A missing/invalid body gives an empty list and count 0.
function Fresh.sectionToRecords(body, toRecord)
    local section = type(body) == "table" and type(body.section) == "table"
        and body.section or nil
    local books = section and type(section.books) == "table" and section.books or {}
    local records = {}
    for _, b in ipairs(books) do
        if type(b) == "table" and b.id ~= nil then
            local raw = b
            if raw.readStatus == nil or raw.readStatus == "" then
                raw = {}
                for key, value in pairs(b) do raw[key] = value end
                raw.readStatus = "want_to_read"
            end
            records[#records + 1] = toRecord(raw)
        end
    end
    return records, {
        count   = #records,
        keys    = sortedKeys(section),
        section = section,
    }
end

-- A paging flag counts as "more to come" for true, a positive number or a
-- non-empty string (a next-page token); false/nil/0/"" mean no.
local function flagIsSet(v)
    if v == true then return true end
    if type(v) == "number" then return v > 0 end
    if type(v) == "string" then return v ~= "" end
    return false
end

--- Fresh.sectionLooksTruncated(section, n) -> bool
-- `n` is how many books the section returned. True when the section carries a
-- total (`total`, `totalCount`, `count`) larger than `n`, or a paging flag
-- (`hasNext`, `hasMore`, `nextPage`) that is set. An unknown shape is
-- "not truncated" (the caller logs the keys so the shape can be learned).
function Fresh.sectionLooksTruncated(section, n)
    if type(section) ~= "table" then return false end
    local have = tonumber(n) or 0
    for _, key in ipairs({ "total", "totalCount", "count" }) do
        local t = tonumber(section[key])
        if t and t > have then return true end
    end
    for _, key in ipairs({ "hasNext", "hasMore", "nextPage" }) do
        if flagIsSet(section[key]) then return true end
    end
    return false
end

--- Fresh.mergeOrder(items, walked) -> records
-- Hybrid list (decision D8): books present in the section first, in section
-- order, then every remaining walked book in walk order.
--   items  : the section's books in server order, as ids or as records
--            (records carry `remote_id`)
--   walked : records from the catalog walk (the full list)
-- For a section book that is also in `walked`, the walked record is used (it
-- comes from the full catalog shape); if it is not in `walked` and `items`
-- gave a record, that record is kept; an id with no record is skipped.
-- No duplicates.
function Fresh.mergeOrder(items, walked)
    local by_id = {}
    for _, r in ipairs(walked or {}) do
        if type(r) == "table" and r.remote_id ~= nil then
            local id = tostring(r.remote_id)
            if by_id[id] == nil then by_id[id] = r end
        end
    end
    local out, seen = {}, {}
    for _, item in ipairs(items or {}) do
        local id, rec
        if type(item) == "table" then
            id, rec = item.remote_id, item
        else
            id = item
        end
        if id ~= nil then
            local sid = tostring(id)
            if not seen[sid] then
                local use = by_id[sid] or rec
                if use then
                    seen[sid] = true
                    out[#out + 1] = use
                end
            end
        end
    end
    for _, r in ipairs(walked or {}) do
        if type(r) == "table" and r.remote_id ~= nil then
            local sid = tostring(r.remote_id)
            if not seen[sid] then
                seen[sid] = true
                out[#out + 1] = r
            end
        end
    end
    return out
end

-- ---------------------------------------------------------------------
-- Which chips take part (Batch 5, decisions U6 / D11 / D14)
-- ---------------------------------------------------------------------

-- Query tokens (the part of a chip's source id before the first colon) whose
-- chip is a FLAT book list read through the plain catalog page cache. They all
-- share the "catalog" kind: probe the first page of the chip's own query,
-- compare signatures, drop the page cache, redraw. Continue reading and Want
-- to read keep their own kinds (Want to read stores the probed list instead).
-- Deliberately absent: discover (random), similar (depends on one book),
-- search (a one-off query).
local CATALOG_QUERIES = {
    recent = true, all = true,
    libraries = true, collections = true, ["smart-scopes"] = true,
    authors = true, series = true,
}

--- Fresh.kindFor(query, is_group_root) -> "continue" | "want_to_read" |
--- "catalog" | nil   (nil = this chip is never checked)
-- Pure, so the id classification is unit tested even though the real source
-- module cannot be loaded under the test stubs. `is_group_root` is the
-- answer of BOSource.isGroupRoot(id): the folder-tile views (bare "authors:"
-- / "series:" and the "*-groups" ids) show tiles, not books, and use another
-- cache, so they never qualify (D14). A bare "libraries:" / "collections:" /
-- "smart-scopes:" id is NOT a group root: it is the flat "All <title>" list
-- (queryForId gives it no filter, i.e. every book by title), so it qualifies.
-- A single author / series ("authors:<name>", "series:<name or id>") has a
-- non-empty rest and is not a group root, so it qualifies too.
function Fresh.kindFor(query, is_group_root)
    if query == "continue" or query == "want_to_read" then return query end
    if is_group_root then return nil end
    if type(query) == "string" and CATALOG_QUERIES[query] then return "catalog" end
    return nil
end

-- ---------------------------------------------------------------------
-- Controller
-- ---------------------------------------------------------------------

-- Decision D3: minimum gap between checks of the same chip. A gap, not a
-- timer: nothing runs by itself; a check inside the gap is just skipped.
Fresh.MIN_INTERVAL = 60
-- Decision D4: after a failed check wait 120 s, 240 s, 360 s ... capped at 900 s
-- (same numbers as bookshelf_bo_data.lua).
Fresh.BACKOFF_MIN = 120
Fresh.BACKOFF_MAX = 900

local Controller = {}
Controller.__index = Controller

--- Fresh.new(deps) -> controller
-- Every dependency is injected so the logic runs off-device. `deps`:
--   now()                      -> seconds (monotonic enough; os.time is fine)
--   enabled()                  -> bool   (setting on AND BookOrbit configured)
--   connected()                -> bool   (the radio is really online; fail closed)
--   wait_for_network(reason, on_ready, on_fail)
--                              waits (Auto Wi-Fi lease) then calls EXACTLY ONE of
--                              on_ready(afterDone) / on_fail(err), or neither if
--                              it gives up silently. afterDone() releases the
--                              lease and MUST be called once on every path.
--   current_chip()             -> BookOrbit chip id on screen, or nil when the
--                                 shelf is not showing / a book is open / drilled in
--   kind_of(id)                -> "continue" | "want_to_read" | "catalog" | nil (ignored)
--                                 (see Fresh.kindFor; every kind except want_to_read is an
--                                 "invalidate" kind in :check)
--   probe(kind, id)            -> records | nil, err   (blocking network call;
--                                 only ever called inside a sync job)
--   get_sig(id) / set_sig(id, sig)   persisted baseline signature
--   store_records(kind, id, records) Want to read: write the probed list to cache
--   invalidate(kind, id)             Continue: drop the chip's cached pages
--   submit(job)                sync coordinator (BookOrbit.submitSyncJob); job =
--                              { family, label, run, cleanup, on_error }
--   on_changed(kind, id)       redraw hook (caller decides whether to repaint)
--   logger                     optional { info, warn, dbg }
function Fresh.new(deps)
    assert(type(deps) == "table", "Fresh.new needs deps")
    local self = setmetatable({
        deps         = deps,
        last_check   = {},   -- id -> time of the last completed (ok) check
        backoff_until = {},  -- id -> time before which a non-forced check is skipped
        fail_count   = {},   -- id -> consecutive failures
        inflight     = {},   -- id -> job state table while a check is queued/running
        waiting      = false,-- a checkWhenOnline is waiting for Wi-Fi
        generation   = 0,    -- bumped by :cancel()
    }, Controller)
    return self
end

local function log(self, level, ...)
    local l = self.deps.logger
    if l and l[level] then pcall(l[level], "Bookshelf BookOrbit fresh:", ...) end
end

-- Calls a dependency that must never be able to break the shelf. Returns
-- ok, a, b. A throw is logged and reported as not ok.
local function safe(self, name, ...)
    local fn = self.deps[name]
    if type(fn) ~= "function" then return false end
    local ok, a, b = pcall(fn, ...)
    if not ok then log(self, "warn", name, "threw:", a); return false end
    return true, a, b
end

--- :check(kind, id, opts) -> status string
-- The immediate check (tap, swipe; also what checkWhenOnline runs once Wi-Fi
-- is ready). Never turns Wi-Fi on, never prompts, never waits.
--   opts.force    bypass the 60 s gap and the failure backoff (book closed,
--                 manual swipe: the data certainly changed)
--   opts.reason   for the log
--   opts.adopt    record the probed signature as the new baseline and do
--                 nothing else (no store, no invalidate, no redraw). For the
--                 manual swipe refresh, which has just reloaded the chip
--                 itself: a normal check would see the news a second time and
--                 redraw again.
--   opts.release  function called EXACTLY ONCE when this check is finished with
--                 the caller's resources (the Wi-Fi lease), on every path:
--                 skipped, ran, threw, or its job dropped by the coordinator
-- Status (for tests/logs): "submitted", "disabled", "ignored", "inflight",
-- "offline", "interval", "backoff", "submit_failed".
-- All skips are silent and none of them counts as a failure (no backoff).
function Controller:check(kind, id, opts)
    opts = opts or {}
    local deps = self.deps

    -- release() is once-only no matter how many paths reach it.
    local released = false
    local function release()
        if released then return end
        released = true
        if opts.release then pcall(opts.release) end
    end

    local function skip(status)
        release()
        return status
    end

    local ok_en, enabled = safe(self, "enabled")
    if not (ok_en and enabled) then return skip("disabled") end

    -- kind_of is the authority on what a chip is; anything that is not
    -- Continue reading / Want to read is ignored.
    if id == nil then return skip("ignored") end
    local ok_k, actual = safe(self, "kind_of", id)
    if not (ok_k and actual) or (kind ~= nil and kind ~= actual) then return skip("ignored") end
    kind = actual

    if self.inflight[id] then return skip("inflight") end

    local ok_c, connected = safe(self, "connected")
    if not (ok_c and connected) then return skip("offline") end

    local now = deps.now()
    if not opts.force then
        local last = self.last_check[id]
        if last and now - last < Fresh.MIN_INTERVAL then return skip("interval") end
        local until_t = self.backoff_until[id]
        if until_t and now < until_t then return skip("backoff") end
    end

    local state = { generation = self.generation, done = false }
    self.inflight[id] = state

    -- Idempotent: runs after the job (finished or threw) and also if the
    -- coordinator drops the job without running it.
    local function cleanup()
        if self.inflight[id] == state then self.inflight[id] = nil end
        release()
    end

    local function fail(err)
        local n = (self.fail_count[id] or 0) + 1
        self.fail_count[id] = n
        self.backoff_until[id] = deps.now() + math.min(Fresh.BACKOFF_MAX, Fresh.BACKOFF_MIN * n)
        log(self, "info", "check failed", kind, id, tostring(err), "backoff", n)
    end

    local function runInner()
        local ok_p, records, err = pcall(deps.probe, kind, id)
        if not ok_p then return fail(records) end
        if type(records) ~= "table" then return fail(err or "no result") end

        local new_sig = Fresh.signature(records)
        local ok_g, old_sig = safe(self, "get_sig", id)
        if not ok_g then old_sig = nil end
        self.fail_count[id] = nil
        self.backoff_until[id] = nil
        self.last_check[id] = deps.now()

        if opts.adopt then
            safe(self, "set_sig", id, new_sig)
            log(self, "dbg", "baseline adopted", kind, id)
            return
        end

        if old_sig ~= nil and old_sig == new_sig then
            log(self, "dbg", "unchanged", kind, id)
            return
        end

        -- Changed, or no baseline yet (D5: counts as changed ONCE, then settles).
        if kind == "want_to_read" then
            safe(self, "store_records", kind, id, records)
        else
            safe(self, "invalidate", kind, id)
        end
        safe(self, "set_sig", id, new_sig)
        log(self, "info", old_sig == nil and "no baseline" or "changed", kind, id, #records)
        -- A cancel() while the job was queued/running keeps the data fresh for
        -- the next visit but must not repaint the screen.
        if state.generation == self.generation then
            safe(self, "on_changed", kind, id)
        end
    end

    -- Anything unexpected inside a check is a failed check (backoff), never a
    -- raised error: the sync runner would only log it.
    local function run()
        local ok_r, rerr = pcall(runInner)
        if not ok_r then fail(rerr) end
    end

    local job = {
        family   = "bo_fresh:" .. tostring(id),
        label    = "freshness check " .. tostring(kind),
        run      = run,
        cleanup  = cleanup,
        on_error = function(err) fail(err); cleanup() end,
    }
    local ok_s, res = pcall(deps.submit, job)
    if not ok_s then
        log(self, "warn", "submit threw:", res)
        cleanup()
        return "submit_failed"
    end
    -- "kept": the coordinator discarded the job (and already ran its cleanup).
    -- cleanup is idempotent, so calling it again is harmless and covers a
    -- coordinator that does not.
    if res == "kept" then cleanup() end
    return "submitted"
end

--- :checkWhenOnline(opts) -> status ("waiting" | "ignored_busy" | "disabled")
-- For wake-on-home and book-closed. Waits for Wi-Fi through the injected
-- `wait_for_network` (Auto Wi-Fi lease; with Auto Wi-Fi off it does not wait),
-- then re-resolves the chip on screen (D10) and runs :check on it.
--   opts.force   bypass the gap / backoff (book closed)
--   opts.reason  "wake" | "book_closed" ... (also the Wi-Fi lease reason)
-- At most one wait pending at a time: a second call while waiting is ignored.
-- The lease is released exactly once on every path (ready, fail, skipped,
-- thrown, dropped job). A wait that ends in on_fail (timeout, manual off) is
-- silent and is not a failure.
function Controller:checkWhenOnline(opts)
    opts = opts or {}
    local ok_en, enabled = safe(self, "enabled")
    if not (ok_en and enabled) then return "disabled" end
    if self.waiting then return "ignored_busy" end

    local token = self.generation
    self.waiting = true
    local answered = false

    local function stillMine()
        return self.generation == token
    end

    local function on_ready(afterDone)
        local released = false
        local function release()
            if released then return end
            released = true
            if type(afterDone) == "function" then pcall(afterDone) end
        end
        if answered then return release() end   -- a second answer: just release
        answered = true
        if stillMine() then self.waiting = false end
        if not stillMine() then return release() end   -- cancelled while waiting

        local ok = pcall(function()
            -- Auto Wi-Fi off: the gate does not wait, so the radio may still be
            -- down. We never connect on our own: just skip.
            local ok_c, connected = safe(self, "connected")
            if not (ok_c and connected) then return release() end
            -- D10: decide the chip NOW, not when the trigger fired.
            local ok_cc, chip = safe(self, "current_chip")
            if not (ok_cc and chip) then return release() end
            local ok_k, kind = safe(self, "kind_of", chip)
            if not (ok_k and kind) then return release() end
            -- :check calls release() exactly once on every path from here
            -- (immediately when skipped, from the job's cleanup otherwise).
            self:check(kind, chip, { force = opts.force, reason = opts.reason, release = release })
        end)
        if not ok then release() end
    end

    local function on_fail(err)
        if answered then return end
        answered = true
        if stillMine() then self.waiting = false end
        log(self, "dbg", "wait for network ended:", tostring(err))
    end

    local ok_w, werr = pcall(self.deps.wait_for_network, opts.reason or "section_refresh", on_ready, on_fail)
    if not ok_w then
        log(self, "warn", "wait_for_network threw:", werr)
        if not answered and stillMine() then self.waiting = false end
        answered = true
    end
    return "waiting"
end

--- :cancel() -- forget a pending wait; an in-flight job still finishes (its
-- result is stored for the next visit) but will not redraw. A wait that is
-- still pending in the Wi-Fi layer is not aborted there (the lease times out
-- by itself); if it later answers, the lease is released and nothing runs.
function Controller:cancel()
    self.generation = self.generation + 1
    self.waiting = false
end

return Fresh
