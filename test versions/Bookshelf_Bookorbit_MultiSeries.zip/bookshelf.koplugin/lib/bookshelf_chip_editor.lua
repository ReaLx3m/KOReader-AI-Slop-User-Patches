-- bookshelf_chip_editor.lua
-- Per-tab editor modal.
--   editTab(tab_id, opts)  -- open the editor for one tab directly.
--
-- Every change applies as it is made: it is saved (in memory, flushed when
-- the editor closes) and the shelf behind rebuilds, once per run of taps.
-- The editor closes with Close; there is no Save and no Cancel.
-- opts.on_change(info) is that rebuild (info.source_changed when the source
-- moved), and also runs at once after each Move-left / Move-right tap.
-- opts.bw is the BookshelfWidget instance; when present the dialog anchors
-- just below the chip strip so the strip stays visible.

local ButtonDialog   = require("ui/widget/buttondialog")
local ConfirmBox     = require("ui/widget/confirmbox")
local UIManager      = require("ui/uimanager")
local Geom           = require("ui/geometry")
local Size           = require("ui/size")
local Screen         = require("device").screen
local Space          = require("lib/bookshelf_space")

local TabModel = require("lib/bookshelf_tab_model")
local ViewMode = require("lib/bookshelf_view_mode")
local Filter   = require("lib/bookshelf_filter")
local logger   = require("logger")
local _        = require("lib/bookshelf_i18n").gettext
local T        = require("ffi/util").template

local Editor = {}

-- _highAnchor(get_dialog) -> an `anchor` function for ButtonDialog.
--
-- Puts the dialog HIGH on the screen, over the hero, so the shelf rows it is
-- about stay visible underneath. The shelf-style picker had this to itself;
-- every chip-editor picker now shares it, because the reason is the same
-- everywhere: a setting about the shelf is chosen by looking at the shelf
-- (maintainer request). get_dialog is a getter rather than the dialog because
-- the dialog does not exist yet when this is passed to its own constructor.
--
-- prefers_pop_down (the second return) is required: MovableContainer places
-- content ABOVE its anchor by default, which for a near-top anchor means
-- clamping back to y=0 and covering the status bar too.
--
-- EVERY FIELD A NUMBER, deliberately. MovableContainer fills in a missing
-- x/y/w/h -- centring horizontally when x is nil -- only since KOReader
-- v2026.07; v2026.03 and earlier read them raw, so a nil x arrives at
-- `if left < 0` in ensureAnchor and takes the whole app down. Release 4.2.0
-- did exactly that on opening the style picker. The centring the older
-- versions will not do for us is done here instead, which is also the same
-- placement on both.
local function _highAnchor(get_dialog)
    return function()
        local d  = get_dialog()
        -- The width comes off the LAID-OUT dialog: MovableContainer sets its
        -- dimen from the content size on the line before it evaluates the
        -- anchor, so by now it is the real rendered width. ButtonDialog's own
        -- `width` is the fallback -- that is the width it ASKED for, which a
        -- scrollable dialog can exceed.
        local mv = d and d.movable
        local dw = (mv and mv.dimen and mv.dimen.w) or (d and d.width) or 0
        return {
            -- Not clamped to 0: ensureAnchor already does `if left < 0 then
            -- left = 0`, and clamping here first would instead trip its
            -- `left + content_w > screen_w` branch, hanging a too-wide dialog
            -- off the LEFT edge (title first) rather than the right.
            x = math.floor((Screen:getWidth() - dw) / 2),
            y = Space.px(96),
            -- w matches the dialog so a mirrored (RTL) layout, which takes the
            -- other branch (left = x + w - content_w), lands on that same
            -- centred x instead of a dialog's width to the left of it. h stays
            -- 0: with prefers_pop_down the top edge is y + h, and y is already
            -- where we want the top.
            w = dw,
            h = 0,
        }, true
    end
end

-- _helpParagraph(text) -> a TextBoxWidget for ButtonDialog's _added_widgets.
--
-- ButtonDialog appends _added_widgets to its title group, each at its own
-- face, so a bold `title` heading and this body-size paragraph read at two
-- distinct sizes. Width mirrors ButtonDialog's internal maths (default
-- width_factor 0.9, then strip the border/button/title insets) so the help
-- aligns with the heading instead of widening the dialog.
--
-- UI modules are lazy-required: this runs only on-device, and a top-level
-- require would break the headless test.
local function _helpParagraph(text)
    local Font_          = require("ui/font")
    local TextBoxWidget_ = require("ui/widget/textboxwidget")
    local Size_          = require("ui/size")
    local Screen_        = require("device").screen
    local dlg_w  = math.floor(math.min(Screen_:getWidth(), Screen_:getHeight()) * 0.9)
    local bt_w   = dlg_w - 2 * Size_.border.window - 2 * Size_.padding.button
    local help_w = bt_w - 2 * (Size_.padding.large + Size_.margin.title)
    local w = TextBoxWidget_:new{
        text  = text,
        face  = Font_:getFace("x_smallinfofont"),
        width = help_w,
    }
    w.not_focusable = true  -- non-interactive; keep it out of dpad nav
    return w
end

-- The chip's view-mode pin, as words. lib/bookshelf_view_mode.lua deliberately
-- holds no strings and no gettext -- it is a pure resolver, testable headless --
-- so the wording lives here, where every other chip-editor label already does.
--
-- nil when the chip follows the global settings, NOT "Default": the callers
-- want to fall through to naming the tile style instead, and a caller that
-- genuinely wants the word supplies it.
function Editor._chipModeLabel(value)
    local v = ViewMode.chipOverride(value)
    if v == ViewMode.LIST   then return _("List")   end
    if v == ViewMode.COVERS then return _("Covers") end
    if v == ViewMode.AUTO   then return _("Auto")   end
    if v == ViewMode.SPINES then return _("Spines") end
    return nil
end

-- Per-key default sort direction. Picking one of these auto-sets the
-- matching reverse flag; the up-arrow indicator only renders when the
-- saved direction differs from this default. So "Book count (most
-- first)" / "Most recently added (newest first)" show no arrow at
-- their natural orientation; flipping them to ascending adds the ↑.
-- Same for text keys -- "Title (A-Z)" shows no arrow at default,
-- shows ↑ if the user reverses to Z-A.
local DEFAULT_REVERSE = {
    book_count   = true,
    last_opened  = true,
    date_added   = true,
    added_or_opened = true,
    -- "Progress" sort defaults to highest-progress-first: a user picking
    -- "Sort by progress" usually wants to see books they're furthest
    -- through (or finished) at the top. Ascending (unread first) is the
    -- niche choice -- still reachable via the picker's toggle.
    percent_read = true,
    -- Rating sort defaults to highest-first, matching the Ratings stack
    -- default and the usual "show my best-rated books at the top" intent.
    rating       = true,
    -- Everything else defaults to false (ascending). The table only
    -- needs entries for keys whose default is true.
}
local function _isDefaultDirection(key, reverse)
    return (DEFAULT_REVERSE[key] == true) == (reverse == true)
end

-- Per-source-kind default sort priority. Applied when the user picks
-- a source in the editor, overwriting the previous sort selection.
-- The user can re-pick sort levels afterwards if they want something
-- different; the defaults are tuned for the "if you didn't think about
-- it, this is probably what you wanted" case.
--
-- Each entry is a sort_priority list -- a sequence of { key, reverse }
-- levels. For group sources (series/authors/genres/tags/formats) the
-- level 1 entry orders the group cards and levels 2+ apply within a
-- drilled-in group (see BookshelfWidget:_applyWithinGroupSort).
-- Forward-declared so `_applySourceDefaults` (defined below) can read
-- it for the auto-rename-new-chip QoL. The actual table populates a
-- few dozen lines further down; this reservation just makes the local
-- visible to the function's upvalue capture.
local SOURCE_LABEL

local SOURCE_SORT_DEFAULTS = {
    -- Book sources (return books, not groups)
    all           = { { key = "filename",        reverse = false } },
    library       = { { key = "author_surname",  reverse = false },
                      { key = "series_name",     reverse = false },
                      { key = "series_index",    reverse = false } },
    recent        = { { key = "last_opened",     reverse = true  } },
    latest        = { { key = "date_added",      reverse = true  } },
    favorites     = { { key = "last_opened",     reverse = true  } },
    folder        = { { key = "filename",        reverse = false } },
    -- Flattened folder (#76): a recursive book list with no folder cards,
    -- so it sorts like "library" (Home flattened) rather than by filename.
    folder_flat   = { { key = "author_surname",  reverse = false },
                      { key = "series_name",     reverse = false },
                      { key = "series_index",    reverse = false } },
    -- A collection is the one book source with an order of its own: KOReader
    -- stores a per-item `order` and files the collection by it. Level two
    -- carries the collections it stores no order for -- only a manually
    -- collated one persists it -- where every book ties on level one and the
    -- shelf comes out as it always did (issue 441).
    collection    = { { key = "collection_order", reverse = false },
                      { key = "last_opened",      reverse = true  } },
    -- NOT collection_order, although a pinned tag chip is also kind
    -- "collection": the id is a tag name, there is rarely a KOReader
    -- collection behind it, and a tag has no curated order to preserve.
    tag           = { { key = "last_opened",     reverse = true  } },
    genre         = { { key = "author_surname",  reverse = false },
                      { key = "series_name",     reverse = false },
                      { key = "series_index",    reverse = false } },
    author        = { { key = "series_name",     reverse = false },
                      { key = "series_index",    reverse = false },
                      { key = "title",           reverse = false } },
    single_series = { { key = "series_index",    reverse = false } },
    status        = { { key = "last_opened",     reverse = true  } },
    format        = { { key = "last_opened",     reverse = true  } },
    -- Group sources (level 1 -> group cards, levels 2+ -> within group)
    series        = { { key = "last_opened",     reverse = true  },
                      { key = "series_index",    reverse = false } },
    authors       = { { key = "author_surname",  reverse = false },
                      { key = "series_name",     reverse = false },
                      { key = "series_index",    reverse = false } },
    genres        = { { key = "book_count",      reverse = true  },
                      { key = "series_name",     reverse = false },
                      { key = "series_index",    reverse = false } },
    tags          = { { key = "book_count",      reverse = true  },
                      { key = "title",           reverse = false } },
    formats       = { { key = "book_count",      reverse = true  },
                      { key = "title",           reverse = false } },
    languages     = { { key = "book_count",      reverse = true  },
                      { key = "series_name",     reverse = false },
                      { key = "series_index",    reverse = false } },
    -- Ratings group: highest rating first, books within each star
    -- bucket sorted series_name -> series_index -> title.
    ratings       = { { key = "rating",           reverse = true  },
                      { key = "series_name",     reverse = false },
                      { key = "series_index",    reverse = false },
                      { key = "title",           reverse = false } },
    -- Specific rating: a book list filtered to one star count.
    rating        = { { key = "series_name",     reverse = false },
                      { key = "series_index",    reverse = false },
                      { key = "title",           reverse = false } },
    -- Specific language: a book list filtered to one language.
    language      = { { key = "author_surname",  reverse = false },
                      { key = "series_name",     reverse = false },
                      { key = "series_index",    reverse = false } },
    -- OPDS catalogue: the feed's own order is authoritative (it may encode
    -- the remote library's curation -- "recently added", a shelf order,
    -- etc.) and this plugin has no independent metadata to re-sort by
    -- until books are actually fetched. Empty list means "no sort levels",
    -- not "fall through to an engine default" -- see _applySourceDefaults.
    opds          = {},
    -- Shelf of shelves: its shelves stand in the order they were added (and
    -- moved), like chips in the strip. No sort levels, as for OPDS.
    shelves       = {},
}
-- A registered source (lib/bookshelf_sources) brings its own default. The
-- Kindle's is title rather than filename: its files are named things like
-- "01. The Colour of Magic - Terry Pratchett_127FE891….kfx", so a filename sort
-- would look arbitrary next to the titles on screen.
setmetatable(SOURCE_SORT_DEFAULTS, { __index = function(_t, kind)
    local spec = require("lib/bookshelf_sources").get(kind)
    return spec and type(spec.sort_default) == "table" and spec.sort_default or nil
end })

-- _resolveOpdsTitle(id): the configured title for an OPDS server key, or nil
-- if bookshelf_opds_source can't be loaded or the server has since been
-- removed from the stock plugin's list. pcall-guarded because the source
-- file is plugin-owned (see bookshelf_opds_source.lua's header) and this
-- editor must degrade gracefully rather than error if it's ever malformed.
local function _resolveOpdsTitle(id)
    if not id or id == "" then return nil end
    local ok, OpdsSource = pcall(require, "lib/bookshelf_opds_source")
    if not ok or not OpdsSource then return nil end
    local ok2, server = pcall(OpdsSource.getServer, id)
    if ok2 and server and server.title then return server.title end
    return nil
end

-- Editor.sourceSortDefaults(kind) -> a fresh { {key, reverse}, ... }, or nil.
--
-- Public because chips are created in more than one place: the collection
-- manager pins one straight into the tab list without building a draft, and
-- carrying its own copy of the collection default is how the two drifted.
-- Always a copy -- the caller stores it on a tab the reader then edits, and a
-- reference would let a toggled `reverse` rewrite the default for every chip
-- made afterwards.
function Editor.sourceSortDefaults(kind)
    local defaults = kind and SOURCE_SORT_DEFAULTS[kind]
    if not defaults then return nil end
    local copy = {}
    for i, level in ipairs(defaults) do
        copy[i] = { key = level.key, reverse = level.reverse }
    end
    return copy
end

local function _applySourceDefaults(draft)
    local kind = draft.source and draft.source.kind
    local copy = Editor.sourceSortDefaults(kind)
    if copy then
        draft.sort_priority = copy
    end
    -- A registered source can have the last word on a new shelf's defaults
    -- (the Kindle's filters out formats KOReader cannot open).
    local Sources = require("lib/bookshelf_sources")
    local src_spec = kind and Sources.get(kind)
    if src_spec and src_spec.new_shelf then Sources.call(src_spec, "new_shelf", draft) end
    -- QoL: if the chip's label is still the default "New shelf" (i.e.
    -- the user hasn't customised it), rename it to match the picked
    -- source — e.g. picking "Genres" sets the label to "Genres",
    -- picking a specific author sets it to that author's name. Only
    -- the untouched default is replaced; user-edited labels are
    -- preserved as-is.
    -- "New chip" was this sentinel's wording before the shelf rename. A tab
    -- saved under the old name still carries that literal label, so accept it
    -- too or those chips silently lose the auto-rename. English only: a
    -- translated old label cannot be recognised without keeping the retired
    -- msgid alive purely to compare against, which is not worth a string in
    -- every locale for a label the reader can change in two taps.
    if (draft.label == _("New shelf") or draft.label == "New chip")
            and draft.source then
        local fresh
        if draft.source.id and draft.source.id ~= "" then
            -- Specific-X sources (folder, single_series, etc.): use the
            -- id as the label, with folder basename special-cased so
            -- long paths don't blow out the chip pill.
            if draft.source.kind == "folder" or draft.source.kind == "folder_flat" then
                fresh = draft.source.id:match("([^/]+)/?$") or draft.source.id
            elseif draft.source.kind == "opds" then
                -- The id is an opaque server-key hash (bookshelf_opds_source's
                -- djb2 digest of the feed URL), not human-readable -- use the
                -- configured title instead, falling back to the raw key only
                -- if the server has since vanished.
                fresh = _resolveOpdsTitle(draft.source.id) or draft.source.id
            else
                fresh = draft.source.id
            end
        elseif kind and SOURCE_LABEL and SOURCE_LABEL[kind] then
            fresh = SOURCE_LABEL[kind]()
        end
        if fresh and fresh ~= "" then draft.label = fresh end
    end
end

-- Group source kinds. These tabs show GROUP CARDS at the top level
-- (one card per author / genre / series / tag / format) and book
-- LISTS inside each card when drilled in. The sort_priority is
-- interpreted as level-1 = order of group cards, levels 2+ = order
-- of books within each group.
local GROUP_KINDS = {
    series  = true, authors = true, genres = true,
    tags    = true, formats = true, languages = true,
}

-- Level-1 (group order) labels for group tabs. The engine's labels
-- ("Series name", "Last opened", "Book count") are aimed at per-book
-- semantics and read awkwardly when the records are groups -- "Series
-- name" on the Authors tab actually orders authors alphabetically.
-- Override here for clarity. Used by both the picker buttons and the
-- editor's Sort-row button text_func so the displayed label matches
-- what the user picked.
--
-- `series_name` is not only the series key: the sort engine uses that field
-- as the GROUP CARD's name for every group shape (see its comment at
-- "5. b.series_name -- group shape (Authors / Genres tab)"). So one label
-- covered both a thing's name and a PERSON's, and English is unusually
-- relaxed about that. Slovak is not -- meno for a person, nazov for a thing --
-- and nor are Czech, Polish, Russian, Ukrainian or German, so a translator
-- had to pick one and be wrong elsewhere (issue 432, from the Slovak
-- translator reviewing the catalogue).
--
-- Split by what is being named rather than per tab: the Authors shelf is the
-- only group whose cards are people, and "Full name" pairs with the Surname
-- option sitting next to it. Everything else is a thing and keeps "Name",
-- which is now unambiguous because the collection dialog no longer shares it.
local GROUP_LEVEL1_NAME_BY_KIND = {
    authors = function() return _("Full name") end,
}
local GROUP_LEVEL1_LABEL = {
    series_name    = function(kind)
        local person = GROUP_LEVEL1_NAME_BY_KIND[kind or ""]
        if person then return person() end
        return _("Name")
    end,
    author_surname = function() return _("Surname") end,
    last_opened    = function() return _("Most recently read") end,
    date_added     = function() return _("Most recently added") end,
    book_count     = function() return _("Book count") end,
}

-- Friendly source labels shown on the "Source:" button in the editor.
-- These mirror the source picker's button labels so the user sees the
-- same wording in both places. Functions because gettext expands at
-- call time, not module load.
SOURCE_LABEL = {
    all           = function() return _("Home (folders)")     end,
    library       = function() return _("Home (flattened)")   end,
    recent        = function() return _("Recently read")      end,
    latest        = function() return _("Latest added")       end,
    series        = function() return _("Series")             end,
    authors       = function() return _("Authors")            end,
    genres        = function() return _("Genres")             end,
    tags          = function() return _("Collections")        end,
    formats       = function() return _("Formats")            end,
    ratings       = function() return _("Ratings")            end,
    languages     = function() return _("Languages")          end,
    favorites     = function() return _("Favorites")          end,
    -- "Specific X" kinds carry an id; the resolver appends it.
    folder        = function() return _("Folder")             end,
    folder_flat   = function() return _("Folder (flattened)")  end,
    collection    = function() return _("Collection")         end,
    tag           = function() return _("Collection")         end,
    genre         = function() return _("Genre")              end,
    author        = function() return _("Author")             end,
    single_series = function() return _("Series")             end,
    status        = function() return _("Status")             end,
    format        = function() return _("Format")             end,
    rating        = function() return _("Rating")             end,
    language      = function() return _("Language")           end,
    bookorbit     = function() return _("BookOrbit")           end,
    -- No id yet (picker not used, or the source table was hand-built):
    -- generic fallback. Once an id is present _resolveSourceLabel takes
    -- the "OPDS: <title>" branch instead of this one.
    opds          = function() return _("OPDS catalog")       end,
    -- A shelf holding other shelves (5.4), each with its own source.
    shelves       = function() return _("Shelf of shelves") end,
    -- A shelf being created, before a source is picked (TabModel.newTab).
    none          = function() return _("(none)") end,
}
-- A registered source (lib/bookshelf_sources: the Kindle's own library, a
-- plugin's) names itself.
setmetatable(SOURCE_LABEL, { __index = function(_t, kind)
    local Sources = require("lib/bookshelf_sources")
    if not Sources.get(kind) then return nil end
    return function() return Sources.label(kind) or kind end
end })

-- _resolveSourceLabel(source): display string for "Source: <label>".
-- For built-in kinds returns just the label ("Recently read"). For
-- specific-X kinds returns "<Category>: <id>" so the user can see at
-- a glance which author / series / folder / etc. is selected.
local function _resolveSourceLabel(source)
    if not source or not source.kind then return _("(none)") end
    if source.kind == "opds" and source.id and source.id ~= "" then
        -- Distinct "OPDS: <title>" shape rather than the generic
        -- "<Category>: <id>" below -- the id is an opaque hash key, not
        -- something worth showing to the user; the title is what they
        -- recognise. Falls back to the raw key if the server has since
        -- been removed from the stock plugin's list.
        return T(_("OPDS: %1"), _resolveOpdsTitle(source.id) or source.id)
    end
    local fn = SOURCE_LABEL[source.kind]
    local label = fn and fn() or source.kind
    if source.id and source.id ~= "" then
        -- For folder paths, show the basename to keep the row tidy --
        -- "/mnt/us/Calibre/library/Pratchett" reads worse than "Pratchett".
        local id = source.id
        if source.kind == "folder" or source.kind == "folder_flat" then
            id = id:match("([^/]+)/?$") or id
        elseif source.kind == "bookorbit" then
            -- id is the internal "query:rest" encoding (see
            -- bookshelf_bookorbit_source.lua) -- not fit for display, so
            -- just show the query part ("libraries", "recent", ...).
            local ok_bo, BOSource = pcall(require, "lib/bookshelf_bookorbit_source")
            local query = ok_bo and BOSource and (BOSource.decodeId(id)) or nil
            -- "libraries-groups" etc. are an internal id token (see
            -- GROUPED_SECTION_QUERY in bookshelf_bookorbit_source.lua),
            -- not meant for display -- show the plain section name with
            -- a hint instead.
            if query then query = query:gsub("%-groups$", " (folders)") end
            local suffix = ""
            if ok_bo and BOSource and BOSource.isGroupRoot and BOSource.isGroupRoot(id) then
                local sec = BOSource.groupSection(id)
                local opts_lbl = Editor._boOptionLabels(sec)
                if opts_lbl then
                    if source.bo_sort then
                        suffix = suffix .. " \xC2\xB7 " .. opts_lbl.sort[source.bo_sort]
                    end
                    if source.bo_filter then
                        suffix = suffix .. " \xC2\xB7 " .. opts_lbl.filter[source.bo_filter]
                    end
                end
            end
            return label .. ": " .. (query or id) .. suffix
        end
        return label .. ": " .. id
    end
    return label
end

-- Resolve the display label for a (level_index, key) pair on a tab
-- with source_kind. Returns the engine's default short/label unless
-- the (group, level 1) context overrides it.
local function _resolveSortLabel(level_index, key, source_kind)
    local is_group = GROUP_KINDS[source_kind or ""] or false
    if is_group and level_index == 1 and GROUP_LEVEL1_LABEL[key] then
        -- kind is passed through: the name label depends on whether the
        -- cards are people or things (issue 432).
        return GROUP_LEVEL1_LABEL[key](source_kind)
    end
    local SortEngine = require("lib/bookshelf_sort_engine")
    local k = SortEngine.KEYS[key]
    return (k and (k.short or k.label)) or key
end

-- editTab(tab_id, opts) -- modal editor for one tab.
-- opts = { on_change = function(info) end, bw = <BookshelfWidget>,
--          pick_source_first = bool, on_discard = function() end }
-- _deepCopy(v) / _sameValue(a, b): for the plain values a shelf record holds
-- (strings, numbers, booleans and tables of them).
function Editor._deepCopy(v)
    if type(v) ~= "table" then return v end
    local out = {}
    for k, x in pairs(v) do out[k] = Editor._deepCopy(x) end
    return out
end

function Editor._sameValue(a, b)
    if type(a) ~= "table" or type(b) ~= "table" then return a == b end
    for k, x in pairs(a) do if not Editor._sameValue(x, b[k]) then return false end end
    for k in pairs(b) do if a[k] == nil then return false end end
    return true
end

function Editor:editTab(tab_id, opts)
    opts = opts or {}
    local target
    for _i, t in ipairs(TabModel.load()) do
        if t.id == tab_id then target = t; break end
    end
    if not target then return end

    -- The shelf being edited, as a working copy. Every change lands on the
    -- saved shelf as it is made (commit, below): there is no Save and no
    -- Cancel any more, only Close (maintainer, after the 5.4 tutorial: "make
    -- that all apply on selection and change Save to Close"). A copy rather
    -- than the stored record itself so a change can still be refused before it
    -- lands (a shelf of shelves' source, sourceChosen) and so the pickers,
    -- which edit it in place, never leave half a change in the settings table.
    -- Deep: a registered source's editor buttons edit tables inside
    -- draft.source.
    local draft = Editor._deepCopy(target)
    -- Ensure required nested tables exist even if a legacy schema is missing them.
    draft.filter        = draft.filter        or {}
    draft.sort_priority = draft.sort_priority or {}
    draft.source        = draft.source        or { kind = tab_id }

    -- One-time schema migration: tab.icon used to be a separate field.
    -- Now label may contain inline nerd-font glyphs. If the persisted tab
    -- still has an icon field, fold it into the front of the label so the
    -- editor presents one unified string. The first change written locks the
    -- migration in (the chip strip falls back on the legacy field meanwhile).
    if draft.icon and draft.icon ~= "" then
        draft.label = draft.icon .. " " .. (draft.label or "")
        draft.icon  = nil
    end

    -- What the saved shelf holds: the working copy as last committed, which a
    -- refused change goes back to.
    local committed = Editor._deepCopy(draft)

    -- A shelf being created (TabModel.newTab) has no source until one is
    -- picked, and stays `pending` until then. Closing the editor while it
    -- still has none removes it and hands back to opts.on_discard (the shelf
    -- the reader came from); once it has one it is an ordinary shelf.
    local is_new = target.pending == true
    local function hasSource()
        return draft.source ~= nil and draft.source.kind ~= TabModel.NO_SOURCE
    end
    local dialog   -- the editor window, built below; discardNew closes it
    local closed = false   -- once, whichever way the editor is left

    -- THE SHELF BEHIND follows every change, on a rebuild DEFERRED and
    -- coalesced. A rebuild inside the tap (several hundred milliseconds on a
    -- Kindle in spine mode) held the picker up, and taps in that window were
    -- dropped ("there's a lag after tapping one where tapping another does
    -- nothing"). Lua has one thread, so the work cannot move off it; it can
    -- move AFTER the tap: armed for PREVIEW_DEBOUNCE_S after the LAST change,
    -- run at once by the close paths (finish) if it is still owed. A source,
    -- filter or sort change is one change and one rebuild: those pickers hand
    -- back when the reader leaves them, not per tap inside them.
    local PREVIEW_DEBOUNCE_S = 0.4
    local owed, owed_info = false, {}
    local function firePreview()
        if not owed then return end
        owed = false
        local info = owed_info
        owed_info = {}
        if opts.on_change then opts.on_change(info) end
    end
    local function schedulePreview()
        owed = true
        UIManager:unschedule(firePreview)
        UIManager:scheduleIn(PREVIEW_DEBOUNCE_S, firePreview)
    end
    -- A close path: the rebuild still owed, now. Or not at all (drop).
    local function settlePreview(drop)
        UIManager:unschedule(firePreview)
        if drop then owed = false; owed_info = {} else firePreview() end
    end

    -- dropShelves(tabs): delete this shelf's shelves from `tabs`, in place.
    local function dropShelves(tabs)
        for _i, kid in ipairs(TabModel.childrenOf(tab_id, tabs)) do
            TabModel.removeTree(tabs, kid.id)
        end
    end

    -- commit([drop_shelves]): write the working copy onto the saved shelf and
    -- arm the rebuild. In memory only (saveDeferred): a tap on a nudge must
    -- not wait for a settings flush, hundreds of milliseconds on a Kindle. The
    -- editor flushes once, as it closes (finish), which is the action
    -- boundary. A source change (or a source's own list / sort choice) tells
    -- the shelf, so a folder drilled into under the old one is left.
    local function commit(drop_shelves)
        if draft.pending and hasSource() then draft.pending = nil end
        local save_tabs = TabModel.load()
        for i, t in ipairs(save_tabs) do
            if t.id == tab_id then
                if not Editor._sameValue(t.source, draft.source) then
                    owed_info.source_changed = true
                end
                save_tabs[i] = Editor._deepCopy(draft)
                break
            end
        end
        if drop_shelves then dropShelves(save_tabs) end
        TabModel.saveDeferred(save_tabs)
        committed = Editor._deepCopy(draft)
        schedulePreview()
    end
    -- revert(): put the working copy back to what is saved, in place (the
    -- pickers hold it by reference).
    local function revert()
        for k in pairs(draft) do draft[k] = nil end
        for k, v in pairs(Editor._deepCopy(committed)) do draft[k] = v end
    end

    local function discardNew()
        closed = true
        settlePreview(true)
        local tabs = TabModel.load()
        TabModel.removeTree(tabs, tab_id)
        TabModel.save(tabs)
        if dialog then UIManager:close(dialog) end
        if opts.on_discard then opts.on_discard()
        elseif opts.on_change then opts.on_change() end
    end

    -- finish(): Close, the title bar X, a tap outside and Back all end here.
    -- Everything is saved already; what is left is the flush, and the shelf's
    -- rebuild if the last change has not had it yet. A new shelf that never
    -- got a source is not kept (see is_new).
    local function finish()
        if closed then return end
        if is_new and not hasSource() then return discardNew() end
        closed = true
        UIManager:close(dialog)
        TabModel.flush()
        settlePreview()
    end

    -- A confirmed arrangement of the collection, from the sort picker's "Edit
    -- collection order". Not shelf state: it is written to KOReader the moment
    -- it is confirmed (and drops the book cache itself), so all the editor owes
    -- it is the shelf's rebuild, the same deferred one any change gets
    -- (maintainer, on the PW5: the shelf behind shows it when the arrange
    -- window closes, not only once the editor is closed).
    --
    -- Declared below schedulePreview: a local function resolves the names in
    -- its body where it is written, so above that point schedulePreview would
    -- be a nil global at the moment of the confirm.
    local function onArranged()
        schedulePreview()
    end

    -- sourceChosen(): the source picker has handed back. Nothing picked is
    -- nothing to do. A shelf of shelves given another source would keep its
    -- shelves but never show them again -- nothing else lists a sub-shelf, so
    -- they could be neither reached nor deleted -- so that change ASKS first,
    -- and deletes them with it; refused, the shelf keeps its source. Anything
    -- else applies at once: one change, one fetch.
    local rebuild   -- the dialog's own redraw, defined below
    local function sourceChosen()
        if Editor._sameValue(draft.source, committed.source) then rebuild(); return end
        if draft.source.kind ~= TabModel.SHELVES_KIND
                and #TabModel.childrenOf(tab_id) > 0 then
            UIManager:show(ConfirmBox:new{
                text        = _("Changing this shelf's source deletes the shelves inside it. This cannot be undone."),
                ok_text     = _("Change"),
                ok_callback = function() commit(true); rebuild() end,
                -- Cancel, a tap outside, Back.
                cancel_callback = function() revert(); rebuild() end,
            })
            return
        end
        commit()
        rebuild()
    end

    -- Lazy-loaded widget constructors (avoids polluting the module-level scope).
    local FrameContainer    = require("ui/widget/container/framecontainer")
    local CenterContainer   = require("ui/widget/container/centercontainer")
    local WidgetContainer   = require("ui/widget/container/widgetcontainer")
    local InputContainer    = require("ui/widget/container/inputcontainer")
    local MovableContainer  = require("ui/widget/container/movablecontainer")
    local VerticalGroup     = require("ui/widget/verticalgroup")
    local HorizontalGroup   = require("ui/widget/horizontalgroup")
    local TitleBar          = require("ui/widget/titlebar")
    local ButtonTable       = require("ui/widget/buttontable")
    local Button            = require("ui/widget/button")
    local InputDialog       = require("ui/widget/inputdialog")
    local GestureRange      = require("ui/gesturerange")
    local Blitbuffer        = require("ffi/blitbuffer")
    local Device            = require("device")

    local sw       = Screen:getWidth()
    local sh       = Screen:getHeight()
    local dialog_w = math.floor(math.min(sw, sh) * 0.85)

    -- `dialog` is declared above, with discardNew, which closes it.
    local frame
    local current_bt   -- the ButtonTable on screen; rebuilt on every edit

    -- rebuild() -- swap frame[1] in-place so the button labels and enabled
    -- states refresh without touching the MovableContainer. The anchor-based
    -- positioning set on first paint is therefore preserved across rebuilds.
    -- Declared above, with sourceChosen, which calls it.
    rebuild = function()
        -- Reload tabs for the move buttons so enabled state is always current.
        local current_tabs = TabModel.load()
        local current_idx = 0
        for i, t in ipairs(current_tabs) do
            if t.id == tab_id then current_idx = i; break end
        end
        -- A chevron is "at the edge" only if there's no ENABLED neighbour
        -- in that direction. Hidden tabs don't count toward visible order
        -- so they shouldn't gate the move buttons.
        -- A sub-shelf moves among the shelves of its own shelf of shelves,
        -- and a top-level shelf among the top-level ones.
        local me = current_tabs[current_idx]
        local function neighbour(t)
            return t.enabled ~= false and TabModel.isSibling(t, me)
        end
        local at_left = true
        for i = current_idx - 1, 1, -1 do
            if neighbour(current_tabs[i]) then at_left = false; break end
        end
        local at_right = true
        for i = current_idx + 1, #current_tabs do
            if neighbour(current_tabs[i]) then at_right = false; break end
        end

        -- Bookends-style nudge chevrons (mdi-chevron-left / right from the
        -- Symbols Nerd Font). Same glyph + render-size as the line editor's
        -- position nudges so the visual language is consistent.
        local CHEV_LEFT  = "\xEE\xA1\x80"  -- U+E840 mdi-chevron-left
        local CHEV_RIGHT = "\xEE\xA1\x81"  -- U+E841 mdi-chevron-right
        local CHEV_SIZE  = 28

        local function open_label_dialog()
            local label_dialog
            local IconsLibrary = require("lib/bookshelf_icons_library")
            local row = {
                {
                    text     = _("Cancel"),
                    id       = "close",
                    callback = function() UIManager:close(label_dialog) end,
                },
                {
                    text     = _("Insert icon\xE2\x80\xA6"),
                    callback = function()
                        -- Dismiss the on-screen keyboard before showing the
                        -- icon picker -- otherwise the keyboard covers the
                        -- bottom half of the icon library on portrait
                        -- e-readers. Re-show after the picker closes so the
                        -- user can keep typing.
                        if label_dialog and label_dialog.onCloseKeyboard then
                            pcall(function() label_dialog:onCloseKeyboard() end)
                        end
                        -- Guard against tap-fall-through. With the keyboard
                        -- hidden, InputDialog:onTap treats any tap outside
                        -- the dialog frame as "close the dialog" (see
                        -- frontend/ui/widget/inputdialog.lua:557-560).
                        -- Rapid pagination taps on the icon picker can leak
                        -- through, dismissing the dialog underneath; the
                        -- picker then has nothing to send its glyph to,
                        -- leaving the keyboard orphaned on screen after the
                        -- user's pick (issue #43). Setting
                        -- deny_keyboard_hiding short-circuits onTap entirely
                        -- so the dialog can't dismiss itself while the
                        -- picker is the modal on top. Restored when the
                        -- picker callback runs.
                        if label_dialog then
                            label_dialog.deny_keyboard_hiding = true
                        end
                        -- Shelf labels render literally (no token
                        -- expansion), so dynamic %tokens are excluded. The
                        -- SVG icon folder is offered (svg): an [icon=NAME]
                        -- in a label draws that image (issue 469).
                        IconsLibrary:show(function(glyph)
                            if label_dialog then
                                label_dialog.deny_keyboard_hiding = false
                            end
                            -- Insert the glyph at cursor in the InputDialog
                            -- via KOReader's InputDialog addTextToInput.
                            if glyph and glyph ~= ""
                                    and label_dialog and label_dialog.addTextToInput then
                                pcall(function() label_dialog:addTextToInput(glyph) end)
                            end
                            if label_dialog and label_dialog.onShowKeyboard then
                                pcall(function() label_dialog:onShowKeyboard() end)
                            end
                        end, { dynamic = false, svg = true })
                    end,
                },
            }
            row[#row + 1] = {
                text             = _("OK"),
                is_enter_default = true,
                callback         = function()
                    -- Applied on OK, not per keystroke: a text field is the
                    -- one control here with a commit of its own.
                    draft.label = label_dialog:getInputText()
                    UIManager:close(label_dialog)
                    commit()
                    rebuild()
                end,
            }
            label_dialog = InputDialog:new{
                title           = _("Shelf label"),
                input           = draft.label or "",
                allow_newline   = false,
                text_height     = Screen:scaleBySize(40),
                edited_callback = function() end,
                buttons         = { row },
            }
            UIManager:show(label_dialog)
            label_dialog:onShowKeyboard()
        end

        -- Sort-button text for level N. Reads draft.sort_priority[N] and
        -- resolves the key's label through _resolveSortLabel so the
        -- group-tab context-renames ("Name", "Surname", etc.) show up
        -- consistently with what the picker offered. The ↑ glyph is
        -- appended only when the direction is inverted from the key's
        -- natural default -- a "Book count" sort at default (most-first)
        -- reads cleaner without an arrow that would suggest ascending.
        local function _sortButtonText(d, level_index)
            local lv = d.sort_priority and d.sort_priority[level_index]
            if not lv then
                return _("Sort ") .. level_index .. _(": (none)")
            end
            local kind = d.source and d.source.kind
            local lbl = _resolveSortLabel(level_index, lv.key, kind)
            if not _isDefaultDirection(lv.key, lv.reverse) then
                lbl = lbl .. " " .. "\xE2\x86\x91"
            end
            return level_index .. ": " .. lbl
        end

        local function move_tab(delta)
            local move_tabs = TabModel.load()
            local mi = 0
            for i, t in ipairs(move_tabs) do
                if t.id == tab_id then mi = i; break end
            end
            if mi == 0 then rebuild(); return end
            -- Walk in the delta direction looking for the next ENABLED
            -- neighbour. Hidden tabs are skipped so the swap moves THIS
            -- tab past any hidden ones between it and the next visible
            -- chip in the strip. If no enabled neighbour exists, no-op.
            local target = mi + delta
            local me = move_tabs[mi]
            while target >= 1 and target <= #move_tabs do
                local t = move_tabs[target]
                if t.enabled ~= false and TabModel.isSibling(t, me) then break end
                target = target + delta
            end
            if target >= 1 and target <= #move_tabs then
                move_tabs[mi], move_tabs[target] = move_tabs[target], move_tabs[mi]
                TabModel.save(move_tabs)
                -- Position moves are visual only (book lists unchanged);
                -- don't invalidate the book cache. Fire on_change so the
                -- chip strip repaints in its new order.
                if opts.on_change then opts.on_change() end
            end
            rebuild()
        end

        -- Row 1b's contents: sort priority levels 1-3 for most sources, but
        -- OPDS feeds have no independent sort -- the remote server's own
        -- order is authoritative (see SOURCE_SORT_DEFAULTS.opds) -- so that
        -- row collapses to a single disabled row naming the constraint
        -- rather than offering pickers that would silently do nothing.
        local sort_row
        -- A fetch-mode registered source (lib/bookshelf_sources) orders itself
        -- the same way.
        local is_paged_src = draft.source
            and require("lib/bookshelf_sources").isPaged(draft.source.kind) or false
        -- ...unless it offers editor buttons of its own (its list, sort and
        -- filters: SOURCE_API.md "Editor rows"), which take that row's place.
        -- A button edits draft.source and calls done(), which saves it; the
        -- shelf fetches again, draft.source being part of its cache key.
        local src_rows
        if is_paged_src then
            local Sources = require("lib/bookshelf_sources")
            local spec_rows = Sources.editorRows(draft.source.kind, draft)
            for _r, row in ipairs(spec_rows or {}) do
                local out = {}
                for _b, b in ipairs(row) do
                    out[#out + 1] = {
                        text_func = function() return Sources.buttonText(b, draft) end,
                        callback = function()
                            local done = function() commit(); rebuild() end
                            local ok, err = pcall(b.callback, draft, done)
                            if not ok then logger.warn("[bookshelf] source: editor button failed:", tostring(err)) end
                        end,
                    }
                end
                src_rows = src_rows or {}
                src_rows[#src_rows + 1] = out
            end
        end
        if draft.source and (draft.source.kind == "opds" or is_paged_src) then
            sort_row = {
                { text = _("Server order"), enabled = false },
            }
        elseif draft.source and draft.source.kind == "shelves" then
            -- Its shelves stand in your order; the arrows in each one's
            -- editor move it.
            sort_row = {
                { text = _("Shelves stand in the order you arrange them"), enabled = false },
            }
        elseif Editor._boGroupSection(draft.source) then
            -- BookOrbit Authors / Series folder chips: server-side sort and
            -- filter, stored on the source (bo_sort / bo_filter). The
            -- generic sort levels do nothing for these.
            local bo_section = Editor._boGroupSection(draft.source)
            local lbl = Editor._boOptionLabels(bo_section)
            local okb, BO = pcall(require, "lib/bookshelf_bookorbit")
            local v2 = okb and BO and BO.cachedListsV2 and BO.cachedListsV2()
            if v2 == false then
                sort_row = {
                    { text = _("Needs a newer BookOrbit server"), enabled = false },
                }
            else
                sort_row = {
                    {
                        text_func = function()
                            return _("Sort: ") .. lbl.sort[draft.source.bo_sort or "name"]
                        end,
                        callback = function()
                            Editor:_pickBookOrbitOption(draft, "bo_sort", lbl.sort_options,
                                _("Sort"), function() commit(); rebuild() end)
                        end,
                    },
                    {
                        text_func = function()
                            return _("Show: ") .. lbl.filter[draft.source.bo_filter or "all"]
                        end,
                        callback = function()
                            Editor:_pickBookOrbitOption(draft, "bo_filter", lbl.filter_options,
                                _("Show"), function() commit(); rebuild() end)
                        end,
                    },
                }
            end
        else
            sort_row = {
                {
                    text_func = function() return _sortButtonText(draft, 1) end,
                    callback = function()
                        Editor:_pickSortLevel(draft, 1, function() commit(); rebuild() end, onArranged)
                    end,
                },
                {
                    text_func = function() return _sortButtonText(draft, 2) end,
                    callback = function()
                        Editor:_pickSortLevel(draft, 2, function() commit(); rebuild() end, onArranged)
                    end,
                },
                {
                    text_func = function() return _sortButtonText(draft, 3) end,
                    callback = function()
                        Editor:_pickSortLevel(draft, 3, function() commit(); rebuild() end, onArranged)
                    end,
                },
            }
        end

        -- Source + Filters row. The local-library filters (genre / tags /
        -- status / rating / ...) do nothing on an OPDS chip -- its books come
        -- straight from the remote feed, unfiltered by these -- so drop the
        -- Filters cell for OPDS sources. OPDS filtering is the feed's own facets
        -- (Language / Category), shown as folder tiles at the top of the shelf.
        local is_opds_src = draft.source and draft.source.kind == "opds"
        -- A shelf of shelves shows shelves, each with filters of its own, so
        -- it has none to offer.
        local is_shelves_src = draft.source and draft.source.kind == "shelves"
        -- Source gets a row to itself: it is the one choice that changes what
        -- every other control on this dialog means, and sharing a row made it
        -- read as a peer of the things it governs.
        local source_row = {
            {
                text_func = function()
                    -- "grouping" in the label: readers asking how to make a
                    -- shelf of series or authors did not look for it under
                    -- "Source" (maintainer).
                    return _("Source / grouping: ") .. _resolveSourceLabel(draft.source)
                end,
                callback = function()
                    Editor:_pickSource(draft, sourceChosen)
                end,
            },
        }
        -- Beneath it, the two per-chip overrides, paired: what this shelf
        -- SHOWS (filters, or a catalog's own settings) and how its group tiles
        -- LOOK.
        local shelf_row = {}
        if is_shelves_src then
            -- No filters (see is_shelves_src). In their place, whether the
            -- "+ Add shelf" tile shows: wanted while the shelves are being
            -- set up, clutter once they are (maintainer).
            shelf_row[#shelf_row + 1] = {
                text_func = function()
                    return (draft.hide_add_tile and "  " or "\xE2\x9C\x93 ")
                        .. _("Show + Add shelf")
                end,
                callback = function()
                    draft.hide_add_tile = (not draft.hide_add_tile) or nil
                    commit()
                    rebuild()
                end,
            }
        elseif is_paged_src then   -- luacheck: ignore 542
            -- A fetch-mode source filters on its own side; no local Filters.
        elseif not is_opds_src then
            shelf_row[#shelf_row + 1] = {
                text_func = function()
                    return _("Filters: ") .. Filter.summary(draft.filter or {})
                end,
                callback = function()
                    Editor:_openFilters(draft, function() commit(); rebuild() end)
                end,
            }
        else
            -- The slot the local filters would occupy: this catalog's own
            -- settings (download folder from issue #319, plus the refresh /
            -- cover / page-size / timeout overrides). Per chip rather than
            -- one global setting so each catalog can be tuned for what it
            -- actually is - a public catalog wants the conservative shelf
            -- defaults, a server on your own network usually does not.
            shelf_row[#shelf_row + 1] = {
                text_func = function() return _("Catalog settings") end,
                callback = function()
                    Editor:_openCatalogSettings(draft, function()
                        commit()
                        rebuild()
                    end)
                end,
            }
        end

        -- Shelf style: whether this chip is a LIST, and if it is a grid, how
        -- its folder / stack tiles are drawn. Per chip because a chip IS a
        -- kind of shelf -- and because an OPDS catalog's subcatalogs render as
        -- folder tiles, so without this they were bound to whatever the
        -- filesystem's folders were set to.
        --
        -- It used to be "Folder style" and to be hidden for catalogues, on the
        -- grounds that an OPDS subcatalog has no artwork of its own so every
        -- tile style renders the same text tile -- a row that changed nothing.
        -- That reasoning holds for the tile styles and NOT for List, which is
        -- as meaningful on a catalogue as anywhere else (arguably more: a
        -- catalogue page is mostly titles). So the row is now always shown and
        -- a catalogue is offered the two options that mean something.
        shelf_row[#shelf_row + 1] = {
            text_func = function()
                local SD = require("lib/bookshelf_stack_display")
                -- ONE line for two settings, so it names the more consequential
                -- one: a chip pinned to a mode says so, and only a chip that
                -- follows the globals falls back to naming its tile style.
                -- "Covers · Ribbon" was the alternative and does not fit the
                -- row on a PW5 -- the picker shows both, and the shelf behind
                -- already shows the look.
                --
                -- chipLabelFor, not labelFor: a chip has a state labelFor
                -- cannot express -- "not set", which is not the same as "set to
                -- Divider card".
                local mode = Editor._chipModeLabel(draft[ViewMode.CHIP_KEY])
                return _("Shelf style: ")
                    .. (mode or SD.chipLabelFor(draft.group_display))
            end,
            callback = function()
                -- now: the shelf behind rebuilt at once, not on the
                -- debounce; the Theme library debounces its taps itself and
                -- refreshes the whole screen as it applies, so a rebuild left
                -- for later was a flash that showed nothing, then a second
                -- one with the theme (maintainer on the PW5, 2026-10-09).
                Editor:_pickGroupDisplay(draft, function(now)
                    commit()
                    if now then settlePreview() end
                    rebuild()
                end, {
                    -- Stand the editor down while the picker is up: it sits
                    -- over the shelf rows whose tiles are being previewed.
                    hide = function() UIManager:close(dialog) end,
                    -- "ui", not a bare show. UIManager:show passes its
                    -- refreshtype straight to setDirty, which only enqueues a
                    -- refresh when it HAS one - so a bare show put the editor
                    -- back on the window stack, taking taps, without ever
                    -- painting it. It read as an invisible dialog swallowing
                    -- the screen: a tap in the middle opened the source menu.
                    show = function() UIManager:show(dialog, "ui") end,
                    -- A catalogue gets Default and List only; see above.
                    is_opds = is_opds_src or is_paged_src,
                    -- The live shelf, so the density nudges can seed from the
                    -- numbers actually on screen instead of from a constant.
                    bw = opts.bw,
                })
            end,
        }

        local buttons = {
            -- Row 0: [chev_left] [Label] [chev_right]. Label is a tappable
            -- button that opens an InputDialog where the user can type plain
            -- text, insert nerd-font glyphs via 'Insert icon...', and remove
            -- them by editing the field as usual. One field for both text
            -- and icons; no separate icon picker on the main dialog.
            {
                {
                    text           = CHEV_LEFT,
                    font_face      = "symbols",
                    font_size      = CHEV_SIZE,
                    font_bold      = false,
                    enabled_func   = function() return not at_left end,
                    callback       = function() move_tab(-1) end,
                },
                {
                    -- Title bar already shows the live label ("Editing: ..."),
                    -- so the button just describes its action -- no need to
                    -- repeat the label text.
                    text     = _("Edit label"),
                    callback = open_label_dialog,
                },
                {
                    text           = CHEV_RIGHT,
                    font_face      = "symbols",
                    font_size      = CHEV_SIZE,
                    font_bold      = false,
                    enabled_func   = function() return not at_right end,
                    callback       = function() move_tab(1) end,
                },
            },
            -- Row 1a: source, full width.
            source_row,
            -- Row 1b: filters (or catalog settings) + folder style.
            shelf_row,
            -- Row 1b: sort priority levels 1, 2, 3 (engine already supports
            -- unbounded levels via chainedComparator; three covers the
            -- common nested case "author surname -> series -> series index"
            -- with zero meaningful perf cost since deeper levels only fire
            -- when earlier ones tie) -- or, for an OPDS source, the single
            -- disabled "Server order" row computed above.
            sort_row,
            -- Row 2: actions [delete] [Close] [add]. One Close, not Cancel
            -- and Save: every change has already been applied and saved, so
            -- there is nothing left to keep or throw away (maintainer, 2026-10-08).
            -- Delete (U+E8BF, mdi-delete) is enabled only for custom tabs;
            -- built-ins are hidden via the bookshelf menu's checkbox.
            -- Add (U+F055, fa-plus-circle) creates a new custom_N tab.
            -- All buttons borderless so the dialog frame's bottom edge
            -- serves as the action-row boundary (no double-border).
            {
                {
                    text           = "\xEE\xA2\xBF",  -- U+E8BF mdi-delete
                    font_face      = "symbols",
                    font_size      = CHEV_SIZE,
                    font_bold      = false,
                    bordersize     = 0,
                    callback   = function()
                        local has_shelves = #TabModel.childrenOf(tab_id) > 0
                        UIManager:show(ConfirmBox:new{
                            text       = has_shelves
                                and _("Delete this shelf and the shelves inside it? This cannot be undone.")
                                or _("Delete this shelf? This cannot be undone."),
                            ok_text    = _("Delete"),
                            ok_callback = function()
                                -- Deleting a tab changes the list of tabs,
                                -- not the contents of any tab. Book caches
                                -- for other tabs stay valid; the deleted
                                -- tab's cache entries are harmless orphans
                                -- (never read again). No invalidateBookCache.
                                closed = true
                                settlePreview(true)
                                local del_tabs = TabModel.load()
                                -- Where the shelf on screen goes if it was
                                -- this one or inside it: up to this one's
                                -- shelf of shelves, read before the delete.
                                local parent_id
                                for _i, t in ipairs(del_tabs) do
                                    if t.id == tab_id then parent_id = t.parent; break end
                                end
                                local gone = TabModel.descendantIds(tab_id, del_tabs)
                                gone[tab_id] = true
                                TabModel.removeTree(del_tabs, tab_id)
                                TabModel.save(del_tabs)
                                UIManager:close(dialog)
                                local bw = opts.bw
                                if bw and gone[bw.chip] and parent_id and bw._openShelf then
                                    bw:_openShelf(parent_id)
                                elseif opts.on_change then
                                    opts.on_change()
                                end
                            end,
                        })
                    end,
                },
                {
                    -- "Close" either way, a new shelf included: one still
                    -- without a source is removed as the editor closes, which
                    -- the note above the source row says while it is that.
                    text             = _("Close"),
                    id               = "close",
                    is_enter_default = true,
                    bordersize       = 0,
                    callback         = function() finish() end,
                },
                {
                    -- Add button placed last in the row to balance the
                    -- destructive Delete on the far left.
                    text           = "\xEF\x81\x95",  -- U+F055 fa-plus-circle
                    font_face      = "symbols",
                    font_bold      = false,
                    font_size  = CHEV_SIZE,
                    bordersize = 0,
                    -- Not from a new shelf that has no source yet: it would
                    -- only make a second empty one beside it.
                    enabled_func = function() return hasSource() end,
                    callback   = function()
                        -- This shelf's changes are saved already; leave its
                        -- editor (the new shelf's selection rebuilds the
                        -- shelf, so no rebuild is owed here).
                        closed = true
                        settlePreview(true)
                        TabModel.flush()
                        -- Inside a shelf of shelves, the new shelf joins this
                        -- one's siblings: the widget makes it, opens it and
                        -- puts its editor up.
                        if draft.parent and opts.bw and opts.bw._addSubShelf then
                            UIManager:close(dialog)
                            opts.bw:_addSubShelf(draft.parent)
                            return
                        end
                        -- A new shelf (TabModel.newTab: no source yet, pending
                        -- until it has one), spliced right after the chip being
                        -- edited rather than at the end of the strip. Matches
                        -- the Pin-from-stack flow and keeps newly created
                        -- chips visually adjacent to their origin.
                        local fresh = TabModel.load()
                        local new_tab = TabModel.newTab(fresh, _("New shelf"))
                        local new_id = new_tab.id
                        TabModel.insertAfter(fresh, tab_id, new_tab)
                        TabModel.save(fresh)
                        UIManager:close(dialog)
                        -- Auto-select the new tab so the user lands on it after
                        -- editing (request), not back on the tab they added from.
                        -- _selectChip does its own rebuild; fall back to on_change
                        -- for any caller without a widget handle.
                        if opts.bw and opts.bw._selectChip then
                            opts.bw:_selectChip(new_id)
                        elseif opts.on_change then
                            opts.on_change()
                        end
                        -- Copied rather than mutated: opts belongs to the
                        -- editor we were opened from and outlives this call.
                        local new_opts = {}
                        for k, v in pairs(opts) do new_opts[k] = v end
                        new_opts.pick_source_first = true
                        -- Backing out of it lands back on this shelf.
                        new_opts.on_discard = function()
                            if opts.bw and opts.bw._selectChip then
                                opts.bw:_selectChip(tab_id)
                            elseif opts.on_change then
                                opts.on_change()
                            end
                        end
                        Editor:editTab(new_id, new_opts)
                    end,
                },
            },
        }

        -- A new shelf without a source yet: say what keeps it, above the
        -- source row, since Close reads the same as on any other shelf.
        if is_new and not hasSource() then
            table.insert(buttons, 2, {
                { text = _("Choose a source to keep this new shelf."), enabled = false },
            })
        end

        -- Strip empty rows. The conditional delete row's IIFE returns {}
        -- for built-in tabs; ButtonTable renders a zero-cell row as a
        -- thin separator strip which visually doubles with the adjacent
        -- row borders. Filtering keeps the dialog cleanly grid-shaped.
        local non_empty_buttons = {}
        for _i,row in ipairs(buttons) do
            if row == sort_row and src_rows then
                for _r, r in ipairs(src_rows) do non_empty_buttons[#non_empty_buttons + 1] = r end
            elseif #row > 0 then non_empty_buttons[#non_empty_buttons + 1] = row end
        end
        local button_table = ButtonTable:new{
            width   = dialog_w - 2 * Space.padding.default,
            buttons = non_empty_buttons,
            zero_sep = true,
        }
        -- FocusManager repaints `show_parent or self` on a D-pad move, and the
        -- table is not on the window stack, so without this the highlight never
        -- moved on screen (GitHub issue 361). Set after new{} so the Buttons
        -- keep their touch flash path exactly as before. The first build runs
        -- before the dialog exists: its creation below catches that one up.
        button_table.show_parent = dialog
        current_bt = button_table

        -- Dynamic title: shows the tab's current label so the user can see
        -- which tab they're editing at a glance, even while the Label
        -- button below is being edited. Falls back to a generic string
        -- when the label is empty / nil. with_bottom_line is off so the
        -- titlebar separator doesn't double with the top_row's top border.
        local title_text = _("Edit shelf")
        if draft.label and draft.label ~= "" then
            title_text = _("Editing: ") .. draft.label
        end
        local title_bar = TitleBar:new{
            width             = dialog_w,
            title             = title_text,
            with_bottom_line  = false,
            -- The X is Close.
            close_callback    = function() finish() end,
        }

        frame[1] = VerticalGroup:new{
            align = "center",
            title_bar,
            CenterContainer:new{
                dimen = Geom:new{ w = dialog_w, h = button_table:getSize().h },
                button_table,
            },
        }

        -- Only a dialog that is on screen gets marked dirty. While a picker
        -- has hidden this one, setDirty(dialog, "ui") with no region enqueued
        -- a FULL-SCREEN ui refresh for a widget nobody could see, and merged
        -- with the picker's own close refresh it became a whole-screen flash
        -- on every tap. The re-show that follows a picker repaints anyway.
        if dialog and UIManager:isWidgetShown(dialog) then
            UIManager:setDirty(dialog, "ui")
        end
    end

    -- Build frame shell once; rebuild() will fill frame[1].
    frame = FrameContainer:new{
        radius     = Space.radius.window,
        padding    = 0,
        margin     = 0,
        background = Blitbuffer.COLOR_WHITE,
        VerticalGroup:new{},  -- placeholder; filled by rebuild() below
    }

    -- Populate frame[1] for the first time before show.
    rebuild()

    local bw = opts.bw

    -- Build the dialog shell with MovableContainer + anchor.
    -- The anchor positions the dialog just below the chip strip on first paint
    -- and stays there because rebuild() only swaps frame[1] (the content),
    -- never the MovableContainer.
    dialog = InputContainer:new{}
    if current_bt then current_bt.show_parent = dialog end

    if Device:isTouchDevice() then
        dialog.ges_events = dialog.ges_events or {}
        dialog.ges_events.TapClose = {
            GestureRange:new{
                ges   = "tap",
                range = Geom:new{ x = 0, y = 0, w = sw, h = sh },
            },
        }
    end
    if Device:hasKeys() then
        dialog.key_events = dialog.key_events or {}
        dialog.key_events.Close = { { Device.input.group.Back } }
    end

    -- A tap outside and Back are Close too. Back used to close the window
    -- and nothing else, which kept a half-made new shelf.
    dialog.onTapClose = function(_self_d, _arg, ges_ev)
        if not frame.dimen or ges_ev.pos:notIntersectWith(frame.dimen) then
            finish()
        end
        return true
    end
    dialog.onClose = function()
        finish()
        return true
    end
    dialog.onCloseWidget = function()
        -- Repaint the region under the dialog. setDirty(nil, fn) only
        -- queues an EPDC flush -- it does NOT trigger any widget's
        -- paintTo, so the stale dialog pixels still sit in the buffer
        -- and would be sent to e-ink as a ghost. Passing the
        -- BookshelfWidget below gives UIManager a tree to paint before
        -- the flush. Falls back to a tree-less flush if bw isn't
        -- attached (caller didn't pass opts.bw).
        UIManager:setDirty(bw or nil, function()
            return "ui", frame.dimen
        end)
    end

    -- The same high anchor every picker this editor opens uses: over the hero,
    -- above the shelf menu bar. It opened in the bottom third before, so the
    -- chip strip stayed visible for the Move-left / Move-right chevrons -- but
    -- the strip sits BELOW the hero, so clearing the hero leaves it visible
    -- anyway, and an editor placed somewhere different from the dialogs it
    -- spawns reads as a different kind of thing (maintainer report).
    --
    -- _highAnchor takes its width off the laid-out MovableContainer, so the
    -- container is held here for it to read rather than built inline.
    local movable = MovableContainer:new{
        frame,
        anchor = _highAnchor(function() return dialog end),
    }
    dialog.movable = movable
    dialog[1] = WidgetContainer:new{
        align = "center",
        dimen = Geom:new{ x = 0, y = 0, w = sw, h = sh },
        movable,
    }

    UIManager:show(dialog, function() return "partial", frame.dimen end)

    -- A chip that has just been created has no source the user chose: it holds
    -- the placeholder every new chip starts from. Picking one is the first
    -- thing to do and it is also what names the chip (_applySourceDefaults
    -- renames a label still reading "New shelf"), so the editor would otherwise
    -- open on a chip presenting a Home (folders) source and a generic name as
    -- though they had been decided.
    --
    -- Shown AFTER the editor so the picker sits on top of it: cancelling
    -- returns to the editor rather than to nothing, and the placeholder source
    -- stands as the fallback exactly as it did before.
    if opts.pick_source_first then
        Editor:_pickSource(draft, function()
            -- Backing out of the very first pick of a shelf being created,
            -- with nothing picked, is backing out of creating it.
            if is_new and not hasSource() then
                return discardNew()
            end
            sourceChosen()
        end)
    end
end

-- _pickSource -- full picker. Top-level ButtonDialog choosing a source kind;
-- selecting a kind that needs an id (folder, collection, genre, author) opens
-- a second-level picker populated from real data (KOReader PathChooser,
-- ReadCollection, or the repository's group fetchers).
--
-- NOTE (v1.4): "Specific tag" and "Reading status" kinds are intentionally
-- absent from the kinds list. getTags predicates on ReadCollection tags
-- (distinct from the `tags` built-in) and getBySource "status" predicates on
-- b.read_status, neither of which is produced by buildBookMeta from lfs
-- entries. These sub-options will be restored once those data paths are wired.
-- Tracked: requires follow-up before enabling tag/status custom sources.
-- _openCatalogSettings(draft, on_close) - the per-catalog tuning menu for an
-- OPDS chip: download folder, refresh age, cover loading, page size and
-- timeout. Everything in here is an override of a shelf default chosen for
-- PUBLIC catalogs; see bookshelf_opds_prefs for why each default is what it
-- is, and why these live on the chip rather than on the server.
--
-- Rows read "Thing: current value" to match the Filters / Saves-to cells the
-- editor already uses; the fuller wording is the sub-dialog's title, so the
-- menu stays narrow enough not to wrap on a small screen.
--
-- Every pick hands back through on_close, which saves it (the caller passes
-- commit + rebuild), and the menu reopens on its new value.
function Editor:_openCatalogSettings(draft, on_close)
    local UIManager    = require("ui/uimanager")
    local ButtonDialog = require("ui/widget/buttondialog")
    local Prefs        = require("lib/bookshelf_opds_prefs")
    local d
    -- Re-entry after any sub-pick, so the row under the finger shows its new
    -- value and the user stays in the menu they were working in.
    local function reopen()
        if d then UIManager:close(d) end
        self:_openCatalogSettings(draft, on_close)
    end
    local function row(label, value, on_tap)
        return {{ text = label .. ": " .. value, callback = on_tap }}
    end
    local function optionRow(label, title, field, options)
        return row(label, Prefs.labelFor(options, draft[field]), function()
            self:_pickOpdsOption(draft, field, options, title, function()
                if on_close then on_close() end
                reopen()
            end)
        end)
    end

    local dir = draft.download_dir
    local dir_label = (type(dir) == "string" and dir ~= "")
        and (dir:match("([^/]+)/?$") or dir)
        or _("KOReader folder")

    -- THE START FOLDER, as a row that shows it and clears it.
    --
    -- Setting one is a long-press on the subcatalog itself out on the shelf,
    -- which is where the reader can see what they are choosing; walking a
    -- catalogue inside a settings dialog would be a second, worse browser for
    -- a structure the shelf already browses. What belongs HERE is the two
    -- things the shelf cannot say: what the start folder currently IS, and how
    -- to get back above it -- which is the same clear, reachable without
    -- having to find a row first.
    local start_url   = draft.source and draft.source.feed_url
    local start_label = draft.source and draft.source.feed_label
    local start_row
    if start_url then
        start_row = row(_("Starts at"), start_label or _("a subcatalog"),
            function()
                draft.source.feed_url   = nil
                draft.source.feed_label = nil
                if on_close then on_close() end
                reopen()
            end)
    else
        start_row = {{
            text = _("Starts at: the top of the catalog"),
            -- Nothing to clear and nothing to pick here: the pick is a
            -- long-press on the shelf. Enabled would promise an action.
            enabled = false,
        }}
    end

    d = ButtonDialog:new{
        title       = _("Catalog settings"),
        title_align = "center",
        buttons = {
            start_row,
            row(_("Saves to"), dir_label, function()
                UIManager:close(d)
                d = nil
                self:_pickDownloadDir(draft, function()
                    if on_close then on_close() end
                    reopen()
                end)
            end),
            optionRow(_("Refresh"), _("Refresh this catalog"),
                      "opds_refresh_age", Prefs.REFRESH_OPTIONS),
            {{
                text = _("Close"),
                callback = function()
                    UIManager:close(d)
                    d = nil
                    if on_close then on_close() end
                end,
            }},
        },
    }
    UIManager:show(d)
end

-- _pickFaceRecentCount(draft, on_change, back) -- how many books count as
-- "recently added" on this shelf.
--
-- A short list rather than a nudger: the useful answers are few and the reader
-- is choosing a shelf's LOOK, not calibrating a number. 1 is "just the newest
-- one", which is a real choice on a small shelf; past about 20 the shelf is
-- mostly face-outs and the reader wants "All books" instead.
--
-- `back` reopens the face-out dialog, so this reads as a step inside it rather
-- than a detour that drops the reader somewhere else.
function Editor:_pickFaceRecentCount(draft, on_change, back)
    local SS = require("lib/bookshelf_spine_shelf")
    local Kit = require("lib/bookshelf_module_kit")
    local d
    local cur = SS.faceOutSpec(draft.spine_face_out).recent
                or SS.FACE_RECENT_DEFAULT
    local rows = {}
    rows[#rows + 1] = {{ text = _("How many count as recently added"),
                         enabled = false }}
    local choices = { 1, 3, 5, 10, 20 }
    local line = {}
    for _i, n in ipairs(choices) do
        line[#line + 1] = Kit.radioRow{
            label   = tostring(n),
            active  = (cur == n),
            on_pick = function()
                local spec = SS.faceOutSpec(draft.spine_face_out)
                spec.recent = n
                spec.all = nil
                draft.spine_face_out = spec
                if on_change then on_change() end
                UIManager:close(d)
                if back then back() end
            end,
        }
    end
    rows[#rows + 1] = line
    rows[#rows + 1] = {{
        text = _("Back"),
        callback = function()
            UIManager:close(d)
            if back then back() end
        end,
    }}
    d = ButtonDialog:new{
        title          = _("Recently added"),
        title_align    = "left",
        use_info_style = false,
        buttons        = rows,
        anchor         = _highAnchor(function() return d end),
    }
    UIManager:show(d)
end

-- _pickFaceCollection(draft, on_change, back) -- which collection the "In a
-- collection" face-out reason reads (issue 470). Favourites is left out: it
-- is a reason of its own. Picking one switches the reason on; `back` reopens
-- the face-out dialog.
function Editor:_pickFaceCollection(draft, on_change, back)
    local SS = require("lib/bookshelf_spine_shelf")
    local Kit = require("lib/bookshelf_module_kit")
    local d
    local cur = SS.faceOutSpec(draft.spine_face_out).collection
    local names = {}
    local ok, rc = pcall(require, "readcollection")
    if ok and rc and rc.coll then
        local default_name = rc.default_collection_name
        for name in pairs(rc.coll) do
            if name ~= default_name then names[#names + 1] = name end
        end
    end
    table.sort(names, function(a, b) return a:lower() < b:lower() end)
    local rows = {}
    if #names == 0 then
        rows[#rows + 1] = {{ text = _("No collections yet"), enabled = false }}
    end
    for _i, name in ipairs(names) do
        rows[#rows + 1] = { Kit.radioRow{
            label   = name,
            active  = (cur == name),
            on_pick = function()
                local spec = SS.faceOutSpec(draft.spine_face_out)
                spec.collection = name
                spec.all = nil
                draft.spine_face_out = spec
                if on_change then on_change() end
                UIManager:close(d)
                if back then back() end
            end,
        } }
    end
    rows[#rows + 1] = {{
        text = _("Back"),
        callback = function()
            UIManager:close(d)
            if back then back() end
        end,
    }}
    d = ButtonDialog:new{
        title          = _("In a collection"),
        title_align    = "left",
        use_info_style = false,
        buttons        = rows,
        anchor         = _highAnchor(function() return d end),
    }
    UIManager:show(d)
end

-- _pickGroupDisplay(draft, on_change) - how THIS chip draws its folder and
-- stack tiles.
--
-- The list leads with "Default setting", so following the library default is
-- a choice a chip can be put back to rather than only a state it starts in.
-- Picking a named style pins it, and the chip keeps that look even if the
-- library default changes underneath it later.
-- The list STAYS OPEN and each pick lands on the shelf immediately, matching
-- the library-wide row in the settings menu. A folder style is a look, and a
-- look is chosen by seeing it: the old behaviour closed on the first tap, so
-- comparing two styles meant reopening the picker for each one.
--
-- Re-shown rather than reinit'd between picks. ButtonDialog:reinit unlocks the
-- MovableContainer, after which the dialog eats taps and wedges with no
-- traceback; closing and building a fresh one is a repaint on e-ink and cannot
-- get into that state. The dialog is centred, so it comes back where it was.
-- chrome (optional): { hide, show } for the editor dialog itself. The picker
-- previews a change to folder tiles, and the editor sits squarely over the
-- shelf rows those tiles are on - so it goes away for the duration and comes
-- back when the picker does. Closing it is safe and cheap: its onCloseWidget
-- only repaints the region it occupied (which is what reveals the shelf), and
-- nothing is freed, so the same widget re-shows intact and keeps the position
-- it was anchored to.
function Editor:_pickGroupDisplay(draft, on_change, chrome)
    local Kit = require("lib/bookshelf_module_kit")
    local StackDisplay = require("lib/bookshelf_stack_display")
    local d
    local show
    -- Once, whichever way the picker ends. The editor must never be left
    -- hidden: OK closes it programmatically, but a tap outside or Back goes
    -- through ButtonDialog:onClose instead, and only that path fires
    -- tap_close_callback. Programmatic closes do NOT fire it, which is what
    -- lets the re-show between picks leave the editor hidden.
    local restored = false
    local function restoreChrome()
        if restored then return end
        restored = true
        if chrome and chrome.show then chrome.show() end
    end
    if chrome and chrome.hide then chrome.hide() end
    show = function()
        -- ── TWO SECTIONS, because they are two independent settings ────────
        --
        -- "Show as" pins the chip to a mode (or lets the global settings
        -- decide); "Folder tiles" says how group tiles are drawn IF tiles are
        -- drawn. They were briefly one list, with List sitting among the tile
        -- styles, and the maintainer split them: a chip has to be able to say
        -- "divider cards" without also asserting a mode, and "always a list"
        -- without discarding the tile style it would use if it showed tiles
        -- again.
        --
        -- A header row is a disabled button. ButtonDialog has no section
        -- concept, and unlabelled sections would leave two runs of radio rows
        -- with no way to tell which question each answers.
        local function header(text)
            return {{ text = text, enabled = false }}
        end
        local function radio(label, active, on_pick)
            return Kit.radioRow{ label = label, active = active,
                                 on_pick = on_pick }
        end
        -- Every pick re-shows: the shelf updates first (the reader is looking
        -- at it), then the dialog, which is one repaint instead of two.
        local function pick(apply)
            return function()
                apply()
                if on_change then on_change() end
                UIManager:close(d)
                show()
            end
        end

        local rows = {}

        -- ── COMPACT, ON A RULING ───────────────────────────────────────────
        --
        -- "The shelf style dialog needs reducing in size so you can actually
        --  see the effects on the shelf you are styling. Do we need a
        --  'default' setting for any of these? can we use single row nudge
        --  style buttons for rows?"
        --
        -- So: one row per question. The radio grids for columns, rows and
        -- folder tiles -- eleven rows of dialog between them -- are now two
        -- nudge rows and a cycle row, and every tap still live-previews on
        -- the shelf behind, which is the whole point of shrinking this.
        --
        -- WHERE "DEFAULT" SURVIVES, and where it does not:
        --   * "Show as" keeps its Default radio. It is the only place "follow
        --     the library's list-mode rules" can be said, and those globals
        --     still exist.
        --   * Folder tiles keeps it as a CYCLE STOP -- "Default setting" is
        --     one of the values the row steps through, because a global
        --     folder style exists to follow.
        --   * Columns and rows have no Default row. Nudging below the minimum
        --     lands on "Auto" instead, so the way back to automatic still
        --     exists but costs no dialog height.

        -- Theme: first, above Show as: the theme sits behind the layout
        -- style (maintainer, 2026-10-09). The shelf's own, in the Theme
        -- library, the one picker the
        -- Theme menu's This shelf and shelf rows open too
        -- (maintainer, 2026-10-07: readers who think "this shelf" start
        -- here). A sub-shelf too (Reddit, after 5.4; it wore its shelf of
        -- shelves' theme only, ruling 2026-10-05): with none of its own it
        -- reads "Theme: Same as Fiction" (TP.followOf). A pick is saved and
        -- shown on the shelf behind (on_change); this dialog comes back, its
        -- row updated, when the picker closes.
        -- Following the default reads "Theme: Default theme", as its row in
        -- the Theme menu does; never "library", the Theme library's own
        -- name, nor a bare "Default" (maintainer, 2026-10-09).
        do
            local TP = require("lib/bookshelf_theme_pack")
            local function cur() return draft.theme end
            local follow = draft.parent ~= nil and TP.followOf(draft.id) or nil
            rows[#rows + 1] = {{
                text_func = function()
                    local v = cur()
                    if v == nil and follow then return T(_("Theme: %1"), follow.title) end
                    return T(_("Theme: %1"), TP.choiceLabel(v))
                end,
                callback = function()
                    UIManager:close(d)
                    require("lib/bookshelf_theme_library").show{
                        shelf = draft.label or "",
                        current = cur,
                        follow = follow,
                        choose = function(value) draft.theme = value end,
                        apply = function() on_change(true) end,
                        on_closed = show,
                    }
                end,
            }}
        end
        -- Show as: Auto / List / Covers, three across. COVERS is the default
        -- (unset), so a chip that has never seen this picker looks exactly as
        -- it did before list view existed; Auto is now an explicit choice
        -- stored on the chip. Its policy is unchanged -- covers collapsed, a
        -- list when the shelf is expanded or inside folders and stacks
        -- (lib/bookshelf_view_mode.lua).
        local mode = ViewMode.chipOverride(draft[ViewMode.CHIP_KEY])
        -- A shelf of shelves is never drilled into (opening a sub-shelf
        -- switches to it), so Auto's levels would be one level: the same as
        -- choosing that style. It is not offered there (maintainer,
        -- 2026-10-11), and one stored before shows as the style it gives.
        local is_shelves = TabModel.isShelves(draft)
        if is_shelves and mode == ViewMode.AUTO then
            mode = ViewMode.auto(draft, false)
            if mode == ViewMode.COVERS then mode = nil end
        end
        rows[#rows + 1] = header(_("Show as"))
        -- Appended, not listed with `cond and x or nil`: a nil FIRST entry
        -- ends ipairs there, and the whole row would vanish.
        local show_row = {}
        if not is_shelves then
            show_row[#show_row + 1] = radio(_("Auto"), mode == ViewMode.AUTO, pick(function()
                draft[ViewMode.CHIP_KEY] = ViewMode.AUTO
            end))
        end
        for _i, b in ipairs({
            -- Covers leads the three styles, on a maintainer ruling: it is
            -- the default, so it is what most chips are showing. Auto keeps
            -- the front because it is not a style at all -- it is the choice
            -- to let the shelf decide between the two that follow.
            --
            -- Covers stores absence: it IS the default, and the summary rows
            -- fall through to the tile style rather than restating it.
            radio(_("Covers"), mode == ViewMode.COVERS or mode == nil,
            pick(function()
                draft[ViewMode.CHIP_KEY] = nil
            end)),
            radio(_("List"), mode == ViewMode.LIST, pick(function()
                draft[ViewMode.CHIP_KEY] = ViewMode.LIST
            end)),
            -- Spines: books edge-on, a real bookcase. A pin, or a level's
            -- choice under Auto (5.4.3), never Auto's default. Not
            -- offered for OPDS catalogues -- remote records have nothing for
            -- the style to stand on, and the widget degrades a stored pin to
            -- covers there.
            (not (chrome and chrome.is_opds)) and
            radio(_("Spines"), mode == ViewMode.SPINES, pick(function()
                draft[ViewMode.CHIP_KEY] = ViewMode.SPINES
            end)) or nil,
        }) do show_row[#show_row + 1] = b end
        rows[#rows + 1] = show_row

        -- Which density rows to offer. LIST numbers only: cover columns are
        -- deliberately absent -- "column numbers for cover view cannot be per
        -- chip as it changes the layout of the whole screen (hero size and
        -- chip bar position)". They stay global, in the main menu's
        -- Columns/Rows editor and under the cover grid's own pinch. List
        -- columns and rows divide nothing but the shelf band, which is what
        -- makes them safe to vary per chip.
        --
        -- chipPin, not `mode`: Covers is stored as ABSENCE, so mode is nil for
        -- a Covers chip and every `mode ~= COVERS` test silently passed. That
        -- is how a Covers chip came to be offered List columns and List rows,
        -- controls for a view it is pinned away from. These three lines were
        -- written when nil meant Auto and were not revisited when the default
        -- flipped (cf885a1); the radios above were.
        local pin = ViewMode.chipPin(mode)
        local no_spines  = (chrome and chrome.is_opds) and true or false
        -- The styles this shelf can show: its pin, or under Auto each level's
        -- (ViewMode.auto). The density rows below follow them, so Auto set to
        -- List then Covers offers list rows and folder tiles, and no spine rows.
        local shows = {}
        if pin == ViewMode.AUTO then
            shows[ViewMode.auto(draft, false)] = true
            shows[ViewMode.auto(draft, true)] = true
        else
            shows[pin] = true
        end
        local show_covers = shows[ViewMode.COVERS] == true
        local show_list   = shows[ViewMode.LIST] == true
        local show_spines = shows[ViewMode.SPINES] == true and not no_spines
        -- Auto's levels, as buttons in the place of the note that used to
        -- explain its fixed policy (maintainer, 2026-10-11).
        local show_levels = (pin == ViewMode.AUTO)
        local bw = chrome and chrome.bw

        -- nudgeRow: [-]  Label: value  [+], writing draft[key].
        --
        -- Nil is "Auto" -- the automatic count -- and the first nudge seeds
        -- from `live()`, the number actually on screen, so + from Auto shows
        -- one more of what the reader is looking at rather than jumping to a
        -- constant. Nudging below `lo` returns to Auto, which is the whole of
        -- the way back and costs no dialog row.
        -- inherit_key: an unset value shows this key's instead (Level 2's list
        -- numbers show Level 1's, which is what the shelf then uses).
        local function nudgeRow(label, key, lo, hi, live, inherit_key)
            local function shown()
                local v = draft[key]
                if v == nil and inherit_key then v = draft[inherit_key] end
                return label .. ": " .. (v and tostring(v) or _("Auto"))
            end
            local function step(delta)
                return pick(function()
                    local cur = draft[key]
                    if not cur then
                        local base = live and live() or lo
                        draft[key] = math.max(lo, math.min(hi, base + delta))
                    else
                        local n = cur + delta
                        if n < lo then draft[key] = nil
                        else draft[key] = math.min(hi, n) end
                    end
                end)
            end
            return {
                { text = "\u{2212}", callback = step(-1) },
                { text_func = shown, enabled = false },
                { text = "+", callback = step(1) },
            }
        end

        -- TWO rows, not one sentence. A Button shrinks its font and falls
        -- back to a two-line TextBoxWidget when text will not fit, but it
        -- squeezes those two lines into ONE button's height and ellipsises
        -- past that -- which at a large DPI is how this note would arrive.
        -- Two standalone sentences cannot truncate, and each stands alone for
        -- a translator rather than being half of one split mid-clause.
        -- Auto's levels: "Level 1: Covers" | "Level 2: List", each tap the
        -- next style (covers, list, spines; no spines for a catalogue), as
        -- the sort levels' buttons step through their keys. Level 1 is the
        -- shelf's top level, collapsed or expanded; Level 2 everything drilled
        -- into below it. A level on its default stores nothing.
        if show_levels then
            local function levelBtn(level)
                local key = ViewMode.LEVEL_KEYS[level]
                local fmt = (level == 1) and _("Level 1: %1") or _("Level 2: %1")
                return {
                    text_func = function()
                        return T(fmt, Editor._chipModeLabel(ViewMode.levelMode(draft[key], level)))
                    end,
                    callback = pick(function()
                        local nxt = ViewMode.nextLevelMode(draft[key], level, no_spines)
                        if nxt == ViewMode.LEVEL_DEFAULTS[level] then draft[key] = nil
                        else draft[key] = nxt end
                    end),
                }
            end
            rows[#rows + 1] = { levelBtn(1), levelBtn(2) }
        end

        if show_list then
            -- Auto listing on BOTH levels: a set per level, under headings
            -- (ViewMode.listLevelsSplit). Level 2's keys carry the suffix and,
            -- until set, show Level 1's numbers, which are what they follow. A
            -- "Same as Level 1" label did not fit the button at PW5 size.
            local split = ViewMode.listLevelsSplit(draft)
            local function listRows(sfx, inherit)
                rows[#rows + 1] = nudgeRow(_("List columns"), "list_columns" .. sfx, 1, 3,
                    bw and function() return bw:_listCols() end,
                    inherit and "list_columns" or nil)
                rows[#rows + 1] = nudgeRow(_("List rows"), "list_rows" .. sfx, 1, 12,
                    bw and function()
                        local ok, plan = pcall(bw._listBandPlan, bw, false,
                                               bw._chip_bar_hidden)
                        return ok and plan and plan.rows or 4
                    end, inherit and "list_rows" or nil)
            end
            if split then
                rows[#rows + 1] = header(_("Level 1"))
                listRows("")
                rows[#rows + 1] = header(_("Level 2"))
                listRows(ViewMode.LEVEL2_SUFFIX, true)
            else
                listRows("")
            end
        end

        if show_spines then
            local Binding = require("lib/bookshelf_book_binding")
            rows[#rows + 1] = {{
                text_func = function()
                    return T(_("Book binding: %1"), Binding.label(draft.book_binding))
                end,
                callback = pick(function()
                    if draft.book_binding == "paperback" then draft.book_binding = nil
                    else draft.book_binding = "paperback" end
                end),
            }, {
                text_func = function()
                    return T(_("Series boxes: %1"), draft.series_boxes and _("On") or _("Off"))
                end,
                callback = pick(function()
                    draft.series_boxes = not draft.series_boxes or nil
                end),
            }}
            -- The spine view's own density. Rows like the list's; height as
            -- a percentage of the row so a single-shelf chip can pull the
            -- books down to a size whose titles stay readable.
            rows[#rows + 1] = nudgeRow(_("Spine rows"), "spine_rows", 1, 6,
                bw and function()
                    local ok, n = pcall(bw._nShelves, bw)
                    return ok and n or 2
                end)
            -- Percent rows step by 10 and treat auto_value as the stored
            -- absence (nil = "follow the default"), so both settings keep
            -- the dialog's nil-means-default semantics.
            local function pctRow(label, key, lo, hi, auto_value)
                local step_sz = 10
                local function shown()
                    local v = draft[key]
                    return label .. ": "
                           .. (v and (tostring(v) .. "%") or _("Auto"))
                end
                local function step(delta)
                    return pick(function()
                        local cur = draft[key] or auto_value
                        local n = cur + delta * step_sz
                        if n > hi then n = hi end
                        if n < lo then n = lo end
                        if n == auto_value then draft[key] = nil
                        else draft[key] = n end
                    end)
                end
                return {
                    { text = "\u{2212}", callback = step(-1) },
                    { text_func = shown, enabled = false },
                    { text = "+", callback = step(1) },
                }
            end
            -- Spine thickness: a multiplier on the page-count width.
            -- (No height row: book height IS rows over available space,
            -- with the hero pinned to the cover grid's standard size.)
            rows[#rows + 1] = pctRow(_("Spine thickness"), "spine_thickness_pct",
                                     60, 200, 100)
            -- Face out (front cover, bookstore style): WHICH books stand
            -- cover-forward. Several values, so a submenu rather than a
            -- cycling button (user ruling). Stored back-compatibly: nil =
            -- favourites (the default the old Yes toggle meant), false =
            -- none (the old No), else the mode string.
            local FACE_LABELS = {
                none      = _("None"),
                favorites = _("Favorites"),
                first     = _("First in series"),
                first_unread = _("First unread in series"),
                -- "Reading", as the book's long-press menu says it: the four
                -- reading states share one row, where "Currently reading"
                -- did not fit.
                reading   = _("Reading"),
                finished  = _("Finished"),
                on_hold   = _("On hold"),
                unread    = _("Unread"),
                standalone = _("Unread standalone"),
                collection = _("In a collection"),
                all       = _("All books"),
            }
            -- The row reads out the SET, not one mode: "Favorites + Reading".
            -- Three or more and it says how many instead, because the row has
            -- to share a line with the rest of the editor.
            local SS = require("lib/bookshelf_spine_shelf")
            local function faceOutSpec()
                return SS.faceOutSpec(draft.spine_face_out)
            end
            local function faceOutShown()
                local spec = faceOutSpec()
                if spec.all then return _("Face out") .. ": " .. FACE_LABELS.all end
                if SS.faceOutEmpty(spec) then
                    return _("Face out") .. ": " .. FACE_LABELS.none
                end
                local parts = {}
                for _i, k in ipairs(SS.FACE_REASONS) do
                    if k == "recent" then
                        if spec.recent then
                            parts[#parts + 1] = T(_("Newest %1"), spec.recent)
                        end
                    elseif k == "collection" then
                        if spec.collection then parts[#parts + 1] = spec.collection end
                    elseif spec[k] then
                        parts[#parts + 1] = FACE_LABELS[k]
                    end
                end
                if #parts > 2 then
                    return T(_("Face out: %1 reasons"), #parts)
                end
                return _("Face out") .. ": " .. table.concat(parts, " + ")
            end
            -- Writes the set back in the SIMPLEST shape that carries it, so a
            -- shelf using one reason still stores the string it always did and
            -- an untouched setting never grows a table in the config.
            local function faceOutSave(spec)
                if spec.all then draft.spine_face_out = "all"; return end
                local n, only = 0, nil
                for _i, k in ipairs(SS.FACE_REASONS) do
                    if spec[k] then n = n + 1; only = k end
                end
                if n == 0 then draft.spine_face_out = false
                elseif n == 1 and only ~= "recent" and only ~= "collection" then
                    draft.spine_face_out = (only == "favorites") and nil or only
                else
                    draft.spine_face_out = spec
                end
            end
            rows[#rows + 1] = {{
                text_func = faceOutShown,
                callback = function()
                    UIManager:close(d)
                    -- A picker that stays open and REDRAWS ITSELF IN PLACE. It
                    -- used to close and reopen after every toggle; KOReader's
                    -- ButtonDialog asks for a flashui of its own rectangle on
                    -- close, and merged with the shelf's refresh that was a
                    -- full-screen flash per tap. Now every button has an id, a
                    -- tap rewrites the labels through getButtonById/setText and
                    -- repaints the dialog's own rectangle with a plain ui
                    -- refresh. The shape is fixed so a label always has a
                    -- button to land in: two reasons per row, the recent-count
                    -- button present but disabled while Recent is off, All and
                    -- None as a pair, Back. The shelf underneath follows on
                    -- the editor's own deferred rebuild (on_change, a commit).
                    local sub
                    local showFace
                    local TICK, BLANK = "\xE2\x9C\x93 ", "\xE2\x80\x83 "
                    local function isOn(spec, k)
                        if k == "recent" then return spec.recent ~= nil end
                        if k == "collection" then return spec.collection ~= nil end
                        return spec[k] == true
                    end
                    local function recentLabel(spec)
                        return T(_("Recently added (%1)"), spec.recent or SS.FACE_RECENT_DEFAULT)
                    end
                    local function countLabel(spec)
                        return T(_("How many: %1"), spec.recent or SS.FACE_RECENT_DEFAULT)
                    end
                    local function whichLabel(spec)
                        if spec.collection then
                            -- Deleted or renamed since: say so, rather than
                            -- a tick on a shelf that faces nothing out.
                            local ok_rc, rc = pcall(require, "readcollection")
                            if ok_rc and rc and rc.coll and rc.coll[spec.collection] == nil then
                                return T(_("Collection: %1 (not found)"), spec.collection)
                            end
                            return T(_("Collection: %1"), spec.collection)
                        end
                        return _("Choose collection")
                    end
                    local function label(spec, k)
                        local text = (k == "recent") and recentLabel(spec) or FACE_LABELS[k]
                        return (isOn(spec, k) and TICK or BLANK) .. text
                    end
                    local function allLabel(spec)
                        return (spec.all and TICK or BLANK) .. FACE_LABELS.all
                    end
                    local function noneLabel(spec)
                        local none = (not spec.all) and SS.faceOutEmpty(spec)
                        return (none and TICK or BLANK) .. FACE_LABELS.none
                    end
                    -- Rewrite every label from the draft and repaint the picker
                    -- only. setText keeps a button's geometry when the width it
                    -- is handed matches its own, which is what keeps the table
                    -- still under the reader's finger.
                    local function refreshLabels()
                        if not sub then return end
                        local spec = faceOutSpec()
                        local function set(id, text)
                            local btn = sub:getButtonById(id)
                            if btn then btn:setText(text, btn.width) end
                            return btn
                        end
                        for _i, k in ipairs(SS.FACE_REASONS) do
                            set("face_" .. k, label(spec, k))
                        end
                        set("face_all",  allLabel(spec))
                        set("face_none", noneLabel(spec))
                        local count = set("face_count", countLabel(spec))
                        if count then
                            if spec.recent then count:enable() else count:disable() end
                        end
                        set("face_which", whichLabel(spec))
                        UIManager:setDirty(sub, function() return "ui", sub.movable.dimen end)
                    end
                    local function changed()
                        if on_change then on_change() end
                        refreshLabels()
                    end
                    -- TOGGLES. A book can be a favourite AND newly added, so
                    -- each row flips one reason and the set builds up.
                    local pickCollection
                    local function toggle(k)
                        return {
                            id   = "face_" .. k,
                            text = label(faceOutSpec(), k),
                            callback = function()
                                local nspec = faceOutSpec()
                                -- Switching the collection reason ON needs a
                                -- name, so it asks for one first.
                                if k == "collection" and not nspec.collection then
                                    pickCollection()
                                    return
                                end
                                nspec.all = nil     -- a reason un-picks "All"
                                if k == "recent" then
                                    nspec.recent = (nspec.recent == nil)
                                        and SS.FACE_RECENT_DEFAULT or nil
                                elseif k == "collection" then
                                    nspec.collection = nil
                                else
                                    nspec[k] = (not nspec[k]) or nil
                                end
                                faceOutSave(nspec)
                                changed()
                            end,
                        }
                    end
                    showFace = function()
                        local spec = faceOutSpec()
                        local sub_rows = {
                            -- Ordered by how a reader thinks about the shelf
                            -- rather than by when each reason was added.
                            -- READING STATE first, the pair most people answer
                            -- with; then the two SERIES reasons together,
                            -- because "first in series" and "first unread in
                            -- series" are the same question asked of a
                            -- shelf you have started or one you have not.
                            -- All four reading states on one row, in the order
                            -- the book's long-press menu sets them (On hold and
                            -- Finished joined in 5.4.4).
                            { toggle("unread"), toggle("reading"), toggle("on_hold"), toggle("finished") },
                            { toggle("standalone"), toggle("favorites") },
                            { toggle("first"),  toggle("first_unread") },
                            -- How many count as "recently added", as a button
                            -- the reader can see: a 20-book shelf and a
                            -- 2000-book one want different answers.
                            { toggle("recent"),
                              { id = "face_count", text = countLabel(spec),
                                enabled = spec.recent ~= nil,
                                callback = function()
                                    UIManager:close(sub)
                                    self:_pickFaceRecentCount(draft, function()
                                        if on_change then on_change() end
                                    end, showFace)
                                end } },
                            -- A collection the reader picks (a To read list,
                            -- say), with the button that changes which one.
                            { toggle("collection"),
                              { id = "face_which", text = whichLabel(spec),
                                callback = function() pickCollection() end } },
                            -- The two that are not reasons but answers on
                            -- their own: the bottom row is where the
                            -- whole-shelf answers live.
                            { { id = "face_all", text = allLabel(spec),
                                callback = function()
                                    draft.spine_face_out = "all"
                                    changed()
                                end },
                              { id = "face_none", text = noneLabel(spec),
                                callback = function()
                                    draft.spine_face_out = false
                                    changed()
                                end } },
                            -- Back, not Cancel: every tick is already saved.
                            -- Back to Shelf style, which this was opened from.
                            { { text = _("Back"),
                                callback = function()
                                    UIManager:close(sub)
                                    show()
                                end } },
                        }
                        sub = ButtonDialog:new{
                            title          = _("Face out"),
                            title_align    = "left",
                            use_info_style = false,
                            _added_widgets = { _helpParagraph(_(
                                "Ticked books stand face out. Tick as many reasons as you like.")) },
                            buttons        = sub_rows,
                            -- Same placement as its parent: this is the one
                            -- pick in the group that redraws the shelf under it.
                            anchor         = _highAnchor(function() return sub end),
                        }
                        UIManager:show(sub)
                    end
                    pickCollection = function()
                        UIManager:close(sub)
                        self:_pickFaceCollection(draft, function()
                            if on_change then on_change() end
                        end, showFace)
                    end
                    showFace()
                end,
            }}
            -- Author on the spine, and ornaments beside it: two switches
            -- that only a spine shelf has, paired on one row to keep the
            -- dialog short enough to still see the shelf behind it.
            --
            -- A tick rather than "Yes/No" (maintainer), which is the mark the
            -- Face out picker already uses, so "this is on" reads the same way
            -- in both places. Stored as false only, nil meaning the default,
            -- the same absence semantics as every other key here.
            local TICK, BLANK = "\xE2\x9C\x93 ", "\xE2\x80\x83 "
            local function authorOn()
                local v = draft.spine_show_author
                if v == nil then return true end
                return v and true or false
            end
            -- Ornaments, here rather than in the library settings: they only
            -- ever appear on a spine shelf, so this is the one screen where
            -- the control is relevant, and a reader may well want a crowded
            -- shelf on one chip and a bare one on another (maintainer).
            --
            -- FOUR stops, and the values are picked for what they LOOK like
            -- rather than for a tidy sequence. pick() multiplies the base odds
            -- by the level and skips the roll altogether once the product
            -- reaches 1, so the old Often (2) and Lots (3) BOTH filled every
            -- eligible gap and were the same picture on a plain shelf -- which
            -- is what the maintainer reported ("I am not sure I can tell any
            -- difference between often and lots"). Measured over 20k seeds:
            --
            --     stop      plain gap   section break   reserved row ends
            --     Rarely       25%           4%          not reserved
            --     Often        50%           8%          not reserved
            --     Always      100%          16%               56%
            --
            -- Always is the top of the dial, not a promise about every
            -- channel. Section breaks stay rare on purpose: they are far more
            -- numerous than row ends, and equal odds would put a plant between
            -- every other series. Some reserved row ends stay bookless by
            -- design too ("allow some rows even on the top setting to be
            -- occasionally filled with books").
            --
            -- No "Default" stop: on a dial this short a value the reader
            -- cannot see is a trap. A chip that has never been touched still
            -- STORES nothing, and shows the word its default resolves to.
            -- Required here, not at the top: the ornament module pulls in a
            -- KOReader widget, and this file is loaded in places that have
            -- none. By the time a spine chip's dialog is built it is loaded
            -- anyway, and require() caches.
            local Orn = require("lib/bookshelf_ornaments")
            local ORN_STOPS = {
                { value = 0,   label = function() return _("None") end },
                { value = 0.5, label = function() return _("Rarely") end },
                { value = 1,   label = function() return _("Often") end },
                { value = 2,   label = function() return _("Always") end },
            }
            -- Nearest stop rather than an exact match, so an unpinned chip
            -- lands on its default's word and a value written by an older
            -- build cannot fall off the end of the list.
            local function ornAt()
                local v = draft.ornament_frequency
                if v == nil then v = Orn.FREQ_DEFAULT end
                local best, dist = 1, math.huge
                for i, stop in ipairs(ORN_STOPS) do
                    local d = math.abs(stop.value - v)
                    if d < dist then best, dist = i, d end
                end
                return best
            end
            rows[#rows + 1] = {
                { text_func = function()
                      return (authorOn() and TICK or BLANK) .. _("Author on spine")
                  end,
                  callback = pick(function()
                      -- NOT `authorOn() and false or nil`: in Lua that can
                      -- never produce false, because `false or nil` is nil.
                      -- So every tap wrote nil, the tick came back from the
                      -- default, and the row could not be turned off at all
                      -- once it was on (#439).
                      if authorOn() then
                          draft.spine_show_author = false   -- pinned off
                      else
                          draft.spine_show_author = nil     -- follow the default
                      end
                  end) },
                { text_func = function()
                      return _("Ornaments") .. ": " .. ORN_STOPS[ornAt()].label()
                  end,
                  callback = pick(function()
                      draft.ornament_frequency = ORN_STOPS[(ornAt() % #ORN_STOPS) + 1].value
                  end) },
            }
        end

        -- Folder tiles: ONE row that cycles through the styles, live-previewed
        -- on the shelf each tap -- the same cycling the line editor's style
        -- button uses, and for the same reason: the values are few, ordered,
        -- and the preview beside the control says more than a grid of radios.
        --
        -- Hidden for a catalogue (an OPDS subcatalog has no artwork of its
        -- own, so every style renders the same text tile) and hidden on a
        -- chip pinned to List -- "folder tiles option has no purpose in the
        -- list style menu": a list's group rows draw a deck of member covers,
        -- not these cards.
        -- Book text (below) shares this row (maintainer on the PW5,
        -- 2026-10-10): both are how the covers are drawn.
        local tiles_row
        if not (chrome and chrome.is_opds) and show_covers then
            tiles_row = {{
                text_func = function()
                    local cur = StackDisplay.pinned(draft.group_display)
                                or StackDisplay.FOLLOW_DEFAULT
                    for _i, opt in ipairs(StackDisplay.CHIP_OPTIONS) do
                        if opt.value == cur then
                            return _("Folder tiles: ") .. opt.label_func()
                        end
                    end
                    return _("Folder tiles")
                end,
                callback = pick(function()
                    local cur = StackDisplay.pinned(draft.group_display)
                                or StackDisplay.FOLLOW_DEFAULT
                    local opts_list = StackDisplay.CHIP_OPTIONS
                    for i, opt in ipairs(opts_list) do
                        if opt.value == cur then
                            local nxt = opts_list[i % #opts_list + 1]
                            draft.group_display = nxt.value
                            return
                        end
                    end
                    draft.group_display = opts_list[1].value
                end),
            }}
            rows[#rows + 1] = tiles_row
        end
        -- Text below covers, this shelf's own (Reddit, after 5.4: "I only
        -- want the series name in a shelf that lists my series"). Opens a
        -- short picker, since Custom opens the line editor and a cycle stop
        -- cannot. Unset follows Cover display's choice, or a sub-shelf's
        -- shelf of shelves' (CoverLabel.modeFor), and reads "Default" or
        -- "Same as Fiction" accordingly. Covers only: a list or spine shelf
        -- has no label strip. Text below GROUPS stays library-wide: the only
        -- group text with anything to print is a series stack's author.
        if show_covers then
            local text_row = self:_coverTextRow(draft, function()
                if on_change then on_change() end
            end, function() UIManager:close(d) end, show, bw)
            if tiles_row then
                tiles_row[#tiles_row + 1] = text_row[1]
            else
                rows[#rows + 1] = text_row
            end
        end
        -- Close: every pick has already been applied and saved, so there is
        -- nothing to confirm. It was OK while the editor's own Save did the
        -- saving; the maintainer wanted every change applied on selection.
        rows[#rows + 1] = {{
            text = _("Close"),
            callback = function()
                UIManager:close(d)
                restoreChrome()
            end,
        }}
        d = ButtonDialog:new{
            title       = _("Shelf style"),
            title_align = "center",
            buttons     = rows,
            -- HIGH, over the hero rather than the shelf: the dialog exists
            -- to show a change to folder tiles, so covering them defeats it.
            anchor      = _highAnchor(function() return d end),
            tap_close_callback = restoreChrome,
        }
        UIManager:show(d)
    end
    show()
end

-- _coverTextRow(draft, on_change, close, reshow, bw) -> Shelf style's
-- "Cover captions: Title" button, opening its picker (_pickCoverText).
-- `close` takes Shelf style down, `reshow` brings it back.
function Editor:_coverTextRow(draft, on_change, close, reshow, bw)
    return {{
        text_func = function()
            return T(_("Cover captions: %1"), Editor._coverTextLabel(draft, draft.cover_text))
        end,
        callback = function()
            close()
            Editor:_pickCoverText(draft, on_change, reshow, bw)
        end,
    }}
end

-- The choices, laid out as a grid rather than a column of one per row (on
-- the PW5 the column was seven rows for one question, maintainer
-- 2026-10-10): what it follows and None, the line's contents, then Custom.
-- "follow" is unset.
local COVER_TEXT_LAYOUT = { { "follow", "none" }, { "title", "author", "series" }, { "custom" } }

-- _coverTextLabel(draft, value) -> how a choice reads: its name, or for
-- unset what it follows, "Default" (Cover display's) or "Same as Fiction"
-- (a sub-shelf's shelf of shelves).
function Editor._coverTextLabel(draft, value)
    if value == "title"  then return _("Title") end
    if value == "author" then return _("Author") end
    if value == "series" then return _("Series") end
    if value == "custom" then return _("Custom") end
    if value == "none"   then return _("None") end
    if draft.parent ~= nil then
        local parent = TabModel.getById(draft.parent)
        return T(_("Same as %1"), (parent and parent.label) or draft.parent)
    end
    return _("Default")
end

-- _pickCoverText(draft, on_change, back, bw): the shelf's own text below
-- covers. A pick is written to the draft, shown on the shelf, and hands back
-- to Shelf style: one question, one answer, and no close-and-reopen of this
-- picker per tap, which flashes the whole screen on a Kindle (see the Face
-- out picker). Custom... opens the line editor on the shelf's own line
-- (CoverLabelEditor.showForShelf), and its Save is what makes Custom the
-- choice, as in Cover display. Back returns unchanged.
function Editor:_pickCoverText(draft, on_change, back, bw)
    local CL = require("lib/bookshelf_cover_label")
    local Kit = require("lib/bookshelf_module_kit")
    local d
    local function set(v)
        return function()
            draft.cover_text = v
            on_change()
            UIManager:close(d)
            back()
        end
    end
    local cur = draft.cover_text
    local function customBtn()
        return {
            text = (cur == "custom" and "\xE2\x9C\x93 " or "") .. _("Custom\xE2\x80\xA6"),
            callback = function()
                UIManager:close(d)
                -- Starts from the shelf's own line, else the one it shows
                -- now, so Custom changes nothing until it is edited.
                require("lib/bookshelf_cover_label_editor").showForShelf(bw, {
                    line = draft.cover_text_line or CL.lineFor(draft.id),
                    save = function(l)
                        draft.cover_text_line = CL.normalise(l)
                        draft.cover_text = "custom"
                        on_change()
                    end,
                    on_closed = back,
                })
            end,
        }
    end
    local rows = {}
    for _i, layout_row in ipairs(COVER_TEXT_LAYOUT) do
        local row = {}
        for _j, v in ipairs(layout_row) do
            if v == "custom" then
                row[#row + 1] = customBtn()
            else
                local value = (v ~= "follow") and v or nil
                row[#row + 1] = Kit.radioRow{ label = Editor._coverTextLabel(draft, value),
                                              active = cur == value, on_pick = set(value) }
            end
        end
        rows[#rows + 1] = row
    end
    rows[#rows + 1] = {{
        text = _("Back"),
        callback = function()
            UIManager:close(d)
            back()
        end,
    }}
    d = ButtonDialog:new{
        title       = _("Cover captions"),
        title_align = "center",
        buttons     = rows,
        anchor      = _highAnchor(function() return d end),
        tap_close_callback = back,
    }
    UIManager:show(d)
end

-- _pickOpdsOption(draft, field, options, title, on_close) - one radio list for
-- one setting. The option's VALUE is written to the draft, never its index:
-- inserting or reordering an option must not change what existing chips do.
--
-- The default option carries no value at all (Lua stores no key for
-- `{ value = nil }`), so picking it clears the field back to unset rather than
-- writing a "default" marker that a later build would have to keep honouring.
function Editor._boGroupSection(source)
    if not (source and source.kind == "bookorbit" and source.id) then return nil end
    local ok, BOSource = pcall(require, "lib/bookshelf_bookorbit_source")
    if not (ok and BOSource and BOSource.isGroupRoot and BOSource.isGroupRoot(source.id)) then
        return nil
    end
    local sec = BOSource.groupSection(source.id)
    if sec == "authors" or sec == "series" then return sec end
    return nil
end

-- Labels and option lists for the BookOrbit Authors / Series sort and filter.
-- sort[...] / filter[...] map a stored value ("name", "name_desc", "books" /
-- "all", "reading", "finished") to its label; "name" and "all" are the
-- defaults (stored as nil). *_options lead with the default.
function Editor._boOptionLabels(section)
    local filter_names
    if section == "authors" then
        filter_names = { all = _("Everyone"), reading = _("Reading now"), finished = _("Read") }
    elseif section == "series" then
        filter_names = { all = _("All series"), reading = _("In progress"), finished = _("Finished") }
    else
        return nil
    end
    local sort_names = {
        name = _("Name A-Z"), name_desc = _("Name Z-A"), books = _("Most books"),
    }
    local function opts(names, order)
        local out = {}
        for i, k in ipairs(order) do
            local label = names[k]
            out[i] = {
                value = (i > 1) and k or nil,
                label_func = function() return label end,
                key = k,
            }
        end
        return out
    end
    return {
        sort = sort_names, filter = filter_names,
        sort_options = opts(sort_names, { "name", "name_desc", "books" }),
        filter_options = opts(filter_names, { "all", "reading", "finished" }),
    }
end

-- _pickBookOrbitOption(draft, field, options, title, on_close) - radio list
-- writing draft.source[field]; the default option clears the key (nil).
function Editor:_pickBookOrbitOption(draft, field, options, title, on_close)
    local UIManager    = require("ui/uimanager")
    local ButtonDialog = require("ui/widget/buttondialog")
    local Kit          = require("lib/bookshelf_module_kit")
    local d
    local rows = {}
    local current = draft.source and draft.source[field]
    for _i, opt in ipairs(options) do
        rows[#rows + 1] = {Kit.radioRow{
            label  = opt.label_func(),
            active = current == opt.value,
            on_pick = function()
                if draft.source then draft.source[field] = opt.value end
                UIManager:close(d)
                if on_close then on_close() end
            end,
        }}
    end
    rows[#rows + 1] = {{
        text = _("Cancel"),
        callback = function()
            UIManager:close(d)
            if on_close then on_close() end
        end,
    }}
    d = ButtonDialog:new{ title = title, title_align = "center", buttons = rows }
    UIManager:show(d)
end

function Editor:_pickOpdsOption(draft, field, options, title, on_close)
    local UIManager    = require("ui/uimanager")
    local ButtonDialog = require("ui/widget/buttondialog")
    local Kit          = require("lib/bookshelf_module_kit")
    local d
    local rows = {}
    -- Tick what the chip DOES, not what it has stored. An untouched chip has
    -- no value in this field, nothing equals nil, and the list opened with no
    -- row ticked at all - reading as "no setting" over a catalog that is very
    -- much doing something. options[1] is the default by construction: every
    -- option list here leads with it, labelFor already renders an unset chip
    -- as options[1], and bookshelf_opds_prefs has a test holding that.
    local current = draft[field]
    if current == nil and options[1] then current = options[1].value end
    for _i, opt in ipairs(options) do
        rows[#rows + 1] = {Kit.radioRow{
            label  = opt.label_func(),
            active = current == opt.value,
            on_pick = function()
                draft[field] = opt.value
                UIManager:close(d)
                if on_close then on_close() end
            end,
        }}
    end
    rows[#rows + 1] = {{
        text = _("Cancel"),
        callback = function()
            UIManager:close(d)
            if on_close then on_close() end
        end,
    }}
    d = ButtonDialog:new{ title = title, title_align = "center", buttons = rows }
    UIManager:show(d)
end

-- _pickDownloadDir(draft, on_close) - where THIS catalog chip saves its
-- downloads (issue #319). Reuses the move flow's folder picker so the choices
-- match "Move to folder…" exactly (searchable library folders, New folder,
-- Browse device). A "Follow KOReader" row clears the per-chip choice, which is
-- also the unset default. on_close saves the pick with the rest of the
-- shelf.
function Editor:_pickDownloadDir(draft, on_close)
    local UIManager = require("ui/uimanager")
    local ButtonDialog = require("ui/widget/buttondialog")
    local Picker = require("lib/bookshelf_folder_picker")
    local d
    d = ButtonDialog:new{
        title       = _("Save downloads from this catalog to\xE2\x80\xA6"),
        title_align = "center",
        buttons = {
            {{
                text = _("Choose folder\xE2\x80\xA6"),
                callback = function()
                    UIManager:close(d)
                    Picker.show{
                        title     = _("Save downloads to\xE2\x80\xA6"),
                        on_cancel = on_close,
                        on_pick   = function(dir)
                            draft.download_dir = dir
                            if on_close then on_close() end
                        end,
                    }
                end,
            }},
            {{
                text = (draft.download_dir == nil or draft.download_dir == "")
                    and ("\xE2\x9C\x93 " .. _("KOReader's download folder"))
                    or  ("  " .. _("KOReader's download folder")),
                callback = function()
                    draft.download_dir = nil
                    UIManager:close(d)
                    if on_close then on_close() end
                end,
            }},
            {{
                text = _("Cancel"),
                callback = function()
                    UIManager:close(d)
                    if on_close then on_close() end
                end,
            }},
        },
    }
    UIManager:show(d)
end

function Editor:_pickSource(draft, on_close)
    local Repo = require("lib/bookshelf_book_repository")
    local d

    -- pickById: search-enabled, paginated 2-column card picker for
    -- choosing from a list of N items (collections, genres, authors).
    -- Uses bookshelf_library_modal (ported from bookends) so bookshelf
    -- works standalone. ButtonDialog fallback retained as a safety net
    -- in case the LibraryModal require ever fails.
    local function pickById(kind, choices, on_pick, opts)
        local ok_lm, LibraryModal = pcall(require, "lib/bookshelf_library_modal")
        if ok_lm and LibraryModal and LibraryModal.new then
            local Font          = require("ui/font")
            local TextWidget    = require("lib/bookshelf_colour_text")
            local VerticalGroup_ = require("ui/widget/verticalgroup")
            local VerticalSpan  = require("ui/widget/verticalspan")
            local FrameContainer_ = require("ui/widget/container/framecontainer")
            local CenterContainer_= require("ui/widget/container/centercontainer")
            local Blitbuffer_   = require("ffi/blitbuffer")
            local Screen_       = require("device").screen

            local query = nil
            local function matches(label, q)
                if not q or q == "" then return true end
                return label:lower():find(q:lower(), 1, true) ~= nil
            end
            local visible = choices
            local function recompute()
                if not query or query == "" then
                    visible = choices
                else
                    visible = {}
                    for _i,c in ipairs(choices) do
                        if matches(c.label, query) then visible[#visible + 1] = c end
                    end
                end
            end

            local modal
            modal = LibraryModal:new{
                config = {
                    title              = (opts and opts.title) or (_("Choose ") .. kind),
                    search_placeholder = function() return _("Search\xE2\x80\xA6") end,
                    on_search_submit   = function(q)
                        query = q
                        recompute()
                        if modal then modal.page = 1; modal:refresh() end
                    end,
                    grid_cols    = 2,
                    cells_per_page = function()
                        -- 2-column grid; 5 rows portrait, 4 landscape.
                        return Screen_:getWidth() > Screen_:getHeight() and 8 or 10
                    end,
                    item_count   = function() return #visible end,
                    item_at      = function(idx) return visible[idx] end,
                    -- Shared cell renderer: same visual treatment in every
                    -- picker (folder, author, series, genre, format, rating,
                    -- collection) AND in the Collection Manager. No selected
                    -- state here -- pickers are one-shot select-and-close.
                    cell_renderer = function(item, dimen)
                        return require("lib/bookshelf_picker_cell").render(item, dimen)
                    end,
                    on_cell_tap = function(item)
                        UIManager:close(modal)
                        on_pick(item.value)
                    end,
                    cell_long_tap = (opts and opts.on_cell_hold) and function(item)
                        UIManager:close(modal)
                        opts.on_cell_hold(item)
                    end or nil,
                    footer_actions = (function()
                        -- Extra actions (e.g. the folder picker's "Browse
                        -- device") sit to the LEFT of Close. Each is wrapped
                        -- so the modal is torn down before the handler runs --
                        -- the handler typically opens another widget and
                        -- shouldn't have to juggle this modal's handle.
                        local actions = {}
                        if opts and opts.extra_footer_actions then
                            for _i, a in ipairs(opts.extra_footer_actions) do
                                actions[#actions + 1] = {
                                    label  = a.label,
                                    on_tap = function()
                                        UIManager:close(modal)
                                        a.on_tap()
                                    end,
                                }
                            end
                        end
                        actions[#actions + 1] = {
                            label  = _("Close"),
                            -- Signal cancel via nil so the caller can
                            -- reopen the parent picker. Without this, Close
                            -- just dismissed back to the editor's dialog,
                            -- losing the user's place in the picker chain.
                            on_tap = function()
                                UIManager:close(modal)
                                on_pick(nil)
                            end,
                        }
                        return actions
                    end)(),
                },
            }
            UIManager:show(modal)
            return
        end
        -- Fallback: flat ButtonDialog (limited for huge lists, but works
        -- when bookends isn't installed).
        local k
        local rows = {}
        for _i,c in ipairs(choices) do
            rows[#rows + 1] = {{
                text     = c.label,
                callback = function() on_pick(c.value); UIManager:close(k) end,
            }}
        end
        if opts and opts.extra_footer_actions then
            for _i, a in ipairs(opts.extra_footer_actions) do
                rows[#rows + 1] = {{
                    text     = a.label,
                    callback = function() UIManager:close(k); a.on_tap() end,
                }}
            end
        end
        rows[#rows + 1] = {{
            text     = _("Cancel"),
            callback = function() UIManager:close(k); on_pick(nil) end,
        }}
        k = ButtonDialog:new{
            title   = (opts and opts.title) or _("Choose " .. kind),
            buttons = rows,
        }
        UIManager:show(k)
    end
    -- Built-in shortcuts + working custom kinds.
    -- "Specific tag..." and "Reading status..." are deferred (see note above).
    -- Folder pair (row 3) lists every directory under home_dir that holds a
    -- book; selecting one writes source = { kind="folder", id=path/ } and
    -- getBySource prefix-matches book filepaths against the trailing-slash id.
    -- Row order favours the chip sources users reach for most often: the
    -- two date-based shortcuts sit at the top, the full-library flattened
    -- view spans the row below, then the folder pair sits with the rest of
    -- the browse-all / specific-picker pairs.
    local function set_simple(kind_value)
        return function()
            draft.source = { kind = kind_value }
            _applySourceDefaults(draft)
            UIManager:close(d)
            on_close()
        end
    end

    -- Generic specific-picker. fetcher_kind is a string ("series", "author",
    -- "genre", "format") routed through Repo.getGroupChoices for a pure-data
    -- read of the cached shapes -- no _hydrateGroupShape, no cover loads.
    -- On a 200-author library that takes the picker from ~1-2s to open down
    -- to ~tens of ms (the cache build, if cold) or single-digit ms (warm).
    local function open_group_picker(picker_kind, fetcher_kind, target_kind)
        local choices = Repo.getGroupChoices(fetcher_kind) or {}
        table.sort(choices, function(a, b) return a.label:lower() < b.label:lower() end)
        UIManager:close(d)
        pickById(picker_kind, choices, function(name)
            if not name then
                -- User tapped Close in the choose modal. Reopen the
                -- source picker so they can pick a different category
                -- without re-entering the editor's main dialog.
                Editor:_pickSource(draft, on_close)
                return
            end
            draft.source = { kind = target_kind, id = name }
            _applySourceDefaults(draft)
            on_close()
        end)
    end

    -- Specific-rating picker: a fixed list (1..5 stars + Unrated) rather
    -- than something derived from the library. Built inline because the
    -- option set is constant and tiny.
    local function open_rating_picker()
        local choices = {
            { value = "5",       label = "\xE2\x98\x85\xE2\x98\x85\xE2\x98\x85\xE2\x98\x85\xE2\x98\x85" },
            { value = "4",       label = "\xE2\x98\x85\xE2\x98\x85\xE2\x98\x85\xE2\x98\x85" },
            { value = "3",       label = "\xE2\x98\x85\xE2\x98\x85\xE2\x98\x85" },
            { value = "2",       label = "\xE2\x98\x85\xE2\x98\x85" },
            { value = "1",       label = "\xE2\x98\x85" },
            { value = "unrated", label = _("Unrated") },
        }
        UIManager:close(d)
        pickById("rating", choices, function(picked)
            if not picked then
                Editor:_pickSource(draft, on_close)
                return
            end
            draft.source = { kind = "rating", id = picked }
            _applySourceDefaults(draft)
            on_close()
        end)
    end

    local function open_tag_picker()
        local ReadCollection = require("readcollection")
        local default_name = ReadCollection.default_collection_name
        local choices = {}
        for name, coll in pairs(ReadCollection.coll or {}) do
            -- Skip the built-in favourites collection: it has its own
            -- dedicated "★ Favourites" button at the top of the source
            -- picker. Showing it here too would be a duplicate entry that
            -- can't be edited or deleted as a regular collection.
            if name ~= default_name then
                local count = 0
                for _ in pairs(coll) do count = count + 1 end
                choices[#choices + 1] = {
                    value = name,
                    label = name,
                    count = count,
                }
            end
        end
        table.sort(choices, function(a, b) return a.label:lower() < b.label:lower() end)
        UIManager:close(d)
        pickById("collection", choices, function(picked)
            if not picked then
                Editor:_pickSource(draft, on_close)
                return
            end
            draft.source = { kind = "collection", id = picked }
            _applySourceDefaults(draft)
            on_close()
        end)
    end

    -- OPDS catalogue picker AND manager. Rows come from bookshelf's own catalog
    -- store (Catalogs.list gives stock-shaped records), which reads/writes the
    -- same opds.lua as the stock plugin. Tap selects a catalogue for this chip;
    -- the "Add catalog" footer button and long-press Edit/Delete manage the
    -- list, so the stock opds plugin is no longer needed to add catalogues.
    local function open_opds_picker()
        local Catalogs   = require("lib/bookshelf_opds_catalogs")
        local Editor_    = require("lib/bookshelf_opds_catalog_editor")
        local OpdsSource = require("lib/bookshelf_opds_source")

        local function build_choices()
            local choices = {}
            for _i, s in ipairs(Catalogs.list() or {}) do
                choices[#choices + 1] = {
                    value    = OpdsSource.serverKey(s.url),
                    label    = s.title,
                    subtitle = s.url,
                    _catalog = s,   -- carry the raw record for edit/delete
                }
            end
            return choices
        end

        UIManager:close(d)

        local reopen  -- forward declaration so handlers can re-open the picker
        reopen = function()
            pickById("OPDS catalog", build_choices(), function(picked)
                if not picked then
                    Editor:_pickSource(draft, on_close)
                    return
                end
                draft.source = { kind = "opds", id = picked }
                _applySourceDefaults(draft)
                on_close()
            end, {
                title = _("Choose OPDS catalog"),
                extra_footer_actions = {
                    { label = _("Add catalog\xE2\x80\xA6"), on_tap = function()
                        Editor_.show{ on_saved = reopen, on_cancel = reopen }
                    end },
                },
                on_cell_hold = function(item)
                    if not item or not item._catalog then
                        reopen(); return
                    end
                    local ButtonDialog = require("ui/widget/buttondialog")
                    local menu
                    menu = ButtonDialog:new{
                        -- Dismissing the menu (tap outside) returns to the
                        -- picker rather than dropping out to the chip editor.
                        tap_close_callback = reopen,
                        buttons = {
                            {{ text = _("Edit"), callback = function()
                                UIManager:close(menu)
                                Editor_.show{ item = item._catalog, on_saved = reopen, on_cancel = reopen }
                            end }},
                            {{ text = _("Delete"), callback = function()
                                UIManager:close(menu)
                                Editor_.confirmDelete{ item = item._catalog, on_deleted = reopen, on_cancel = reopen }
                            end }},
                        },
                    }
                    UIManager:show(menu)
                end,
            })
        end
        reopen()
    end

    -- Folder picker: flat list of every directory under home_dir that
    -- contains a book at any depth. Each choice carries the full path as a
    -- subtitle (rendered by pickById's cell renderer) so duplicate basenames
    -- can be disambiguated. The picked path is the source id; getBySource
    -- prefix-matches it against book filepaths.
    -- folder_kind is "folder" (tree view, subfolders as cards) or
    -- "folder_flat" (#76: every book under the path, no folder cards).
    -- Both share the same picker + Browse-device flow; only the stored
    -- source kind differs.
    local function open_folder_picker(folder_kind)
        folder_kind = folder_kind or "folder"
        local choices = Repo.getFolderChoices() or {}
        UIManager:close(d)

        local function pick_path(picked)
            draft.source = { kind = folder_kind, id = picked }
            _applySourceDefaults(draft)
            on_close()
        end

        -- "Browse device": KOReader's own folder navigator, unrooted, so any
        -- folder on the device can back a chip -- including ones outside the
        -- home folder that getFolderChoices (home-tree + book-bearing only)
        -- never offers. Folder-only config matches Settings:_pickImageLibraryPath.
        local function browse_device()
            local PathChooser = require("ui/widget/pathchooser")
            local confirmed = false
            UIManager:show(PathChooser:new{
                path             = require("lib/bookshelf_home_dir").get() or "/",
                select_directory = true,
                select_file      = false,
                show_files       = false,
                onConfirm        = function(folder)
                    confirmed = true
                    -- Normalise to getFolderChoices' no-trailing-slash id form
                    -- so both entry points store the path identically.
                    folder = (folder == "/") and "/" or folder:gsub("/+$", "")
                    pick_path(folder)
                end,
                -- Backing out of the browser without choosing returns to the
                -- source picker rather than dropping to the shelf -- the
                -- editor's dialog `d` was already closed when the flat-list
                -- picker opened, so there's nothing underneath to fall back to.
                -- close_callback fires on any close, hence the confirmed guard.
                close_callback   = function()
                    if not confirmed then
                        Editor:_pickSource(draft, on_close)
                    end
                end,
            })
        end

        pickById("folder", choices, function(picked)
            if not picked then
                Editor:_pickSource(draft, on_close)
                return
            end
            pick_path(picked)
        end, {
            title = _("Choose folder within home folder"),
            extra_footer_actions = {
                { label = _("Browse device\xE2\x80\xA6"), on_tap = browse_device },
            },
        })
    end

    -- BookOrbit section picker: two-level drill-down (root shortcuts +
    -- server-advertised sections -> entries within a section), backed by
    -- lib/bookshelf_bookorbit_source.lua. Mirrors open_group_picker /
    -- open_tag_picker's shape (close d, fetch choices, pickById, write
    -- draft.source, on_close) but the fetch is a real network call, so it
    -- shows a brief loading notice first and can fail (offline / not
    -- configured / server error) instead of always having an answer.
    local function open_bookorbit_picker()
        UIManager:close(d)
        local BookOrbit   = require("lib/bookshelf_bookorbit")
        local InfoMessage = require("ui/widget/infomessage")
        if not BookOrbit.isConfigured() then
            UIManager:show(InfoMessage:new{
                text = _("Set up your BookOrbit server first (Bookshelf menu \xE2\x86\x92 BookOrbit \xE2\x86\x92 Connect)."),
                timeout = 3,
            })
            Editor:_pickSource(draft, on_close)
            return
        end
        local BOSource = require("lib/bookshelf_bookorbit_source")

        local showLevel
        showLevel = function(choices, title)
            pickById("bookorbit", choices, function(picked)
                if picked == nil then
                    Editor:_pickSource(draft, on_close)
                    return
                end
                if picked.drill then
                    UIManager:show(InfoMessage:new{ text = _("Loading\xE2\x80\xA6"), timeout = 1 })
                    UIManager:nextTick(function()
                        -- Self-contained one-shot action (like
                        -- resolveOpenPath) -- opens its own Trapper
                        -- coroutine, since nothing further up this
                        -- nextTick's call stack has one open. Needed
                        -- because fetchSectionChoices can now block on a
                        -- BookOrbit catalogSection fetch.
                        local function work()
                            local entries = BOSource.fetchSectionChoices(picked.drill, picked.title)
                            if not entries or #entries == 0 then
                                entries = { { value = { id = false }, label = _("Nothing here yet.") } }
                            end
                            showLevel(entries, picked.title)
                        end
                        local ok_t, Trapper = pcall(require, "ui/trapper")
                        if ok_t and Trapper and Trapper.wrap and Trapper.isWrapped then
                            if Trapper:isWrapped() then
                                work()      -- already inside a coroutine opened further up -- don't nest
                            else
                                Trapper:wrap(work)
                            end
                        else
                            work()
                        end
                    end)
                    return
                end
                if not picked.id then
                    -- Placeholder "nothing here" row; just reopen this level.
                    showLevel(choices, title)
                    return
                end
                draft.source = { kind = "bookorbit", id = picked.id }
                -- Name the chip after the picked section right away -- the
                -- id itself ("libraries:42") makes a poor label, so this
                -- runs BEFORE _applySourceDefaults' generic "New chip" ->
                -- source.id fallback would otherwise use the raw id.
                if draft.label == _("New chip") and picked.label then
                    draft.label = picked.label
                end
                _applySourceDefaults(draft)
                on_close()
            end, { title = title or _("BookOrbit") })
        end

        UIManager:show(InfoMessage:new{ text = _("Loading BookOrbit sections\xE2\x80\xA6"), timeout = 1 })
        UIManager:nextTick(function()
            -- Self-contained one-shot action, same reasoning as the
            -- fetchSectionChoices drill-down above -- fetchRootChoices can
            -- now block on a BookOrbit catalogRoot fetch.
            local function work()
                local choices, err = BOSource.fetchRootChoices()
                if not choices then
                    UIManager:show(InfoMessage:new{ text = _("Couldn't reach the BookOrbit server."), timeout = 3 })
                    Editor:_pickSource(draft, on_close)
                    return
                end
                showLevel(choices, _("BookOrbit"))
            end
            local ok_t, Trapper = pcall(require, "ui/trapper")
            if ok_t and Trapper and Trapper.wrap and Trapper.isWrapped then
                if Trapper:isWrapped() then
                    work()      -- already inside a coroutine opened further up -- don't nest
                else
                    Trapper:wrap(work)
                end
            else
                work()
            end
        end)
    end

    local function btn(kind_value, label, on_tap)
        local prefix = (draft.source.kind == kind_value) and "\xE2\x9C\x93 " or "  "
        return { text = prefix .. label, callback = on_tap or set_simple(kind_value) }
    end

    -- For the "specific" right-column buttons the check should also trip
    -- when the persisted source.kind matches that specific kind (e.g.
    -- collection / genre / author / single_series).
    local function specific_btn(picked_kind, label, on_tap)
        local prefix = (draft.source.kind == picked_kind) and "\xE2\x9C\x93 " or "  "
        return { text = prefix .. label, callback = on_tap }
    end

    -- Two greyed headings split the list in two: shelves of BOOKS, and
    -- shelves GROUPED into series / author / genre ... tiles, the second being
    -- what readers looked for and did not find (maintainer).
    local function heading(label)
        return { { text = label, enabled = false } }
    end
    local rows = {
        heading(_("Books")),
        -- Row 1: the most-reached-for shortcuts — date-based plus the
        -- favourites curated shortcut. Favourites was previously on its
        -- own row but it's the same "curated shortcut" tier as Recent /
        -- Latest, so it earns the same row visually too.
        {
            btn("recent",    _("Recently read")),
            btn("latest",    _("Latest added")),
            btn("favorites", _("\xE2\x98\x85 Favorites")),  -- ★ Favourites
        },
        -- Home pair: folders (tree view) on the left, flattened (every book,
        -- no subfolder cards) on the right.
        {
            btn("all",       _("Home (folders)")),
            btn("library",   _("Home (flattened)")),
        },
        -- Specific-folder pair (#76): same folder picker + Browse-device
        -- flow, differing only in render. Left pins a folder subtree as a
        -- tree (subfolder cards); right flattens it to every book under the
        -- path with no subfolder cards. Mirrors the Home pair above.
        {
            specific_btn("folder", _("Specific folder\xE2\x80\xA6"),
                function() open_folder_picker("folder") end),
            specific_btn("folder_flat", _("Flattened folder\xE2\x80\xA6"),
                function() open_folder_picker("folder_flat") end),
        },
        -- Rows 4+: browse-all on the left, specific-picker on the right
        heading(_("Grouped")),
        {
            btn("series",    _("Series")),
            specific_btn("single_series", _("Specific series\xE2\x80\xA6"),
                function() open_group_picker("series", "series", "single_series") end),
        },
        {
            btn("authors",   _("Authors")),
            specific_btn("author", _("Specific author\xE2\x80\xA6"),
                function() open_group_picker("author", "author", "author") end),
        },
        {
            btn("genres",    _("Genres")),
            specific_btn("genre", _("Specific genre\xE2\x80\xA6"),
                function() open_group_picker("genre", "genre", "genre") end),
        },
        {
            btn("tags",      _("Collections")),
            specific_btn("collection", _("Specific collection\xE2\x80\xA6"), open_tag_picker),
        },
        {
            btn("formats",   _("Formats")),
            specific_btn("format", _("Specific format\xE2\x80\xA6"),
                function() open_group_picker("format", "format", "format") end),
        },
        {
            btn("ratings",   _("Ratings")),
            specific_btn("rating", _("Specific rating\xE2\x80\xA6"), open_rating_picker),
        },
        {
            btn("languages", _("Languages")),
            specific_btn("language", _("Specific language\xE2\x80\xA6"),
                function() open_group_picker("language", "language", "language") end),
        },
        -- BookOrbit: a remote server section (library/collection/author/
        -- series/etc., or one of the "all/recent/continue reading"
        -- shortcuts). Always shown; tapping it with no server configured
        -- just points the user at Bookshelf menu -> BookOrbit -> Connect
        -- (see open_bookorbit_picker) rather than hiding the row.
        {
            specific_btn("bookorbit", _("BookOrbit section\xE2\x80\xA6"), open_bookorbit_picker),
        },
        -- OPDS row: always present, even with zero catalogues configured
        -- yet -- unlike the other "Specific X…" pickers, this row is the only
        -- route into the catalogue picker (which now hosts add/edit/delete),
        -- so it must stay discoverable rather than being gated on
        -- OpdsSource.isAvailable().
        --
        -- Shelf of shelves (5.4) shares it: its tiles are shelves of their
        -- own, each with every option a top-level shelf has. A row of its
        -- own (and a heading) made the picker two rows taller, and it already
        -- scrolls on a small screen (maintainer).
        {
            btn("shelves", _("Shelf of shelves")),
            specific_btn("opds", _("OPDS catalog\xE2\x80\xA6"),
                function() open_opds_picker() end),
        },
        -- Cancel row
        {
            { text = _("Cancel"), callback = function() UIManager:close(d); on_close() end },
        },
    }

    -- Registered sources (lib/bookshelf_sources): the Kindle's own library, and
    -- any plugin's (issue 452). Unlike the OPDS row above these are gated on
    -- the source being available -- the Kindle one needs a readable catalogue
    -- AND kindle.koplugin to open the books -- so nobody sees a source they
    -- cannot use. Above Cancel, so they read as the last real sources.
    local Sources = require("lib/bookshelf_sources")
    for _i, id in ipairs(Sources.pickerIds()) do
        local spec = Sources.get(id)
        local on_tap
        if spec.pick then
            -- The source asks its own question (which server, which library)
            -- and fills draft.source; done() carries on as a plain pick would.
            on_tap = function()
                UIManager:close(d)
                local prev = draft.source
                draft.source = { kind = id }
                local ok = Sources.call(spec, "pick", draft, function(accepted)
                    if accepted == false then draft.source = prev; on_close() return end
                    if type(draft.source) ~= "table" then draft.source = { kind = id } end
                    draft.source.kind = id
                    _applySourceDefaults(draft)
                    on_close()
                end)
                if not ok then draft.source = prev; on_close() end
            end
        end
        table.insert(rows, #rows, { btn(id, Sources.label(id) or id, on_tap) })
    end
    d = ButtonDialog:new{
        title   = _("Shelf source or grouping"),
        buttons = rows,
        anchor  = _highAnchor(function() return d end),
    }
    UIManager:show(d)
end
-- Filters list: one row per dimension showing its current selection, plus a
-- Clear-all row. Re-opens itself after each sub-picker so the summary updates.
function Editor:_openFilters(draft, on_close)
    draft.filter = draft.filter or {}
    local d
    local function reopen() UIManager:close(d); Editor:_openFilters(draft, on_close) end

    -- Pixel-accurate row truncation: a standard button SHRINKS its font when
    -- the label is too wide rather than ellipsising, so measure the row text at
    -- the button's own face (cfont/20/bold per ui/widget/button.lua) and trim it
    -- to the row width with "…" ourselves. This fills right to the edge before
    -- truncating (a fixed char budget cut too early on narrow glyphs).
    local Font_       = require("ui/font")
    local Size_       = require("ui/size")
    local Screen_     = require("device").screen
    local RenderText_ = require("ui/rendertext")
    local TextSegments_ = require("lib/bookshelf_text_segments")
    local btn_face = Font_:getFace("cfont", 20)
    local dlg_w    = math.floor(math.min(Screen_:getWidth(), Screen_:getHeight()) * 0.9)
    -- Conservative inner label width: the dialog border + buttontable + button
    -- cell insets compound to more than their nominal sums, so subtract a
    -- generous margin. Leaning narrow means we truncate just shy of the edge
    -- rather than overflow into the font-shrink the user saw. Tune the margin
    -- if rows under-fill (raise) or the font still shrinks (lower).
    local row_avail = dlg_w - 2 * (Size_.padding.large + Size_.padding.default + Size_.border.window)
    local function fitRow(text)
        local w = RenderText_:sizeUtf8Text(0, Screen_:getWidth(), btn_face, text, false, true).x
        if w > row_avail then
            text = RenderText_:truncateTextByWidth(text, btn_face, row_avail, false, true)
        end
        return text
    end

    local rows = {}
    for _i, dim in ipairs(Filter.dimensions()) do
        local dkey   = dim.key
        -- Uppercase label separates the filter name from its value without
        -- per-substring bold (standard buttons are single-weight). The value
        -- stays normal case after the colon; fitRow trims a long list with "…".
        -- TextSegments.upper is Unicode-aware (utf8proc) so accented labels like
        -- "Műfaj"/"Értékelés" uppercase correctly, unlike Lua's ASCII :upper() (#209).
        local prefix = TextSegments_.upper(dim.label) .. ": "
        rows[#rows + 1] = {
            {
                text  = fitRow(prefix .. Filter.dimSummary(draft.filter, dkey)),
                align = "left",   -- line up with the left-aligned header text
                callback = function()
                    UIManager:close(d)
                    local reopen_filters = function() Editor:_openFilters(draft, on_close) end
                    if dim.kind == "folder" then
                        Editor:_pickFolderFilter(draft, reopen_filters)
                    elseif dim.kind == "choice" then
                        Editor:_pickChoiceFilter(draft, dkey, reopen_filters)
                    else
                        Editor:_pickMultiFilter(draft, dkey, reopen_filters)
                    end
                end,
            },
        }
    end
    -- Single bottom row: Clear all on the left, Done on the right.
    rows[#rows + 1] = {
        { text = _("Clear all filters"), callback = function()
            draft.filter = {}
            reopen()
        end },
        -- Close: the filters apply as the reader leaves this list (on_close
        -- saves them and rebuilds the shelf once), not per tap inside it.
        { text = _("Close"), callback = function() UIManager:close(d); on_close() end },
    }
    -- A bold "Filters" heading plus a body-size help paragraph below it.
    local help_widget = _helpParagraph(_("Pick filters to narrow the shelf. Several picks in the same row match any of them, so picking two genres shows books in either. Picks in different rows must all match, so adding a 5-star rating then limits those to 5-star books only. Numbers below filter choices show how many books currently match based on other selected filters."))
    d = ButtonDialog:new{
        title          = _("Filters"),
        title_align    = "left",
        use_info_style = false,        -- bold heading, distinct from the body text
        _added_widgets = { help_widget },
        buttons        = rows,
        anchor         = _highAnchor(function() return d end),
    }
    UIManager:show(d)
end

-- Generic multi-select picker for a categorical dimension. Status uses a fixed
-- value list; the others enumerate distinct library values via Repo.
-- Single-choice ("choice" kind) filter picker -- currently only the Series
-- dimension (standalone vs in a series). A small radio ButtonDialog: one row
-- per option with the active one marked (filled/hollow circle); tapping sets it
-- and returns to the filter list. "both" persists as an explicit value: on
-- book-list chips it still compiles to no effect, but the Series source reads
-- it to mix standalone books in with the stacks (#160).
-- Any dismissal (tap-outside included) reopens the filter list via on_close.
function Editor:_pickChoiceFilter(draft, dim_key, on_close)
    draft.filter = draft.filter or {}
    local ButtonDialog = require("ui/widget/buttondialog")
    local values = (dim_key == "series_membership") and Filter.seriesValues() or {}
    -- The UNSET marker must show what unset actually DOES (issue 350). On a
    -- book-list chip an absent value compiles to no effect, i.e. "both"; but
    -- the SERIES source reads absent as its historical stacks-only mode, so
    -- marking "both" there claimed a state the shelf was not in - and the
    -- user had to tap the already-ticked row to make the dialog true.
    local unset_means = "both"
    if dim_key == "series_membership"
            and draft.source and draft.source.kind == "series" then
        unset_means = "in_series"
    end
    local current = draft.filter[dim_key] or unset_means
    local d
    local buttons = {}
    for _i, v in ipairs(values) do
        -- ● (U+25CF) selected / ○ (U+25CB) unselected -- a plain radio marker.
        local mark = (v.value == current) and "\xE2\x97\x8F  " or "\xE2\x97\x8B  "
        buttons[#buttons + 1] = {{
            text  = mark .. v.label,
            align = "left",
            callback = function()
                draft.filter[dim_key] = v.value
                UIManager:close(d)
                on_close()
            end,
        }}
    end
    d = ButtonDialog:new{
        title             = _("Series filter"),
        title_align       = "center",
        buttons           = buttons,
        anchor            = _highAnchor(function() return d end),
        tap_close_callback = function() on_close() end,
    }
    UIManager:show(d)
end

function Editor:_pickMultiFilter(draft, dim_key, on_close)
    draft.filter = draft.filter or {}
    draft.filter[dim_key] = draft.filter[dim_key] or {}
    local sel = draft.filter[dim_key]

    local titles = {
        statuses    = _("Reading status filter"),
        genres      = _("Genre filter"),
        langs       = _("Language filter"),
        formats     = _("Format filter"),
        ratings     = _("Rating filter"),
        collections = _("Collection filter"),
    }
    local title = titles[dim_key] or _("Filter")

    -- Build choices list.
    local choices
    local Repo = require("lib/bookshelf_book_repository")
    if dim_key == "statuses" then
        choices = {}
        for _i, v in ipairs(Filter.statusValues()) do
            choices[#choices + 1] = { value = v.value, label = v.label }
        end
    elseif dim_key == "ratings" then
        choices = {}
        for _i, v in ipairs(Filter.ratingValues()) do
            choices[#choices + 1] = { value = v.value, label = v.label }
        end
    else
        choices = Repo.distinctFilterValues(dim_key, draft.source) or {}
    end

    -- Overlay faceted counts: replace static library totals with counts
    -- reflecting the OTHER active filter dimensions (filter minus dim_key).
    -- Computed once here (picker open); stable while the user toggles within
    -- this dimension because those selections are excluded. nil return means
    -- no other dim is active so static counts already reflect reality.
    --
    -- draft.source scopes both halves to the chip's own source, so a Kindle or
    -- Kobo chip offers and counts ITS books rather than the walked library's.
    local facet = Repo.filterValueCounts(dim_key, draft.filter, draft.source)
    if facet then
        for _i, c in ipairs(choices) do c.count = facet[c.value] or 0 end
    end


    -- LibraryModal path (lazy + pcall-guarded so the module still loads
    -- headlessly in _test_chip_editor.lua, which stubs nothing from this
    -- require tree).
    local ok_lm, LibraryModal = pcall(require, "lib/bookshelf_library_modal")
    if ok_lm and LibraryModal and LibraryModal.new then
        local Screen_ = require("device").screen

        local query = nil
        local function matches(label, q)
            if not q or q == "" then return true end
            return label:lower():find(q:lower(), 1, true) ~= nil
        end
        local visible = choices
        local function recompute()
            if not query or query == "" then
                visible = choices
            else
                visible = {}
                for _i, c in ipairs(choices) do
                    if matches(c.label, query) then visible[#visible + 1] = c end
                end
            end
        end

        local modal
        modal = LibraryModal:new{
            config = {
                title              = title,
                search_placeholder = function() return _("Search\xE2\x80\xA6") end,
                on_search_submit   = function(q)
                    query = q
                    recompute()
                    if modal then modal.page = 1; modal:refresh() end
                end,
                grid_cols      = 2,
                cells_per_page = function()
                    return Screen_:getWidth() > Screen_:getHeight() and 8 or 10
                end,
                item_count  = function() return #visible end,
                item_at     = function(idx) return visible[idx] end,
                cell_renderer = function(item, dimen)
                    return require("lib/bookshelf_picker_cell").render(
                        item, dimen, { selected = sel[item.value] == true })
                end,
                on_cell_tap = function(item)
                    -- Toggle in place; never close/reopen (that's the old
                    -- scroll-reset bug). refresh() re-renders the current
                    -- page with updated selected states.
                    if sel[item.value] then
                        sel[item.value] = nil
                    else
                        sel[item.value] = true
                    end
                    modal:refresh()
                end,
                footer_actions = {
                    {
                        label  = _("Clear"),
                        on_tap = function()
                            -- Empty the set in place so `sel` stays valid
                            -- (reassigning draft.filter[dim_key] would
                            -- orphan the `sel` upvalue).
                            for k in pairs(sel) do sel[k] = nil end
                            modal:refresh()
                        end,
                    },
                    {
                        -- Back to the Filters list, which this was opened from.
                        label  = _("Back"),
                        on_tap = function()
                            UIManager:close(modal)
                            on_close()
                        end,
                    },
                },
            },
        }
        -- LibraryModal has no separate cancel/close hook beyond footer
        -- actions. Hardware-back closes the modal widget and returns to
        -- whatever was below it (the _openFilters ButtonDialog), which is
        -- acceptable -- the user isn't stranded. A second action calling
        -- on_close() would duplicate Back's effect, so a single Back footer
        -- action is kept.
        UIManager:show(modal)
        return
    end

    -- Fallback: ButtonDialog multi-select (original implementation).
    -- Used when LibraryModal is unavailable (e.g. headless test stubs or
    -- a bare KOReader install without the bookends widget set).
    local d
    local values = choices

    local function any_checked()
        for _k in pairs(sel) do return false end
        return true
    end
    local function reopen() UIManager:close(d); Editor:_pickMultiFilter(draft, dim_key, on_close) end
    local function toggle(value)
        if sel[value] then sel[value] = nil else sel[value] = true end
        reopen()
    end

    local rows = {
        { { text = (any_checked() and "\xE2\x9C\x93 " or "  ") .. _("Any"),
            callback = function() draft.filter[dim_key] = {}; reopen() end } },
    }
    local i = 1
    while i <= #values do
        local left  = values[i]
        local right = values[i + 1]
        local function vbtn(v)
            if not v then return nil end
            local checked = sel[v.value] == true
            return { text = (checked and "\xE2\x9C\x93 " or "  ") .. v.label,
                     callback = function() toggle(v.value) end }
        end
        local row = { vbtn(left) }
        local rb = vbtn(right)
        if rb then row[#row + 1] = rb end
        rows[#rows + 1] = row
        i = i + 2
    end
    if #values == 0 then
        rows[#rows + 1] = { { text = _("(none in library)"), callback = function() end } }
    end
    rows[#rows + 1] = { { text = _("Back"), callback = function() UIManager:close(d); on_close() end } }

    d = ButtonDialog:new{
        title   = title,
        buttons = rows,
        anchor  = _highAnchor(function() return d end),
    }
    UIManager:show(d)
end

-- Folder include/exclude manager. Lists current include (+) and exclude (-)
-- entries; tapping one removes it. "Add include / Add exclude" open the
-- KOReader folder chooser to add a path. Recursive matching + exclude-wins are
-- enforced by Filter.matches; this screen only edits the path sets.
function Editor:_pickFolderFilter(draft, on_close)
    local PathChooser = require("ui/widget/pathchooser")
    draft.filter = draft.filter or {}
    draft.filter.folders = draft.filter.folders or { include = {}, exclude = {} }
    local folders = draft.filter.folders
    folders.include = folders.include or {}
    folders.exclude = folders.exclude or {}
    local d
    local function reopen() UIManager:close(d); Editor:_pickFolderFilter(draft, on_close) end

    local function add_via_chooser(set)
        local confirmed = false
        UIManager:show(PathChooser:new{
            path             = require("lib/bookshelf_home_dir").get() or "/",
            select_directory = true,
            select_file      = false,
            show_files       = false,
            onConfirm        = function(folder)
                confirmed = true
                folder = (folder == "/") and "/" or folder:gsub("/+$", "")
                set[folder] = true
                Editor:_pickFolderFilter(draft, on_close)
            end,
            close_callback   = function()
                if not confirmed then Editor:_pickFolderFilter(draft, on_close) end
            end,
        })
    end

    local rows = {}
    local function entry_rows(set, sign)
        local keys = {}
        for p in pairs(set) do keys[#keys + 1] = p end
        table.sort(keys)
        for _i, p in ipairs(keys) do
            rows[#rows + 1] = { { text = sign .. " " .. p,
                callback = function() set[p] = nil; reopen() end } }
        end
    end
    entry_rows(folders.include, "+")
    entry_rows(folders.exclude, "-")
    if not next(folders.include) and not next(folders.exclude) then
        rows[#rows + 1] = { { text = _("(no folder filters - tap to remove once added)"),
            callback = function() end } }
    end
    rows[#rows + 1] = {
        { text = _("Add folder to include"), callback = function() UIManager:close(d); add_via_chooser(folders.include) end },
        { text = _("Add folder to exclude"), callback = function() UIManager:close(d); add_via_chooser(folders.exclude) end },
    }
    rows[#rows + 1] = { { text = _("Back"), callback = function() UIManager:close(d); on_close() end } }

    d = ButtonDialog:new{
        title   = _("Folder filter"),
        buttons = rows,
        anchor  = _highAnchor(function() return d end),
    }
    UIManager:show(d)
end

-- _pickSortLevel -- single-level sort key picker.
-- Opens a ButtonDialog listing all sort keys. Tapping an already-selected key
-- toggles its reverse flag. Tapping "(none)" clears the slot.
-- level_index is 1 or 2 (Sort 1 / Sort 2); L3+ is preserved in the data
-- array but not exposed in the main editor dialog.
function Editor:_pickSortLevel(draft, level_index, on_close, on_arranged)
    local current = draft.sort_priority and draft.sort_priority[level_index]
    local d
    local kind = draft.source and draft.source.kind
    local is_group = GROUP_KINDS[kind or ""] or false

    -- Build a button for a sort key (with checkmark + reverse arrow). Second
    -- tap on the already-selected key toggles its reverse flag. The label
    -- comes from _resolveSortLabel so the editor's main Sort row and the
    -- picker row show the same text for the same key in the same context.
    -- The ↑ glyph appears only when the saved direction differs from this
    -- key's natural default -- consistent with how the editor's Sort row
    -- displays the same selection.
    local function key_btn(key_id)
        local selected = current and current.key == key_id
        local prefix   = selected and "\xE2\x9C\x93 " or "  "
        local is_inverted = selected
            and not _isDefaultDirection(key_id, current and current.reverse)
        local rev_suffix = is_inverted and " \xE2\x86\x91" or ""
        local lbl = _resolveSortLabel(level_index, key_id, kind)
        return {
            text     = prefix .. lbl .. rev_suffix,
            callback = function()
                draft.sort_priority = draft.sort_priority or {}
                local rev
                if selected then
                    rev = not (current and current.reverse)  -- toggle
                else
                    rev = DEFAULT_REVERSE[key_id] == true    -- natural default
                end
                draft.sort_priority[level_index] = { key = key_id, reverse = rev }
                UIManager:close(d); on_close()
            end,
        }
    end

    -- "Clear sort" removes this level's sort_priority entry (the old
    -- full-width "(none)" row, moved to a bottom-left button beside Close so
    -- the picker leads with the actual sort options). Checkmark shows when no
    -- sort is currently set for this level. Per-book tabs only -- group tabs
    -- deliberately have no clear option (a group view must have an order).
    local clear_btn = {
        text     = (not current and "\xE2\x9C\x93 " or "  ") .. _("Clear sort"),
        callback = function()
            if draft.sort_priority then
                table.remove(draft.sort_priority, level_index)
            end
            UIManager:close(d); on_close()
        end,
    }
    local close_btn = { text = _("Close"),
                        callback = function() UIManager:close(d); on_close() end }
    local close_row = { close_btn }

    local rows
    if is_group and level_index == 1 then
        -- Group tabs: level 1 orders the GROUP CARDS (author / genre /
        -- series stacks on the tab). Keys that have no data on group
        -- records are omitted -- only those whose comparator can read
        -- something useful from a group shape are exposed.
        --   * series_name        -> alphabetical by group display name
        --   * author_surname     -> Authors-tab surname extraction; falls
        --     back to series_name on other group tabs
        --   * book_count         -> #group.filepaths
        --   * last_opened        -> group.latest (max read time)
        --   * date_added         -> group.latest_added (max member mtime)
        --
        -- No (none) row at level 1 on group tabs: the whole point of a
        -- group view is to have an order, and the user can always tap a
        -- different option to switch. Compacts the picker to 3 rows.
        rows = {
            { key_btn("series_name"), key_btn("author_surname"), key_btn("book_count") },
            { key_btn("last_opened"), key_btn("date_added"),
              key_btn("added_or_opened") },
            close_row,
        }
    else
        -- Per-book tabs get the full 2-col layout. Pairs grouped by
        -- meaning (identity / author / series / time / progress); the
        -- numeric/size sorts (file size / page count / stack size) share
        -- the final 3-up row.
        rows = {
            { key_btn("title"),          key_btn("filename"),
              key_btn("series_or_title") },
            { key_btn("author_surname"), key_btn("author_name")       },
            -- Series name / index / combined ("Series + #") share one row
            -- so the one-tap combined option sits beside the pair it merges.
            { key_btn("series_name"),    key_btn("series_index"),
              key_btn("series_combined") },
            { key_btn("last_opened"),    key_btn("date_added"),
              key_btn("added_or_opened") },
            { key_btn("percent_read"),   key_btn("rating")            },
            { key_btn("read_status"),    key_btn("read_status_active"),
              key_btn("favorites_first") },
            { key_btn("size"),           key_btn("page_count"),
              key_btn("book_count") },
            { clear_btn, close_btn },
        }
        -- A collection is the only book source carrying an order of its own,
        -- and on one that has it, it is the order the reader arranged by hand
        -- in KOReader -- so it leads. Added here rather than in the grid
        -- above so no other source pays a row for a key that would be nil for
        -- every book on its shelf (issue 441).
        if kind == "collection" then
            local row = { key_btn("collection_order") }
            -- Beside it, the way to CHANGE that order, which otherwise meant
            -- leaving for KOReader's collections view. Only when a collection
            -- is really behind the chip: a pinned tag is kind "collection" too,
            -- with nothing to arrange.
            --
            -- Opened over this picker rather than instead of it, so confirming
            -- or backing out of the arrange window lands the reader here, by
            -- the key. A confirm drops the book cache (CollectionOrder.save)
            -- and calls on_arranged, which tells editTab to repaint the shelf
            -- on the way out -- Cancel included, since the arrangement is
            -- already written. An earlier version of this comment claimed the
            -- editor invalidated the cache on close; it does not, and the
            -- shelf kept the old order until a swipe down.
            local CollectionOrder = require("lib/bookshelf_collection_order")
            local coll_id = draft.source and draft.source.id
            if CollectionOrder.exists(coll_id) then
                row[2] = {
                    text     = _("Edit collection order"),
                    callback = function() CollectionOrder.arrange(coll_id, on_arranged) end,
                }
            end
            table.insert(rows, 1, row)
        end
    end

    local title
    if is_group and level_index == 1 then
        title = _("Sort groups by")
    elseif is_group then
        title = _("Within each group, then by")
    elseif level_index == 1 then
        title = _("Sort by")
    else
        title = _("Then by")
    end
    d = ButtonDialog:new{
        title   = title,
        buttons = rows,
        anchor  = _highAnchor(function() return d end),
    }
    UIManager:show(d)
end
-- _pickIcon -- opens the bundled icons library (categorised glyph grid) for
-- the start-menu icon slot. Selection writes the chosen value into draft.icon.
-- Dynamic %tokens are excluded: the start-menu icon slot does not expand them.
-- SVG icons are enabled because the start-menu renderer turns [icon=NAME]
-- values into IconWidget images.
function Editor:_pickIcon(draft, on_close)
    local IconsLibrary = require("lib/bookshelf_icons_library")
    IconsLibrary:show(function(value)
        draft.icon = value and value ~= "" and value or nil
        on_close()
    end, { dynamic = false, svg = true })
end

-- Exposed for tests/_test_chip_editor.lua (config tables + the pure
-- defaults-applier). Not referenced at runtime.
Editor._test = {
    SOURCE_SORT_DEFAULTS = SOURCE_SORT_DEFAULTS,
    GROUP_KINDS          = GROUP_KINDS,
    applySourceDefaults  = _applySourceDefaults,
    resolveSourceLabel   = _resolveSourceLabel,
}

return Editor
