--[[--
Repaint coalescer for BookOrbit cover fills.

Problem (see HANDOFF_cover_speed): every batch of covers that landed used to
trigger a full BookshelfWidget:_rebuild() + e-ink repaint, about 10 per
page. This object merges those requests: a leading + trailing throttle.

  * The first request (or one arriving at least `min_gap` seconds after the
    last flush ENDED) flushes at once.
  * Requests inside the gap are merged; ONE trailing flush is scheduled at
    the end of the last flush + min_gap. The gap runs from the END of a flush
    (C21a): a rebuild that itself takes 450 ms must not be followed at once by
    the next one, which kept the UI busy back to back.
  * A request marked `final` (the cover queue just ended) flushes at once and
    cancels the trailing timer, so the last covers never wait.
  * HOLD (optional third argument of request): `hold = true` says "more covers
    are about to land, wait for them". A request that would flush on the LEADING
    edge (first one, or after a full gap) is then kept pending instead and ONE
    hold timer of `hold_max` seconds is armed. The hold ends, flushing everything
    merged so far, when a later request arrives with `hold` false/nil or `final`,
    or when the timer fires (hard cap: a slow decode never holds the repaint
    back for longer than `hold_max`). Further `hold = true` requests while held
    are merged. A request inside the min_gap window behaves exactly as without
    hold (the trailing timer already bounds it). No `hold` anywhere = the old
    behaviour, request for request.

It has NO KOReader dependency: the clock and the timer are passed in, so it
can be tested off-device (tools/bo_tests/test_bo_covers.lua).

  local C = Coalesce.new{
    now        = function() return seconds end,
    schedule   = function(delay, fn) return handle end,
    unschedule = function(handle) end,
    min_gap    = 0.5,                       -- optional, default 0.5
    hold_max   = 1.0,                       -- optional, default 1.0 (cap of a hold)
    flush      = function(source_ids) end,  -- set: source_ids[id] = true
    logger     = optional, needs :dbg()
  }
  C:request(source_id, final, hold)  -> "flushed" | "scheduled" | "merged" | "held"
  C:cancel()
  C:stats() -> { requests = n, flushes = n }   (since the last reset)

A nil source id is stored under the key Coalesce.ANY ("*"): the flush callback
treats it as "unknown source, repaint to be safe", the same as the old
one-argument callback did.
]]

local Coalesce = {}
Coalesce.__index = Coalesce

Coalesce.ANY = "*"
Coalesce.DEFAULT_MIN_GAP = 0.5
Coalesce.DEFAULT_HOLD_MAX = 1.0

function Coalesce.new(deps)
    deps = deps or {}
    local self = setmetatable({}, Coalesce)
    self.now = deps.now
    self.schedule = deps.schedule
    self.unschedule = deps.unschedule
    self.min_gap = tonumber(deps.min_gap) or Coalesce.DEFAULT_MIN_GAP
    self.hold_max = tonumber(deps.hold_max) or Coalesce.DEFAULT_HOLD_MAX
    self.flush_cb = deps.flush
    self.logger = deps.logger
    self.pending = {}
    self.has_pending = false
    self.timer = nil
    self.hold_timer = nil
    self.last_flush = nil
    self.n_requests = 0
    self.n_flushes = 0
    return self
end

local function nowOf(self)
    local ok, t = pcall(self.now)
    return (ok and tonumber(t)) or 0
end

function Coalesce:_clearTimer()
    local handle = self.timer
    self.timer = nil
    if handle ~= nil and self.unschedule then
        pcall(self.unschedule, handle)
    end
    local hh = self.hold_timer
    self.hold_timer = nil
    if hh ~= nil and self.unschedule then
        pcall(self.unschedule, hh)
    end
end

function Coalesce:_flush()
    self:_clearTimer()
    local set = self.pending
    self.pending = {}
    local had = self.has_pending
    self.has_pending = false
    -- Stamped at the START too, so a request arriving while the flush runs
    -- (re-entrancy) already sees "just flushed"; re-stamped at the END below.
    self.last_flush = nowOf(self)
    if not had then return end
    self.n_flushes = self.n_flushes + 1
    if self.flush_cb then
        local ok, err = pcall(self.flush_cb, set)
        if not ok and self.logger and self.logger.dbg then
            pcall(self.logger.dbg, "[bookshelf] cover repaint flush failed", err)
        end
    end
    self.last_flush = nowOf(self)
end

--- Ask for a repaint. Returns what happened, for logs and tests.
function Coalesce:request(source_id, final, hold)
    self.n_requests = self.n_requests + 1
    local key = source_id
    if key == nil then key = Coalesce.ANY end
    self.pending[key] = true
    self.has_pending = true

    if final then
        self:_flush()
        return "flushed"
    end

    local now = nowOf(self)
    if self.last_flush == nil or (now - self.last_flush) >= self.min_gap then
        -- Leading edge. Held back only while the caller says more covers are
        -- about to land, and at most hold_max seconds.
        if hold and self.hold_max > 0 then
            if self.hold_timer ~= nil then return "merged" end
            local ok, handle = pcall(self.schedule, self.hold_max, function()
                -- Cap reached: forget the handle first (it already ran).
                self.hold_timer = nil
                if self.has_pending then self:_flush() end
            end)
            if ok and handle ~= nil then
                self.hold_timer = handle
                return "held"
            end
            -- No timer available: do not hold the repaint back at all.
        end
        self:_flush()
        return "flushed"
    end

    if self.timer ~= nil then return "merged" end

    local delay = self.min_gap - (now - self.last_flush)
    if delay < 0 then delay = 0 end
    local ok = self:_arm(delay)
    if not ok then
        -- No timer available: do not hold the repaint back forever.
        self:_flush()
        return "flushed"
    end
    return "scheduled"
end

-- Schedule the trailing flush. When it fires, the gap is re-checked against
-- the END of the latest flush (a slow flush that was still running when this
-- timer was armed moves last_flush forward); if the gap has not passed yet it
-- waits for the remainder instead of flushing at once.
function Coalesce:_arm(delay)
    local ok, handle = pcall(self.schedule, delay, function()
        -- The timer fired: forget the handle first so _flush does not try to
        -- unschedule a timer that already ran.
        self.timer = nil
        if not self.has_pending then return end
        local now = nowOf(self)
        if self.last_flush ~= nil and (now - self.last_flush) < self.min_gap - 1e-9 then
            local rest = self.min_gap - (now - self.last_flush)
            if self:_arm(rest) then return end
        end
        self:_flush()
    end)
    if not ok or handle == nil then return false end
    self.timer = handle
    return true
end

--- Drop pending state and any scheduled flush (widget torn down).
function Coalesce:cancel()
    self:_clearTimer()
    self.pending = {}
    self.has_pending = false
end

function Coalesce:stats()
    return { requests = self.n_requests, flushes = self.n_flushes }
end

return Coalesce
