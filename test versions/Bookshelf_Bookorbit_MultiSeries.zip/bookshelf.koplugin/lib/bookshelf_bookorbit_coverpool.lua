--[[--
Cover download pool for BookOrbit (pure logic, no KOReader dependency).

Problem (see HANDOFF_cover_speed): cover downloads ran as blocking HTTP calls
on the UI thread. This object runs them through forked workers instead, a few
at a time, and decodes the finished files back in the parent (a BlitBuffer
cannot cross a fork), one per tick.

Everything it touches is passed in, so it can be tested off-device with fake
forks and a fake clock (tools/bo_tests/test_bo_coverpool.lua). NOT wired into
the UI yet (Batch 3).

  local P = Pool.new{
    now = function() return seconds end,
    schedule = function(delay, fn) return handle end,   -- handle must be non-nil
    unschedule = function(handle) end,
    online = function() return bool end,
    exists = function(path) return bool end,
    describe = function(record) -> { key=, path=, part= } | nil,
    spawn = function(job) -> pid, fd | nil, err,
    is_done = function(pid) -> bool,
    readable = function(fd) -> bool,
    read = function(fd) -> string,
    kill = function(pid),
    remove = function(path),
    decode = function(job) -> bool,          -- fills every record in job.records
    mark_failed = function(key, why),
    on_landed = function(source_id, final, decode_left),
    on_fork_broken = function(records, source_id),  -- optional
    on_idle = function(had_landed),   -- optional: the chain drained (see rules)
    on_worker = function(info),   -- optional, log only: { key=, ms=, result= }
                                  -- result = "ok" | "nf:<why>" | "timeout" | "crash"
    width = 3, deadline = 25, logger = optional (needs :dbg)
  }

  P:enqueue(records, source_id) -> "queued" | "empty" | "fork_broken"
  P:cancel()          -- drop PENDING downloads only; in-flight and decode work go on
  P:cancelDecode()    -- drop the QUEUED decodes only (no callbacks); pending and in-flight go on
  P:shutdown()        -- kill in-flight workers, drop everything, no callbacks
  P:resetFailures()   -- forget give-ups and retry counts (manual refresh)
  P:status()          -- counts, for tests and logs

Rules (decisions C5-C11 in the handoff):
  * width starts at `width` (default 3), halves on a transport-like failure or
    a timeout (floor 1) and never widens again within one chain. A chain is
    the time from the first enqueue to the moment everything is drained.
  * A worker writes the file under its `part` name and renames it on success.
    The pool only trusts a result string "1" AND `exists(path)`. Any other
    result, a crash, or a timeout counts as a try for that key; the 2nd try
    gives up (mark_failed). "nf:<why>" is a definitive answer: the key is given
    up at once. A server saying no ("http_4xx", "not_an_image", "no_cover")
    does not narrow the width; "nf:offline" is dropped silently.
  * enqueue replaces only the PENDING list. A key already in flight or waiting
    for decode is kept and the new record objects are attached to the same job,
    so an in-flight download is never wasted by a page rebuild.
  * cancelDecode empties the decode queue (jobs whose file is on disk but not yet
    decoded) and nothing else: pending downloads and in-flight workers are not
    touched, a decode already done is not undone, and no callback fires. The chain
    end is still detected from the poll timer, so on_idle fires as usual. A key that
    was dropped can be enqueued again later. (Decode-ahead uses it so a stale page
    stops decoding when the user moves on; a download already in flight still lands
    and then queues its own decode.)
  * Callbacks (`on_landed`, `on_fork_broken`) are only ever fired from timers,
    never from enqueue/cancel/shutdown, so they can safely call back into the
    pool (the widget repaint rebuilds the shelf, which enqueues again).
  * `on_landed(source_id, false, decode_left)` after each decoded cover while more
    work remains; `on_landed(source_id, true, 0)` once per distinct source that
    landed something when the chain drains. `decode_left` is the number of jobs
    still waiting in the DECODE queue (files already on disk) after the decode
    that just landed; downloads pending or in flight are NOT counted, so a slow
    download never makes it look like decodes remain. Callbacks that take two
    arguments simply ignore it.
  * `on_idle(had_landed)` fires once when a chain drains, AFTER the on_landed(...,
    true) calls, whether or not anything landed (everything given up, or the
    pending list dropped because the device went offline). `had_landed` is true
    when at least one cover was decoded in that chain. Like the others it only
    fires from timers, never from enqueue/cancel/shutdown (shutdown stands the
    chain down silently), and it may enqueue again. Absent dep = no change.
  * Killed pids are re-checked every second until `is_done` says so (no zombie).
]]

local Pool = {}
Pool.__index = Pool

Pool.DEFAULT_WIDTH = 3
Pool.DEFAULT_DEADLINE = 25
Pool.POLL = 0.15
Pool.FIRST_POLL = 0.02     -- first launch after an enqueue, then every POLL
Pool.DECODE_TICK = 0.02
Pool.REAP_TICK = 1
Pool.MAX_TRIES = 2
Pool.OK = "1"
Pool.FAIL_PREFIX = "nf:"

-- Reasons where the SERVER answered and said "no": not a width problem.
local function serverSaysNo(why)
    why = tostring(why or "")
    return why:match("^http_4%d%d$") ~= nil or why == "not_an_image" or why == "no_cover"
end

function Pool.new(deps)
    deps = deps or {}
    local self = setmetatable({}, Pool)
    self.d = deps
    self.base_width = math.max(1, math.floor(tonumber(deps.width) or Pool.DEFAULT_WIDTH))
    self.deadline = tonumber(deps.deadline) or Pool.DEFAULT_DEADLINE
    self.cap = self.base_width
    self.pending = {}          -- jobs waiting for a worker, in order
    self.pending_by_key = {}
    self.in_flight = {}        -- { pid=, fd=, job=, t0= }
    self.in_flight_by_key = {} -- key -> job
    self.decode_q = {}         -- jobs whose file is on disk, waiting for decode
    self.decode_by_key = {}
    self.reap = {}             -- pids that must still be collected
    self.tries = {}            -- key -> failed tries this session
    self.gave_up = {}          -- key -> true
    self.chain_active = false
    self.landed_total = 0
    self.landed_order = {}     -- distinct source ids that landed, in order
    self.landed_seen = {}
    self.fork_broken = false
    self.poll_h, self.decode_h, self.reap_h = nil, nil, nil
    return self
end

-- Safe call into a dep: never throws. Returns ok, a, b.
local function call(self, name, ...)
    local fn = self.d[name]
    if type(fn) ~= "function" then return false end
    return pcall(fn, ...)
end

local function nowOf(self)
    local ok, t = call(self, "now")
    return (ok and tonumber(t)) or 0
end

local function dbg(self, ...)
    local lg = self.d.logger
    if lg and lg.dbg then pcall(lg.dbg, ...) end
end

-- Per-worker timing (C22): spawn to result, for the log only. Never throws.
local function workerDone(self, e, result)
    if type(self.d.on_worker) ~= "function" then return end
    local ms = (nowOf(self) - (e.t0 or 0)) * 1000
    call(self, "on_worker", { key = e.job and e.job.key, ms = ms, result = result })
end

local function removeFirst(list, item)
    for i = 1, #list do
        if list[i] == item then table.remove(list, i); return true end
    end
    return false
end

-- Attach a record object to an existing job (identity-deduped).
local function addRecord(job, rec)
    if not job.rec_set[rec] then
        job.rec_set[rec] = true
        job.records[#job.records + 1] = rec
    end
end

-- Timers -----------------------------------------------------------------------

function Pool:_sched(fieldname, delay, fn)
    if self[fieldname] ~= nil then return end
    local ok, h = call(self, "schedule", delay, function()
        self[fieldname] = nil
        fn(self)
    end)
    if ok and h ~= nil then self[fieldname] = h end
end

function Pool:_unsched(fieldname)
    local h = self[fieldname]
    self[fieldname] = nil
    if h ~= nil then call(self, "unschedule", h) end
end

function Pool:_ensureTimers()
    if self.chain_active then self:_sched("poll_h", Pool.POLL, Pool._poll) end
    if #self.decode_q > 0 then self:_sched("decode_h", Pool.DECODE_TICK, Pool._decodeTick) end
    if #self.reap > 0 then self:_sched("reap_h", Pool.REAP_TICK, Pool._reapTick) end
end

-- Zombie control ------------------------------------------------------------------

function Pool:_reapLater(pid)
    if pid == nil then return end
    self.reap[#self.reap + 1] = pid
end

function Pool:_reapTick()
    local keep = {}
    for _, pid in ipairs(self.reap) do
        local ok, done = call(self, "is_done", pid)
        if not (ok and done) then keep[#keep + 1] = pid end
    end
    self.reap = keep
    self:_ensureTimers()
end

-- Job bookkeeping -------------------------------------------------------------------

function Pool:_narrow()
    local n = math.max(1, math.floor(self.cap / 2))
    if n < self.cap then
        dbg(self, "[bookshelf perf] bo covers: pool narrowed", self.cap, "->", n)
    end
    self.cap = n
end

function Pool:_giveUp(job, why)
    self.gave_up[job.key] = true
    call(self, "mark_failed", job.key, why)
    dbg(self, "[bookshelf] bo covers: gave up on", job.key, tostring(why))
end

-- A try that did not work. Requeue (at the end) or give up on the 2nd failure.
function Pool:_failTransient(job, why, narrow)
    if narrow then self:_narrow() end
    local n = (self.tries[job.key] or 0) + 1
    self.tries[job.key] = n
    if n >= Pool.MAX_TRIES then
        self:_giveUp(job, why)
        return
    end
    if not self.pending_by_key[job.key] then
        self.pending[#self.pending + 1] = job
        self.pending_by_key[job.key] = job
    end
end

function Pool:_toDecode(job, front)
    if self.decode_by_key[job.key] then return end
    if front then table.insert(self.decode_q, 1, job)
    else self.decode_q[#self.decode_q + 1] = job end
    self.decode_by_key[job.key] = job
end

-- Public: enqueue / cancel / shutdown ---------------------------------------------------

function Pool:enqueue(records, source_id)
    if self.fork_broken then return "fork_broken" end
    -- Supersede: only the PENDING list is replaced.
    self.pending, self.pending_by_key = {}, {}

    local fresh_decode = {}
    local fresh_decode_by_key = {}   -- same-key disk hits within THIS call
    local fresh_pending = {}
    local added = 0
    for _, rec in ipairs(records or {}) do
        local okd, d = call(self, "describe", rec)
        if okd and type(d) == "table" and d.key ~= nil and d.path and not self.gave_up[d.key] then
            local existing = self.in_flight_by_key[d.key]
                or self.decode_by_key[d.key]
                or self.pending_by_key[d.key]
                or fresh_decode_by_key[d.key]
            if existing then
                addRecord(existing, rec)
            else
                local job = {
                    key = d.key, path = d.path, part = d.part,
                    records = { rec }, rec_set = { [rec] = true },
                    source_id = source_id,
                }
                local oke, there = call(self, "exists", d.path)
                if oke and there then
                    fresh_decode[#fresh_decode + 1] = job
                    fresh_decode_by_key[job.key] = job
                else
                    fresh_pending[#fresh_pending + 1] = job
                    self.pending_by_key[job.key] = job
                end
                added = added + 1
            end
        end
    end
    -- New disk hits decode ahead of older queued decodes (they are the page on screen).
    for i = #fresh_decode, 1, -1 do self:_toDecode(fresh_decode[i], true) end
    self.pending = fresh_pending

    if added == 0 and not self.chain_active then return "empty" end
    self.chain_active = true
    self:_sched("poll_h", Pool.FIRST_POLL, Pool._poll)
    self:_ensureTimers()
    return "queued"
end

--- Drop PENDING downloads only (C7). Never fires callbacks.
function Pool:cancel()
    self.pending, self.pending_by_key = {}, {}
    self:_ensureTimers()   -- the chain end is still detected on the next poll
end

--- Drop the QUEUED decodes only. Never fires callbacks; pending downloads and
-- in-flight workers are untouched. The chain end is still seen by the next poll.
function Pool:cancelDecode()
    self.decode_q, self.decode_by_key = {}, {}
    self:_unsched("decode_h")
    self:_ensureTimers()   -- chain_active keeps the poll timer, which ends the chain
end

--- Kill everything and stand down. Never fires callbacks.
function Pool:shutdown()
    for _, e in ipairs(self.in_flight) do
        call(self, "kill", e.pid)
        if e.fd then call(self, "read", e.fd) end
        if e.job.part then call(self, "remove", e.job.part) end
        self:_reapLater(e.pid)
    end
    self.in_flight, self.in_flight_by_key = {}, {}
    self.pending, self.pending_by_key = {}, {}
    self.decode_q, self.decode_by_key = {}, {}
    self:_unsched("poll_h")
    self:_unsched("decode_h")
    self.chain_active = false
    self.landed_total, self.landed_order, self.landed_seen = 0, {}, {}
    self.cap = self.base_width
    self:_ensureTimers()   -- keep the reaper alive until every pid is collected
end

function Pool:resetFailures()
    self.tries, self.gave_up = {}, {}
end

function Pool:status()
    return {
        pending = #self.pending, in_flight = #self.in_flight, decode = #self.decode_q,
        reaping = #self.reap, cap = self.cap, landed = self.landed_total,
        fork_broken = self.fork_broken, chain_active = self.chain_active,
    }
end

-- Poll: collect finished workers, enforce the deadline, launch new ones ---------------------

function Pool:_finishEntry(e, out, done)
    self.in_flight_by_key[e.job.key] = nil
    removeFirst(self.in_flight, e)
    local job = e.job
    if not done then self:_reapLater(e.pid) end

    if out == Pool.OK then
        workerDone(self, e, "ok")
        local ok, there = call(self, "exists", job.path)
        if ok and there then
            self:_toDecode(job)
        else
            if job.part then call(self, "remove", job.part) end
            self:_failTransient(job, "missing", true)
        end
        return
    end
    if type(out) == "string" and out:sub(1, #Pool.FAIL_PREFIX) == Pool.FAIL_PREFIX then
        local why = out:sub(#Pool.FAIL_PREFIX + 1)
        workerDone(self, e, Pool.FAIL_PREFIX .. why)
        if job.part then call(self, "remove", job.part) end
        if why == "offline" then return end            -- not a failure of the cover
        if not serverSaysNo(why) then self:_narrow() end
        self:_giveUp(job, why)
        return
    end
    -- Empty or unknown result from a finished worker: it crashed.
    workerDone(self, e, "crash")
    if job.part then call(self, "remove", job.part) end
    self:_failTransient(job, "crash", true)
end

function Pool:_collect()
    local now = nowOf(self)
    local snapshot = {}
    for i, e in ipairs(self.in_flight) do snapshot[i] = e end
    for _, e in ipairs(snapshot) do
        local okd, done = call(self, "is_done", e.pid)
        done = okd and done and true or false
        local readable = false
        if e.fd then
            local okr, r = call(self, "readable", e.fd)
            readable = okr and r and true or false
        end
        if done or readable then
            local out = ""
            if e.fd then
                local okx, got = call(self, "read", e.fd)
                if okx and type(got) == "string" then out = got end
            end
            if out ~= "" or done then
                self:_finishEntry(e, out, done)
            end
        elseif (now - e.t0) > self.deadline then
            -- Hard deadline: kill, drop the half-written file, count a try.
            workerDone(self, e, "timeout")
            call(self, "kill", e.pid)
            if e.fd then call(self, "read", e.fd) end
            if e.job.part then call(self, "remove", e.job.part) end
            self.in_flight_by_key[e.job.key] = nil
            removeFirst(self.in_flight, e)
            self:_reapLater(e.pid)
            self:_failTransient(e.job, "timeout", true)
        end
    end
end

function Pool:_launch()
    if not self.chain_active then return end
    local okn, on = call(self, "online")
    if not (okn and on) then
        -- Offline: never launch, drop what was waiting. Not a failure.
        self.pending, self.pending_by_key = {}, {}
        return
    end
    while #self.in_flight < self.cap and #self.pending > 0 and not self.fork_broken do
        local job = table.remove(self.pending, 1)
        self.pending_by_key[job.key] = nil
        local oke, there = call(self, "exists", job.path)
        if oke and there then
            self:_toDecode(job)          -- it arrived meanwhile (another pass)
        else
            local oks, pid, fd = call(self, "spawn", job)
            if not (oks and pid) then
                -- No fork available: hand EVERYTHING still waiting back to the caller.
                self.fork_broken = true
                local recs, sid = {}, job.source_id
                for _, r in ipairs(job.records) do recs[#recs + 1] = r end
                for _, j in ipairs(self.pending) do
                    for _, r in ipairs(j.records) do recs[#recs + 1] = r end
                end
                self.pending, self.pending_by_key = {}, {}
                self._broken_payload = { records = recs, source_id = sid }
                break
            end
            local e = { pid = pid, fd = fd, job = job, t0 = nowOf(self) }
            self.in_flight[#self.in_flight + 1] = e
            self.in_flight_by_key[job.key] = job
        end
    end
end

function Pool:_idleCheck()
    if not self.chain_active then return end
    if #self.pending > 0 or #self.in_flight > 0 or #self.decode_q > 0 then return end
    -- Chain drained. Reset BEFORE the callbacks: they may enqueue again.
    local order = self.landed_order
    self.chain_active = false
    self.landed_total, self.landed_order, self.landed_seen = 0, {}, {}
    self.cap = self.base_width
    self:_unsched("poll_h")
    for _, box in ipairs(order) do
        call(self, "on_landed", box.id, true, 0)
    end
    call(self, "on_idle", #order > 0)
end

function Pool:_poll()
    self:_collect()
    self:_launch()
    if self._broken_payload then
        local payload = self._broken_payload
        self._broken_payload = nil
        call(self, "on_fork_broken", payload.records, payload.source_id)
    end
    self:_idleCheck()
    self:_ensureTimers()
end

-- Decode: one cover per tick, in the parent ---------------------------------------------------

function Pool:_decodeTick()
    local job = table.remove(self.decode_q, 1)
    if job then
        self.decode_by_key[job.key] = nil
        local ok, res = call(self, "decode", job)
        if ok and res then
            self.landed_total = self.landed_total + 1
            local sid = job.source_id
            local seen_key = sid == nil and "\0nil" or sid
            if not self.landed_seen[seen_key] then
                self.landed_seen[seen_key] = true
                self.landed_order[#self.landed_order + 1] = { id = sid }   -- boxed: sid may be nil
            end
            local more = #self.pending > 0 or #self.in_flight > 0 or #self.decode_q > 0
            if more then call(self, "on_landed", sid, false, #self.decode_q) end
        else
            -- Bad file (decode removes it): download it again once, then give up.
            self:_failTransient(job, "decode", false)
        end
    end
    self:_idleCheck()
    self:_ensureTimers()
end

return Pool
