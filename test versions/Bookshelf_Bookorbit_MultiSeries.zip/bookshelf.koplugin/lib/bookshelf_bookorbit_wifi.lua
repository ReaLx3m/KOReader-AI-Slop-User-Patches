-- bookshelf_bookorbit_wifi.lua
-- Auto Wi-Fi controller: one place that decides when the radio goes on and
-- off for BookOrbit sync and browsing. Replaces the old per-trigger helpers
-- (withWifiGate in bookshelf_bookorbit.lua, _tryAutoConnect in
-- bookshelf_bookorbit_source.lua), which each decided ownership on their
-- own and could turn Wi-Fi off under one another.
--
-- Model
--   * Settings (read through injected callbacks, see Wifi.get):
--       enabled()      the parent "Auto Wi-Fi" switch
--       off_in_book()  sub-setting 1: off while a book is open
--   * Leases: a job that needs the network (a sync push/pull) takes one
--     with acquire() and gives it back with release(). The radio is only
--     turned off when the last lease is gone, so overlapping jobs never cut
--     each other off.
--   * Steady state ("wants on"): enabled, not manually switched off, and
--     not (a book is open and off_in_book is on). trigger() brings Wi-Fi up
--     for that state with a bounded number of attempts (see RETRY_DELAYS).
--   * Manual off: if the radio goes off without us asking (the user toggled
--     it), manual_off is set and nothing reconnects until the next trigger
--     (trigger(), or acquire(..., { trigger = true })), or until Wi-Fi comes
--     back by other means (onNetworkConnected).
--
-- Triggers (callers wire these): startup / home shown, book closed and
-- returning to home, wake while home is showing, "Sync now", sleep sync.
-- Browsing a BookOrbit chip is deliberately NOT a trigger, otherwise a
-- manual off would never stay off on the home screen.
--
-- Everything external (NetworkMgr, UIManager, settings, hooks) is injected
-- through Wifi.new so the logic runs off-device in tools/bo_tests/test_bo_wifi.lua.
-- Time is counted in poll ticks driven by UIManager:scheduleIn, not by a
-- clock, so tests advance it with a fake scheduler.
--
-- Not yet run on a device. In particular the exact NetworkMgr calls
-- (turnOnWifi's signature, what runWhenOnline does on failure) are still to
-- be verified against KOReader's source -- see the handoff, section 7.

local Wifi = {}
Wifi.__index = Wifi

-- Seconds between connectivity checks while a connect is in flight.
Wifi.POLL_INTERVAL = 1
-- Default time a lease waits for the connection before on_fail("timeout").
Wifi.DEFAULT_LEASE_TIMEOUT = 30
-- How long one steady-state connect attempt runs before it counts as failed.
Wifi.ATTEMPT_WINDOW = 25
-- Waits before attempt 2, 3 and 4 after a failed attempt; then give up until
-- the next trigger. (Attempt 1 is immediate, so: 0 s, 30 s, 60 s, 120 s.)
Wifi.RETRY_DELAYS = { 30, 60, 120 }
-- A programmatic turnOffWifi() may produce a NetworkDisconnected broadcast a
-- little later; ignore broadcasts inside this window instead of mistaking
-- them for the user switching Wi-Fi off.
Wifi.EXPECTED_OFF_WINDOW = 10

--- Wifi.new(deps) -> controller
-- deps.network   NetworkMgr-like: isOnline, isWifiOn, turnOffWifi, and
--                turnOnWifi(cb, interactive) or runWhenOnline(cb)
-- deps.ui        UIManager-like: scheduleIn(seconds, fn), unschedule(fn)
-- deps.settings  { enabled = fn, off_in_book = fn }
-- deps.settings.can_restore  optional fn -> bool: Device:hasWifiRestore()
-- deps.hooks     optional { notify_wifi_off = fn, on_online = fn }
-- deps.logger    optional
function Wifi.new(deps)
    assert(deps and deps.network and deps.ui, "Wifi.new needs network and ui")
    local self = setmetatable({}, Wifi)
    self.net      = deps.network
    self.ui       = deps.ui
    self.cfg      = deps.settings or {}
    self.hooks    = deps.hooks or {}
    self.logger   = deps.logger

    self.leases       = {}     -- live leases, oldest first
    self.count        = 0      -- live leases (pending + ready)
    self.manual_off   = false
    self.book_open    = false
    self.expected_off = false
    -- Sleep sync (batch 5): set while the device is going to sleep with a
    -- lease that asked for off_when_done. Steady state then wants Wi-Fi OFF
    -- (otherwise the home/in-book "keep it on" target would reconnect it
    -- under the suspend); cleared by the next trigger().
    self.sleeping     = false
    self.off_pending  = false  -- a released lease asked for the radio off

    self.connecting      = false  -- a connect is in flight (poll timer running)
    self.attempt_active  = false  -- the in-flight connect serves steady state
    self.attempt_deadline = nil   -- tick at which that attempt gives up
    self.ticks           = 0
    self.retry_step      = 0
    self.retry_pending   = false
    self.poll_pending    = false

    self.stats = { attempts = 0, turn_on_calls = 0, turn_off_calls = 0 }

    -- Stable function identities so UIManager:unschedule can find them.
    self._tick_fn           = function() self:_tick() end
    self._retry_fn          = function() self:_retry() end
    self._expected_clear_fn = function() self.expected_off = false end
    return self
end

-- -------------------------------------------------------------------------
-- small helpers
-- -------------------------------------------------------------------------

function Wifi:_log(level, ...)
    local lg = self.logger
    if lg and lg[level] then pcall(lg[level], ...) end
end

--- Run a caller-supplied callback; a throwing callback must never break the
-- controller's own bookkeeping.
function Wifi:_call(fn, ...)
    if not fn then return end
    local ok, err = pcall(fn, ...)
    if not ok then self:_log("warn", "[bookshelf] auto-wifi callback failed:", err) end
end

function Wifi:_enabled()
    local f = self.cfg.enabled
    return (f and f() and true) or false
end

function Wifi:_offInBook()
    if not self:_enabled() then return false end
    local f = self.cfg.off_in_book
    return (f and f() and true) or false
end

function Wifi:_online()
    local ok, v = pcall(function() return self.net:isOnline() end)
    return (ok and v and true) or false
end

function Wifi:_radioOn()
    local ok, v = pcall(function() return self.net:isWifiOn() end)
    return (ok and v and true) or false
end

--- Steady-state target: should Wi-Fi be up right now?
function Wifi:wantsOn()
    if not self:_enabled() then return false end
    if self.manual_off then return false end
    if self.book_open and self:_offInBook() then return false end
    if self.sleeping then return false end
    return true
end

--- True while Auto Wi-Fi manages the radio. Callers use it to bypass the
-- "Skip when offline" option (Auto Wi-Fi wins over it).
function Wifi:shouldBypassSkipOffline()
    return self:_enabled()
end

function Wifi:status()
    return {
        enabled = self:_enabled(), manual_off = self.manual_off,
        book_open = self.book_open, leases = self.count, sleeping = self.sleeping,
        connecting = self.connecting, retry_step = self.retry_step,
        attempts = self.stats.attempts,
    }
end

-- -------------------------------------------------------------------------
-- connect machinery
-- -------------------------------------------------------------------------

function Wifi:_schedulePoll()
    if self.poll_pending then return end
    self.poll_pending = true
    self.ui:scheduleIn(Wifi.POLL_INTERVAL, self._tick_fn)
end

function Wifi:_cancelPoll()
    if self.poll_pending then
        self.ui:unschedule(self._tick_fn)
        self.poll_pending = false
    end
end

function Wifi:_cancelRetry()
    if self.retry_pending then
        self.ui:unschedule(self._retry_fn)
        self.retry_pending = false
    end
end

--- Ask the platform to bring the radio up WITHOUT popping the network
-- picker or blocking the UI. The callback only nudges a re-check: success is
-- always confirmed by isOnline(), never by the callback alone.
--
-- Verified against KOReader v2025.08 and master (batch 4 research):
--   * The raw backend turnOnWifi() is NOT meant to be called directly. It
--     skips NetworkMgr's bookkeeping (pending_connection, the
--     NetworkConnecting/NetworkConnected events, wifi_was_on) and, when the
--     connect fails, nobody tears the radio back down (enableWifi does that
--     on a `false` return). The earlier batch called it directly; fixed here.
--   * restoreWifiAsync() is the quiet path KOReader itself uses to bring
--     Wi-Fi back at start-up: it runs a background script (Kobo: enable the
--     radio, wait up to ~15 s for wpa_supplicant to join a KNOWN network,
--     else switch the radio off again by itself) and never shows UI or
--     blocks the event loop. Out of range of any known network it simply
--     gives up quietly, which is exactly the D5 behaviour. Kindle's version
--     just enables the radio and lets the framework reconnect.
--   * Fallback (no Wi-Fi restore support): enableWifi(cb, false), the
--     supported non-interactive wrapper. On Kobo that call blocks while it
--     scans and shows KOReader's own "Scanning for networks" notices.
function Wifi:_turnOn()
    local net = self.net
    self.stats.turn_on_calls = self.stats.turn_on_calls + 1
    local nudge = function() self:_pollNow() end
    local can_restore = self.cfg.can_restore and self.cfg.can_restore()
    if can_restore and type(net.restoreWifiAsync) == "function" then
        local ok, err = pcall(function()
            net:restoreWifiAsync()
            -- Same pairing NetworkMgr:init uses: a connectivity check makes
            -- KOReader broadcast NetworkConnected (and set wifi_was_on) when
            -- the link comes up, and abort the attempt if it never does.
            if type(net.scheduleConnectivityCheck) == "function" then
                if net.pending_connectivity_check and type(net.unscheduleConnectivityCheck) == "function" then
                    net:unscheduleConnectivityCheck()
                end
                net:scheduleConnectivityCheck()
            end
        end)
        if not ok then self:_log("warn", "[bookshelf] auto-wifi restoreWifiAsync failed:", err) end
    elseif type(net.enableWifi) == "function" then
        local ok, err = pcall(function() net:enableWifi(nudge, false) end)
        if not ok then self:_log("warn", "[bookshelf] auto-wifi enableWifi failed:", err) end
    elseif type(net.turnOnWifi) == "function" then
        -- Bare backend (older builds / test doubles). See the note above.
        local ok, err = pcall(function() net:turnOnWifi(nudge, false) end)
        if not ok then self:_log("warn", "[bookshelf] auto-wifi turnOnWifi failed:", err) end
    elseif type(net.runWhenOnline) == "function" then
        -- Last resort. May show the network picker; nothing better to call.
        local ok, err = pcall(function() net:runWhenOnline(nudge) end)
        if not ok then self:_log("warn", "[bookshelf] auto-wifi runWhenOnline failed:", err) end
    end
end

function Wifi:_startConnect()
    if self.connecting then return end
    self.connecting = true
    if not self:_radioOn() then
        self:_turnOn()
    end
    -- _turnOn's callback may already have finished the connect.
    if self.connecting then self:_schedulePoll() end
end

function Wifi:_pendingLeases()
    local out = {}
    for _i, l in ipairs(self.leases) do
        if l.state == "pending" then out[#out + 1] = l end
    end
    return out
end

function Wifi:_removeLease(lease)
    for i, l in ipairs(self.leases) do
        if l == lease then table.remove(self.leases, i) break end
    end
end

--- Fail one pending lease (timeout / manual off).
function Wifi:_failLease(lease, err)
    if lease.released then return end
    lease.released = true
    self:_removeLease(lease)
    self.count = self.count - 1
    if lease.off_when_done then self.off_pending = true end
    self:_call(lease.on_fail, err)
end

--- Fail pending leases past their deadline; true if any are still waiting.
function Wifi:_expireLeases()
    local expired = {}
    local waiting = false
    for _i, l in ipairs(self:_pendingLeases()) do
        if l.deadline and l.deadline <= self.ticks then
            expired[#expired + 1] = l
        else
            waiting = true
        end
    end
    for _i, l in ipairs(expired) do self:_failLease(l, "timeout") end
    return waiting
end

--- One connectivity check (no tick advance).
function Wifi:_check()
    if not self.connecting then return end
    if self:_online() then return self:_finishConnect(true) end
    local waiting = self:_expireLeases()
    local attempt_live = self.attempt_active and self.attempt_deadline
        and self.attempt_deadline > self.ticks
    if not waiting and not attempt_live then
        return self:_finishConnect(false)
    end
    self:_schedulePoll()
end

function Wifi:_tick()
    self.poll_pending = false
    if not self.connecting then return end
    self.ticks = self.ticks + 1
    self:_check()
end

--- Called from turnOnWifi's callback: re-check now instead of waiting for
-- the next poll tick.
function Wifi:_pollNow()
    if not self.connecting then return end
    self:_cancelPoll()
    self:_check()
end

function Wifi:_finishConnect(ok)
    local was_attempt = self.attempt_active
    self.connecting = false
    self.attempt_active = false
    self.attempt_deadline = nil
    self:_cancelPoll()

    if ok then
        self.retry_step = 0
        self:_cancelRetry()
        -- Mark every pending lease ready first, then call out: a callback
        -- may release its lease or take a new one.
        local ready = self:_pendingLeases()
        for _i, l in ipairs(ready) do l.state = "ready" end
        for _i, l in ipairs(ready) do
            if not l.released then self:_call(l.on_ready) end
        end
        self:_call(self.hooks.on_online)
        self:reconcile()
    else
        if was_attempt then self:_scheduleRetry() end
        -- A lease that timed out may have been the only thing holding the
        -- radio up while the state wants it off (book open + off_in_book):
        -- let reconcile turn it off now. Not done when the state wants it
        -- ON, so a failed lease cannot skip the retry backoff above.
        if not self:wantsOn() then self:reconcile() end
    end
end

-- -------------------------------------------------------------------------
-- steady-state attempts with backoff
-- -------------------------------------------------------------------------

function Wifi:_beginAttempt()
    self.stats.attempts = self.stats.attempts + 1
    self.attempt_active = true
    self.attempt_deadline = self.ticks + math.ceil(Wifi.ATTEMPT_WINDOW / Wifi.POLL_INTERVAL)
    self:_startConnect()
end

function Wifi:_scheduleRetry()
    if not self:wantsOn() then return end
    local delay = Wifi.RETRY_DELAYS[self.retry_step + 1]
    if not delay then return end            -- out of attempts: wait for a trigger
    self.retry_step = self.retry_step + 1
    self.retry_pending = true
    self.ui:scheduleIn(delay, self._retry_fn)
end

function Wifi:_retry()
    self.retry_pending = false
    if self:wantsOn() and not self:_online() and not self.connecting then
        self:_beginAttempt()
    end
end

-- -------------------------------------------------------------------------
-- reconcile: move the radio toward the steady state
-- -------------------------------------------------------------------------

--- Bring the radio toward the target state. Safe to call at any time.
function Wifi:reconcile()
    if not self:_enabled() then return end
    if self:wantsOn() then
        if self:_online() then return end
        if self.connecting then
            -- A lease connect is already running: let it also serve the
            -- steady state, with its own window.
            if not self.attempt_active then
                self.attempt_active = true
                self.attempt_deadline = self.ticks + math.ceil(Wifi.ATTEMPT_WINDOW / Wifi.POLL_INTERVAL)
            end
            return
        end
        if self.retry_pending then return end   -- a retry is already queued
        self:_beginAttempt()
        return
    end

    -- Does not want it on. Stop trying to connect for the steady state.
    self.attempt_active = false
    self.attempt_deadline = nil
    self:_cancelRetry()
    -- Only the "book open + off_in_book" case turns the radio off here; a
    -- manual off is already off, and a disabled feature never gets here.
    if self.book_open and self:_offInBook() and self.count == 0 then
        if self:_radioOn() or self:_online() then self:_turnOff() end
    elseif self.off_pending and self.count == 0 then
        -- A sleep-sync lease brought Wi-Fi up (KOReader had switched it off
        -- for the suspend): put it back, whatever the in-book setting says.
        if self:_radioOn() or self:_online() then self:_turnOff() end
    end
    if self.count == 0 then self.off_pending = false end
end

function Wifi:_turnOff()
    self.stats.turn_off_calls = self.stats.turn_off_calls + 1
    -- Tell onNetworkDisconnected this one is ours, not the user's. The flag
    -- clears on the first matching broadcast or after a short window.
    self.expected_off = true
    self.ui:unschedule(self._expected_clear_fn)
    self.ui:scheduleIn(Wifi.EXPECTED_OFF_WINDOW, self._expected_clear_fn)
    -- disableWifi is KOReader's supported way: unlike a bare turnOffWifi() it
    -- also cancels a pending connectivity check and a still-running
    -- restore-wifi script, and sends NetworkDisconnecting/Disconnected.
    local net = self.net
    local ok, err = pcall(function()
        if type(net.disableWifi) == "function" then net:disableWifi()
        else net:turnOffWifi() end
    end)
    if not ok then self:_log("warn", "[bookshelf] auto-wifi turn-off failed:", err) end
    -- NetworkMgr's own NetworkDisconnected broadcast is not reliable after a
    -- programmatic turn-off, so the shelf's Wi-Fi icon is refreshed through
    -- an explicit hook (see bookshelf_bookorbit_source.lua notifyWifiOff).
    self:_call(self.hooks.notify_wifi_off)
end

-- -------------------------------------------------------------------------
-- public API
-- -------------------------------------------------------------------------

--- trigger(reason): clear a manual off and bring Wi-Fi to the steady state.
-- reason is only for logs/tests. No-op while the feature is disabled.
function Wifi:trigger(reason)
    if not self:_enabled() then return end
    self:_log("dbg", "[bookshelf] auto-wifi trigger:", reason)
    self.manual_off = false
    self.sleeping = false
    self.retry_step = 0
    self:_cancelRetry()
    self:reconcile()
end

--- acquire(reason, on_ready, on_fail, opts) -> lease | nil
-- Ask for the network for one job. on_ready() runs once online (immediately
-- if already online); on_fail(err) runs with "timeout" or "manual_off" when
-- it will not come up. Call release(lease) when the job is done, success or
-- failure alike. opts: { timeout = seconds, trigger = bool,
-- off_when_done = bool }. off_when_done is for the sleep sync: the radio is
-- switched off again when the last lease is gone and Wi-Fi is not
-- reconnected behind the suspend (see `sleeping`).
--   * Feature disabled: on_ready() runs at once and nil is returned, so the
--     job goes ahead (and queues itself if it turns out to be offline).
--   * manual_off and still offline: on_fail("manual_off") unless
--     opts.trigger (an explicit user action such as "Sync now") clears it.
function Wifi:acquire(reason, on_ready, on_fail, opts)
    opts = opts or {}
    if not self:_enabled() then
        self:_call(on_ready)
        return nil
    end
    if opts.trigger then self.manual_off = false end
    if self.manual_off then
        if self:_online() then
            self.manual_off = false        -- the user turned Wi-Fi back on
        else
            self:_call(on_fail, "manual_off")
            return nil
        end
    end

    local lease = { reason = reason, on_ready = on_ready, on_fail = on_fail,
                    state = "pending", released = false,
                    off_when_done = opts.off_when_done and true or false }
    if lease.off_when_done then
        -- Going to sleep: stop any steady-state attempt/retry that is still
        -- running, so only this lease decides how long the radio stays up.
        self.sleeping = true
        self.attempt_active = false
        self.attempt_deadline = nil
        self:_cancelRetry()
    end
    self.leases[#self.leases + 1] = lease
    self.count = self.count + 1

    if self:_online() then
        lease.state = "ready"
        self:_call(on_ready)
        return lease
    end
    local timeout = tonumber(opts.timeout) or Wifi.DEFAULT_LEASE_TIMEOUT
    lease.deadline = self.ticks + math.ceil(timeout / Wifi.POLL_INTERVAL)
    self:_startConnect()
    return lease
end

--- release(lease): idempotent; nil is fine. When the last lease goes, the
-- radio may be turned off (only while a book is open with off_in_book).
function Wifi:release(lease)
    if not lease or lease.released then return end
    lease.released = true
    self:_removeLease(lease)
    self.count = self.count - 1
    if lease.off_when_done then self.off_pending = true end
    self:reconcile()
end

--- A book was opened. Call AFTER acquiring any open-time lease (the pull
-- on open), otherwise Wi-Fi could be turned off before the pull gets it.
function Wifi:noteBookOpened()
    self.book_open = true
    self:reconcile()
end

--- A book was closed. returning_home = false means KOReader is only handing
-- over to another book: do nothing then, to avoid an off/on flip between
-- the two. Returning home is a trigger.
function Wifi:noteBookClosed(returning_home)
    if not returning_home then return end
    self.book_open = false
    self:trigger("book_closed")
end

--- NetworkDisconnected broadcast (and our own explicit hook calls). Decides
-- whether the user switched Wi-Fi off.
function Wifi:onNetworkDisconnected()
    if self.expected_off then
        -- Ours. Consume it.
        self.expected_off = false
        self.ui:unschedule(self._expected_clear_fn)
        return
    end
    if not self:_enabled() then return end
    -- Mid-connect broadcasts come from the platform's own bring-up; ignore.
    -- (If the user really switches it off mid-connect, pending leases simply
    -- run into their timeout and the next trigger starts clean.)
    if self.connecting then return end
    -- Radio still on (out of range, access point gone): not a manual off.
    if self:_radioOn() then return end
    self.manual_off = true
    self:_cancelRetry()
    self.attempt_active = false
    self.attempt_deadline = nil
    for _i, l in ipairs(self:_pendingLeases()) do
        self:_failLease(l, "manual_off")
    end
end

--- NetworkConnected broadcast: Wi-Fi is up (by us or by the user), so a
-- manual off no longer applies.
function Wifi:onNetworkConnected()
    self.manual_off = false
    self:_pollNow()
end

-- -------------------------------------------------------------------------
-- default instance wired to the real KOReader modules
-- -------------------------------------------------------------------------

local _default

--- The process-wide controller. Built lazily; all lookups of other plugin
-- modules go through pcall so a load-order problem degrades to "feature
-- off" instead of an error.
function Wifi.get()
    if _default then return _default end
    local NetworkMgr = require("ui/network/manager")
    local UIManager  = require("ui/uimanager")
    local ok_lg, logger = pcall(require, "logger")

    local function bookorbit()
        local ok, m = pcall(require, "lib/bookshelf_bookorbit")
        return ok and m or nil
    end
    local function source()
        local ok, m = pcall(require, "lib/bookshelf_bookorbit_source")
        return ok and m or nil
    end

    _default = Wifi.new{
        network = NetworkMgr,
        ui      = UIManager,
        logger  = ok_lg and logger or nil,
        settings = {
            enabled = function()
                local b = bookorbit()
                return b and b.autoWifiEnabled and b.autoWifiEnabled() or false
            end,
            off_in_book = function()
                local b = bookorbit()
                return b and b.autoWifiOffInBook and b.autoWifiOffInBook() or false
            end,
            -- Quiet, non-blocking reconnect where the platform supports it
            -- (Kobo, Kindle): see Wifi:_turnOn.
            can_restore = function()
                local ok, Device = pcall(require, "device")
                if not (ok and Device and Device.hasWifiRestore) then return false end
                local ok2, v = pcall(function() return Device:hasWifiRestore() end)
                return ok2 and v and true or false
            end,
        },
        hooks = {
            notify_wifi_off = function()
                local s = source()
                if s and s.notifyWifiOff then s.notifyWifiOff() end
            end,
            on_online = function()
                local s = source()
                if s and s.notifyReconnected then s.notifyReconnected() end
            end,
        },
    }
    return _default
end

--- Drop the default instance (tests only).
function Wifi._resetDefault()
    _default = nil
end

return Wifi
