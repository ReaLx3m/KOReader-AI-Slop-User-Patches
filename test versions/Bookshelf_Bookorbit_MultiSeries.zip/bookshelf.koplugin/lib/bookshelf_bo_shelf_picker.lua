--[[
"Shelf from your library" picker for the BookOrbit micro-module of that name.

BookOrbit's board lets a shelf show one library, collection, SmartScope,
author or series. In Bookshelf the choice is made when the module is added (and
changed later from its settings): this asks WHICH KIND of list, loads that list
from the server, and hands back the pick as

    { source = "<section>", params = { libraryId = ... }, title = "<name>" }

which is exactly the `props` shape BookOrbit's shelf widget and this plugin's
data layer already understand (source is one of libraries, collections,
smart-scopes, authors, series).

Picker.pick(done): done(shelf) with the choice, or done(nil) if cancelled.
Network calls run on a scheduled tick after Wi-Fi is up, never in a render.
]]
local logger = require("logger")
local _ = require("lib/bookshelf_i18n").gettext

local Picker = {}

local KINDS = {
    { section = "libraries", label = function() return _("A library") end },
    { section = "collections", label = function() return _("A collection") end },
    { section = "smart-scopes", label = function() return _("A SmartScope") end },
    { section = "authors", label = function() return _("An author") end },
    { section = "series", label = function() return _("A series") end },
}

local function notify(text)
    local InfoMessage = require("ui/widget/infomessage")
    require("ui/uimanager"):show(InfoMessage:new{ text = text, timeout = 3 })
end

-- One page of entries of a section; tapping an entry finishes the pick.
local function showEntries(section, page, state)
    local UIManager = require("ui/uimanager")
    local NetworkMgr = require("ui/network/manager")
    local BO = require("lib/bookshelf_bookorbit")
    local Catalog = require("lib/bookshelf_bookorbit_catalog")
    NetworkMgr:runWhenOnline(function()
        UIManager:scheduleIn(0.05, function()
            local body, err = BO.catalogSection(section, { page = page })
            if not body then
                logger.warn("[bookshelf] shelf picker: section failed:", section, err)
                notify(_("Couldn't load the list from BookOrbit."))
                state.finish(nil)
                return
            end
            local Menu = require("ui/widget/menu")
            local Device = require("device")
            local items = {}
            if page > 1 then
                items[#items + 1] = { text = _("← Previous page"), callback = function()
                    state.keep = true
                    UIManager:close(state.menu)
                    showEntries(section, page - 1, state)
                end }
            end
            for _i, entry in ipairs(body.items or {}) do
                items[#items + 1] = {
                    text = entry.title or _("Untitled"),
                    mandatory = entry.count and tostring(entry.count) or nil,
                    callback = function()
                        state.keep = true
                        UIManager:close(state.menu)
                        state.finish{
                            source = section,
                            params = Catalog.paramsForEntry(section, entry),
                            title = entry.title,
                        }
                    end,
                }
            end
            if body.hasNext then
                items[#items + 1] = { text = _("Next page →"), callback = function()
                    state.keep = true
                    UIManager:close(state.menu)
                    showEntries(section, page + 1, state)
                end }
            end
            if #items == 0 then
                items[#items + 1] = { text = _("Nothing here yet."), enabled = false }
            end
            state.keep = false
            state.menu = Menu:new{
                title = _("Pick a list for this shelf"),
                item_table = items,
                is_borderless = true,
                is_popout = false,
                width = Device.screen:getWidth(),
                height = Device.screen:getHeight(),
                -- Closing without choosing cancels the add.
                close_callback = function()
                    if not state.keep then state.finish(nil) end
                end,
            }
            UIManager:show(state.menu)
        end)
    end)
end

function Picker.pick(done)
    local UIManager = require("ui/uimanager")
    local BO = require("lib/bookshelf_bookorbit")
    local finished = false
    local function finish(shelf)
        if finished then return end
        finished = true
        done(shelf)
    end
    if not BO.isConfigured() then
        notify(_("Set up your BookOrbit server first (Bookshelf menu → BookOrbit → Connect)."))
        return finish(nil)
    end
    local ButtonDialog = require("ui/widget/buttondialog")
    local dialog
    local buttons = {}
    for _i, kind in ipairs(KINDS) do
        buttons[#buttons + 1] = {{ text = kind.label(), callback = function()
            UIManager:close(dialog)
            showEntries(kind.section, 1, { finish = finish })
        end }}
    end
    buttons[#buttons + 1] = {{ text = _("Cancel"), callback = function()
        UIManager:close(dialog)
        finish(nil)
    end }}
    dialog = ButtonDialog:new{
        title = _("Show a shelf of"),
        title_align = "center",
        buttons = buttons,
    }
    UIManager:show(dialog)
end

return Picker
