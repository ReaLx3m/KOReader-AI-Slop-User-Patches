--[[--
Auto Wi-Fi sub-setting 2: "Push progress on sleep" (setting key auto_wifi_sync_on_sleep).

What KOReader does when the user presses sleep (verified against v2025.08
and master, `frontend/device/generic/device.lua` Device:onPowerEvent and
`frontend/device/kobo/device.lua` Kobo:suspend; see HANDOFF batch 4):

  1. the screensaver is shown,
  2. Wi-Fi is switched OFF (suspend can deadlock with it on),
  3. the `Suspend` event is broadcast (this is where our onSuspend runs;
     input is already inhibited and the screensaver is already up),
  4. the real suspend is scheduled `suspend_wait_timeout` (15 s) later; just
     before suspending, Kobo:suspend() kills Wi-Fi once more and its own
     comment expects Suspend handlers that bring Wi-Fi up.

So there is NOTHING to intercept or hold: the device stays awake for about
15 s after our handler is called. We use that window, with a cap safely
below it, to bring Wi-Fi up, push, and switch Wi-Fi off again. Sleep always
proceeds; if the push cannot be done it is queued (markPendingSync).

Consequences for the design:
  * No on-screen notice: the screensaver is already showing, and anything
    drawn now would be left on the sleep screen.
  * The cap is derived from the device's suspend delay (cap = delay - 3 s,
    at most 15 s, at least 5 s) instead of a fixed 15 s, which would race
    KOReader's own suspend.
  * Sleep sync is an explicit trigger: it clears a manual Wi-Fi off.
  * It works with or without "Disconnect Wi-Fi when book is opened": the
    lease is taken with off_when_done, so Wi-Fi (which KOReader had already
    switched off) is switched off again afterwards and the controller does
    not reconnect it under the suspend.

Everything is injected so the logic runs off-device (test_bo_sleep.lua).
]]

local Sleep = {}

-- Margin kept below the device's own suspend delay.
Sleep.SAFETY_MARGIN = 3
Sleep.MAX_CAP = 15
Sleep.MIN_CAP = 5
Sleep.DEFAULT_SUSPEND_DELAY = 15

--- Seconds we may spend connecting before sleep must go ahead.
-- device: optional Device-like table (suspend_wait_timeout,
-- screensaver_suspend_wait_timeout).
function Sleep.cap(device)
    local delay = device and (tonumber(device.screensaver_suspend_wait_timeout)
        or tonumber(device.suspend_wait_timeout)) or Sleep.DEFAULT_SUSPEND_DELAY
    local cap = delay - Sleep.SAFETY_MARGIN
    if cap > Sleep.MAX_CAP then cap = Sleep.MAX_CAP end
    if cap < Sleep.MIN_CAP then cap = Sleep.MIN_CAP end
    return cap
end

--- Run the sleep sync for the open book.
-- ctx = {
--   bookorbit = BookOrbit-like (autoWifiSyncOnSleep, isConfigured,
--               autoSyncEnabled, getBookHash, progressChangedSincePush,
--               pushProgressGuarded (falls back to pushProgress),
--               markPendingSync, submitSyncJob, SYNC_PRIORITY),
--   wifi      = controller (acquire/release),
--   fp, pct, pos = the open book and its live place,
--   device    = Device-like, for the cap (optional),
--   logger    = optional,
-- }
-- Returns a short status string (also what the tests assert on):
--   "disabled" | "not_configured" | "unchanged" | "no_progress" | "started"
function Sleep.run(ctx)
    local bo, wifi, lg = ctx.bookorbit, ctx.wifi, ctx.logger
    local function log(level, ...)
        if lg and lg[level] then pcall(lg[level], ...) end
    end

    if not (bo.autoWifiSyncOnSleep and bo.autoWifiSyncOnSleep()) then return "disabled" end
    if not (bo.isConfigured and bo.isConfigured() and bo.autoSyncEnabled and bo.autoSyncEnabled()) then
        return "not_configured"
    end
    local fp, pct, pos = ctx.fp, ctx.pct, ctx.pos
    if not (fp and pct) then return "no_progress" end
    -- D2: do not wake the radio for nothing.
    if not bo.progressChangedSincePush(fp, pct, pos) then
        log("dbg", "[bookshelf] sleep sync: nothing changed, Wi-Fi left off")
        return "unchanged"
    end

    local hash = bo.getBookHash(fp)
    local lease
    local function queue()
        -- The place is safe: the next time the device is online the pending
        -- outbox pushes it (Bookshelf:onNetworkConnected -> retryPendingSyncs).
        pcall(bo.markPendingSync, fp, hash)
    end
    -- Idempotent; also called through the job's cleanup so the lease cannot
    -- leak when the coordinator drops or the job throws.
    local released = false
    local function afterDone()
        if released then return end
        released = true
        if lease then wifi:release(lease) end
    end

    lease = wifi:acquire("sleep_sync",
        function()
            -- Online (possibly synchronously, before acquire returned).
            local job = {
                family  = "progress:" .. (hash or fp),
                label   = "push progress (on sleep)",
                cleanup = afterDone,
                run = function()
                    -- Guarded (Batch 6A): ask the server first. When another
                    -- device wrote a place we have not weighed, skip the push
                    -- and do NOT queue it: the queued place would be obsolete
                    -- (D23; the next open pulls the newer place).
                    local push = bo.pushProgressGuarded or bo.pushProgress
                    local ok, res, err = pcall(push, fp, pct, pos)
                    if ok and err == "server_ahead" then
                        log("info", "[bookshelf] sleep sync: server is ahead, push skipped")
                    elseif not (ok and res == true) then
                        queue()
                    end
                end,
            }
            if bo.SYNC_PRIORITY then job.priority = bo.SYNC_PRIORITY.manual end
            local ok_s, status = pcall(bo.submitSyncJob, job)
            if not ok_s then
                log("warn", "[bookshelf] sleep sync: submit failed:", status)
                queue()
                afterDone()
            end
        end,
        function(err)
            log("info", "[bookshelf] sleep sync: Wi-Fi did not come up (" .. tostring(err) .. "), queued")
            queue()
        end,
        { timeout = Sleep.cap(ctx.device), trigger = true, off_when_done = true })

    -- on_ready may already have run and finished before acquire returned.
    if released and lease then wifi:release(lease) end
    return "started"
end

return Sleep
