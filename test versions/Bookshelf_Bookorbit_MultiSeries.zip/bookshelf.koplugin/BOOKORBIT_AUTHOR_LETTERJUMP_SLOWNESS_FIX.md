# BookOrbit: "Go to letter" very slow (30+ seconds) on Authors/Series with covers enabled

## Symptom

Opening the page-jump dialog's "Go to letter" from a chip pointed at
BookOrbit's "All authors" (or "All series") root took 30+ seconds --
but only when Settings > BookOrbit > "Show covers on Author/Series
tiles" (`bookorbit_group_covers`) was on. With that setting off, the
same jump was fast.

## Root cause

`BookshelfWidget:_jumpToLetterPrefix` needs the FULL sorted list just to
work out which page a given letter falls on. For an ordinary chip it
asks the repo for that list with `{ lazy_cover = true, light_only =
true }` -- the same "just the sort-key fields, skip any cover work"
contract every source already honors for this exact call (a metadata-
only scan across up to ~10000 entries, never rendered).

`Repo.getBySource`'s BookOrbit **group-root** branch (the one that
serves the Authors/Series "All ..." tile view -- see
`BOOKORBIT_GROUPED_AUTHORS_SERIES.md`) dropped those `opts` on the
floor:

```lua
if BOSource.isGroupRoot and BOSource.isGroupRoot(source.id) then
    ...
    return BOSource.listGroups(section, off, lim)   -- opts never passed
end
```

...and `listGroups` didn't accept an `opts` argument at all -- whether
it resolved each tile's sample-book/cover was gated *only* on the
`bookorbit_group_covers` setting:

```lua
local show_covers = M.groupCoversEnabled(section)
...
if show_covers then
    local sample = M.listBooks(gid, 0, 1)   -- one blocking catalogBooks() round trip
```

So with covers on, a single letter-jump on "All Authors" synchronously
fired **one blocking network round trip per author** across the entire
(thousands-large) window `_jumpToLetterPrefix` requested -- not just
the handful of tiles actually visible on a page -- before the letter
search could even start. With covers off, that whole block was already
skipped (by design, to avoid the per-tile `catalogBooks` cost when the
setting is disabled), which is exactly why disabling it "fixed" the
slowness.

## Fix

Two changes:

1. **`lib/bookshelf_bookorbit_source.lua`** -- `M.listGroups` now takes
   an `opts` 4th argument. `opts.light_only` skips the per-tile
   sample-book/cover resolution entirely, regardless of the
   `bookorbit_group_covers` setting.

   Note it's gated on `light_only` specifically, **not** `lazy_cover`:
   `lazy_cover` is set unconditionally on every ordinary chip render
   (`BookshelfWidget:_fetchChipItems` always sets `fetch_opts = {
   lazy_cover = true }`), where it just means "don't decode inline,
   `scheduleCoverFills` will fill it asynchronously" -- not "skip
   resolution altogether". An earlier version of this fix gated on
   `light_only or lazy_cover`, which made every normal render look like
   a metadata-only scan and stopped Authors/Series tiles from ever
   getting a cover at all, regardless of the covers setting. Only
   `light_only` -- set exclusively by `_jumpToLetterPrefix`'s bulk
   sort-key scan -- actually distinguishes that case.
2. **`lib/bookshelf_book_repository.lua`** -- `Repo.getBySource`'s
   group-root branch now forwards its own `opts` parameter through to
   `listGroups`.

Both changes are additive (an extra, optional argument on a
single-call-site function), so an ordinary render -- small offset/limit
window, `lazy_cover` set but not `light_only` -- resolves covers exactly
as before. Only `_jumpToLetterPrefix`'s bulk metadata-only scan now
actually gets the metadata-only behavior it always asked for.

## Testing

`luac5.1 -p` syntax check passed on both touched files. Not yet run
inside KOReader against a live BookOrbit server; would be good to time
"Go to letter" on a real Authors chip with covers enabled, before/after,
on a library with enough authors to have made this noticeable.
